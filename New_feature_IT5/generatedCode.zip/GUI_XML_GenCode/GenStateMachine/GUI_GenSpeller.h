/*  This file has been generated on 05.12.2014 16:37 */
/*
 *
 */


DEFINE_EMPTY( 94 )
DEFINE_FILL( 167 )
DEFINE_EOL( 182 )
DEFAULT_SEQUENCE("default")

BEGIN_LAYOUTS()
    LAYOUT( all_fill, "\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7^^^^^ ^^^" )
    LAYOUT( alphabet_QWERTY, "QWERTYUIOPASDFGHJKL-ZXCVBNM,.\xC2\xA7\xC2\xA7\xC2\xA7 \xC2\xA7\xC2\xA7\xC2\xA7" )
    LAYOUT( alphabet_QWERTZ, "QWERTZUIOPASDFGHJKL-YXCVBNM,.\xC2\xA7\xC2\xA7\xC2\xA7 \xC2\xA7\xC2\xA7\xC2\xA7" )
    LAYOUT( alphabet_arab_QWERTY, "\xD8\xB6\xD8\xB5\xD8\xAB\xD9\x82\xD9\x81\xD8\xBA\xD8\xB9\xD9\x87\xD8\xAE\xD8\xAD\xD8\xB4\xD8\xB3\xD9\x8A\xD8\xA8\xD9\x84\xD8\xA7\xD8\xAA\xD9\x86\xD9\x85\xD8\xA6\xD8\xA1\xD8\xA4\xD8\xB1\xD9\x89\xD8\xA9\xD9\x88\xD8\xB2\xD8\xB8\xD8\xB0\xD9\x83\xD8\xB7\xD8\xAC \xD8\xAF\xC2\xA7\xC2\xA7" )
    LAYOUT( alphabet_arab_QWERTY_sms, "\xD8\xB6\xD8\xB5\xD8\xAB\xD9\x82\xD9\x81\xD8\xBA\xD8\xB9\xD9\x87\xD8\xAE\xD8\xAD\xD8\xB4\xD8\xB3\xD9\x8A\xD8\xA8\xD9\x84\xD8\xA7\xD8\xAA\xD9\x86\xD9\x85\xD8\xA6\xD8\xA1\xD8\xA4\xD8\xB1\xD9\x89\xD8\xA9\xD9\x88\xD8\xB2\xD8\xB8\xD8\xB0\xD9\x83\xD8\xB7\xD8\xAC \xD8\xAF^\xC2\xB6" )
    LAYOUT( alphabet_bulgaria_QWERTY, "\xD0\xAB\xD0\xA3\xD0\x95\xD0\x98\xD0\xA8\xD0\xA9\xD0\x9A\xD0\xA1\xD0\x94\xD0\x97\xD0\xAC\xD0\xAF\xD0\x90\xD0\x9E\xD0\x96\xD0\x93\xD0\xA2\xD0\x9D\xD0\x92\xD0\xAE\xD0\x99\xD0\xAA\xD0\xAD\xD0\xA4\xD0\xA5\xD0\x9F\xD0\xA0\xD0\x9B\xD0\x91\xD0\xA6\xD0\x9C\xD0\xA7 \xC2\xA7\xC2\xA7\xC2\xA7" )
    LAYOUT( alphabet_cyr_QWERTY, "\xD0\x99\xD0\xA6\xD0\xA3\xD0\x9A\xD0\x95\xD0\x9D\xD0\x93\xD0\xA8\xD0\xA9\xD0\x97\xD0\xA4\xD0\xAB\xD0\x92\xD0\x90\xD0\x9F\xD0\xA0\xD0\x9E\xD0\x9B\xD0\x94^\xD0\xAF\xD0\xA7\xD0\xA1\xD0\x9C\xD0\x98\xD0\xA2\xD0\xAC\xD0\x91\xD0\xAE\xD0\xA5\xD0\xAA\xD0\x96 \xD0\xAD\xD0\x81\xC2\xA7" )
    LAYOUT( alphabet_french_AZERTY, "AZERTYUIOPQSDFGHJKL-WXCVBNM,.\xC2\xA7\xC2\xA7\xC2\xA7 \xC2\xA7\xC2\xA7\xC2\xA7" )
    LAYOUT( alphabet_greek_QWERTY, "^^\xCE\x95\xCE\xA1\xCE\xA4\xCE\xA5\xCE\x98\xCE\x99\xCE\x9F\xCE\xA0\xCE\x91\xCE\xA3\xCE\x94\xCE\xA6\xCE\x93\xCE\x97\xCE\x9E\xCE\x9A\xCE\x9B-\xCE\x96\xCE\xA7\xCE\xA8\xCE\xA9\xCE\x92\xCE\x9D\xCE\x9C,.\xC2\xA7\xC2\xA7\xC2\xA7 \xC2\xA7\xC2\xA7\xC2\xA7" )
    LAYOUT( alphabet_greek_lo_qwerty_sms, ";\xCF\x82\xCE\xB5\xCF\x81\xCF\x84\xCF\x85\xCE\xB8\xCE\xB9\xCE\xBF\xCF\x80\xCE\xB1\xCF\x83\xCE\xB4\xCF\x86\xCE\xB3\xCE\xB7\xCE\xBE\xCE\xBA\xCE\xBB-\xCE\xB6\xCF\x87\xCF\x88\xCF\x89\xCE\xB2\xCE\xBD\xCE\xBC,.*+^ ()\xC2\xB6" )
    LAYOUT( alphabet_greek_up_QWERTY_sms, ":\xCF\x82\xCE\x95\xCE\xA1\xCE\xA4\xCE\xA5\xCE\x98\xCE\x99\xCE\x9F\xCE\xA0\xCE\x91\xCE\xA3\xCE\x94\xCE\xA6\xCE\x93\xCE\x97\xCE\x9E\xCE\x9A\xCE\x9B-\xCE\x96\xCE\xA7\xCE\xA8\xCE\xA9\xCE\x92\xCE\x9D\xCE\x9C,.@'^ !?\xC2\xB6" )
    LAYOUT( alphabet_lo_azerty_sms, "azertyuiopqsdfghjkl-wxcvbnm,.*+; ()\xC2\xB6" )
    LAYOUT( alphabet_lo_cyr_qwerty_sms, "\xD0\xB9\xD1\x86\xD1\x83\xD0\xBA\xD0\xB5\xD0\xBD\xD0\xB3\xD1\x88\xD1\x89\xD0\xB7\xD1\x84\xD1\x8B\xD0\xB2\xD0\xB0\xD0\xBF\xD1\x80\xD0\xBE\xD0\xBB\xD0\xB4.\xD1\x8F\xD1\x87\xD1\x81\xD0\xBC\xD0\xB8\xD1\x82\xD1\x8C\xD0\xB1\xD1\x8E\xD1\x85\xD1\x8A\xD0\xB6 \xD1\x8D\xD1\x91\xC2\xB6" )
    LAYOUT( alphabet_lo_qwerty_sms, "qwertyuiopasdfghjkl-zxcvbnm,.*+; ()\xC2\xB6" )
    LAYOUT( alphabet_lo_qwertz_sms, "qwertzuiopasdfghjkl-yxcvbnm,.*+; ()\xC2\xB6" )
    LAYOUT( alphabet_macedonia_QWERTZ, "\xD0\x89\xD0\x8A\xD0\x95\xD0\xA0\xD0\xA2\xD0\x85\xD0\xA3\xD0\x98\xD0\x9E\xD0\x9F\xD0\x90\xD0\xA1\xD0\x94\xD0\xA4\xD0\x93\xD0\xA5\xD0\x88\xD0\x9A\xD0\x9B/\xD0\x97\xD0\x8F\xD0\xA6\xD0\x92\xD0\x91\xD0\x9D\xD0\x9C,.\xD0\xA8\xD0\x83\xD0\xA7 \xD0\x8C\xD0\x96\xC2\xA7" )
    LAYOUT( alphabet_portuguese_QWERTY, "QWERTYUIOPASDFGHJKL\xC3\x87ZXCVBNM,.\xC2\xA7\xC2\xA7\xC2\xA7 \xC2\xA7\xC2\xA7\xC2\xA7" )
    LAYOUT( alphabet_portuguese_lo_qwerty_sms, "qwertyuiopasdfghjkl\xC3\xA7zxcvbnm,.*+; ()\xC2\xB6" )
    LAYOUT( alphabet_serbia_QWERTZ, "\xD0\x89\xD0\x8A\xD0\x95\xD0\xA0\xD0\xA2\xD0\x97\xD0\xA3\xD0\x98\xD0\x9E\xD0\x9F\xD0\x90\xD0\xA1\xD0\x94\xD0\xA4\xD0\x93\xD0\xA5\xD0\x88\xD0\x9A\xD0\x9B-\xD0\x85\xD0\x8F\xD0\xA6\xD0\x92\xD0\x91\xD0\x9D\xD0\x9C,.\xD0\xA8\xD0\x82\xD0\xA7 \xD0\x8B\xD0\x96\xC2\xA7" )
    LAYOUT( alphabet_thai_1, "\xE0\xB9\x85/-\xE0\xB8\xA0\xE0\xB8\x96\xE0\xB8\xB8\xE0\xB8\xB6\xE0\xB8\x84\xE0\xB8\x95\xE0\xB8\x88\xE0\xB8\x82\xE0\xB8\x8A\xE0\xB9\x86\xE0\xB9\x84\xE0\xB8\xB3\xE0\xB8\x9E\xE0\xB8\xB0\xE0\xB8\xB1\xE0\xB8\xB5\xE0\xB8\xA3\xE0\xB8\x99\xE0\xB8\xA2\xE0\xB8\x9A\xE0\xB8\xA5\xE0\xB8\x9F\xE0\xB8\xAB\xE0\xB8\x81\xE0\xB8\x94\xE0\xB9\x80\xE0\xB9\x89\xE0\xB9\x88\xE0\xB8\xB2\xE0\xB8\xAA\xE0\xB8\xA7\xE0\xB8\x87\xE0\xB8\x83\xE0\xB8\x9C\xE0\xB8\x9B\xE0\xB9\x81\xE0\xB8\xAD\xE0\xB8\xB4\xE0\xB8\xB7\xE0\xB8\x97\xE0\xB8\xA1\xE0\xB9\x83\xE0\xB8\x9D " )
    LAYOUT( alphabet_thai_2, "+\xE0\xB9\x91\xE0\xB9\x92\xE0\xB9\x93\xE0\xB9\x94\xE0\xB8\xB9\xE0\xB8\xBF\xE0\xB9\x95\xE0\xB9\x96\xE0\xB9\x97\xE0\xB9\x98\xE0\xB9\x99\xE0\xB9\x90\x22\xE0\xB8\x8E\xE0\xB8\x91\xE0\xB8\x98\xE0\xB9\x8D\xE0\xB9\x8A\xE0\xB8\x93\xE0\xB8\xAF\xE0\xB8\x8D\xE0\xB8\x90,\xE0\xB8\xA4\xE0\xB8\x86\xE0\xB8\x8F\xE0\xB9\x82\xE0\xB8\x8C\xE0\xB9\x87\xE0\xB9\x8B\xE0\xB8\xA9\xE0\xB8\xA8\xE0\xB8\x8B.()\xE0\xB8\x89\xE0\xB8\xAE\xE0\xB8\xB8\xE0\xB9\x8C?\xE0\xB8\x92\xE0\xB8\xAC\xE0\xB8\xA6^ " )
    LAYOUT( alphabet_ukraine_QWERTY, "\xD0\x99\xD0\xA6\xD0\xA3\xD0\x9A\xD0\x95\xD0\x9D\xD0\x93\xD0\xA8\xD0\xA9\xD0\x97\xD0\xA4\xD0\x98\xD0\x92\xD0\x90\xD0\x9F\xD0\xA0\xD0\x9E\xD0\x9B\xD0\x94\xD0\xAF\xD0\xA7\xD0\xA1\xD0\x9C\xD0\x86\xD0\xA2\xD0\xAC\xD0\x91\xD0\xAE\xD0\x87\xD0\xA5\xD2\x90\xD0\x96 \xD0\x84\xC2\xA7\xC2\xA7" )
    LAYOUT( alphabet_up_AZERTY_sms, "AZERTYUIOPQSDFGHJKL-WXCVBNM,.@': !?\xC2\xB6" )
    LAYOUT( alphabet_up_QWERTY_sms, "QWERTYUIOPASDFGHJKL-ZXCVBNM,.@': !?\xC2\xB6" )
    LAYOUT( alphabet_up_QWERTZ_sms, "QWERTZUIOPASDFGHJKL-YXCVBNM,.@': !?\xC2\xB6" )
    LAYOUT( alphabet_up_cyr_QWERTY_sms, "\xD0\x99\xD0\xA6\xD0\xA3\xD0\x9A\xD0\x95\xD0\x9D\xD0\x93\xD0\xA8\xD0\xA9\xD0\x97\xD0\xA4\xD0\xAB\xD0\x92\xD0\x90\xD0\x9F\xD0\xA0\xD0\x9E\xD0\x9B\xD0\x94.\xD0\xAF\xD0\xA7\xD0\xA1\xD0\x9C\xD0\x98\xD0\xA2\xD0\xAC\xD0\x91\xD0\xAE\xD0\xA5\xD0\xAA\xD0\x96 \xD0\xAD\xD0\x81\xC2\xB6" )
    LAYOUT( alphabet_us_QWERTY, "QWERTYUIOPASDFGHJKL-ZXCVBNM,.\xC2\xA7\xC2\xA7\xC2\xA7 \xC2\xA7\xC2\xA7\xC2\xA7" )
    LAYOUT( freetext1_cyr, "\xD0\x82\xD0\x83\xD0\x84\xD0\x85\xD0\x86\xD0\x87\xD0\x88\xD0\x89\xD0\x8A\xD0\x8B\xD0\x8C\xD0\x8E\xD0\x8F^^^^^^^^^^^^^^^^@': &()" )
    LAYOUT( freetext1_fr_sms, "1234567890\xC3\x80\xC3\x81\xC3\x82\xC3\x86\xC3\x87\xC3\x88\xC3\x89\xC3\x8A\xC3\x8B/\xC3\x8C\xC3\x8D\xC3\x8E\xC3\x8F\xC3\x94\xC5\x92\xC3\x99\xC3\x9B^&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext1_it_sms, "1234567890\xC3\x80\xC3\x88\xC3\x89\xC3\x8C\xC3\x8D\xC3\x8F\xC3\x92\xC3\x93\xC3\x99\xC3\x9A/^^^^^^^^&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext1_nl_sms, "1234567890\xC3\x80\xC3\x81\xC3\x82\xC3\x84\xC3\x88\xC3\x89\xC3\x8A\xC3\x8B/\xC3\x8C\xC3\x8D\xC3\x8E\xC3\x8F\xC3\x92\xC3\x93\xC3\x94\xC3\x96\xC3\x99^&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext1_pl_sms, "1234567890\xC4\x84\xC4\x86\xC4\x98\xC5\x81\xC5\x83\xC3\x93\xC5\x9A\xC5\xB9\xC5\xBB\xC4\x85\xC4\x87\xC4\x99\xC5\x82\xC5\x84\xC3\xB3\xC5\x9B\xC5\xBA\xC5\xBC/&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext1_tr_sms, "1234567890\xC3\x80\xC3\x81\xC3\x82\xC3\x84\xC3\x87\xC3\x88\xC3\x89\xC3\x8A/\xC3\x8C\xC3\x8D\xC3\x8E\xC3\x8F\xC3\x91^^^^^&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext2_NAR, "_.,!?\xC2\xA1\xC2\xBF/+*%#;$\xC2\xA2\xE2\x82\xAC\xC2\xA5^^^^^^^^^^^^^^^ ^^^" )
    LAYOUT( freetext2_de, "\xC4\x8A\xC3\x87\xC4\x86\xC4\x88\xC4\x8C\xC3\x90\xC4\x8E\xC4\x90\xC3\x89\xC3\x88\xC3\x8A\xC3\x8B\xC4\x92\xC4\x96\xC4\x98\xC4\x9A\xC4\x9C\xC4\x9E\xC4\xA0\xC4\xA2\xC3\x8D\xC3\x8C\xC3\x8E\xC3\x8F\xC4\xAA\xC4\xAC\xC4\xAE\xC4\xB0\xC4\xB6\xC4\xB9\xC4\xBB\xC4\xBD \xC5\x81^^" )
    LAYOUT( freetext2_es, "\xC4\x80\xC4\x82\xC4\x84\xC4\x8A\xC3\x87\xC4\x86\xC4\x88\xC4\x8C\xC3\x90\xC4\x8E\xC4\x90\xC3\x88\xC3\x8A\xC3\x8B\xC4\x92\xC4\x96\xC4\x98\xC4\x9A\xC4\x9C\xC4\x9E\xC4\xA0\xC4\xA2\xC3\x8C\xC3\x8E\xC3\x8F\xC4\xAA\xC4\xAC\xC4\xAE\xC4\xB0\xC4\xB6\xC4\xB9\xC4\xBB \xC4\xBD\xC5\x81^" )
    LAYOUT( freetext2_fr, "\xC3\x83\xC3\x84\xC3\x85\xC4\x80\xC4\x82\xC4\x84\xC4\x8A\xC4\x86\xC4\x88\xC4\x8C\xC3\x90\xC4\x8E\xC4\x90\xC4\x92\xC4\x96\xC4\x98\xC4\x9A\xC4\x9C\xC4\x9E\xC4\xA0\xC4\xA2\xC4\xAA\xC4\xAC\xC4\xAE\xC4\xB0\xC4\xB6\xC4\xB9\xC4\xBB\xC4\xBD\xC5\x81*% #\xC2\xA1\xC2\xBF" )
    LAYOUT( freetext2_fr_sms, "1234567890\xC3\xA0\xC3\xA1\xC3\xA2\xC3\xA6\xC3\xA7\xC3\xA8\xC3\xA9\xC3\xAA\xC3\xAB/\xC3\xAC\xC3\xAD\xC3\xAE\xC3\xAF\xC3\xB4\xC5\x93\xC3\xB9\xC3\xBB^&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext2_it, "\xC3\x81\xC3\x82\xC3\x83\xC3\x84\xC3\x85\xC3\x86\xC4\x80\xC4\x82\xC4\x84\xC4\x8A\xC3\x87\xC4\x86\xC4\x88\xC4\x8C\xC3\x90\xC4\x8E\xC4\x90\xC3\x8A\xC3\x8B\xC4\x92\xC4\x96\xC4\x98\xC4\x9A\xC4\x9C\xC4\x9E\xC4\xA0\xC4\xA2\xC3\x8E\xC4\xAA\xC4\xAC\xC4\xAE\xC4\xB0 \xC4\xB6\xC4\xB9\xC4\xBB" )
    LAYOUT( freetext2_it_sms, "1234567890\xC3\xA0\xC3\xA8\xC3\xA9\xC3\xAC\xC3\xAD\xC3\xAF\xC3\xB2\xC3\xB3\xC3\xB9\xC3\xBA/^^^^^^^^&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext2_lat, "\xC4\x88\xC4\x8C\xC3\x90\xC4\x8E\xC4\x90\xC3\x89\xC3\x88\xC3\x8A\xC3\x8B\xC4\x92\xC4\x96\xC4\x98\xC4\x9A\xC4\x9C\xC4\x9E\xC4\xA0\xC4\xA2\xC3\x8D\xC3\x8C\xC3\x8E\xC3\x8F\xC4\xAA\xC4\xAC\xC4\xAE\xC4\xB0\xC4\xB6\xC4\xB9\xC4\xBB\xC4\xBD\xC5\x81\xC3\x91\xC5\x83 \xC5\x85\xC5\x87^" )
    LAYOUT( freetext2_nl, "\xC3\x80\xC3\x82\xC3\x83\xC3\x85\xC3\x86\xC4\x80\xC4\x82\xC4\x84\xC4\x8A\xC3\x87\xC4\x86\xC4\x88\xC4\x8C\xC3\x90\xC4\x8E\xC4\x90\xC3\x88\xC3\x8A\xC4\x92\xC4\x96\xC4\x98\xC4\x9A\xC4\x9C\xC4\x9E\xC4\xA0\xC4\xA2\xC3\x8C\xC3\x8E\xC4\xAA\xC4\xAC\xC4\xAE\xC4\xB0 \xC4\xB6\xC4\xB9\xC4\xBB" )
    LAYOUT( freetext2_nl_sms, "1234567890\xC3\xA0\xC3\xA1\xC3\xA2\xC3\xA4\xC3\xA8\xC3\xA9\xC3\xAA\xC3\xAB/\xC3\xAC\xC3\xAD\xC3\xAE\xC3\xAF\xC3\xB2\xC3\xB3\xC3\xB4\xC3\xB6\xC3\xB9^&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext2_pl, "\xC2\xA1\xC2\xBF*%#&$\xC2\xA2\xE2\x82\xAC\xC2\xA5()^^^^^^^^^^^^^^^^^^^^ ^^^" )
    LAYOUT( freetext2_pt, "\xC3\x84\xC3\x85\xC3\x86\xC4\x80\xC4\x82\xC4\x84\xC4\x8A\xC4\x86\xC4\x88\xC4\x8C\xC3\x90\xC4\x8E\xC4\x90\xC3\x88\xC3\x8B\xC4\x92\xC4\x96\xC4\x98\xC4\x9A\xC4\x9C\xC4\x9E\xC4\xA0\xC4\xA2\xC3\x8C\xC3\x8E\xC3\x8F\xC4\xAA\xC4\xAC\xC4\xAE\xC4\xB0\xC4\xB6\xC4\xB9 \xC4\xBB\xC4\xBD\xC5\x81" )
    LAYOUT( freetext2_tr, "\xC3\x83\xC3\x85\xC3\x86\xC4\x80\xC4\x82\xC4\x84\xC4\x8A\xC4\x86\xC4\x88\xC4\x8C\xC3\x90\xC4\x8E\xC4\x90\xC3\x88\xC3\x8A\xC3\x8B\xC4\x92\xC4\x96\xC4\x98\xC4\x9A\xC4\x9C\xC4\xA0\xC4\xA2\xC3\x8D\xC3\x8C\xC3\x8F\xC4\xAA\xC4\xAC\xC4\xAE\xC4\xB6\xC4\xB9\xC4\xBB \xC4\xBD\xC5\x81^" )
    LAYOUT( freetext2_tr_sms, "1234567890\xC3\xA0\xC3\xA1\xC3\xA2\xC3\xA4\xC3\xA7\xC3\xA8\xC3\xA9\xC3\xAA/\xC3\xAC\xC3\xAD\xC3\xAE\xC3\xAF\xC3\xB1^^^^^&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext3_de, "\xC3\x91\xC5\x83\xC5\x85\xC5\x87\xC3\x93\xC3\x92\xC3\x94\xC3\x95\xC3\x98\xC5\x8C\xC5\x90\xC5\x92\xC5\x94\xC5\x96\xC5\x98\xC5\x9A\xC5\x9E\xC5\xA0\xC5\xA2\xC5\xA4\xC3\x9A\xC3\x99\xC3\x9B\xC5\xA8\xC5\xAA\xC5\xAE\xC5\xB0\xC5\xB2\xC7\x93\xC3\x9D\xC5\xB8\xC5\xB9 \xC5\xBB\xC5\xBD^" )
    LAYOUT( freetext3_es, "\xC5\x83\xC5\x85\xC5\x87\xC3\x92\xC3\x94\xC3\x95\xC3\x96\xC3\x98\xC5\x8C\xC5\x90\xC5\x92\xC5\x94\xC5\x96\xC5\x98\xC5\x9A\xC5\x9E\xC5\xA0\xC3\x9F^\xC5\xA2\xC5\xA4\xC3\x99\xC3\x9B\xC5\xA8\xC5\xAA\xC5\xAE\xC5\xB0\xC5\xB2\xC7\x93\xC3\x9D\xC5\xB8\xC5\xB9 \xC5\xBB\xC5\xBD^" )
    LAYOUT( freetext3_fr, "\xC3\x91\xC5\x83\xC5\x85\xC5\x87\xC3\x93\xC3\x92\xC3\x95\xC3\x96\xC3\x98\xC5\x8C\xC5\x90\xC5\x94\xC5\x96\xC5\x98\xC5\x9A\xC5\x9E\xC5\xA0\xC3\x9F^\xC5\xA2\xC5\xA4\xC3\x9A\xC5\xA8\xC5\xAA\xC5\xAE\xC5\xB0\xC5\xB2\xC7\x93\xC3\x9D\xC5\xB9\xC5\xBB\xC5\xBD ^^^" )
    LAYOUT( freetext3_it, "\xC4\xBD\xC5\x81\xC3\x91\xC5\x83\xC5\x85\xC5\x87\xC3\x94\xC3\x95\xC3\x96\xC3\x98\xC5\x8C\xC5\x90\xC5\x92\xC5\x94\xC5\x96\xC5\x98\xC5\x9A\xC5\x9E\xC5\xA0\xC3\x9F\xC5\xA2\xC5\xA4\xC3\x9B\xC3\x9C\xC5\xA8\xC5\xAA\xC5\xAE\xC5\xB0\xC5\xB2\xC7\x93\xC3\x9D\xC5\xB8 \xC5\xB9\xC5\xBB\xC5\xBD" )
    LAYOUT( freetext3_lat, "\xC3\x93\xC3\x92\xC3\x94\xC3\x95\xC3\x96\xC3\x98\xC5\x8C\xC5\x90\xC5\x92\xC5\x94\xC5\x96\xC5\x98\xC5\x9A\xC5\x9E\xC5\xA0\xC3\x9F\xC5\xA2\xC5\xA4\xC3\x9A\xC3\x99\xC3\x9B\xC3\x9C\xC5\xA8\xC5\xAA\xC5\xAE\xC5\xB0\xC5\xB2\xC7\x93\xC3\x9D\xC5\xB8\xC5\xB9\xC5\xBB \xC5\xBD^^" )
    LAYOUT( freetext3_nl, "\xC4\xBD\xC5\x81\xC3\x91\xC5\x83\xC5\x85\xC5\x87\xC3\x92\xC3\x94\xC3\x95\xC3\x98\xC5\x8C\xC5\x90\xC5\x92\xC5\x94\xC5\x96\xC5\x98\xC5\x9A\xC5\x9E\xC5\xA0\xC3\x9F\xC5\xA2\xC5\xA4\xC3\x99\xC3\x9B\xC5\xA8\xC5\xAA\xC5\xAE\xC5\xB0\xC5\xB2\xC7\x93\xC3\x9D\xC5\xB8 \xC5\xB9\xC5\xBB\xC5\xBD" )
    LAYOUT( freetext3_pt, "\xC3\x91\xC5\x83\xC5\x85\xC5\x87\xC3\x92\xC3\x96\xC3\x98\xC5\x8C\xC5\x90\xC5\x92\xC5\x94\xC5\x96\xC5\x98\xC5\x9A\xC5\x9E\xC5\xA0\xC3\x9F\xC5\xA2\xC5\xA4\xC3\x9A\xC3\x99\xC3\x9B\xC3\x9C\xC5\xA8\xC5\xAA\xC5\xAE\xC5\xB0\xC5\xB2\xC7\x93^\xC3\x9D\xC5\xB8 \xC5\xB9\xC5\xBB\xC5\xBD" )
    LAYOUT( freetext3_tr, "\xC3\x91\xC5\x83\xC5\x85\xC5\x87\xC3\x93\xC3\x92\xC3\x94\xC3\x95\xC3\x98\xC5\x8C\xC5\x90\xC5\x92\xC5\x94\xC5\x96\xC5\x98\xC5\x9A\xC5\x9E\xC5\xA0\xC3\x9F\xC5\xA2\xC5\xA4\xC3\x9A\xC3\x99\xC5\xA8\xC5\xAA\xC5\xAE\xC5\xB0\xC5\xB2\xC7\x93^\xC3\x9D\xC5\xB8 \xC5\xB9\xC5\xBB\xC5\xBD" )
    LAYOUT( freetext_QWERTY, "QWERTYUIOPASDFGHJKL-ZXCVBNM,.@': &()" )
    LAYOUT( freetext_QWERTZ, "QWERTZUIOPASDFGHJKL-YXCVBNM,.@': &()" )
    LAYOUT( freetext_azerty_pwd1, "AZERTYUIOPQSDFGHJKL-WXCVBNM,.!#$^*/@" )
    LAYOUT( freetext_azerty_pwd2, "azertyuiopqsdfghjkl-wxcvbnm:;\x22%&^()?" )
    LAYOUT( freetext_de_sms, "1234567890\xC3\x84\xC3\x96\xC3\x9C\xC3\x9F^\xC3\xA4\xC3\xB6\xC3\xBC/^^^^^^^^^^&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext_es_sms, "1234567890^\xC3\x81\xC3\x89\xC3\x8D\xC3\x91\xC3\x93\xC3\x9A/^^^\xC3\xA1\xC3\xA9\xC3\xAD\xC3\xB1\xC3\xB3\xC3\xBA^^&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext_french_AZERTY, "AZERTYUIOPQSDFGHJKL-WXCVBNM,.@': &()" )
    LAYOUT( freetext_greek_QWERTY, "^^\xCE\x95\xCE\xA1\xCE\xA4\xCE\xA5\xCE\x98\xCE\x99\xCE\x9F\xCE\xA0\xCE\x91\xCE\xA3\xCE\x94\xCE\xA6\xCE\x93\xCE\x97\xCE\x9E\xCE\x9A\xCE\x9B-\xCE\x96\xCE\xA7\xCE\xA8\xCE\xA9\xCE\x92\xCE\x9D\xCE\x9C,.@': &()" )
    LAYOUT( freetext_lat_sms, "1234567890/^^^^^^^^^^^^^^^^^^&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext_number_pwd3, "1234567890()+_={}[]<>~\\^^^^^^^^^^^^^" )
    LAYOUT( freetext_portuguese_QWERTY, "QWERTYUIOPASDFGHJKL\xC3\x87ZXCVBNM,.@': &()" )
    LAYOUT( freetext_pt_sms, "1234567890\xC3\x82\xC3\x83\xC3\x8A\xC3\x93\xC3\x94\xC3\x95/-^^\xC3\xA2\xC3\xA3\xC3\xAA\xC3\xB3\xC3\xB4\xC3\xB5^^^&\xC2\xA1\xC2\xBF %#\xC2\xB6" )
    LAYOUT( freetext_qwerty_pwd1, "QWERTYUIOPASDFGHJKL-ZXCVBNM,.!#$^*/@" )
    LAYOUT( freetext_qwerty_pwd2, "qwertyuiopasdfghjkl-zxcvbnm:;%\x22&^()?" )
    LAYOUT( freetext_qwertz_pwd1, "QWERTZUIOPASDFGHJKL-YXCVBNM,.!#$^*/@" )
    LAYOUT( freetext_qwertz_pwd2, "qwertzuiopasdfghjkl-yxcvbnm:;\x22%&^()?" )
    LAYOUT( freetext_us_QWERTY, "QWERTYUIOPASDFGHJKL-ZXCVBNM,.@': &()" )
    LAYOUT( num_fill, "1234567890()\x22':\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7\xC2\xA7 \xC2\xA7\xC2\xA7\xC2\xA7" )
    LAYOUT( number_freetext1_NAR, "1234567890\xC3\x81\xC3\x80\xC3\x82\xC3\x86\xC3\x87\xC3\x89\xC3\x88\xC3\x8A\xC3\x8B\xC3\x8D\xC3\x8C\xC3\x8E\xC3\x8F\xC3\x91\xC3\x93\xC3\x92\xC3\x94\xC5\x92^\xC3\x9A\xC3\x99\xC3\x9B \xC3\x9C\xC5\xB8^" )
    LAYOUT( number_freetext1_de, "1234567890\xC3\x84\xC3\x96\xC3\x9C\xC3\x9F.,!?/+*%#\xC2\xA1\xC2\xBF\xC3\x81\xC3\x80\xC3\x82\xC3\x83\xC3\x84\xC3\x85\xC3\x86 \xC4\x80\xC4\x82\xC4\x84" )
    LAYOUT( number_freetext1_es, "1234567890\xC3\x81\xC3\x89\xC3\x8D\xC3\x91\xC3\x93\xC3\x9A\xC3\x9C.,\xC2\xA1\xC2\xBF!?/+*%#;\xC3\x80\xC3\x82\xC3\x83 \xC3\x84\xC3\x85\xC3\x86" )
    LAYOUT( number_freetext1_fr, "1234567890\xC3\x81\xC3\x80\xC3\x82\xC3\x86\xC3\x87\xC3\x89\xC3\x88\xC3\x8A\xC3\x8B\xC3\x8D\xC3\x8C\xC3\x8E\xC3\x8F\xC3\x94\xC5\x92\xC3\x99\xC3\x9B\xC3\x9C\xC5\xB8.,! ?/+" )
    LAYOUT( number_freetext1_gr, "1234567890\xCE\x86\xCE\x88\xCE\x89\xCE\x8A\xCE\xAA\xCE\x90\xCE\x8C\xCE\x8E\xCE\xAB\xCF\x82\xCE\x8F@.,:!?/+*%# &'\x22" )
    LAYOUT( number_freetext1_it, "1234567890.,!?/+*%#\xC3\x80\xC3\x89\xC3\x88\xC3\x8D\xC3\x8C\xC3\x8F\xC3\x93\xC3\x92\xC3\x9A\xC3\x99\xC2\xA1\xC2\xBF; ^^^" )
    LAYOUT( number_freetext1_lat, "1234567890.,!?\xC2\xA1\xC2\xBF/+*%#;\xC3\x81\xC3\x80\xC3\x82\xC3\x83\xC3\x84\xC3\x85\xC3\x86\xC4\x80\xC4\x82\xC4\x84 \xC4\x8A\xC3\x87\xC4\x86" )
    LAYOUT( number_freetext1_nl, "1234567890.,!?/+*%#\xC3\x81\xC3\x84\xC3\x89\xC3\x8B\xC3\x8D\xC3\x8F\xC3\x93\xC3\x96\xC3\x9A\xC3\x9C\xC2\xA1\xC2\xBF; ^^^" )
    LAYOUT( number_freetext1_pl, "1234567890\xC4\x84\xC4\x86\xC4\x98\xC5\x81\xC5\x83\xC3\x93\xC5\x9A\xC5\xB9\xC5\xBB@_.,:'!?/+^^^ ^^^" )
    LAYOUT( number_freetext1_pt, "1234567890\xC3\x81\xC3\x80\xC3\x82\xC3\x83\xC3\x87\xC3\x89\xC3\x8A\xC3\x8D^\xC3\x93\xC3\x94\xC3\x95.,!?\xC2\xA1\xC2\xBF/+-* %#^" )
    LAYOUT( number_freetext1_tr, "1234567890\xC3\x82\xC3\x87\xC3\x89\xC4\x9E\xC3\x8E\xC4\xB0\xC4\xB1\xC3\x96\xC5\x9E\xC3\x9C\xC3\x9B.,!?/+*%^#; \xC3\x81\xC3\x80\xC3\x84" )
    LAYOUT( number_freetext2_cyr, "1234567890.,!?-_/+*%#^^^^^^^^^^^ ^^^" )
    LAYOUT( number_freetext_others, "1234567890@.,:!?\xC2\xA1\xC2\xBF/+*%#&'()^^^^^ ^^^" )
    LAYOUT( phone_number, "123456789+0^" )
    LAYOUT( pin_number, "123456789-0^" )
    LAYOUT( pin_number_thai, "123456789-0/" )
END_LAYOUTS()

BEGIN_SEQUENCE( "default" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "freetext" )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext1_lat )
    ADDLAYOUT( freetext2_lat )
    ADDLAYOUT( freetext3_lat )
END_SEQUENCE

BEGIN_SEQUENCE( "pin" )
    ADDLAYOUT( pin_number )
END_SEQUENCE

BEGIN_SEQUENCE( "phone" )
    ADDLAYOUT( phone_number )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( freetext2_NAR )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTZ )
END_SEQUENCE

BEGIN_SEQUENCE( "da_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "de_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTZ )
END_SEQUENCE

BEGIN_SEQUENCE( "el_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "en_houseno" )
    ADDLAYOUT( pin_number_thai )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( freetext2_NAR )
END_SEQUENCE

BEGIN_SEQUENCE( "es_houseno" )
    ADDLAYOUT( pin_number_thai )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( freetext2_NAR )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_houseno" )
    ADDLAYOUT( pin_number_thai )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( freetext2_NAR )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTZ )
END_SEQUENCE

BEGIN_SEQUENCE( "it_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( freetext2_NAR )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "no_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( freetext1_cyr )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTZ )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "th_houseno" )
    ADDLAYOUT( pin_number_thai )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( freetext2_NAR )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( freetext1_cyr )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "us_houseno" )
    ADDLAYOUT( pin_number )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( freetext2_NAR )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_ALB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_AND_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_ARG_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_AUS_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_AUT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_BEL_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_BIH_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_CAN_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_CHE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_CZE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_DEU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_DNK_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_ESP_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_EST_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_FIN_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_FRA_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_GBR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_GIB_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_HRV_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_HUN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_IRL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_ITA_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_LIE_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_LTU_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_LUX_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_LVA_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_MCO_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_MEX_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_MYS_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_NLD_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_NOR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_NZL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_POL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_PRI_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_ROU_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_SMR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_SVK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_SVN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_SWE_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_TUR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_USA_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_VAT_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_ZAF_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_CAN_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_MEX_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_USA_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_ALB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_AND_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_ARG_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_AUS_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_AUT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_BEL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_BIH_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_CAN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_CHE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_CZE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_DEU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_DNK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_ESP_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_EST_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_FIN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_FRA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_GBR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_GIB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_HRV_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_HUN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_IRL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_ITA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_LIE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_LTU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_LUX_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_LVA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_MCO_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_MEX_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_MYS_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_NLD_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_NOR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_NZL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_POL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_PRI_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_ROU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_SMR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_SVK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_SVN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_SWE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_TUR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_USA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_VAT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_ZAF_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "da_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_ALB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_AND_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_ARG_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_AUS_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_AUT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_BEL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_BIH_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_CAN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_CHE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_CZE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_DEU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_DNK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_ESP_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_EST_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_FIN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_FRA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_GBR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_GIB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_HRV_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_HUN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_IRL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_ITA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_LIE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_LTU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_LUX_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_LVA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_MCO_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_MEX_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_MYS_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_NLD_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_NOR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_NZL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_POL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_PRI_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_ROU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_SMR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_SVK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_SVN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_SWE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_TUR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_USA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_VAT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_ZAF_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "de_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_ALB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_AND_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_ARG_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_AUS_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_AUT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_BEL_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_BIH_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_CAN_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_CHE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_CZE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_DEU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_DNK_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_ESP_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_EST_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_FIN_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_FRA_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_GBR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_GIB_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_HRV_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_HUN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_IRL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_ITA_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_LIE_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_LTU_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_LUX_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_LVA_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_MCO_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_MEX_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_MYS_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_NLD_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_NOR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_NZL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_POL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_PRI_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_ROU_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_SMR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_SVK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_SVN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_SWE_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_TUR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_USA_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_VAT_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_ZAF_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "el_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "en_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "es_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_ALB_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_AND_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_ARG_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_AUS_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_AUT_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_BEL_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_BIH_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_CAN_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_CHE_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_CZE_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_DEU_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_DNK_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_ESP_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_EST_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_FIN_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_FRA_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_GBR_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_GIB_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_HRV_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_HUN_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_IRL_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_ITA_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_LIE_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_LTU_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_LUX_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_LVA_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_MCO_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_MEX_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_MYS_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_NLD_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_NOR_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_NZL_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_POL_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_PRI_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_ROU_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_SMR_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_SVK_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_SVN_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_SWE_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_TUR_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_USA_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_VAT_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_ZAF_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_ALB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_AND_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_ARG_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_AUS_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_AUT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_BEL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_BIH_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_CAN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_CHE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_CZE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_DEU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_DNK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_ESP_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_EST_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_FIN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_FRA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_GBR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_GIB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_HRV_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_HUN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_IRL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_ITA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_LIE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_LTU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_LUX_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_LVA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_MCO_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_MEX_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_MYS_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_NLD_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_NOR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_NZL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_POL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_PRI_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_ROU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_SMR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_SVK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_SVN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_SWE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_TUR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_USA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_VAT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_ZAF_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "it_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_CAN_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_MEX_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_USA_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "no_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_ALB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_AND_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_ARG_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_AUS_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_AUT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_BEL_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_BIH_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_CAN_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_CHE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_CZE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_DEU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_DNK_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_ESP_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_EST_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_FIN_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_FRA_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_GBR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_GIB_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_HRV_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_HUN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_IRL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_ITA_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_LIE_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_LTU_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_LUX_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_LVA_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_MCO_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_MEX_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_MYS_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_NLD_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_NOR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_NZL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_POL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_PRI_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_ROU_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_SMR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_SVK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_SVN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_SWE_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_TUR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_USA_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_VAT_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_ZAF_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_ALB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_AND_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_ARG_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_AUS_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_AUT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_BEL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_BIH_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_CAN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_CHE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_CZE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_DEU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_DNK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_ESP_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_EST_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_FIN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_FRA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_GBR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_GIB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_HRV_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_HUN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_IRL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_ITA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_LIE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_LTU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_LUX_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_LVA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_MCO_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_MEX_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_MYS_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_NLD_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_NOR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_NZL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_POL_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_PRI_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_ROU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_SMR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_SVK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_SVN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_SWE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_TUR_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_USA_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_VAT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_ZAF_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_ALB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_AND_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_ARG_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_AUS_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_AUT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_BEL_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_BIH_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_CAN_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_CHE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_CZE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_DEU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_DNK_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_ESP_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_EST_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_FIN_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_FRA_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_GBR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_GIB_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_HRV_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_HUN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_IRL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_ITA_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_LIE_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_LTU_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_LUX_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_LVA_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_MCO_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_MEX_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_MYS_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_NLD_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_NOR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_NZL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_POL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_PRI_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_ROU_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_SMR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_SVK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_SVN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_SWE_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_TUR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_USA_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_VAT_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_ZAF_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "th_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_BLR_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_RUS_match" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_ALB_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_AND_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_ARG_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_AUS_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_AUT_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_BEL_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_BGR_match" )
    ADDLAYOUT( alphabet_bulgaria_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_BIH_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_BLR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_CAN_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_CHE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_CZE_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_DEU_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_DNK_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_ESP_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_EST_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_FIN_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_FRA_match" )
    ADDLAYOUT( alphabet_french_AZERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_GBR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_GIB_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_GRC_match" )
    ADDLAYOUT( alphabet_greek_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_HRV_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_HUN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_IRL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_ITA_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_LIE_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_LTU_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_LUX_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_LVA_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_MCO_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_MEX_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_MKD_match" )
    ADDLAYOUT( alphabet_macedonia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_MNE_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_MYS_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_NLD_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_NOR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_NZL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_POL_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_PRI_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_ROU_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_RUS_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_SMR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_SRB_match" )
    ADDLAYOUT( alphabet_serbia_QWERTZ )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_SVK_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_SVN_match" )
    ADDLAYOUT( alphabet_QWERTZ )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_SWE_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_THA_match" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_TUR_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_UKR_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_USA_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_VAT_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_ZAF_match" )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_match" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( alphabet_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_ARE_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_BHR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_BRA_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_CAN_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_JOR_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_KWT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_LBN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_MEX_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_OMN_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_PRT_match" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_QAT_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_SAU_match" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_USA_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "us_match" )
    ADDLAYOUT( alphabet_us_QWERTY )
    ADDLAYOUT( num_fill )
    ADDLAYOUT( all_fill )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_freetext" )
    ADDLAYOUT( alphabet_arab_QWERTY )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext_others )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "ar_freetext_sms" )
    ADDLAYOUT( alphabet_arab_QWERTY_sms )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_lat_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_freetext" )
    ADDLAYOUT( freetext_us_QWERTY )
    ADDLAYOUT( number_freetext1_NAR )
    ADDLAYOUT( freetext2_NAR )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "cn_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_lat_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_freetext" )
    ADDLAYOUT( freetext_QWERTZ )
    ADDLAYOUT( number_freetext1_lat )
    ADDLAYOUT( freetext2_lat )
    ADDLAYOUT( freetext3_lat )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_freetext_pwd" )
    ADDLAYOUT( freetext_qwertz_pwd1 )
    ADDLAYOUT( freetext_qwertz_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "cs_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTZ_sms )
    ADDLAYOUT( alphabet_lo_qwertz_sms )
    ADDLAYOUT( freetext_de_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "da_freetext" )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext1_lat )
    ADDLAYOUT( freetext2_lat )
    ADDLAYOUT( freetext3_lat )
END_SEQUENCE

BEGIN_SEQUENCE( "da_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "da_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_lat_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "de_freetext" )
    ADDLAYOUT( freetext_QWERTZ )
    ADDLAYOUT( number_freetext1_de )
    ADDLAYOUT( freetext2_de )
    ADDLAYOUT( freetext3_de )
END_SEQUENCE

BEGIN_SEQUENCE( "de_freetext_pwd" )
    ADDLAYOUT( freetext_qwertz_pwd1 )
    ADDLAYOUT( freetext_qwertz_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "de_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTZ_sms )
    ADDLAYOUT( alphabet_lo_qwertz_sms )
    ADDLAYOUT( freetext_de_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "el_freetext" )
    ADDLAYOUT( freetext_greek_QWERTY )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext1_gr )
END_SEQUENCE

BEGIN_SEQUENCE( "el_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "el_freetext_sms" )
    ADDLAYOUT( alphabet_greek_up_QWERTY_sms )
    ADDLAYOUT( alphabet_greek_lo_qwerty_sms )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_lat_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "en_freetext" )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext1_lat )
    ADDLAYOUT( freetext2_lat )
    ADDLAYOUT( freetext3_lat )
END_SEQUENCE

BEGIN_SEQUENCE( "en_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "en_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_lat_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "es_freetext" )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext1_es )
    ADDLAYOUT( freetext2_es )
    ADDLAYOUT( freetext3_es )
END_SEQUENCE

BEGIN_SEQUENCE( "es_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "es_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_es_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_freetext" )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext1_lat )
    ADDLAYOUT( freetext2_lat )
    ADDLAYOUT( freetext3_lat )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "fi_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_lat_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_freetext" )
    ADDLAYOUT( freetext_french_AZERTY )
    ADDLAYOUT( number_freetext1_fr )
    ADDLAYOUT( freetext2_fr )
    ADDLAYOUT( freetext3_fr )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_freetext_pwd" )
    ADDLAYOUT( freetext_azerty_pwd1 )
    ADDLAYOUT( freetext_azerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "fr_freetext_sms" )
    ADDLAYOUT( alphabet_up_AZERTY_sms )
    ADDLAYOUT( alphabet_lo_azerty_sms )
    ADDLAYOUT( freetext1_fr_sms )
    ADDLAYOUT( freetext2_fr_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_freetext" )
    ADDLAYOUT( freetext_QWERTZ )
    ADDLAYOUT( number_freetext1_lat )
    ADDLAYOUT( freetext2_lat )
    ADDLAYOUT( freetext3_lat )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_freetext_pwd" )
    ADDLAYOUT( freetext_qwertz_pwd1 )
    ADDLAYOUT( freetext_qwertz_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "hu_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTZ_sms )
    ADDLAYOUT( alphabet_lo_qwertz_sms )
    ADDLAYOUT( freetext_de_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "it_freetext" )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext1_it )
    ADDLAYOUT( freetext2_it )
    ADDLAYOUT( freetext3_it )
END_SEQUENCE

BEGIN_SEQUENCE( "it_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "it_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext1_it_sms )
    ADDLAYOUT( freetext2_it_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_freetext" )
    ADDLAYOUT( freetext_us_QWERTY )
    ADDLAYOUT( number_freetext1_NAR )
    ADDLAYOUT( freetext2_NAR )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "mx_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_lat_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_freetext" )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext1_nl )
    ADDLAYOUT( freetext2_nl )
    ADDLAYOUT( freetext3_nl )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "nl_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext1_nl_sms )
    ADDLAYOUT( freetext2_nl_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "no_freetext" )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext1_lat )
    ADDLAYOUT( freetext2_lat )
    ADDLAYOUT( freetext3_lat )
END_SEQUENCE

BEGIN_SEQUENCE( "no_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "no_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_lat_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_freetext" )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext1_pl )
    ADDLAYOUT( freetext2_pl )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "pl_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext1_pl_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_freetext" )
    ADDLAYOUT( freetext_portuguese_QWERTY )
    ADDLAYOUT( number_freetext1_pt )
    ADDLAYOUT( freetext2_pt )
    ADDLAYOUT( freetext3_pt )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "pt_freetext_sms" )
    ADDLAYOUT( alphabet_portuguese_QWERTY )
    ADDLAYOUT( alphabet_portuguese_lo_qwerty_sms )
    ADDLAYOUT( freetext_pt_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_freetext" )
    ADDLAYOUT( alphabet_cyr_QWERTY )
    ADDLAYOUT( freetext1_cyr )
    ADDLAYOUT( number_freetext2_cyr )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "ru_freetext_sms" )
    ADDLAYOUT( alphabet_up_cyr_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_cyr_qwerty_sms )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_lat_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_freetext" )
    ADDLAYOUT( freetext_QWERTZ )
    ADDLAYOUT( number_freetext1_lat )
    ADDLAYOUT( freetext2_lat )
    ADDLAYOUT( freetext3_lat )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_freetext_pwd" )
    ADDLAYOUT( freetext_qwertz_pwd1 )
    ADDLAYOUT( freetext_qwertz_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "sk_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTZ_sms )
    ADDLAYOUT( alphabet_lo_qwertz_sms )
    ADDLAYOUT( freetext_de_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_freetext" )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext1_lat )
    ADDLAYOUT( freetext2_lat )
    ADDLAYOUT( freetext3_lat )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "sv_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_lat_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "th_freetext" )
    ADDLAYOUT( alphabet_thai_1 )
    ADDLAYOUT( alphabet_thai_2 )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext_others )
END_SEQUENCE

BEGIN_SEQUENCE( "th_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "th_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_lat_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_freetext" )
    ADDLAYOUT( freetext_QWERTY )
    ADDLAYOUT( number_freetext1_tr )
    ADDLAYOUT( freetext2_tr )
    ADDLAYOUT( freetext3_tr )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "tr_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext1_tr_sms )
    ADDLAYOUT( freetext2_tr_sms )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_freetext" )
    ADDLAYOUT( alphabet_ukraine_QWERTY )
    ADDLAYOUT( freetext1_cyr )
    ADDLAYOUT( number_freetext2_cyr )
    ADDLAYOUT( alphabet_QWERTY )
END_SEQUENCE

BEGIN_SEQUENCE( "ua_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "us_freetext" )
    ADDLAYOUT( freetext_us_QWERTY )
    ADDLAYOUT( number_freetext1_NAR )
    ADDLAYOUT( freetext2_NAR )
END_SEQUENCE

BEGIN_SEQUENCE( "us_freetext_pwd" )
    ADDLAYOUT( freetext_qwerty_pwd1 )
    ADDLAYOUT( freetext_qwerty_pwd2 )
    ADDLAYOUT( freetext_number_pwd3 )
END_SEQUENCE

BEGIN_SEQUENCE( "us_freetext_sms" )
    ADDLAYOUT( alphabet_up_QWERTY_sms )
    ADDLAYOUT( alphabet_lo_qwerty_sms )
    ADDLAYOUT( freetext_lat_sms )
END_SEQUENCE

