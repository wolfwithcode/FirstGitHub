/**
 *  @file Implementation of GUI_MessageBoxGUI
 * Generator version:	1.4
 * Generation date:	Fri Dec 05 16:37:53 IST 2014
*/

#include "GUI_MessageBoxGUI.h"
#include "GUI_Widget/util/GUI_UTIL_QueueReader.h"
#include "GUI_Widget/util/GUI_UTIL_QueueWriter.h"
#include "GUI_Widget/util/GUI_UTIL_Queue.h"


GUI_UTIL_Queue* GUI_MessageBoxGUI::ms_pQueue = 0;
GUI_UTIL_QueueReader* GUI_MessageBoxGUI::ms_pQueueReader = 0;


GUI_MessageBoxGUI::GUI_MessageBoxGUI()
{
}


GUI_MessageBoxGUI::~GUI_MessageBoxGUI()
{
}


// !!this is generated code - do not modify this!!
GUI_UTIL_Queue* GUI_MessageBoxGUI::getQueue() const

{
    // return queue object
    return ms_pQueue;

}


// Initialize object. !!This is generated code - do not modify this!!
bool GUI_MessageBoxGUI::s_initialize(int nQueueSize)
{
    if(ms_pQueue == 0)
    {
        // instantiate queue
        ms_pQueue = new GUI_UTIL_Queue();
        GUI_ASSERT(ms_pQueue != 0);
        if(!ms_pQueue->initialize(nQueueSize))
        {
            delete ms_pQueue;
            ms_pQueue = 0;
        }
        else
        {
            ms_pQueue->getMutex()->setMutexName("MUTEX_FOR_GUI_MessageBoxGUI");
            ms_pQueueReader = new GUI_UTIL_QueueReader(ms_pQueue);
            GUI_ASSERT(ms_pQueueReader != 0);
        }
    }
    // return success or error
    return ms_pQueue != 0;
}


bool GUI_MessageBoxGUI::parseMessage(int nEventId)
{
    bool bMsgOk = false;
    bool bRcvOk = false;

    switch(nEventId)
    {
        case eSIDGuiSetDynamicImage: 
        {
            // get parameters
            tU32 u32ImageId = (tU32) ms_pQueueReader->readInt();
            void* pvData =  ms_pQueueReader->readPointer();
            tU32 u32DataSize = (tU32) ms_pQueueReader->readInt();
            tU32 u32Width = (tU32) ms_pQueueReader->readInt();
            tU32 u32Height = (tU32) ms_pQueueReader->readInt();
            tU8 u8Format = (tU8) ms_pQueueReader->readInt();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxGUI.onGuiSetDynamicImage(%i,%i,%i,%i,%i)",u32ImageId, pvData, u32DataSize, u32Width, u32Height, u8Format);
#endif
                bRcvOk = onGuiSetDynamicImage(u32ImageId, pvData, u32DataSize, u32Width, u32Height, u8Format);
            }
            break;
        }

        case eSIDGuiLSyncViewStatusChanged: 
        {
            // get parameters
            tU8 u8AppId = (tU8) ms_pQueueReader->readInt();
            tU8 u8ViewState = (tU8) ms_pQueueReader->readInt();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxGUI.onGuiLSyncViewStatusChanged(%i,%i)",u8AppId, u8ViewState);
#endif
                bRcvOk = onGuiLSyncViewStatusChanged(u8AppId, u8ViewState);
            }
            break;
        }

        case eSIDGuiLSyncSetLayerNames: 
        {
            // get parameters
            tU8 u8AppId = (tU8) ms_pQueueReader->readInt();
            const char* pcLayer1Name = (const char*) ms_pQueueReader->readString();
            const char* pcLayer2Name = (const char*) ms_pQueueReader->readString();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxGUI.onGuiLSyncSetLayerNames(%i,%s,%s)",u8AppId, pcLayer1Name, pcLayer2Name);
#endif
                bRcvOk = onGuiLSyncSetLayerNames(u8AppId, pcLayer1Name, pcLayer2Name);
            }
            break;
        }

        case eSIDGuiSetDisplayMode: 
        {
            // get parameters
            tU8 u8Mode = (tU8) ms_pQueueReader->readInt();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxGUI.onGuiSetDisplayMode(%i)",u8Mode);
#endif
                bRcvOk = onGuiSetDisplayMode(u8Mode);
            }
            break;
        }

        case eSIDGuiEADisplayModeChanged: 
        {
            // get parameters
            tU8 u8AppId = (tU8) ms_pQueueReader->readInt();
            tU8 u8Mode = (tU8) ms_pQueueReader->readInt();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxGUI.onGuiEADisplayModeChanged(%i,%i)",u8AppId, u8Mode);
#endif
                bRcvOk = onGuiEADisplayModeChanged(u8AppId, u8Mode);
            }
            break;
        }

        case eSIDGuiStartupAnimStatus: 
        {
            // get parameters
            tU8 u8Status = (tU8) ms_pQueueReader->readInt();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxGUI.onGuiStartupAnimStatus(%i)",u8Status);
#endif
                bRcvOk = onGuiStartupAnimStatus(u8Status);
            }
            break;
        }

        case eSIDGuiResizeScreen: 
        {
            // get parameters
            tU8 u8XScale = (tU8) ms_pQueueReader->readInt();
            tU8 u8YScale = (tU8) ms_pQueueReader->readInt();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxGUI.onGuiResizeScreen(%i,%i)",u8XScale, u8YScale);
#endif
                bRcvOk = onGuiResizeScreen(u8XScale, u8YScale);
            }
            break;
        }

        default:
            break;
        }

    return bMsgOk && bRcvOk;
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::onGuiSetDynamicImage(tU32 u32ImageId, void* pvData, tU32 u32DataSize, tU32 u32Width, tU32 u32Height, tU8 u8Format)
{
    // Avoid unreferenced parameter warnings
    (void)u32ImageId;
    (void)pvData;
    (void)u32DataSize;
    (void)u32Width;
    (void)u32Height;
    (void)u8Format;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::sendGuiSetDynamicImage(tU32 u32ImageId, void* pvData, tU32 u32DataSize, tU32 u32Width, tU32 u32Height, tU8 u8Format) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiSetDynamicImage);
    // write integer
    writer.writeInt((tS32) u32ImageId);
    // write pointer
    writer.writePointer(pvData);
    // write integer
    writer.writeInt((tS32) u32DataSize);
    // write integer
    writer.writeInt((tS32) u32Width);
    // write integer
    writer.writeInt((tS32) u32Height);
    // write integer
    writer.writeInt((tS32) u8Format);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::onGuiLSyncViewStatusChanged(tU8 u8AppId, tU8 u8ViewState)
{
    // Avoid unreferenced parameter warnings
    (void)u8AppId;
    (void)u8ViewState;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::sendGuiLSyncViewStatusChanged(tU8 u8AppId, tU8 u8ViewState) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiLSyncViewStatusChanged);
    // write integer
    writer.writeInt((tS32) u8AppId);
    // write integer
    writer.writeInt((tS32) u8ViewState);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::onGuiLSyncSetLayerNames(tU8 u8AppId, const char* pcLayer1Name, const char* pcLayer2Name)
{
    // Avoid unreferenced parameter warnings
    (void)u8AppId;
    (void)pcLayer1Name;
    (void)pcLayer2Name;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::sendGuiLSyncSetLayerNames(tU8 u8AppId, const char* pcLayer1Name, const char* pcLayer2Name) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiLSyncSetLayerNames);
    // write integer
    writer.writeInt((tS32) u8AppId);
    // write string
    writer.writeString(pcLayer1Name);
    // write string
    writer.writeString(pcLayer2Name);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::onGuiSetDisplayMode(tU8 u8Mode)
{
    // Avoid unreferenced parameter warnings
    (void)u8Mode;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::sendGuiSetDisplayMode(tU8 u8Mode) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiSetDisplayMode);
    // write integer
    writer.writeInt((tS32) u8Mode);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::onGuiEADisplayModeChanged(tU8 u8AppId, tU8 u8Mode)
{
    // Avoid unreferenced parameter warnings
    (void)u8AppId;
    (void)u8Mode;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::sendGuiEADisplayModeChanged(tU8 u8AppId, tU8 u8Mode) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiEADisplayModeChanged);
    // write integer
    writer.writeInt((tS32) u8AppId);
    // write integer
    writer.writeInt((tS32) u8Mode);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::onGuiStartupAnimStatus(tU8 u8Status)
{
    // Avoid unreferenced parameter warnings
    (void)u8Status;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::sendGuiStartupAnimStatus(tU8 u8Status) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiStartupAnimStatus);
    // write integer
    writer.writeInt((tS32) u8Status);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::onGuiResizeScreen(tU8 u8XScale, tU8 u8YScale)
{
    // Avoid unreferenced parameter warnings
    (void)u8XScale;
    (void)u8YScale;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxGUI::sendGuiResizeScreen(tU8 u8XScale, tU8 u8YScale) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiResizeScreen);
    // write integer
    writer.writeInt((tS32) u8XScale);
    // write integer
    writer.writeInt((tS32) u8YScale);
    // return result of writer unlock()
    return writer.unlock();
}


