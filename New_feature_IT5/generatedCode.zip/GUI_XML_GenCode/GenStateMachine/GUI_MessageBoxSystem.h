/**
 *  @file Definition of GUI_MessageBoxSystem
 * Generator version:	1.4
 * Generation date:	Fri Dec 05 16:37:53 IST 2014
*/

#ifndef _GUI_MESSAGEBOXSYSTEM_H
#define _GUI_MESSAGEBOXSYSTEM_H

#include "GUI_Widget/Common/GUI_BaseTypes.h"


class GUI_UTIL_Queue;

class GUI_UTIL_QueueReader;


class GUI_MessageBoxSystem
{
public:
    enum serviceIDRange
    {
        eGuiServiceIDRangeStart = 1001,
        eGuiServiceIDRangeEnd = 2000,

    };

    enum serviceID
    {
        eSIDGuiLSyncSetApplicationSettings = eGuiServiceIDRangeStart,
        eSIDGuiLSyncSetView,
        eSIDGuiLSyncSetViewStatus,
        eSIDGuiLSyncLayerSnapshotFinished,
        eSIDGuiConfirmDynamicImage,
        eSIDGuiConfirmDisplayMode,
        eSIDGuiRequestEADisplayModeChange,
        eSIDGuiHMILayerInitiallyFilled,
    };

    GUI_MessageBoxSystem();
    virtual ~GUI_MessageBoxSystem();

    static bool s_initialize(int nQueueSize);

    bool parseMessage(int nEventId);
    GUI_UTIL_Queue* getQueue() const;

    inline static GUI_UTIL_Queue* s_getQueue()
    {
        return ms_pQueue;
    }
    /**
     * @brief Event sent by GUI to HSI, to inform external applications about the coordinates of the widget.
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP)
     * @param[in] u16MinX Origin X-cordinate
     * @param[in] u16MinY Origin Y-cordinate
     * @param[in] u16Width width of the widget rectangle
     * @param[in] u16Height height of the widget rectangle
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiLSyncSetApplicationSettings(tU8 u8AppId, tU16 u16MinX, tU16 u16MinY, tU16 u16Width, tU16 u16Height);

    /**
     * @brief Event sent by GUI to HSI, to inform external applications about the coordinates of the widget.
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP)
     * @param[in] u16MinX Origin X-cordinate
     * @param[in] u16MinY Origin Y-cordinate
     * @param[in] u16Width width of the widget rectangle
     * @param[in] u16Height height of the widget rectangle
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiLSyncSetApplicationSettings(tU8 u8AppId, tU16 u16MinX, tU16 u16MinY, tU16 u16Width, tU16 u16Height) const;


    /**
     * @brief Event sent by GUI to HSI, to inform external application visible/invisible, and about the coordinates of the widget.
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP)
     * @param[in] u8Visible 1-if the app gets visible, 0-if it gets invisible
     * @param[in] u16MinX Min X-cordinate, considered only if u8Visible = 1
     * @param[in] u16MinY Min Y-cordinate, considered only if u8Visible = 1
     * @param[in] u16MaxX Max X-cordinate, considered only if u8Visible = 1
     * @param[in] u16MaxY Max X-cordinate, considered only if u8Visible = 1
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiLSyncSetView(tU8 u8AppId, tU8 u8Visible, tU16 u16MinX, tU16 u16MinY, tU16 u16MaxX, tU16 u16MaxY);

    /**
     * @brief Event sent by GUI to HSI, to inform external application visible/invisible, and about the coordinates of the widget.
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP)
     * @param[in] u8Visible 1-if the app gets visible, 0-if it gets invisible
     * @param[in] u16MinX Min X-cordinate, considered only if u8Visible = 1
     * @param[in] u16MinY Min Y-cordinate, considered only if u8Visible = 1
     * @param[in] u16MaxX Max X-cordinate, considered only if u8Visible = 1
     * @param[in] u16MaxY Max X-cordinate, considered only if u8Visible = 1
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiLSyncSetView(tU8 u8AppId, tU8 u8Visible, tU16 u16MinX, tU16 u16MinY, tU16 u16MaxX, tU16 u16MaxY) const;


    /**
     * @brief This event is used to request a view status change
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP)
     * @param[in] u8ViewState View status (e.g. ACTIVE / STOPPED
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiLSyncSetViewStatus(tU8 u8AppId, tU8 u8ViewState);

    /**
     * @brief This event is used to request a view status change
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP)
     * @param[in] u8ViewState View status (e.g. ACTIVE / STOPPED
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiLSyncSetViewStatus(tU8 u8AppId, tU8 u8ViewState) const;


    /**
     * @brief This event is used to indicate a successfull layer snapshot
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP)
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiLSyncLayerSnapshotFinished(tU8 u8AppId);

    /**
     * @brief This event is used to indicate a successfull layer snapshot
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP)
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiLSyncLayerSnapshotFinished(tU8 u8AppId) const;


    /**
     * @brief This event is used to as confirmation from GUI on dynamic image set
     *
     * @param[in] u32ImageId Image Id for differant application(e.g.0-MediaImage, 1-MsgAttachment etc...)
     * @param[in] pu8NewImage Image pointer (heap memory)for new image stored
     * @param[in] pu8OldImage Image pointer (heap memory)for old image stored
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiConfirmDynamicImage(tU32 u32ImageId, void* pu8NewImage, void* pu8OldImage);

    /**
     * @brief This event is used to as confirmation from GUI on dynamic image set
     *
     * @param[in] u32ImageId Image Id for differant application(e.g.0-MediaImage, 1-MsgAttachment etc...)
     * @param[in] pu8NewImage Image pointer (heap memory)for new image stored
     * @param[in] pu8OldImage Image pointer (heap memory)for old image stored
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiConfirmDynamicImage(tU32 u32ImageId, void* pu8NewImage, void* pu8OldImage) const;


    /**
     * @brief This event is used to confirm the change of day/night mode
     *
     * @param[in] u8Mode Type declared in enum GUI_DisplayMode, see hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiConfirmDisplayMode(tU8 u8Mode);

    /**
     * @brief This event is used to confirm the change of day/night mode
     *
     * @param[in] u8Mode Type declared in enum GUI_DisplayMode, see hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiConfirmDisplayMode(tU8 u8Mode) const;


    /**
     * @brief This event is used to confirm the change of day/night mode
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP)
     * @param[in] u8Mode Type declared in enum GUI_DisplayMode, see hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiRequestEADisplayModeChange(tU8 u8AppId, tU8 u8Mode);

    /**
     * @brief This event is used to confirm the change of day/night mode
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP)
     * @param[in] u8Mode Type declared in enum GUI_DisplayMode, see hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiRequestEADisplayModeChange(tU8 u8AppId, tU8 u8Mode) const;


    /**
     * @brief This event is used to inform the system layer that there is something on screen now (first HMI mask)
     *
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiHMILayerInitiallyFilled();

    /**
     * @brief This event is used to inform the system layer that there is something on screen now (first HMI mask)
     *
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiHMILayerInitiallyFilled() const;



protected:
    static GUI_UTIL_Queue* ms_pQueue;
    static GUI_UTIL_QueueReader* ms_pQueueReader;

private:
    GUI_MessageBoxSystem(const GUI_MessageBoxSystem& rhs)
    {
        OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(rhs);
    }

    GUI_MessageBoxSystem    & operator=(GUI_MessageBoxSystem& rhs)
    {
        OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(rhs);
        if(this != &rhs) {
            // check to satisfy lint
        }
        return *this;
    }

};

#endif //_GUI_MESSAGEBOXSYSTEM_H
