/**
 *  @file Definition of GUI_MessageBoxGUI
 * Generator version:	1.4
 * Generation date:	Fri Dec 05 16:37:53 IST 2014
*/

#ifndef _GUI_MESSAGEBOXGUI_H
#define _GUI_MESSAGEBOXGUI_H

#include "GUI_Widget/Common/GUI_BaseTypes.h"


class GUI_UTIL_Queue;

class GUI_UTIL_QueueReader;


class GUI_MessageBoxGUI
{
public:
    enum serviceIDRange
    {
        eGuiServiceIDRangeStart = 1,
        eGuiServiceIDRangeEnd = 1000,

    };

    enum serviceID
    {
        eSIDGuiSetDynamicImage = eGuiServiceIDRangeStart,
        eSIDGuiLSyncViewStatusChanged,
        eSIDGuiLSyncSetLayerNames,
        eSIDGuiSetDisplayMode,
        eSIDGuiEADisplayModeChanged,
        eSIDGuiStartupAnimStatus,
        eSIDGuiResizeScreen,
    };

    GUI_MessageBoxGUI();
    virtual ~GUI_MessageBoxGUI();

    static bool s_initialize(int nQueueSize);

    bool parseMessage(int nEventId);
    GUI_UTIL_Queue* getQueue() const;

    inline static GUI_UTIL_Queue* s_getQueue()
    {
        return ms_pQueue;
    }
    /**
     * @brief Define a dynamic image using a data block
     *
     * @param[in] u32ImageId Image ID to define (valid values: 0...GUI_MAX_MEMORY_BITMAPS-1)
     * @param[in] pvData Pointer to the data block that stores the image (see u32DataSize)
     * @param[in] u32DataSize Size of the image data (see pvData)
     * @param[in] u32Width Width of already decoded image
     * @param[in] u32Height Height of already decoded image
     * @param[in] u8Format Image format: values from SVGBmpDecImageEncoding (jpeg=1, png=2)
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiSetDynamicImage(tU32 u32ImageId, void* pvData, tU32 u32DataSize, tU32 u32Width, tU32 u32Height, tU8 u8Format);

    /**
     * @brief Define a dynamic image using a data block
     *
     * @param[in] u32ImageId Image ID to define (valid values: 0...GUI_MAX_MEMORY_BITMAPS-1)
     * @param[in] pvData Pointer to the data block that stores the image (see u32DataSize)
     * @param[in] u32DataSize Size of the image data (see pvData)
     * @param[in] u32Width Width of already decoded image
     * @param[in] u32Height Height of already decoded image
     * @param[in] u8Format Image format: values from SVGBmpDecImageEncoding (jpeg=1, png=2)
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiSetDynamicImage(tU32 u32ImageId, void* pvData, tU32 u32DataSize, tU32 u32Width, tU32 u32Height, tU8 u8Format) const;


    /**
     * @brief Inform GUI that the view status of a foreign application has changed
     *
     * @param[in] u8AppId Type of foreign applications (e.g. RVC, MAP); see enum GUI_ForeignApplications in gui/framework/gui/include/GUI_Common.h
     * @param[in] u8ViewState View status (e.g. ACTIVE, STOPPED); see enum GUI_ExternalApplicationStatus in hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiLSyncViewStatusChanged(tU8 u8AppId, tU8 u8ViewState);

    /**
     * @brief Inform GUI that the view status of a foreign application has changed
     *
     * @param[in] u8AppId Type of foreign applications (e.g. RVC, MAP); see enum GUI_ForeignApplications in gui/framework/gui/include/GUI_Common.h
     * @param[in] u8ViewState View status (e.g. ACTIVE, STOPPED); see enum GUI_ExternalApplicationStatus in hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiLSyncViewStatusChanged(tU8 u8AppId, tU8 u8ViewState) const;


    /**
     * @brief Define layer name(s) for foreign applications
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP); see enum GUI_ExternalApplications in hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     * @param[in] pcLayer1Name Name of layer 1 (if two layers are used, this is the top-most)
     * @param[in] pcLayer2Name Name of layer 2 (if only one layer is used, this is an empty string)
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiLSyncSetLayerNames(tU8 u8AppId, const char* pcLayer1Name, const char* pcLayer2Name);

    /**
     * @brief Define layer name(s) for foreign applications
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP); see enum GUI_ExternalApplications in hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     * @param[in] pcLayer1Name Name of layer 1 (if two layers are used, this is the top-most)
     * @param[in] pcLayer2Name Name of layer 2 (if only one layer is used, this is an empty string)
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiLSyncSetLayerNames(tU8 u8AppId, const char* pcLayer1Name, const char* pcLayer2Name) const;


    /**
     * @brief change the display modes day/night
     *
     * @param[in] u8Mode Type declared in enum GUI_DisplayMode, see hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiSetDisplayMode(tU8 u8Mode);

    /**
     * @brief change the display modes day/night
     *
     * @param[in] u8Mode Type declared in enum GUI_DisplayMode, see hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiSetDisplayMode(tU8 u8Mode) const;


    /**
     * @brief change the display modes day/night
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP); see enum GUI_ExternalApplications in hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     * @param[in] u8Mode Type declared in enum GUI_DisplayMode, see hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiEADisplayModeChanged(tU8 u8AppId, tU8 u8Mode);

    /**
     * @brief change the display modes day/night
     *
     * @param[in] u8AppId Type of external applications (e.g. RVC, MAP); see enum GUI_ExternalApplications in hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     * @param[in] u8Mode Type declared in enum GUI_DisplayMode, see hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiEADisplayModeChanged(tU8 u8AppId, tU8 u8Mode) const;


    /**
     * @brief indicates the status of the startup animation, to block the HMI display update until startup anim is running
     *
     * @param[in] u8Status Type declared in enum GUI_StartupAnimationState, see hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiStartupAnimStatus(tU8 u8Status);

    /**
     * @brief indicates the status of the startup animation, to block the HMI display update until startup anim is running
     *
     * @param[in] u8Status Type declared in enum GUI_StartupAnimationState, see hmi_framework/GUI_Widget/Common/GUI_BaseTypes.h
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiStartupAnimStatus(tU8 u8Status) const;


    /**
     * @brief set the scaling factors for the resulting image on the screen
     *
     * @param[in] u8XScale the scaling in x direction (1-256%)
     * @param[in] u8YScale the scaling in y direction (1-256%)
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    virtual bool onGuiResizeScreen(tU8 u8XScale, tU8 u8YScale);

    /**
     * @brief set the scaling factors for the resulting image on the screen
     *
     * @param[in] u8XScale the scaling in x direction (1-256%)
     * @param[in] u8YScale the scaling in y direction (1-256%)
     *
     * @author generated
     *         (c) 2014 Robert Bosch GmbH, Hildesheim
     */
    bool sendGuiResizeScreen(tU8 u8XScale, tU8 u8YScale) const;



protected:
    static GUI_UTIL_Queue* ms_pQueue;
    static GUI_UTIL_QueueReader* ms_pQueueReader;

private:
    GUI_MessageBoxGUI(const GUI_MessageBoxGUI& rhs)
    {
        OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(rhs);
    }

    GUI_MessageBoxGUI    & operator=(GUI_MessageBoxGUI& rhs)
    {
        OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(rhs);
        if(this != &rhs) {
            // check to satisfy lint
        }
        return *this;
    }

};

#endif //_GUI_MESSAGEBOXGUI_H
