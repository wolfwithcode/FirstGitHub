/**
 *  @file Implementation of GUI_MessageBoxSystem
 * Generator version:	1.4
 * Generation date:	Fri Dec 05 16:37:53 IST 2014
*/

#include "GUI_MessageBoxSystem.h"
#include "GUI_Widget/util/GUI_UTIL_QueueReader.h"
#include "GUI_Widget/util/GUI_UTIL_QueueWriter.h"
#include "GUI_Widget/util/GUI_UTIL_Queue.h"


GUI_UTIL_Queue* GUI_MessageBoxSystem::ms_pQueue = 0;
GUI_UTIL_QueueReader* GUI_MessageBoxSystem::ms_pQueueReader = 0;


GUI_MessageBoxSystem::GUI_MessageBoxSystem()
{
}


GUI_MessageBoxSystem::~GUI_MessageBoxSystem()
{
}


// !!this is generated code - do not modify this!!
GUI_UTIL_Queue* GUI_MessageBoxSystem::getQueue() const

{
    // return queue object
    return ms_pQueue;

}


// Initialize object. !!This is generated code - do not modify this!!
bool GUI_MessageBoxSystem::s_initialize(int nQueueSize)
{
    if(ms_pQueue == 0)
    {
        // instantiate queue
        ms_pQueue = new GUI_UTIL_Queue();
        GUI_ASSERT(ms_pQueue != 0);
        if(!ms_pQueue->initialize(nQueueSize))
        {
            delete ms_pQueue;
            ms_pQueue = 0;
        }
        else
        {
            ms_pQueue->getMutex()->setMutexName("MUTEX_FOR_GUI_MessageBoxSystem");
            ms_pQueueReader = new GUI_UTIL_QueueReader(ms_pQueue);
            GUI_ASSERT(ms_pQueueReader != 0);
        }
    }
    // return success or error
    return ms_pQueue != 0;
}


bool GUI_MessageBoxSystem::parseMessage(int nEventId)
{
    bool bMsgOk = false;
    bool bRcvOk = false;

    switch(nEventId)
    {
        case eSIDGuiLSyncSetApplicationSettings: 
        {
            // get parameters
            tU8 u8AppId = (tU8) ms_pQueueReader->readInt();
            tU16 u16MinX = (tU16) ms_pQueueReader->readInt();
            tU16 u16MinY = (tU16) ms_pQueueReader->readInt();
            tU16 u16Width = (tU16) ms_pQueueReader->readInt();
            tU16 u16Height = (tU16) ms_pQueueReader->readInt();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxSystem.onGuiLSyncSetApplicationSettings(%i,%i,%i,%i,%i)",u8AppId, u16MinX, u16MinY, u16Width, u16Height);
#endif
                bRcvOk = onGuiLSyncSetApplicationSettings(u8AppId, u16MinX, u16MinY, u16Width, u16Height);
            }
            break;
        }

        case eSIDGuiLSyncSetView: 
        {
            // get parameters
            tU8 u8AppId = (tU8) ms_pQueueReader->readInt();
            tU8 u8Visible = (tU8) ms_pQueueReader->readInt();
            tU16 u16MinX = (tU16) ms_pQueueReader->readInt();
            tU16 u16MinY = (tU16) ms_pQueueReader->readInt();
            tU16 u16MaxX = (tU16) ms_pQueueReader->readInt();
            tU16 u16MaxY = (tU16) ms_pQueueReader->readInt();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxSystem.onGuiLSyncSetView(%i,%i,%i,%i,%i,%i)",u8AppId, u8Visible, u16MinX, u16MinY, u16MaxX, u16MaxY);
#endif
                bRcvOk = onGuiLSyncSetView(u8AppId, u8Visible, u16MinX, u16MinY, u16MaxX, u16MaxY);
            }
            break;
        }

        case eSIDGuiLSyncSetViewStatus: 
        {
            // get parameters
            tU8 u8AppId = (tU8) ms_pQueueReader->readInt();
            tU8 u8ViewState = (tU8) ms_pQueueReader->readInt();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxSystem.onGuiLSyncSetViewStatus(%i,%i)",u8AppId, u8ViewState);
#endif
                bRcvOk = onGuiLSyncSetViewStatus(u8AppId, u8ViewState);
            }
            break;
        }

        case eSIDGuiLSyncLayerSnapshotFinished: 
        {
            // get parameters
            tU8 u8AppId = (tU8) ms_pQueueReader->readInt();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxSystem.onGuiLSyncLayerSnapshotFinished(%i)",u8AppId);
#endif
                bRcvOk = onGuiLSyncLayerSnapshotFinished(u8AppId);
            }
            break;
        }

        case eSIDGuiConfirmDynamicImage: 
        {
            // get parameters
            tU32 u32ImageId = (tU32) ms_pQueueReader->readInt();
            void* pu8NewImage =  ms_pQueueReader->readPointer();
            void* pu8OldImage =  ms_pQueueReader->readPointer();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxSystem.onGuiConfirmDynamicImage(%i)",u32ImageId, pu8NewImage, pu8OldImage);
#endif
                bRcvOk = onGuiConfirmDynamicImage(u32ImageId, pu8NewImage, pu8OldImage);
            }
            break;
        }

        case eSIDGuiConfirmDisplayMode: 
        {
            // get parameters
            tU8 u8Mode = (tU8) ms_pQueueReader->readInt();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxSystem.onGuiConfirmDisplayMode(%i)",u8Mode);
#endif
                bRcvOk = onGuiConfirmDisplayMode(u8Mode);
            }
            break;
        }

        case eSIDGuiRequestEADisplayModeChange: 
        {
            // get parameters
            tU8 u8AppId = (tU8) ms_pQueueReader->readInt();
            tU8 u8Mode = (tU8) ms_pQueueReader->readInt();

            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxSystem.onGuiRequestEADisplayModeChange(%i,%i)",u8AppId, u8Mode);
#endif
                bRcvOk = onGuiRequestEADisplayModeChange(u8AppId, u8Mode);
            }
            break;
        }

        case eSIDGuiHMILayerInitiallyFilled: 
        {
            // call function
            bMsgOk =  !ms_pQueueReader->getError();
            if(bMsgOk)
            {
#ifdef TRACE_MSG
GUI_Trace::s_debugTrace(GUI_Trace::CHN_MSG,"GUI_MessageBoxSystem.onGuiHMILayerInitiallyFilled()");
#endif
                bRcvOk = onGuiHMILayerInitiallyFilled();
            }
            break;
        }

        default:
            break;
        }

    return bMsgOk && bRcvOk;
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::onGuiLSyncSetApplicationSettings(tU8 u8AppId, tU16 u16MinX, tU16 u16MinY, tU16 u16Width, tU16 u16Height)
{
    // Avoid unreferenced parameter warnings
    (void)u8AppId;
    (void)u16MinX;
    (void)u16MinY;
    (void)u16Width;
    (void)u16Height;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::sendGuiLSyncSetApplicationSettings(tU8 u8AppId, tU16 u16MinX, tU16 u16MinY, tU16 u16Width, tU16 u16Height) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiLSyncSetApplicationSettings);
    // write integer
    writer.writeInt((tS32) u8AppId);
    // write integer
    writer.writeInt((tS32) u16MinX);
    // write integer
    writer.writeInt((tS32) u16MinY);
    // write integer
    writer.writeInt((tS32) u16Width);
    // write integer
    writer.writeInt((tS32) u16Height);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::onGuiLSyncSetView(tU8 u8AppId, tU8 u8Visible, tU16 u16MinX, tU16 u16MinY, tU16 u16MaxX, tU16 u16MaxY)
{
    // Avoid unreferenced parameter warnings
    (void)u8AppId;
    (void)u8Visible;
    (void)u16MinX;
    (void)u16MinY;
    (void)u16MaxX;
    (void)u16MaxY;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::sendGuiLSyncSetView(tU8 u8AppId, tU8 u8Visible, tU16 u16MinX, tU16 u16MinY, tU16 u16MaxX, tU16 u16MaxY) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiLSyncSetView);
    // write integer
    writer.writeInt((tS32) u8AppId);
    // write integer
    writer.writeInt((tS32) u8Visible);
    // write integer
    writer.writeInt((tS32) u16MinX);
    // write integer
    writer.writeInt((tS32) u16MinY);
    // write integer
    writer.writeInt((tS32) u16MaxX);
    // write integer
    writer.writeInt((tS32) u16MaxY);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::onGuiLSyncSetViewStatus(tU8 u8AppId, tU8 u8ViewState)
{
    // Avoid unreferenced parameter warnings
    (void)u8AppId;
    (void)u8ViewState;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::sendGuiLSyncSetViewStatus(tU8 u8AppId, tU8 u8ViewState) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiLSyncSetViewStatus);
    // write integer
    writer.writeInt((tS32) u8AppId);
    // write integer
    writer.writeInt((tS32) u8ViewState);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::onGuiLSyncLayerSnapshotFinished(tU8 u8AppId)
{
    // Avoid unreferenced parameter warnings
    (void)u8AppId;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::sendGuiLSyncLayerSnapshotFinished(tU8 u8AppId) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiLSyncLayerSnapshotFinished);
    // write integer
    writer.writeInt((tS32) u8AppId);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::onGuiConfirmDynamicImage(tU32 u32ImageId, void* pu8NewImage, void* pu8OldImage)
{
    // Avoid unreferenced parameter warnings
    (void)u32ImageId;
    (void)pu8NewImage;
    (void)pu8OldImage;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::sendGuiConfirmDynamicImage(tU32 u32ImageId, void* pu8NewImage, void* pu8OldImage) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiConfirmDynamicImage);
    // write integer
    writer.writeInt((tS32) u32ImageId);
    // write pointer
    writer.writePointer(pu8NewImage);
    // write pointer
    writer.writePointer(pu8OldImage);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::onGuiConfirmDisplayMode(tU8 u8Mode)
{
    // Avoid unreferenced parameter warnings
    (void)u8Mode;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::sendGuiConfirmDisplayMode(tU8 u8Mode) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiConfirmDisplayMode);
    // write integer
    writer.writeInt((tS32) u8Mode);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::onGuiRequestEADisplayModeChange(tU8 u8AppId, tU8 u8Mode)
{
    // Avoid unreferenced parameter warnings
    (void)u8AppId;
    (void)u8Mode;

    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::sendGuiRequestEADisplayModeChange(tU8 u8AppId, tU8 u8Mode) const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiRequestEADisplayModeChange);
    // write integer
    writer.writeInt((tS32) u8AppId);
    // write integer
    writer.writeInt((tS32) u8Mode);
    // return result of writer unlock()
    return writer.unlock();
}


// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::onGuiHMILayerInitiallyFilled()
{
    // always return false
    return false;
}

// !!This is generated code. Do not modify this!!
bool GUI_MessageBoxSystem::sendGuiHMILayerInitiallyFilled() const
{
    GUI_UTIL_QueueWriter writer(ms_pQueue);
    writer.writeInt((tS32) eSIDGuiHMILayerInitiallyFilled);
    // return result of writer unlock()
    return writer.unlock();
}


