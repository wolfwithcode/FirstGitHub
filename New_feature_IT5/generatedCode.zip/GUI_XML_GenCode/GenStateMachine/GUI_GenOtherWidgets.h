/*  This file has been generated on 05.12.2014 16:37 */
/*
 *  This file defines all widgets that have no C++ implementation.
 *
 *  This file contains C++ class definitions for widget classes. Each
 *  new class has to be directly or indirectly derived from GUI_Widget.
 *  Any number of new properties can be added. Properties that are
 *  defined in the base classes (e.g. X, Y) must not be redefined here!
 *
 *  All kinds of scripted (Lua) widgets have to be (again, directly or
 *  indirectly) derived from GUI_Scripted.
 *
 *  To add a normal variable, add a variable of type GUI_ContentId with
 *  the prefix m_cid (e.g. GUI_ContentId m_cidMyNewProperty). All property
 *  names should start with a capital letter, and must be legal C++
 *  symbol names (consisting of letters, digits and underscore).
 *
 */




#ifndef _GUI_GENOTHERWIDGETS_H
#define _GUI_GENOTHERWIDGETS_H

#include "GUI_Widget/Widget/GUI_Scripted.h"


class GUI_Container : public GUI_Scripted
{
public:

};
class GUI_Label : public GUI_Scripted
{
public:
    GUI_ContentId m_cidAnimateOnTouch;
    const GUI_ContentId* m_acidStateColors;
    int m_nNumStateColors;
    const GUI_ContentId* m_acidBaselineList;
    int m_nNumBaselineList;
    GUI_ContentId m_cidFont;
    GUI_ContentId m_cidMaxLines;
    GUI_ContentId m_cidText;
    GUI_ContentId m_cidTextColor;
    const GUI_ContentId* m_acidTextColorArray;
    int m_nNumTextColorArray;
    GUI_ContentId m_cidTextColorValue;
    GUI_ContentId m_cidTextXAlign;
    GUI_ContentId m_cidTextYAlign;
    GUI_ContentId m_cidUseGlobalColors;

};
class GUI_ChoiceImage : public GUI_Scripted
{
public:
    GUI_ContentId m_cidAlpha;
    GUI_ContentId m_cidAnimEndIndex;
    GUI_ContentId m_cidAnimStartIndex;
    GUI_ContentId m_cidAnimation;
    GUI_ContentId m_cidBottomShade;
    const GUI_ContentId* m_acidImagePaths;
    int m_nNumImagePaths;
    const GUI_ContentId* m_acidImages;
    int m_nNumImages;
    GUI_ContentId m_cidLeftShade;
    GUI_ContentId m_cidMax;
    GUI_ContentId m_cidMin;
    GUI_ContentId m_cidRightShade;
    GUI_ContentId m_cidState;
    GUI_ContentId m_cidTime;
    GUI_ContentId m_cidTopShade;
    GUI_ContentId m_cidValue;
    GUI_ContentId m_cidValueString;
    GUI_ContentId m_cidAnimdirection;
    GUI_ContentId m_cidForeground;
    GUI_ContentId m_cidXAlign;
    GUI_ContentId m_cidYAlign;

};
class GUI_ButtonContainer : public GUI_Scripted
{
public:
    GUI_ContentId m_cidDefaultFocus;
    GUI_ContentId m_cidDynPositioning;
    GUI_ContentId m_cidUseSysEncoderDirection;

};
class GUI_Multiline : public GUI_Scripted
{
public:
    GUI_ContentId m_cidLineSpacing;
    GUI_ContentId m_cidScrollable;
    GUI_ContentId m_cidSpeedLock;
    GUI_ContentId m_cidWrapMode;
    const GUI_ContentId* m_acidBaselineList;
    int m_nNumBaselineList;
    GUI_ContentId m_cidFont;
    GUI_ContentId m_cidInDocPath;
    GUI_ContentId m_cidInDocSize;
    GUI_ContentId m_cidInTextType;
    GUI_ContentId m_cidText;
    GUI_ContentId m_cidTextColor;
    GUI_ContentId m_cidTextXAlign;
    GUI_ContentId m_cidTextYAlign;
    GUI_ContentId m_cidXTab;
    GUI_ContentId m_cidIN_EVENT_pageDownPressed;
    GUI_ContentId m_cidIN_EVENT_pageUpPressed;
    GUI_ContentId m_cidIN_EVENT_resetCursorPosition;
    GUI_ContentId m_cidOUT_EVENT_speedlock_active;
    GUI_ContentId m_cidOUT_EVENT_turnleft;
    GUI_ContentId m_cidOUT_EVENT_turnright;

};
class GUI_Bargraph : public GUI_Scripted
{
public:
    GUI_ContentId m_cidMaxValue;
    GUI_ContentId m_cidMinValue;
    GUI_ContentId m_cidOrientation;
    GUI_ContentId m_cidValue;
    GUI_ContentId m_cidBmBackground;
    GUI_ContentId m_cidBmBegin;
    GUI_ContentId m_cidBmBig;
    GUI_ContentId m_cidBmBorder;
    GUI_ContentId m_cidBmEnd;
    GUI_ContentId m_cidBmFill;
    GUI_ContentId m_cidBmSmall;
    GUI_ContentId m_cidFillMode;

};
class GUI_ExternalApplicationWidget : public GUI_Scripted
{
public:
    GUI_ContentId m_cidInAnimContentId;
    GUI_ContentId m_cidInBlockingMode;
    GUI_ContentId m_cidInDefaultAlpha;
    GUI_ContentId m_cidInDefaultColor;
    GUI_ContentId m_cidInDefaultImage;
    GUI_ContentId m_cidInDoubleTapDelta;
    GUI_ContentId m_cidInDragEnable;
    GUI_ContentId m_cidInDragHoldTime;
    GUI_ContentId m_cidInDragMaxDistance;
    GUI_ContentId m_cidInDragMinDistance;
    GUI_ContentId m_cidInMode;
    GUI_ContentId m_cidInTapDistance;
    GUI_ContentId m_cidInTapEnable;
    GUI_ContentId m_cidInTapHoldTime;
    GUI_ContentId m_cidInTapRepeatTime;
    GUI_ContentId m_cidInTimeoutError;
    GUI_ContentId m_cidInTimeoutShort;
    GUI_ContentId m_cidOutGEEventType;
    GUI_ContentId m_cidOutGEGestureType;
    GUI_ContentId m_cidOutGEPos1Valid;
    GUI_ContentId m_cidOutGEPos1X;
    GUI_ContentId m_cidOutGEPos1Y;
    GUI_ContentId m_cidOutGEPos2Valid;
    GUI_ContentId m_cidOutGEPos2X;
    GUI_ContentId m_cidOutGEPos2Y;
    GUI_ContentId m_cidOutGETimestamp;
    GUI_ContentId m_cidOutLayerVisible;
    GUI_ContentId m_cidOutX;
    GUI_ContentId m_cidOutY;
    GUI_ContentId m_cidOUT_EVENT_outGestureevent;
    GUI_ContentId m_cidOUT_EVENT_outShort;
    GUI_ContentId m_cidOUT_EVENT_outTimeoutError;
    GUI_ContentId m_cidOUT_EVENT_outTimeoutShort;

};
class GUI_Scrollbar : public GUI_Scripted
{
public:
    GUI_ContentId m_cidSpeedLock;
    GUI_ContentId m_cidBmBottom;
    GUI_ContentId m_cidBmScrollbox;
    GUI_ContentId m_cidBmSlider;
    GUI_ContentId m_cidBmSliderInactive;
    GUI_ContentId m_cidBmTop;
    GUI_ContentId m_cidEnabled;
    GUI_ContentId m_cidNumLines;
    GUI_ContentId m_cidNumVisibleLines;
    GUI_ContentId m_cidTopLine;
    GUI_ContentId m_cidTouchableArea_X;
    GUI_ContentId m_cidTouchableArea_Y;
    GUI_ContentId m_cidTouchableArea_height;
    GUI_ContentId m_cidTouchableArea_width;
    GUI_ContentId m_cidOUT_EVENT_listscrollbar_endofscroll;
    GUI_ContentId m_cidOUT_EVENT_listscrollbar_next;
    GUI_ContentId m_cidOUT_EVENT_listscrollbar_position;
    GUI_ContentId m_cidOUT_EVENT_listscrollbar_prev;
    GUI_ContentId m_cidOUT_EVENT_updn_pressed;

};
class GUI_ListContainer : public GUI_Scripted
{
public:
    GUI_ContentId m_cidCurrentCenterPosition;
    GUI_ContentId m_cidDefaultFocus;
    GUI_ContentId m_cidListIdentifier;
    GUI_ContentId m_cidMovedDynamicIndex;
    GUI_ContentId m_cidPressedDynamicIndex;
    GUI_ContentId m_cidSpeedLock;
    const GUI_ContentId* m_acidTopOffset;
    int m_nNumTopOffset;
    GUI_ContentId m_cidUserPosition;
    GUI_ContentId m_cidFocusedItem;
    GUI_ContentId m_cidIdleTimeout;
    GUI_ContentId m_cidInitCenterItem;
    GUI_ContentId m_cidLines;
    GUI_ContentId m_cidIN_EVENT_resetCursorPosition;
    GUI_ContentId m_cidIN_EVENT_resetIdleTimer;
    GUI_ContentId m_cidIN_EVENT_userPosition;
    GUI_ContentId m_cidOUT_EVENT_abortmovemode;
    GUI_ContentId m_cidOUT_EVENT_entermovemode;
    GUI_ContentId m_cidOUT_EVENT_idleTimeout;
    GUI_ContentId m_cidOUT_EVENT_leavemovemode;
    GUI_ContentId m_cidOUT_EVENT_move_down;
    GUI_ContentId m_cidOUT_EVENT_move_up;
    GUI_ContentId m_cidOUT_EVENT_operatedEvent;

};
class GUI_ListItem : public GUI_Scripted
{
public:
    GUI_ContentId m_cidAltDesign;
    GUI_ContentId m_cidDynamicIndex;
    GUI_ContentId m_cidItemAvailable;
    GUI_ContentId m_cidItemCount;
    GUI_ContentId m_cidEnabled;
    GUI_ContentId m_cidFocused;
    GUI_ContentId m_cidOUT_EVENT_longpressed;
    GUI_ContentId m_cidOUT_EVENT_pressed;
    GUI_ContentId m_cidOUT_EVENT_shortreleased;

};
class GUI_ListItemAction : public GUI_ListItem
{
public:
    GUI_ContentId m_cidActiveIndex;
    GUI_ContentId m_cidActive;

};
class GUI_EntryField : public GUI_Scripted
{
public:
    GUI_ContentId m_cidBaseline;
    GUI_ContentId m_cidCursorChar;
    GUI_ContentId m_cidCursorColor;
    GUI_ContentId m_cidCursorPos;
    GUI_ContentId m_cidFont;
    GUI_ContentId m_cidHiddenChar;
    GUI_ContentId m_cidHiddenTyping;
    GUI_ContentId m_cidMatchText;
    GUI_ContentId m_cidMatchTextColor;
    GUI_ContentId m_cidText;
    GUI_ContentId m_cidTextColor;
    GUI_ContentId m_cidTextXAlign;
    GUI_ContentId m_cidTextYAlign;

};
class GUI_Speller : public GUI_Scripted
{
public:
    GUI_ContentId m_cidGetLetterFunction;
    GUI_ContentId m_cidInvertGetLetterFunction;
    GUI_ContentId m_cidLayoutSequence;
    GUI_ContentId m_cidPressedCharacter;
    GUI_ContentId m_cidTextDel;
    GUI_ContentId m_cidTextSpace;
    GUI_ContentId m_cidBaseline;
    const GUI_ContentId* m_acidBmDisabled;
    int m_nNumBmDisabled;
    const GUI_ContentId* m_acidBmEnabled;
    int m_nNumBmEnabled;
    const GUI_ContentId* m_acidBmFocus;
    int m_nNumBmFocus;
    const GUI_ContentId* m_acidBmPressed;
    int m_nNumBmPressed;
    const GUI_ContentId* m_acidColDisabled;
    int m_nNumColDisabled;
    const GUI_ContentId* m_acidColEnabled;
    int m_nNumColEnabled;
    const GUI_ContentId* m_acidColFocus;
    int m_nNumColFocus;
    const GUI_ContentId* m_acidColPressed;
    int m_nNumColPressed;
    GUI_ContentId m_cidEnabled;
    GUI_ContentId m_cidFont;
    GUI_ContentId m_cidIN_EVENT_toggle_layout;
    GUI_ContentId m_cidOUT_EVENT_longpressed;
    GUI_ContentId m_cidOUT_EVENT_pressed;
    GUI_ContentId m_cidOUT_EVENT_released;
    GUI_ContentId m_cidOUT_EVENT_repeat;
    GUI_ContentId m_cidOUT_EVENT_shortreleased;

};
class GUI_ListItemCheckbox : public GUI_ListItem
{
public:
    GUI_ContentId m_cidStateChecked;
    GUI_ContentId m_cidBmChecked;
    GUI_ContentId m_cidBmNotChecked;

};
class GUI_ListItemSetting : public GUI_ListItem
{
public:
    GUI_ContentId m_cidActiveIndex;
    GUI_ContentId m_cidActive;
    GUI_ContentId m_cidOUT_EVENT_turnneg;
    GUI_ContentId m_cidOUT_EVENT_turnpos;

};
class GUI_ListItemChoice : public GUI_ListItem
{
public:
    const GUI_ContentId* m_acidImages;
    int m_nNumImages;
    GUI_ContentId m_cidValue;
    const GUI_ContentId* m_acidContent;
    int m_nNumContent;

};
class GUI_ListItemMove : public GUI_ListItem
{
public:
    GUI_ContentId m_cidActiveIndex;
    GUI_ContentId m_cidActive;
    GUI_ContentId m_cidMoveable;
    GUI_ContentId m_cidIN_EVENT_listctrl_moveable;
    GUI_ContentId m_cidIN_EVENT_listctrl_not_moveable;

};
class GUI_DynamicImage : public GUI_Scripted
{
public:
    GUI_ContentId m_cidInDefaultImage;
    GUI_ContentId m_cidInDownloadedIconAlign;
    GUI_ContentId m_cidInDownloadedIconResize;
    GUI_ContentId m_cidInImagePath;

};
class GUI_ResizeableWidgetContainer : public GUI_Scripted
{
public:
    GUI_ContentId m_cidAlign;

};
class GUI_AlternateImageAnim : public GUI_Scripted
{
public:
    GUI_ContentId m_cidClock;
    const GUI_ContentId* m_acidImages;
    int m_nNumImages;
    GUI_ContentId m_cidMirror;
    GUI_ContentId m_cidRaster;
    GUI_ContentId m_cidStartIndex;

};
class GUI_Rotary : public GUI_Scripted
{
public:
    GUI_ContentId m_cidBand;
    GUI_ContentId m_cidMax;
    GUI_ContentId m_cidMin;
    GUI_ContentId m_cidTouchValue;
    GUI_ContentId m_cidValue;
    GUI_ContentId m_cidBmEnabled;
    GUI_ContentId m_cidBmPressed;
    GUI_ContentId m_cidBmScale;
    GUI_ContentId m_cidTouchableArea_X;
    GUI_ContentId m_cidTouchableArea_Y;
    GUI_ContentId m_cidTouchableArea_height;
    GUI_ContentId m_cidTouchableArea_width;
    GUI_ContentId m_cidOUT_EVENT_move;
    GUI_ContentId m_cidOUT_EVENT_pressed;
    GUI_ContentId m_cidOUT_EVENT_shortreleased;

};
class GUI_Sonar : public GUI_Scripted
{
public:
    GUI_ContentId m_cidCarType;
    GUI_ContentId m_cidFrontAvailable;
    GUI_ContentId m_cidFrontStatus;
    GUI_ContentId m_cidRearAvailable;
    GUI_ContentId m_cidRearStatus;
    GUI_ContentId m_cidTrailorConnected;

};
class GUI_TemplateWidgetContainer : public GUI_Scripted
{
public:

};
#endif // #ifndef _GUI_GENOTHERWIDGETS_H
