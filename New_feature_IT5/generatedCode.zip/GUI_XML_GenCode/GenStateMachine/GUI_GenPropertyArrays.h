/*  This file has been generated on 05.12.2014 16:37 */
/*
 *  This file contains the definition of all property arrays.
 *  Property arrays can be used in two different places:
 *    - directly as value for a widget's array property
 *      (see GUI_GenWidgetProperties.h, macro ARRAY_PROPERTY)
 *    - for an array access bin-operator (see GUI_GenContent.h,
 *      macro CONTENT_BINOPER_ARRAY)
 *
 *  Please note that:
 *    - Property arrays are arrays of content ids.
 *    - All kinds of cids can be mixed within one array.
 *    - Property arrays cannot be expressed by a cid themself.
 *    - Property arrays are read-only, i.e. they cannot change
 *      at runtime.
 *    - Property arrays can be re-used.
 *    - An empty array is also a valid property array.
 *
 *  The following macros are used:
 *
 *    BEGIN_PROPERTY_ARRAY(propsname, numprops)
 *       mark the beginning of a cid array;
 *       the propsname has to be a valid C++ identifier (consisting of
 *       letters, digits, and the underscore character)
 *
 *    END_ARRAY_PROPS()
 *       mark the end of a cid array
 *
 *    PROPERTY(value)
 *       define the value (a content id) for one property
 *
 */


BEGIN_PROPERTY_ARRAY(StateColors, 7)
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList, 1)
    PROPERTY(0xe0023014)                // Display1: 35, Display2: 20
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TMPL_strliMasterHeader_texts, 323)
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x8000043c)                // FM STATION LIST -> TMPL.strliMasterHeader.texts-001
    PROPERTY(0x8000043d)                // AM/FM TUNER -> TMPL.strliMasterHeader.texts-002
    PROPERTY(0x8000043e)                // FM TUNE -> TMPL.strliMasterHeader.texts-003
    PROPERTY(0x8000043f)                // AM TUNE -> TMPL.strliMasterHeader.texts-004
    PROPERTY(0x80000440)                // SIRIUSXM TRAFFIC -> TMPL.strliMasterHeader.texts-005
    PROPERTY(0x80000441)                // ALL TRAFFIC EVENTS -> TMPL.strliMasterHeader.texts-006
    PROPERTY(0x80000442)                // TRAFFIC EVENTS ON ROUTE -> TMPL.strliMasterHeader.texts-007
    PROPERTY(0x80000443)                // DETOUR -> TMPL.strliMasterHeader.texts-008
    PROPERTY(0x80000444)                // Set Distance then Recalculate -> TMPL.strliMasterHeader.texts-009
    PROPERTY(0x80000445)                // Select Segment then Recalculate -> TMPL.strliMasterHeader.texts-010
    PROPERTY(0x80000446)                // Touch to mark destination -> TMPL.strliMasterHeader.texts-011
    PROPERTY(0x80000447)                // NAVIGATION -> TMPL.strliMasterHeader.texts-012
    PROPERTY(0x80000448)                // ENTER DESTINATION BY: -> TMPL.strliMasterHeader.texts-013
    PROPERTY(0x80000449)                // INTERSECTION -> TMPL.strliMasterHeader.texts-014
    PROPERTY(0x8000044a)                // STREET ADDRESS -> TMPL.strliMasterHeader.texts-015
    PROPERTY(0x8000044b)                // Select City Name: -> TMPL.strliMasterHeader.texts-016
    PROPERTY(0x8000044c)                // Select Street Name: -> TMPL.strliMasterHeader.texts-017
    PROPERTY(0x8000044d)                // Select House Number: -> TMPL.strliMasterHeader.texts-018
    PROPERTY(0x8000044e)                // Select City Name: -> TMPL.strliMasterHeader.texts-019
    PROPERTY(0x8000044f)                // Select Area: -> TMPL.strliMasterHeader.texts-020
    PROPERTY(0x80000450)                // Select State/Province: -> TMPL.strliMasterHeader.texts-021
    PROPERTY(0x80000451)                // ENTER NEW ADDRESS -> TMPL.strliMasterHeader.texts-022
    PROPERTY(0x80000452)                // ROUTING OPTIONS -> TMPL.strliMasterHeader.texts-023
    PROPERTY(0x80000453)                // POINTS OF INTEREST -> TMPL.strliMasterHeader.texts-024
    PROPERTY(0x80000454)                // MY POINTS OF INTEREST -> TMPL.strliMasterHeader.texts-025
    PROPERTY(0x80000455)                // Select Points Of Interest Category: -> TMPL.strliMasterHeader.texts-026
    PROPERTY(0x80000456)                // TURN LIST -> TMPL.strliMasterHeader.texts-027
    PROPERTY(0x80000457)                // ADDRESS BOOK -> TMPL.strliMasterHeader.texts-028
    PROPERTY(0x80000458)                // PREVIOUS DESTINATION -> TMPL.strliMasterHeader.texts-029
    PROPERTY(0x80000459)                // HOME -> TMPL.strliMasterHeader.texts-030
    PROPERTY(0x8000045a)                // #Obsolete -> TMPL.strliMasterHeader.texts-031
    PROPERTY(0x8000045b)                // MY POINTS OF INTEREST -> TMPL.strliMasterHeader.texts-032
    PROPERTY(0x8000045c)                // MAP OPTIONS -> TMPL.strliMasterHeader.texts-033
    PROPERTY(0x8000045d)                // GPS POSITION -> TMPL.strliMasterHeader.texts-034
    PROPERTY(0x8000045e)                // DESTINATION -> TMPL.strliMasterHeader.texts-035
    PROPERTY(0x8000045f)                // SETTINGS -> TMPL.strliMasterHeader.texts-036
    PROPERTY(0x80000460)                // AUDIO SETTINGS -> TMPL.strliMasterHeader.texts-037
    PROPERTY(0x80000461)                // RADIO SETTINGS -> TMPL.strliMasterHeader.texts-038
    PROPERTY(0x80000462)                // SYSTEM SETTINGS -> TMPL.strliMasterHeader.texts-039
    PROPERTY(0x80000463)                // LANGUAGE -> TMPL.strliMasterHeader.texts-040
    PROPERTY(0x80000464)                // CLOCK SETTINGS -> TMPL.strliMasterHeader.texts-041
    PROPERTY(0x80000465)                // SET CLOCK MANUALLY -> TMPL.strliMasterHeader.texts-042
    PROPERTY(0x80000466)                // TIME ZONE -> TMPL.strliMasterHeader.texts-043
    PROPERTY(0x80000467)                // DISPLAY SETTINGS -> TMPL.strliMasterHeader.texts-044
    PROPERTY(0x80000468)                // NAVIGATION SETTINGS -> TMPL.strliMasterHeader.texts-045
    PROPERTY(0x80000469)                // GUIDANCE & MAP SETTINGS -> TMPL.strliMasterHeader.texts-046
    PROPERTY(0x8000046a)                // MAP CONTENT -> TMPL.strliMasterHeader.texts-047
    PROPERTY(0x8000046b)                // NAVIGATION INFORMATION -> TMPL.strliMasterHeader.texts-048
    PROPERTY(0x8000046c)                // TESTMODE MENU -> TMPL.strliMasterHeader.texts-049
    PROPERTY(0x8000046d)                // TESTMODE RADIO -> TMPL.strliMasterHeader.texts-050
    PROPERTY(0x8000046e)                // TESTMODE RADIO FM -> TMPL.strliMasterHeader.texts-051
    PROPERTY(0x8000046f)                // TESTMODE RADIO AM -> TMPL.strliMasterHeader.texts-052
    PROPERTY(0x80000470)                // TESTMODE RADIO AF LIST -> TMPL.strliMasterHeader.texts-053
    PROPERTY(0x80000471)                // TESTMODE-NAVIGATION -> TMPL.strliMasterHeader.texts-054
    PROPERTY(0x80000472)                // TESTMODE MAP INFO -> TMPL.strliMasterHeader.texts-055
    PROPERTY(0x80000473)                // TESTMODE GPS -> TMPL.strliMasterHeader.texts-056
    PROPERTY(0x80000474)                // TESTMODE DEAD RECKONING -> TMPL.strliMasterHeader.texts-057
    PROPERTY(0x80000475)                // TESTMODE MATCHED POS. -> TMPL.strliMasterHeader.texts-058
    PROPERTY(0x80000476)                // TESTMODE BEST SATELLITES -> TMPL.strliMasterHeader.texts-059
    PROPERTY(0x80000477)                // TESTMODE MERIDIANS -> TMPL.strliMasterHeader.texts-060
    PROPERTY(0x80000478)                // TESTMODE TRAFFIC INFO -> TMPL.strliMasterHeader.texts-061
    PROPERTY(0x80000479)                // TESTMODE TMC STATION LIST -> TMPL.strliMasterHeader.texts-062
    PROPERTY(0x8000047a)                // TESTMODE TMC STATION INFO -> TMPL.strliMasterHeader.texts-063
    PROPERTY(0x8000047b)                // TESTMODE-SYSTEM -> TMPL.strliMasterHeader.texts-064
    PROPERTY(0x8000047c)                // SERVICE SYSTEM STATUS -> TMPL.strliMasterHeader.texts-065
    PROPERTY(0x8000047d)                // TESTMODE SYSTEM TEMP. -> TMPL.strliMasterHeader.texts-066
    PROPERTY(0x8000047e)                // TESTMODE RESET COUNTER -> TMPL.strliMasterHeader.texts-067
    PROPERTY(0x8000047f)                // BLUETOOTH -> TMPL.strliMasterHeader.texts-068
    PROPERTY(0x80000480)                // TESTMODE AUDIO -> TMPL.strliMasterHeader.texts-069
    PROPERTY(0x80000481)                // SYSTEM VERSIONS -> TMPL.strliMasterHeader.texts-070
    PROPERTY(0x80000482)                // TESTMODE TMC -> TMPL.strliMasterHeader.texts-071
    PROPERTY(0x80000483)                // SERVICE MENU -> TMPL.strliMasterHeader.texts-072
    PROPERTY(0x80000484)                // SERVICE VERSION -> TMPL.strliMasterHeader.texts-073
    PROPERTY(0x80000485)                // SERVICE RADIO -> TMPL.strliMasterHeader.texts-074
    PROPERTY(0x80000486)                // SERVICE FM MONITOR -> TMPL.strliMasterHeader.texts-075
    PROPERTY(0x80000487)                // SERVICE AM MONITOR -> TMPL.strliMasterHeader.texts-076
    PROPERTY(0x80000488)                // SERVICE CONFIGURATION -> TMPL.strliMasterHeader.texts-077
    PROPERTY(0x80000489)                // SERVICE SYSTEM STATUS -> TMPL.strliMasterHeader.texts-078
    PROPERTY(0x8000048a)                // SERVICE SYSTEM HISTORY -> TMPL.strliMasterHeader.texts-079
    PROPERTY(0x8000048b)                // SERVICE SYS CONFIGURATION -> TMPL.strliMasterHeader.texts-080
    PROPERTY(0x8000048c)                // SERVICE SYSTEM SELF TEST -> TMPL.strliMasterHeader.texts-081
    PROPERTY(0x8000048d)                // CD -> TMPL.strliMasterHeader.texts-082
    PROPERTY(0x8000048e)                // CD MP3 -> TMPL.strliMasterHeader.texts-083
    PROPERTY(0x8000048f)                // iPod -> TMPL.strliMasterHeader.texts-084
    PROPERTY(0x80000490)                // USB -> TMPL.strliMasterHeader.texts-085
    PROPERTY(0x80000491)                // AUX  -> TMPL.strliMasterHeader.texts-086
    PROPERTY(0x80000492)                // BLUETOOTH AUDIO -> TMPL.strliMasterHeader.texts-087
    PROPERTY(0x80000493)                // PHONE -> TMPL.strliMasterHeader.texts-088
    PROPERTY(0x80000494)                // PHONEBOOK -> TMPL.strliMasterHeader.texts-089
    PROPERTY(0x80000495)                // CALL LIST -> TMPL.strliMasterHeader.texts-090
    PROPERTY(0x80000496)                // REDIAL -> TMPL.strliMasterHeader.texts-091
    PROPERTY(0x80000497)                // INCOMING CALLS -> TMPL.strliMasterHeader.texts-092
    PROPERTY(0x80000498)                // OUTGOING CALLS -> TMPL.strliMasterHeader.texts-093
    PROPERTY(0x80000499)                // MISSED CALLS -> TMPL.strliMasterHeader.texts-094
    PROPERTY(0x8000049a)                // TESTMODE AF LIST -> TMPL.strliMasterHeader.texts-095
    PROPERTY(0x8000049b)                // PHONE & BLUETOOTH SETTINGS -> TMPL.strliMasterHeader.texts-096
    PROPERTY(0x8000049c)                // NEARBY GAS STATIONS -> TMPL.strliMasterHeader.texts-097
    PROPERTY(0x8000049d)                // NEARBY PARKING -> TMPL.strliMasterHeader.texts-098
    PROPERTY(0x8000049e)                // City -> TMPL.strliMasterHeader.texts-099
    PROPERTY(0x80000185)                // Street -> NAV.strNAV_DESTENTRY.Street.text
    PROPERTY(0x8000049f)                // House Number -> TMPL.strliMasterHeader.texts-101
    PROPERTY(0x800004a0)                // Name -> TMPL.strliMasterHeader.texts-102
    PROPERTY(0x800004a1)                // Number -> TMPL.strliMasterHeader.texts-103
    PROPERTY(0x800004a2)                // AM -> TMPL.strliMasterHeader.texts-104
    PROPERTY(0x800004a3)                // FM -> TMPL.strliMasterHeader.texts-105
    PROPERTY(0x800004a4)                // #No translation required -> TMPL.strliMasterHeader.texts-106
    PROPERTY(0x800004a5)                // POINTS OF INTEREST AROUND POSITION -> TMPL.strliMasterHeader.texts-107
    PROPERTY(0x80000418)                // #Obsolete -> SYSDLG_NAV_STARTING_UP_SYSIND.c1.text2
    PROPERTY(0x800004a6)                // TESTMODE HIGHCUT -> TMPL.strliMasterHeader.texts-109
    PROPERTY(0x800004a7)                // Select Area: -> TMPL.strliMasterHeader.texts-110
    PROPERTY(0x800004a7)                // Select Area: -> TMPL.strliMasterHeader.texts-110
    PROPERTY(0x800004a8)                // REDIAL -> TMPL.strliMasterHeader.texts-112
    PROPERTY(0x800004a9)                // DELETE CONNECTED DEVICE -> TMPL.strliMasterHeader.texts-113
    PROPERTY(0x800004aa)                // SELECT CONNECTED DEVICE -> TMPL.strliMasterHeader.texts-114
    PROPERTY(0x800004ab)                // DEMO START LOCATION -> TMPL.strliMasterHeader.texts-115
    PROPERTY(0x800004ac)                // MY POINTS OF INTEREST ERRORS -> TMPL.strliMasterHeader.texts-116
    PROPERTY(0x800004ad)                // MAP DATA INFORMATION -> TMPL.strliMasterHeader.texts-117
    PROPERTY(0x800004ae)                // GPS POSITION -> TMPL.strliMasterHeader.texts-118
    PROPERTY(0x800004af)                // WAYPOINT -> TMPL.strliMasterHeader.texts-119
    PROPERTY(0x800004b0)                // Touch to mark destination: -> TMPL.strliMasterHeader.texts-120
    PROPERTY(0x800004b1)                // POINTS OF INTEREST -> TMPL.strliMasterHeader.texts-121
    PROPERTY(0x800004b2)                // SEARCH BY NAME -> TMPL.strliMasterHeader.texts-122
    PROPERTY(0x800004b3)                // SHOW POINTS OF INTEREST ON MAP -> TMPL.strliMasterHeader.texts-123
    PROPERTY(0x800004b4)                // SELECT AREA -> TMPL.strliMasterHeader.texts-124
    PROPERTY(0x800004b5)                // Search -> TMPL.strliMasterHeader.texts-125
    PROPERTY(0x800004b6)                // ADDRESS BOOK -> TMPL.strliMasterHeader.texts-126
    PROPERTY(0x800004b7)                // TESTMODE BLUETOOTH -> TMPL.strliMasterHeader.texts-127
    PROPERTY(0x800004b8)                //  ID STATUS DATA -> TMPL.strliMasterHeader.texts-128
    PROPERTY(0x800004b9)                // APPLICATION -> TMPL.strliMasterHeader.texts-129
    PROPERTY(0x800004ba)                // PHONE SETTINGS -> TMPL.strliMasterHeader.texts-130
    PROPERTY(0x800004bb)                // #Obsolete -> TMPL.strliMasterHeader.texts-131
    PROPERTY(0x800004bc)                // TRAFFIC SETTINGS -> TMPL.strliMasterHeader.texts-132
    PROPERTY(0x800004bd)                // MY POI ALERT DISTANCE -> TMPL.strliMasterHeader.texts-133
    PROPERTY(0x800004be)                // SERVICE SXM MONITOR 1 -> TMPL.strliMasterHeader.texts-134
    PROPERTY(0x800004bf)                // SERVICE SXM MONITOR 2 -> TMPL.strliMasterHeader.texts-135
    PROPERTY(0x800004c0)                // SERVICE SXM VERSION -> TMPL.strliMasterHeader.texts-136
    PROPERTY(0x800004c1)                // SERVICE SXM FUNCTIONS -> TMPL.strliMasterHeader.texts-137
    PROPERTY(0x800004c2)                // SXM CHANNELS -> TMPL.strliMasterHeader.texts-138
    PROPERTY(0x800004c3)                // SXM CATEGORIES -> TMPL.strliMasterHeader.texts-139
    PROPERTY(0x800004c4)                // SXM STATUS -> TMPL.strliMasterHeader.texts-140
    PROPERTY(0x800004c5)                // State/Prov. -> TMPL.strliMasterHeader.texts-141
    PROPERTY(0x800004c6)                // ENTER INTERSECTION -> TMPL.strliMasterHeader.texts-142
    PROPERTY(0x800004c7)                // SELECT INTERSECTION -> TMPL.strliMasterHeader.texts-143
    PROPERTY(0x800004c8)                // ADD DESTINATION -> TMPL.strliMasterHeader.texts-144
    PROPERTY(0x800004c9)                // Push "Start" to calculate route -> TMPL.strliMasterHeader.texts-145
    PROPERTY(0x800004ca)                // Push "Save" to save address -> TMPL.strliMasterHeader.texts-146
    PROPERTY(0x800004cb)                // Push "Save" to save as Home -> TMPL.strliMasterHeader.texts-147
    PROPERTY(0x800004cc)                // Push "Save" to save position -> TMPL.strliMasterHeader.texts-148
    PROPERTY(0x800004cd)                // CUSTOMIZE TRAVEL SPEEDS -> TMPL.strliMasterHeader.texts-149
    PROPERTY(0x800004ce)                // MY POINTS OF INTEREST SETTINGS -> TMPL.strliMasterHeader.texts-150
    PROPERTY(0x800004cf)                // FILE INFORMATION -> TMPL.strliMasterHeader.texts-151
    PROPERTY(0x800004d0)                // #Obsolete -> TMPL.strliMasterHeader.texts-152
    PROPERTY(0x800004d1)                // #Obsolete -> TMPL.strliMasterHeader.texts-153
    PROPERTY(0x800004d2)                // LOCATION -> TMPL.strliMasterHeader.texts-154
    PROPERTY(0x800004d3)                // #Obsolete -> TMPL.strliMasterHeader.texts-155
    PROPERTY(0x800004d4)                // APPS�INFORMATION -> TMPL.strliMasterHeader.texts-156
    PROPERTY(0x800004d5)                // WEATHER: -> TMPL.strliMasterHeader.texts-157
    PROPERTY(0x800004d6)                // 5 DAY WEATHER FORECAST -> TMPL.strliMasterHeader.texts-158
    PROPERTY(0x800004d7)                // VOICE RECOGNITION -> TMPL.strliMasterHeader.texts-159
    PROPERTY(0x800004d8)                // SEARCH -> TMPL.strliMasterHeader.texts-160
    PROPERTY(0x800004d9)                // SEARCH RESULT -> TMPL.strliMasterHeader.texts-161
    PROPERTY(0x800004da)                // Google� Send-to-Car -> TMPL.strliMasterHeader.texts-162
    PROPERTY(0x800004db)                // INFO SETTINGS -> TMPL.strliMasterHeader.texts-163
    PROPERTY(0x800004dc)                // #Obsolete -> TMPL.strliMasterHeader.texts-164
    PROPERTY(0x800004dd)                // WAYPOINT LIST -> TMPL.strliMasterHeader.texts-165
    PROPERTY(0x800004de)                // TRIP LIST -> TMPL.strliMasterHeader.texts-166
    PROPERTY(0x800004df)                // Select the position in the route. -> TMPL.strliMasterHeader.texts-167
    PROPERTY(0x800004e0)                // SECTION DETAILS -> TMPL.strliMasterHeader.texts-168
    PROPERTY(0x800004e1)                // CAMERA SETTINGS -> TMPL.strliMasterHeader.texts-169
    PROPERTY(0x800004e2)                // Select device to replace. -> TMPL.strliMasterHeader.texts-170
    PROPERTY(0x800004e3)                // INFO -> TMPL.strliMasterHeader.texts-171
    PROPERTY(0x800004e4)                // #Obsolete -> TMPL.strliMasterHeader.texts-172
    PROPERTY(0x800004e5)                // #Obsolete -> TMPL.strliMasterHeader.texts-173
    PROPERTY(0x800004e6)                // ECO DRIVING SCORE -> TMPL.strliMasterHeader.texts-174
    PROPERTY(0x800004e7)                // ECO SCORE HISTORY -> TMPL.strliMasterHeader.texts-175
    PROPERTY(0x800004e8)                // There is a route in progress. -> TMPL.strliMasterHeader.texts-176
    PROPERTY(0x800004e9)                // #No translation required -> TMPL.strliMasterHeader.texts-177
    PROPERTY(0x800004ea)                // #No translation required -> TMPL.strliMasterHeader.texts-178
    PROPERTY(0x800004eb)                // #No translation required -> TMPL.strliMasterHeader.texts-179
    PROPERTY(0x800004ec)                // #No translation required -> TMPL.strliMasterHeader.texts-180
    PROPERTY(0x800004ed)                // FUEL PRICES -> TMPL.strliMasterHeader.texts-181
    PROPERTY(0x800004ee)                // #No translation required -> TMPL.strliMasterHeader.texts-182
    PROPERTY(0x800004ef)                // #No translation required -> TMPL.strliMasterHeader.texts-183
    PROPERTY(0x800004f0)                // #No translation required -> TMPL.strliMasterHeader.texts-184
    PROPERTY(0x800004f1)                // BT DEVICE TESTMODE -> TMPL.strliMasterHeader.texts-185
    PROPERTY(0x800004f2)                // STATION LIST -> TMPL.strliMasterHeader.texts-186
    PROPERTY(0x800004f3)                // DELETE STATION -> TMPL.strliMasterHeader.texts-187
    PROPERTY(0x800004f4)                // APPS�INFORMATION -> TMPL.strliMasterHeader.texts-188
    PROPERTY(0x800004f5)                // TEXT MESSAGE -> TMPL.strliMasterHeader.texts-189
    PROPERTY(0x800004f6)                // #Obsolete -> TMPL.strliMasterHeader.texts-190
    PROPERTY(0x800004f7)                // Select message for auto reply -> TMPL.strliMasterHeader.texts-191
    PROPERTY(0x800004f8)                // Select a message to edit -> TMPL.strliMasterHeader.texts-192
    PROPERTY(0x800004f9)                // DELETE ENTRY FROM LIST -> TMPL.strliMasterHeader.texts-193
    PROPERTY(0x800004fa)                // CITY CENTER -> TMPL.strliMasterHeader.texts-194
    PROPERTY(0x800004fb)                // GAS STATION -> TMPL.strliMasterHeader.texts-195
    PROPERTY(0x800004fc)                // RESTAURANT -> TMPL.strliMasterHeader.texts-196
    PROPERTY(0x800004fd)                // ATM -> TMPL.strliMasterHeader.texts-197
    PROPERTY(0x800004fe)                // PARKING -> TMPL.strliMasterHeader.texts-198
    PROPERTY(0x800004ff)                // REST AREA -> TMPL.strliMasterHeader.texts-199
    PROPERTY(0x80000500)                // HOTEL -> TMPL.strliMasterHeader.texts-200
    PROPERTY(0x80000501)                // DEALERSHIP -> TMPL.strliMasterHeader.texts-201
    PROPERTY(0x80000502)                // AIRPORT -> TMPL.strliMasterHeader.texts-202
    PROPERTY(0x80000503)                // POINTS OF INTEREST ALONG ROUTE -> TMPL.strliMasterHeader.texts-203
    PROPERTY(0x80000504)                // SEARCH BY NAME -> TMPL.strliMasterHeader.texts-204
    PROPERTY(0x80000505)                // SEARCH BY CATEGORY -> TMPL.strliMasterHeader.texts-205
    PROPERTY(0x80000506)                // DRIVING ASSISTANCE -> TMPL.strliMasterHeader.texts-206
    PROPERTY(0x80000506)                // DRIVING ASSISTANCE -> TMPL.strliMasterHeader.texts-206
    PROPERTY(0x80000507)                // Text -> TMPL.strliMasterHeader.texts-208
    PROPERTY(0x80000508)                // NEARBY RESTAURANTS -> TMPL.strliMasterHeader.texts-209
    PROPERTY(0x80000509)                // GUIDANCE INFORMATION -> TMPL.strliMasterHeader.texts-210
    PROPERTY(0x8000050a)                // Select received text message -> TMPL.strliMasterHeader.texts-211
    PROPERTY(0x8000050b)                // CUSTOM MESSAGE OPTIONS -> TMPL.strliMasterHeader.texts-212
    PROPERTY(0x8000050c)                // TESTMODE - FM SETUP -> TMPL.strliMasterHeader.texts-213
    PROPERTY(0x8000050d)                // TESTMODE - AF LIST -> TMPL.strliMasterHeader.texts-214
    PROPERTY(0x8000050e)                // TESTMODE QUADMONITOR -> TMPL.strliMasterHeader.texts-215
    PROPERTY(0x8000050f)                // TESTMODE - DAB SETUP -> TMPL.strliMasterHeader.texts-216
    PROPERTY(0x80000510)                // TESTMODE GNSS -> TMPL.strliMasterHeader.texts-217
    PROPERTY(0x80000511)                // NEARBY ATM -> TMPL.strliMasterHeader.texts-218
    PROPERTY(0x80000512)                // ENTIRE ROUTE -> TMPL.strliMasterHeader.texts-219
    PROPERTY(0x80000513)                // TESTMODE - CALIBRATION -> TMPL.strliMasterHeader.texts-220
    PROPERTY(0x800004ed)                // FUEL PRICES -> TMPL.strliMasterHeader.texts-181
    PROPERTY(0x80000514)                // NEARBY -> TMPL.strliMasterHeader.texts-222
    PROPERTY(0x80000515)                // NEAR DESTINATION -> TMPL.strliMasterHeader.texts-223
    PROPERTY(0x80000516)                // FAVORITES -> TMPL.strliMasterHeader.texts-224
    PROPERTY(0x80000517)                // FILTER BY BRAND -> TMPL.strliMasterHeader.texts-225
    PROPERTY(0x80000518)                // REPLACE FAVORITE -> TMPL.strliMasterHeader.texts-226
    PROPERTY(0x80000519)                // LOCATION -> TMPL.strliMasterHeader.texts-227
    PROPERTY(0x8000051a)                // FAVORITE LOCATIONS -> TMPL.strliMasterHeader.texts-228
    PROPERTY(0x8000051b)                // WEATHER FORECAST -> TMPL.strliMasterHeader.texts-229
    PROPERTY(0x8000051c)                // MAP TYPE -> TMPL.strliMasterHeader.texts-230
    PROPERTY(0x8000051d)                // GUIDANCE & MAP SETTINGS -> TMPL.strliMasterHeader.texts-231
    PROPERTY(0x8000051e)                // #No translation required -> TMPL.strliMasterHeader.texts-232
    PROPERTY(0x8000051f)                // #No translation required -> TMPL.strliMasterHeader.texts-233
    PROPERTY(0x80000520)                // #No translation required -> TMPL.strliMasterHeader.texts-234
    PROPERTY(0x800004a1)                // Number -> TMPL.strliMasterHeader.texts-103
    PROPERTY(0x80000521)                // STOCKS -> TMPL.strliMasterHeader.texts-236
    PROPERTY(0x80000522)                // Select list item to add -> TMPL.strliMasterHeader.texts-237
    PROPERTY(0x80000523)                // Select a ticker to remove it -> TMPL.strliMasterHeader.texts-238
    PROPERTY(0x80000524)                // MOVIE -> TMPL.strliMasterHeader.texts-239
    PROPERTY(0x80000525)                // MOVIES -> TMPL.strliMasterHeader.texts-240
    PROPERTY(0x80000526)                // MOVIE THEATERS -> TMPL.strliMasterHeader.texts-241
    PROPERTY(0x80000516)                // FAVORITES -> TMPL.strliMasterHeader.texts-224
    PROPERTY(0x80000527)                // REPLACE FAVORITE -> TMPL.strliMasterHeader.texts-243
    PROPERTY(0x80000528)                // THEATERS -> TMPL.strliMasterHeader.texts-244
    PROPERTY(0x80000529)                // SHOW TIMES -> TMPL.strliMasterHeader.texts-245
    PROPERTY(0x8000052a)                // THEATER -> TMPL.strliMasterHeader.texts-246
    PROPERTY(0x8000052b)                // RADAR MAP -> TMPL.strliMasterHeader.texts-247
    PROPERTY(0x8000052c)                // PRESSURE MAP -> TMPL.strliMasterHeader.texts-248
    PROPERTY(0x8000052d)                // WIND MAP -> TMPL.strliMasterHeader.texts-249
    PROPERTY(0x8000052e)                // STORM CELLS MAP -> TMPL.strliMasterHeader.texts-250
    PROPERTY(0x8000052f)                // HURRICANE TRACKING MAP -> TMPL.strliMasterHeader.texts-251
    PROPERTY(0x80000530)                // SOFTWARE LICENSES -> TMPL.strliMasterHeader.texts-252
    PROPERTY(0x80000531)                // DELETE FAVORITE -> TMPL.strliMasterHeader.texts-253
    PROPERTY(0x80000532)                // SELECTED POIs ON MAP -> TMPL.strliMasterHeader.texts-254
    PROPERTY(0x80000533)                // SIRIUSXM TRAVEL LINK -> TMPL.strliMasterHeader.texts-255
    PROPERTY(0x80000534)                // FILTER BY FUEL TYPE -> TMPL.strliMasterHeader.texts-256
    PROPERTY(0x80000535)                // ADD WAYPOINT -> TMPL.strliMasterHeader.texts-257
    PROPERTY(0x80000536)                // DRIVING ASSISTANCE -> TMPL.strliMasterHeader.texts-258
    PROPERTY(0x80000537)                // CAMERA SETTINGS -> TMPL.strliMasterHeader.texts-259
    PROPERTY(0x80000538)                // TESTMODE SXM SIGNAL 1 -> TMPL.strliMasterHeader.texts-260
    PROPERTY(0x80000539)                // TESTMODE SXM SIGNAL 2 -> TMPL.strliMasterHeader.texts-261
    PROPERTY(0x8000053a)                // TESTMODE SXM VERSION 1 -> TMPL.strliMasterHeader.texts-262
    PROPERTY(0x8000053b)                // TESTMODE SXM VERSION 2 -> TMPL.strliMasterHeader.texts-263
    PROPERTY(0x8000053c)                // TESTMODE SXM SUBSCRIPTION -> TMPL.strliMasterHeader.texts-264
    PROPERTY(0x8000053d)                // TESTMODE � MONITOR SELECTION -> TMPL.strliMasterHeader.texts-265
    PROPERTY(0x8000053e)                // TESTMODE � SXM SETTINGS -> TMPL.strliMasterHeader.texts-266
    PROPERTY(0x8000053f)                // SERVICE SXM MONITOR -> TMPL.strliMasterHeader.texts-267
    PROPERTY(0x80000540)                // Province -> TMPL.strliMasterHeader.texts-268
    PROPERTY(0x80000541)                // Select Province -> TMPL.strliMasterHeader.texts-269
    PROPERTY(0x80000542)                // TRAFFIC EVENT DETAILS -> TMPL.strliMasterHeader.texts-270
    PROPERTY(0x80000543)                // TESTMODE LANGUAGE -> TMPL.strliMasterHeader.texts-271
    PROPERTY(0x80000544)                // Country -> TMPL.strliMasterHeader.texts-272
    PROPERTY(0x80000545)                // Select Country -> TMPL.strliMasterHeader.texts-273
    PROPERTY(0x80000546)                // Voice Menu -> TMPL.strliMasterHeader.texts-274
    PROPERTY(0x80000547)                // SMART FAVORITES SETUP -> TMPL.strliMasterHeader.texts-275
    PROPERTY(0x80000548)                // AVAILABLE PRESET LIST -> TMPL.strliMasterHeader.texts-276
    PROPERTY(0x80000549)                // NissanConnect Services -> TMPL.strliMasterHeader.texts-277
    PROPERTY(0x8000054a)                // Destination Send-to-Car -> TMPL.strliMasterHeader.texts-278
    PROPERTY(0x8000054b)                // Connected Search -> TMPL.strliMasterHeader.texts-279
    PROPERTY(0x8000054c)                // Message History -> TMPL.strliMasterHeader.texts-280
    PROPERTY(0x8000054d)                // FEED AUTOPLAY -> TMPL.strliMasterHeader.texts-281
    PROPERTY(0x8000054e)                // ENERGY FLOW -> TMPL.strliMasterHeader.texts-282
    PROPERTY(0x8000054f)                // ENERGY / FUEL HISTORY -> TMPL.strliMasterHeader.texts-283
    PROPERTY(0x80000550)                // TODAY'S EVENT -> TMPL.strliMasterHeader.texts-284
    PROPERTY(0x80000551)                // RECENT EVENTS -> TMPL.strliMasterHeader.texts-285
    PROPERTY(0x80000552)                // FUTURE EVENTS -> TMPL.strliMasterHeader.texts-286
    PROPERTY(0x80000553)                // INFO -> TMPL.strliMasterHeader.texts-287
    PROPERTY(0x80000554)                // GAMES -> TMPL.strliMasterHeader.texts-288
    PROPERTY(0x80000555)                // SPORTS -> TMPL.strliMasterHeader.texts-289
    PROPERTY(0x80000556)                // NEWS -> TMPL.strliMasterHeader.texts-290
    PROPERTY(0x80000557)                // ALL TEAMS -> TMPL.strliMasterHeader.texts-291
    PROPERTY(0x80000558)                // TOP TEAMS -> TMPL.strliMasterHeader.texts-292
    PROPERTY(0x80000559)                // Siri -> TMPL.strliMasterHeader.texts-293
    PROPERTY(0x8000055a)                // Voice Assistant -> TMPL.strliMasterHeader.texts-294
    PROPERTY(0x8000055b)                // JOURNEY PLANNER -> TMPL.strliMasterHeader.texts-295
    PROPERTY(0x8000055c)                // Select country for dial-in number -> TMPL.strliMasterHeader.texts-296
    PROPERTY(0x8000055d)                // NISSANCONNECT SERVICES SETTINGS -> TMPL.strliMasterHeader.texts-297
    PROPERTY(0x8000055e)                // MOBILE INFORMATION FOLDER -> TMPL.strliMasterHeader.texts-298
    PROPERTY(0x8000055f)                // MOBILE INFORMATION MESSAGES -> TMPL.strliMasterHeader.texts-299
    PROPERTY(0x80000560)                // InTouch Services -> TMPL.strliMasterHeader.texts-300
    PROPERTY(0x80000561)                // INTOUCH SERVICES SETTINGS -> TMPL.strliMasterHeader.texts-301
    PROPERTY(0x80000562)                // CLIMA SETUP -> TMPL.strliMasterHeader.texts-302
    PROPERTY(0x80000563)                // VEHICLE SETTINGS -> TMPL.strliMasterHeader.texts-303
    PROPERTY(0x80000564)                // CLIMATE -> TMPL.strliMasterHeader.texts-304
    PROPERTY(0x80000565)                // UNIT SETTINGS -> TMPL.strliMasterHeader.texts-305
    PROPERTY(0x80000566)                // RSE SETTINGS -> TMPL.strliMasterHeader.texts-306
    PROPERTY(0x80000567)                // FUEL ECONOMY -> TMPL.strliMasterHeader.texts-307
    PROPERTY(0x80000568)                // TIRE PRESSURE -> TMPL.strliMasterHeader.texts-308
    PROPERTY(0x80000569)                // VEHICLE FUNCTIONS -> TMPL.strliMasterHeader.texts-309
    PROPERTY(0x8000056a)                // AM STATION LIST -> TMPL.strliMasterHeader.texts-310
    PROPERTY(0x8000056b)                // BOSE AUDIO SETTINGS -> TMPL.strliMasterHeader.texts-311
    PROPERTY(0x8000056c)                // OPERATOR POI DOWNLOAD -> TMPL.strliMasterHeader.texts-312
    PROPERTY(0x8000056d)                // TODAY'S GAMES -> TMPL.strliMasterHeader.texts-313
    PROPERTY(0x8000056e)                // RECENT GAMES -> TMPL.strliMasterHeader.texts-314
    PROPERTY(0x8000056f)                // FUTURE GAMES -> TMPL.strliMasterHeader.texts-315
    PROPERTY(0x80000570)                // Leaderboard -> TMPL.strliMasterHeader.texts-316
    PROPERTY(0x80000571)                // Standings -> TMPL.strliMasterHeader.texts-317
    PROPERTY(0x80000572)                // Results -> TMPL.strliMasterHeader.texts-318
    PROPERTY(0x80000573)                // FAVORITE TEAMS -> TMPL.strliMasterHeader.texts-319
    PROPERTY(0x80000574)                // TODAY'S RACES -> TMPL.strliMasterHeader.texts-320
    PROPERTY(0x80000575)                // RECENT RACES -> TMPL.strliMasterHeader.texts-321
    PROPERTY(0x80000576)                // FUTURE RACES -> TMPL.strliMasterHeader.texts-322
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Empty, 0)
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images, 6)
    PROPERTY(0x20000004)                // 800x480\HMINissanResources\HMI\header_statusline\header_phone_strength_00.png
    PROPERTY(0x20000005)                // 800x480\HMINissanResources\HMI\header_statusline\header_phone_strength_01.png
    PROPERTY(0x20000006)                // 800x480\HMINissanResources\HMI\header_statusline\header_phone_strength_02.png
    PROPERTY(0x20000007)                // 800x480\HMINissanResources\HMI\header_statusline\header_phone_strength_03.png
    PROPERTY(0x20000008)                // 800x480\HMINissanResources\HMI\header_statusline\header_phone_strength_04.png
    PROPERTY(0x20000009)                // 800x480\HMINissanResources\HMI\header_statusline\header_phone_strength_05.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_96, 1)
    PROPERTY(0x2000000a)                // 800x480\HMINissanResources\HMI\header_statusline\header_bt_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_97, 6)
    PROPERTY(0x2000000b)                // 800x480\HMINissanResources\HMI\header_statusline\battery_0_4.png
    PROPERTY(0x2000000c)                // 800x480\HMINissanResources\HMI\header_statusline\battery_1_4.png
    PROPERTY(0x2000000c)                // 800x480\HMINissanResources\HMI\header_statusline\battery_1_4.png
    PROPERTY(0x2000000d)                // 800x480\HMINissanResources\HMI\header_statusline\battery_2_4.png
    PROPERTY(0x2000000d)                // 800x480\HMINissanResources\HMI\header_statusline\battery_2_4.png
    PROPERTY(0x2000000e)                // 800x480\HMINissanResources\HMI\header_statusline\battery_3_4.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_98, 4)
    PROPERTY(0x2000000f)                // 800x480\HMINissanResources\HMI\header_statusline\ta_e_available.png
    PROPERTY(0x20000010)                // 800x480\HMINissanResources\HMI\header_statusline\ta_e_not_available.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_99, 21)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000012)                // 800x480\HMINissanResources\HMI\header_statusline\sms01.png
    PROPERTY(0x20000013)                // 800x480\HMINissanResources\HMI\header_statusline\sms02.png
    PROPERTY(0x20000014)                // 800x480\HMINissanResources\HMI\header_statusline\sms03.png
    PROPERTY(0x20000015)                // 800x480\HMINissanResources\HMI\header_statusline\sms04.png
    PROPERTY(0x20000016)                // 800x480\HMINissanResources\HMI\header_statusline\sms05.png
    PROPERTY(0x20000017)                // 800x480\HMINissanResources\HMI\header_statusline\sms06.png
    PROPERTY(0x20000018)                // 800x480\HMINissanResources\HMI\header_statusline\sms07.png
    PROPERTY(0x20000019)                // 800x480\HMINissanResources\HMI\header_statusline\sms08.png
    PROPERTY(0x2000001a)                // 800x480\HMINissanResources\HMI\header_statusline\sms09.png
    PROPERTY(0x2000001b)                // 800x480\HMINissanResources\HMI\header_statusline\sms10.png
    PROPERTY(0x2000001c)                // 800x480\HMINissanResources\HMI\header_statusline\sms11.png
    PROPERTY(0x2000001d)                // 800x480\HMINissanResources\HMI\header_statusline\sms12.png
    PROPERTY(0x2000001e)                // 800x480\HMINissanResources\HMI\header_statusline\sms13.png
    PROPERTY(0x2000001f)                // 800x480\HMINissanResources\HMI\header_statusline\sms14.png
    PROPERTY(0x20000020)                // 800x480\HMINissanResources\HMI\header_statusline\sms15.png
    PROPERTY(0x20000021)                // 800x480\HMINissanResources\HMI\header_statusline\sms16.png
    PROPERTY(0x20000022)                // 800x480\HMINissanResources\HMI\header_statusline\sms17.png
    PROPERTY(0x20000023)                // 800x480\HMINissanResources\HMI\header_statusline\sms18.png
    PROPERTY(0x20000024)                // 800x480\HMINissanResources\HMI\header_statusline\sms19.png
    PROPERTY(0x20000025)                // 800x480\HMINissanResources\HMI\header_statusline\sms20.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_100, 3)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000026)                // 800x480\HMINissanResources\HMI\header_statusline\telematic_connect.png
    PROPERTY(0x20000027)                // 800x480\HMINissanResources\HMI\header_statusline\telematic_disconnect.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages, 7)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages, 9)
    PROPERTY(0x20000028)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_e.png
    PROPERTY(0x20000029)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_e_f.png
    PROPERTY(0x2000002a)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_d.png
    PROPERTY(0x2000002a)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_d.png
    PROPERTY(0x20000028)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_e.png
    PROPERTY(0x20000029)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_e_f.png
    PROPERTY(0x2000002b)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_101, 7)
    PROPERTY(0x10f47721)                // 16021281
    PROPERTY(0x109b0000)                // 10158080
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_102, 1)
    PROPERTY(0xe003101c)                // Display1: 49, Display2: 28
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_125, 7)
    PROPERTY(0x10dc1900)                // 14424320
    PROPERTY(0x10dc1900)                // 14424320
    PROPERTY(0x10dc1900)                // 14424320
    PROPERTY(0x10dc1900)                // 14424320
    PROPERTY(0x10dc1900)                // 14424320
    PROPERTY(0x10dc1900)                // 14424320
    PROPERTY(0x10dc1900)                // 14424320
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_127, 7)
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_137, 9)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_139, 7)
    PROPERTY(0x10f47721)                // 16021281
    PROPERTY(0x109b0000)                // 10158080
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_140, 52)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000031)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_arrived_ul.png
    PROPERTY(0x20000032)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_exit-l_ul.png
    PROPERTY(0x20000033)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_exit-r_ul.png
    PROPERTY(0x20000034)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_l_rdbt000_ul.png
    PROPERTY(0x20000035)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_l_rdbt045-l_ul.png
    PROPERTY(0x20000036)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_l_rdbt045-r_ul.png
    PROPERTY(0x20000037)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_l_rdbt090-l_ul.png
    PROPERTY(0x20000038)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_l_rdbt090-r_ul.png
    PROPERTY(0x20000039)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_l_rdbt135-l_ul.png
    PROPERTY(0x2000003a)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_l_rdbt135-r_ul.png
    PROPERTY(0x2000003b)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_l_rdbt180_ul.png
    PROPERTY(0x2000003c)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_r_rdbt000_ul.png
    PROPERTY(0x2000003d)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_r_rdbt045-l_ul.png
    PROPERTY(0x2000003e)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_r_rdbt045-r_ul.png
    PROPERTY(0x2000003f)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_r_rdbt090-l_ul.png
    PROPERTY(0x20000040)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_r_rdbt090-r_ul.png
    PROPERTY(0x20000041)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_r_rdbt135-l_ul.png
    PROPERTY(0x20000042)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_r_rdbt135-r_ul.png
    PROPERTY(0x20000043)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_r_rdbt180_ul.png
    PROPERTY(0x20000044)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_turn000_ul.png
    PROPERTY(0x20000045)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_turn045-l_ul.png
    PROPERTY(0x20000046)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_turn045-r_ul.png
    PROPERTY(0x20000047)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_turn090-l_ul.png
    PROPERTY(0x20000048)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_turn090-r_ul.png
    PROPERTY(0x20000049)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_turn135-l_ul.png
    PROPERTY(0x2000004a)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_turn135-r_ul.png
    PROPERTY(0x2000004b)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_uturn-l_ul.png
    PROPERTY(0x2000004c)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_uturn-r_ul.png
    PROPERTY(0x2000004d)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_l_changestreet_ul.png
    PROPERTY(0x2000004e)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_r_changestreet_ul.png
    PROPERTY(0x2000004f)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_000.png
    PROPERTY(0x20000050)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_022.png
    PROPERTY(0x20000051)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_045.png
    PROPERTY(0x20000052)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_067.png
    PROPERTY(0x20000053)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_090.png
    PROPERTY(0x20000054)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_112.png
    PROPERTY(0x20000055)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_135.png
    PROPERTY(0x20000056)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_157.png
    PROPERTY(0x20000057)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_180.png
    PROPERTY(0x20000058)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_202.png
    PROPERTY(0x20000059)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_225.png
    PROPERTY(0x2000005a)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_247.png
    PROPERTY(0x2000005b)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_270.png
    PROPERTY(0x2000005c)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_292.png
    PROPERTY(0x2000005d)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_315.png
    PROPERTY(0x2000005e)                // 800x480\HMINissanResources\HMI\ofe_offroad\offroad_337.png
    PROPERTY(0x2000005f)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_follow_ul.png
    PROPERTY(0x20000060)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_keep_l.png
    PROPERTY(0x20000061)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_keep_r.png
    PROPERTY(0x20000062)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_arrived-l_ul.png
    PROPERTY(0x20000063)                // 800x480\HMINissanResources\HMI\ofe_mnvr\mnvr_arrived-r_ul.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_141, 1)
    PROPERTY(0xe001c010)                // Display1: 28, Display2: 16
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Navigation_Map_GetDistanceTodestinationUnit, 5)
    PROPERTY(0x8000003c)                // km -> __export_Navigation_StrliAPIString-030
    PROPERTY(0x800001e7)                // m -> Navigation.Map.GetDistanceToManeuverUnit-001
    PROPERTY(0x800001e8)                // mi -> Navigation.Map.GetDistanceToManeuverUnit-002
    PROPERTY(0x80000041)                // yds -> __export_Navigation_StrliAPIString-035
    PROPERTY(0x800001ea)                // ft -> Navigation.Map.GetDistanceToManeuverUnit-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_142, 1)
    PROPERTY(0xe001800d)                // Display1: 24, Display2: 13
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_144, 7)
    PROPERTY(0x10f47721)                // 16021281
    PROPERTY(0x109b0000)                // 10158080
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10000000)                // 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_145, 7)
    PROPERTY(0x10f47721)                // 16021281
    PROPERTY(0x109b0000)                // 10158080
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_148, 1)
    PROPERTY(0xe0054030)                // Display1: 84, Display2: 48
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(CONST_SYSTEM_CLOCK_AM_PM_text, 2)
    PROPERTY(0x800000bd)                // AM -> CONST.SYSTEM_CLOCK.AM_PM.text-000
    PROPERTY(0x800000be)                // PM -> CONST.SYSTEM_CLOCK.AM_PM.text-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_159, 9)
    PROPERTY(0x2000006a)                // 800x480\HMINissanResources\HMI\header_icons\btn_back_a.png
    PROPERTY(0x2000006b)                // 800x480\HMINissanResources\HMI\header_icons\btn_back_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000006c)                // 800x480\HMINissanResources\HMI\header_icons\btn_back_e.png
    PROPERTY(0x2000006c)                // 800x480\HMINissanResources\HMI\header_icons\btn_back_e.png
    PROPERTY(0x2000006d)                // 800x480\HMINissanResources\HMI\header_icons\btn_back_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_160, 1)
    PROPERTY(0xe001b00f)                // Display1: 27, Display2: 15
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(textColorArray, 4)
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10ffffff)                // 16777215
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_161, 9)
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x20000070)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e_f.png
    PROPERTY(0x20000071)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_d.png
    PROPERTY(0x20000071)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_d.png
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x20000070)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e_f.png
    PROPERTY(0x20000072)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_165, 16)
    PROPERTY(0x20000073)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_000_ul.png
    PROPERTY(0x20000074)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_022_ul.png
    PROPERTY(0x20000075)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_045_ul.png
    PROPERTY(0x20000076)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_067_ul.png
    PROPERTY(0x20000077)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_090_ul.png
    PROPERTY(0x20000078)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_112_ul.png
    PROPERTY(0x20000079)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_135_ul.png
    PROPERTY(0x2000007a)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_157_ul.png
    PROPERTY(0x2000007b)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_180_ul.png
    PROPERTY(0x2000007c)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_202_ul.png
    PROPERTY(0x2000007d)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_225_ul.png
    PROPERTY(0x2000007e)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_247_ul.png
    PROPERTY(0x2000007f)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_270_ul.png
    PROPERTY(0x20000080)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_292_ul.png
    PROPERTY(0x20000081)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_315_ul.png
    PROPERTY(0x20000082)                // 800x480\HMINissanResources\HMI\map_compass\n-arrow_337_ul.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_166, 16)
    PROPERTY(0x20000084)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_000_ul.png
    PROPERTY(0x20000085)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_022_ul.png
    PROPERTY(0x20000086)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_045_ul.png
    PROPERTY(0x20000087)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_067_ul.png
    PROPERTY(0x20000088)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_090_ul.png
    PROPERTY(0x20000089)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_112_ul.png
    PROPERTY(0x2000008a)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_135_ul.png
    PROPERTY(0x2000008b)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_157_ul.png
    PROPERTY(0x2000008c)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_180_ul.png
    PROPERTY(0x2000008d)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_202_ul.png
    PROPERTY(0x2000008e)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_225_ul.png
    PROPERTY(0x2000008f)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_247_ul.png
    PROPERTY(0x20000090)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_270_ul.png
    PROPERTY(0x20000091)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_292_ul.png
    PROPERTY(0x20000092)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_315_ul.png
    PROPERTY(0x20000093)                // 800x480\HMINissanResources\HMI\map_compass_3D\n-arrow_337_ul.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(NAV_MAP_strlstZoomLevel_miles, 13)
    PROPERTY(0x80000150)                // 150ft -> NAV.MAP.strlstZoomLevel_miles-000
    PROPERTY(0x80000151)                // 300ft -> NAV.MAP.strlstZoomLevel_miles-001
    PROPERTY(0x80000152)                // 600ft -> NAV.MAP.strlstZoomLevel_miles-002
    PROPERTY(0x80000153)                // 1/4mi -> NAV.MAP.strlstZoomLevel_miles-003
    PROPERTY(0x80000154)                // 1/2mi -> NAV.MAP.strlstZoomLevel_miles-004
    PROPERTY(0x80000155)                // 1mi -> NAV.MAP.strlstZoomLevel_miles-005
    PROPERTY(0x80000156)                // 2.5mi -> NAV.MAP.strlstZoomLevel_miles-006
    PROPERTY(0x80000157)                // 5mi -> NAV.MAP.strlstZoomLevel_miles-007
    PROPERTY(0x80000158)                // 10mi -> NAV.MAP.strlstZoomLevel_miles-008
    PROPERTY(0x80000159)                // 25mi -> NAV.MAP.strlstZoomLevel_miles-009
    PROPERTY(0x8000015a)                // 50mi -> NAV.MAP.strlstZoomLevel_miles-010
    PROPERTY(0x8000015b)                // 100mi -> NAV.MAP.strlstZoomLevel_miles-011
    PROPERTY(0x8000015c)                // 250mi -> NAV.MAP.strlstZoomLevel_miles-012
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(textColorArray_168, 4)
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(NAV_MAP_strlstZoomLevel_meter, 13)
    PROPERTY(0x80000143)                // 50m -> NAV.MAP.strlstZoomLevel_meter-000
    PROPERTY(0x80000144)                // 100m -> NAV.MAP.strlstZoomLevel_meter-001
    PROPERTY(0x80000145)                // 200m -> NAV.MAP.strlstZoomLevel_meter-002
    PROPERTY(0x80000146)                // 500m -> NAV.MAP.strlstZoomLevel_meter-003
    PROPERTY(0x80000147)                // 1km -> NAV.MAP.strlstZoomLevel_meter-004
    PROPERTY(0x80000148)                // 2km -> NAV.MAP.strlstZoomLevel_meter-005
    PROPERTY(0x80000149)                // 5km -> NAV.MAP.strlstZoomLevel_meter-006
    PROPERTY(0x8000014a)                // 10km -> NAV.MAP.strlstZoomLevel_meter-007
    PROPERTY(0x8000014b)                // 20km -> NAV.MAP.strlstZoomLevel_meter-008
    PROPERTY(0x8000014c)                // 50km -> NAV.MAP.strlstZoomLevel_meter-009
    PROPERTY(0x8000014d)                // 100km -> NAV.MAP.strlstZoomLevel_meter-010
    PROPERTY(0x8000014e)                // 200km -> NAV.MAP.strlstZoomLevel_meter-011
    PROPERTY(0x8000014f)                // 500km -> NAV.MAP.strlstZoomLevel_meter-012
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_169, 13)
    PROPERTY(0x20000094)                // 800x480\HMINissanResources\HMI\map\map_yardstick_yard_61x6.png
    PROPERTY(0x20000094)                // 800x480\HMINissanResources\HMI\map\map_yardstick_yard_61x6.png
    PROPERTY(0x20000094)                // 800x480\HMINissanResources\HMI\map\map_yardstick_yard_61x6.png
    PROPERTY(0x20000094)                // 800x480\HMINissanResources\HMI\map\map_yardstick_yard_61x6.png
    PROPERTY(0x20000095)                // 800x480\HMINissanResources\HMI\map\map_yardstick_mile_61x6.png
    PROPERTY(0x20000095)                // 800x480\HMINissanResources\HMI\map\map_yardstick_mile_61x6.png
    PROPERTY(0x20000095)                // 800x480\HMINissanResources\HMI\map\map_yardstick_mile_61x6.png
    PROPERTY(0x20000095)                // 800x480\HMINissanResources\HMI\map\map_yardstick_mile_61x6.png
    PROPERTY(0x20000095)                // 800x480\HMINissanResources\HMI\map\map_yardstick_mile_61x6.png
    PROPERTY(0x20000095)                // 800x480\HMINissanResources\HMI\map\map_yardstick_mile_61x6.png
    PROPERTY(0x20000095)                // 800x480\HMINissanResources\HMI\map\map_yardstick_mile_61x6.png
    PROPERTY(0x20000095)                // 800x480\HMINissanResources\HMI\map\map_yardstick_mile_61x6.png
    PROPERTY(0x20000095)                // 800x480\HMINissanResources\HMI\map\map_yardstick_mile_61x6.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_188, 9)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000009c)                // 800x480\HMINissanResources\HMI\scrollbar\sb_btn_up_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000009d)                // 800x480\HMINissanResources\HMI\scrollbar\sb_btn_up_e.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000009e)                // 800x480\HMINissanResources\HMI\scrollbar\sb_btn_up_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_189, 9)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000009f)                // 800x480\HMINissanResources\HMI\scrollbar\sb_btn_dwn_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200000a0)                // 800x480\HMINissanResources\HMI\scrollbar\sb_btn_dwn_e.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200000a1)                // 800x480\HMINissanResources\HMI\scrollbar\sb_btn_dwn_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_196, 7)
    PROPERTY(0x200000a3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_dest_e.png
    PROPERTY(0x200000a4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_dest_f.png
    PROPERTY(0x200000a5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_dest_d.png
    PROPERTY(0x200000a5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_dest_d.png
    PROPERTY(0x200000a3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_dest_e.png
    PROPERTY(0x200000a4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_dest_f.png
    PROPERTY(0x200000a6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_dest_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_197, 9)
    PROPERTY(0x200000a7)                // 800x480\HMINissanResources\HMI\button\btn_6btn_array_e.png
    PROPERTY(0x200000a8)                // 800x480\HMINissanResources\HMI\button\btn_6btn_array_e_f.png
    PROPERTY(0x200000a9)                // 800x480\HMINissanResources\HMI\button\btn_6btn_array_d.png
    PROPERTY(0x200000a9)                // 800x480\HMINissanResources\HMI\button\btn_6btn_array_d.png
    PROPERTY(0x200000a7)                // 800x480\HMINissanResources\HMI\button\btn_6btn_array_e.png
    PROPERTY(0x200000a8)                // 800x480\HMINissanResources\HMI\button\btn_6btn_array_e_f.png
    PROPERTY(0x200000aa)                // 800x480\HMINissanResources\HMI\button\btn_6btn_array_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_199, 3)
    PROPERTY(0xe0025015)                // Display1: 37, Display2: 21
    PROPERTY(0xe001b00f)                // Display1: 27, Display2: 15
    PROPERTY(0xe003e023)                // Display1: 62, Display2: 35
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_200, 7)
    PROPERTY(0x200000ab)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchalongroute_e.png
    PROPERTY(0x200000ac)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchalongroute_f.png
    PROPERTY(0x200000ad)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchalongroute_d.png
    PROPERTY(0x200000ad)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchalongroute_d.png
    PROPERTY(0x200000ab)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchalongroute_e.png
    PROPERTY(0x200000ac)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchalongroute_f.png
    PROPERTY(0x200000ae)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchalongroute_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_202, 7)
    PROPERTY(0x200000af)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_traffic_settings_e.png
    PROPERTY(0x200000b0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_traffic_settings_f.png
    PROPERTY(0x200000b1)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_traffic_settings_d.png
    PROPERTY(0x200000b1)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_traffic_settings_d.png
    PROPERTY(0x200000af)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_traffic_settings_e.png
    PROPERTY(0x200000b0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_traffic_settings_f.png
    PROPERTY(0x200000b2)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_traffic_settings_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_205, 7)
    PROPERTY(0x200000b3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cancel_route_e.png
    PROPERTY(0x200000b4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cancel_route_f.png
    PROPERTY(0x200000b5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cancel_route_d.png
    PROPERTY(0x200000b5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cancel_route_d.png
    PROPERTY(0x200000b3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cancel_route_e.png
    PROPERTY(0x200000b4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cancel_route_f.png
    PROPERTY(0x200000b6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cancel_route_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_207, 7)
    PROPERTY(0x200000b7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_route_e.png
    PROPERTY(0x200000b8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_route_f.png
    PROPERTY(0x200000b9)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_route_d.png
    PROPERTY(0x200000b9)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_route_d.png
    PROPERTY(0x200000b7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_route_e.png
    PROPERTY(0x200000b8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_route_f.png
    PROPERTY(0x200000ba)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_route_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_209, 7)
    PROPERTY(0x200000bb)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nextpage_e.png
    PROPERTY(0x200000bc)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nextpage_f.png
    PROPERTY(0x200000bd)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nextpage_d.png
    PROPERTY(0x200000bd)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nextpage_d.png
    PROPERTY(0x200000bb)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nextpage_e.png
    PROPERTY(0x200000bc)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nextpage_f.png
    PROPERTY(0x200000be)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nextpage_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_221, 7)
    PROPERTY(0x200000bf)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_routemap_e.png
    PROPERTY(0x200000c0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_routemap_f.png
    PROPERTY(0x200000c1)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_routemap_d.png
    PROPERTY(0x200000c1)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_routemap_d.png
    PROPERTY(0x200000bf)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_routemap_e.png
    PROPERTY(0x200000c0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_routemap_f.png
    PROPERTY(0x200000c2)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_routemap_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_224, 7)
    PROPERTY(0x200000c3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_waypoints_e.png
    PROPERTY(0x200000c4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_waypoints_f.png
    PROPERTY(0x200000c5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_waypoints_d.png
    PROPERTY(0x200000c5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_waypoints_d.png
    PROPERTY(0x200000c3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_waypoints_e.png
    PROPERTY(0x200000c4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_waypoints_f.png
    PROPERTY(0x200000c6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_waypoints_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_227, 7)
    PROPERTY(0x200000c7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_position_e.png
    PROPERTY(0x200000c8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_position_f.png
    PROPERTY(0x200000c9)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_position_d.png
    PROPERTY(0x200000c9)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_position_d.png
    PROPERTY(0x200000c7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_position_e.png
    PROPERTY(0x200000c8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_position_f.png
    PROPERTY(0x200000ca)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_position_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_230, 7)
    PROPERTY(0x200000cb)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_options_e.png
    PROPERTY(0x200000cc)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_options_f.png
    PROPERTY(0x200000cd)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_options_d.png
    PROPERTY(0x200000cd)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_options_d.png
    PROPERTY(0x200000cb)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_options_e.png
    PROPERTY(0x200000cc)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_options_f.png
    PROPERTY(0x200000ce)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_options_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_233, 7)
    PROPERTY(0x200000cf)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nav_settings_e.png
    PROPERTY(0x200000d0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nav_settings_f.png
    PROPERTY(0x200000d1)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nav_settings_d.png
    PROPERTY(0x200000d1)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nav_settings_d.png
    PROPERTY(0x200000cf)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nav_settings_e.png
    PROPERTY(0x200000d0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nav_settings_f.png
    PROPERTY(0x200000d2)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nav_settings_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_236, 7)
    PROPERTY(0x200000d3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prevpage_e.png
    PROPERTY(0x200000d4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prevpage_f.png
    PROPERTY(0x200000d5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prevpage_d.png
    PROPERTY(0x200000d5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prevpage_d.png
    PROPERTY(0x200000d3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prevpage_e.png
    PROPERTY(0x200000d4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prevpage_f.png
    PROPERTY(0x200000d6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prevpage_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_254, 7)
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TopOffset, 6)
    PROPERTY(0xe0000000)                // Display1: 0, Display2: 0
    PROPERTY(0xe003f024)                // Display1: 63, Display2: 36
    PROPERTY(0xe007e048)                // Display1: 126, Display2: 72
    PROPERTY(0xe00bd06c)                // Display1: 189, Display2: 108
    PROPERTY(0xe00fc090)                // Display1: 252, Display2: 144
    PROPERTY(0xe013b0b4)                // Display1: 315, Display2: 180
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_268, 9)
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000db)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_p.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_270, 1)
    PROPERTY(0xe0024014)                // Display1: 36, Display2: 20
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_314, 9)
    PROPERTY(0x200000dc)                // 800x480\HMINissanResources\HMI\button\btn_5btn_row_e.png
    PROPERTY(0x200000dd)                // 800x480\HMINissanResources\HMI\button\btn_5btn_row_e_f.png
    PROPERTY(0x200000de)                // 800x480\HMINissanResources\HMI\button\btn_5btn_row_d.png
    PROPERTY(0x200000de)                // 800x480\HMINissanResources\HMI\button\btn_5btn_row_d.png
    PROPERTY(0x200000dc)                // 800x480\HMINissanResources\HMI\button\btn_5btn_row_e.png
    PROPERTY(0x200000dd)                // 800x480\HMINissanResources\HMI\button\btn_5btn_row_e_f.png
    PROPERTY(0x200000df)                // 800x480\HMINissanResources\HMI\button\btn_5btn_row_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R0, 4)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R1, 6)
    PROPERTY(0x200000e0)                // 800x480\HMINissanResources\HMI\listicon_16px\20E0_e.png
    PROPERTY(0x200000e0)                // 800x480\HMINissanResources\HMI\listicon_16px\20E0_e.png
    PROPERTY(0x200000e1)                // 800x480\HMINissanResources\HMI\listicon_16px\20E0_f.png
    PROPERTY(0x200000e2)                // 800x480\HMINissanResources\HMI\listicon_16px\20E0_p.png
    PROPERTY(0x200000e3)                // 800x480\HMINissanResources\HMI\listicon_16px\20E0_a.png
    PROPERTY(0x200000e4)                // 800x480\HMINissanResources\HMI\listicon_16px\20E0_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R6, 6)
    PROPERTY(0x200000e5)                // 800x480\HMINissanResources\HMI\listicon_16px\20E1_e.png
    PROPERTY(0x200000e5)                // 800x480\HMINissanResources\HMI\listicon_16px\20E1_e.png
    PROPERTY(0x200000e6)                // 800x480\HMINissanResources\HMI\listicon_16px\20E1_f.png
    PROPERTY(0x200000e7)                // 800x480\HMINissanResources\HMI\listicon_16px\20E1_p.png
    PROPERTY(0x200000e8)                // 800x480\HMINissanResources\HMI\listicon_16px\20E1_a.png
    PROPERTY(0x200000e9)                // 800x480\HMINissanResources\HMI\listicon_16px\20E1_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R11, 6)
    PROPERTY(0x200000ea)                // 800x480\HMINissanResources\HMI\listicon_16px\20E2_e.png
    PROPERTY(0x200000ea)                // 800x480\HMINissanResources\HMI\listicon_16px\20E2_e.png
    PROPERTY(0x200000eb)                // 800x480\HMINissanResources\HMI\listicon_16px\20E2_f.png
    PROPERTY(0x200000ec)                // 800x480\HMINissanResources\HMI\listicon_16px\20E2_p.png
    PROPERTY(0x200000ed)                // 800x480\HMINissanResources\HMI\listicon_16px\20E2_a.png
    PROPERTY(0x200000ee)                // 800x480\HMINissanResources\HMI\listicon_16px\20E2_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R16, 6)
    PROPERTY(0x200000ef)                // 800x480\HMINissanResources\HMI\listicon_16px\20E3_e.png
    PROPERTY(0x200000ef)                // 800x480\HMINissanResources\HMI\listicon_16px\20E3_e.png
    PROPERTY(0x200000f0)                // 800x480\HMINissanResources\HMI\listicon_16px\20E3_f.png
    PROPERTY(0x200000f1)                // 800x480\HMINissanResources\HMI\listicon_16px\20E3_p.png
    PROPERTY(0x200000f2)                // 800x480\HMINissanResources\HMI\listicon_16px\20E3_a.png
    PROPERTY(0x200000f3)                // 800x480\HMINissanResources\HMI\listicon_16px\20E3_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R21, 6)
    PROPERTY(0x200000f4)                // 800x480\HMINissanResources\HMI\listicon_16px\20E4_e.png
    PROPERTY(0x200000f4)                // 800x480\HMINissanResources\HMI\listicon_16px\20E4_e.png
    PROPERTY(0x200000f5)                // 800x480\HMINissanResources\HMI\listicon_16px\20E4_f.png
    PROPERTY(0x200000f6)                // 800x480\HMINissanResources\HMI\listicon_16px\20E4_p.png
    PROPERTY(0x200000f7)                // 800x480\HMINissanResources\HMI\listicon_16px\20E4_a.png
    PROPERTY(0x200000f8)                // 800x480\HMINissanResources\HMI\listicon_16px\20E4_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R26, 6)
    PROPERTY(0x200000f9)                // 800x480\HMINissanResources\HMI\listicon_16px\20E5_e.png
    PROPERTY(0x200000f9)                // 800x480\HMINissanResources\HMI\listicon_16px\20E5_e.png
    PROPERTY(0x200000fa)                // 800x480\HMINissanResources\HMI\listicon_16px\20E5_f.png
    PROPERTY(0x200000fb)                // 800x480\HMINissanResources\HMI\listicon_16px\20E5_p.png
    PROPERTY(0x200000fc)                // 800x480\HMINissanResources\HMI\listicon_16px\20E5_a.png
    PROPERTY(0x200000fd)                // 800x480\HMINissanResources\HMI\listicon_16px\20E5_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R31, 6)
    PROPERTY(0x200000fe)                // 800x480\HMINissanResources\HMI\listicon_16px\20E6_e.png
    PROPERTY(0x200000fe)                // 800x480\HMINissanResources\HMI\listicon_16px\20E6_e.png
    PROPERTY(0x200000ff)                // 800x480\HMINissanResources\HMI\listicon_16px\20E6_f.png
    PROPERTY(0x20000100)                // 800x480\HMINissanResources\HMI\listicon_16px\20E6_p.png
    PROPERTY(0x20000101)                // 800x480\HMINissanResources\HMI\listicon_16px\20E6_a.png
    PROPERTY(0x20000102)                // 800x480\HMINissanResources\HMI\listicon_16px\20E6_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R36, 6)
    PROPERTY(0x20000103)                // 800x480\HMINissanResources\HMI\listicon_16px\20E7_e.png
    PROPERTY(0x20000103)                // 800x480\HMINissanResources\HMI\listicon_16px\20E7_e.png
    PROPERTY(0x20000104)                // 800x480\HMINissanResources\HMI\listicon_16px\20E7_f.png
    PROPERTY(0x20000105)                // 800x480\HMINissanResources\HMI\listicon_16px\20E7_p.png
    PROPERTY(0x20000106)                // 800x480\HMINissanResources\HMI\listicon_16px\20E7_a.png
    PROPERTY(0x20000107)                // 800x480\HMINissanResources\HMI\listicon_16px\20E7_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_TDARRAY(ImagePaths, 41)
    PROPERTY_ARRAY_ROW(ImagePaths_R0)
    PROPERTY_ARRAY_ROW(ImagePaths_R1)
    PROPERTY_ARRAY_ROW(ImagePaths_R1)
    PROPERTY_ARRAY_ROW(ImagePaths_R1)
    PROPERTY_ARRAY_ROW(ImagePaths_R1)
    PROPERTY_ARRAY_ROW(ImagePaths_R1)
    PROPERTY_ARRAY_ROW(ImagePaths_R6)
    PROPERTY_ARRAY_ROW(ImagePaths_R6)
    PROPERTY_ARRAY_ROW(ImagePaths_R6)
    PROPERTY_ARRAY_ROW(ImagePaths_R6)
    PROPERTY_ARRAY_ROW(ImagePaths_R6)
    PROPERTY_ARRAY_ROW(ImagePaths_R11)
    PROPERTY_ARRAY_ROW(ImagePaths_R11)
    PROPERTY_ARRAY_ROW(ImagePaths_R11)
    PROPERTY_ARRAY_ROW(ImagePaths_R11)
    PROPERTY_ARRAY_ROW(ImagePaths_R11)
    PROPERTY_ARRAY_ROW(ImagePaths_R16)
    PROPERTY_ARRAY_ROW(ImagePaths_R16)
    PROPERTY_ARRAY_ROW(ImagePaths_R16)
    PROPERTY_ARRAY_ROW(ImagePaths_R16)
    PROPERTY_ARRAY_ROW(ImagePaths_R16)
    PROPERTY_ARRAY_ROW(ImagePaths_R21)
    PROPERTY_ARRAY_ROW(ImagePaths_R21)
    PROPERTY_ARRAY_ROW(ImagePaths_R21)
    PROPERTY_ARRAY_ROW(ImagePaths_R21)
    PROPERTY_ARRAY_ROW(ImagePaths_R21)
    PROPERTY_ARRAY_ROW(ImagePaths_R26)
    PROPERTY_ARRAY_ROW(ImagePaths_R26)
    PROPERTY_ARRAY_ROW(ImagePaths_R26)
    PROPERTY_ARRAY_ROW(ImagePaths_R26)
    PROPERTY_ARRAY_ROW(ImagePaths_R26)
    PROPERTY_ARRAY_ROW(ImagePaths_R31)
    PROPERTY_ARRAY_ROW(ImagePaths_R31)
    PROPERTY_ARRAY_ROW(ImagePaths_R31)
    PROPERTY_ARRAY_ROW(ImagePaths_R31)
    PROPERTY_ARRAY_ROW(ImagePaths_R31)
    PROPERTY_ARRAY_ROW(ImagePaths_R36)
    PROPERTY_ARRAY_ROW(ImagePaths_R36)
    PROPERTY_ARRAY_ROW(ImagePaths_R36)
    PROPERTY_ARRAY_ROW(ImagePaths_R36)
    PROPERTY_ARRAY_ROW(ImagePaths_R36)
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R1_322, 6)
    PROPERTY(0x20000108)                // 800x480\HMINissanResources\HMI\listicon_16px\20E8_e.png
    PROPERTY(0x20000108)                // 800x480\HMINissanResources\HMI\listicon_16px\20E8_e.png
    PROPERTY(0x20000109)                // 800x480\HMINissanResources\HMI\listicon_16px\20E8_f.png
    PROPERTY(0x2000010a)                // 800x480\HMINissanResources\HMI\listicon_16px\20E8_p.png
    PROPERTY(0x2000010b)                // 800x480\HMINissanResources\HMI\listicon_16px\20E8_a.png
    PROPERTY(0x2000010c)                // 800x480\HMINissanResources\HMI\listicon_16px\20E8_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R6_323, 6)
    PROPERTY(0x2000010d)                // 800x480\HMINissanResources\HMI\listicon_16px\20E9_e.png
    PROPERTY(0x2000010d)                // 800x480\HMINissanResources\HMI\listicon_16px\20E9_e.png
    PROPERTY(0x2000010e)                // 800x480\HMINissanResources\HMI\listicon_16px\20E9_f.png
    PROPERTY(0x2000010f)                // 800x480\HMINissanResources\HMI\listicon_16px\20E9_p.png
    PROPERTY(0x20000110)                // 800x480\HMINissanResources\HMI\listicon_16px\20E9_a.png
    PROPERTY(0x20000111)                // 800x480\HMINissanResources\HMI\listicon_16px\20E9_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R11_324, 6)
    PROPERTY(0x20000112)                // 800x480\HMINissanResources\HMI\listicon_16px\40EA_e.png
    PROPERTY(0x20000112)                // 800x480\HMINissanResources\HMI\listicon_16px\40EA_e.png
    PROPERTY(0x20000113)                // 800x480\HMINissanResources\HMI\listicon_16px\40EA_f.png
    PROPERTY(0x20000114)                // 800x480\HMINissanResources\HMI\listicon_16px\40EA_p.png
    PROPERTY(0x20000115)                // 800x480\HMINissanResources\HMI\listicon_16px\40EA_a.png
    PROPERTY(0x20000116)                // 800x480\HMINissanResources\HMI\listicon_16px\40EA_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R12, 6)
    PROPERTY(0x20000117)                // 800x480\HMINissanResources\HMI\listicon_16px\20EA_e.png
    PROPERTY(0x20000117)                // 800x480\HMINissanResources\HMI\listicon_16px\20EA_e.png
    PROPERTY(0x20000118)                // 800x480\HMINissanResources\HMI\listicon_16px\20EA_f.png
    PROPERTY(0x20000119)                // 800x480\HMINissanResources\HMI\listicon_16px\20EA_p.png
    PROPERTY(0x2000011a)                // 800x480\HMINissanResources\HMI\listicon_16px\20EA_a.png
    PROPERTY(0x2000011b)                // 800x480\HMINissanResources\HMI\listicon_16px\20EA_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R16_325, 6)
    PROPERTY(0x2000011c)                // 800x480\HMINissanResources\HMI\listicon_16px\20EB_e.png
    PROPERTY(0x2000011c)                // 800x480\HMINissanResources\HMI\listicon_16px\20EB_e.png
    PROPERTY(0x2000011d)                // 800x480\HMINissanResources\HMI\listicon_16px\20EB_f.png
    PROPERTY(0x2000011e)                // 800x480\HMINissanResources\HMI\listicon_16px\20EB_p.png
    PROPERTY(0x2000011f)                // 800x480\HMINissanResources\HMI\listicon_16px\20EB_a.png
    PROPERTY(0x20000120)                // 800x480\HMINissanResources\HMI\listicon_16px\20EB_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R21_326, 6)
    PROPERTY(0x20000121)                // 800x480\HMINissanResources\HMI\listicon_16px\20EC_e.png
    PROPERTY(0x20000121)                // 800x480\HMINissanResources\HMI\listicon_16px\20EC_e.png
    PROPERTY(0x20000122)                // 800x480\HMINissanResources\HMI\listicon_16px\20EC_f.png
    PROPERTY(0x20000123)                // 800x480\HMINissanResources\HMI\listicon_16px\20EC_p.png
    PROPERTY(0x20000124)                // 800x480\HMINissanResources\HMI\listicon_16px\20EC_a.png
    PROPERTY(0x20000125)                // 800x480\HMINissanResources\HMI\listicon_16px\20EC_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R26_327, 6)
    PROPERTY(0x20000126)                // 800x480\HMINissanResources\HMI\listicon_16px\20ED_e.png
    PROPERTY(0x20000126)                // 800x480\HMINissanResources\HMI\listicon_16px\20ED_e.png
    PROPERTY(0x20000127)                // 800x480\HMINissanResources\HMI\listicon_16px\20ED_f.png
    PROPERTY(0x20000128)                // 800x480\HMINissanResources\HMI\listicon_16px\20ED_p.png
    PROPERTY(0x20000129)                // 800x480\HMINissanResources\HMI\listicon_16px\20ED_a.png
    PROPERTY(0x2000012a)                // 800x480\HMINissanResources\HMI\listicon_16px\20ED_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R31_328, 6)
    PROPERTY(0x2000012b)                // 800x480\HMINissanResources\HMI\listicon_16px\20EE_e.png
    PROPERTY(0x2000012b)                // 800x480\HMINissanResources\HMI\listicon_16px\20EE_e.png
    PROPERTY(0x2000012c)                // 800x480\HMINissanResources\HMI\listicon_16px\20EE_f.png
    PROPERTY(0x2000012d)                // 800x480\HMINissanResources\HMI\listicon_16px\20EE_p.png
    PROPERTY(0x2000012e)                // 800x480\HMINissanResources\HMI\listicon_16px\20EE_a.png
    PROPERTY(0x2000012f)                // 800x480\HMINissanResources\HMI\listicon_16px\20EE_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R36_329, 6)
    PROPERTY(0x20000130)                // 800x480\HMINissanResources\HMI\listicon_16px\20EF_e.png
    PROPERTY(0x20000130)                // 800x480\HMINissanResources\HMI\listicon_16px\20EF_e.png
    PROPERTY(0x20000131)                // 800x480\HMINissanResources\HMI\listicon_16px\20EF_f.png
    PROPERTY(0x20000132)                // 800x480\HMINissanResources\HMI\listicon_16px\20EF_p.png
    PROPERTY(0x20000133)                // 800x480\HMINissanResources\HMI\listicon_16px\20EF_a.png
    PROPERTY(0x20000134)                // 800x480\HMINissanResources\HMI\listicon_16px\20EF_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R41, 6)
    PROPERTY(0x20000135)                // 800x480\HMINissanResources\HMI\listicon_16px\20F0_e.png
    PROPERTY(0x20000135)                // 800x480\HMINissanResources\HMI\listicon_16px\20F0_e.png
    PROPERTY(0x20000136)                // 800x480\HMINissanResources\HMI\listicon_16px\20F0_f.png
    PROPERTY(0x20000137)                // 800x480\HMINissanResources\HMI\listicon_16px\20F0_p.png
    PROPERTY(0x20000138)                // 800x480\HMINissanResources\HMI\listicon_16px\20F0_a.png
    PROPERTY(0x20000139)                // 800x480\HMINissanResources\HMI\listicon_16px\20F0_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R46, 6)
    PROPERTY(0x2000013a)                // 800x480\HMINissanResources\HMI\listicon_16px\20F1_e.png
    PROPERTY(0x2000013a)                // 800x480\HMINissanResources\HMI\listicon_16px\20F1_e.png
    PROPERTY(0x2000013b)                // 800x480\HMINissanResources\HMI\listicon_16px\20F1_f.png
    PROPERTY(0x2000013c)                // 800x480\HMINissanResources\HMI\listicon_16px\20F1_p.png
    PROPERTY(0x2000013d)                // 800x480\HMINissanResources\HMI\listicon_16px\20F1_a.png
    PROPERTY(0x2000013e)                // 800x480\HMINissanResources\HMI\listicon_16px\20F1_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R50, 6)
    PROPERTY(0x2000013f)                // 800x480\HMINissanResources\HMI\listicon_16px\50F1_e.png
    PROPERTY(0x2000013f)                // 800x480\HMINissanResources\HMI\listicon_16px\50F1_e.png
    PROPERTY(0x20000140)                // 800x480\HMINissanResources\HMI\listicon_16px\50F1_f.png
    PROPERTY(0x20000141)                // 800x480\HMINissanResources\HMI\listicon_16px\50F1_p.png
    PROPERTY(0x20000142)                // 800x480\HMINissanResources\HMI\listicon_16px\50F1_a.png
    PROPERTY(0x20000143)                // 800x480\HMINissanResources\HMI\listicon_16px\50F1_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R51, 6)
    PROPERTY(0x20000144)                // 800x480\HMINissanResources\HMI\listicon_16px\20F2_e.png
    PROPERTY(0x20000144)                // 800x480\HMINissanResources\HMI\listicon_16px\20F2_e.png
    PROPERTY(0x20000145)                // 800x480\HMINissanResources\HMI\listicon_16px\20F2_f.png
    PROPERTY(0x20000146)                // 800x480\HMINissanResources\HMI\listicon_16px\20F2_p.png
    PROPERTY(0x20000147)                // 800x480\HMINissanResources\HMI\listicon_16px\20F2_a.png
    PROPERTY(0x20000148)                // 800x480\HMINissanResources\HMI\listicon_16px\20F2_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R55, 6)
    PROPERTY(0x20000149)                // 800x480\HMINissanResources\HMI\listicon_16px\50F2_e.png
    PROPERTY(0x20000149)                // 800x480\HMINissanResources\HMI\listicon_16px\50F2_e.png
    PROPERTY(0x2000014a)                // 800x480\HMINissanResources\HMI\listicon_16px\50F2_f.png
    PROPERTY(0x2000014b)                // 800x480\HMINissanResources\HMI\listicon_16px\50F2_p.png
    PROPERTY(0x2000014c)                // 800x480\HMINissanResources\HMI\listicon_16px\50F2_a.png
    PROPERTY(0x2000014d)                // 800x480\HMINissanResources\HMI\listicon_16px\50F2_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R56, 6)
    PROPERTY(0x2000014e)                // 800x480\HMINissanResources\HMI\listicon_16px\20F3_e.png
    PROPERTY(0x2000014e)                // 800x480\HMINissanResources\HMI\listicon_16px\20F3_e.png
    PROPERTY(0x2000014f)                // 800x480\HMINissanResources\HMI\listicon_16px\20F3_f.png
    PROPERTY(0x20000150)                // 800x480\HMINissanResources\HMI\listicon_16px\20F3_p.png
    PROPERTY(0x20000151)                // 800x480\HMINissanResources\HMI\listicon_16px\20F3_a.png
    PROPERTY(0x20000152)                // 800x480\HMINissanResources\HMI\listicon_16px\20F3_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R61, 6)
    PROPERTY(0x20000153)                // 800x480\HMINissanResources\HMI\listicon_16px\20F4_e.png
    PROPERTY(0x20000153)                // 800x480\HMINissanResources\HMI\listicon_16px\20F4_e.png
    PROPERTY(0x20000154)                // 800x480\HMINissanResources\HMI\listicon_16px\20F4_f.png
    PROPERTY(0x20000155)                // 800x480\HMINissanResources\HMI\listicon_16px\20F4_p.png
    PROPERTY(0x20000156)                // 800x480\HMINissanResources\HMI\listicon_16px\20F4_a.png
    PROPERTY(0x20000157)                // 800x480\HMINissanResources\HMI\listicon_16px\20F4_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R66, 6)
    PROPERTY(0x20000158)                // 800x480\HMINissanResources\HMI\listicon_16px\20F5_e.png
    PROPERTY(0x20000158)                // 800x480\HMINissanResources\HMI\listicon_16px\20F5_e.png
    PROPERTY(0x20000159)                // 800x480\HMINissanResources\HMI\listicon_16px\20F5_f.png
    PROPERTY(0x2000015a)                // 800x480\HMINissanResources\HMI\listicon_16px\20F5_p.png
    PROPERTY(0x2000015b)                // 800x480\HMINissanResources\HMI\listicon_16px\20F5_a.png
    PROPERTY(0x2000015c)                // 800x480\HMINissanResources\HMI\listicon_16px\20F5_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R71, 6)
    PROPERTY(0x2000015d)                // 800x480\HMINissanResources\HMI\listicon_16px\20F6_e.png
    PROPERTY(0x2000015d)                // 800x480\HMINissanResources\HMI\listicon_16px\20F6_e.png
    PROPERTY(0x2000015e)                // 800x480\HMINissanResources\HMI\listicon_16px\20F6_f.png
    PROPERTY(0x2000015f)                // 800x480\HMINissanResources\HMI\listicon_16px\20F6_p.png
    PROPERTY(0x20000160)                // 800x480\HMINissanResources\HMI\listicon_16px\20F6_a.png
    PROPERTY(0x20000161)                // 800x480\HMINissanResources\HMI\listicon_16px\20F6_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R76, 6)
    PROPERTY(0x20000162)                // 800x480\HMINissanResources\HMI\listicon_16px\20F7_e.png
    PROPERTY(0x20000162)                // 800x480\HMINissanResources\HMI\listicon_16px\20F7_e.png
    PROPERTY(0x20000163)                // 800x480\HMINissanResources\HMI\listicon_16px\20F7_f.png
    PROPERTY(0x20000164)                // 800x480\HMINissanResources\HMI\listicon_16px\20F7_p.png
    PROPERTY(0x20000165)                // 800x480\HMINissanResources\HMI\listicon_16px\20F7_a.png
    PROPERTY(0x20000166)                // 800x480\HMINissanResources\HMI\listicon_16px\20F7_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R81, 6)
    PROPERTY(0x20000167)                // 800x480\HMINissanResources\HMI\listicon_16px\20F8_e.png
    PROPERTY(0x20000167)                // 800x480\HMINissanResources\HMI\listicon_16px\20F8_e.png
    PROPERTY(0x20000168)                // 800x480\HMINissanResources\HMI\listicon_16px\20F8_f.png
    PROPERTY(0x20000169)                // 800x480\HMINissanResources\HMI\listicon_16px\20F8_p.png
    PROPERTY(0x2000016a)                // 800x480\HMINissanResources\HMI\listicon_16px\20F8_a.png
    PROPERTY(0x2000016b)                // 800x480\HMINissanResources\HMI\listicon_16px\20F8_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R86, 6)
    PROPERTY(0x2000016c)                // 800x480\HMINissanResources\HMI\listicon_16px\20F9_e.png
    PROPERTY(0x2000016c)                // 800x480\HMINissanResources\HMI\listicon_16px\20F9_e.png
    PROPERTY(0x2000016d)                // 800x480\HMINissanResources\HMI\listicon_16px\20F9_f.png
    PROPERTY(0x2000016e)                // 800x480\HMINissanResources\HMI\listicon_16px\20F9_p.png
    PROPERTY(0x2000016f)                // 800x480\HMINissanResources\HMI\listicon_16px\20F9_a.png
    PROPERTY(0x20000170)                // 800x480\HMINissanResources\HMI\listicon_16px\20F9_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R91, 6)
    PROPERTY(0x20000171)                // 800x480\HMINissanResources\HMI\listicon_16px\20FA_e.png
    PROPERTY(0x20000171)                // 800x480\HMINissanResources\HMI\listicon_16px\20FA_e.png
    PROPERTY(0x20000172)                // 800x480\HMINissanResources\HMI\listicon_16px\20FA_f.png
    PROPERTY(0x20000173)                // 800x480\HMINissanResources\HMI\listicon_16px\20FA_p.png
    PROPERTY(0x20000174)                // 800x480\HMINissanResources\HMI\listicon_16px\20FA_a.png
    PROPERTY(0x20000175)                // 800x480\HMINissanResources\HMI\listicon_16px\20FA_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R96, 6)
    PROPERTY(0x20000176)                // 800x480\HMINissanResources\HMI\listicon_16px\20FB_e.png
    PROPERTY(0x20000176)                // 800x480\HMINissanResources\HMI\listicon_16px\20FB_e.png
    PROPERTY(0x20000177)                // 800x480\HMINissanResources\HMI\listicon_16px\20FB_f.png
    PROPERTY(0x20000178)                // 800x480\HMINissanResources\HMI\listicon_16px\20FB_p.png
    PROPERTY(0x20000179)                // 800x480\HMINissanResources\HMI\listicon_16px\20FB_a.png
    PROPERTY(0x2000017a)                // 800x480\HMINissanResources\HMI\listicon_16px\20FB_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R101, 6)
    PROPERTY(0x2000017b)                // 800x480\HMINissanResources\HMI\listicon_16px\20FC_e.png
    PROPERTY(0x2000017b)                // 800x480\HMINissanResources\HMI\listicon_16px\20FC_e.png
    PROPERTY(0x2000017c)                // 800x480\HMINissanResources\HMI\listicon_16px\20FC_f.png
    PROPERTY(0x2000017d)                // 800x480\HMINissanResources\HMI\listicon_16px\20FC_p.png
    PROPERTY(0x2000017e)                // 800x480\HMINissanResources\HMI\listicon_16px\20FC_a.png
    PROPERTY(0x2000017f)                // 800x480\HMINissanResources\HMI\listicon_16px\20FC_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R106, 6)
    PROPERTY(0x20000180)                // 800x480\HMINissanResources\HMI\listicon_16px\20FD_e.png
    PROPERTY(0x20000180)                // 800x480\HMINissanResources\HMI\listicon_16px\20FD_e.png
    PROPERTY(0x20000181)                // 800x480\HMINissanResources\HMI\listicon_16px\20FD_f.png
    PROPERTY(0x20000182)                // 800x480\HMINissanResources\HMI\listicon_16px\20FD_p.png
    PROPERTY(0x20000183)                // 800x480\HMINissanResources\HMI\listicon_16px\20FD_a.png
    PROPERTY(0x20000184)                // 800x480\HMINissanResources\HMI\listicon_16px\20FD_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R111, 6)
    PROPERTY(0x20000185)                // 800x480\HMINissanResources\HMI\listicon_16px\20FE_e.png
    PROPERTY(0x20000185)                // 800x480\HMINissanResources\HMI\listicon_16px\20FE_e.png
    PROPERTY(0x20000186)                // 800x480\HMINissanResources\HMI\listicon_16px\20FE_f.png
    PROPERTY(0x20000187)                // 800x480\HMINissanResources\HMI\listicon_16px\20FE_p.png
    PROPERTY(0x20000188)                // 800x480\HMINissanResources\HMI\listicon_16px\20FE_a.png
    PROPERTY(0x20000189)                // 800x480\HMINissanResources\HMI\listicon_16px\20FE_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R116, 6)
    PROPERTY(0x2000018a)                // 800x480\HMINissanResources\HMI\listicon_16px\20FF_e.png
    PROPERTY(0x2000018a)                // 800x480\HMINissanResources\HMI\listicon_16px\20FF_e.png
    PROPERTY(0x2000018b)                // 800x480\HMINissanResources\HMI\listicon_16px\20FF_f.png
    PROPERTY(0x2000018c)                // 800x480\HMINissanResources\HMI\listicon_16px\20FF_p.png
    PROPERTY(0x2000018d)                // 800x480\HMINissanResources\HMI\listicon_16px\20FF_a.png
    PROPERTY(0x2000018e)                // 800x480\HMINissanResources\HMI\listicon_16px\20FF_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R121, 6)
    PROPERTY(0x2000018f)                // 800x480\HMINissanResources\HMI\listicon_16px\2100_e.png
    PROPERTY(0x2000018f)                // 800x480\HMINissanResources\HMI\listicon_16px\2100_e.png
    PROPERTY(0x20000190)                // 800x480\HMINissanResources\HMI\listicon_16px\2100_f.png
    PROPERTY(0x20000191)                // 800x480\HMINissanResources\HMI\listicon_16px\2100_p.png
    PROPERTY(0x20000192)                // 800x480\HMINissanResources\HMI\listicon_16px\2100_a.png
    PROPERTY(0x20000193)                // 800x480\HMINissanResources\HMI\listicon_16px\2100_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R126, 6)
    PROPERTY(0x20000194)                // 800x480\HMINissanResources\HMI\listicon_16px\20A8_e.png
    PROPERTY(0x20000194)                // 800x480\HMINissanResources\HMI\listicon_16px\20A8_e.png
    PROPERTY(0x20000195)                // 800x480\HMINissanResources\HMI\listicon_16px\20A8_f.png
    PROPERTY(0x20000196)                // 800x480\HMINissanResources\HMI\listicon_16px\20A8_p.png
    PROPERTY(0x20000197)                // 800x480\HMINissanResources\HMI\listicon_16px\20A8_a.png
    PROPERTY(0x20000198)                // 800x480\HMINissanResources\HMI\listicon_16px\20A8_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R131, 6)
    PROPERTY(0x20000199)                // 800x480\HMINissanResources\HMI\listicon_16px\2102_e.png
    PROPERTY(0x20000199)                // 800x480\HMINissanResources\HMI\listicon_16px\2102_e.png
    PROPERTY(0x2000019a)                // 800x480\HMINissanResources\HMI\listicon_16px\2102_f.png
    PROPERTY(0x2000019b)                // 800x480\HMINissanResources\HMI\listicon_16px\2102_p.png
    PROPERTY(0x2000019c)                // 800x480\HMINissanResources\HMI\listicon_16px\2102_a.png
    PROPERTY(0x2000019d)                // 800x480\HMINissanResources\HMI\listicon_16px\2102_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R136, 6)
    PROPERTY(0x2000019e)                // 800x480\HMINissanResources\HMI\listicon_16px\2103_e.png
    PROPERTY(0x2000019e)                // 800x480\HMINissanResources\HMI\listicon_16px\2103_e.png
    PROPERTY(0x2000019f)                // 800x480\HMINissanResources\HMI\listicon_16px\2103_f.png
    PROPERTY(0x200001a0)                // 800x480\HMINissanResources\HMI\listicon_16px\2103_p.png
    PROPERTY(0x200001a1)                // 800x480\HMINissanResources\HMI\listicon_16px\2103_a.png
    PROPERTY(0x200001a2)                // 800x480\HMINissanResources\HMI\listicon_16px\2103_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R141, 6)
    PROPERTY(0x200001a3)                // 800x480\HMINissanResources\HMI\listicon_16px\2104_e.png
    PROPERTY(0x200001a3)                // 800x480\HMINissanResources\HMI\listicon_16px\2104_e.png
    PROPERTY(0x200001a4)                // 800x480\HMINissanResources\HMI\listicon_16px\2104_f.png
    PROPERTY(0x200001a5)                // 800x480\HMINissanResources\HMI\listicon_16px\2104_p.png
    PROPERTY(0x200001a6)                // 800x480\HMINissanResources\HMI\listicon_16px\2104_a.png
    PROPERTY(0x200001a7)                // 800x480\HMINissanResources\HMI\listicon_16px\2104_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R146, 6)
    PROPERTY(0x200001a8)                // 800x480\HMINissanResources\HMI\listicon_16px\2105_e.png
    PROPERTY(0x200001a8)                // 800x480\HMINissanResources\HMI\listicon_16px\2105_e.png
    PROPERTY(0x200001a9)                // 800x480\HMINissanResources\HMI\listicon_16px\2105_f.png
    PROPERTY(0x200001aa)                // 800x480\HMINissanResources\HMI\listicon_16px\2105_p.png
    PROPERTY(0x200001ab)                // 800x480\HMINissanResources\HMI\listicon_16px\2105_a.png
    PROPERTY(0x200001ac)                // 800x480\HMINissanResources\HMI\listicon_16px\2105_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R151, 6)
    PROPERTY(0x200001ad)                // 800x480\HMINissanResources\HMI\listicon_16px\2106_e.png
    PROPERTY(0x200001ad)                // 800x480\HMINissanResources\HMI\listicon_16px\2106_e.png
    PROPERTY(0x200001ae)                // 800x480\HMINissanResources\HMI\listicon_16px\2106_f.png
    PROPERTY(0x200001af)                // 800x480\HMINissanResources\HMI\listicon_16px\2106_p.png
    PROPERTY(0x200001b0)                // 800x480\HMINissanResources\HMI\listicon_16px\2106_a.png
    PROPERTY(0x200001b1)                // 800x480\HMINissanResources\HMI\listicon_16px\2106_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R153, 6)
    PROPERTY(0x200001b2)                // 800x480\HMINissanResources\HMI\listicon_16px\3106_e.png
    PROPERTY(0x200001b2)                // 800x480\HMINissanResources\HMI\listicon_16px\3106_e.png
    PROPERTY(0x200001b3)                // 800x480\HMINissanResources\HMI\listicon_16px\3106_f.png
    PROPERTY(0x200001b4)                // 800x480\HMINissanResources\HMI\listicon_16px\3106_p.png
    PROPERTY(0x200001b5)                // 800x480\HMINissanResources\HMI\listicon_16px\3106_a.png
    PROPERTY(0x200001b6)                // 800x480\HMINissanResources\HMI\listicon_16px\3106_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R156, 6)
    PROPERTY(0x200001b7)                // 800x480\HMINissanResources\HMI\listicon_16px\2107_e.png
    PROPERTY(0x200001b7)                // 800x480\HMINissanResources\HMI\listicon_16px\2107_e.png
    PROPERTY(0x200001b8)                // 800x480\HMINissanResources\HMI\listicon_16px\2107_f.png
    PROPERTY(0x200001b9)                // 800x480\HMINissanResources\HMI\listicon_16px\2107_p.png
    PROPERTY(0x200001ba)                // 800x480\HMINissanResources\HMI\listicon_16px\2107_a.png
    PROPERTY(0x200001bb)                // 800x480\HMINissanResources\HMI\listicon_16px\2107_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R161, 6)
    PROPERTY(0x200001bc)                // 800x480\HMINissanResources\HMI\listicon_16px\210C_e.png
    PROPERTY(0x200001bc)                // 800x480\HMINissanResources\HMI\listicon_16px\210C_e.png
    PROPERTY(0x200001bd)                // 800x480\HMINissanResources\HMI\listicon_16px\210C_f.png
    PROPERTY(0x200001be)                // 800x480\HMINissanResources\HMI\listicon_16px\210C_p.png
    PROPERTY(0x200001bf)                // 800x480\HMINissanResources\HMI\listicon_16px\210C_a.png
    PROPERTY(0x200001c0)                // 800x480\HMINissanResources\HMI\listicon_16px\210C_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R166, 6)
    PROPERTY(0x200001c1)                // 800x480\HMINissanResources\HMI\listicon_16px\210D_e.png
    PROPERTY(0x200001c1)                // 800x480\HMINissanResources\HMI\listicon_16px\210D_e.png
    PROPERTY(0x200001c2)                // 800x480\HMINissanResources\HMI\listicon_16px\210D_f.png
    PROPERTY(0x200001c3)                // 800x480\HMINissanResources\HMI\listicon_16px\210D_p.png
    PROPERTY(0x200001c4)                // 800x480\HMINissanResources\HMI\listicon_16px\210D_a.png
    PROPERTY(0x200001c5)                // 800x480\HMINissanResources\HMI\listicon_16px\210D_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R171, 6)
    PROPERTY(0x200001c6)                // 800x480\HMINissanResources\HMI\listicon_16px\210E_e.png
    PROPERTY(0x200001c6)                // 800x480\HMINissanResources\HMI\listicon_16px\210E_e.png
    PROPERTY(0x200001c7)                // 800x480\HMINissanResources\HMI\listicon_16px\210E_f.png
    PROPERTY(0x200001c8)                // 800x480\HMINissanResources\HMI\listicon_16px\210E_p.png
    PROPERTY(0x200001c9)                // 800x480\HMINissanResources\HMI\listicon_16px\210E_a.png
    PROPERTY(0x200001ca)                // 800x480\HMINissanResources\HMI\listicon_16px\210E_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R172, 6)
    PROPERTY(0x200001cb)                // 800x480\HMINissanResources\HMI\listicon_16px\50B1_e.png
    PROPERTY(0x200001cb)                // 800x480\HMINissanResources\HMI\listicon_16px\50B1_e.png
    PROPERTY(0x200001cc)                // 800x480\HMINissanResources\HMI\listicon_16px\50B1_f.png
    PROPERTY(0x200001cd)                // 800x480\HMINissanResources\HMI\listicon_16px\50B1_p.png
    PROPERTY(0x200001ce)                // 800x480\HMINissanResources\HMI\listicon_16px\50B1_a.png
    PROPERTY(0x200001cf)                // 800x480\HMINissanResources\HMI\listicon_16px\50B1_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R173, 6)
    PROPERTY(0x200001d0)                // 800x480\HMINissanResources\HMI\listicon_16px\30B1_e.png
    PROPERTY(0x200001d0)                // 800x480\HMINissanResources\HMI\listicon_16px\30B1_e.png
    PROPERTY(0x200001d1)                // 800x480\HMINissanResources\HMI\listicon_16px\30B1_f.png
    PROPERTY(0x200001d2)                // 800x480\HMINissanResources\HMI\listicon_16px\30B1_p.png
    PROPERTY(0x200001d3)                // 800x480\HMINissanResources\HMI\listicon_16px\30B1_a.png
    PROPERTY(0x200001d4)                // 800x480\HMINissanResources\HMI\listicon_16px\30B1_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R176, 6)
    PROPERTY(0x200001d5)                // 800x480\HMINissanResources\HMI\listicon_16px\210F_e.png
    PROPERTY(0x200001d5)                // 800x480\HMINissanResources\HMI\listicon_16px\210F_e.png
    PROPERTY(0x200001d6)                // 800x480\HMINissanResources\HMI\listicon_16px\210F_f.png
    PROPERTY(0x200001d7)                // 800x480\HMINissanResources\HMI\listicon_16px\210F_p.png
    PROPERTY(0x200001d8)                // 800x480\HMINissanResources\HMI\listicon_16px\210F_a.png
    PROPERTY(0x200001d9)                // 800x480\HMINissanResources\HMI\listicon_16px\210F_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R181, 6)
    PROPERTY(0x200001da)                // 800x480\HMINissanResources\HMI\listicon_16px\2110_e.png
    PROPERTY(0x200001da)                // 800x480\HMINissanResources\HMI\listicon_16px\2110_e.png
    PROPERTY(0x200001db)                // 800x480\HMINissanResources\HMI\listicon_16px\2110_f.png
    PROPERTY(0x200001dc)                // 800x480\HMINissanResources\HMI\listicon_16px\2110_p.png
    PROPERTY(0x200001dd)                // 800x480\HMINissanResources\HMI\listicon_16px\2110_a.png
    PROPERTY(0x200001de)                // 800x480\HMINissanResources\HMI\listicon_16px\2110_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R186, 6)
    PROPERTY(0x200001df)                // 800x480\HMINissanResources\HMI\listicon_16px\2111_e.png
    PROPERTY(0x200001df)                // 800x480\HMINissanResources\HMI\listicon_16px\2111_e.png
    PROPERTY(0x200001e0)                // 800x480\HMINissanResources\HMI\listicon_16px\2111_f.png
    PROPERTY(0x200001e1)                // 800x480\HMINissanResources\HMI\listicon_16px\2111_p.png
    PROPERTY(0x200001e2)                // 800x480\HMINissanResources\HMI\listicon_16px\2111_a.png
    PROPERTY(0x200001e3)                // 800x480\HMINissanResources\HMI\listicon_16px\2111_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R191, 6)
    PROPERTY(0x200001e4)                // 800x480\HMINissanResources\HMI\listicon_16px\2112_e.png
    PROPERTY(0x200001e4)                // 800x480\HMINissanResources\HMI\listicon_16px\2112_e.png
    PROPERTY(0x200001e5)                // 800x480\HMINissanResources\HMI\listicon_16px\2112_f.png
    PROPERTY(0x200001e6)                // 800x480\HMINissanResources\HMI\listicon_16px\2112_p.png
    PROPERTY(0x200001e7)                // 800x480\HMINissanResources\HMI\listicon_16px\2112_a.png
    PROPERTY(0x200001e8)                // 800x480\HMINissanResources\HMI\listicon_16px\2112_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R196, 6)
    PROPERTY(0x200001e9)                // 800x480\HMINissanResources\HMI\listicon_16px\2113_e.png
    PROPERTY(0x200001e9)                // 800x480\HMINissanResources\HMI\listicon_16px\2113_e.png
    PROPERTY(0x200001ea)                // 800x480\HMINissanResources\HMI\listicon_16px\2113_f.png
    PROPERTY(0x200001eb)                // 800x480\HMINissanResources\HMI\listicon_16px\2113_p.png
    PROPERTY(0x200001ec)                // 800x480\HMINissanResources\HMI\listicon_16px\2113_a.png
    PROPERTY(0x200001ed)                // 800x480\HMINissanResources\HMI\listicon_16px\2113_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R201, 6)
    PROPERTY(0x200001ee)                // 800x480\HMINissanResources\HMI\listicon_16px\2116_e.png
    PROPERTY(0x200001ee)                // 800x480\HMINissanResources\HMI\listicon_16px\2116_e.png
    PROPERTY(0x200001ef)                // 800x480\HMINissanResources\HMI\listicon_16px\2116_f.png
    PROPERTY(0x200001f0)                // 800x480\HMINissanResources\HMI\listicon_16px\2116_p.png
    PROPERTY(0x200001f1)                // 800x480\HMINissanResources\HMI\listicon_16px\2116_a.png
    PROPERTY(0x200001f2)                // 800x480\HMINissanResources\HMI\listicon_16px\2116_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R206, 6)
    PROPERTY(0x200001f3)                // 800x480\HMINissanResources\HMI\listicon_16px\2117_e.png
    PROPERTY(0x200001f3)                // 800x480\HMINissanResources\HMI\listicon_16px\2117_e.png
    PROPERTY(0x200001f4)                // 800x480\HMINissanResources\HMI\listicon_16px\2117_f.png
    PROPERTY(0x200001f5)                // 800x480\HMINissanResources\HMI\listicon_16px\2117_p.png
    PROPERTY(0x200001f6)                // 800x480\HMINissanResources\HMI\listicon_16px\2117_a.png
    PROPERTY(0x200001f7)                // 800x480\HMINissanResources\HMI\listicon_16px\2117_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R211, 6)
    PROPERTY(0x200001f8)                // 800x480\HMINissanResources\HMI\listicon_16px\2118_e.png
    PROPERTY(0x200001f8)                // 800x480\HMINissanResources\HMI\listicon_16px\2118_e.png
    PROPERTY(0x200001f9)                // 800x480\HMINissanResources\HMI\listicon_16px\2118_f.png
    PROPERTY(0x200001fa)                // 800x480\HMINissanResources\HMI\listicon_16px\2118_p.png
    PROPERTY(0x200001fb)                // 800x480\HMINissanResources\HMI\listicon_16px\2118_a.png
    PROPERTY(0x200001fc)                // 800x480\HMINissanResources\HMI\listicon_16px\2118_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R216, 6)
    PROPERTY(0x200001fd)                // 800x480\HMINissanResources\HMI\listicon_16px\2119_e.png
    PROPERTY(0x200001fd)                // 800x480\HMINissanResources\HMI\listicon_16px\2119_e.png
    PROPERTY(0x200001fe)                // 800x480\HMINissanResources\HMI\listicon_16px\2119_f.png
    PROPERTY(0x200001ff)                // 800x480\HMINissanResources\HMI\listicon_16px\2119_p.png
    PROPERTY(0x20000200)                // 800x480\HMINissanResources\HMI\listicon_16px\2119_a.png
    PROPERTY(0x20000201)                // 800x480\HMINissanResources\HMI\listicon_16px\2119_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R221, 6)
    PROPERTY(0x20000202)                // 800x480\HMINissanResources\HMI\listicon_16px\211A_e.png
    PROPERTY(0x20000202)                // 800x480\HMINissanResources\HMI\listicon_16px\211A_e.png
    PROPERTY(0x20000203)                // 800x480\HMINissanResources\HMI\listicon_16px\211A_f.png
    PROPERTY(0x20000204)                // 800x480\HMINissanResources\HMI\listicon_16px\211A_p.png
    PROPERTY(0x20000205)                // 800x480\HMINissanResources\HMI\listicon_16px\211A_a.png
    PROPERTY(0x20000206)                // 800x480\HMINissanResources\HMI\listicon_16px\211A_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R226, 6)
    PROPERTY(0x20000207)                // 800x480\HMINissanResources\HMI\listicon_16px\211B_e.png
    PROPERTY(0x20000207)                // 800x480\HMINissanResources\HMI\listicon_16px\211B_e.png
    PROPERTY(0x20000208)                // 800x480\HMINissanResources\HMI\listicon_16px\211B_f.png
    PROPERTY(0x20000209)                // 800x480\HMINissanResources\HMI\listicon_16px\211B_p.png
    PROPERTY(0x2000020a)                // 800x480\HMINissanResources\HMI\listicon_16px\211B_a.png
    PROPERTY(0x2000020b)                // 800x480\HMINissanResources\HMI\listicon_16px\211B_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R231, 6)
    PROPERTY(0x2000020c)                // 800x480\HMINissanResources\HMI\listicon_16px\211C_e.png
    PROPERTY(0x2000020c)                // 800x480\HMINissanResources\HMI\listicon_16px\211C_e.png
    PROPERTY(0x2000020d)                // 800x480\HMINissanResources\HMI\listicon_16px\211C_f.png
    PROPERTY(0x2000020e)                // 800x480\HMINissanResources\HMI\listicon_16px\211C_p.png
    PROPERTY(0x2000020f)                // 800x480\HMINissanResources\HMI\listicon_16px\211C_a.png
    PROPERTY(0x20000210)                // 800x480\HMINissanResources\HMI\listicon_16px\211C_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R241, 6)
    PROPERTY(0x20000211)                // 800x480\HMINissanResources\HMI\listicon_16px\211E_e.png
    PROPERTY(0x20000211)                // 800x480\HMINissanResources\HMI\listicon_16px\211E_e.png
    PROPERTY(0x20000212)                // 800x480\HMINissanResources\HMI\listicon_16px\211E_f.png
    PROPERTY(0x20000213)                // 800x480\HMINissanResources\HMI\listicon_16px\211E_p.png
    PROPERTY(0x20000214)                // 800x480\HMINissanResources\HMI\listicon_16px\211E_a.png
    PROPERTY(0x20000215)                // 800x480\HMINissanResources\HMI\listicon_16px\211E_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R246, 6)
    PROPERTY(0x20000216)                // 800x480\HMINissanResources\HMI\listicon_16px\211F_e.png
    PROPERTY(0x20000216)                // 800x480\HMINissanResources\HMI\listicon_16px\211F_e.png
    PROPERTY(0x20000217)                // 800x480\HMINissanResources\HMI\listicon_16px\211F_f.png
    PROPERTY(0x20000218)                // 800x480\HMINissanResources\HMI\listicon_16px\211F_p.png
    PROPERTY(0x20000219)                // 800x480\HMINissanResources\HMI\listicon_16px\211F_a.png
    PROPERTY(0x2000021a)                // 800x480\HMINissanResources\HMI\listicon_16px\211F_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R251, 6)
    PROPERTY(0x2000021b)                // 800x480\HMINissanResources\HMI\listicon_16px\2120_e.png
    PROPERTY(0x2000021b)                // 800x480\HMINissanResources\HMI\listicon_16px\2120_e.png
    PROPERTY(0x2000021c)                // 800x480\HMINissanResources\HMI\listicon_16px\2120_f.png
    PROPERTY(0x2000021d)                // 800x480\HMINissanResources\HMI\listicon_16px\2120_p.png
    PROPERTY(0x2000021e)                // 800x480\HMINissanResources\HMI\listicon_16px\2120_a.png
    PROPERTY(0x2000021f)                // 800x480\HMINissanResources\HMI\listicon_16px\2120_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R256, 6)
    PROPERTY(0x20000220)                // 800x480\HMINissanResources\HMI\listicon_16px\2121_e.png
    PROPERTY(0x20000220)                // 800x480\HMINissanResources\HMI\listicon_16px\2121_e.png
    PROPERTY(0x20000221)                // 800x480\HMINissanResources\HMI\listicon_16px\2121_f.png
    PROPERTY(0x20000222)                // 800x480\HMINissanResources\HMI\listicon_16px\2121_p.png
    PROPERTY(0x20000223)                // 800x480\HMINissanResources\HMI\listicon_16px\2121_a.png
    PROPERTY(0x20000224)                // 800x480\HMINissanResources\HMI\listicon_16px\2121_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R261, 6)
    PROPERTY(0x20000225)                // 800x480\HMINissanResources\HMI\listicon_16px\2122_e.png
    PROPERTY(0x20000225)                // 800x480\HMINissanResources\HMI\listicon_16px\2122_e.png
    PROPERTY(0x20000226)                // 800x480\HMINissanResources\HMI\listicon_16px\2122_f.png
    PROPERTY(0x20000227)                // 800x480\HMINissanResources\HMI\listicon_16px\2122_p.png
    PROPERTY(0x20000228)                // 800x480\HMINissanResources\HMI\listicon_16px\2122_a.png
    PROPERTY(0x20000229)                // 800x480\HMINissanResources\HMI\listicon_16px\2122_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_TDARRAY(ImagePaths_330, 267)
    PROPERTY_ARRAY_ROW(ImagePaths_R0)
    PROPERTY_ARRAY_ROW(ImagePaths_R1_322)
    PROPERTY_ARRAY_ROW(ImagePaths_R1_322)
    PROPERTY_ARRAY_ROW(ImagePaths_R1_322)
    PROPERTY_ARRAY_ROW(ImagePaths_R1_322)
    PROPERTY_ARRAY_ROW(ImagePaths_R1_322)
    PROPERTY_ARRAY_ROW(ImagePaths_R6_323)
    PROPERTY_ARRAY_ROW(ImagePaths_R6_323)
    PROPERTY_ARRAY_ROW(ImagePaths_R6_323)
    PROPERTY_ARRAY_ROW(ImagePaths_R6_323)
    PROPERTY_ARRAY_ROW(ImagePaths_R6_323)
    PROPERTY_ARRAY_ROW(ImagePaths_R11_324)
    PROPERTY_ARRAY_ROW(ImagePaths_R12)
    PROPERTY_ARRAY_ROW(ImagePaths_R11_324)
    PROPERTY_ARRAY_ROW(ImagePaths_R12)
    PROPERTY_ARRAY_ROW(ImagePaths_R12)
    PROPERTY_ARRAY_ROW(ImagePaths_R16_325)
    PROPERTY_ARRAY_ROW(ImagePaths_R16_325)
    PROPERTY_ARRAY_ROW(ImagePaths_R16_325)
    PROPERTY_ARRAY_ROW(ImagePaths_R16_325)
    PROPERTY_ARRAY_ROW(ImagePaths_R16_325)
    PROPERTY_ARRAY_ROW(ImagePaths_R21_326)
    PROPERTY_ARRAY_ROW(ImagePaths_R21_326)
    PROPERTY_ARRAY_ROW(ImagePaths_R21_326)
    PROPERTY_ARRAY_ROW(ImagePaths_R21_326)
    PROPERTY_ARRAY_ROW(ImagePaths_R21_326)
    PROPERTY_ARRAY_ROW(ImagePaths_R26_327)
    PROPERTY_ARRAY_ROW(ImagePaths_R26_327)
    PROPERTY_ARRAY_ROW(ImagePaths_R26_327)
    PROPERTY_ARRAY_ROW(ImagePaths_R26_327)
    PROPERTY_ARRAY_ROW(ImagePaths_R26_327)
    PROPERTY_ARRAY_ROW(ImagePaths_R31_328)
    PROPERTY_ARRAY_ROW(ImagePaths_R31_328)
    PROPERTY_ARRAY_ROW(ImagePaths_R31_328)
    PROPERTY_ARRAY_ROW(ImagePaths_R31_328)
    PROPERTY_ARRAY_ROW(ImagePaths_R31_328)
    PROPERTY_ARRAY_ROW(ImagePaths_R36_329)
    PROPERTY_ARRAY_ROW(ImagePaths_R36_329)
    PROPERTY_ARRAY_ROW(ImagePaths_R36_329)
    PROPERTY_ARRAY_ROW(ImagePaths_R36_329)
    PROPERTY_ARRAY_ROW(ImagePaths_R36_329)
    PROPERTY_ARRAY_ROW(ImagePaths_R41)
    PROPERTY_ARRAY_ROW(ImagePaths_R41)
    PROPERTY_ARRAY_ROW(ImagePaths_R41)
    PROPERTY_ARRAY_ROW(ImagePaths_R41)
    PROPERTY_ARRAY_ROW(ImagePaths_R41)
    PROPERTY_ARRAY_ROW(ImagePaths_R46)
    PROPERTY_ARRAY_ROW(ImagePaths_R46)
    PROPERTY_ARRAY_ROW(ImagePaths_R46)
    PROPERTY_ARRAY_ROW(ImagePaths_R46)
    PROPERTY_ARRAY_ROW(ImagePaths_R50)
    PROPERTY_ARRAY_ROW(ImagePaths_R51)
    PROPERTY_ARRAY_ROW(ImagePaths_R51)
    PROPERTY_ARRAY_ROW(ImagePaths_R51)
    PROPERTY_ARRAY_ROW(ImagePaths_R51)
    PROPERTY_ARRAY_ROW(ImagePaths_R55)
    PROPERTY_ARRAY_ROW(ImagePaths_R56)
    PROPERTY_ARRAY_ROW(ImagePaths_R56)
    PROPERTY_ARRAY_ROW(ImagePaths_R56)
    PROPERTY_ARRAY_ROW(ImagePaths_R56)
    PROPERTY_ARRAY_ROW(ImagePaths_R56)
    PROPERTY_ARRAY_ROW(ImagePaths_R61)
    PROPERTY_ARRAY_ROW(ImagePaths_R61)
    PROPERTY_ARRAY_ROW(ImagePaths_R61)
    PROPERTY_ARRAY_ROW(ImagePaths_R61)
    PROPERTY_ARRAY_ROW(ImagePaths_R61)
    PROPERTY_ARRAY_ROW(ImagePaths_R66)
    PROPERTY_ARRAY_ROW(ImagePaths_R66)
    PROPERTY_ARRAY_ROW(ImagePaths_R66)
    PROPERTY_ARRAY_ROW(ImagePaths_R66)
    PROPERTY_ARRAY_ROW(ImagePaths_R66)
    PROPERTY_ARRAY_ROW(ImagePaths_R71)
    PROPERTY_ARRAY_ROW(ImagePaths_R71)
    PROPERTY_ARRAY_ROW(ImagePaths_R71)
    PROPERTY_ARRAY_ROW(ImagePaths_R71)
    PROPERTY_ARRAY_ROW(ImagePaths_R71)
    PROPERTY_ARRAY_ROW(ImagePaths_R76)
    PROPERTY_ARRAY_ROW(ImagePaths_R76)
    PROPERTY_ARRAY_ROW(ImagePaths_R76)
    PROPERTY_ARRAY_ROW(ImagePaths_R76)
    PROPERTY_ARRAY_ROW(ImagePaths_R76)
    PROPERTY_ARRAY_ROW(ImagePaths_R81)
    PROPERTY_ARRAY_ROW(ImagePaths_R81)
    PROPERTY_ARRAY_ROW(ImagePaths_R81)
    PROPERTY_ARRAY_ROW(ImagePaths_R81)
    PROPERTY_ARRAY_ROW(ImagePaths_R81)
    PROPERTY_ARRAY_ROW(ImagePaths_R86)
    PROPERTY_ARRAY_ROW(ImagePaths_R86)
    PROPERTY_ARRAY_ROW(ImagePaths_R86)
    PROPERTY_ARRAY_ROW(ImagePaths_R86)
    PROPERTY_ARRAY_ROW(ImagePaths_R86)
    PROPERTY_ARRAY_ROW(ImagePaths_R91)
    PROPERTY_ARRAY_ROW(ImagePaths_R91)
    PROPERTY_ARRAY_ROW(ImagePaths_R91)
    PROPERTY_ARRAY_ROW(ImagePaths_R91)
    PROPERTY_ARRAY_ROW(ImagePaths_R91)
    PROPERTY_ARRAY_ROW(ImagePaths_R96)
    PROPERTY_ARRAY_ROW(ImagePaths_R96)
    PROPERTY_ARRAY_ROW(ImagePaths_R96)
    PROPERTY_ARRAY_ROW(ImagePaths_R96)
    PROPERTY_ARRAY_ROW(ImagePaths_R96)
    PROPERTY_ARRAY_ROW(ImagePaths_R101)
    PROPERTY_ARRAY_ROW(ImagePaths_R101)
    PROPERTY_ARRAY_ROW(ImagePaths_R101)
    PROPERTY_ARRAY_ROW(ImagePaths_R101)
    PROPERTY_ARRAY_ROW(ImagePaths_R101)
    PROPERTY_ARRAY_ROW(ImagePaths_R106)
    PROPERTY_ARRAY_ROW(ImagePaths_R106)
    PROPERTY_ARRAY_ROW(ImagePaths_R106)
    PROPERTY_ARRAY_ROW(ImagePaths_R106)
    PROPERTY_ARRAY_ROW(ImagePaths_R106)
    PROPERTY_ARRAY_ROW(ImagePaths_R111)
    PROPERTY_ARRAY_ROW(ImagePaths_R111)
    PROPERTY_ARRAY_ROW(ImagePaths_R111)
    PROPERTY_ARRAY_ROW(ImagePaths_R111)
    PROPERTY_ARRAY_ROW(ImagePaths_R111)
    PROPERTY_ARRAY_ROW(ImagePaths_R116)
    PROPERTY_ARRAY_ROW(ImagePaths_R116)
    PROPERTY_ARRAY_ROW(ImagePaths_R116)
    PROPERTY_ARRAY_ROW(ImagePaths_R116)
    PROPERTY_ARRAY_ROW(ImagePaths_R116)
    PROPERTY_ARRAY_ROW(ImagePaths_R121)
    PROPERTY_ARRAY_ROW(ImagePaths_R121)
    PROPERTY_ARRAY_ROW(ImagePaths_R121)
    PROPERTY_ARRAY_ROW(ImagePaths_R121)
    PROPERTY_ARRAY_ROW(ImagePaths_R121)
    PROPERTY_ARRAY_ROW(ImagePaths_R126)
    PROPERTY_ARRAY_ROW(ImagePaths_R126)
    PROPERTY_ARRAY_ROW(ImagePaths_R126)
    PROPERTY_ARRAY_ROW(ImagePaths_R126)
    PROPERTY_ARRAY_ROW(ImagePaths_R126)
    PROPERTY_ARRAY_ROW(ImagePaths_R131)
    PROPERTY_ARRAY_ROW(ImagePaths_R131)
    PROPERTY_ARRAY_ROW(ImagePaths_R131)
    PROPERTY_ARRAY_ROW(ImagePaths_R131)
    PROPERTY_ARRAY_ROW(ImagePaths_R131)
    PROPERTY_ARRAY_ROW(ImagePaths_R136)
    PROPERTY_ARRAY_ROW(ImagePaths_R136)
    PROPERTY_ARRAY_ROW(ImagePaths_R136)
    PROPERTY_ARRAY_ROW(ImagePaths_R136)
    PROPERTY_ARRAY_ROW(ImagePaths_R136)
    PROPERTY_ARRAY_ROW(ImagePaths_R141)
    PROPERTY_ARRAY_ROW(ImagePaths_R141)
    PROPERTY_ARRAY_ROW(ImagePaths_R141)
    PROPERTY_ARRAY_ROW(ImagePaths_R141)
    PROPERTY_ARRAY_ROW(ImagePaths_R141)
    PROPERTY_ARRAY_ROW(ImagePaths_R146)
    PROPERTY_ARRAY_ROW(ImagePaths_R146)
    PROPERTY_ARRAY_ROW(ImagePaths_R146)
    PROPERTY_ARRAY_ROW(ImagePaths_R146)
    PROPERTY_ARRAY_ROW(ImagePaths_R146)
    PROPERTY_ARRAY_ROW(ImagePaths_R151)
    PROPERTY_ARRAY_ROW(ImagePaths_R151)
    PROPERTY_ARRAY_ROW(ImagePaths_R153)
    PROPERTY_ARRAY_ROW(ImagePaths_R153)
    PROPERTY_ARRAY_ROW(ImagePaths_R151)
    PROPERTY_ARRAY_ROW(ImagePaths_R156)
    PROPERTY_ARRAY_ROW(ImagePaths_R156)
    PROPERTY_ARRAY_ROW(ImagePaths_R156)
    PROPERTY_ARRAY_ROW(ImagePaths_R156)
    PROPERTY_ARRAY_ROW(ImagePaths_R156)
    PROPERTY_ARRAY_ROW(ImagePaths_R161)
    PROPERTY_ARRAY_ROW(ImagePaths_R161)
    PROPERTY_ARRAY_ROW(ImagePaths_R161)
    PROPERTY_ARRAY_ROW(ImagePaths_R161)
    PROPERTY_ARRAY_ROW(ImagePaths_R161)
    PROPERTY_ARRAY_ROW(ImagePaths_R166)
    PROPERTY_ARRAY_ROW(ImagePaths_R166)
    PROPERTY_ARRAY_ROW(ImagePaths_R166)
    PROPERTY_ARRAY_ROW(ImagePaths_R166)
    PROPERTY_ARRAY_ROW(ImagePaths_R166)
    PROPERTY_ARRAY_ROW(ImagePaths_R171)
    PROPERTY_ARRAY_ROW(ImagePaths_R172)
    PROPERTY_ARRAY_ROW(ImagePaths_R173)
    PROPERTY_ARRAY_ROW(ImagePaths_R173)
    PROPERTY_ARRAY_ROW(ImagePaths_R172)
    PROPERTY_ARRAY_ROW(ImagePaths_R176)
    PROPERTY_ARRAY_ROW(ImagePaths_R176)
    PROPERTY_ARRAY_ROW(ImagePaths_R176)
    PROPERTY_ARRAY_ROW(ImagePaths_R176)
    PROPERTY_ARRAY_ROW(ImagePaths_R176)
    PROPERTY_ARRAY_ROW(ImagePaths_R181)
    PROPERTY_ARRAY_ROW(ImagePaths_R181)
    PROPERTY_ARRAY_ROW(ImagePaths_R181)
    PROPERTY_ARRAY_ROW(ImagePaths_R181)
    PROPERTY_ARRAY_ROW(ImagePaths_R181)
    PROPERTY_ARRAY_ROW(ImagePaths_R186)
    PROPERTY_ARRAY_ROW(ImagePaths_R186)
    PROPERTY_ARRAY_ROW(ImagePaths_R186)
    PROPERTY_ARRAY_ROW(ImagePaths_R186)
    PROPERTY_ARRAY_ROW(ImagePaths_R186)
    PROPERTY_ARRAY_ROW(ImagePaths_R191)
    PROPERTY_ARRAY_ROW(ImagePaths_R191)
    PROPERTY_ARRAY_ROW(ImagePaths_R191)
    PROPERTY_ARRAY_ROW(ImagePaths_R191)
    PROPERTY_ARRAY_ROW(ImagePaths_R191)
    PROPERTY_ARRAY_ROW(ImagePaths_R196)
    PROPERTY_ARRAY_ROW(ImagePaths_R196)
    PROPERTY_ARRAY_ROW(ImagePaths_R196)
    PROPERTY_ARRAY_ROW(ImagePaths_R196)
    PROPERTY_ARRAY_ROW(ImagePaths_R196)
    PROPERTY_ARRAY_ROW(ImagePaths_R201)
    PROPERTY_ARRAY_ROW(ImagePaths_R201)
    PROPERTY_ARRAY_ROW(ImagePaths_R201)
    PROPERTY_ARRAY_ROW(ImagePaths_R201)
    PROPERTY_ARRAY_ROW(ImagePaths_R201)
    PROPERTY_ARRAY_ROW(ImagePaths_R206)
    PROPERTY_ARRAY_ROW(ImagePaths_R206)
    PROPERTY_ARRAY_ROW(ImagePaths_R206)
    PROPERTY_ARRAY_ROW(ImagePaths_R206)
    PROPERTY_ARRAY_ROW(ImagePaths_R206)
    PROPERTY_ARRAY_ROW(ImagePaths_R211)
    PROPERTY_ARRAY_ROW(ImagePaths_R211)
    PROPERTY_ARRAY_ROW(ImagePaths_R211)
    PROPERTY_ARRAY_ROW(ImagePaths_R211)
    PROPERTY_ARRAY_ROW(ImagePaths_R211)
    PROPERTY_ARRAY_ROW(ImagePaths_R216)
    PROPERTY_ARRAY_ROW(ImagePaths_R216)
    PROPERTY_ARRAY_ROW(ImagePaths_R216)
    PROPERTY_ARRAY_ROW(ImagePaths_R216)
    PROPERTY_ARRAY_ROW(ImagePaths_R216)
    PROPERTY_ARRAY_ROW(ImagePaths_R221)
    PROPERTY_ARRAY_ROW(ImagePaths_R221)
    PROPERTY_ARRAY_ROW(ImagePaths_R221)
    PROPERTY_ARRAY_ROW(ImagePaths_R221)
    PROPERTY_ARRAY_ROW(ImagePaths_R221)
    PROPERTY_ARRAY_ROW(ImagePaths_R226)
    PROPERTY_ARRAY_ROW(ImagePaths_R226)
    PROPERTY_ARRAY_ROW(ImagePaths_R226)
    PROPERTY_ARRAY_ROW(ImagePaths_R226)
    PROPERTY_ARRAY_ROW(ImagePaths_R226)
    PROPERTY_ARRAY_ROW(ImagePaths_R231)
    PROPERTY_ARRAY_ROW(ImagePaths_R231)
    PROPERTY_ARRAY_ROW(ImagePaths_R231)
    PROPERTY_ARRAY_ROW(ImagePaths_R231)
    PROPERTY_ARRAY_ROW(ImagePaths_R231)
    PROPERTY_ARRAY_ROW(ImagePaths_R196)
    PROPERTY_ARRAY_ROW(ImagePaths_R196)
    PROPERTY_ARRAY_ROW(ImagePaths_R196)
    PROPERTY_ARRAY_ROW(ImagePaths_R196)
    PROPERTY_ARRAY_ROW(ImagePaths_R196)
    PROPERTY_ARRAY_ROW(ImagePaths_R241)
    PROPERTY_ARRAY_ROW(ImagePaths_R241)
    PROPERTY_ARRAY_ROW(ImagePaths_R241)
    PROPERTY_ARRAY_ROW(ImagePaths_R241)
    PROPERTY_ARRAY_ROW(ImagePaths_R241)
    PROPERTY_ARRAY_ROW(ImagePaths_R246)
    PROPERTY_ARRAY_ROW(ImagePaths_R246)
    PROPERTY_ARRAY_ROW(ImagePaths_R246)
    PROPERTY_ARRAY_ROW(ImagePaths_R246)
    PROPERTY_ARRAY_ROW(ImagePaths_R246)
    PROPERTY_ARRAY_ROW(ImagePaths_R251)
    PROPERTY_ARRAY_ROW(ImagePaths_R251)
    PROPERTY_ARRAY_ROW(ImagePaths_R251)
    PROPERTY_ARRAY_ROW(ImagePaths_R251)
    PROPERTY_ARRAY_ROW(ImagePaths_R251)
    PROPERTY_ARRAY_ROW(ImagePaths_R256)
    PROPERTY_ARRAY_ROW(ImagePaths_R256)
    PROPERTY_ARRAY_ROW(ImagePaths_R256)
    PROPERTY_ARRAY_ROW(ImagePaths_R256)
    PROPERTY_ARRAY_ROW(ImagePaths_R256)
    PROPERTY_ARRAY_ROW(ImagePaths_R261)
    PROPERTY_ARRAY_ROW(ImagePaths_R261)
    PROPERTY_ARRAY_ROW(ImagePaths_R261)
    PROPERTY_ARRAY_ROW(ImagePaths_R261)
    PROPERTY_ARRAY_ROW(ImagePaths_R261)
    PROPERTY_ARRAY_ROW(ImagePaths_R261)
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_354, 7)
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_426, 9)
    PROPERTY(0x2000022c)                // 800x480\HMINissanResources\HMI\speller_header\speller_btn_ok_e.png
    PROPERTY(0x2000022d)                // 800x480\HMINissanResources\HMI\speller_header\speller_btn_ok_e_f.png
    PROPERTY(0x2000022e)                // 800x480\HMINissanResources\HMI\speller_header\speller_btn_ok_d.png
    PROPERTY(0x2000022e)                // 800x480\HMINissanResources\HMI\speller_header\speller_btn_ok_d.png
    PROPERTY(0x2000022c)                // 800x480\HMINissanResources\HMI\speller_header\speller_btn_ok_e.png
    PROPERTY(0x2000022d)                // 800x480\HMINissanResources\HMI\speller_header\speller_btn_ok_e_f.png
    PROPERTY(0x2000022f)                // 800x480\HMINissanResources\HMI\speller_header\speller_btn_ok_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_428, 9)
    PROPERTY(0x20000230)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_e.png
    PROPERTY(0x20000231)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_e_f.png
    PROPERTY(0x20000232)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_d.png
    PROPERTY(0x20000232)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_d.png
    PROPERTY(0x20000230)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_e.png
    PROPERTY(0x20000231)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_e_f.png
    PROPERTY(0x20000233)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(bmDisabled, 19)
    PROPERTY(0x20000234)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_left_d.png
    PROPERTY(0x20000234)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_left_d.png
    PROPERTY(0x20000235)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_right_d.png
    PROPERTY(0x20000236)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_space_d.png
    PROPERTY(0x20000237)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_d.png
    PROPERTY(0x20000237)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_d.png
    PROPERTY(0x20000238)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_left_d.png
    PROPERTY(0x20000238)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_left_d.png
    PROPERTY(0x20000239)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_right_d.png
    PROPERTY(0x20000239)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_right_d.png
    PROPERTY(0x2000023a)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_d.png
    PROPERTY(0x2000023a)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_d.png
    PROPERTY(0x2000023b)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_left_d.png
    PROPERTY(0x2000023b)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_left_d.png
    PROPERTY(0x2000023c)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_right_d.png
    PROPERTY(0x2000023c)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_right_d.png
    PROPERTY(0x2000023d)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_space_d.png
    PROPERTY(0x2000023e)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_d.png
    PROPERTY(0x2000023e)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_d.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(bmEnabled, 19)
    PROPERTY(0x2000023f)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_left_e.png
    PROPERTY(0x2000023f)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_left_e.png
    PROPERTY(0x20000240)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_right_e.png
    PROPERTY(0x20000241)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_space_e.png
    PROPERTY(0x20000242)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_e.png
    PROPERTY(0x20000242)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_e.png
    PROPERTY(0x20000243)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_left_e.png
    PROPERTY(0x20000243)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_left_e.png
    PROPERTY(0x20000244)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_right_e.png
    PROPERTY(0x20000244)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_right_e.png
    PROPERTY(0x20000245)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_e.png
    PROPERTY(0x20000245)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_e.png
    PROPERTY(0x20000246)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_left_e.png
    PROPERTY(0x20000246)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_left_e.png
    PROPERTY(0x20000247)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_right_e.png
    PROPERTY(0x20000247)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_right_e.png
    PROPERTY(0x20000248)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_space_e.png
    PROPERTY(0x20000249)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_e.png
    PROPERTY(0x20000249)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(bmFocus, 19)
    PROPERTY(0x2000024a)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_left_e_f.png
    PROPERTY(0x2000024a)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_left_e_f.png
    PROPERTY(0x2000024b)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_right_e_f.png
    PROPERTY(0x2000024c)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_space_e_f.png
    PROPERTY(0x2000024d)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_e_f.png
    PROPERTY(0x2000024d)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_e_f.png
    PROPERTY(0x2000024e)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_left_e_f.png
    PROPERTY(0x2000024e)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_left_e_f.png
    PROPERTY(0x2000024f)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_right_e_f.png
    PROPERTY(0x2000024f)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_right_e_f.png
    PROPERTY(0x20000250)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_e_f.png
    PROPERTY(0x20000250)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_e_f.png
    PROPERTY(0x20000251)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_left_e_f.png
    PROPERTY(0x20000251)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_left_e_f.png
    PROPERTY(0x20000252)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_right_e_f.png
    PROPERTY(0x20000252)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_right_e_f.png
    PROPERTY(0x20000253)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_space_e_f.png
    PROPERTY(0x20000254)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_e_f.png
    PROPERTY(0x20000254)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_e_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(bmPressed, 19)
    PROPERTY(0x20000255)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_left_p.png
    PROPERTY(0x20000255)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_left_p.png
    PROPERTY(0x20000256)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_right_p.png
    PROPERTY(0x20000257)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_space_p.png
    PROPERTY(0x20000258)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_p.png
    PROPERTY(0x20000258)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_p.png
    PROPERTY(0x20000259)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_left_p.png
    PROPERTY(0x20000259)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_left_p.png
    PROPERTY(0x2000025a)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_right_p.png
    PROPERTY(0x2000025a)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_right_p.png
    PROPERTY(0x2000025b)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_p.png
    PROPERTY(0x2000025b)                // 800x480\HMINissanResources\HMI\button_speller\speller_num_btn_p.png
    PROPERTY(0x2000025c)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_left_p.png
    PROPERTY(0x2000025c)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_left_p.png
    PROPERTY(0x2000025d)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_right_p.png
    PROPERTY(0x2000025d)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_right_p.png
    PROPERTY(0x2000025e)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_space_p.png
    PROPERTY(0x2000025f)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_p.png
    PROPERTY(0x2000025f)                // 800x480\HMINissanResources\HMI\button_speller\speller_thai_btn_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(colDisabled, 19)
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(colEnabled, 19)
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffffff)                // 16777215
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TopOffset_435, 5)
    PROPERTY(0xe0000000)                // Display1: 0, Display2: 0
    PROPERTY(0xe004d02c)                // Display1: 77, Display2: 44
    PROPERTY(0xe009a058)                // Display1: 154, Display2: 88
    PROPERTY(0xe00e7084)                // Display1: 231, Display2: 132
    PROPERTY(0xe01340b0)                // Display1: 308, Display2: 176
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_437, 9)
    PROPERTY(0x20000262)                // 800x480\HMINissanResources\HMI\list_settings\li_set_83p_e.png
    PROPERTY(0x20000263)                // 800x480\HMINissanResources\HMI\list_settings\li_set_83p_e_f.png
    PROPERTY(0x20000264)                // 800x480\HMINissanResources\HMI\list_settings\li_set_83p_d.png
    PROPERTY(0x20000264)                // 800x480\HMINissanResources\HMI\list_settings\li_set_83p_d.png
    PROPERTY(0x20000262)                // 800x480\HMINissanResources\HMI\list_settings\li_set_83p_e.png
    PROPERTY(0x20000263)                // 800x480\HMINissanResources\HMI\list_settings\li_set_83p_e_f.png
    PROPERTY(0x20000265)                // 800x480\HMINissanResources\HMI\list_settings\li_set_83p_p.png
    PROPERTY(0x20000262)                // 800x480\HMINissanResources\HMI\list_settings\li_set_83p_e.png
    PROPERTY(0x20000262)                // 800x480\HMINissanResources\HMI\list_settings\li_set_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_438, 7)
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_440, 9)
    PROPERTY(0x20000266)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e.png
    PROPERTY(0x20000267)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e_f.png
    PROPERTY(0x20000268)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_d.png
    PROPERTY(0x20000268)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_d.png
    PROPERTY(0x20000266)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e.png
    PROPERTY(0x20000267)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e_f.png
    PROPERTY(0x20000269)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_p.png
    PROPERTY(0x20000266)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e.png
    PROPERTY(0x20000266)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_441, 9)
    PROPERTY(0x2000026a)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_inc_e.png
    PROPERTY(0x2000026a)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_inc_e.png
    PROPERTY(0x2000026b)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_inc_d.png
    PROPERTY(0x2000026b)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_inc_d.png
    PROPERTY(0x2000026a)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_inc_e.png
    PROPERTY(0x2000026a)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_inc_e.png
    PROPERTY(0x2000026c)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_inc_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_442, 9)
    PROPERTY(0x2000026d)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_dec_e.png
    PROPERTY(0x2000026d)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_dec_e.png
    PROPERTY(0x2000026e)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_dec_d.png
    PROPERTY(0x2000026e)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_dec_d.png
    PROPERTY(0x2000026d)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_dec_e.png
    PROPERTY(0x2000026d)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_dec_e.png
    PROPERTY(0x2000026f)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_dec_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content, 2)
    PROPERTY(0x800002c9)                // 2D -> SET.strSettings.MAP.USERMAP.content-000
    PROPERTY(0x800002ca)                // 3D -> SET.strSettings.MAP.USERMAP.content-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_553, 2)
    PROPERTY(0x20000270)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_2_1.png
    PROPERTY(0x20000271)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_2_2.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_554, 2)
    PROPERTY(0x800002c5)                // North -> SET.strSettings.MAP.ORIENTATION.content-000
    PROPERTY(0x800002c6)                // Head -> SET.strSettings.MAP.ORIENTATION.content-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_556, 9)
    PROPERTY(0x20000272)                // 800x480\HMINissanResources\HMI\list_settings\if_display_settings_83p_e.png
    PROPERTY(0x20000273)                // 800x480\HMINissanResources\HMI\list_settings\if_display_settings_83p_e_f.png
    PROPERTY(0x20000274)                // 800x480\HMINissanResources\HMI\list_settings\if_display_settings_83p_d.png
    PROPERTY(0x20000274)                // 800x480\HMINissanResources\HMI\list_settings\if_display_settings_83p_d.png
    PROPERTY(0x20000272)                // 800x480\HMINissanResources\HMI\list_settings\if_display_settings_83p_e.png
    PROPERTY(0x20000273)                // 800x480\HMINissanResources\HMI\list_settings\if_display_settings_83p_e_f.png
    PROPERTY(0x20000275)                // 800x480\HMINissanResources\HMI\list_settings\if_display_settings_83p_p.png
    PROPERTY(0x20000272)                // 800x480\HMINissanResources\HMI\list_settings\if_display_settings_83p_e.png
    PROPERTY(0x20000272)                // 800x480\HMINissanResources\HMI\list_settings\if_display_settings_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_559, 3)
    PROPERTY(0x80000311)                // Never -> SETTINGS_MAP.ListItemChoice_AutoZoom.content-000
    PROPERTY(0x80000312)                // Always -> SETTINGS_MAP.ListItemChoice_AutoZoom.content-001
    PROPERTY(0x80000313)                // Only with a route -> SETTINGS_MAP.ListItemChoice_AutoZoom.content-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_561, 9)
    PROPERTY(0x20000266)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e.png
    PROPERTY(0x20000267)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e_f.png
    PROPERTY(0x20000268)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_d.png
    PROPERTY(0x20000268)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_d.png
    PROPERTY(0x20000266)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e.png
    PROPERTY(0x20000267)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e_f.png
    PROPERTY(0x20000269)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_p.png
    PROPERTY(0x20000266)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e.png
    PROPERTY(0x20000272)                // 800x480\HMINissanResources\HMI\list_settings\if_display_settings_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_564, 3)
    PROPERTY(0x20000276)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_3_1.png
    PROPERTY(0x20000277)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_3_2.png
    PROPERTY(0x20000278)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_3_3.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_567, 9)
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x2000027a)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e_f.png
    PROPERTY(0x2000027b)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_d.png
    PROPERTY(0x2000027b)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_d.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x2000027a)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e_f.png
    PROPERTY(0x2000027c)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_p.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_569, 3)
    PROPERTY(0x800000a5)                // OFF -> CONST.Navigation.Setup.WarningSettings-000
    PROPERTY(0x800000a6)                // Show Only -> CONST.Navigation.Setup.WarningSettings-001
    PROPERTY(0x800000a7)                // Show & Beep -> CONST.Navigation.Setup.WarningSettings-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_594, 2)
    PROPERTY(0x800002a9)                // of Arrival -> SET.strliSettingsNav.ListItemChoiceTimeDispaly.content.Arrival-000
    PROPERTY(0x800002aa)                // Remaining -> SET.strliSettingsNav.ListItemChoiceTimeDispaly.content.Arrival-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_614, 2)
    PROPERTY(0x800002b0)                // Metric -> SET.strliSettingsSystem.ListItemChoiceDistanceUnits.content.KM-000
    PROPERTY(0x800002b1)                // US -> SET.strliSettingsSystem.ListItemChoiceDistanceUnits.content.KM-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R0_887, 6)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R1_888, 6)
    PROPERTY(0x2000027d)                // 800x480\HMINissanResources\HMI\listicon_16px\2060_e.png
    PROPERTY(0x2000027d)                // 800x480\HMINissanResources\HMI\listicon_16px\2060_e.png
    PROPERTY(0x2000027e)                // 800x480\HMINissanResources\HMI\listicon_16px\2060_f.png
    PROPERTY(0x2000027f)                // 800x480\HMINissanResources\HMI\listicon_16px\2060_p.png
    PROPERTY(0x20000280)                // 800x480\HMINissanResources\HMI\listicon_16px\2060_a.png
    PROPERTY(0x20000281)                // 800x480\HMINissanResources\HMI\listicon_16px\2060_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R6_889, 6)
    PROPERTY(0x20000282)                // 800x480\HMINissanResources\HMI\listicon_16px\1061_e.png
    PROPERTY(0x20000282)                // 800x480\HMINissanResources\HMI\listicon_16px\1061_e.png
    PROPERTY(0x20000283)                // 800x480\HMINissanResources\HMI\listicon_16px\1061_f.png
    PROPERTY(0x20000284)                // 800x480\HMINissanResources\HMI\listicon_16px\1061_p.png
    PROPERTY(0x20000285)                // 800x480\HMINissanResources\HMI\listicon_16px\1061_a.png
    PROPERTY(0x20000286)                // 800x480\HMINissanResources\HMI\listicon_16px\1061_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R7, 6)
    PROPERTY(0x20000287)                // 800x480\HMINissanResources\HMI\listicon_16px\2061_e.png
    PROPERTY(0x20000287)                // 800x480\HMINissanResources\HMI\listicon_16px\2061_e.png
    PROPERTY(0x20000288)                // 800x480\HMINissanResources\HMI\listicon_16px\2061_f.png
    PROPERTY(0x20000289)                // 800x480\HMINissanResources\HMI\listicon_16px\2061_p.png
    PROPERTY(0x2000028a)                // 800x480\HMINissanResources\HMI\listicon_16px\2061_a.png
    PROPERTY(0x2000028b)                // 800x480\HMINissanResources\HMI\listicon_16px\2061_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R11_890, 6)
    PROPERTY(0x2000028c)                // 800x480\HMINissanResources\HMI\listicon_16px\2062_e.png
    PROPERTY(0x2000028c)                // 800x480\HMINissanResources\HMI\listicon_16px\2062_e.png
    PROPERTY(0x2000028d)                // 800x480\HMINissanResources\HMI\listicon_16px\2062_f.png
    PROPERTY(0x2000028e)                // 800x480\HMINissanResources\HMI\listicon_16px\2062_p.png
    PROPERTY(0x2000028f)                // 800x480\HMINissanResources\HMI\listicon_16px\2062_a.png
    PROPERTY(0x20000290)                // 800x480\HMINissanResources\HMI\listicon_16px\2062_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R13, 5)
    PROPERTY(0x2000028c)                // 800x480\HMINissanResources\HMI\listicon_16px\2062_e.png
    PROPERTY(0x2000028c)                // 800x480\HMINissanResources\HMI\listicon_16px\2062_e.png
    PROPERTY(0x2000028d)                // 800x480\HMINissanResources\HMI\listicon_16px\2062_f.png
    PROPERTY(0x2000028e)                // 800x480\HMINissanResources\HMI\listicon_16px\2062_p.png
    PROPERTY(0x2000028f)                // 800x480\HMINissanResources\HMI\listicon_16px\2062_a.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R16_891, 6)
    PROPERTY(0x20000291)                // 800x480\HMINissanResources\HMI\listicon_16px\1063_e.png
    PROPERTY(0x20000291)                // 800x480\HMINissanResources\HMI\listicon_16px\1063_e.png
    PROPERTY(0x20000292)                // 800x480\HMINissanResources\HMI\listicon_16px\1063_f.png
    PROPERTY(0x20000293)                // 800x480\HMINissanResources\HMI\listicon_16px\1063_p.png
    PROPERTY(0x20000294)                // 800x480\HMINissanResources\HMI\listicon_16px\1063_a.png
    PROPERTY(0x20000295)                // 800x480\HMINissanResources\HMI\listicon_16px\1063_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R17, 6)
    PROPERTY(0x20000296)                // 800x480\HMINissanResources\HMI\listicon_16px\2063_e.png
    PROPERTY(0x20000296)                // 800x480\HMINissanResources\HMI\listicon_16px\2063_e.png
    PROPERTY(0x20000297)                // 800x480\HMINissanResources\HMI\listicon_16px\2063_f.png
    PROPERTY(0x20000298)                // 800x480\HMINissanResources\HMI\listicon_16px\2063_p.png
    PROPERTY(0x20000299)                // 800x480\HMINissanResources\HMI\listicon_16px\2063_a.png
    PROPERTY(0x2000029a)                // 800x480\HMINissanResources\HMI\listicon_16px\2063_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R21_892, 6)
    PROPERTY(0x2000029b)                // 800x480\HMINissanResources\HMI\listicon_16px\2064_e.png
    PROPERTY(0x2000029b)                // 800x480\HMINissanResources\HMI\listicon_16px\2064_e.png
    PROPERTY(0x2000029c)                // 800x480\HMINissanResources\HMI\listicon_16px\2064_f.png
    PROPERTY(0x2000029d)                // 800x480\HMINissanResources\HMI\listicon_16px\2064_p.png
    PROPERTY(0x2000029e)                // 800x480\HMINissanResources\HMI\listicon_16px\2064_a.png
    PROPERTY(0x2000029f)                // 800x480\HMINissanResources\HMI\listicon_16px\2064_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R26_893, 6)
    PROPERTY(0x200002a0)                // 800x480\HMINissanResources\HMI\listicon_16px\1065_e.png
    PROPERTY(0x200002a0)                // 800x480\HMINissanResources\HMI\listicon_16px\1065_e.png
    PROPERTY(0x200002a1)                // 800x480\HMINissanResources\HMI\listicon_16px\1065_f.png
    PROPERTY(0x200002a2)                // 800x480\HMINissanResources\HMI\listicon_16px\1065_p.png
    PROPERTY(0x200002a3)                // 800x480\HMINissanResources\HMI\listicon_16px\1065_a.png
    PROPERTY(0x200002a4)                // 800x480\HMINissanResources\HMI\listicon_16px\1065_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R27, 6)
    PROPERTY(0x200002a5)                // 800x480\HMINissanResources\HMI\listicon_16px\2065_e.png
    PROPERTY(0x200002a5)                // 800x480\HMINissanResources\HMI\listicon_16px\2065_e.png
    PROPERTY(0x200002a6)                // 800x480\HMINissanResources\HMI\listicon_16px\2065_f.png
    PROPERTY(0x200002a7)                // 800x480\HMINissanResources\HMI\listicon_16px\2065_p.png
    PROPERTY(0x200002a8)                // 800x480\HMINissanResources\HMI\listicon_16px\2065_a.png
    PROPERTY(0x200002a9)                // 800x480\HMINissanResources\HMI\listicon_16px\2065_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R31_894, 6)
    PROPERTY(0x200002aa)                // 800x480\HMINissanResources\HMI\listicon_16px\2066_e.png
    PROPERTY(0x200002aa)                // 800x480\HMINissanResources\HMI\listicon_16px\2066_e.png
    PROPERTY(0x200002ab)                // 800x480\HMINissanResources\HMI\listicon_16px\2066_f.png
    PROPERTY(0x200002ac)                // 800x480\HMINissanResources\HMI\listicon_16px\2066_p.png
    PROPERTY(0x200002ad)                // 800x480\HMINissanResources\HMI\listicon_16px\2066_a.png
    PROPERTY(0x200002ae)                // 800x480\HMINissanResources\HMI\listicon_16px\2066_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R36_895, 6)
    PROPERTY(0x200002af)                // 800x480\HMINissanResources\HMI\listicon_16px\1067_e.png
    PROPERTY(0x200002af)                // 800x480\HMINissanResources\HMI\listicon_16px\1067_e.png
    PROPERTY(0x200002b0)                // 800x480\HMINissanResources\HMI\listicon_16px\1067_f.png
    PROPERTY(0x200002b1)                // 800x480\HMINissanResources\HMI\listicon_16px\1067_p.png
    PROPERTY(0x200002b2)                // 800x480\HMINissanResources\HMI\listicon_16px\1067_a.png
    PROPERTY(0x200002b3)                // 800x480\HMINissanResources\HMI\listicon_16px\1067_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R37, 6)
    PROPERTY(0x200002b4)                // 800x480\HMINissanResources\HMI\listicon_16px\2067_e.png
    PROPERTY(0x200002b4)                // 800x480\HMINissanResources\HMI\listicon_16px\2067_e.png
    PROPERTY(0x200002b5)                // 800x480\HMINissanResources\HMI\listicon_16px\2067_f.png
    PROPERTY(0x200002b6)                // 800x480\HMINissanResources\HMI\listicon_16px\2067_p.png
    PROPERTY(0x200002b7)                // 800x480\HMINissanResources\HMI\listicon_16px\2067_a.png
    PROPERTY(0x200002b8)                // 800x480\HMINissanResources\HMI\listicon_16px\2067_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R41_896, 6)
    PROPERTY(0x200002b9)                // 800x480\HMINissanResources\HMI\listicon_16px\2068_e.png
    PROPERTY(0x200002b9)                // 800x480\HMINissanResources\HMI\listicon_16px\2068_e.png
    PROPERTY(0x200002ba)                // 800x480\HMINissanResources\HMI\listicon_16px\2068_f.png
    PROPERTY(0x200002bb)                // 800x480\HMINissanResources\HMI\listicon_16px\2068_p.png
    PROPERTY(0x200002bc)                // 800x480\HMINissanResources\HMI\listicon_16px\2068_a.png
    PROPERTY(0x200002bd)                // 800x480\HMINissanResources\HMI\listicon_16px\2068_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R46_897, 6)
    PROPERTY(0x200002be)                // 800x480\HMINissanResources\HMI\listicon_16px\1069_e.png
    PROPERTY(0x200002be)                // 800x480\HMINissanResources\HMI\listicon_16px\1069_e.png
    PROPERTY(0x200002bf)                // 800x480\HMINissanResources\HMI\listicon_16px\1069_f.png
    PROPERTY(0x200002c0)                // 800x480\HMINissanResources\HMI\listicon_16px\1069_p.png
    PROPERTY(0x200002c1)                // 800x480\HMINissanResources\HMI\listicon_16px\1069_a.png
    PROPERTY(0x200002c2)                // 800x480\HMINissanResources\HMI\listicon_16px\1069_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R47, 6)
    PROPERTY(0x200002c3)                // 800x480\HMINissanResources\HMI\listicon_16px\2069_e.png
    PROPERTY(0x200002c3)                // 800x480\HMINissanResources\HMI\listicon_16px\2069_e.png
    PROPERTY(0x200002c4)                // 800x480\HMINissanResources\HMI\listicon_16px\2069_f.png
    PROPERTY(0x200002c5)                // 800x480\HMINissanResources\HMI\listicon_16px\2069_p.png
    PROPERTY(0x200002c6)                // 800x480\HMINissanResources\HMI\listicon_16px\2069_a.png
    PROPERTY(0x200002c7)                // 800x480\HMINissanResources\HMI\listicon_16px\2069_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R51_898, 6)
    PROPERTY(0x200002c8)                // 800x480\HMINissanResources\HMI\listicon_16px\206A_e.png
    PROPERTY(0x200002c8)                // 800x480\HMINissanResources\HMI\listicon_16px\206A_e.png
    PROPERTY(0x200002c9)                // 800x480\HMINissanResources\HMI\listicon_16px\206A_f.png
    PROPERTY(0x200002ca)                // 800x480\HMINissanResources\HMI\listicon_16px\206A_p.png
    PROPERTY(0x200002cb)                // 800x480\HMINissanResources\HMI\listicon_16px\206A_a.png
    PROPERTY(0x200002cc)                // 800x480\HMINissanResources\HMI\listicon_16px\206A_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R56_899, 6)
    PROPERTY(0x200002cd)                // 800x480\HMINissanResources\HMI\listicon_16px\106B_e.png
    PROPERTY(0x200002cd)                // 800x480\HMINissanResources\HMI\listicon_16px\106B_e.png
    PROPERTY(0x200002ce)                // 800x480\HMINissanResources\HMI\listicon_16px\106B_f.png
    PROPERTY(0x200002cf)                // 800x480\HMINissanResources\HMI\listicon_16px\106B_p.png
    PROPERTY(0x200002d0)                // 800x480\HMINissanResources\HMI\listicon_16px\106B_a.png
    PROPERTY(0x200002d1)                // 800x480\HMINissanResources\HMI\listicon_16px\106B_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R57, 6)
    PROPERTY(0x200002d2)                // 800x480\HMINissanResources\HMI\listicon_16px\206B_e.png
    PROPERTY(0x200002d2)                // 800x480\HMINissanResources\HMI\listicon_16px\206B_e.png
    PROPERTY(0x200002d3)                // 800x480\HMINissanResources\HMI\listicon_16px\206B_f.png
    PROPERTY(0x200002d4)                // 800x480\HMINissanResources\HMI\listicon_16px\206B_p.png
    PROPERTY(0x200002d5)                // 800x480\HMINissanResources\HMI\listicon_16px\206B_a.png
    PROPERTY(0x200002d6)                // 800x480\HMINissanResources\HMI\listicon_16px\206B_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R61_900, 6)
    PROPERTY(0x200002d7)                // 800x480\HMINissanResources\HMI\listicon_16px\206C_e.png
    PROPERTY(0x200002d7)                // 800x480\HMINissanResources\HMI\listicon_16px\206C_e.png
    PROPERTY(0x200002d8)                // 800x480\HMINissanResources\HMI\listicon_16px\206C_f.png
    PROPERTY(0x200002d9)                // 800x480\HMINissanResources\HMI\listicon_16px\206C_p.png
    PROPERTY(0x200002da)                // 800x480\HMINissanResources\HMI\listicon_16px\206C_a.png
    PROPERTY(0x200002db)                // 800x480\HMINissanResources\HMI\listicon_16px\206C_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R66_901, 6)
    PROPERTY(0x200002dc)                // 800x480\HMINissanResources\HMI\listicon_16px\106D_e.png
    PROPERTY(0x200002dc)                // 800x480\HMINissanResources\HMI\listicon_16px\106D_e.png
    PROPERTY(0x200002dd)                // 800x480\HMINissanResources\HMI\listicon_16px\106D_f.png
    PROPERTY(0x200002de)                // 800x480\HMINissanResources\HMI\listicon_16px\106D_p.png
    PROPERTY(0x200002df)                // 800x480\HMINissanResources\HMI\listicon_16px\106D_a.png
    PROPERTY(0x200002e0)                // 800x480\HMINissanResources\HMI\listicon_16px\106D_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R67, 6)
    PROPERTY(0x200002e1)                // 800x480\HMINissanResources\HMI\listicon_16px\206D_e.png
    PROPERTY(0x200002e1)                // 800x480\HMINissanResources\HMI\listicon_16px\206D_e.png
    PROPERTY(0x200002e2)                // 800x480\HMINissanResources\HMI\listicon_16px\206D_f.png
    PROPERTY(0x200002e3)                // 800x480\HMINissanResources\HMI\listicon_16px\206D_p.png
    PROPERTY(0x200002e4)                // 800x480\HMINissanResources\HMI\listicon_16px\206D_a.png
    PROPERTY(0x200002e5)                // 800x480\HMINissanResources\HMI\listicon_16px\206D_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R71_902, 6)
    PROPERTY(0x200002e6)                // 800x480\HMINissanResources\HMI\listicon_16px\206E_e.png
    PROPERTY(0x200002e6)                // 800x480\HMINissanResources\HMI\listicon_16px\206E_e.png
    PROPERTY(0x200002e7)                // 800x480\HMINissanResources\HMI\listicon_16px\206E_f.png
    PROPERTY(0x200002e8)                // 800x480\HMINissanResources\HMI\listicon_16px\206E_p.png
    PROPERTY(0x200002e9)                // 800x480\HMINissanResources\HMI\listicon_16px\206E_a.png
    PROPERTY(0x200002ea)                // 800x480\HMINissanResources\HMI\listicon_16px\206E_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R76_903, 6)
    PROPERTY(0x200002eb)                // 800x480\HMINissanResources\HMI\listicon_16px\106F_e.png
    PROPERTY(0x200002eb)                // 800x480\HMINissanResources\HMI\listicon_16px\106F_e.png
    PROPERTY(0x200002ec)                // 800x480\HMINissanResources\HMI\listicon_16px\106F_f.png
    PROPERTY(0x200002ed)                // 800x480\HMINissanResources\HMI\listicon_16px\106F_p.png
    PROPERTY(0x200002ee)                // 800x480\HMINissanResources\HMI\listicon_16px\106F_a.png
    PROPERTY(0x200002ef)                // 800x480\HMINissanResources\HMI\listicon_16px\106F_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R77, 6)
    PROPERTY(0x200002f0)                // 800x480\HMINissanResources\HMI\listicon_16px\206F_e.png
    PROPERTY(0x200002f0)                // 800x480\HMINissanResources\HMI\listicon_16px\206F_e.png
    PROPERTY(0x200002f1)                // 800x480\HMINissanResources\HMI\listicon_16px\206F_f.png
    PROPERTY(0x200002f2)                // 800x480\HMINissanResources\HMI\listicon_16px\206F_p.png
    PROPERTY(0x200002f3)                // 800x480\HMINissanResources\HMI\listicon_16px\206F_a.png
    PROPERTY(0x200002f4)                // 800x480\HMINissanResources\HMI\listicon_16px\206F_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R81_904, 6)
    PROPERTY(0x200002f5)                // 800x480\HMINissanResources\HMI\listicon_16px\2070_e.png
    PROPERTY(0x200002f5)                // 800x480\HMINissanResources\HMI\listicon_16px\2070_e.png
    PROPERTY(0x200002f6)                // 800x480\HMINissanResources\HMI\listicon_16px\2070_f.png
    PROPERTY(0x200002f7)                // 800x480\HMINissanResources\HMI\listicon_16px\2070_p.png
    PROPERTY(0x200002f8)                // 800x480\HMINissanResources\HMI\listicon_16px\2070_a.png
    PROPERTY(0x200002f9)                // 800x480\HMINissanResources\HMI\listicon_16px\2070_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R86_905, 6)
    PROPERTY(0x200002fa)                // 800x480\HMINissanResources\HMI\listicon_16px\1071_e.png
    PROPERTY(0x200002fa)                // 800x480\HMINissanResources\HMI\listicon_16px\1071_e.png
    PROPERTY(0x200002fb)                // 800x480\HMINissanResources\HMI\listicon_16px\1071_f.png
    PROPERTY(0x200002fc)                // 800x480\HMINissanResources\HMI\listicon_16px\1071_p.png
    PROPERTY(0x200002fd)                // 800x480\HMINissanResources\HMI\listicon_16px\1071_a.png
    PROPERTY(0x200002fe)                // 800x480\HMINissanResources\HMI\listicon_16px\1071_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R87, 6)
    PROPERTY(0x200002ff)                // 800x480\HMINissanResources\HMI\listicon_16px\2071_e.png
    PROPERTY(0x200002ff)                // 800x480\HMINissanResources\HMI\listicon_16px\2071_e.png
    PROPERTY(0x20000300)                // 800x480\HMINissanResources\HMI\listicon_16px\2071_f.png
    PROPERTY(0x20000301)                // 800x480\HMINissanResources\HMI\listicon_16px\2071_p.png
    PROPERTY(0x20000302)                // 800x480\HMINissanResources\HMI\listicon_16px\2071_a.png
    PROPERTY(0x20000303)                // 800x480\HMINissanResources\HMI\listicon_16px\2071_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R91_906, 6)
    PROPERTY(0x20000304)                // 800x480\HMINissanResources\HMI\listicon_16px\2072_e.png
    PROPERTY(0x20000304)                // 800x480\HMINissanResources\HMI\listicon_16px\2072_e.png
    PROPERTY(0x20000305)                // 800x480\HMINissanResources\HMI\listicon_16px\2072_f.png
    PROPERTY(0x20000306)                // 800x480\HMINissanResources\HMI\listicon_16px\2072_p.png
    PROPERTY(0x20000307)                // 800x480\HMINissanResources\HMI\listicon_16px\2072_a.png
    PROPERTY(0x20000308)                // 800x480\HMINissanResources\HMI\listicon_16px\2072_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R96_907, 6)
    PROPERTY(0x20000309)                // 800x480\HMINissanResources\HMI\listicon_16px\1073_e.png
    PROPERTY(0x20000309)                // 800x480\HMINissanResources\HMI\listicon_16px\1073_e.png
    PROPERTY(0x2000030a)                // 800x480\HMINissanResources\HMI\listicon_16px\1073_f.png
    PROPERTY(0x2000030b)                // 800x480\HMINissanResources\HMI\listicon_16px\1073_p.png
    PROPERTY(0x2000030c)                // 800x480\HMINissanResources\HMI\listicon_16px\1073_a.png
    PROPERTY(0x2000030d)                // 800x480\HMINissanResources\HMI\listicon_16px\1073_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R97, 6)
    PROPERTY(0x2000030e)                // 800x480\HMINissanResources\HMI\listicon_16px\2073_e.png
    PROPERTY(0x2000030e)                // 800x480\HMINissanResources\HMI\listicon_16px\2073_e.png
    PROPERTY(0x2000030f)                // 800x480\HMINissanResources\HMI\listicon_16px\2073_f.png
    PROPERTY(0x20000310)                // 800x480\HMINissanResources\HMI\listicon_16px\2073_p.png
    PROPERTY(0x20000311)                // 800x480\HMINissanResources\HMI\listicon_16px\2073_a.png
    PROPERTY(0x20000312)                // 800x480\HMINissanResources\HMI\listicon_16px\2073_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R101_908, 6)
    PROPERTY(0x20000313)                // 800x480\HMINissanResources\HMI\listicon_16px\2074_e.png
    PROPERTY(0x20000313)                // 800x480\HMINissanResources\HMI\listicon_16px\2074_e.png
    PROPERTY(0x20000314)                // 800x480\HMINissanResources\HMI\listicon_16px\2074_f.png
    PROPERTY(0x20000315)                // 800x480\HMINissanResources\HMI\listicon_16px\2074_p.png
    PROPERTY(0x20000316)                // 800x480\HMINissanResources\HMI\listicon_16px\2074_a.png
    PROPERTY(0x20000317)                // 800x480\HMINissanResources\HMI\listicon_16px\2074_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R106_909, 6)
    PROPERTY(0x20000318)                // 800x480\HMINissanResources\HMI\listicon_16px\1075_e.png
    PROPERTY(0x20000318)                // 800x480\HMINissanResources\HMI\listicon_16px\1075_e.png
    PROPERTY(0x20000319)                // 800x480\HMINissanResources\HMI\listicon_16px\1075_f.png
    PROPERTY(0x2000031a)                // 800x480\HMINissanResources\HMI\listicon_16px\1075_p.png
    PROPERTY(0x2000031b)                // 800x480\HMINissanResources\HMI\listicon_16px\1075_a.png
    PROPERTY(0x2000031c)                // 800x480\HMINissanResources\HMI\listicon_16px\1075_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R107, 6)
    PROPERTY(0x2000031d)                // 800x480\HMINissanResources\HMI\listicon_16px\2075_e.png
    PROPERTY(0x2000031d)                // 800x480\HMINissanResources\HMI\listicon_16px\2075_e.png
    PROPERTY(0x2000031e)                // 800x480\HMINissanResources\HMI\listicon_16px\2075_f.png
    PROPERTY(0x2000031f)                // 800x480\HMINissanResources\HMI\listicon_16px\2075_p.png
    PROPERTY(0x20000320)                // 800x480\HMINissanResources\HMI\listicon_16px\2075_a.png
    PROPERTY(0x20000321)                // 800x480\HMINissanResources\HMI\listicon_16px\2075_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R111_910, 6)
    PROPERTY(0x20000322)                // 800x480\HMINissanResources\HMI\listicon_16px\2076_e.png
    PROPERTY(0x20000322)                // 800x480\HMINissanResources\HMI\listicon_16px\2076_e.png
    PROPERTY(0x20000323)                // 800x480\HMINissanResources\HMI\listicon_16px\2076_f.png
    PROPERTY(0x20000324)                // 800x480\HMINissanResources\HMI\listicon_16px\2076_p.png
    PROPERTY(0x20000325)                // 800x480\HMINissanResources\HMI\listicon_16px\2076_a.png
    PROPERTY(0x20000326)                // 800x480\HMINissanResources\HMI\listicon_16px\2076_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R116_911, 6)
    PROPERTY(0x20000327)                // 800x480\HMINissanResources\HMI\listicon_16px\1077_e.png
    PROPERTY(0x20000327)                // 800x480\HMINissanResources\HMI\listicon_16px\1077_e.png
    PROPERTY(0x20000328)                // 800x480\HMINissanResources\HMI\listicon_16px\1077_f.png
    PROPERTY(0x20000329)                // 800x480\HMINissanResources\HMI\listicon_16px\1077_p.png
    PROPERTY(0x2000032a)                // 800x480\HMINissanResources\HMI\listicon_16px\1077_a.png
    PROPERTY(0x2000032b)                // 800x480\HMINissanResources\HMI\listicon_16px\1077_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R117, 6)
    PROPERTY(0x2000032c)                // 800x480\HMINissanResources\HMI\listicon_16px\2077_e.png
    PROPERTY(0x2000032c)                // 800x480\HMINissanResources\HMI\listicon_16px\2077_e.png
    PROPERTY(0x2000032d)                // 800x480\HMINissanResources\HMI\listicon_16px\2077_f.png
    PROPERTY(0x2000032e)                // 800x480\HMINissanResources\HMI\listicon_16px\2077_p.png
    PROPERTY(0x2000032f)                // 800x480\HMINissanResources\HMI\listicon_16px\2077_a.png
    PROPERTY(0x20000330)                // 800x480\HMINissanResources\HMI\listicon_16px\2077_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R121_912, 6)
    PROPERTY(0x20000331)                // 800x480\HMINissanResources\HMI\listicon_16px\2078_e.png
    PROPERTY(0x20000331)                // 800x480\HMINissanResources\HMI\listicon_16px\2078_e.png
    PROPERTY(0x20000332)                // 800x480\HMINissanResources\HMI\listicon_16px\2078_f.png
    PROPERTY(0x20000333)                // 800x480\HMINissanResources\HMI\listicon_16px\2078_p.png
    PROPERTY(0x20000334)                // 800x480\HMINissanResources\HMI\listicon_16px\2078_a.png
    PROPERTY(0x20000335)                // 800x480\HMINissanResources\HMI\listicon_16px\2078_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R126_913, 6)
    PROPERTY(0x20000336)                // 800x480\HMINissanResources\HMI\listicon_16px\1079_e.png
    PROPERTY(0x20000336)                // 800x480\HMINissanResources\HMI\listicon_16px\1079_e.png
    PROPERTY(0x20000337)                // 800x480\HMINissanResources\HMI\listicon_16px\1079_f.png
    PROPERTY(0x20000338)                // 800x480\HMINissanResources\HMI\listicon_16px\1079_p.png
    PROPERTY(0x20000339)                // 800x480\HMINissanResources\HMI\listicon_16px\1079_a.png
    PROPERTY(0x2000033a)                // 800x480\HMINissanResources\HMI\listicon_16px\1079_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R127, 6)
    PROPERTY(0x2000033b)                // 800x480\HMINissanResources\HMI\listicon_16px\2079_e.png
    PROPERTY(0x2000033b)                // 800x480\HMINissanResources\HMI\listicon_16px\2079_e.png
    PROPERTY(0x2000033c)                // 800x480\HMINissanResources\HMI\listicon_16px\2079_f.png
    PROPERTY(0x2000033d)                // 800x480\HMINissanResources\HMI\listicon_16px\2079_p.png
    PROPERTY(0x2000033e)                // 800x480\HMINissanResources\HMI\listicon_16px\2079_a.png
    PROPERTY(0x2000033f)                // 800x480\HMINissanResources\HMI\listicon_16px\2079_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R131_914, 6)
    PROPERTY(0x20000340)                // 800x480\HMINissanResources\HMI\listicon_16px\207A_e.png
    PROPERTY(0x20000340)                // 800x480\HMINissanResources\HMI\listicon_16px\207A_e.png
    PROPERTY(0x20000341)                // 800x480\HMINissanResources\HMI\listicon_16px\207A_f.png
    PROPERTY(0x20000342)                // 800x480\HMINissanResources\HMI\listicon_16px\207A_p.png
    PROPERTY(0x20000343)                // 800x480\HMINissanResources\HMI\listicon_16px\207A_a.png
    PROPERTY(0x20000344)                // 800x480\HMINissanResources\HMI\listicon_16px\207A_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R136_915, 6)
    PROPERTY(0x20000345)                // 800x480\HMINissanResources\HMI\listicon_16px\107B_e.png
    PROPERTY(0x20000345)                // 800x480\HMINissanResources\HMI\listicon_16px\107B_e.png
    PROPERTY(0x20000346)                // 800x480\HMINissanResources\HMI\listicon_16px\107B_f.png
    PROPERTY(0x20000347)                // 800x480\HMINissanResources\HMI\listicon_16px\107B_p.png
    PROPERTY(0x20000348)                // 800x480\HMINissanResources\HMI\listicon_16px\107B_a.png
    PROPERTY(0x20000349)                // 800x480\HMINissanResources\HMI\listicon_16px\107B_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R137, 6)
    PROPERTY(0x2000034a)                // 800x480\HMINissanResources\HMI\listicon_16px\207B_e.png
    PROPERTY(0x2000034a)                // 800x480\HMINissanResources\HMI\listicon_16px\207B_e.png
    PROPERTY(0x2000034b)                // 800x480\HMINissanResources\HMI\listicon_16px\207B_f.png
    PROPERTY(0x2000034c)                // 800x480\HMINissanResources\HMI\listicon_16px\207B_p.png
    PROPERTY(0x2000034d)                // 800x480\HMINissanResources\HMI\listicon_16px\207B_a.png
    PROPERTY(0x2000034e)                // 800x480\HMINissanResources\HMI\listicon_16px\207B_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R141_916, 6)
    PROPERTY(0x2000034f)                // 800x480\HMINissanResources\HMI\listicon_16px\207C_e.png
    PROPERTY(0x2000034f)                // 800x480\HMINissanResources\HMI\listicon_16px\207C_e.png
    PROPERTY(0x20000350)                // 800x480\HMINissanResources\HMI\listicon_16px\207C_f.png
    PROPERTY(0x20000351)                // 800x480\HMINissanResources\HMI\listicon_16px\207C_p.png
    PROPERTY(0x20000352)                // 800x480\HMINissanResources\HMI\listicon_16px\207C_a.png
    PROPERTY(0x20000353)                // 800x480\HMINissanResources\HMI\listicon_16px\207C_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R146_917, 6)
    PROPERTY(0x20000354)                // 800x480\HMINissanResources\HMI\listicon_16px\107D_e.png
    PROPERTY(0x20000354)                // 800x480\HMINissanResources\HMI\listicon_16px\107D_e.png
    PROPERTY(0x20000355)                // 800x480\HMINissanResources\HMI\listicon_16px\107D_f.png
    PROPERTY(0x20000356)                // 800x480\HMINissanResources\HMI\listicon_16px\107D_p.png
    PROPERTY(0x20000357)                // 800x480\HMINissanResources\HMI\listicon_16px\107D_a.png
    PROPERTY(0x20000358)                // 800x480\HMINissanResources\HMI\listicon_16px\107D_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R147, 6)
    PROPERTY(0x20000359)                // 800x480\HMINissanResources\HMI\listicon_16px\207D_e.png
    PROPERTY(0x20000359)                // 800x480\HMINissanResources\HMI\listicon_16px\207D_e.png
    PROPERTY(0x2000035a)                // 800x480\HMINissanResources\HMI\listicon_16px\207D_f.png
    PROPERTY(0x2000035b)                // 800x480\HMINissanResources\HMI\listicon_16px\207D_p.png
    PROPERTY(0x2000035c)                // 800x480\HMINissanResources\HMI\listicon_16px\207D_a.png
    PROPERTY(0x2000035d)                // 800x480\HMINissanResources\HMI\listicon_16px\207D_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R151_918, 6)
    PROPERTY(0x2000035e)                // 800x480\HMINissanResources\HMI\listicon_16px\207E_e.png
    PROPERTY(0x2000035e)                // 800x480\HMINissanResources\HMI\listicon_16px\207E_e.png
    PROPERTY(0x2000035f)                // 800x480\HMINissanResources\HMI\listicon_16px\207E_f.png
    PROPERTY(0x20000360)                // 800x480\HMINissanResources\HMI\listicon_16px\207E_p.png
    PROPERTY(0x20000361)                // 800x480\HMINissanResources\HMI\listicon_16px\207E_a.png
    PROPERTY(0x20000362)                // 800x480\HMINissanResources\HMI\listicon_16px\207E_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R156_919, 6)
    PROPERTY(0x20000363)                // 800x480\HMINissanResources\HMI\listicon_16px\107F_e.png
    PROPERTY(0x20000363)                // 800x480\HMINissanResources\HMI\listicon_16px\107F_e.png
    PROPERTY(0x20000364)                // 800x480\HMINissanResources\HMI\listicon_16px\107F_f.png
    PROPERTY(0x20000365)                // 800x480\HMINissanResources\HMI\listicon_16px\107F_p.png
    PROPERTY(0x20000366)                // 800x480\HMINissanResources\HMI\listicon_16px\107F_a.png
    PROPERTY(0x20000367)                // 800x480\HMINissanResources\HMI\listicon_16px\107F_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R157, 6)
    PROPERTY(0x20000368)                // 800x480\HMINissanResources\HMI\listicon_16px\207F_e.png
    PROPERTY(0x20000368)                // 800x480\HMINissanResources\HMI\listicon_16px\207F_e.png
    PROPERTY(0x20000369)                // 800x480\HMINissanResources\HMI\listicon_16px\207F_f.png
    PROPERTY(0x2000036a)                // 800x480\HMINissanResources\HMI\listicon_16px\207F_p.png
    PROPERTY(0x2000036b)                // 800x480\HMINissanResources\HMI\listicon_16px\207F_a.png
    PROPERTY(0x2000036c)                // 800x480\HMINissanResources\HMI\listicon_16px\207F_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R161_920, 6)
    PROPERTY(0x2000036d)                // 800x480\HMINissanResources\HMI\listicon_16px\2080_e.png
    PROPERTY(0x2000036d)                // 800x480\HMINissanResources\HMI\listicon_16px\2080_e.png
    PROPERTY(0x2000036e)                // 800x480\HMINissanResources\HMI\listicon_16px\2080_f.png
    PROPERTY(0x2000036f)                // 800x480\HMINissanResources\HMI\listicon_16px\2080_p.png
    PROPERTY(0x20000370)                // 800x480\HMINissanResources\HMI\listicon_16px\2080_a.png
    PROPERTY(0x20000371)                // 800x480\HMINissanResources\HMI\listicon_16px\2080_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R166_921, 6)
    PROPERTY(0x20000372)                // 800x480\HMINissanResources\HMI\listicon_16px\2081_e.png
    PROPERTY(0x20000372)                // 800x480\HMINissanResources\HMI\listicon_16px\2081_e.png
    PROPERTY(0x20000373)                // 800x480\HMINissanResources\HMI\listicon_16px\2081_f.png
    PROPERTY(0x20000374)                // 800x480\HMINissanResources\HMI\listicon_16px\2081_p.png
    PROPERTY(0x20000375)                // 800x480\HMINissanResources\HMI\listicon_16px\2081_a.png
    PROPERTY(0x20000376)                // 800x480\HMINissanResources\HMI\listicon_16px\2081_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R171_922, 6)
    PROPERTY(0x20000377)                // 800x480\HMINissanResources\HMI\listicon_16px\2082_e.png
    PROPERTY(0x20000377)                // 800x480\HMINissanResources\HMI\listicon_16px\2082_e.png
    PROPERTY(0x20000378)                // 800x480\HMINissanResources\HMI\listicon_16px\2082_f.png
    PROPERTY(0x20000379)                // 800x480\HMINissanResources\HMI\listicon_16px\2082_p.png
    PROPERTY(0x2000037a)                // 800x480\HMINissanResources\HMI\listicon_16px\2082_a.png
    PROPERTY(0x2000037b)                // 800x480\HMINissanResources\HMI\listicon_16px\2082_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R176_923, 6)
    PROPERTY(0x2000037c)                // 800x480\HMINissanResources\HMI\listicon_16px\2083_e.png
    PROPERTY(0x2000037c)                // 800x480\HMINissanResources\HMI\listicon_16px\2083_e.png
    PROPERTY(0x2000037d)                // 800x480\HMINissanResources\HMI\listicon_16px\2083_f.png
    PROPERTY(0x2000037e)                // 800x480\HMINissanResources\HMI\listicon_16px\2083_p.png
    PROPERTY(0x2000037f)                // 800x480\HMINissanResources\HMI\listicon_16px\2083_a.png
    PROPERTY(0x20000380)                // 800x480\HMINissanResources\HMI\listicon_16px\2083_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R181_924, 6)
    PROPERTY(0x20000381)                // 800x480\HMINissanResources\HMI\listicon_16px\2084_e.png
    PROPERTY(0x20000381)                // 800x480\HMINissanResources\HMI\listicon_16px\2084_e.png
    PROPERTY(0x20000382)                // 800x480\HMINissanResources\HMI\listicon_16px\2084_f.png
    PROPERTY(0x20000383)                // 800x480\HMINissanResources\HMI\listicon_16px\2084_p.png
    PROPERTY(0x20000384)                // 800x480\HMINissanResources\HMI\listicon_16px\2084_a.png
    PROPERTY(0x20000385)                // 800x480\HMINissanResources\HMI\listicon_16px\2084_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R186_925, 6)
    PROPERTY(0x20000386)                // 800x480\HMINissanResources\HMI\listicon_16px\2085_e.png
    PROPERTY(0x20000386)                // 800x480\HMINissanResources\HMI\listicon_16px\2085_e.png
    PROPERTY(0x20000387)                // 800x480\HMINissanResources\HMI\listicon_16px\2085_f.png
    PROPERTY(0x20000388)                // 800x480\HMINissanResources\HMI\listicon_16px\2085_p.png
    PROPERTY(0x20000389)                // 800x480\HMINissanResources\HMI\listicon_16px\2085_a.png
    PROPERTY(0x2000038a)                // 800x480\HMINissanResources\HMI\listicon_16px\2085_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R191_926, 6)
    PROPERTY(0x2000038b)                // 800x480\HMINissanResources\HMI\listicon_16px\2086_e.png
    PROPERTY(0x2000038b)                // 800x480\HMINissanResources\HMI\listicon_16px\2086_e.png
    PROPERTY(0x2000038c)                // 800x480\HMINissanResources\HMI\listicon_16px\2086_f.png
    PROPERTY(0x2000038d)                // 800x480\HMINissanResources\HMI\listicon_16px\2086_p.png
    PROPERTY(0x2000038e)                // 800x480\HMINissanResources\HMI\listicon_16px\2086_a.png
    PROPERTY(0x2000038f)                // 800x480\HMINissanResources\HMI\listicon_16px\2086_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R196_927, 6)
    PROPERTY(0x20000390)                // 800x480\HMINissanResources\HMI\listicon_16px\2087_e.png
    PROPERTY(0x20000390)                // 800x480\HMINissanResources\HMI\listicon_16px\2087_e.png
    PROPERTY(0x20000391)                // 800x480\HMINissanResources\HMI\listicon_16px\2087_f.png
    PROPERTY(0x20000392)                // 800x480\HMINissanResources\HMI\listicon_16px\2087_p.png
    PROPERTY(0x20000393)                // 800x480\HMINissanResources\HMI\listicon_16px\2087_a.png
    PROPERTY(0x20000394)                // 800x480\HMINissanResources\HMI\listicon_16px\2087_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R201_928, 6)
    PROPERTY(0x20000395)                // 800x480\HMINissanResources\HMI\listicon_16px\2088_e.png
    PROPERTY(0x20000395)                // 800x480\HMINissanResources\HMI\listicon_16px\2088_e.png
    PROPERTY(0x20000396)                // 800x480\HMINissanResources\HMI\listicon_16px\2088_f.png
    PROPERTY(0x20000397)                // 800x480\HMINissanResources\HMI\listicon_16px\2088_p.png
    PROPERTY(0x20000398)                // 800x480\HMINissanResources\HMI\listicon_16px\2088_a.png
    PROPERTY(0x20000399)                // 800x480\HMINissanResources\HMI\listicon_16px\2088_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R206_929, 6)
    PROPERTY(0x2000039a)                // 800x480\HMINissanResources\HMI\listicon_16px\2089_e.png
    PROPERTY(0x2000039a)                // 800x480\HMINissanResources\HMI\listicon_16px\2089_e.png
    PROPERTY(0x2000039b)                // 800x480\HMINissanResources\HMI\listicon_16px\2089_f.png
    PROPERTY(0x2000039c)                // 800x480\HMINissanResources\HMI\listicon_16px\2089_p.png
    PROPERTY(0x2000039d)                // 800x480\HMINissanResources\HMI\listicon_16px\2089_a.png
    PROPERTY(0x2000039e)                // 800x480\HMINissanResources\HMI\listicon_16px\2089_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R211_930, 6)
    PROPERTY(0x2000039f)                // 800x480\HMINissanResources\HMI\listicon_16px\20A0_e.png
    PROPERTY(0x2000039f)                // 800x480\HMINissanResources\HMI\listicon_16px\20A0_e.png
    PROPERTY(0x200003a0)                // 800x480\HMINissanResources\HMI\listicon_16px\20A0_f.png
    PROPERTY(0x200003a1)                // 800x480\HMINissanResources\HMI\listicon_16px\20A0_p.png
    PROPERTY(0x200003a2)                // 800x480\HMINissanResources\HMI\listicon_16px\20A0_a.png
    PROPERTY(0x200003a3)                // 800x480\HMINissanResources\HMI\listicon_16px\20A0_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R216_931, 6)
    PROPERTY(0x200003a4)                // 800x480\HMINissanResources\HMI\listicon_16px\10A1_e.png
    PROPERTY(0x200003a4)                // 800x480\HMINissanResources\HMI\listicon_16px\10A1_e.png
    PROPERTY(0x200003a5)                // 800x480\HMINissanResources\HMI\listicon_16px\10A1_f.png
    PROPERTY(0x200003a6)                // 800x480\HMINissanResources\HMI\listicon_16px\10A1_p.png
    PROPERTY(0x200003a7)                // 800x480\HMINissanResources\HMI\listicon_16px\10A1_a.png
    PROPERTY(0x200003a8)                // 800x480\HMINissanResources\HMI\listicon_16px\10A1_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R217, 6)
    PROPERTY(0x200003a9)                // 800x480\HMINissanResources\HMI\listicon_16px\20A1_e.png
    PROPERTY(0x200003a9)                // 800x480\HMINissanResources\HMI\listicon_16px\20A1_e.png
    PROPERTY(0x200003aa)                // 800x480\HMINissanResources\HMI\listicon_16px\20A1_f.png
    PROPERTY(0x200003ab)                // 800x480\HMINissanResources\HMI\listicon_16px\20A1_p.png
    PROPERTY(0x200003ac)                // 800x480\HMINissanResources\HMI\listicon_16px\20A1_a.png
    PROPERTY(0x200003ad)                // 800x480\HMINissanResources\HMI\listicon_16px\20A1_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R221_932, 6)
    PROPERTY(0x200003ae)                // 800x480\HMINissanResources\HMI\listicon_16px\20A2_e.png
    PROPERTY(0x200003ae)                // 800x480\HMINissanResources\HMI\listicon_16px\20A2_e.png
    PROPERTY(0x200003af)                // 800x480\HMINissanResources\HMI\listicon_16px\20A2_f.png
    PROPERTY(0x200003b0)                // 800x480\HMINissanResources\HMI\listicon_16px\20A2_p.png
    PROPERTY(0x200003b1)                // 800x480\HMINissanResources\HMI\listicon_16px\20A2_a.png
    PROPERTY(0x200003b2)                // 800x480\HMINissanResources\HMI\listicon_16px\20A2_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R226_933, 6)
    PROPERTY(0x200003b3)                // 800x480\HMINissanResources\HMI\listicon_16px\10A3_e.png
    PROPERTY(0x200003b3)                // 800x480\HMINissanResources\HMI\listicon_16px\10A3_e.png
    PROPERTY(0x200003b4)                // 800x480\HMINissanResources\HMI\listicon_16px\10A3_f.png
    PROPERTY(0x200003b5)                // 800x480\HMINissanResources\HMI\listicon_16px\10A3_p.png
    PROPERTY(0x200003b6)                // 800x480\HMINissanResources\HMI\listicon_16px\10A3_a.png
    PROPERTY(0x200003b7)                // 800x480\HMINissanResources\HMI\listicon_16px\10A3_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R227, 6)
    PROPERTY(0x200003b8)                // 800x480\HMINissanResources\HMI\listicon_16px\20A3_e.png
    PROPERTY(0x200003b8)                // 800x480\HMINissanResources\HMI\listicon_16px\20A3_e.png
    PROPERTY(0x200003b9)                // 800x480\HMINissanResources\HMI\listicon_16px\20A3_f.png
    PROPERTY(0x200003ba)                // 800x480\HMINissanResources\HMI\listicon_16px\20A3_p.png
    PROPERTY(0x200003bb)                // 800x480\HMINissanResources\HMI\listicon_16px\20A3_a.png
    PROPERTY(0x200003bc)                // 800x480\HMINissanResources\HMI\listicon_16px\20A3_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R231_934, 6)
    PROPERTY(0x200003bd)                // 800x480\HMINissanResources\HMI\listicon_16px\20A4_e.png
    PROPERTY(0x200003bd)                // 800x480\HMINissanResources\HMI\listicon_16px\20A4_e.png
    PROPERTY(0x200003be)                // 800x480\HMINissanResources\HMI\listicon_16px\20A4_f.png
    PROPERTY(0x200003bf)                // 800x480\HMINissanResources\HMI\listicon_16px\20A4_p.png
    PROPERTY(0x200003c0)                // 800x480\HMINissanResources\HMI\listicon_16px\20A4_a.png
    PROPERTY(0x200003c1)                // 800x480\HMINissanResources\HMI\listicon_16px\20A4_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R236, 6)
    PROPERTY(0x200003c2)                // 800x480\HMINissanResources\HMI\listicon_16px\10A5_e.png
    PROPERTY(0x200003c2)                // 800x480\HMINissanResources\HMI\listicon_16px\10A5_e.png
    PROPERTY(0x200003c3)                // 800x480\HMINissanResources\HMI\listicon_16px\10A5_f.png
    PROPERTY(0x200003c4)                // 800x480\HMINissanResources\HMI\listicon_16px\10A5_p.png
    PROPERTY(0x200003c5)                // 800x480\HMINissanResources\HMI\listicon_16px\10A5_a.png
    PROPERTY(0x200003c6)                // 800x480\HMINissanResources\HMI\listicon_16px\10A5_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R237, 6)
    PROPERTY(0x200003c7)                // 800x480\HMINissanResources\HMI\listicon_16px\20A5_e.png
    PROPERTY(0x200003c7)                // 800x480\HMINissanResources\HMI\listicon_16px\20A5_e.png
    PROPERTY(0x200003c8)                // 800x480\HMINissanResources\HMI\listicon_16px\20A5_f.png
    PROPERTY(0x200003c9)                // 800x480\HMINissanResources\HMI\listicon_16px\20A5_p.png
    PROPERTY(0x200003ca)                // 800x480\HMINissanResources\HMI\listicon_16px\20A5_a.png
    PROPERTY(0x200003cb)                // 800x480\HMINissanResources\HMI\listicon_16px\20A5_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R241_935, 6)
    PROPERTY(0x200003cc)                // 800x480\HMINissanResources\HMI\listicon_16px\20A6_e.png
    PROPERTY(0x200003cc)                // 800x480\HMINissanResources\HMI\listicon_16px\20A6_e.png
    PROPERTY(0x200003cd)                // 800x480\HMINissanResources\HMI\listicon_16px\20A6_f.png
    PROPERTY(0x200003ce)                // 800x480\HMINissanResources\HMI\listicon_16px\20A6_p.png
    PROPERTY(0x200003cf)                // 800x480\HMINissanResources\HMI\listicon_16px\20A6_a.png
    PROPERTY(0x200003d0)                // 800x480\HMINissanResources\HMI\listicon_16px\20A6_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R246_936, 6)
    PROPERTY(0x200003d1)                // 800x480\HMINissanResources\HMI\listicon_16px\10A7_e.png
    PROPERTY(0x200003d1)                // 800x480\HMINissanResources\HMI\listicon_16px\10A7_e.png
    PROPERTY(0x200003d2)                // 800x480\HMINissanResources\HMI\listicon_16px\10A7_f.png
    PROPERTY(0x200003d3)                // 800x480\HMINissanResources\HMI\listicon_16px\10A7_p.png
    PROPERTY(0x200003d4)                // 800x480\HMINissanResources\HMI\listicon_16px\10A7_a.png
    PROPERTY(0x200003d5)                // 800x480\HMINissanResources\HMI\listicon_16px\10A7_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R247, 6)
    PROPERTY(0x200003d6)                // 800x480\HMINissanResources\HMI\listicon_16px\20A7_e.png
    PROPERTY(0x200003d6)                // 800x480\HMINissanResources\HMI\listicon_16px\20A7_e.png
    PROPERTY(0x200003d7)                // 800x480\HMINissanResources\HMI\listicon_16px\20A7_f.png
    PROPERTY(0x200003d8)                // 800x480\HMINissanResources\HMI\listicon_16px\20A7_p.png
    PROPERTY(0x200003d9)                // 800x480\HMINissanResources\HMI\listicon_16px\20A7_a.png
    PROPERTY(0x200003da)                // 800x480\HMINissanResources\HMI\listicon_16px\20A7_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R261_937, 6)
    PROPERTY(0x200003db)                // 800x480\HMINissanResources\HMI\listicon_16px\20AA_e.png
    PROPERTY(0x200003db)                // 800x480\HMINissanResources\HMI\listicon_16px\20AA_e.png
    PROPERTY(0x200003dc)                // 800x480\HMINissanResources\HMI\listicon_16px\20AA_f.png
    PROPERTY(0x200003dd)                // 800x480\HMINissanResources\HMI\listicon_16px\20AA_p.png
    PROPERTY(0x200003de)                // 800x480\HMINissanResources\HMI\listicon_16px\20AA_a.png
    PROPERTY(0x200003df)                // 800x480\HMINissanResources\HMI\listicon_16px\20AA_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R266, 6)
    PROPERTY(0x200003e0)                // 800x480\HMINissanResources\HMI\listicon_16px\10AB_e.png
    PROPERTY(0x200003e0)                // 800x480\HMINissanResources\HMI\listicon_16px\10AB_e.png
    PROPERTY(0x200003e1)                // 800x480\HMINissanResources\HMI\listicon_16px\10AB_f.png
    PROPERTY(0x200003e2)                // 800x480\HMINissanResources\HMI\listicon_16px\10AB_p.png
    PROPERTY(0x200003e3)                // 800x480\HMINissanResources\HMI\listicon_16px\10AB_a.png
    PROPERTY(0x200003e4)                // 800x480\HMINissanResources\HMI\listicon_16px\10AB_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R267, 6)
    PROPERTY(0x200003e5)                // 800x480\HMINissanResources\HMI\listicon_16px\20AB_e.png
    PROPERTY(0x200003e5)                // 800x480\HMINissanResources\HMI\listicon_16px\20AB_e.png
    PROPERTY(0x200003e6)                // 800x480\HMINissanResources\HMI\listicon_16px\20AB_f.png
    PROPERTY(0x200003e7)                // 800x480\HMINissanResources\HMI\listicon_16px\20AB_p.png
    PROPERTY(0x200003e8)                // 800x480\HMINissanResources\HMI\listicon_16px\20AB_a.png
    PROPERTY(0x200003e9)                // 800x480\HMINissanResources\HMI\listicon_16px\20AB_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R271, 6)
    PROPERTY(0x200003ea)                // 800x480\HMINissanResources\HMI\listicon_16px\20AC_e.png
    PROPERTY(0x200003ea)                // 800x480\HMINissanResources\HMI\listicon_16px\20AC_e.png
    PROPERTY(0x200003eb)                // 800x480\HMINissanResources\HMI\listicon_16px\20AC_f.png
    PROPERTY(0x200003ec)                // 800x480\HMINissanResources\HMI\listicon_16px\20AC_p.png
    PROPERTY(0x200003ed)                // 800x480\HMINissanResources\HMI\listicon_16px\20AC_a.png
    PROPERTY(0x200003ee)                // 800x480\HMINissanResources\HMI\listicon_16px\20AC_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R276, 6)
    PROPERTY(0x200003ef)                // 800x480\HMINissanResources\HMI\listicon_16px\10AD_e.png
    PROPERTY(0x200003ef)                // 800x480\HMINissanResources\HMI\listicon_16px\10AD_e.png
    PROPERTY(0x200003f0)                // 800x480\HMINissanResources\HMI\listicon_16px\10AD_f.png
    PROPERTY(0x200003f1)                // 800x480\HMINissanResources\HMI\listicon_16px\10AD_p.png
    PROPERTY(0x200003f2)                // 800x480\HMINissanResources\HMI\listicon_16px\10AD_a.png
    PROPERTY(0x200003f3)                // 800x480\HMINissanResources\HMI\listicon_16px\10AD_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R277, 6)
    PROPERTY(0x200003f4)                // 800x480\HMINissanResources\HMI\listicon_16px\20AD_e.png
    PROPERTY(0x200003f4)                // 800x480\HMINissanResources\HMI\listicon_16px\20AD_e.png
    PROPERTY(0x200003f5)                // 800x480\HMINissanResources\HMI\listicon_16px\20AD_f.png
    PROPERTY(0x200003f6)                // 800x480\HMINissanResources\HMI\listicon_16px\20AD_p.png
    PROPERTY(0x200003f7)                // 800x480\HMINissanResources\HMI\listicon_16px\20AD_a.png
    PROPERTY(0x200003f8)                // 800x480\HMINissanResources\HMI\listicon_16px\20AD_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R281, 6)
    PROPERTY(0x200003f9)                // 800x480\HMINissanResources\HMI\listicon_16px\20AE_e.png
    PROPERTY(0x200003f9)                // 800x480\HMINissanResources\HMI\listicon_16px\20AE_e.png
    PROPERTY(0x200003fa)                // 800x480\HMINissanResources\HMI\listicon_16px\20AE_f.png
    PROPERTY(0x200003fb)                // 800x480\HMINissanResources\HMI\listicon_16px\20AE_p.png
    PROPERTY(0x200003fc)                // 800x480\HMINissanResources\HMI\listicon_16px\20AE_a.png
    PROPERTY(0x200003fd)                // 800x480\HMINissanResources\HMI\listicon_16px\20AE_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R286, 6)
    PROPERTY(0x200003fe)                // 800x480\HMINissanResources\HMI\listicon_16px\10AF_e.png
    PROPERTY(0x200003fe)                // 800x480\HMINissanResources\HMI\listicon_16px\10AF_e.png
    PROPERTY(0x200003ff)                // 800x480\HMINissanResources\HMI\listicon_16px\10AF_f.png
    PROPERTY(0x20000400)                // 800x480\HMINissanResources\HMI\listicon_16px\10AF_p.png
    PROPERTY(0x20000401)                // 800x480\HMINissanResources\HMI\listicon_16px\10AF_a.png
    PROPERTY(0x20000402)                // 800x480\HMINissanResources\HMI\listicon_16px\10AF_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R287, 6)
    PROPERTY(0x20000403)                // 800x480\HMINissanResources\HMI\listicon_16px\20AF_e.png
    PROPERTY(0x20000403)                // 800x480\HMINissanResources\HMI\listicon_16px\20AF_e.png
    PROPERTY(0x20000404)                // 800x480\HMINissanResources\HMI\listicon_16px\20AF_f.png
    PROPERTY(0x20000405)                // 800x480\HMINissanResources\HMI\listicon_16px\20AF_p.png
    PROPERTY(0x20000406)                // 800x480\HMINissanResources\HMI\listicon_16px\20AF_a.png
    PROPERTY(0x20000407)                // 800x480\HMINissanResources\HMI\listicon_16px\20AF_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R291, 6)
    PROPERTY(0x20000408)                // 800x480\HMINissanResources\HMI\listicon_16px\20B0_e.png
    PROPERTY(0x20000408)                // 800x480\HMINissanResources\HMI\listicon_16px\20B0_e.png
    PROPERTY(0x20000409)                // 800x480\HMINissanResources\HMI\listicon_16px\20B0_f.png
    PROPERTY(0x2000040a)                // 800x480\HMINissanResources\HMI\listicon_16px\20B0_p.png
    PROPERTY(0x2000040b)                // 800x480\HMINissanResources\HMI\listicon_16px\20B0_a.png
    PROPERTY(0x2000040c)                // 800x480\HMINissanResources\HMI\listicon_16px\20B0_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R293, 6)
    PROPERTY(0x2000040d)                // 800x480\HMINissanResources\HMI\listicon_16px\30B0_e.png
    PROPERTY(0x2000040d)                // 800x480\HMINissanResources\HMI\listicon_16px\30B0_e.png
    PROPERTY(0x2000040e)                // 800x480\HMINissanResources\HMI\listicon_16px\30B0_f.png
    PROPERTY(0x2000040f)                // 800x480\HMINissanResources\HMI\listicon_16px\30B0_p.png
    PROPERTY(0x20000410)                // 800x480\HMINissanResources\HMI\listicon_16px\30B0_a.png
    PROPERTY(0x20000411)                // 800x480\HMINissanResources\HMI\listicon_16px\30B0_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R296, 6)
    PROPERTY(0x20000412)                // 800x480\HMINissanResources\HMI\listicon_16px\10B1_e.png
    PROPERTY(0x20000412)                // 800x480\HMINissanResources\HMI\listicon_16px\10B1_e.png
    PROPERTY(0x20000413)                // 800x480\HMINissanResources\HMI\listicon_16px\10B1_f.png
    PROPERTY(0x20000414)                // 800x480\HMINissanResources\HMI\listicon_16px\10B1_p.png
    PROPERTY(0x20000415)                // 800x480\HMINissanResources\HMI\listicon_16px\10B1_a.png
    PROPERTY(0x20000416)                // 800x480\HMINissanResources\HMI\listicon_16px\10B1_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R297, 6)
    PROPERTY(0x20000417)                // 800x480\HMINissanResources\HMI\listicon_16px\20B1_e.png
    PROPERTY(0x20000417)                // 800x480\HMINissanResources\HMI\listicon_16px\20B1_e.png
    PROPERTY(0x20000418)                // 800x480\HMINissanResources\HMI\listicon_16px\20B1_f.png
    PROPERTY(0x20000419)                // 800x480\HMINissanResources\HMI\listicon_16px\20B1_p.png
    PROPERTY(0x2000041a)                // 800x480\HMINissanResources\HMI\listicon_16px\20B1_a.png
    PROPERTY(0x2000041b)                // 800x480\HMINissanResources\HMI\listicon_16px\20B1_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R301, 6)
    PROPERTY(0x2000041c)                // 800x480\HMINissanResources\HMI\listicon_16px\20B2_e.png
    PROPERTY(0x2000041c)                // 800x480\HMINissanResources\HMI\listicon_16px\20B2_e.png
    PROPERTY(0x2000041d)                // 800x480\HMINissanResources\HMI\listicon_16px\20B2_f.png
    PROPERTY(0x2000041e)                // 800x480\HMINissanResources\HMI\listicon_16px\20B2_p.png
    PROPERTY(0x2000041f)                // 800x480\HMINissanResources\HMI\listicon_16px\20B2_a.png
    PROPERTY(0x20000420)                // 800x480\HMINissanResources\HMI\listicon_16px\20B2_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R306, 6)
    PROPERTY(0x20000421)                // 800x480\HMINissanResources\HMI\listicon_16px\20B3_e.png
    PROPERTY(0x20000421)                // 800x480\HMINissanResources\HMI\listicon_16px\20B3_e.png
    PROPERTY(0x20000422)                // 800x480\HMINissanResources\HMI\listicon_16px\20B3_f.png
    PROPERTY(0x20000423)                // 800x480\HMINissanResources\HMI\listicon_16px\20B3_p.png
    PROPERTY(0x20000424)                // 800x480\HMINissanResources\HMI\listicon_16px\20B3_a.png
    PROPERTY(0x20000425)                // 800x480\HMINissanResources\HMI\listicon_16px\20B3_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R311, 6)
    PROPERTY(0x20000426)                // 800x480\HMINissanResources\HMI\listicon_16px\20B4_e.png
    PROPERTY(0x20000426)                // 800x480\HMINissanResources\HMI\listicon_16px\20B4_e.png
    PROPERTY(0x20000427)                // 800x480\HMINissanResources\HMI\listicon_16px\20B4_f.png
    PROPERTY(0x20000428)                // 800x480\HMINissanResources\HMI\listicon_16px\20B4_p.png
    PROPERTY(0x20000429)                // 800x480\HMINissanResources\HMI\listicon_16px\20B4_a.png
    PROPERTY(0x2000042a)                // 800x480\HMINissanResources\HMI\listicon_16px\20B4_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R316, 6)
    PROPERTY(0x2000042b)                // 800x480\HMINissanResources\HMI\listicon_16px\20B5_e.png
    PROPERTY(0x2000042b)                // 800x480\HMINissanResources\HMI\listicon_16px\20B5_e.png
    PROPERTY(0x2000042c)                // 800x480\HMINissanResources\HMI\listicon_16px\20B5_f.png
    PROPERTY(0x2000042d)                // 800x480\HMINissanResources\HMI\listicon_16px\20B5_p.png
    PROPERTY(0x2000042e)                // 800x480\HMINissanResources\HMI\listicon_16px\20B5_a.png
    PROPERTY(0x2000042f)                // 800x480\HMINissanResources\HMI\listicon_16px\20B5_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R321, 6)
    PROPERTY(0x20000430)                // 800x480\HMINissanResources\HMI\listicon_16px\20B6_e.png
    PROPERTY(0x20000430)                // 800x480\HMINissanResources\HMI\listicon_16px\20B6_e.png
    PROPERTY(0x20000431)                // 800x480\HMINissanResources\HMI\listicon_16px\20B6_f.png
    PROPERTY(0x20000432)                // 800x480\HMINissanResources\HMI\listicon_16px\20B6_p.png
    PROPERTY(0x20000433)                // 800x480\HMINissanResources\HMI\listicon_16px\20B6_a.png
    PROPERTY(0x20000434)                // 800x480\HMINissanResources\HMI\listicon_16px\20B6_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R326, 6)
    PROPERTY(0x20000435)                // 800x480\HMINissanResources\HMI\listicon_16px\20B7_e.png
    PROPERTY(0x20000435)                // 800x480\HMINissanResources\HMI\listicon_16px\20B7_e.png
    PROPERTY(0x20000436)                // 800x480\HMINissanResources\HMI\listicon_16px\20B7_f.png
    PROPERTY(0x20000437)                // 800x480\HMINissanResources\HMI\listicon_16px\20B7_p.png
    PROPERTY(0x20000438)                // 800x480\HMINissanResources\HMI\listicon_16px\20B7_a.png
    PROPERTY(0x20000439)                // 800x480\HMINissanResources\HMI\listicon_16px\20B7_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R331, 6)
    PROPERTY(0x2000043a)                // 800x480\HMINissanResources\HMI\listicon_16px\20B8_e.png
    PROPERTY(0x2000043a)                // 800x480\HMINissanResources\HMI\listicon_16px\20B8_e.png
    PROPERTY(0x2000043b)                // 800x480\HMINissanResources\HMI\listicon_16px\20B8_f.png
    PROPERTY(0x2000043c)                // 800x480\HMINissanResources\HMI\listicon_16px\20B8_p.png
    PROPERTY(0x2000043d)                // 800x480\HMINissanResources\HMI\listicon_16px\20B8_a.png
    PROPERTY(0x2000043e)                // 800x480\HMINissanResources\HMI\listicon_16px\20B8_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R336, 6)
    PROPERTY(0x2000043f)                // 800x480\HMINissanResources\HMI\listicon_16px\10B9_e.png
    PROPERTY(0x2000043f)                // 800x480\HMINissanResources\HMI\listicon_16px\10B9_e.png
    PROPERTY(0x20000440)                // 800x480\HMINissanResources\HMI\listicon_16px\10B9_f.png
    PROPERTY(0x20000441)                // 800x480\HMINissanResources\HMI\listicon_16px\10B9_p.png
    PROPERTY(0x20000442)                // 800x480\HMINissanResources\HMI\listicon_16px\10B9_a.png
    PROPERTY(0x20000443)                // 800x480\HMINissanResources\HMI\listicon_16px\10B9_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R337, 6)
    PROPERTY(0x20000444)                // 800x480\HMINissanResources\HMI\listicon_16px\20B9_e.png
    PROPERTY(0x20000444)                // 800x480\HMINissanResources\HMI\listicon_16px\20B9_e.png
    PROPERTY(0x20000445)                // 800x480\HMINissanResources\HMI\listicon_16px\20B9_f.png
    PROPERTY(0x20000446)                // 800x480\HMINissanResources\HMI\listicon_16px\20B9_p.png
    PROPERTY(0x20000447)                // 800x480\HMINissanResources\HMI\listicon_16px\20B9_a.png
    PROPERTY(0x20000448)                // 800x480\HMINissanResources\HMI\listicon_16px\20B9_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R341, 6)
    PROPERTY(0x20000449)                // 800x480\HMINissanResources\HMI\listicon_16px\20BA_e.png
    PROPERTY(0x20000449)                // 800x480\HMINissanResources\HMI\listicon_16px\20BA_e.png
    PROPERTY(0x2000044a)                // 800x480\HMINissanResources\HMI\listicon_16px\20BA_f.png
    PROPERTY(0x2000044b)                // 800x480\HMINissanResources\HMI\listicon_16px\20BA_p.png
    PROPERTY(0x2000044c)                // 800x480\HMINissanResources\HMI\listicon_16px\20BA_a.png
    PROPERTY(0x2000044d)                // 800x480\HMINissanResources\HMI\listicon_16px\20BA_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R346, 6)
    PROPERTY(0x2000044e)                // 800x480\HMINissanResources\HMI\listicon_16px\20BB_e.png
    PROPERTY(0x2000044e)                // 800x480\HMINissanResources\HMI\listicon_16px\20BB_e.png
    PROPERTY(0x2000044f)                // 800x480\HMINissanResources\HMI\listicon_16px\20BB_f.png
    PROPERTY(0x20000450)                // 800x480\HMINissanResources\HMI\listicon_16px\20BB_p.png
    PROPERTY(0x20000451)                // 800x480\HMINissanResources\HMI\listicon_16px\20BB_a.png
    PROPERTY(0x20000452)                // 800x480\HMINissanResources\HMI\listicon_16px\20BB_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R351, 6)
    PROPERTY(0x20000453)                // 800x480\HMINissanResources\HMI\listicon_16px\10BC_e.png
    PROPERTY(0x20000453)                // 800x480\HMINissanResources\HMI\listicon_16px\10BC_e.png
    PROPERTY(0x20000454)                // 800x480\HMINissanResources\HMI\listicon_16px\10BC_f.png
    PROPERTY(0x20000455)                // 800x480\HMINissanResources\HMI\listicon_16px\10BC_p.png
    PROPERTY(0x20000456)                // 800x480\HMINissanResources\HMI\listicon_16px\10BC_a.png
    PROPERTY(0x20000457)                // 800x480\HMINissanResources\HMI\listicon_16px\10BC_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R352, 6)
    PROPERTY(0x20000458)                // 800x480\HMINissanResources\HMI\listicon_16px\20BC_e.png
    PROPERTY(0x20000458)                // 800x480\HMINissanResources\HMI\listicon_16px\20BC_e.png
    PROPERTY(0x20000459)                // 800x480\HMINissanResources\HMI\listicon_16px\20BC_f.png
    PROPERTY(0x2000045a)                // 800x480\HMINissanResources\HMI\listicon_16px\20BC_p.png
    PROPERTY(0x2000045b)                // 800x480\HMINissanResources\HMI\listicon_16px\20BC_a.png
    PROPERTY(0x2000045c)                // 800x480\HMINissanResources\HMI\listicon_16px\20BC_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R356, 6)
    PROPERTY(0x2000045d)                // 800x480\HMINissanResources\HMI\listicon_16px\20BD_e.png
    PROPERTY(0x2000045d)                // 800x480\HMINissanResources\HMI\listicon_16px\20BD_e.png
    PROPERTY(0x2000045e)                // 800x480\HMINissanResources\HMI\listicon_16px\20BD_f.png
    PROPERTY(0x2000045f)                // 800x480\HMINissanResources\HMI\listicon_16px\20BD_p.png
    PROPERTY(0x20000460)                // 800x480\HMINissanResources\HMI\listicon_16px\20BD_a.png
    PROPERTY(0x20000461)                // 800x480\HMINissanResources\HMI\listicon_16px\20BD_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R366, 6)
    PROPERTY(0x20000462)                // 800x480\HMINissanResources\HMI\listicon_16px\1095_e.png
    PROPERTY(0x20000462)                // 800x480\HMINissanResources\HMI\listicon_16px\1095_e.png
    PROPERTY(0x20000463)                // 800x480\HMINissanResources\HMI\listicon_16px\1095_f.png
    PROPERTY(0x20000464)                // 800x480\HMINissanResources\HMI\listicon_16px\1095_p.png
    PROPERTY(0x20000465)                // 800x480\HMINissanResources\HMI\listicon_16px\1095_a.png
    PROPERTY(0x20000463)                // 800x480\HMINissanResources\HMI\listicon_16px\1095_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R371, 6)
    PROPERTY(0x20000466)                // 800x480\HMINissanResources\HMI\listicon_16px\1090_e.png
    PROPERTY(0x20000466)                // 800x480\HMINissanResources\HMI\listicon_16px\1090_e.png
    PROPERTY(0x20000467)                // 800x480\HMINissanResources\HMI\listicon_16px\1090_f.png
    PROPERTY(0x20000468)                // 800x480\HMINissanResources\HMI\listicon_16px\1090_p.png
    PROPERTY(0x20000469)                // 800x480\HMINissanResources\HMI\listicon_16px\1090_a.png
    PROPERTY(0x20000467)                // 800x480\HMINissanResources\HMI\listicon_16px\1090_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R376, 6)
    PROPERTY(0x2000046a)                // 800x480\HMINissanResources\HMI\listicon_16px\1091_e.png
    PROPERTY(0x2000046a)                // 800x480\HMINissanResources\HMI\listicon_16px\1091_e.png
    PROPERTY(0x2000046b)                // 800x480\HMINissanResources\HMI\listicon_16px\1091_f.png
    PROPERTY(0x2000046c)                // 800x480\HMINissanResources\HMI\listicon_16px\1091_p.png
    PROPERTY(0x2000046d)                // 800x480\HMINissanResources\HMI\listicon_16px\1091_a.png
    PROPERTY(0x2000046b)                // 800x480\HMINissanResources\HMI\listicon_16px\1091_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R381, 6)
    PROPERTY(0x2000046e)                // 800x480\HMINissanResources\HMI\listicon_16px\1092_e.png
    PROPERTY(0x2000046e)                // 800x480\HMINissanResources\HMI\listicon_16px\1092_e.png
    PROPERTY(0x2000046f)                // 800x480\HMINissanResources\HMI\listicon_16px\1092_f.png
    PROPERTY(0x20000470)                // 800x480\HMINissanResources\HMI\listicon_16px\1092_p.png
    PROPERTY(0x20000471)                // 800x480\HMINissanResources\HMI\listicon_16px\1092_a.png
    PROPERTY(0x2000046f)                // 800x480\HMINissanResources\HMI\listicon_16px\1092_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R386, 6)
    PROPERTY(0x20000472)                // 800x480\HMINissanResources\HMI\listicon_16px\1093_e.png
    PROPERTY(0x20000472)                // 800x480\HMINissanResources\HMI\listicon_16px\1093_e.png
    PROPERTY(0x20000473)                // 800x480\HMINissanResources\HMI\listicon_16px\1093_f.png
    PROPERTY(0x20000474)                // 800x480\HMINissanResources\HMI\listicon_16px\1093_p.png
    PROPERTY(0x20000475)                // 800x480\HMINissanResources\HMI\listicon_16px\1093_a.png
    PROPERTY(0x20000473)                // 800x480\HMINissanResources\HMI\listicon_16px\1093_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_TDARRAY(ImagePaths_938, 391)
    PROPERTY_ARRAY_ROW(ImagePaths_R0_887)
    PROPERTY_ARRAY_ROW(ImagePaths_R1_888)
    PROPERTY_ARRAY_ROW(ImagePaths_R1_888)
    PROPERTY_ARRAY_ROW(ImagePaths_R1_888)
    PROPERTY_ARRAY_ROW(ImagePaths_R1_888)
    PROPERTY_ARRAY_ROW(ImagePaths_R1_888)
    PROPERTY_ARRAY_ROW(ImagePaths_R6_889)
    PROPERTY_ARRAY_ROW(ImagePaths_R7)
    PROPERTY_ARRAY_ROW(ImagePaths_R7)
    PROPERTY_ARRAY_ROW(ImagePaths_R6_889)
    PROPERTY_ARRAY_ROW(ImagePaths_R7)
    PROPERTY_ARRAY_ROW(ImagePaths_R11_890)
    PROPERTY_ARRAY_ROW(ImagePaths_R11_890)
    PROPERTY_ARRAY_ROW(ImagePaths_R13)
    PROPERTY_ARRAY_ROW(ImagePaths_R11_890)
    PROPERTY_ARRAY_ROW(ImagePaths_R11_890)
    PROPERTY_ARRAY_ROW(ImagePaths_R16_891)
    PROPERTY_ARRAY_ROW(ImagePaths_R17)
    PROPERTY_ARRAY_ROW(ImagePaths_R17)
    PROPERTY_ARRAY_ROW(ImagePaths_R16_891)
    PROPERTY_ARRAY_ROW(ImagePaths_R17)
    PROPERTY_ARRAY_ROW(ImagePaths_R21_892)
    PROPERTY_ARRAY_ROW(ImagePaths_R21_892)
    PROPERTY_ARRAY_ROW(ImagePaths_R21_892)
    PROPERTY_ARRAY_ROW(ImagePaths_R21_892)
    PROPERTY_ARRAY_ROW(ImagePaths_R21_892)
    PROPERTY_ARRAY_ROW(ImagePaths_R26_893)
    PROPERTY_ARRAY_ROW(ImagePaths_R27)
    PROPERTY_ARRAY_ROW(ImagePaths_R27)
    PROPERTY_ARRAY_ROW(ImagePaths_R26_893)
    PROPERTY_ARRAY_ROW(ImagePaths_R27)
    PROPERTY_ARRAY_ROW(ImagePaths_R31_894)
    PROPERTY_ARRAY_ROW(ImagePaths_R31_894)
    PROPERTY_ARRAY_ROW(ImagePaths_R31_894)
    PROPERTY_ARRAY_ROW(ImagePaths_R31_894)
    PROPERTY_ARRAY_ROW(ImagePaths_R31_894)
    PROPERTY_ARRAY_ROW(ImagePaths_R36_895)
    PROPERTY_ARRAY_ROW(ImagePaths_R37)
    PROPERTY_ARRAY_ROW(ImagePaths_R37)
    PROPERTY_ARRAY_ROW(ImagePaths_R36_895)
    PROPERTY_ARRAY_ROW(ImagePaths_R37)
    PROPERTY_ARRAY_ROW(ImagePaths_R41_896)
    PROPERTY_ARRAY_ROW(ImagePaths_R41_896)
    PROPERTY_ARRAY_ROW(ImagePaths_R41_896)
    PROPERTY_ARRAY_ROW(ImagePaths_R41_896)
    PROPERTY_ARRAY_ROW(ImagePaths_R41_896)
    PROPERTY_ARRAY_ROW(ImagePaths_R46_897)
    PROPERTY_ARRAY_ROW(ImagePaths_R47)
    PROPERTY_ARRAY_ROW(ImagePaths_R47)
    PROPERTY_ARRAY_ROW(ImagePaths_R46_897)
    PROPERTY_ARRAY_ROW(ImagePaths_R47)
    PROPERTY_ARRAY_ROW(ImagePaths_R51_898)
    PROPERTY_ARRAY_ROW(ImagePaths_R51_898)
    PROPERTY_ARRAY_ROW(ImagePaths_R51_898)
    PROPERTY_ARRAY_ROW(ImagePaths_R51_898)
    PROPERTY_ARRAY_ROW(ImagePaths_R51_898)
    PROPERTY_ARRAY_ROW(ImagePaths_R56_899)
    PROPERTY_ARRAY_ROW(ImagePaths_R57)
    PROPERTY_ARRAY_ROW(ImagePaths_R57)
    PROPERTY_ARRAY_ROW(ImagePaths_R56_899)
    PROPERTY_ARRAY_ROW(ImagePaths_R57)
    PROPERTY_ARRAY_ROW(ImagePaths_R61_900)
    PROPERTY_ARRAY_ROW(ImagePaths_R61_900)
    PROPERTY_ARRAY_ROW(ImagePaths_R61_900)
    PROPERTY_ARRAY_ROW(ImagePaths_R61_900)
    PROPERTY_ARRAY_ROW(ImagePaths_R61_900)
    PROPERTY_ARRAY_ROW(ImagePaths_R66_901)
    PROPERTY_ARRAY_ROW(ImagePaths_R67)
    PROPERTY_ARRAY_ROW(ImagePaths_R67)
    PROPERTY_ARRAY_ROW(ImagePaths_R66_901)
    PROPERTY_ARRAY_ROW(ImagePaths_R67)
    PROPERTY_ARRAY_ROW(ImagePaths_R71_902)
    PROPERTY_ARRAY_ROW(ImagePaths_R71_902)
    PROPERTY_ARRAY_ROW(ImagePaths_R71_902)
    PROPERTY_ARRAY_ROW(ImagePaths_R71_902)
    PROPERTY_ARRAY_ROW(ImagePaths_R71_902)
    PROPERTY_ARRAY_ROW(ImagePaths_R76_903)
    PROPERTY_ARRAY_ROW(ImagePaths_R77)
    PROPERTY_ARRAY_ROW(ImagePaths_R77)
    PROPERTY_ARRAY_ROW(ImagePaths_R76_903)
    PROPERTY_ARRAY_ROW(ImagePaths_R77)
    PROPERTY_ARRAY_ROW(ImagePaths_R81_904)
    PROPERTY_ARRAY_ROW(ImagePaths_R81_904)
    PROPERTY_ARRAY_ROW(ImagePaths_R81_904)
    PROPERTY_ARRAY_ROW(ImagePaths_R81_904)
    PROPERTY_ARRAY_ROW(ImagePaths_R81_904)
    PROPERTY_ARRAY_ROW(ImagePaths_R86_905)
    PROPERTY_ARRAY_ROW(ImagePaths_R87)
    PROPERTY_ARRAY_ROW(ImagePaths_R87)
    PROPERTY_ARRAY_ROW(ImagePaths_R86_905)
    PROPERTY_ARRAY_ROW(ImagePaths_R87)
    PROPERTY_ARRAY_ROW(ImagePaths_R91_906)
    PROPERTY_ARRAY_ROW(ImagePaths_R91_906)
    PROPERTY_ARRAY_ROW(ImagePaths_R91_906)
    PROPERTY_ARRAY_ROW(ImagePaths_R91_906)
    PROPERTY_ARRAY_ROW(ImagePaths_R91_906)
    PROPERTY_ARRAY_ROW(ImagePaths_R96_907)
    PROPERTY_ARRAY_ROW(ImagePaths_R97)
    PROPERTY_ARRAY_ROW(ImagePaths_R97)
    PROPERTY_ARRAY_ROW(ImagePaths_R96_907)
    PROPERTY_ARRAY_ROW(ImagePaths_R97)
    PROPERTY_ARRAY_ROW(ImagePaths_R101_908)
    PROPERTY_ARRAY_ROW(ImagePaths_R101_908)
    PROPERTY_ARRAY_ROW(ImagePaths_R101_908)
    PROPERTY_ARRAY_ROW(ImagePaths_R101_908)
    PROPERTY_ARRAY_ROW(ImagePaths_R101_908)
    PROPERTY_ARRAY_ROW(ImagePaths_R106_909)
    PROPERTY_ARRAY_ROW(ImagePaths_R107)
    PROPERTY_ARRAY_ROW(ImagePaths_R107)
    PROPERTY_ARRAY_ROW(ImagePaths_R106_909)
    PROPERTY_ARRAY_ROW(ImagePaths_R107)
    PROPERTY_ARRAY_ROW(ImagePaths_R111_910)
    PROPERTY_ARRAY_ROW(ImagePaths_R111_910)
    PROPERTY_ARRAY_ROW(ImagePaths_R111_910)
    PROPERTY_ARRAY_ROW(ImagePaths_R111_910)
    PROPERTY_ARRAY_ROW(ImagePaths_R111_910)
    PROPERTY_ARRAY_ROW(ImagePaths_R116_911)
    PROPERTY_ARRAY_ROW(ImagePaths_R117)
    PROPERTY_ARRAY_ROW(ImagePaths_R117)
    PROPERTY_ARRAY_ROW(ImagePaths_R116_911)
    PROPERTY_ARRAY_ROW(ImagePaths_R117)
    PROPERTY_ARRAY_ROW(ImagePaths_R121_912)
    PROPERTY_ARRAY_ROW(ImagePaths_R121_912)
    PROPERTY_ARRAY_ROW(ImagePaths_R121_912)
    PROPERTY_ARRAY_ROW(ImagePaths_R121_912)
    PROPERTY_ARRAY_ROW(ImagePaths_R121_912)
    PROPERTY_ARRAY_ROW(ImagePaths_R126_913)
    PROPERTY_ARRAY_ROW(ImagePaths_R127)
    PROPERTY_ARRAY_ROW(ImagePaths_R127)
    PROPERTY_ARRAY_ROW(ImagePaths_R126_913)
    PROPERTY_ARRAY_ROW(ImagePaths_R127)
    PROPERTY_ARRAY_ROW(ImagePaths_R131_914)
    PROPERTY_ARRAY_ROW(ImagePaths_R131_914)
    PROPERTY_ARRAY_ROW(ImagePaths_R131_914)
    PROPERTY_ARRAY_ROW(ImagePaths_R131_914)
    PROPERTY_ARRAY_ROW(ImagePaths_R131_914)
    PROPERTY_ARRAY_ROW(ImagePaths_R136_915)
    PROPERTY_ARRAY_ROW(ImagePaths_R137)
    PROPERTY_ARRAY_ROW(ImagePaths_R137)
    PROPERTY_ARRAY_ROW(ImagePaths_R136_915)
    PROPERTY_ARRAY_ROW(ImagePaths_R137)
    PROPERTY_ARRAY_ROW(ImagePaths_R141_916)
    PROPERTY_ARRAY_ROW(ImagePaths_R141_916)
    PROPERTY_ARRAY_ROW(ImagePaths_R141_916)
    PROPERTY_ARRAY_ROW(ImagePaths_R141_916)
    PROPERTY_ARRAY_ROW(ImagePaths_R141_916)
    PROPERTY_ARRAY_ROW(ImagePaths_R146_917)
    PROPERTY_ARRAY_ROW(ImagePaths_R147)
    PROPERTY_ARRAY_ROW(ImagePaths_R147)
    PROPERTY_ARRAY_ROW(ImagePaths_R146_917)
    PROPERTY_ARRAY_ROW(ImagePaths_R147)
    PROPERTY_ARRAY_ROW(ImagePaths_R151_918)
    PROPERTY_ARRAY_ROW(ImagePaths_R151_918)
    PROPERTY_ARRAY_ROW(ImagePaths_R151_918)
    PROPERTY_ARRAY_ROW(ImagePaths_R151_918)
    PROPERTY_ARRAY_ROW(ImagePaths_R151_918)
    PROPERTY_ARRAY_ROW(ImagePaths_R156_919)
    PROPERTY_ARRAY_ROW(ImagePaths_R157)
    PROPERTY_ARRAY_ROW(ImagePaths_R157)
    PROPERTY_ARRAY_ROW(ImagePaths_R156_919)
    PROPERTY_ARRAY_ROW(ImagePaths_R157)
    PROPERTY_ARRAY_ROW(ImagePaths_R161_920)
    PROPERTY_ARRAY_ROW(ImagePaths_R161_920)
    PROPERTY_ARRAY_ROW(ImagePaths_R161_920)
    PROPERTY_ARRAY_ROW(ImagePaths_R161_920)
    PROPERTY_ARRAY_ROW(ImagePaths_R161_920)
    PROPERTY_ARRAY_ROW(ImagePaths_R166_921)
    PROPERTY_ARRAY_ROW(ImagePaths_R166_921)
    PROPERTY_ARRAY_ROW(ImagePaths_R166_921)
    PROPERTY_ARRAY_ROW(ImagePaths_R166_921)
    PROPERTY_ARRAY_ROW(ImagePaths_R166_921)
    PROPERTY_ARRAY_ROW(ImagePaths_R171_922)
    PROPERTY_ARRAY_ROW(ImagePaths_R171_922)
    PROPERTY_ARRAY_ROW(ImagePaths_R171_922)
    PROPERTY_ARRAY_ROW(ImagePaths_R171_922)
    PROPERTY_ARRAY_ROW(ImagePaths_R171_922)
    PROPERTY_ARRAY_ROW(ImagePaths_R176_923)
    PROPERTY_ARRAY_ROW(ImagePaths_R176_923)
    PROPERTY_ARRAY_ROW(ImagePaths_R176_923)
    PROPERTY_ARRAY_ROW(ImagePaths_R176_923)
    PROPERTY_ARRAY_ROW(ImagePaths_R176_923)
    PROPERTY_ARRAY_ROW(ImagePaths_R181_924)
    PROPERTY_ARRAY_ROW(ImagePaths_R181_924)
    PROPERTY_ARRAY_ROW(ImagePaths_R181_924)
    PROPERTY_ARRAY_ROW(ImagePaths_R181_924)
    PROPERTY_ARRAY_ROW(ImagePaths_R181_924)
    PROPERTY_ARRAY_ROW(ImagePaths_R186_925)
    PROPERTY_ARRAY_ROW(ImagePaths_R186_925)
    PROPERTY_ARRAY_ROW(ImagePaths_R186_925)
    PROPERTY_ARRAY_ROW(ImagePaths_R186_925)
    PROPERTY_ARRAY_ROW(ImagePaths_R186_925)
    PROPERTY_ARRAY_ROW(ImagePaths_R191_926)
    PROPERTY_ARRAY_ROW(ImagePaths_R191_926)
    PROPERTY_ARRAY_ROW(ImagePaths_R191_926)
    PROPERTY_ARRAY_ROW(ImagePaths_R191_926)
    PROPERTY_ARRAY_ROW(ImagePaths_R191_926)
    PROPERTY_ARRAY_ROW(ImagePaths_R196_927)
    PROPERTY_ARRAY_ROW(ImagePaths_R196_927)
    PROPERTY_ARRAY_ROW(ImagePaths_R196_927)
    PROPERTY_ARRAY_ROW(ImagePaths_R196_927)
    PROPERTY_ARRAY_ROW(ImagePaths_R196_927)
    PROPERTY_ARRAY_ROW(ImagePaths_R201_928)
    PROPERTY_ARRAY_ROW(ImagePaths_R201_928)
    PROPERTY_ARRAY_ROW(ImagePaths_R201_928)
    PROPERTY_ARRAY_ROW(ImagePaths_R201_928)
    PROPERTY_ARRAY_ROW(ImagePaths_R201_928)
    PROPERTY_ARRAY_ROW(ImagePaths_R206_929)
    PROPERTY_ARRAY_ROW(ImagePaths_R206_929)
    PROPERTY_ARRAY_ROW(ImagePaths_R206_929)
    PROPERTY_ARRAY_ROW(ImagePaths_R206_929)
    PROPERTY_ARRAY_ROW(ImagePaths_R206_929)
    PROPERTY_ARRAY_ROW(ImagePaths_R211_930)
    PROPERTY_ARRAY_ROW(ImagePaths_R211_930)
    PROPERTY_ARRAY_ROW(ImagePaths_R211_930)
    PROPERTY_ARRAY_ROW(ImagePaths_R211_930)
    PROPERTY_ARRAY_ROW(ImagePaths_R211_930)
    PROPERTY_ARRAY_ROW(ImagePaths_R216_931)
    PROPERTY_ARRAY_ROW(ImagePaths_R217)
    PROPERTY_ARRAY_ROW(ImagePaths_R217)
    PROPERTY_ARRAY_ROW(ImagePaths_R216_931)
    PROPERTY_ARRAY_ROW(ImagePaths_R217)
    PROPERTY_ARRAY_ROW(ImagePaths_R221_932)
    PROPERTY_ARRAY_ROW(ImagePaths_R221_932)
    PROPERTY_ARRAY_ROW(ImagePaths_R221_932)
    PROPERTY_ARRAY_ROW(ImagePaths_R221_932)
    PROPERTY_ARRAY_ROW(ImagePaths_R221_932)
    PROPERTY_ARRAY_ROW(ImagePaths_R226_933)
    PROPERTY_ARRAY_ROW(ImagePaths_R227)
    PROPERTY_ARRAY_ROW(ImagePaths_R227)
    PROPERTY_ARRAY_ROW(ImagePaths_R226_933)
    PROPERTY_ARRAY_ROW(ImagePaths_R227)
    PROPERTY_ARRAY_ROW(ImagePaths_R231_934)
    PROPERTY_ARRAY_ROW(ImagePaths_R231_934)
    PROPERTY_ARRAY_ROW(ImagePaths_R231_934)
    PROPERTY_ARRAY_ROW(ImagePaths_R231_934)
    PROPERTY_ARRAY_ROW(ImagePaths_R231_934)
    PROPERTY_ARRAY_ROW(ImagePaths_R236)
    PROPERTY_ARRAY_ROW(ImagePaths_R237)
    PROPERTY_ARRAY_ROW(ImagePaths_R237)
    PROPERTY_ARRAY_ROW(ImagePaths_R236)
    PROPERTY_ARRAY_ROW(ImagePaths_R237)
    PROPERTY_ARRAY_ROW(ImagePaths_R241_935)
    PROPERTY_ARRAY_ROW(ImagePaths_R241_935)
    PROPERTY_ARRAY_ROW(ImagePaths_R241_935)
    PROPERTY_ARRAY_ROW(ImagePaths_R241_935)
    PROPERTY_ARRAY_ROW(ImagePaths_R241_935)
    PROPERTY_ARRAY_ROW(ImagePaths_R246_936)
    PROPERTY_ARRAY_ROW(ImagePaths_R247)
    PROPERTY_ARRAY_ROW(ImagePaths_R247)
    PROPERTY_ARRAY_ROW(ImagePaths_R246_936)
    PROPERTY_ARRAY_ROW(ImagePaths_R247)
    PROPERTY_ARRAY_ROW(ImagePaths_R126)
    PROPERTY_ARRAY_ROW(ImagePaths_R126)
    PROPERTY_ARRAY_ROW(ImagePaths_R126)
    PROPERTY_ARRAY_ROW(ImagePaths_R126)
    PROPERTY_ARRAY_ROW(ImagePaths_R126)
    PROPERTY_ARRAY_ROW(ImagePaths_R226_933)
    PROPERTY_ARRAY_ROW(ImagePaths_R227)
    PROPERTY_ARRAY_ROW(ImagePaths_R227)
    PROPERTY_ARRAY_ROW(ImagePaths_R226_933)
    PROPERTY_ARRAY_ROW(ImagePaths_R227)
    PROPERTY_ARRAY_ROW(ImagePaths_R261_937)
    PROPERTY_ARRAY_ROW(ImagePaths_R261_937)
    PROPERTY_ARRAY_ROW(ImagePaths_R261_937)
    PROPERTY_ARRAY_ROW(ImagePaths_R261_937)
    PROPERTY_ARRAY_ROW(ImagePaths_R261_937)
    PROPERTY_ARRAY_ROW(ImagePaths_R266)
    PROPERTY_ARRAY_ROW(ImagePaths_R267)
    PROPERTY_ARRAY_ROW(ImagePaths_R267)
    PROPERTY_ARRAY_ROW(ImagePaths_R266)
    PROPERTY_ARRAY_ROW(ImagePaths_R267)
    PROPERTY_ARRAY_ROW(ImagePaths_R271)
    PROPERTY_ARRAY_ROW(ImagePaths_R271)
    PROPERTY_ARRAY_ROW(ImagePaths_R271)
    PROPERTY_ARRAY_ROW(ImagePaths_R271)
    PROPERTY_ARRAY_ROW(ImagePaths_R271)
    PROPERTY_ARRAY_ROW(ImagePaths_R276)
    PROPERTY_ARRAY_ROW(ImagePaths_R277)
    PROPERTY_ARRAY_ROW(ImagePaths_R277)
    PROPERTY_ARRAY_ROW(ImagePaths_R276)
    PROPERTY_ARRAY_ROW(ImagePaths_R277)
    PROPERTY_ARRAY_ROW(ImagePaths_R281)
    PROPERTY_ARRAY_ROW(ImagePaths_R281)
    PROPERTY_ARRAY_ROW(ImagePaths_R281)
    PROPERTY_ARRAY_ROW(ImagePaths_R281)
    PROPERTY_ARRAY_ROW(ImagePaths_R281)
    PROPERTY_ARRAY_ROW(ImagePaths_R286)
    PROPERTY_ARRAY_ROW(ImagePaths_R287)
    PROPERTY_ARRAY_ROW(ImagePaths_R287)
    PROPERTY_ARRAY_ROW(ImagePaths_R286)
    PROPERTY_ARRAY_ROW(ImagePaths_R287)
    PROPERTY_ARRAY_ROW(ImagePaths_R291)
    PROPERTY_ARRAY_ROW(ImagePaths_R291)
    PROPERTY_ARRAY_ROW(ImagePaths_R293)
    PROPERTY_ARRAY_ROW(ImagePaths_R293)
    PROPERTY_ARRAY_ROW(ImagePaths_R291)
    PROPERTY_ARRAY_ROW(ImagePaths_R296)
    PROPERTY_ARRAY_ROW(ImagePaths_R297)
    PROPERTY_ARRAY_ROW(ImagePaths_R173)
    PROPERTY_ARRAY_ROW(ImagePaths_R173)
    PROPERTY_ARRAY_ROW(ImagePaths_R297)
    PROPERTY_ARRAY_ROW(ImagePaths_R301)
    PROPERTY_ARRAY_ROW(ImagePaths_R301)
    PROPERTY_ARRAY_ROW(ImagePaths_R301)
    PROPERTY_ARRAY_ROW(ImagePaths_R301)
    PROPERTY_ARRAY_ROW(ImagePaths_R301)
    PROPERTY_ARRAY_ROW(ImagePaths_R306)
    PROPERTY_ARRAY_ROW(ImagePaths_R306)
    PROPERTY_ARRAY_ROW(ImagePaths_R306)
    PROPERTY_ARRAY_ROW(ImagePaths_R306)
    PROPERTY_ARRAY_ROW(ImagePaths_R306)
    PROPERTY_ARRAY_ROW(ImagePaths_R311)
    PROPERTY_ARRAY_ROW(ImagePaths_R311)
    PROPERTY_ARRAY_ROW(ImagePaths_R311)
    PROPERTY_ARRAY_ROW(ImagePaths_R311)
    PROPERTY_ARRAY_ROW(ImagePaths_R311)
    PROPERTY_ARRAY_ROW(ImagePaths_R316)
    PROPERTY_ARRAY_ROW(ImagePaths_R316)
    PROPERTY_ARRAY_ROW(ImagePaths_R316)
    PROPERTY_ARRAY_ROW(ImagePaths_R316)
    PROPERTY_ARRAY_ROW(ImagePaths_R316)
    PROPERTY_ARRAY_ROW(ImagePaths_R321)
    PROPERTY_ARRAY_ROW(ImagePaths_R321)
    PROPERTY_ARRAY_ROW(ImagePaths_R321)
    PROPERTY_ARRAY_ROW(ImagePaths_R321)
    PROPERTY_ARRAY_ROW(ImagePaths_R321)
    PROPERTY_ARRAY_ROW(ImagePaths_R326)
    PROPERTY_ARRAY_ROW(ImagePaths_R326)
    PROPERTY_ARRAY_ROW(ImagePaths_R326)
    PROPERTY_ARRAY_ROW(ImagePaths_R326)
    PROPERTY_ARRAY_ROW(ImagePaths_R326)
    PROPERTY_ARRAY_ROW(ImagePaths_R331)
    PROPERTY_ARRAY_ROW(ImagePaths_R331)
    PROPERTY_ARRAY_ROW(ImagePaths_R331)
    PROPERTY_ARRAY_ROW(ImagePaths_R331)
    PROPERTY_ARRAY_ROW(ImagePaths_R331)
    PROPERTY_ARRAY_ROW(ImagePaths_R336)
    PROPERTY_ARRAY_ROW(ImagePaths_R337)
    PROPERTY_ARRAY_ROW(ImagePaths_R337)
    PROPERTY_ARRAY_ROW(ImagePaths_R336)
    PROPERTY_ARRAY_ROW(ImagePaths_R337)
    PROPERTY_ARRAY_ROW(ImagePaths_R341)
    PROPERTY_ARRAY_ROW(ImagePaths_R341)
    PROPERTY_ARRAY_ROW(ImagePaths_R341)
    PROPERTY_ARRAY_ROW(ImagePaths_R341)
    PROPERTY_ARRAY_ROW(ImagePaths_R341)
    PROPERTY_ARRAY_ROW(ImagePaths_R346)
    PROPERTY_ARRAY_ROW(ImagePaths_R346)
    PROPERTY_ARRAY_ROW(ImagePaths_R346)
    PROPERTY_ARRAY_ROW(ImagePaths_R346)
    PROPERTY_ARRAY_ROW(ImagePaths_R346)
    PROPERTY_ARRAY_ROW(ImagePaths_R351)
    PROPERTY_ARRAY_ROW(ImagePaths_R352)
    PROPERTY_ARRAY_ROW(ImagePaths_R352)
    PROPERTY_ARRAY_ROW(ImagePaths_R351)
    PROPERTY_ARRAY_ROW(ImagePaths_R352)
    PROPERTY_ARRAY_ROW(ImagePaths_R356)
    PROPERTY_ARRAY_ROW(ImagePaths_R356)
    PROPERTY_ARRAY_ROW(ImagePaths_R356)
    PROPERTY_ARRAY_ROW(ImagePaths_R356)
    PROPERTY_ARRAY_ROW(ImagePaths_R356)
    PROPERTY_ARRAY_ROW(ImagePaths_R131)
    PROPERTY_ARRAY_ROW(ImagePaths_R131)
    PROPERTY_ARRAY_ROW(ImagePaths_R131)
    PROPERTY_ARRAY_ROW(ImagePaths_R131)
    PROPERTY_ARRAY_ROW(ImagePaths_R131)
    PROPERTY_ARRAY_ROW(ImagePaths_R366)
    PROPERTY_ARRAY_ROW(ImagePaths_R366)
    PROPERTY_ARRAY_ROW(ImagePaths_R366)
    PROPERTY_ARRAY_ROW(ImagePaths_R366)
    PROPERTY_ARRAY_ROW(ImagePaths_R366)
    PROPERTY_ARRAY_ROW(ImagePaths_R371)
    PROPERTY_ARRAY_ROW(ImagePaths_R371)
    PROPERTY_ARRAY_ROW(ImagePaths_R371)
    PROPERTY_ARRAY_ROW(ImagePaths_R371)
    PROPERTY_ARRAY_ROW(ImagePaths_R371)
    PROPERTY_ARRAY_ROW(ImagePaths_R376)
    PROPERTY_ARRAY_ROW(ImagePaths_R376)
    PROPERTY_ARRAY_ROW(ImagePaths_R376)
    PROPERTY_ARRAY_ROW(ImagePaths_R376)
    PROPERTY_ARRAY_ROW(ImagePaths_R376)
    PROPERTY_ARRAY_ROW(ImagePaths_R381)
    PROPERTY_ARRAY_ROW(ImagePaths_R381)
    PROPERTY_ARRAY_ROW(ImagePaths_R381)
    PROPERTY_ARRAY_ROW(ImagePaths_R381)
    PROPERTY_ARRAY_ROW(ImagePaths_R381)
    PROPERTY_ARRAY_ROW(ImagePaths_R386)
    PROPERTY_ARRAY_ROW(ImagePaths_R386)
    PROPERTY_ARRAY_ROW(ImagePaths_R386)
    PROPERTY_ARRAY_ROW(ImagePaths_R386)
    PROPERTY_ARRAY_ROW(ImagePaths_R386)
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_939, 9)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000476)                // 800x480\HMINissanResources\HMI\button\li_move_ok_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000477)                // 800x480\HMINissanResources\HMI\button\li_move_ok_e.png
    PROPERTY(0x20000477)                // 800x480\HMINissanResources\HMI\button\li_move_ok_e.png
    PROPERTY(0x20000478)                // 800x480\HMINissanResources\HMI\button\li_move_ok_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_941, 9)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000479)                // 800x480\HMINissanResources\HMI\button\li_move_dwn_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000047a)                // 800x480\HMINissanResources\HMI\button\li_move_dwn_e.png
    PROPERTY(0x2000047a)                // 800x480\HMINissanResources\HMI\button\li_move_dwn_e.png
    PROPERTY(0x2000047b)                // 800x480\HMINissanResources\HMI\button\li_move_dwn_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_943, 9)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000047c)                // 800x480\HMINissanResources\HMI\button\li_move_up_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000047d)                // 800x480\HMINissanResources\HMI\button\li_move_up_e.png
    PROPERTY(0x2000047d)                // 800x480\HMINissanResources\HMI\button\li_move_up_e.png
    PROPERTY(0x2000047e)                // 800x480\HMINissanResources\HMI\button\li_move_up_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_974, 9)
    PROPERTY(0x2000047f)                // 800x480\HMINissanResources\HMI\voice\btn_call_e.png
    PROPERTY(0x2000047f)                // 800x480\HMINissanResources\HMI\voice\btn_call_e.png
    PROPERTY(0x20000480)                // 800x480\HMINissanResources\HMI\voice\btn_call_d.png
    PROPERTY(0x20000480)                // 800x480\HMINissanResources\HMI\voice\btn_call_d.png
    PROPERTY(0x2000047f)                // 800x480\HMINissanResources\HMI\voice\btn_call_e.png
    PROPERTY(0x2000047f)                // 800x480\HMINissanResources\HMI\voice\btn_call_e.png
    PROPERTY(0x20000481)                // 800x480\HMINissanResources\HMI\voice\btn_call_p.png
    PROPERTY(0x2000047f)                // 800x480\HMINissanResources\HMI\voice\btn_call_e.png
    PROPERTY(0x2000047f)                // 800x480\HMINissanResources\HMI\voice\btn_call_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1007, 9)
    PROPERTY(0x20000482)                // 800x480\HMINissanResources\HMI\map\crosshair.png
    PROPERTY(0x20000482)                // 800x480\HMINissanResources\HMI\map\crosshair.png
    PROPERTY(0x20000482)                // 800x480\HMINissanResources\HMI\map\crosshair.png
    PROPERTY(0x20000482)                // 800x480\HMINissanResources\HMI\map\crosshair.png
    PROPERTY(0x20000482)                // 800x480\HMINissanResources\HMI\map\crosshair.png
    PROPERTY(0x20000482)                // 800x480\HMINissanResources\HMI\map\crosshair.png
    PROPERTY(0x20000482)                // 800x480\HMINissanResources\HMI\map\crosshair.png
    PROPERTY(0x20000482)                // 800x480\HMINissanResources\HMI\map\crosshair.png
    PROPERTY(0x20000482)                // 800x480\HMINissanResources\HMI\map\crosshair.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_1031, 17)
    PROPERTY(0x20000484)                // 800x480\HMINissanResources\HMI\header_icons\header_navi_dest.png
    PROPERTY(0x20000484)                // 800x480\HMINissanResources\HMI\header_icons\header_navi_dest.png
    PROPERTY(0x20000485)                // 800x480\HMINissanResources\HMI\header_icons\header_navi_info.png
    PROPERTY(0x20000486)                // 800x480\HMINissanResources\HMI\header_icons\header_navi_settings.png
    PROPERTY(0x20000487)                // 800x480\HMINissanResources\HMI\header_icons\header_navi_traffic.png
    PROPERTY(0x20000488)                // 800x480\HMINissanResources\HMI\header_icons\header_src_aux.png
    PROPERTY(0x20000489)                // 800x480\HMINissanResources\HMI\header_icons\header_src_cd.png
    PROPERTY(0x2000048a)                // 800x480\HMINissanResources\HMI\header_icons\header_src_ipod.png
    PROPERTY(0x2000048b)                // 800x480\HMINissanResources\HMI\header_icons\header_src_phone.png
    PROPERTY(0x2000048c)                // 800x480\HMINissanResources\HMI\header_icons\header_src_radio.png
    PROPERTY(0x2000048d)                // 800x480\HMINissanResources\HMI\header_icons\header_src_usb.png
    PROPERTY(0x2000048e)                // 800x480\HMINissanResources\HMI\header_icons\header_src_xm.png
    PROPERTY(0x2000048f)                // 800x480\HMINissanResources\HMI\header_icons\header_vr.png
    PROPERTY(0x20000490)                // 800x480\HMINissanResources\HMI\header_icons\header_sms.png
    PROPERTY(0x20000491)                // 800x480\HMINissanResources\HMI\header_icons\header_src_sxm.png
    PROPERTY(0x20000492)                // 800x480\HMINissanResources\HMI\header_icons\header_connectservices.png
    PROPERTY(0x20000493)                // 800x480\HMINissanResources\HMI\header_icons\header_siri.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_1040, 3)
    PROPERTY(0xe001c010)                // Display1: 28, Display2: 16
    PROPERTY(0xe0023014)                // Display1: 35, Display2: 20
    PROPERTY(0xe003f024)                // Display1: 63, Display2: 36
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_1041, 4)
    PROPERTY(0x2000049a)                // 800x480\HMINissanResources\HMI\map\icon_curve_left_de.png
    PROPERTY(0x2000049b)                // 800x480\HMINissanResources\HMI\map\icon_curve_right_de.png
    PROPERTY(0x2000049c)                // 800x480\HMINissanResources\HMI\map\icon_s_curve_left_de.png
    PROPERTY(0x2000049d)                // 800x480\HMINissanResources\HMI\map\icon_s_curve_right_de.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_1042, 4)
    PROPERTY(0x2000049e)                // 800x480\HMINissanResources\HMI\map\icon_curve_left_us.png
    PROPERTY(0x2000049f)                // 800x480\HMINissanResources\HMI\map\icon_curve_right_us.png
    PROPERTY(0x200004a0)                // 800x480\HMINissanResources\HMI\map\icon_s_curve_left_us.png
    PROPERTY(0x200004a1)                // 800x480\HMINissanResources\HMI\map\icon_s_curve_right_us.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_1081, 163)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200004a3)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F990.png
    PROPERTY(0x200004a4)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F991.png
    PROPERTY(0x200004a5)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F992.png
    PROPERTY(0x200004a6)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F993.png
    PROPERTY(0x200004a7)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F994.png
    PROPERTY(0x200004a8)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F995.png
    PROPERTY(0x200004a9)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F996.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200004aa)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9A0.png
    PROPERTY(0x200004ab)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9A1.png
    PROPERTY(0x200004ac)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9A2.png
    PROPERTY(0x200004ad)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9A3.png
    PROPERTY(0x200004ae)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9A4.png
    PROPERTY(0x200004af)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9A5.png
    PROPERTY(0x200004b0)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9A6.png
    PROPERTY(0x200004b1)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9A7.png
    PROPERTY(0x200004b2)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9A8.png
    PROPERTY(0x200004b3)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9A9.png
    PROPERTY(0x200004b4)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9AA.png
    PROPERTY(0x200004b5)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9AB.png
    PROPERTY(0x200004b6)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9AC.png
    PROPERTY(0x200004b7)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9AD.png
    PROPERTY(0x200004b8)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9AE.png
    PROPERTY(0x200004b9)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9AF.png
    PROPERTY(0x200004ba)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9B0.png
    PROPERTY(0x200004bb)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9B1.png
    PROPERTY(0x200004bc)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9B2.png
    PROPERTY(0x200004bd)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9B3.png
    PROPERTY(0x200004be)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9B4.png
    PROPERTY(0x200004bf)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9B5.png
    PROPERTY(0x200004c0)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9B6.png
    PROPERTY(0x200004c1)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9B7.png
    PROPERTY(0x200004c2)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9B8.png
    PROPERTY(0x200004c3)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9B9.png
    PROPERTY(0x200004c4)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9BA.png
    PROPERTY(0x200004c5)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9BB.png
    PROPERTY(0x200004c6)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9BC.png
    PROPERTY(0x200004c7)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9BD.png
    PROPERTY(0x200004c8)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9BE.png
    PROPERTY(0x200004c9)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9BF.png
    PROPERTY(0x200004ca)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9C0.png
    PROPERTY(0x200004cb)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9C1.png
    PROPERTY(0x200004cc)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9C2.png
    PROPERTY(0x200004cd)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9C3.png
    PROPERTY(0x200004ce)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9C4.png
    PROPERTY(0x200004cf)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9C5.png
    PROPERTY(0x200004d0)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9C6.png
    PROPERTY(0x200004d1)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9C7.png
    PROPERTY(0x200004d2)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9C8.png
    PROPERTY(0x200004d3)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9C9.png
    PROPERTY(0x200004d4)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9CA.png
    PROPERTY(0x200004d5)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9CB.png
    PROPERTY(0x200004d6)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9CC.png
    PROPERTY(0x200004d7)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9CD.png
    PROPERTY(0x200004d8)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9CE.png
    PROPERTY(0x200004d9)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9CF.png
    PROPERTY(0x200004da)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9D0.png
    PROPERTY(0x200004db)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9D1.png
    PROPERTY(0x200004dc)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9D2.png
    PROPERTY(0x200004dd)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9E0.png
    PROPERTY(0x200004de)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9E1.png
    PROPERTY(0x200004df)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9E2.png
    PROPERTY(0x200004e0)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9E3.png
    PROPERTY(0x200004e1)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9E4.png
    PROPERTY(0x200004e2)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9E5.png
    PROPERTY(0x200004e3)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9E6.png
    PROPERTY(0x200004e4)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9E7.png
    PROPERTY(0x200004e5)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9E8.png
    PROPERTY(0x200004e6)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9E9.png
    PROPERTY(0x200004e7)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9EA.png
    PROPERTY(0x200004e8)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9FB.png
    PROPERTY(0x200004e9)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9EC.png
    PROPERTY(0x200004ea)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9ED.png
    PROPERTY(0x200004eb)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9EE.png
    PROPERTY(0x200004ec)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9EF.png
    PROPERTY(0x200004ed)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9F0.png
    PROPERTY(0x200004ee)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9F1.png
    PROPERTY(0x200004ef)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9F2.png
    PROPERTY(0x200004f0)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9F3.png
    PROPERTY(0x200004f1)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9F4.png
    PROPERTY(0x200004f2)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9F5.png
    PROPERTY(0x200004f3)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9F6.png
    PROPERTY(0x200004f4)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9F7.png
    PROPERTY(0x200004f5)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9F8.png
    PROPERTY(0x200004f6)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9F9.png
    PROPERTY(0x200004f7)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9FA.png
    PROPERTY(0x200004e8)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9FB.png
    PROPERTY(0x200004f8)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9FC.png
    PROPERTY(0x200004f9)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9FD.png
    PROPERTY(0x200004fa)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9FE.png
    PROPERTY(0x200004fb)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\F9FF.png
    PROPERTY(0x200004fc)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA00.png
    PROPERTY(0x200004fd)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA01.png
    PROPERTY(0x200004fe)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA02.png
    PROPERTY(0x200004ff)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA03.png
    PROPERTY(0x20000500)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA04.png
    PROPERTY(0x20000501)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA05.png
    PROPERTY(0x20000502)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA06.png
    PROPERTY(0x20000503)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA07.png
    PROPERTY(0x20000504)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA08.png
    PROPERTY(0x20000505)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA09.png
    PROPERTY(0x20000506)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA0A.png
    PROPERTY(0x20000507)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA0B.png
    PROPERTY(0x20000508)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA0C.png
    PROPERTY(0x20000509)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA0D.png
    PROPERTY(0x2000050a)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA0E.png
    PROPERTY(0x2000050b)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA0F.png
    PROPERTY(0x2000050c)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA10.png
    PROPERTY(0x2000050d)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA11.png
    PROPERTY(0x2000050e)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA12.png
    PROPERTY(0x2000050f)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA20.png
    PROPERTY(0x20000510)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA21.png
    PROPERTY(0x20000511)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA22.png
    PROPERTY(0x20000512)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA23.png
    PROPERTY(0x20000513)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA24.png
    PROPERTY(0x20000514)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA25.png
    PROPERTY(0x20000515)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA26.png
    PROPERTY(0x20000516)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA27.png
    PROPERTY(0x20000517)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA28.png
    PROPERTY(0x20000518)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA29.png
    PROPERTY(0x20000519)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA2A.png
    PROPERTY(0x2000051a)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA2B.png
    PROPERTY(0x2000051b)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA2C.png
    PROPERTY(0x2000051c)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA2D.png
    PROPERTY(0x2000051d)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA2E.png
    PROPERTY(0x2000051e)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA2F.png
    PROPERTY(0x2000051f)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA30.png
    PROPERTY(0x20000520)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA31.png
    PROPERTY(0x20000521)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA32.png
    PROPERTY(0x20000522)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA33.png
    PROPERTY(0x20000523)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA34.png
    PROPERTY(0x20000524)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA35.png
    PROPERTY(0x20000525)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA36.png
    PROPERTY(0x20000526)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA37.png
    PROPERTY(0x20000527)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA38.png
    PROPERTY(0x20000528)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA39.png
    PROPERTY(0x20000529)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA3A.png
    PROPERTY(0x2000052a)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA3B.png
    PROPERTY(0x2000052b)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA3C.png
    PROPERTY(0x2000052c)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA3D.png
    PROPERTY(0x2000052d)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA3E.png
    PROPERTY(0x2000052e)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA3F.png
    PROPERTY(0x2000052f)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA40.png
    PROPERTY(0x20000530)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA41.png
    PROPERTY(0x20000531)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA42.png
    PROPERTY(0x20000532)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA43.png
    PROPERTY(0x20000533)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA44.png
    PROPERTY(0x20000534)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA45.png
    PROPERTY(0x20000535)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA46.png
    PROPERTY(0x20000536)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA47.png
    PROPERTY(0x20000537)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA48.png
    PROPERTY(0x20000538)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA49.png
    PROPERTY(0x20000539)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA4A.png
    PROPERTY(0x2000053a)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA4B.png
    PROPERTY(0x2000053b)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA4C.png
    PROPERTY(0x2000053c)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA4D.png
    PROPERTY(0x2000053d)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA4E.png
    PROPERTY(0x2000053e)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA4F.png
    PROPERTY(0x2000053f)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA50.png
    PROPERTY(0x20000540)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA51.png
    PROPERTY(0x20000541)                // 800x480\HMINissanResources\HMI\Icon_LaneGuidance\FA52.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1089, 9)
    PROPERTY(0x20000542)                // 800x480\HMINissanResources\HMI\button\btn_map_1_map_e.png
    PROPERTY(0x20000543)                // 800x480\HMINissanResources\HMI\button\btn_map_1_map_e_f.png
    PROPERTY(0x20000544)                // 800x480\HMINissanResources\HMI\button\btn_map_1_map_d.png
    PROPERTY(0x20000544)                // 800x480\HMINissanResources\HMI\button\btn_map_1_map_d.png
    PROPERTY(0x20000542)                // 800x480\HMINissanResources\HMI\button\btn_map_1_map_e.png
    PROPERTY(0x20000543)                // 800x480\HMINissanResources\HMI\button\btn_map_1_map_e_f.png
    PROPERTY(0x20000545)                // 800x480\HMINissanResources\HMI\button\btn_map_1_map_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_1091, 1)
    PROPERTY(0xe0022013)                // Display1: 34, Display2: 19
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1093, 9)
    PROPERTY(0x20000546)                // 800x480\HMINissanResources\HMI\button\btn_map_2_map_e.png
    PROPERTY(0x20000547)                // 800x480\HMINissanResources\HMI\button\btn_map_2_map_e_f.png
    PROPERTY(0x20000548)                // 800x480\HMINissanResources\HMI\button\btn_map_2_map_d.png
    PROPERTY(0x20000548)                // 800x480\HMINissanResources\HMI\button\btn_map_2_map_d.png
    PROPERTY(0x20000546)                // 800x480\HMINissanResources\HMI\button\btn_map_2_map_e.png
    PROPERTY(0x20000547)                // 800x480\HMINissanResources\HMI\button\btn_map_2_map_e_f.png
    PROPERTY(0x20000549)                // 800x480\HMINissanResources\HMI\button\btn_map_2_map_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1097, 9)
    PROPERTY(0x2000054a)                // 800x480\HMINissanResources\HMI\button\btn_map_3_map_e.png
    PROPERTY(0x2000054b)                // 800x480\HMINissanResources\HMI\button\btn_map_3_map_e_f.png
    PROPERTY(0x2000054c)                // 800x480\HMINissanResources\HMI\button\btn_map_3_map_d.png
    PROPERTY(0x2000054c)                // 800x480\HMINissanResources\HMI\button\btn_map_3_map_d.png
    PROPERTY(0x2000054a)                // 800x480\HMINissanResources\HMI\button\btn_map_3_map_e.png
    PROPERTY(0x2000054b)                // 800x480\HMINissanResources\HMI\button\btn_map_3_map_e_f.png
    PROPERTY(0x2000054d)                // 800x480\HMINissanResources\HMI\button\btn_map_3_map_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1101, 9)
    PROPERTY(0x2000054e)                // 800x480\HMINissanResources\HMI\button\btn_map_4_map_e.png
    PROPERTY(0x2000054f)                // 800x480\HMINissanResources\HMI\button\btn_map_4_map_e_f.png
    PROPERTY(0x20000550)                // 800x480\HMINissanResources\HMI\button\btn_map_4_map_d.png
    PROPERTY(0x20000550)                // 800x480\HMINissanResources\HMI\button\btn_map_4_map_d.png
    PROPERTY(0x2000054e)                // 800x480\HMINissanResources\HMI\button\btn_map_4_map_e.png
    PROPERTY(0x2000054f)                // 800x480\HMINissanResources\HMI\button\btn_map_4_map_e_f.png
    PROPERTY(0x20000551)                // 800x480\HMINissanResources\HMI\button\btn_map_4_map_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1105, 9)
    PROPERTY(0x20000552)                // 800x480\HMINissanResources\HMI\button\btn_map_5_map_e.png
    PROPERTY(0x20000553)                // 800x480\HMINissanResources\HMI\button\btn_map_5_map_e_f.png
    PROPERTY(0x20000554)                // 800x480\HMINissanResources\HMI\button\btn_map_5_map_d.png
    PROPERTY(0x20000554)                // 800x480\HMINissanResources\HMI\button\btn_map_5_map_d.png
    PROPERTY(0x20000552)                // 800x480\HMINissanResources\HMI\button\btn_map_5_map_e.png
    PROPERTY(0x20000553)                // 800x480\HMINissanResources\HMI\button\btn_map_5_map_e_f.png
    PROPERTY(0x20000555)                // 800x480\HMINissanResources\HMI\button\btn_map_5_map_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1109, 9)
    PROPERTY(0x20000556)                // 800x480\HMINissanResources\HMI\button\btn_map_6_map_e.png
    PROPERTY(0x20000557)                // 800x480\HMINissanResources\HMI\button\btn_map_6_map_e_f.png
    PROPERTY(0x20000558)                // 800x480\HMINissanResources\HMI\button\btn_map_6_map_d.png
    PROPERTY(0x20000558)                // 800x480\HMINissanResources\HMI\button\btn_map_6_map_d.png
    PROPERTY(0x20000556)                // 800x480\HMINissanResources\HMI\button\btn_map_6_map_e.png
    PROPERTY(0x20000557)                // 800x480\HMINissanResources\HMI\button\btn_map_6_map_e_f.png
    PROPERTY(0x20000559)                // 800x480\HMINissanResources\HMI\button\btn_map_6_map_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1112, 9)
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x20000072)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_1117, 7)
    PROPERTY(0x2000055a)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_a.png
    PROPERTY(0x2000055a)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_a.png
    PROPERTY(0x2000055b)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000055c)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_e.png
    PROPERTY(0x2000055a)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_a.png
    PROPERTY(0x2000055d)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_1119, 7)
    PROPERTY(0x2000055a)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_a.png
    PROPERTY(0x2000055a)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_a.png
    PROPERTY(0x2000055b)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_d.png
    PROPERTY(0x2000055b)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_d.png
    PROPERTY(0x2000055c)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_e.png
    PROPERTY(0x2000055a)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_a.png
    PROPERTY(0x2000055d)                // 800x480\HMINissanResources\HMI\icons_radio\radio_replay_small_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(NAV_MAP__strlstSwitchRoad, 3)
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800007bd)                // Detecting alternative Roads -> NAV_MAP__strlstSwitchRoad-001
    PROPERTY(0x800007be)                // No alternative Roads available -> NAV_MAP__strlstSwitchRoad-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_1239, 20)
    PROPERTY(0x2000055e)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_0.png
    PROPERTY(0x2000055f)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_1.png
    PROPERTY(0x20000560)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_2.png
    PROPERTY(0x20000561)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_3.png
    PROPERTY(0x20000562)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_4.png
    PROPERTY(0x20000563)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_5.png
    PROPERTY(0x20000564)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_6.png
    PROPERTY(0x20000565)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_7.png
    PROPERTY(0x20000566)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_8.png
    PROPERTY(0x20000567)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_9.png
    PROPERTY(0x20000568)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_19.png
    PROPERTY(0x20000569)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_10.png
    PROPERTY(0x2000056a)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_11.png
    PROPERTY(0x2000056b)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_12.png
    PROPERTY(0x2000056c)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_13.png
    PROPERTY(0x2000056d)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_14.png
    PROPERTY(0x2000056e)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_15.png
    PROPERTY(0x2000056f)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_16.png
    PROPERTY(0x20000570)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_17.png
    PROPERTY(0x20000571)                // 800x480\HMINissanResources\HMI\route_exit_view\route_exit_name_18.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(textColorArray_1240, 2)
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10000000)                // 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1272, 9)
    PROPERTY(0x20000573)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_long_e.png
    PROPERTY(0x20000574)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_long_e_f.png
    PROPERTY(0x20000575)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_long_d.png
    PROPERTY(0x20000575)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_long_d.png
    PROPERTY(0x20000573)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_long_e.png
    PROPERTY(0x20000574)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_long_e_f.png
    PROPERTY(0x20000576)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_long_p.png
    PROPERTY(0x20000573)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_long_e.png
    PROPERTY(0x20000573)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_long_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1275, 9)
    PROPERTY(0x20000577)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_very_short_e.png
    PROPERTY(0x20000578)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_very_short_e_f.png
    PROPERTY(0x20000579)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_very_short_d.png
    PROPERTY(0x20000579)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_very_short_d.png
    PROPERTY(0x20000577)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_very_short_e.png
    PROPERTY(0x20000578)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_very_short_e_f.png
    PROPERTY(0x2000057a)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_very_short_p.png
    PROPERTY(0x20000577)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_very_short_e.png
    PROPERTY(0x20000577)                // 800x480\HMINissanResources\HMI\button_destentry\if_destentry_very_short_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1280, 9)
    PROPERTY(0x2000057b)                // 800x480\HMINissanResources\HMI\button\btn_ok_e.png
    PROPERTY(0x2000057c)                // 800x480\HMINissanResources\HMI\button\btn_ok_e_f.png
    PROPERTY(0x2000057d)                // 800x480\HMINissanResources\HMI\button\btn_ok_d.png
    PROPERTY(0x2000057d)                // 800x480\HMINissanResources\HMI\button\btn_ok_d.png
    PROPERTY(0x2000057b)                // 800x480\HMINissanResources\HMI\button\btn_ok_e.png
    PROPERTY(0x2000057c)                // 800x480\HMINissanResources\HMI\button\btn_ok_e_f.png
    PROPERTY(0x2000057e)                // 800x480\HMINissanResources\HMI\button\btn_ok_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1920, 9)
    PROPERTY(0x20000581)                // 800x480\HMINissanResources\HMI\button_destentry\if_searchstate_e.png
    PROPERTY(0x20000582)                // 800x480\HMINissanResources\HMI\button_destentry\if_searchstate_e_f.png
    PROPERTY(0x20000583)                // 800x480\HMINissanResources\HMI\button_destentry\if_searchstate_d.png
    PROPERTY(0x20000583)                // 800x480\HMINissanResources\HMI\button_destentry\if_searchstate_d.png
    PROPERTY(0x20000581)                // 800x480\HMINissanResources\HMI\button_destentry\if_searchstate_e.png
    PROPERTY(0x20000582)                // 800x480\HMINissanResources\HMI\button_destentry\if_searchstate_e_f.png
    PROPERTY(0x20000584)                // 800x480\HMINissanResources\HMI\button_destentry\if_searchstate_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_1922, 1)
    PROPERTY(0xe0000000)                // Display1: 0, Display2: 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_1926, 9)
    PROPERTY(0x20000585)                // 800x480\HMINissanResources\HMI\button_destentry\btn_destentry_e.png
    PROPERTY(0x20000586)                // 800x480\HMINissanResources\HMI\button_destentry\btn_destentry_e_f.png
    PROPERTY(0x20000587)                // 800x480\HMINissanResources\HMI\button_destentry\btn_destentry_d.png
    PROPERTY(0x20000587)                // 800x480\HMINissanResources\HMI\button_destentry\btn_destentry_d.png
    PROPERTY(0x20000585)                // 800x480\HMINissanResources\HMI\button_destentry\btn_destentry_e.png
    PROPERTY(0x20000586)                // 800x480\HMINissanResources\HMI\button_destentry\btn_destentry_e_f.png
    PROPERTY(0x20000588)                // 800x480\HMINissanResources\HMI\button_destentry\btn_destentry_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_1928, 3)
    PROPERTY(0xe003101c)                // Display1: 49, Display2: 28
    PROPERTY(0xe001c010)                // Display1: 28, Display2: 16
    PROPERTY(0xe0046028)                // Display1: 70, Display2: 40
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_2257, 3)
    PROPERTY(0x800000a5)                // OFF -> CONST.Navigation.Setup.WarningSettings-000
    PROPERTY(0x80000171)                // Automatic -> NAV.NAV_ROUTEOPTIONS.DYN_GUIDANCE.content-001
    PROPERTY(0x80000172)                // Prompt -> NAV.NAV_ROUTEOPTIONS.DYN_GUIDANCE.content-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_2261, 3)
    PROPERTY(0x80000174)                // Fastest -> NAV.NAV_ROUTEOPTIONS.ltChoiceRoute.content-000
    PROPERTY(0x80000175)                // Eco -> NAV.NAV_ROUTEOPTIONS.ltChoiceRoute.content-001
    PROPERTY(0x80000176)                // Shortest Dist. -> NAV.NAV_ROUTEOPTIONS.ltChoiceRoute.content-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_2266, 2)
    PROPERTY(0x800001db)                // OFF -> NAV_ROUTEOPTIONS.ListItemChoiceAvoiDFerries.content-000
    PROPERTY(0x800001dc)                // ON -> NAV_ROUTEOPTIONS.ListItemChoiceAvoiDFerries.content-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_2270, 2)
    PROPERTY(0x20000261)                // 800x480\HMINissanResources\HMI\choice_buttons\set_radio_btn_off.png
    PROPERTY(0x20000260)                // 800x480\HMINissanResources\HMI\choice_buttons\set_radio_btn_on.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_2291, 3)
    PROPERTY(0x800001dd)                // Never -> NAV_ROUTEOPTIONS.ListItemChoiceAvoidTimeRestrictedroads.content-000
    PROPERTY(0x800001de)                // When Closed -> NAV_ROUTEOPTIONS.ListItemChoiceAvoidTimeRestrictedroads.content-001
    PROPERTY(0x800001df)                // Always -> NAV_ROUTEOPTIONS.ListItemChoiceAvoidTimeRestrictedroads.content-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_2500, 9)
    PROPERTY(0x20000585)                // 800x480\HMINissanResources\HMI\button_destentry\btn_destentry_e.png
    PROPERTY(0x20000029)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_e_f.png
    PROPERTY(0x2000002a)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_d.png
    PROPERTY(0x2000002a)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_d.png
    PROPERTY(0x20000028)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_e.png
    PROPERTY(0x20000029)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_e_f.png
    PROPERTY(0x2000002b)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_2711, 9)
    PROPERTY(0x2000058a)                // 800x480\HMINissanResources\HMI\list\li_6row_22p_e.png
    PROPERTY(0x2000058a)                // 800x480\HMINissanResources\HMI\list\li_6row_22p_e.png
    PROPERTY(0x2000058b)                // 800x480\HMINissanResources\HMI\list\li_6row_22p_d.png
    PROPERTY(0x2000058b)                // 800x480\HMINissanResources\HMI\list\li_6row_22p_d.png
    PROPERTY(0x2000058a)                // 800x480\HMINissanResources\HMI\list\li_6row_22p_e.png
    PROPERTY(0x2000058a)                // 800x480\HMINissanResources\HMI\list\li_6row_22p_e.png
    PROPERTY(0x2000058c)                // 800x480\HMINissanResources\HMI\list\li_6row_22p_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_2714, 9)
    PROPERTY(0x2000058d)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_e.png
    PROPERTY(0x2000058e)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_e_f.png
    PROPERTY(0x2000058f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_d.png
    PROPERTY(0x2000058f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_d.png
    PROPERTY(0x2000058d)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_e.png
    PROPERTY(0x2000058e)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_e_f.png
    PROPERTY(0x20000590)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_2715, 9)
    PROPERTY(0x20000591)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_e.png
    PROPERTY(0x20000592)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_e_f.png
    PROPERTY(0x20000593)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_d.png
    PROPERTY(0x20000593)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_d.png
    PROPERTY(0x20000591)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_e.png
    PROPERTY(0x20000592)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_e_f.png
    PROPERTY(0x20000594)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_2804, 9)
    PROPERTY(0x2000058a)                // 800x480\HMINissanResources\HMI\list\li_6row_22p_e.png
    PROPERTY(0x20000595)                // 800x480\HMINissanResources\HMI\button\btn_map_6row_e_f.png
    PROPERTY(0x2000058b)                // 800x480\HMINissanResources\HMI\list\li_6row_22p_d.png
    PROPERTY(0x2000058b)                // 800x480\HMINissanResources\HMI\list\li_6row_22p_d.png
    PROPERTY(0x2000058a)                // 800x480\HMINissanResources\HMI\list\li_6row_22p_e.png
    PROPERTY(0x20000595)                // 800x480\HMINissanResources\HMI\button\btn_map_6row_e_f.png
    PROPERTY(0x2000058c)                // 800x480\HMINissanResources\HMI\list\li_6row_22p_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_2979, 7)
    PROPERTY(0x20000597)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_mix_a.png
    PROPERTY(0x20000598)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_mix_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000599)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_mix_e.png
    PROPERTY(0x2000059a)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_mix_e_f.png
    PROPERTY(0x2000059b)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_mix_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_2980, 9)
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_2982, 7)
    PROPERTY(0x2000059d)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_repeat_a.png
    PROPERTY(0x2000059e)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_repeat_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000059f)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_repeat_e.png
    PROPERTY(0x200005a0)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_repeat_e_f.png
    PROPERTY(0x200005a1)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_repeat_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_2984, 7)
    PROPERTY(0x200005a2)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_TA_a.png
    PROPERTY(0x200005a3)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_TA_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005a4)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_TA_e.png
    PROPERTY(0x200005a5)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_TA_e_f.png
    PROPERTY(0x200005a6)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_TA_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_2986, 7)
    PROPERTY(0x200005a7)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_browse_a.png
    PROPERTY(0x200005a8)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_browse_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005a9)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_browse_e.png
    PROPERTY(0x200005aa)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_browse_e_f.png
    PROPERTY(0x200005ab)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_browse_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliStatetextCpra_Label_text, 10)
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800006d6)                // Random Folder -> TRA__strliStatetextCpra.Label_text-003
    PROPERTY(0x800006d6)                // Random Folder -> TRA__strliStatetextCpra.Label_text-003
    PROPERTY(0x800006d7)                // Random All -> TRA__strliStatetextCpra.Label_text-005
    PROPERTY(0x800006d8)                // Repeat Track -> TRA__strliStatetextCpra.Label_text-006
    PROPERTY(0x800006d9)                // Repeat Folder -> TRA__strliStatetextCpra.Label_text-007
    PROPERTY(0x800006d9)                // Repeat Folder -> TRA__strliStatetextCpra.Label_text-007
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_3029, 9)
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x2000002a)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_d.png
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x2000059c)                // 800x480\HMINissanResources\HMI\button\btn_audio_4btn_row.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliStatetextCDA_Label_text, 10)
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800000fc)                // Random -> Const_strRandom
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800000fc)                // Random -> Const_strRandom
    PROPERTY(0x800006d4)                // Repeat  -> TRA__strliStatetextCDA.Label_text-006
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800006d5)                // Repeat  -> TRA__strliStatetextCDA.Label_text-009
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_3100, 3)
    PROPERTY(0x200005ad)                // 800x480\HMINissanResources\HMI\icons_app\audio_icon_track.png
    PROPERTY(0x200005ae)                // 800x480\HMINissanResources\HMI\icons_app\audio_icon_folder.png
    PROPERTY(0x200005af)                // 800x480\HMINissanResources\HMI\icons_app\audio_icon_playlist.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_3102, 9)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005b1)                // 800x480\HMINissanResources\HMI\scrollbar\sb_btn_search_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005b2)                // 800x480\HMINissanResources\HMI\scrollbar\sb_btn_search_e.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005b3)                // 800x480\HMINissanResources\HMI\scrollbar\sb_btn_search_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_3213, 2)
    PROPERTY(0xe011109c)                // Display1: 273, Display2: 156
    PROPERTY(0xe01570c4)                // Display1: 343, Display2: 196
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliBTStreamingPausedLabel_text, 5)
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800007b2)                // Device is not able to stream audio. -> TRA__strliBTStreamingPausedLabel_text-002
    PROPERTY(0x800007b3)                // Handset is in use. -> TRA__strliBTStreamingPausedLabel_text-003
    PROPERTY(0x800007b4)                // Apple device is connected via USB and BT -> TRA__strliBTStreamingPausedLabel_text-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_3216, 7)
    PROPERTY(0x200005b4)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_pause_a.png
    PROPERTY(0x200005b5)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_pause_a_f.png
    PROPERTY(0x200005b6)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_pause_d.png
    PROPERTY(0x200005b6)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_pause_d.png
    PROPERTY(0x200005b7)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_pause_e.png
    PROPERTY(0x200005b8)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_pause_e_f.png
    PROPERTY(0x200005b9)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_pause_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_3218, 7)
    PROPERTY(0x200005ba)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_play_a.png
    PROPERTY(0x200005bb)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_play_a_f.png
    PROPERTY(0x200005bc)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_play_d.png
    PROPERTY(0x200005bc)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_play_d.png
    PROPERTY(0x200005bd)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_play_e.png
    PROPERTY(0x200005be)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_play_e_f.png
    PROPERTY(0x200005bf)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_play_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_3221, 7)
    PROPERTY(0x200005c0)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_connect_a.png
    PROPERTY(0x200005c1)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_connect_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005c2)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_connect_e.png
    PROPERTY(0x200005c3)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_connect_e_f.png
    PROPERTY(0x200005c4)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_connect_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliStatetextAUXMediaPlayer_Label_text, 10)
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800006d2)                // Shuffle Songs -> TRA__strliStatetextAUXMediaPlayer.Label_text-005
    PROPERTY(0x800006d3)                // Repeat Song -> TRA__strliStatetextAUXMediaPlayer.Label_text-006
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_3374, 4)
    PROPERTY(0x200005c7)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_bt_audio.png
    PROPERTY(0x200005c8)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_bt_telefonie.png
    PROPERTY(0x200005c9)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_bt_audio_telefonie.png
    PROPERTY(0x200005ca)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_bt.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_3411, 2)
    PROPERTY(0x80000863)                // Short Press -> SET.strliSettingsPhone.ListItemChoice.Siri_VA_StartBy-000
    PROPERTY(0x80000864)                // Long Press -> SET.strliSettingsPhone.ListItemChoice.Siri_VA_StartBy-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_3415, 2)
    PROPERTY(0x800002ae)                // First Name -> SET.strliSettingsPhone.ListItemChoice.Phonebook_Sort.content-000
    PROPERTY(0x800002af)                // Last Name -> SET.strliSettingsPhone.ListItemChoice.Phonebook_Sort.content-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_3420, 3)
    PROPERTY(0x800002ab)                // Handset -> SET.strliSettingsPhone.ListItemChoice.Phonebook.content-000
    PROPERTY(0x800002ac)                // SIM card -> SET.strliSettingsPhone.ListItemChoice.Phonebook.content-001
    PROPERTY(0x800002ad)                // Both -> SET.strliSettingsPhone.ListItemChoice.Phonebook.content-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_3458, 2)
    PROPERTY(0x80000321)                // Both -> SETTINGS_PHONE_NAR.ListItemChoice_Phone_Notification.content-000
    PROPERTY(0x80000322)                // Driver -> SETTINGS_PHONE_NAR.ListItemChoice_Phone_Notification.content-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_3555, 9)
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000db)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_3678, 9)
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x2000027a)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e_f.png
    PROPERTY(0x2000027b)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_d.png
    PROPERTY(0x2000027b)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_d.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x2000027a)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e_f.png
    PROPERTY(0x2000027c)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_p.png
    PROPERTY(0x2000027a)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e_f.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_3722, 3)
    PROPERTY(0x80000866)                // OFF -> SETTINGS__showIncomingText_Meter_Options-000
    PROPERTY(0x80000867)                // DRIVER -> SETTINGS__showIncomingText_Meter_Options-001
    PROPERTY(0x80000868)                // BOTH -> SETTINGS__showIncomingText_Meter_Options-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_4081, 7)
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_4139, 4)
    PROPERTY(0x200005d4)                // 800x480\HMINissanResources\HMI\header_statusline\dwnload01.png
    PROPERTY(0x200005d5)                // 800x480\HMINissanResources\HMI\header_statusline\dwnload02.png
    PROPERTY(0x200005d6)                // 800x480\HMINissanResources\HMI\header_statusline\dwnload03.png
    PROPERTY(0x200005d7)                // 800x480\HMINissanResources\HMI\header_statusline\dwnload04.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4396, 7)
    PROPERTY(0x200005d8)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_toggle_preset_a.png
    PROPERTY(0x200005d9)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_toggle_preset_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005da)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_toggle_preset_e.png
    PROPERTY(0x200005db)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_toggle_preset_e_f.png
    PROPERTY(0x200005dc)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_toggle_preset_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4400, 7)
    PROPERTY(0x200005dd)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_station_list_a.png
    PROPERTY(0x200005de)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_station_list_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005df)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_station_list_e.png
    PROPERTY(0x200005e0)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_station_list_e_f.png
    PROPERTY(0x200005e1)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_station_list_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4405, 7)
    PROPERTY(0x200005e2)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_2nd_audio_a.png
    PROPERTY(0x200005e3)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_2nd_audio_a_f.png
    PROPERTY(0x200005e4)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_2nd_audio_d.png
    PROPERTY(0x200005e4)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_2nd_audio_d.png
    PROPERTY(0x200005e5)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_2nd_audio_e.png
    PROPERTY(0x200005e6)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_2nd_audio_e_f.png
    PROPERTY(0x200005e7)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_2nd_audio_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4565, 7)
    PROPERTY(0x200005e8)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_tune_a.png
    PROPERTY(0x200005e9)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_tune_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005ea)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_tune_e.png
    PROPERTY(0x200005eb)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_tune_e_f.png
    PROPERTY(0x200005ec)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_tune_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4574, 7)
    PROPERTY(0x200005ed)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_hdradio_a.png
    PROPERTY(0x200005ee)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_hdradio_a_f.png
    PROPERTY(0x200005ef)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_hdradio_d.png
    PROPERTY(0x200005ef)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_hdradio_d.png
    PROPERTY(0x200005f0)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_hdradio_e.png
    PROPERTY(0x200005f1)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_hdradio_e_f.png
    PROPERTY(0x200005f2)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_hdradio_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4602, 7)
    PROPERTY(0x200005f3)                // 800x480\HMINissanResources\HMI\icons_radio\radio_hdradio_small_a.png
    PROPERTY(0x200005f3)                // 800x480\HMINissanResources\HMI\icons_radio\radio_hdradio_small_a.png
    PROPERTY(0x200005f4)                // 800x480\HMINissanResources\HMI\icons_radio\radio_hdradio_small_d.png
    PROPERTY(0x200005f4)                // 800x480\HMINissanResources\HMI\icons_radio\radio_hdradio_small_d.png
    PROPERTY(0x200005f5)                // 800x480\HMINissanResources\HMI\icons_radio\radio_hdradio_small_e.png
    PROPERTY(0x200005f6)                // 800x480\HMINissanResources\HMI\icons_radio\radio_hdradio_small_p.png
    PROPERTY(0x200005f6)                // 800x480\HMINissanResources\HMI\icons_radio\radio_hdradio_small_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_4609, 9)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005f8)                // 800x480\HMINissanResources\HMI\icons_radio\btn_hdradio_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005f9)                // 800x480\HMINissanResources\HMI\icons_radio\btn_hdradio_e.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_4624, 9)
    PROPERTY(0x200005ff)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_e.png
    PROPERTY(0x20000600)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_e_f.png
    PROPERTY(0x20000601)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_d.png
    PROPERTY(0x20000601)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_d.png
    PROPERTY(0x200005ff)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_e.png
    PROPERTY(0x20000600)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_e_f.png
    PROPERTY(0x20000602)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_4626, 1)
    PROPERTY(0xe002a018)                // Display1: 42, Display2: 24
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_4628, 9)
    PROPERTY(0x20000603)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_e.png
    PROPERTY(0x20000604)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_e_f.png
    PROPERTY(0x20000605)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_d.png
    PROPERTY(0x20000605)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_d.png
    PROPERTY(0x20000603)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_e.png
    PROPERTY(0x20000604)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_e_f.png
    PROPERTY(0x20000606)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_4707, 9)
    PROPERTY(0x2000057b)                // 800x480\HMINissanResources\HMI\button\btn_ok_e.png
    PROPERTY(0x2000057c)                // 800x480\HMINissanResources\HMI\button\btn_ok_e_f.png
    PROPERTY(0x2000057d)                // 800x480\HMINissanResources\HMI\button\btn_ok_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000057b)                // 800x480\HMINissanResources\HMI\button\btn_ok_e.png
    PROPERTY(0x2000057c)                // 800x480\HMINissanResources\HMI\button\btn_ok_e_f.png
    PROPERTY(0x2000057e)                // 800x480\HMINissanResources\HMI\button\btn_ok_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_4710, 9)
    PROPERTY(0x200005ff)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_e.png
    PROPERTY(0x20000600)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_e_f.png
    PROPERTY(0x20000601)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_d.png
    PROPERTY(0x20000609)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_d_f.png
    PROPERTY(0x200005ff)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_e.png
    PROPERTY(0x20000600)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_e_f.png
    PROPERTY(0x20000602)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_right_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_4713, 9)
    PROPERTY(0x20000603)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_e.png
    PROPERTY(0x20000604)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_e_f.png
    PROPERTY(0x20000605)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_d.png
    PROPERTY(0x2000060a)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_d_f.png
    PROPERTY(0x20000603)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_e.png
    PROPERTY(0x20000604)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_e_f.png
    PROPERTY(0x20000606)                // 800x480\HMINissanResources\HMI\tuner\btn_tuner_left_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__SXMRadio_AdvisoryMessages, 6)
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x8000033c)                // Check Antenna -> Sxm_Fuel__StrliFuelAdvisoryMessage-000
    PROPERTY(0x800000f3)                // No Signal -> Const_strNoSignal
    PROPERTY(0x80000086)                // Loading -> __export_SXM_StrliAPIInfo-036
    PROPERTY(0x80000724)                // Channel Off Air -> TRA__SXMRadio_AdvisoryMessages-004
    PROPERTY(0x80000725)                // Channel Not Available -> TRA__SXMRadio_AdvisoryMessages-005
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4867, 7)
    PROPERTY(0x2000060d)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_ replay_a.png
    PROPERTY(0x2000060e)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_ replay_a_f.png
    PROPERTY(0x2000060f)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_ replay_d.png
    PROPERTY(0x2000060f)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_ replay_d.png
    PROPERTY(0x20000610)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_ replay_e.png
    PROPERTY(0x20000611)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_ replay_e_f.png
    PROPERTY(0x20000612)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_ replay_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4870, 7)
    PROPERTY(0x20000613)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_replay_setup_a.png
    PROPERTY(0x20000614)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_replay_setup_a_f.png
    PROPERTY(0x20000615)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_replay_setup_d.png
    PROPERTY(0x20000615)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_replay_setup_d.png
    PROPERTY(0x20000616)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_replay_setup_e.png
    PROPERTY(0x20000617)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_replay_setup_e_f.png
    PROPERTY(0x20000618)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_replay_setup_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4873, 7)
    PROPERTY(0x20000619)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_category_list_a.png
    PROPERTY(0x2000061a)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_category_list_a_f.png
    PROPERTY(0x2000061b)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_category_list_d.png
    PROPERTY(0x2000061b)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_category_list_d.png
    PROPERTY(0x2000061c)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_category_list_e.png
    PROPERTY(0x2000061d)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_category_list_e_f.png
    PROPERTY(0x2000061e)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_category_list_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4876, 7)
    PROPERTY(0x2000061f)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_exit_a.png
    PROPERTY(0x20000620)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_exit_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000621)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_exit_e.png
    PROPERTY(0x20000622)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_exit_e_f.png
    PROPERTY(0x20000623)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_exit_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4879, 7)
    PROPERTY(0x20000624)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_previous_a.png
    PROPERTY(0x20000625)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_previous_a_f.png
    PROPERTY(0x20000626)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_previous_d.png
    PROPERTY(0x20000626)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_previous_d.png
    PROPERTY(0x20000627)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_previous_e.png
    PROPERTY(0x20000628)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_previous_e_f.png
    PROPERTY(0x20000629)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_previous_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4880, 7)
    PROPERTY(0x200005ba)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_play_a.png
    PROPERTY(0x200005bb)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_play_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005bd)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_play_e.png
    PROPERTY(0x200005be)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_play_e_f.png
    PROPERTY(0x200005bf)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_play_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4881, 7)
    PROPERTY(0x200005b4)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_pause_a.png
    PROPERTY(0x200005b5)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_pause_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200005b7)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_pause_e.png
    PROPERTY(0x200005b8)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_pause_e_f.png
    PROPERTY(0x200005b9)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_pause_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_4883, 7)
    PROPERTY(0x2000062a)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_next_a.png
    PROPERTY(0x2000062b)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_next_a_f.png
    PROPERTY(0x2000062c)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_next_d.png
    PROPERTY(0x2000062c)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_next_d.png
    PROPERTY(0x2000062d)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_next_e.png
    PROPERTY(0x2000062e)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_next_e_f.png
    PROPERTY(0x2000062f)                // 800x480\HMINissanResources\HMI\icons_audiofooter\audiofooter_icon_next_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__SXM_Audio_strliGetGetReplayMode, 3)
    PROPERTY(0x800008cd)                // Live -> TRA__SXM_Audio_strliGetGetReplayMode-000
    PROPERTY(0x800008ce)                // Replay -> TRA__SXM_Audio_strliGetGetReplayMode-001
    PROPERTY(0x800008cf)                // At The End -> TRA__SXM_Audio_strliGetGetReplayMode-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_4996, 9)
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x2000027b)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x2000027a)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e_f.png
    PROPERTY(0x2000027c)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_p.png
    PROPERTY(0x2000027a)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e_f.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_5220, 9)
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_5223, 7)
    PROPERTY(0x10ff7a04)                // 16742916
    PROPERTY(0x10ff7a04)                // 16742916
    PROPERTY(0x10ff7a04)                // 16742916
    PROPERTY(0x10ff7a04)                // 16742916
    PROPERTY(0x10ff7a04)                // 16742916
    PROPERTY(0x10ff7a04)                // 16742916
    PROPERTY(0x10ff7a04)                // 16742916
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_5232, 9)
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_5291, 9)
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000db)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_p.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_5367, 4)
    PROPERTY(0x40000fbc)                // OFF
    PROPERTY(0x400001b2)                // DAB
    PROPERTY(0x400023e2)                // DAB/FM
    PROPERTY(0x400001a5)                // FM
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_5372, 4)
    PROPERTY(0x20000630)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_4_1.png
    PROPERTY(0x20000631)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_4_2.png
    PROPERTY(0x20000632)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_4_3.png
    PROPERTY(0x20000633)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_4_4.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_5389, 4)
    PROPERTY(0x400023fe)                // Customer
    PROPERTY(0x400023ff)                // DDA
    PROPERTY(0x40002400)                // DDS
    PROPERTY(0x40002401)                // Single Tuner
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_5419, 2)
    PROPERTY(0x40002421)                // Fix
    PROPERTY(0x40002422)                // Auto
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_5506, 9)
    PROPERTY(0x20000634)                // 800x480\HMINissanResources\HMI\button\btn_tm_29x6_e.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000635)                // 800x480\HMINissanResources\HMI\button\btn_tm_29x6_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000634)                // 800x480\HMINissanResources\HMI\button\btn_tm_29x6_e.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_5508, 7)
    PROPERTY(0x10f47721)                // 16021281
    PROPERTY(0x109b0000)                // 10158080
    PROPERTY(0x10808080)                // 8421504
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_5512, 9)
    PROPERTY(0x20000636)                // 800x480\HMINissanResources\HMI\button\btn_tm_23x6_e.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000637)                // 800x480\HMINissanResources\HMI\button\btn_tm_23x6_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000636)                // 800x480\HMINissanResources\HMI\button\btn_tm_23x6_e.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(strDEV_Testmode_SLinkSL, 4)
    PROPERTY(0x40000fbc)                // OFF
    PROPERTY(0x400001b2)                // DAB
    PROPERTY(0x40002574)                // DABFM
    PROPERTY(0x400001a5)                // FM
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(DEV_Testmode_PrimarySecond_SL, 2)
    PROPERTY(0x40002590)                // S
    PROPERTY(0x40002591)                // P
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_5774, 9)
    PROPERTY(0x20000638)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6_e.png
    PROPERTY(0x20000638)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6_e.png
    PROPERTY(0x20000639)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6_d.png
    PROPERTY(0x20000639)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6_d.png
    PROPERTY(0x20000638)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6_e.png
    PROPERTY(0x20000638)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6_e.png
    PROPERTY(0x2000063a)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_5778, 9)
    PROPERTY(0x20000638)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6_e.png
    PROPERTY(0x20000638)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6_e.png
    PROPERTY(0x20000639)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6_d.png
    PROPERTY(0x20000639)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6_d.png
    PROPERTY(0x20000638)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6_e.png
    PROPERTY(0x20000634)                // 800x480\HMINissanResources\HMI\button\btn_tm_29x6_e.png
    PROPERTY(0x2000063a)                // 800x480\HMINissanResources\HMI\button\btn_tm_42x6.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliAudioCodecUsed, 7)
    PROPERTY(0x40002652)                // PHONE_CALL_NBS
    PROPERTY(0x40002653)                // PHONE_CALL_WBS
    PROPERTY(0x40002654)                // SIRI_NBS
    PROPERTY(0x40002655)                // SIRI_WBS
    PROPERTY(0x40002656)                // DEFAULT_VA_NBS
    PROPERTY(0x40002657)                // DEFAULT_VA_WBS
    PROPERTY(0x40002658)                // IDLE
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_5974, 9)
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x2000027b)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_d.png
    PROPERTY(0x2000027b)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_d.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x2000027a)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e_f.png
    PROPERTY(0x2000027c)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_p.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_5984, 3)
    PROPERTY(0x4000268e)                // 2402 MHz
    PROPERTY(0x4000268f)                // 2441 MHz
    PROPERTY(0x40002690)                // 2480 MHz
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_5988, 3)
    PROPERTY(0x40002695)                // DH5
    PROPERTY(0x40002696)                // 3DH5
    PROPERTY(0x40002697)                // 2DH5
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_5993, 3)
    PROPERTY(0x4000269d)                // 0 kHz
    PROPERTY(0x4000269e)                // 500 kHz
    PROPERTY(0x4000269f)                // 1000 kHz
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(strliTestmodeSystem_CurrentBoseSpeaker, 1)
    PROPERTY(0x800007fb)                // Center Front -> strliTestmodeSystem.CurrentBoseSpeaker-000
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Service__Radio_Antenna_Status, 6)
    PROPERTY(0x8000026f)                // UNKNOWN -> Service__Radio_Antenna_Status-000
    PROPERTY(0x800000ad)                // OK -> CONST.strLabelONOff.text.OK
    PROPERTY(0x80000270)                // SHORT -> Service__Radio_Antenna_Status-002
    PROPERTY(0x80000271)                // Open -> Service__Radio_Antenna_Status-003
    PROPERTY(0x80000272)                // Deactivated -> Service__Radio_Antenna_Status-004
    PROPERTY(0x80000273)                // Passive -> Service__Radio_Antenna_Status-005
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Service__strListDAB_Antenna_Status, 5)
    PROPERTY(0x800000ad)                // OK -> CONST.strLabelONOff.text.OK
    PROPERTY(0x80000274)                // Short -> Service__strListDAB_Antenna_Status-001
    PROPERTY(0x80000271)                // Open -> Service__Radio_Antenna_Status-003
    PROPERTY(0x80000275)                // Deactivated -> Service__strListDAB_Antenna_Status-003
    PROPERTY(0x80000276)                // Disconnected -> Service__strListDAB_Antenna_Status-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliSXM_Antenna_Status, 4)
    PROPERTY(0x800006d1)                // Wait... -> TRA__strliSignalQuality-004
    PROPERTY(0x800006dc)                // Ok -> TRA__strliSXM_Antenna_Status-001
    PROPERTY(0x800006dd)                // Disconnected -> TRA__strliSXM_Antenna_Status-002
    PROPERTY(0x800006de)                // Shorted -> TRA__strliSXM_Antenna_Status-003
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliSignalQuality, 5)
    PROPERTY(0x800000f3)                // No Signal -> Const_strNoSignal
    PROPERTY(0x80000642)                // Weak -> TRA__SettingsXMSignalStrength1value
    PROPERTY(0x800006cf)                // Good -> TRA__strliSignalQuality-002
    PROPERTY(0x800006d0)                // Excellent -> TRA__strliSignalQuality-003
    PROPERTY(0x800006d1)                // Wait... -> TRA__strliSignalQuality-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliServiceSXMAudio, 5)
    PROPERTY(0x800006ca)                // Not Subscribed -> TRA__strliServiceSXMAudio-000
    PROPERTY(0x800006cb)                // Subscribed -> TRA__strliServiceSXMAudio-001
    PROPERTY(0x800006cc)                // Suspend alert -> TRA__strliServiceSXMAudio-002
    PROPERTY(0x800006cd)                // Suspended -> TRA__strliServiceSXMAudio-003
    PROPERTY(0x8000063c)                // Invalid -> TRA__SettingsXMAudio4value
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliServiceSXMNavTraffic, 4)
    PROPERTY(0x800006ca)                // Not Subscribed -> TRA__strliServiceSXMAudio-000
    PROPERTY(0x80000639)                // Subscribed -> TRA__SettingsXMAudio1value
    PROPERTY(0x8000063f)                // Not Available -> TRA__SettingsXMNavTrafficNotavailable
    PROPERTY(0x800006ce)                // Loading -> TRA__strliServiceSXMNavTraffic-003
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemSelfTest_28_1_29__List, 2)
    PROPERTY(0x800000ef)                // NG -> Const_strNG
    PROPERTY(0x800000ad)                // OK -> CONST.strLabelONOff.text.OK
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliBTModuleStatus, 3)
    PROPERTY(0x800000ad)                // OK -> CONST.strLabelONOff.text.OK
    PROPERTY(0x800003aa)                // Not connected -> SYS.strliBTModuleStatus-001
    PROPERTY(0x800003ab)                // Switched Off -> SYS.strliBTModuleStatus-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemSelfTest_28_3_29__List, 4)
    PROPERTY(0x800003ec)                // Unknown -> SYS.strliGetSrvSystemSelfTest(3).List-000
    PROPERTY(0x800003ed)                // Connected -> SYS.strliGetSrvSystemSelfTest(3).List-001
    PROPERTY(0x80000271)                // Open -> Service__Radio_Antenna_Status-003
    PROPERTY(0x800003ee)                // Short -> SYS.strliGetSrvSystemSelfTest(3).List-003
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemStatus_28_2_29__list, 3)
    PROPERTY(0x800003ef)                // Forward -> SYS.strliGetSrvSystemStatus(2).list-000
    PROPERTY(0x800003f0)                // Reverse -> SYS.strliGetSrvSystemStatus(2).list-001
    PROPERTY(0x800003f1)                // Unknown -> SYS.strliGetSrvSystemStatus(2).list-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliGetMFLKeyPressed_List, 16)
    PROPERTY(0x800006b8)                // No key -> TRA__strliGetMFLKeyPressed.List-000
    PROPERTY(0x800006b9)                // Vol. down -> TRA__strliGetMFLKeyPressed.List-001
    PROPERTY(0x800006ba)                // Volume up -> TRA__strliGetMFLKeyPressed.List-002
    PROPERTY(0x800006bb)                // Seek up -> TRA__strliGetMFLKeyPressed.List-003
    PROPERTY(0x800006bc)                // Seek down -> TRA__strliGetMFLKeyPressed.List-004
    PROPERTY(0x800006bd)                // Source -> TRA__strliGetMFLKeyPressed.List-005
    PROPERTY(0x800006be)                // Telephone -> TRA__strliGetMFLKeyPressed.List-006
    PROPERTY(0x800006bf)                // Tel. Start -> TRA__strliGetMFLKeyPressed.List-007
    PROPERTY(0x800006c0)                // Tel. Stop -> TRA__strliGetMFLKeyPressed.List-008
    PROPERTY(0x800006c1)                //  -> TRA__strliGetMFLKeyPressed.List-009
    PROPERTY(0x800006c2)                // Back -> TRA__strliGetMFLKeyPressed.List-010
    PROPERTY(0x800006c3)                // Enter -> TRA__strliGetMFLKeyPressed.List-011
    PROPERTY(0x800006c4)                // PTT -> TRA__strliGetMFLKeyPressed.List-012
    PROPERTY(0x800006c4)                // PTT -> TRA__strliGetMFLKeyPressed.List-012
    PROPERTY(0x800006c5)                // RIGHT -> TRA__strliGetMFLKeyPressed.List-014
    PROPERTY(0x800006c6)                // LEFT -> TRA__strliGetMFLKeyPressed.List-015
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetUsbDeviceSrvStatus_List, 3)
    PROPERTY(0x800003f3)                // Error -> SYS.strliGetUsbDeviceSrvStatus.List-000
    PROPERTY(0x800003f4)                // Removed -> SYS.strliGetUsbDeviceSrvStatus.List-001
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(strliTestmodeANCASCConnection_ListItemChoiceConnectionStatus, 6)
    PROPERTY(0x800007f4)                // Normal -> strliTestmodeANCASCConnection.ListItemChoiceConnectionStatus-000
    PROPERTY(0x800007f5)                // Open -> strliTestmodeANCASCConnection.ListItemChoiceConnectionStatus-001
    PROPERTY(0x800007f6)                // Short -> strliTestmodeANCASCConnection.ListItemChoiceConnectionStatus-002
    PROPERTY(0x800007f7)                // Short (Battery) -> strliTestmodeANCASCConnection.ListItemChoiceConnectionStatus-003
    PROPERTY(0x800007f8)                // Short (Ground) -> strliTestmodeANCASCConnection.ListItemChoiceConnectionStatus-004
    PROPERTY(0x800007f9)                // Amp Over Temp -> strliTestmodeANCASCConnection.ListItemChoiceConnectionStatus-005
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(strliTestmodeANCASCConnection_ListItemChoiceConnectStatus, 2)
    PROPERTY(0x800007f4)                // Normal -> strliTestmodeANCASCConnection.ListItemChoiceConnectionStatus-000
    PROPERTY(0x800007fa)                // Fail -> strliTestmodeANCASCConnection.ListItemChoiceConnectStatus-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_6873, 3)
    PROPERTY(0x800002a1)                // 2012 - 2030 -> ServiceTestModeUserConfig_TimeInterval-000
    PROPERTY(0x800002a2)                // 2031 - 2049 -> ServiceTestModeUserConfig_TimeInterval-001
    PROPERTY(0x800002a3)                // 2050 - 2068 -> ServiceTestModeUserConfig_TimeInterval-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_6927, 9)
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000db)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_p.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_7026, 3)
    PROPERTY(0x800007d7)                // Near -> RVC__strliSONARSensitivityLevelText-000
    PROPERTY(0x800007d8)                // Middle -> RVC__strliSONARSensitivityLevelText-001
    PROPERTY(0x800007d9)                // Far -> RVC__strliSONARSensitivityLevelText-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_7030, 3)
    PROPERTY(0x800007da)                // Low -> RVC__strliSONARVolumeLevelText-000
    PROPERTY(0x800007d8)                // Middle -> RVC__strliSONARSensitivityLevelText-001
    PROPERTY(0x800007db)                // High -> RVC__strliSONARVolumeLevelText-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_7061, 4)
    PROPERTY(0x20000647)                // 800x480\HMINissanResources\HMI\hev\P32R_00.png
    PROPERTY(0x20000647)                // 800x480\HMINissanResources\HMI\hev\P32R_00.png
    PROPERTY(0x20000647)                // 800x480\HMINissanResources\HMI\hev\P32R_00.png
    PROPERTY(0x20000647)                // 800x480\HMINissanResources\HMI\hev\P32R_00.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_7062, 44)
    PROPERTY(0x20000648)                // 800x480\HMINissanResources\HMI\hev\P32R_02_PT_01.png
    PROPERTY(0x20000649)                // 800x480\HMINissanResources\HMI\hev\P32R_02_PT_02.png
    PROPERTY(0x2000064a)                // 800x480\HMINissanResources\HMI\hev\P32R_02_PT_03.png
    PROPERTY(0x2000064b)                // 800x480\HMINissanResources\HMI\hev\P32R_02_PT_04.png
    PROPERTY(0x2000064c)                // 800x480\HMINissanResources\HMI\hev\P32R_03_PT_01.png
    PROPERTY(0x2000064d)                // 800x480\HMINissanResources\HMI\hev\P32R_03_PT_02.png
    PROPERTY(0x2000064e)                // 800x480\HMINissanResources\HMI\hev\P32R_03_PT_03.png
    PROPERTY(0x2000064f)                // 800x480\HMINissanResources\HMI\hev\P32R_03_PT_04.png
    PROPERTY(0x20000650)                // 800x480\HMINissanResources\HMI\hev\P32R_04_PT_01.png
    PROPERTY(0x20000651)                // 800x480\HMINissanResources\HMI\hev\P32R_04_PT_02.png
    PROPERTY(0x20000652)                // 800x480\HMINissanResources\HMI\hev\P32R_04_PT_03.png
    PROPERTY(0x20000653)                // 800x480\HMINissanResources\HMI\hev\P32R_04_PT_04.png
    PROPERTY(0x20000654)                // 800x480\HMINissanResources\HMI\hev\P32R_05_PT_01.png
    PROPERTY(0x20000655)                // 800x480\HMINissanResources\HMI\hev\P32R_05_PT_02.png
    PROPERTY(0x20000656)                // 800x480\HMINissanResources\HMI\hev\P32R_05_PT_03.png
    PROPERTY(0x20000657)                // 800x480\HMINissanResources\HMI\hev\P32R_05_PT_04.png
    PROPERTY(0x20000658)                // 800x480\HMINissanResources\HMI\hev\P32R_06_PT_01.png
    PROPERTY(0x20000659)                // 800x480\HMINissanResources\HMI\hev\P32R_06_PT_02.png
    PROPERTY(0x2000065a)                // 800x480\HMINissanResources\HMI\hev\P32R_06_PT_03.png
    PROPERTY(0x2000065b)                // 800x480\HMINissanResources\HMI\hev\P32R_06_PT_04.png
    PROPERTY(0x2000065c)                // 800x480\HMINissanResources\HMI\hev\P32R_07_PT_01.png
    PROPERTY(0x2000065d)                // 800x480\HMINissanResources\HMI\hev\P32R_07_PT_02.png
    PROPERTY(0x2000065e)                // 800x480\HMINissanResources\HMI\hev\P32R_07_PT_03.png
    PROPERTY(0x2000065f)                // 800x480\HMINissanResources\HMI\hev\P32R_07_PT_04.png
    PROPERTY(0x20000660)                // 800x480\HMINissanResources\HMI\hev\P32R_08_PT_01.png
    PROPERTY(0x20000661)                // 800x480\HMINissanResources\HMI\hev\P32R_08_PT_02.png
    PROPERTY(0x20000662)                // 800x480\HMINissanResources\HMI\hev\P32R_08_PT_03.png
    PROPERTY(0x20000663)                // 800x480\HMINissanResources\HMI\hev\P32R_08_PT_04.png
    PROPERTY(0x20000664)                // 800x480\HMINissanResources\HMI\hev\P32R_09_PT_01.png
    PROPERTY(0x20000665)                // 800x480\HMINissanResources\HMI\hev\P32R_09_PT_02.png
    PROPERTY(0x20000666)                // 800x480\HMINissanResources\HMI\hev\P32R_09_PT_03.png
    PROPERTY(0x20000667)                // 800x480\HMINissanResources\HMI\hev\P32R_09_PT_04.png
    PROPERTY(0x20000668)                // 800x480\HMINissanResources\HMI\hev\P32R_10_PT_01.png
    PROPERTY(0x20000669)                // 800x480\HMINissanResources\HMI\hev\P32R_10_PT_02.png
    PROPERTY(0x2000066a)                // 800x480\HMINissanResources\HMI\hev\P32R_10_PT_03.png
    PROPERTY(0x2000066b)                // 800x480\HMINissanResources\HMI\hev\P32R_10_PT_04.png
    PROPERTY(0x2000066c)                // 800x480\HMINissanResources\HMI\hev\P32R_12_PT_01.png
    PROPERTY(0x2000066d)                // 800x480\HMINissanResources\HMI\hev\P32R_12_PT_02.png
    PROPERTY(0x2000066e)                // 800x480\HMINissanResources\HMI\hev\P32R_12_PT_03.png
    PROPERTY(0x2000066f)                // 800x480\HMINissanResources\HMI\hev\P32R_12_PT_04.png
    PROPERTY(0x20000670)                // 800x480\HMINissanResources\HMI\hev\P32R_13_PT_01.png
    PROPERTY(0x20000671)                // 800x480\HMINissanResources\HMI\hev\P32R_13_PT_02.png
    PROPERTY(0x20000672)                // 800x480\HMINissanResources\HMI\hev\P32R_13_PT_03.png
    PROPERTY(0x20000673)                // 800x480\HMINissanResources\HMI\hev\P32R_13_PT_04.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_7063, 7)
    PROPERTY(0x20000675)                // 800x480\HMINissanResources\HMI\hev\P32R_00_cell_0.png
    PROPERTY(0x20000676)                // 800x480\HMINissanResources\HMI\hev\P32R_00_cell_1.png
    PROPERTY(0x20000677)                // 800x480\HMINissanResources\HMI\hev\P32R_00_cell_2.png
    PROPERTY(0x20000678)                // 800x480\HMINissanResources\HMI\hev\P32R_00_cell_3.png
    PROPERTY(0x20000679)                // 800x480\HMINissanResources\HMI\hev\P32R_00_cell_4.png
    PROPERTY(0x2000067a)                // 800x480\HMINissanResources\HMI\hev\P32R_00_cell_5.png
    PROPERTY(0x2000067b)                // 800x480\HMINissanResources\HMI\hev\P32R_00_cell_6.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_7064, 4)
    PROPERTY(0x2000067c)                // 800x480\HMINissanResources\HMI\hev\P32R_00_indicator_0.png
    PROPERTY(0x2000067d)                // 800x480\HMINissanResources\HMI\hev\P32R_00_indicator_1.png
    PROPERTY(0x2000067e)                // 800x480\HMINissanResources\HMI\hev\P32R_00_indicator_2.png
    PROPERTY(0x2000067f)                // 800x480\HMINissanResources\HMI\hev\P32R_00_indicator_3.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_7065, 4)
    PROPERTY(0x20000680)                // 800x480\HMINissanResources\HMI\hev\WheelFront_1.png
    PROPERTY(0x20000681)                // 800x480\HMINissanResources\HMI\hev\WheelFront_2.png
    PROPERTY(0x20000682)                // 800x480\HMINissanResources\HMI\hev\WheelFront_3.png
    PROPERTY(0x20000683)                // 800x480\HMINissanResources\HMI\hev\WheelFront_4.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_7066, 4)
    PROPERTY(0x20000684)                // 800x480\HMINissanResources\HMI\hev\WheelRear_1.png
    PROPERTY(0x20000685)                // 800x480\HMINissanResources\HMI\hev\WheelRear_2.png
    PROPERTY(0x20000686)                // 800x480\HMINissanResources\HMI\hev\WheelRear_3.png
    PROPERTY(0x20000687)                // 800x480\HMINissanResources\HMI\hev\WheelRear_4.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(HEV__iListAverageFuelMaxVaules, 4)
    PROPERTY(0x10000019)                // 25
    PROPERTY(0x1000001e)                // 30
    PROPERTY(0x10000032)                // 50
    PROPERTY(0x1000003c)                // 60
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_7093, 9)
    PROPERTY(0x2000069a)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_e.png
    PROPERTY(0x2000069b)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_e_f.png
    PROPERTY(0x2000069c)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_d.png
    PROPERTY(0x2000069c)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_d.png
    PROPERTY(0x2000069a)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_e.png
    PROPERTY(0x2000069b)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_e_f.png
    PROPERTY(0x2000069d)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_7094, 9)
    PROPERTY(0x2000069e)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_e.png
    PROPERTY(0x2000069f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_e_f.png
    PROPERTY(0x200006a0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_d.png
    PROPERTY(0x200006a0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_d.png
    PROPERTY(0x2000069e)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_e.png
    PROPERTY(0x2000069f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_e_f.png
    PROPERTY(0x200006a1)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strFuelEconomyUnit, 3)
    PROPERTY(0x800006a2)                // km/l -> TRA__strFuelEconomyUnit-000
    PROPERTY(0x800006a3)                // l/100km -> TRA__strFuelEconomyUnit-001
    PROPERTY(0x800006a4)                // MPG -> TRA__strFuelEconomyUnit-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7154, 7)
    PROPERTY(0x200006a2)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_phone_settings_e.png
    PROPERTY(0x200006a3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_phone_settings_f.png
    PROPERTY(0x200006a4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_phone_settings_d.png
    PROPERTY(0x200006a4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_phone_settings_d.png
    PROPERTY(0x200006a2)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_phone_settings_e.png
    PROPERTY(0x200006a3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_phone_settings_f.png
    PROPERTY(0x200006a5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_phone_settings_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7157, 7)
    PROPERTY(0x200006a6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cs_e.png
    PROPERTY(0x200006a7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cs_f.png
    PROPERTY(0x200006a8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cs_d.png
    PROPERTY(0x200006a7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cs_f.png
    PROPERTY(0x200006a6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cs_e.png
    PROPERTY(0x200006a7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cs_f.png
    PROPERTY(0x200006a9)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_cs_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7164, 7)
    PROPERTY(0x200006aa)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sxm_e.png
    PROPERTY(0x200006ab)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sxm_f.png
    PROPERTY(0x200006ac)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sxm_d.png
    PROPERTY(0x200006ac)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sxm_d.png
    PROPERTY(0x200006aa)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sxm_e.png
    PROPERTY(0x200006ab)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sxm_f.png
    PROPERTY(0x200006ad)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sxm_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7172, 7)
    PROPERTY(0x200006ae)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_vrhelp_e.png
    PROPERTY(0x200006af)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_vrhelp_f.png
    PROPERTY(0x200006b0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_vrhelp_d.png
    PROPERTY(0x200006b0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_vrhelp_d.png
    PROPERTY(0x200006ae)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_vrhelp_e.png
    PROPERTY(0x200006af)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_vrhelp_f.png
    PROPERTY(0x200006b1)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_vrhelp_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7194, 7)
    PROPERTY(0x200006b2)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_call_e.png
    PROPERTY(0x200006b3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_call_f.png
    PROPERTY(0x200006b4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_call_d.png
    PROPERTY(0x200006b4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_call_d.png
    PROPERTY(0x200006b2)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_call_e.png
    PROPERTY(0x200006b3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_call_f.png
    PROPERTY(0x200006b5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_call_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7265, 7)
    PROPERTY(0x200006b6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_apps_e.png
    PROPERTY(0x200006b7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_apps_f.png
    PROPERTY(0x200006b8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_apps_d.png
    PROPERTY(0x200006b8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_apps_d.png
    PROPERTY(0x200006b6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_apps_e.png
    PROPERTY(0x200006b7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_apps_f.png
    PROPERTY(0x200006b9)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_apps_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7268, 7)
    PROPERTY(0x200006ba)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_setup_e.png
    PROPERTY(0x200006bb)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_setup_f.png
    PROPERTY(0x200006bc)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_setup_d.png
    PROPERTY(0x200006bc)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_setup_d.png
    PROPERTY(0x200006ba)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_setup_e.png
    PROPERTY(0x200006bb)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_setup_f.png
    PROPERTY(0x200006bd)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_setup_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7273, 7)
    PROPERTY(0x200006be)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_ecoscore_e.png
    PROPERTY(0x200006bf)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_ecoscore_f.png
    PROPERTY(0x200006c0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_ecoscore_d.png
    PROPERTY(0x200006c0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_ecoscore_d.png
    PROPERTY(0x200006be)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_ecoscore_e.png
    PROPERTY(0x200006bf)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_ecoscore_f.png
    PROPERTY(0x200006c1)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_ecoscore_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7409, 7)
    PROPERTY(0x200006c2)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_energyflow_e.png
    PROPERTY(0x200006c3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_energyflow_f.png
    PROPERTY(0x200006c4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_energyflow_d.png
    PROPERTY(0x200006c4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_energyflow_d.png
    PROPERTY(0x200006c2)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_energyflow_e.png
    PROPERTY(0x200006c3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_energyflow_f.png
    PROPERTY(0x200006c5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_energyflow_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7427, 7)
    PROPERTY(0x200006c6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_gasprices_e.png
    PROPERTY(0x200006c7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_gasprices_f.png
    PROPERTY(0x200006c8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_gasprices_d.png
    PROPERTY(0x200006c8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_gasprices_d.png
    PROPERTY(0x200006c6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_gasprices_e.png
    PROPERTY(0x200006c7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_gasprices_f.png
    PROPERTY(0x200006c9)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_gasprices_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7430, 7)
    PROPERTY(0x200006ca)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_weather_e.png
    PROPERTY(0x200006cb)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_weather_f.png
    PROPERTY(0x200006cc)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_weather_d.png
    PROPERTY(0x200006cc)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_weather_d.png
    PROPERTY(0x200006ca)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_weather_e.png
    PROPERTY(0x200006cb)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_weather_f.png
    PROPERTY(0x200006cd)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_weather_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7433, 7)
    PROPERTY(0x200006ce)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_stocks_e.png
    PROPERTY(0x200006cf)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_stocks_f.png
    PROPERTY(0x200006d0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_stocks_d.png
    PROPERTY(0x200006d0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_stocks_d.png
    PROPERTY(0x200006ce)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_stocks_e.png
    PROPERTY(0x200006cf)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_stocks_f.png
    PROPERTY(0x200006d1)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_stocks_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7436, 7)
    PROPERTY(0x200006d2)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_movies_e.png
    PROPERTY(0x200006d3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_movies_f.png
    PROPERTY(0x200006d4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_movies_d.png
    PROPERTY(0x200006d4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_movies_d.png
    PROPERTY(0x200006d2)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_movies_e.png
    PROPERTY(0x200006d3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_movies_f.png
    PROPERTY(0x200006d5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_movies_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7439, 7)
    PROPERTY(0x200006d6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sports_e.png
    PROPERTY(0x200006d7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sports_f.png
    PROPERTY(0x200006d8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sports_d.png
    PROPERTY(0x200006d8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sports_d.png
    PROPERTY(0x200006d6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sports_e.png
    PROPERTY(0x200006d7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sports_f.png
    PROPERTY(0x200006d9)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_sports_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7716, 7)
    PROPERTY(0x200006db)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_destsendtocar_e.png
    PROPERTY(0x200006dc)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_destsendtocar_f.png
    PROPERTY(0x200006dd)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_destsendtocar_d.png
    PROPERTY(0x200006dd)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_destsendtocar_d.png
    PROPERTY(0x200006db)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_destsendtocar_e.png
    PROPERTY(0x200006dc)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_destsendtocar_f.png
    PROPERTY(0x200006de)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_destsendtocar_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7719, 7)
    PROPERTY(0x200006df)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_googlesend2car_e.png
    PROPERTY(0x200006e0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_googlesend2car_f.png
    PROPERTY(0x200006e1)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_googlesend2car_d.png
    PROPERTY(0x200006e1)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_googlesend2car_d.png
    PROPERTY(0x200006df)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_googlesend2car_e.png
    PROPERTY(0x200006e0)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_googlesend2car_f.png
    PROPERTY(0x200006e2)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_googlesend2car_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7722, 7)
    PROPERTY(0x200006e3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_journeyplanner_e.png
    PROPERTY(0x200006e4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_journeyplanner_f.png
    PROPERTY(0x200006e5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_journeyplanner_d.png
    PROPERTY(0x200006e5)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_journeyplanner_d.png
    PROPERTY(0x200006e3)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_journeyplanner_e.png
    PROPERTY(0x200006e4)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_journeyplanner_f.png
    PROPERTY(0x200006e6)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_journeyplanner_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7725, 7)
    PROPERTY(0x200006e7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_connectedsearch_e.png
    PROPERTY(0x200006e8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_connectedsearch_f.png
    PROPERTY(0x200006e9)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_connectedsearch_d.png
    PROPERTY(0x200006e9)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_connectedsearch_d.png
    PROPERTY(0x200006e7)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_connectedsearch_e.png
    PROPERTY(0x200006e8)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_connectedsearch_f.png
    PROPERTY(0x200006ea)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_connectedsearch_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_7748, 7)
    PROPERTY(0x200006eb)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_messagehistory_e.png
    PROPERTY(0x200006ec)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_messagehistory_f.png
    PROPERTY(0x200006ed)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_messagehistory_d.png
    PROPERTY(0x200006ed)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_messagehistory_d.png
    PROPERTY(0x200006eb)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_messagehistory_e.png
    PROPERTY(0x200006ec)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_messagehistory_f.png
    PROPERTY(0x200006ee)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_messagehistory_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_8023, 9)
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000db)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_p.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TopOffset_8126, 5)
    PROPERTY(0xe0000000)                // Display1: 0, Display2: 0
    PROPERTY(0xe003f024)                // Display1: 63, Display2: 36
    PROPERTY(0xe007e048)                // Display1: 126, Display2: 72
    PROPERTY(0xe00bd06c)                // Display1: 189, Display2: 108
    PROPERTY(0xe00fc090)                // Display1: 252, Display2: 144
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_8135, 4)
    PROPERTY(0x8000006e)                // None -> __export_SXM_StrliAPIInfo-010
    PROPERTY(0x80000873)                // Unknown -> SXM_Fuel__StrliSortingOrder-001
    PROPERTY(0x80000874)                // Price -> SXM_Fuel__StrliSortingOrder-002
    PROPERTY(0x80000875)                // Distance -> SXM_Fuel__StrliSortingOrder-003
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_8137, 9)
    PROPERTY(0x200006f0)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_100p_e.png
    PROPERTY(0x200006f1)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_100p_e_f.png
    PROPERTY(0x200006f2)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_100p_d.png
    PROPERTY(0x200006f2)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_100p_d.png
    PROPERTY(0x200006f0)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_100p_e.png
    PROPERTY(0x200006f1)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_100p_e_f.png
    PROPERTY(0x200006f3)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_100p_p.png
    PROPERTY(0x200006f0)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_100p_e.png
    PROPERTY(0x200006f0)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_100p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_8141, 4)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000270)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_2_1.png
    PROPERTY(0x20000271)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_2_2.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_8153, 9)
    PROPERTY(0x200006f4)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_e.png
    PROPERTY(0x200006f5)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_e_f.png
    PROPERTY(0x200006f6)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_d.png
    PROPERTY(0x200006f6)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_d.png
    PROPERTY(0x200006f4)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_e.png
    PROPERTY(0x200006f5)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_e_f.png
    PROPERTY(0x200006f7)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_p.png
    PROPERTY(0x200006f4)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_e.png
    PROPERTY(0x200006f4)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_8162, 7)
    PROPERTY(0x10f47721)                // 16021281
    PROPERTY(0x109b0000)                // 10158080
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10f47721)                // 16021281
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TopOffset_8588, 3)
    PROPERTY(0xe0000000)                // Display1: 0, Display2: 0
    PROPERTY(0xe007e048)                // Display1: 126, Display2: 72
    PROPERTY(0xe00fc090)                // Display1: 252, Display2: 144
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_8590, 9)
    PROPERTY(0x200006f8)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e.png
    PROPERTY(0x200006f9)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e_f.png
    PROPERTY(0x200006fa)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_d.png
    PROPERTY(0x200006fa)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_d.png
    PROPERTY(0x200006f8)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e.png
    PROPERTY(0x200006f9)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e_f.png
    PROPERTY(0x200006fb)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_p.png
    PROPERTY(0x200006f8)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e.png
    PROPERTY(0x200006f8)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_8591, 9)
    PROPERTY(0x200006fc)                // 800x480\HMINissanResources\HMI\list\li_3row_in_83p_e.png
    PROPERTY(0x200006fc)                // 800x480\HMINissanResources\HMI\list\li_3row_in_83p_e.png
    PROPERTY(0x200006fd)                // 800x480\HMINissanResources\HMI\list\li_3row_in_83p_d.png
    PROPERTY(0x200006fd)                // 800x480\HMINissanResources\HMI\list\li_3row_in_83p_d.png
    PROPERTY(0x200006fc)                // 800x480\HMINissanResources\HMI\list\li_3row_in_83p_e.png
    PROPERTY(0x200006fc)                // 800x480\HMINissanResources\HMI\list\li_3row_in_83p_e.png
    PROPERTY(0x200006fe)                // 800x480\HMINissanResources\HMI\list\li_3row_in_83p_p.png
    PROPERTY(0x200006fc)                // 800x480\HMINissanResources\HMI\list\li_3row_in_83p_e.png
    PROPERTY(0x200006fc)                // 800x480\HMINissanResources\HMI\list\li_3row_in_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_8881, 9)
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_8883, 7)
    PROPERTY(0x10f47721)                // 16021281
    PROPERTY(0x109b0000)                // 10158080
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10ffffff)                // 16777215
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_8900, 9)
    PROPERTY(0x200006f8)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e.png
    PROPERTY(0x200006f9)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e_f.png
    PROPERTY(0x200006fa)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_d.png
    PROPERTY(0x200006fa)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_d.png
    PROPERTY(0x200006f8)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e.png
    PROPERTY(0x200006f9)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e_f.png
    PROPERTY(0x200006f9)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e_f.png
    PROPERTY(0x200006f8)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e.png
    PROPERTY(0x200006f8)                // 800x480\HMINissanResources\HMI\list\li_3row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_9049, 9)
    PROPERTY(0x200006f4)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_e.png
    PROPERTY(0x200006f4)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_e.png
    PROPERTY(0x200006f6)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_d.png
    PROPERTY(0x200006f6)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_d.png
    PROPERTY(0x200006f4)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_e.png
    PROPERTY(0x200006f5)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_e_f.png
    PROPERTY(0x200006f7)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_p.png
    PROPERTY(0x200006f4)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_e.png
    PROPERTY(0x200006f4)                // 800x480\HMINissanResources\HMI\list\li_5row_100p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_9060, 9)
    PROPERTY(0x200006ff)                // 800x480\HMINissanResources\HMI\list\li_6row_100p_e.png
    PROPERTY(0x20000700)                // 800x480\HMINissanResources\HMI\list\li_6row_100p_e_f.png
    PROPERTY(0x20000701)                // 800x480\HMINissanResources\HMI\list\li_6row_100p_d.png
    PROPERTY(0x20000701)                // 800x480\HMINissanResources\HMI\list\li_6row_100p_d.png
    PROPERTY(0x200006ff)                // 800x480\HMINissanResources\HMI\list\li_6row_100p_e.png
    PROPERTY(0x20000700)                // 800x480\HMINissanResources\HMI\list\li_6row_100p_e_f.png
    PROPERTY(0x20000702)                // 800x480\HMINissanResources\HMI\list\li_6row_100p_p.png
    PROPERTY(0x200006ff)                // 800x480\HMINissanResources\HMI\list\li_6row_100p_e.png
    PROPERTY(0x200006ff)                // 800x480\HMINissanResources\HMI\list\li_6row_100p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_9105, 256)
    PROPERTY(0x20000703)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_0.png
    PROPERTY(0x20000704)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_1.png
    PROPERTY(0x20000705)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_2.png
    PROPERTY(0x20000706)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_3.png
    PROPERTY(0x20000707)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_4.png
    PROPERTY(0x20000708)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_5.png
    PROPERTY(0x20000709)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_6.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000070a)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_10.png
    PROPERTY(0x2000070b)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_11.png
    PROPERTY(0x2000070c)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_12.png
    PROPERTY(0x2000070d)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_13.png
    PROPERTY(0x2000070e)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_14.png
    PROPERTY(0x2000070f)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_15.png
    PROPERTY(0x20000710)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_16.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000711)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_20.png
    PROPERTY(0x20000712)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_21.png
    PROPERTY(0x20000713)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_22.png
    PROPERTY(0x20000714)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_23.png
    PROPERTY(0x20000715)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_24.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000716)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_30.png
    PROPERTY(0x20000717)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_31.png
    PROPERTY(0x20000718)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_32.png
    PROPERTY(0x20000719)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_33.png
    PROPERTY(0x2000071a)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_34.png
    PROPERTY(0x2000071b)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_35.png
    PROPERTY(0x2000071c)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_36.png
    PROPERTY(0x2000071d)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_37.png
    PROPERTY(0x2000071e)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_38.png
    PROPERTY(0x2000071f)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_39.png
    PROPERTY(0x20000720)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_40.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000721)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_50.png
    PROPERTY(0x20000722)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_51.png
    PROPERTY(0x20000723)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_52.png
    PROPERTY(0x20000724)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_53.png
    PROPERTY(0x20000725)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_54.png
    PROPERTY(0x20000726)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_55.png
    PROPERTY(0x20000727)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_56.png
    PROPERTY(0x20000728)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_57.png
    PROPERTY(0x20000729)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_58.png
    PROPERTY(0x2000072a)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_59.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000072b)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_70.png
    PROPERTY(0x2000072c)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_71.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000072d)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_80.png
    PROPERTY(0x2000072e)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_81.png
    PROPERTY(0x2000072f)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_82.png
    PROPERTY(0x20000730)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_83.png
    PROPERTY(0x20000731)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_84.png
    PROPERTY(0x20000732)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_85.png
    PROPERTY(0x20000733)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_86.png
    PROPERTY(0x20000734)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_87.png
    PROPERTY(0x20000735)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_88.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000736)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_100.png
    PROPERTY(0x20000737)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_101.png
    PROPERTY(0x20000738)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_102.png
    PROPERTY(0x20000739)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_103.png
    PROPERTY(0x2000073a)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_104.png
    PROPERTY(0x2000073b)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_105.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000073c)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_200.png
    PROPERTY(0x2000073d)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_201.png
    PROPERTY(0x2000073e)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_202.png
    PROPERTY(0x2000073f)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_203.png
    PROPERTY(0x20000740)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_204.png
    PROPERTY(0x20000741)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_205.png
    PROPERTY(0x20000742)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_206.png
    PROPERTY(0x20000743)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_207.png
    PROPERTY(0x20000744)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_208.png
    PROPERTY(0x20000745)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_209.png
    PROPERTY(0x20000746)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_210.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000747)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_254.png
    PROPERTY(0x20000748)                // 800x480\HMINissanResources\HMI\weather_forecast_icons\weather_255.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Sxm_Weather__StrLiTempUnit_content, 2)
    PROPERTY(0x8000030e)                // �F -> SETTINGS_INFO_NAR.ListItemChoice_TempUnit.content-000
    PROPERTY(0x8000030f)                // �C -> SETTINGS_INFO_NAR.ListItemChoice_TempUnit.content-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Sxm_Weather__StrliSXMCurrentWeatherWinddirection, 16)
    PROPERTY(0x8000002b)                // N -> __export_Navigation_StrliAPIString-013
    PROPERTY(0x8000002c)                // NNE -> __export_Navigation_StrliAPIString-014
    PROPERTY(0x8000002d)                // NE -> __export_Navigation_StrliAPIString-015
    PROPERTY(0x8000002e)                // ENE -> __export_Navigation_StrliAPIString-016
    PROPERTY(0x8000002f)                // E -> __export_Navigation_StrliAPIString-017
    PROPERTY(0x80000030)                // ESE -> __export_Navigation_StrliAPIString-018
    PROPERTY(0x80000031)                // SE -> __export_Navigation_StrliAPIString-019
    PROPERTY(0x80000032)                // SSE -> __export_Navigation_StrliAPIString-020
    PROPERTY(0x80000033)                // S -> __export_Navigation_StrliAPIString-021
    PROPERTY(0x80000034)                // SSW -> __export_Navigation_StrliAPIString-022
    PROPERTY(0x80000035)                // SW -> __export_Navigation_StrliAPIString-023
    PROPERTY(0x80000036)                // WSW -> __export_Navigation_StrliAPIString-024
    PROPERTY(0x80000037)                // W -> __export_Navigation_StrliAPIString-025
    PROPERTY(0x80000038)                // WNW -> __export_Navigation_StrliAPIString-026
    PROPERTY(0x80000039)                // NW -> __export_Navigation_StrliAPIString-027
    PROPERTY(0x8000003a)                // NNW -> __export_Navigation_StrliAPIString-028
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_9145, 256)
    PROPERTY(0x2000074b)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_0.png
    PROPERTY(0x2000074c)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_1.png
    PROPERTY(0x2000074d)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_2.png
    PROPERTY(0x2000074e)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_3.png
    PROPERTY(0x2000074f)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_4.png
    PROPERTY(0x20000750)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_5.png
    PROPERTY(0x20000751)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_6.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000752)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_10.png
    PROPERTY(0x20000753)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_11.png
    PROPERTY(0x20000754)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_12.png
    PROPERTY(0x20000755)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_13.png
    PROPERTY(0x20000756)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_14.png
    PROPERTY(0x20000757)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_15.png
    PROPERTY(0x20000758)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_16.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000759)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_20.png
    PROPERTY(0x2000075a)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_21.png
    PROPERTY(0x2000075b)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_22.png
    PROPERTY(0x2000075c)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_23.png
    PROPERTY(0x2000075d)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_24.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000075e)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_30.png
    PROPERTY(0x2000075f)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_31.png
    PROPERTY(0x20000760)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_32.png
    PROPERTY(0x20000761)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_33.png
    PROPERTY(0x20000762)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_34.png
    PROPERTY(0x20000763)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_35.png
    PROPERTY(0x20000764)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_36.png
    PROPERTY(0x20000765)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_37.png
    PROPERTY(0x20000766)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_38.png
    PROPERTY(0x20000767)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_39.png
    PROPERTY(0x20000768)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_40.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000769)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_50.png
    PROPERTY(0x2000076a)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_51.png
    PROPERTY(0x2000076b)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_52.png
    PROPERTY(0x2000076c)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_53.png
    PROPERTY(0x2000076d)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_54.png
    PROPERTY(0x2000076e)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_55.png
    PROPERTY(0x2000076f)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_56.png
    PROPERTY(0x20000770)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_57.png
    PROPERTY(0x20000771)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_58.png
    PROPERTY(0x20000772)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_59.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000773)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_70.png
    PROPERTY(0x20000774)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_71.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000775)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_80.png
    PROPERTY(0x20000776)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_81.png
    PROPERTY(0x20000777)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_82.png
    PROPERTY(0x20000778)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_83.png
    PROPERTY(0x20000779)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_84.png
    PROPERTY(0x2000077a)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_85.png
    PROPERTY(0x2000077b)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_86.png
    PROPERTY(0x2000077c)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_87.png
    PROPERTY(0x2000077d)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_88.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000077e)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_100.png
    PROPERTY(0x2000077f)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_101.png
    PROPERTY(0x20000780)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_102.png
    PROPERTY(0x20000781)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_103.png
    PROPERTY(0x20000782)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_104.png
    PROPERTY(0x20000783)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_105.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000784)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_200.png
    PROPERTY(0x20000785)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_201.png
    PROPERTY(0x20000786)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_202.png
    PROPERTY(0x20000787)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_203.png
    PROPERTY(0x20000788)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_204.png
    PROPERTY(0x20000789)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_205.png
    PROPERTY(0x2000078a)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_206.png
    PROPERTY(0x2000078b)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_207.png
    PROPERTY(0x2000078c)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_208.png
    PROPERTY(0x2000078d)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_209.png
    PROPERTY(0x2000078e)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_210.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000078f)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_254.png
    PROPERTY(0x20000790)                // 800x480\HMINissanResources\HMI\weather_forecast_6H_icons\weather_255.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_9186, 256)
    PROPERTY(0x20000791)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_0.png
    PROPERTY(0x20000792)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_1.png
    PROPERTY(0x20000793)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_2.png
    PROPERTY(0x20000794)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_3.png
    PROPERTY(0x20000795)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_4.png
    PROPERTY(0x20000796)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_5.png
    PROPERTY(0x20000797)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_6.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000798)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_10.png
    PROPERTY(0x20000799)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_11.png
    PROPERTY(0x2000079a)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_12.png
    PROPERTY(0x2000079b)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_13.png
    PROPERTY(0x2000079c)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_14.png
    PROPERTY(0x2000079d)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_15.png
    PROPERTY(0x2000079e)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_16.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000079f)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_20.png
    PROPERTY(0x200007a0)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_21.png
    PROPERTY(0x200007a1)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_22.png
    PROPERTY(0x200007a2)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_23.png
    PROPERTY(0x200007a3)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_24.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200007a4)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_30.png
    PROPERTY(0x200007a5)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_31.png
    PROPERTY(0x200007a6)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_32.png
    PROPERTY(0x200007a7)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_33.png
    PROPERTY(0x200007a8)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_34.png
    PROPERTY(0x200007a9)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_35.png
    PROPERTY(0x200007aa)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_36.png
    PROPERTY(0x200007ab)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_37.png
    PROPERTY(0x200007ac)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_38.png
    PROPERTY(0x200007ad)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_39.png
    PROPERTY(0x200007ae)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_40.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200007af)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_50.png
    PROPERTY(0x200007b0)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_51.png
    PROPERTY(0x200007b1)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_52.png
    PROPERTY(0x200007b2)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_53.png
    PROPERTY(0x200007b3)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_54.png
    PROPERTY(0x200007b4)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_55.png
    PROPERTY(0x200007b5)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_56.png
    PROPERTY(0x200007b6)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_57.png
    PROPERTY(0x200007b7)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_58.png
    PROPERTY(0x200007b8)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_59.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200007b9)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_70.png
    PROPERTY(0x200007ba)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_71.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200007bb)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_80.png
    PROPERTY(0x200007bc)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_81.png
    PROPERTY(0x200007bd)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_82.png
    PROPERTY(0x200007be)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_83.png
    PROPERTY(0x200007bf)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_84.png
    PROPERTY(0x200007c0)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_85.png
    PROPERTY(0x200007c1)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_86.png
    PROPERTY(0x200007c2)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_87.png
    PROPERTY(0x200007c3)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_88.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200007c4)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_100.png
    PROPERTY(0x200007c5)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_101.png
    PROPERTY(0x200007c6)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_102.png
    PROPERTY(0x200007c7)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_103.png
    PROPERTY(0x200007c8)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_104.png
    PROPERTY(0x200007c9)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_105.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200007ca)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_200.png
    PROPERTY(0x200007cb)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_201.png
    PROPERTY(0x200007cc)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_202.png
    PROPERTY(0x200007cd)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_203.png
    PROPERTY(0x200007ce)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_204.png
    PROPERTY(0x200007cf)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_205.png
    PROPERTY(0x200007d0)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_206.png
    PROPERTY(0x200007d1)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_207.png
    PROPERTY(0x200007d2)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_208.png
    PROPERTY(0x200007d3)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_209.png
    PROPERTY(0x200007d4)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_210.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200007d5)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_254.png
    PROPERTY(0x200007d6)                // 800x480\HMINissanResources\HMI\weather_report_icons\weather_255.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_9187, 1)
    PROPERTY(0xe0046028)                // Display1: 70, Display2: 40
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_9279, 9)
    PROPERTY(0x200007d7)                // 800x480\HMINissanResources\HMI\button\map_zoom_in_map_e.png
    PROPERTY(0x200007d7)                // 800x480\HMINissanResources\HMI\button\map_zoom_in_map_e.png
    PROPERTY(0x200007d8)                // 800x480\HMINissanResources\HMI\button\map_zoom_in_map_d.png
    PROPERTY(0x200007d8)                // 800x480\HMINissanResources\HMI\button\map_zoom_in_map_d.png
    PROPERTY(0x200007d7)                // 800x480\HMINissanResources\HMI\button\map_zoom_in_map_e.png
    PROPERTY(0x200007d7)                // 800x480\HMINissanResources\HMI\button\map_zoom_in_map_e.png
    PROPERTY(0x200007d9)                // 800x480\HMINissanResources\HMI\button\map_zoom_in_map_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_9280, 9)
    PROPERTY(0x200007da)                // 800x480\HMINissanResources\HMI\button\map_zoom_out_map_e.png
    PROPERTY(0x200007da)                // 800x480\HMINissanResources\HMI\button\map_zoom_out_map_e.png
    PROPERTY(0x200007db)                // 800x480\HMINissanResources\HMI\button\map_zoom_out_map_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200007da)                // 800x480\HMINissanResources\HMI\button\map_zoom_out_map_e.png
    PROPERTY(0x200007da)                // 800x480\HMINissanResources\HMI\button\map_zoom_out_map_e.png
    PROPERTY(0x200007dc)                // 800x480\HMINissanResources\HMI\button\map_zoom_out_map_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_9281, 9)
    PROPERTY(0x200007dd)                // 800x480\HMINissanResources\HMI\button\map_btn_map_e.png
    PROPERTY(0x200007dd)                // 800x480\HMINissanResources\HMI\button\map_btn_map_e.png
    PROPERTY(0x200007dd)                // 800x480\HMINissanResources\HMI\button\map_btn_map_e.png
    PROPERTY(0x200007dd)                // 800x480\HMINissanResources\HMI\button\map_btn_map_e.png
    PROPERTY(0x200007dd)                // 800x480\HMINissanResources\HMI\button\map_btn_map_e.png
    PROPERTY(0x200007dd)                // 800x480\HMINissanResources\HMI\button\map_btn_map_e.png
    PROPERTY(0x200007de)                // 800x480\HMINissanResources\HMI\button\map_btn_map_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_9284, 5)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200007df)                // 800x480\HMINissanResources\HMI\weather_legend\legend_hurricane_tracking_map_en_kmh.png
    PROPERTY(0x200007e0)                // 800x480\HMINissanResources\HMI\weather_legend\legend_hurricane_tracking_map_es_kmh.png
    PROPERTY(0x200007e1)                // 800x480\HMINissanResources\HMI\weather_legend\legend_hurricane_tracking_map_fr_kmh.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_9285, 5)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200007e2)                // 800x480\HMINissanResources\HMI\weather_legend\legend_radar_map_en.png
    PROPERTY(0x200007e3)                // 800x480\HMINissanResources\HMI\weather_legend\legend_radar_map_es.png
    PROPERTY(0x200007e4)                // 800x480\HMINissanResources\HMI\weather_legend\legend_radar_map_fr.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_9286, 5)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200007e5)                // 800x480\HMINissanResources\HMI\weather_legend\legend_hurricane_tracking_map_en_mph.png
    PROPERTY(0x200007e6)                // 800x480\HMINissanResources\HMI\weather_legend\legend_hurricane_tracking_map_es_mph.png
    PROPERTY(0x200007e7)                // 800x480\HMINissanResources\HMI\weather_legend\legend_hurricane_tracking_map_fr_mph.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_9308, 1)
    PROPERTY(0xe006903c)                // Display1: 105, Display2: 60
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9364, 7)
    PROPERTY(0x200007f9)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_avoidroadahead_e.png
    PROPERTY(0x200007fa)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_avoidroadahead_f.png
    PROPERTY(0x200007fb)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_avoidroadahead_d.png
    PROPERTY(0x200007fb)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_avoidroadahead_d.png
    PROPERTY(0x200007f9)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_avoidroadahead_e.png
    PROPERTY(0x200007fa)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_avoidroadahead_f.png
    PROPERTY(0x200007fc)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_avoidroadahead_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_9392, 4)
    PROPERTY(0x80000827)                // psi -> Settings__strliTyrePressure.Labeltext-000
    PROPERTY(0x80000828)                //  kPa -> Settings__strliTyrePressure.Labeltext-001
    PROPERTY(0x80000829)                // bar -> Settings__strliTyrePressure.Labeltext-002
    PROPERTY(0x8000082a)                // kgf/cm2 -> Settings__strliTyrePressure.Labeltext-003
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9469, 7)
    PROPERTY(0x200007fd)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_address_e.png
    PROPERTY(0x200007fe)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_address_f.png
    PROPERTY(0x200007ff)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_address_d.png
    PROPERTY(0x200007ff)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_address_d.png
    PROPERTY(0x200007fd)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_address_e.png
    PROPERTY(0x200007fe)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_address_f.png
    PROPERTY(0x20000800)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_address_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9472, 7)
    PROPERTY(0x20000801)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_places_e.png
    PROPERTY(0x20000802)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_places_f.png
    PROPERTY(0x20000803)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_places_d.png
    PROPERTY(0x20000803)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_places_d.png
    PROPERTY(0x20000801)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_places_e.png
    PROPERTY(0x20000802)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_places_f.png
    PROPERTY(0x20000804)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_places_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9475, 7)
    PROPERTY(0x20000805)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_home_e.png
    PROPERTY(0x20000806)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_home_f.png
    PROPERTY(0x20000807)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_home_d.png
    PROPERTY(0x20000807)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_home_d.png
    PROPERTY(0x20000805)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_home_e.png
    PROPERTY(0x20000806)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_home_f.png
    PROPERTY(0x20000808)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_home_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9480, 7)
    PROPERTY(0x20000809)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prev_dest_e.png
    PROPERTY(0x2000080a)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prev_dest_f.png
    PROPERTY(0x2000080b)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prev_dest_d.png
    PROPERTY(0x2000080b)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prev_dest_d.png
    PROPERTY(0x20000809)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prev_dest_e.png
    PROPERTY(0x2000080a)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prev_dest_f.png
    PROPERTY(0x2000080c)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_prev_dest_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9741, 7)
    PROPERTY(0x2000080d)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearbyparking_e.png
    PROPERTY(0x2000080e)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearbyparking_f.png
    PROPERTY(0x2000080f)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearbyparking_d.png
    PROPERTY(0x2000080f)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearbyparking_d.png
    PROPERTY(0x2000080d)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearbyparking_e.png
    PROPERTY(0x2000080e)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearbyparking_f.png
    PROPERTY(0x20000810)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearbyparking_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9744, 7)
    PROPERTY(0x20000811)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchnearby_e.png
    PROPERTY(0x20000812)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchnearby_f.png
    PROPERTY(0x20000813)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchnearby_d.png
    PROPERTY(0x20000813)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchnearby_d.png
    PROPERTY(0x20000811)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchnearby_e.png
    PROPERTY(0x20000812)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchnearby_f.png
    PROPERTY(0x20000814)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchnearby_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9749, 7)
    PROPERTY(0x20000815)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_gas_e.png
    PROPERTY(0x20000816)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_gas_f.png
    PROPERTY(0x20000817)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_gas_d.png
    PROPERTY(0x20000817)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_gas_d.png
    PROPERTY(0x20000815)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_gas_e.png
    PROPERTY(0x20000816)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_gas_f.png
    PROPERTY(0x20000818)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_gas_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9752, 7)
    PROPERTY(0x20000819)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchinanothercity_e.png
    PROPERTY(0x2000081a)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchinanothercity_f.png
    PROPERTY(0x2000081b)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchinanothercity_d.png
    PROPERTY(0x2000081b)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchinanothercity_d.png
    PROPERTY(0x20000819)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchinanothercity_e.png
    PROPERTY(0x2000081a)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchinanothercity_f.png
    PROPERTY(0x2000081c)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchinanothercity_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9755, 7)
    PROPERTY(0x2000081d)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchatdestination_e.png
    PROPERTY(0x2000081e)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchatdestination_f.png
    PROPERTY(0x2000081f)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchatdestination_d.png
    PROPERTY(0x2000081f)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchatdestination_d.png
    PROPERTY(0x2000081d)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchatdestination_e.png
    PROPERTY(0x2000081e)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchatdestination_f.png
    PROPERTY(0x20000820)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_searchatdestination_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9766, 7)
    PROPERTY(0x20000821)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_food_e.png
    PROPERTY(0x20000822)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_food_f.png
    PROPERTY(0x20000823)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_food_d.png
    PROPERTY(0x20000823)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_food_d.png
    PROPERTY(0x20000821)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_food_e.png
    PROPERTY(0x20000822)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_food_f.png
    PROPERTY(0x20000824)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_food_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9775, 7)
    PROPERTY(0x20000825)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_e.png
    PROPERTY(0x20000826)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_f.png
    PROPERTY(0x20000827)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_d.png
    PROPERTY(0x20000827)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_d.png
    PROPERTY(0x20000825)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_e.png
    PROPERTY(0x20000826)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_f.png
    PROPERTY(0x20000828)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_9777, 7)
    PROPERTY(0x20000829)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_eu_e.png
    PROPERTY(0x2000082a)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_eu_f.png
    PROPERTY(0x2000082b)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_eu_d.png
    PROPERTY(0x2000082b)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_eu_d.png
    PROPERTY(0x20000829)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_eu_e.png
    PROPERTY(0x2000082a)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_eu_f.png
    PROPERTY(0x2000082c)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_nearby_atm_eu_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_10224, 7)
    PROPERTY(0x2000082d)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_addressbook_e.png
    PROPERTY(0x2000082e)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_addressbook_f.png
    PROPERTY(0x2000082f)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_addressbook_d.png
    PROPERTY(0x2000082f)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_addressbook_d.png
    PROPERTY(0x2000082d)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_addressbook_e.png
    PROPERTY(0x2000082e)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_addressbook_f.png
    PROPERTY(0x20000830)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_addressbook_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_10227, 7)
    PROPERTY(0x20000831)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_intersection_e.png
    PROPERTY(0x20000832)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_intersection_f.png
    PROPERTY(0x20000833)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_intersection_d.png
    PROPERTY(0x20000833)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_intersection_d.png
    PROPERTY(0x20000831)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_intersection_e.png
    PROPERTY(0x20000832)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_intersection_f.png
    PROPERTY(0x20000834)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_intersection_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_10230, 7)
    PROPERTY(0x20000835)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_citycenter_e.png
    PROPERTY(0x20000836)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_citycenter_f.png
    PROPERTY(0x20000837)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_citycenter_d.png
    PROPERTY(0x20000837)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_citycenter_d.png
    PROPERTY(0x20000835)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_citycenter_e.png
    PROPERTY(0x20000836)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_citycenter_f.png
    PROPERTY(0x20000838)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_citycenter_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_10235, 7)
    PROPERTY(0x20000839)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_myplaces_e.png
    PROPERTY(0x2000083a)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_myplaces_f.png
    PROPERTY(0x2000083b)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_myplaces_d.png
    PROPERTY(0x2000083b)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_myplaces_d.png
    PROPERTY(0x20000839)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_myplaces_e.png
    PROPERTY(0x2000083a)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_myplaces_f.png
    PROPERTY(0x2000083c)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_myplaces_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_11065, 9)
    PROPERTY(0x2000083e)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_ok_e.png
    PROPERTY(0x2000022d)                // 800x480\HMINissanResources\HMI\speller_header\speller_btn_ok_e_f.png
    PROPERTY(0x2000022e)                // 800x480\HMINissanResources\HMI\speller_header\speller_btn_ok_d.png
    PROPERTY(0x2000022e)                // 800x480\HMINissanResources\HMI\speller_header\speller_btn_ok_d.png
    PROPERTY(0x2000083e)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_ok_e.png
    PROPERTY(0x2000022d)                // 800x480\HMINissanResources\HMI\speller_header\speller_btn_ok_e_f.png
    PROPERTY(0x2000022f)                // 800x480\HMINissanResources\HMI\speller_header\speller_btn_ok_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_11077, 9)
    PROPERTY(0x2000083f)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_book_unkown.png
    PROPERTY(0x20000840)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_book_general.png
    PROPERTY(0x20000841)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_book_mobile.png
    PROPERTY(0x20000842)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_book_office.png
    PROPERTY(0x20000843)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_book_home.png
    PROPERTY(0x20000844)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_book_fax.png
    PROPERTY(0x20000845)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_book_pager.png
    PROPERTY(0x20000846)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_book_car.png
    PROPERTY(0x20000847)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_book_sim.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_11109, 9)
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000da)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_d.png
    PROPERTY(0x200000d8)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e.png
    PROPERTY(0x200000d9)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_e_f.png
    PROPERTY(0x200000db)                // 800x480\HMINissanResources\HMI\list\li_6row_83p_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_11179, 7)
    PROPERTY(0x20000849)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_numpad_a.png
    PROPERTY(0x2000084a)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_numpad_a_f.png
    PROPERTY(0x2000084b)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_numpad_e.png
    PROPERTY(0x2000084b)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_numpad_e.png
    PROPERTY(0x2000084b)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_numpad_e.png
    PROPERTY(0x2000084c)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_numpad_f_p.png
    PROPERTY(0x2000084c)                // 800x480\HMINissanResources\HMI\icons_app\phone_icon_numpad_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_11360, 9)
    PROPERTY(0x20000230)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_e.png
    PROPERTY(0x20000231)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_e_f.png
    PROPERTY(0x20000232)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_d.png
    PROPERTY(0x20000232)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_d.png
    PROPERTY(0x20000230)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_e.png
    PROPERTY(0x20000029)                // 800x480\HMINissanResources\HMI\button\btn_4btn_row_e_f.png
    PROPERTY(0x20000233)                // 800x480\HMINissanResources\HMI\button_speller\speller_btn_function_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_11407, 7)
    PROPERTY(0x20000854)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_audio_settings_e.png
    PROPERTY(0x20000855)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_audio_settings_f.png
    PROPERTY(0x20000856)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_audio_settings_d.png
    PROPERTY(0x20000856)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_audio_settings_d.png
    PROPERTY(0x20000854)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_audio_settings_e.png
    PROPERTY(0x20000855)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_audio_settings_f.png
    PROPERTY(0x20000857)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_audio_settings_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_11414, 7)
    PROPERTY(0x20000858)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_system_settings_e.png
    PROPERTY(0x20000859)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_system_settings_f.png
    PROPERTY(0x2000085a)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_system_settings_d.png
    PROPERTY(0x2000085a)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_system_settings_d.png
    PROPERTY(0x20000858)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_system_settings_e.png
    PROPERTY(0x20000859)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_system_settings_f.png
    PROPERTY(0x2000085b)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_system_settings_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_11416, 7)
    PROPERTY(0x2000085c)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_radio_settings_e.png
    PROPERTY(0x2000085d)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_radio_settings_f.png
    PROPERTY(0x2000085e)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_radio_settings_d.png
    PROPERTY(0x2000085e)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_radio_settings_d.png
    PROPERTY(0x2000085c)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_radio_settings_e.png
    PROPERTY(0x2000085d)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_radio_settings_f.png
    PROPERTY(0x2000085f)                // 800x480\HMINissanResources\HMI\icons_buttons\icon_6btn_radio_settings_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_11454, 8)
    PROPERTY(0xe008504c)                // Display1: 133, Display2: 76
    PROPERTY(0xe00af064)                // Display1: 175, Display2: 100
    PROPERTY(0xe00d907c)                // Display1: 217, Display2: 124
    PROPERTY(0xe0103094)                // Display1: 259, Display2: 148
    PROPERTY(0xe012d0ac)                // Display1: 301, Display2: 172
    PROPERTY(0xe01570c4)                // Display1: 343, Display2: 196
    PROPERTY(0xe01810dc)                // Display1: 385, Display2: 220
    PROPERTY(0xe01ab0f4)                // Display1: 427, Display2: 244
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TopOffset_11493, 6)
    PROPERTY(0xe0000000)                // Display1: 0, Display2: 0
    PROPERTY(0xe0046028)                // Display1: 70, Display2: 40
    PROPERTY(0xe007e048)                // Display1: 126, Display2: 72
    PROPERTY(0xe00bd06c)                // Display1: 189, Display2: 108
    PROPERTY(0xe00fc090)                // Display1: 252, Display2: 144
    PROPERTY(0xe013b0b4)                // Display1: 315, Display2: 180
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strSettingsPOIDistances_meter, 8)
    PROPERTY(0x800002dc)                // 250m -> SET.strSettingsPOIDistances_meter-000
    PROPERTY(0x80000146)                // 500m -> NAV.MAP.strlstZoomLevel_meter-003
    PROPERTY(0x800002dd)                // 1000m -> SET.strSettingsPOIDistances_meter-002
    PROPERTY(0x800002de)                // 1.5km -> SET.strSettingsPOIDistances_meter-003
    PROPERTY(0x800002df)                // 2.0km -> SET.strSettingsPOIDistances_meter-004
    PROPERTY(0x800002e0)                // 3.0km -> SET.strSettingsPOIDistances_meter-005
    PROPERTY(0x800002e1)                // 4.0km -> SET.strSettingsPOIDistances_meter-006
    PROPERTY(0x800002e2)                // 5.0km -> SET.strSettingsPOIDistances_meter-007
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strSettingsPOIDistances_miles, 8)
    PROPERTY(0x800002e3)                // 1000 ft -> SET.strSettingsPOIDistances_miles-000
    PROPERTY(0x800002e4)                // 1/4 Mile -> SET.strSettingsPOIDistances_miles-001
    PROPERTY(0x800002e5)                // 1/2 Mile -> SET.strSettingsPOIDistances_miles-002
    PROPERTY(0x800002e6)                // 1 Mile -> SET.strSettingsPOIDistances_miles-003
    PROPERTY(0x800002e7)                // 1.5 Miles -> SET.strSettingsPOIDistances_miles-004
    PROPERTY(0x800002e8)                // 2 Miles -> SET.strSettingsPOIDistances_miles-005
    PROPERTY(0x800002e9)                // 3 Miles -> SET.strSettingsPOIDistances_miles-006
    PROPERTY(0x800002ea)                // 5 Miles -> SET.strSettingsPOIDistances_miles-007
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_11704, 9)
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x2000027a)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e_f.png
    PROPERTY(0x2000027b)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x2000027a)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e_f.png
    PROPERTY(0x2000027c)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_p.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
    PROPERTY(0x20000279)                // 800x480\HMINissanResources\HMI\list\li_5row_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_11755, 3)
    PROPERTY(0x800005e5)                // #No translation required -> TRA__NavSatelliteSystem-000
    PROPERTY(0x800005e6)                // #No translation required -> TRA__NavSatelliteSystem-001
    PROPERTY(0x800005e7)                // #No translation required -> TRA__NavSatelliteSystem-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_11760, 3)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000270)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_2_1.png
    PROPERTY(0x20000271)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_2_2.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_12112, 11)
    PROPERTY(0x20000860)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_11_steps\set_bal11_l_05.png
    PROPERTY(0x20000861)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_11_steps\set_bal11_l_04.png
    PROPERTY(0x20000862)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_11_steps\set_bal11_l_03.png
    PROPERTY(0x20000863)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_11_steps\set_bal11_l_02.png
    PROPERTY(0x20000864)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_11_steps\set_bal11_l_01.png
    PROPERTY(0x20000865)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_11_steps\set_bal11_n.png
    PROPERTY(0x20000866)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_11_steps\set_bal11_r_01.png
    PROPERTY(0x20000867)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_11_steps\set_bal11_r_02.png
    PROPERTY(0x20000868)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_11_steps\set_bal11_r_03.png
    PROPERTY(0x20000869)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_11_steps\set_bal11_r_04.png
    PROPERTY(0x2000086a)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_11_steps\set_bal11_r_05.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12121, 9)
    PROPERTY(0x2000086b)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_right_e.png
    PROPERTY(0x2000086b)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_right_e.png
    PROPERTY(0x2000086c)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_right_d.png
    PROPERTY(0x2000086c)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_right_d.png
    PROPERTY(0x2000086b)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_right_e.png
    PROPERTY(0x2000086b)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_right_e.png
    PROPERTY(0x2000086d)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_right_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12123, 9)
    PROPERTY(0x2000086e)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_left_e.png
    PROPERTY(0x2000086e)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_left_e.png
    PROPERTY(0x2000086f)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_left_d.png
    PROPERTY(0x2000086f)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_left_d.png
    PROPERTY(0x2000086e)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_left_e.png
    PROPERTY(0x2000086e)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_left_e.png
    PROPERTY(0x20000870)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_left_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12128, 9)
    PROPERTY(0x20000871)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_down_e.png
    PROPERTY(0x20000871)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_down_e.png
    PROPERTY(0x20000872)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_down_d.png
    PROPERTY(0x20000872)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_down_d.png
    PROPERTY(0x20000871)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_down_e.png
    PROPERTY(0x20000871)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_down_e.png
    PROPERTY(0x20000873)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_down_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12130, 9)
    PROPERTY(0x20000874)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_up_e.png
    PROPERTY(0x20000874)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_up_e.png
    PROPERTY(0x20000875)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_up_d.png
    PROPERTY(0x20000875)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_up_d.png
    PROPERTY(0x20000874)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_up_e.png
    PROPERTY(0x20000874)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_up_e.png
    PROPERTY(0x20000876)                // 800x480\HMINissanResources\HMI\button_settings\set_btn_up_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_12137, 3)
    PROPERTY(0x800002a6)                // Low -> SET.strliSettingsAudio.ListItemChoiceAuxLevel.content.QuietMiddleLoud-000
    PROPERTY(0x800002a7)                // Medium -> SET.strliSettingsAudio.ListItemChoiceAuxLevel.content.QuietMiddleLoud-001
    PROPERTY(0x800002a8)                // High -> SET.strliSettingsAudio.ListItemChoiceAuxLevel.content.QuietMiddleLoud-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_12254, 2)
    PROPERTY(0x800002b7)                // 12 h -> SET.strliSettingsSystemClock.ListItemChoiceTimeFormat.ButtonTop.content.12H(AM/PM)-000
    PROPERTY(0x800002b8)                // 24 h -> SET.strliSettingsSystemClock.ListItemChoiceTimeFormat.ButtonTop.content.12H(AM/PM)-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_12259, 5)
    PROPERTY(0x800002b5)                // DD/MM/YYYY -> SET.strliSettingsSystemClock.ListItemChoiceDateFormat.ButtonTop.content.dd_mm_yy-000
    PROPERTY(0x800002b6)                // MM/DD/YYYY -> SET.strliSettingsSystemClock.ListItemChoiceDateFormat.ButtonTop.content.dd_mm_yy-001
    PROPERTY(0x8000032d)                // DD.MM.YYYY -> SETTINGS_SYSTEM_CLOCK.ListItemChoice_DateFormat.content-002
    PROPERTY(0x8000032e)                // DD-MM-YYYY -> SETTINGS_SYSTEM_CLOCK.ListItemChoice_DateFormat.content-003
    PROPERTY(0x8000032f)                // YYYY-DD-MM -> SETTINGS_SYSTEM_CLOCK.ListItemChoice_DateFormat.content-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_12264, 5)
    PROPERTY(0x20000877)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_5_1.png
    PROPERTY(0x20000878)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_5_2.png
    PROPERTY(0x20000879)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_5_3.png
    PROPERTY(0x2000087a)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_5_4.png
    PROPERTY(0x2000087b)                // 800x480\HMINissanResources\HMI\choice_buttons\set_choice_btn_5_5.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_12265, 3)
    PROPERTY(0x800002b2)                // Manual -> SET.strliSettingsSystemClock.ListItemChoiceClockFormat.ButtonTop.content.Clock_mode-000
    PROPERTY(0x800002b3)                // Time Zone -> SET.strliSettingsSystemClock.ListItemChoiceClockFormat.ButtonTop.content.Clock_mode-001
    PROPERTY(0x800002b4)                // Auto -> SET.strliSettingsSystemClock.ListItemChoiceClockFormat.ButtonTop.content.Clock_mode-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_12382, 19)
    PROPERTY(0x2000087c)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_l_09.png
    PROPERTY(0x2000087d)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_l_08.png
    PROPERTY(0x2000087e)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_l_07.png
    PROPERTY(0x2000087f)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_l_06.png
    PROPERTY(0x20000880)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_l_05.png
    PROPERTY(0x20000881)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_l_04.png
    PROPERTY(0x20000882)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_l_03.png
    PROPERTY(0x20000883)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_l_02.png
    PROPERTY(0x20000884)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_l_01.png
    PROPERTY(0x20000885)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_n.png
    PROPERTY(0x20000886)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_r_01.png
    PROPERTY(0x20000887)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_r_02.png
    PROPERTY(0x20000888)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_r_03.png
    PROPERTY(0x20000889)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_r_04.png
    PROPERTY(0x2000088a)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_r_05.png
    PROPERTY(0x2000088b)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_r_06.png
    PROPERTY(0x2000088c)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_r_07.png
    PROPERTY(0x2000088d)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_r_08.png
    PROPERTY(0x2000088e)                // 800x480\HMINissanResources\HMI\bargraph\set_bal_19_steps\set_bal_r_09.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_12383, 3)
    PROPERTY(0x800002b9)                // Auto -> SET.strliSettingsSystemDisplay.ListItemChoiceDisplayMode.ButtonTop.Labeltext.content-000
    PROPERTY(0x800002ba)                // Day -> SET.strliSettingsSystemDisplay.ListItemChoiceDisplayMode.ButtonTop.Labeltext.content-001
    PROPERTY(0x800002bb)                // Night -> SET.strliSettingsSystemDisplay.ListItemChoiceDisplayMode.ButtonTop.Labeltext.content-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(content_12388, 1)
    PROPERTY(0x800002bc)                // moves -> SET.strliSettingsSystemDisplay.ListItemChoiceEncoderDirection.content.Turns-000
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12390, 9)
    PROPERTY(0x20000266)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e.png
    PROPERTY(0x20000267)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e_f.png
    PROPERTY(0x20000268)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_d.png
    PROPERTY(0x20000268)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_d.png
    PROPERTY(0x20000266)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e.png
    PROPERTY(0x20000267)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_e_f.png
    PROPERTY(0x20000269)                // 800x480\HMINissanResources\HMI\list_settings\if_settings_83p_p.png
    PROPERTY(0x20000272)                // 800x480\HMINissanResources\HMI\list_settings\if_display_settings_83p_e.png
    PROPERTY(0x20000272)                // 800x480\HMINissanResources\HMI\list_settings\if_display_settings_83p_e.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(RVC__strDyIPAMessageStringList, 47)
    PROPERTY(0x80000200)                // #No translation required -> RVC__strDyIPAMessageStringList-000
    PROPERTY(0x80000201)                // Ensure it is safe before maneuvering -> RVC__strDyIPAMessageStringList-001
    PROPERTY(0x80000202)                // Check surroundings -> RVC__strDyIPAMessageStringList-002
    PROPERTY(0x80000203)                // Stop beside park slot to start park assist -> RVC__strDyIPAMessageStringList-003
    PROPERTY(0x80000204)                // Drive forward -> RVC__strDyIPAMessageStringList-004
    PROPERTY(0x80000205)                // Reduce speed -> RVC__strDyIPAMessageStringList-005
    PROPERTY(0x80000206)                // Stop and select reverse gear -> RVC__strDyIPAMessageStringList-006
    PROPERTY(0x80000207)                // Stop and select drive gear -> RVC__strDyIPAMessageStringList-007
    PROPERTY(0x80000208)                // Drive rearward -> RVC__strDyIPAMessageStringList-008
    PROPERTY(0x80000209)                // Stop next to empty parking space -> RVC__strDyIPAMessageStringList-009
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x8000020a)                // Adjust park position -> RVC__strDyIPAMessageStringList-011
    PROPERTY(0x8000020b)                // Steering rotating -> RVC__strDyIPAMessageStringList-012
    PROPERTY(0x8000020c)                // Drive forward with care -> RVC__strDyIPAMessageStringList-013
    PROPERTY(0x8000020d)                // Drive backward with care -> RVC__strDyIPAMessageStringList-014
    PROPERTY(0x8000020e)                // Check obstacle! -> RVC__strDyIPAMessageStringList-015
    PROPERTY(0x8000020f)                // Finished -> RVC__strDyIPAMessageStringList-016
    PROPERTY(0x80000210)                // Select drive gear -> RVC__strDyIPAMessageStringList-017
    PROPERTY(0x80000211)                // Centre steering wheel -> RVC__strDyIPAMessageStringList-018
    PROPERTY(0x80000212)                // Remove trailer -> RVC__strDyIPAMessageStringList-019
    PROPERTY(0x80000213)                // VDC must be ON -> RVC__strDyIPAMessageStringList-020
    PROPERTY(0x80000214)                // Close door to start -> RVC__strDyIPAMessageStringList-021
    PROPERTY(0x80000215)                // System Fault -> RVC__strDyIPAMessageStringList-022
    PROPERTY(0x80000216)                // IPA fault -> RVC__strDyIPAMessageStringList-023
    PROPERTY(0x80000217)                // Over Speed -> RVC__strDyIPAMessageStringList-024
    PROPERTY(0x80000218)                // Steering Intervened -> RVC__strDyIPAMessageStringList-025
    PROPERTY(0x80000219)                // Trailer ON -> RVC__strDyIPAMessageStringList-026
    PROPERTY(0x8000021a)                // VDC Active -> RVC__strDyIPAMessageStringList-027
    PROPERTY(0x8000021b)                // Door Open / Belt OFF -> RVC__strDyIPAMessageStringList-028
    PROPERTY(0x8000021c)                // Time Out -> RVC__strDyIPAMessageStringList-029
    PROPERTY(0x8000021d)                // Multi step mode -> RVC__strDyIPAMessageStringList-030
    PROPERTY(0x8000021e)                // Switch back mode -> RVC__strDyIPAMessageStringList-031
    PROPERTY(0x8000021f)                // Turn signal to switch side -> RVC__strDyIPAMessageStringList-032
    PROPERTY(0x80000220)                // Park Assist Unavailable -> RVC__strDyIPAMessageStringList-033
    PROPERTY(0x80000221)                // Engine not active -> RVC__strDyIPAMessageStringList-034
    PROPERTY(0x80000222)                // EPS not active -> RVC__strDyIPAMessageStringList-035
    PROPERTY(0x80000223)                // Fwd gear outside of park slot -> RVC__strDyIPAMessageStringList-036
    PROPERTY(0x80000224)                // Resume not possible -> RVC__strDyIPAMessageStringList-037
    PROPERTY(0x80000225)                // Space found -> RVC__strDyIPAMessageStringList-038
    PROPERTY(0x80000226)                // Stop -> RVC__strDyIPAMessageStringList-039
    PROPERTY(0x80000227)                // Select reverse gear -> RVC__strDyIPAMessageStringList-040
    PROPERTY(0x80000228)                // Drive rearward -> RVC__strDyIPAMessageStringList-041
    PROPERTY(0x80000229)                // Reduce speed -> RVC__strDyIPAMessageStringList-042
    PROPERTY(0x8000022a)                // Drive forward -> RVC__strDyIPAMessageStringList-043
    PROPERTY(0x8000022b)                // Park Assist canceled -> RVC__strDyIPAMessageStringList-044
    PROPERTY(0x8000022c)                // Park Assist finished -> RVC__strDyIPAMessageStringList-045
    PROPERTY(0x8000022d)                // Canceled -> RVC__strDyIPAMessageStringList-046
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_12603, 47)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000899)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_stop.png
    PROPERTY(0x2000089a)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_fwd.png
    PROPERTY(0x2000089b)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_bwd.png
    PROPERTY(0x20000899)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_stop.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x2000089c)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_att.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12604, 9)
    PROPERTY(0x2000089d)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_e.png
    PROPERTY(0x2000089e)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_e_f.png
    PROPERTY(0x2000089f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_d.png
    PROPERTY(0x2000089f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_d.png
    PROPERTY(0x2000089d)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_e.png
    PROPERTY(0x2000089e)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_e_f.png
    PROPERTY(0x200008a0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12605, 9)
    PROPERTY(0x200008a1)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_e.png
    PROPERTY(0x200008a2)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_e_f.png
    PROPERTY(0x200008a3)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_d.png
    PROPERTY(0x200008a3)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_d.png
    PROPERTY(0x200008a1)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_e.png
    PROPERTY(0x200008a2)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_e_f.png
    PROPERTY(0x200008a4)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12613, 9)
    PROPERTY(0x2000089f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_d.png
    PROPERTY(0x2000089f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_d.png
    PROPERTY(0x2000089f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_d.png
    PROPERTY(0x2000089f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_d.png
    PROPERTY(0x2000089f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_d.png
    PROPERTY(0x2000089f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_d.png
    PROPERTY(0x2000089f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_acw_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12614, 9)
    PROPERTY(0x200008a3)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_d.png
    PROPERTY(0x200008a3)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_d.png
    PROPERTY(0x200008a3)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_d.png
    PROPERTY(0x200008a3)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_d.png
    PROPERTY(0x200008a3)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_d.png
    PROPERTY(0x200008a3)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_d.png
    PROPERTY(0x200008a3)                // 800x480\HMINissanResources\HMI\button\btn_ipa_cw_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12615, 9)
    PROPERTY(0x2000058f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_d.png
    PROPERTY(0x2000058f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_d.png
    PROPERTY(0x2000058f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_d.png
    PROPERTY(0x2000058f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_d.png
    PROPERTY(0x2000058f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_d.png
    PROPERTY(0x2000058f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_d.png
    PROPERTY(0x2000058f)                // 800x480\HMINissanResources\HMI\button\btn_ipa_up_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12616, 9)
    PROPERTY(0x2000069c)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_d.png
    PROPERTY(0x2000069c)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_d.png
    PROPERTY(0x2000069c)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_d.png
    PROPERTY(0x2000069c)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_d.png
    PROPERTY(0x2000069c)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_d.png
    PROPERTY(0x2000069c)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_d.png
    PROPERTY(0x2000069c)                // 800x480\HMINissanResources\HMI\button\btn_ipa_left_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12617, 9)
    PROPERTY(0x20000593)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_d.png
    PROPERTY(0x20000593)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_d.png
    PROPERTY(0x20000593)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_d.png
    PROPERTY(0x20000593)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_d.png
    PROPERTY(0x20000593)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_d.png
    PROPERTY(0x20000593)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_d.png
    PROPERTY(0x20000593)                // 800x480\HMINissanResources\HMI\button\btn_ipa_down_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12618, 9)
    PROPERTY(0x200006a0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_d.png
    PROPERTY(0x200006a0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_d.png
    PROPERTY(0x200006a0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_d.png
    PROPERTY(0x200006a0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_d.png
    PROPERTY(0x200006a0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_d.png
    PROPERTY(0x200006a0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_d.png
    PROPERTY(0x200006a0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_right_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12627, 9)
    PROPERTY(0x200008aa)                // 800x480\HMINissanResources\HMI\button\btn_ipa_e.png
    PROPERTY(0x200008ab)                // 800x480\HMINissanResources\HMI\button\btn_ipa_e_f.png
    PROPERTY(0x200008ac)                // 800x480\HMINissanResources\HMI\button\btn_ipa_d.png
    PROPERTY(0x200008ac)                // 800x480\HMINissanResources\HMI\button\btn_ipa_d.png
    PROPERTY(0x200008aa)                // 800x480\HMINissanResources\HMI\button\btn_ipa_e.png
    PROPERTY(0x200008ab)                // 800x480\HMINissanResources\HMI\button\btn_ipa_e_f.png
    PROPERTY(0x200008ad)                // 800x480\HMINissanResources\HMI\button\btn_ipa_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12634, 9)
    PROPERTY(0x200008ae)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_e.png
    PROPERTY(0x200008af)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_e_f.png
    PROPERTY(0x200008b0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_d.png
    PROPERTY(0x200008b0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_d.png
    PROPERTY(0x200008ae)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_e.png
    PROPERTY(0x200008af)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_e_f.png
    PROPERTY(0x200008b1)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12636, 9)
    PROPERTY(0x200008b2)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_e.png
    PROPERTY(0x200008b3)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_e_f.png
    PROPERTY(0x200008b4)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_d.png
    PROPERTY(0x200008b4)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_d.png
    PROPERTY(0x200008b2)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_e.png
    PROPERTY(0x200008b3)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_e_f.png
    PROPERTY(0x200008b5)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12638, 9)
    PROPERTY(0x200008b6)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_e.png
    PROPERTY(0x200008b7)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_e_f.png
    PROPERTY(0x200008b8)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_d.png
    PROPERTY(0x200008b8)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_d.png
    PROPERTY(0x200008b6)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_e.png
    PROPERTY(0x200008b7)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_e_f.png
    PROPERTY(0x200008b9)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12642, 9)
    PROPERTY(0x200008ac)                // 800x480\HMINissanResources\HMI\button\btn_ipa_d.png
    PROPERTY(0x200008ac)                // 800x480\HMINissanResources\HMI\button\btn_ipa_d.png
    PROPERTY(0x200008ac)                // 800x480\HMINissanResources\HMI\button\btn_ipa_d.png
    PROPERTY(0x200008ac)                // 800x480\HMINissanResources\HMI\button\btn_ipa_d.png
    PROPERTY(0x200008ac)                // 800x480\HMINissanResources\HMI\button\btn_ipa_d.png
    PROPERTY(0x200008ac)                // 800x480\HMINissanResources\HMI\button\btn_ipa_d.png
    PROPERTY(0x200008ac)                // 800x480\HMINissanResources\HMI\button\btn_ipa_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12645, 9)
    PROPERTY(0x200008b0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_d.png
    PROPERTY(0x200008b0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_d.png
    PROPERTY(0x200008b0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_d.png
    PROPERTY(0x200008b0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_d.png
    PROPERTY(0x200008b0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_d.png
    PROPERTY(0x200008b0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_d.png
    PROPERTY(0x200008b0)                // 800x480\HMINissanResources\HMI\button\btn_ipa_stwheel_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12646, 9)
    PROPERTY(0x200008b4)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_d.png
    PROPERTY(0x200008b4)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_d.png
    PROPERTY(0x200008b4)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_d.png
    PROPERTY(0x200008b4)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_d.png
    PROPERTY(0x200008b4)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_d.png
    PROPERTY(0x200008b4)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_d.png
    PROPERTY(0x200008b4)                // 800x480\HMINissanResources\HMI\button\btn_ipa_bay_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12647, 9)
    PROPERTY(0x200008b8)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_d.png
    PROPERTY(0x200008b8)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_d.png
    PROPERTY(0x200008b8)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_d.png
    PROPERTY(0x200008b8)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_d.png
    PROPERTY(0x200008b8)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_d.png
    PROPERTY(0x200008b8)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_d.png
    PROPERTY(0x200008b8)                // 800x480\HMINissanResources\HMI\button\btn_ipa_parallel_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_12649, 2)
    PROPERTY(0x200008ba)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_cam_front.png
    PROPERTY(0x200008bb)                // 800x480\HMINissanResources\HMI\ipa\ipa_sign_cam_rear.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_12744, 3)
    PROPERTY(0x200008bd)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_Sedan.png
    PROPERTY(0x200008be)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_SUV.png
    PROPERTY(0x200008bf)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_Van.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_12745, 11)
    PROPERTY(0x200008c0)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_left_n.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200008c1)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_left_g.png
    PROPERTY(0x200008c2)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_left_y.png
    PROPERTY(0x200008c3)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_left_r.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_12746, 11)
    PROPERTY(0x200008c4)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_center_n.png
    PROPERTY(0x200008c5)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_center_gg.png
    PROPERTY(0x200008c6)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_center_g.png
    PROPERTY(0x200008c7)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_center_y.png
    PROPERTY(0x200008c8)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_center_r.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_12747, 11)
    PROPERTY(0x200008c9)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_right_n.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200008ca)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_right_g.png
    PROPERTY(0x200008cb)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_right_y.png
    PROPERTY(0x200008cc)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_front_right_r.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_12748, 11)
    PROPERTY(0x200008cd)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_left_n.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200008ce)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_left_g.png
    PROPERTY(0x200008cf)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_left_y.png
    PROPERTY(0x200008d0)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_left_r.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_12749, 11)
    PROPERTY(0x200008d1)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_center_n.png
    PROPERTY(0x200008d2)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_center_gg.png
    PROPERTY(0x200008d3)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_center_g.png
    PROPERTY(0x200008d4)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_center_y.png
    PROPERTY(0x200008d5)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_center_r.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_12750, 11)
    PROPERTY(0x200008d6)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_right_n.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200008d7)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_right_g.png
    PROPERTY(0x200008d8)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_right_y.png
    PROPERTY(0x200008d9)                // 800x480\HMINissanResources\HMI\sonar\RVC_sonar_rear_right_r.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_12751, 7)
    PROPERTY(0x200008da)                // 800x480\HMINissanResources\HMI\icons_app\rvc_icon_sonaroff_a.png
    PROPERTY(0x200008db)                // 800x480\HMINissanResources\HMI\icons_app\rvc_icon_sonaroff_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200008dc)                // 800x480\HMINissanResources\HMI\icons_app\rvc_icon_sonaroff_e.png
    PROPERTY(0x200008dd)                // 800x480\HMINissanResources\HMI\icons_app\rvc_icon_sonaroff_f_p.png
    PROPERTY(0x200008dd)                // 800x480\HMINissanResources\HMI\icons_app\rvc_icon_sonaroff_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_12752, 9)
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x2000006f)                // 800x480\HMINissanResources\HMI\button\btn_map_menu_map_e.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(IconImages_12754, 7)
    PROPERTY(0x200008de)                // 800x480\HMINissanResources\HMI\icons_app\rvc_icon_sonaron_a.png
    PROPERTY(0x200008df)                // 800x480\HMINissanResources\HMI\icons_app\rvc_icon_sonaron_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200008e0)                // 800x480\HMINissanResources\HMI\icons_app\rvc_icon_sonaron_e.png
    PROPERTY(0x200008e1)                // 800x480\HMINissanResources\HMI\icons_app\rvc_icon_sonaron_f_p.png
    PROPERTY(0x200008e1)                // 800x480\HMINissanResources\HMI\icons_app\rvc_icon_sonaron_f_p.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_13446, 9)
    PROPERTY(0x200008e3)                // 800x480\HMINissanResources\HMI\status\status_icon_status_prev_a.png
    PROPERTY(0x200008e4)                // 800x480\HMINissanResources\HMI\status\status_icon_status_prev_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200008e5)                // 800x480\HMINissanResources\HMI\status\status_icon_status_prev_e.png
    PROPERTY(0x200008e5)                // 800x480\HMINissanResources\HMI\status\status_icon_status_prev_e.png
    PROPERTY(0x200008e6)                // 800x480\HMINissanResources\HMI\status\status_icon_status_prev_f_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_13447, 9)
    PROPERTY(0x200008e7)                // 800x480\HMINissanResources\HMI\status\status_icon_status_next_a.png
    PROPERTY(0x200008e8)                // 800x480\HMINissanResources\HMI\status\status_icon_status_next_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200008e9)                // 800x480\HMINissanResources\HMI\status\status_icon_status_next_e.png
    PROPERTY(0x200008e9)                // 800x480\HMINissanResources\HMI\status\status_icon_status_next_e.png
    PROPERTY(0x200008ea)                // 800x480\HMINissanResources\HMI\status\status_icon_status_next_f_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_13448, 1)
    PROPERTY(0xe001a00e)                // Display1: 26, Display2: 14
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_13449, 1)
    PROPERTY(0xe001f011)                // Display1: 31, Display2: 17
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_13455, 1)
    PROPERTY(0xe0020012)                // Display1: 32, Display2: 18
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_13479, 4)
    PROPERTY(0x200008f0)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_plasma.png
    PROPERTY(0x200008f1)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_plasma_blue.png
    PROPERTY(0x200008f2)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_plasma_green.png
    PROPERTY(0x200008f3)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_plasma_grey.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_13480, 8)
    PROPERTY(0x200008f4)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_0.png
    PROPERTY(0x200008f5)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_1.png
    PROPERTY(0x200008f6)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_2.png
    PROPERTY(0x200008f7)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_3.png
    PROPERTY(0x200008f8)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_4.png
    PROPERTY(0x200008f9)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_5.png
    PROPERTY(0x200008fa)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_6.png
    PROPERTY(0x200008fb)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_7.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_13482, 8)
    PROPERTY(0x200008fd)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_alloff.png
    PROPERTY(0x200008fe)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_vent.png
    PROPERTY(0x200008ff)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_b-l.png
    PROPERTY(0x20000900)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_foot.png
    PROPERTY(0x20000901)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_d-f.png
    PROPERTY(0x20000902)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_def.png
    PROPERTY(0x20000903)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_b-l-def.png
    PROPERTY(0x20000904)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_vent-def.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_13532, 1)
    PROPERTY(0xe0021012)                // Display1: 33, Display2: 18
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_13540, 4)
    PROPERTY(0x20000908)                // 800x480\HMINissanResources\HMI\status\status_icon_s_curve_right_de.png
    PROPERTY(0x20000909)                // 800x480\HMINissanResources\HMI\status\status_icon_s_curve_left_de.png
    PROPERTY(0x2000090a)                // 800x480\HMINissanResources\HMI\status\status_icon_curve_right_de.png
    PROPERTY(0x2000090b)                // 800x480\HMINissanResources\HMI\status\status_icon_curve_left_de.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R1_13576, 6)
    PROPERTY(0x2000090c)                // 800x480\HMINissanResources\HMI\listicon_16px\1030_e.png
    PROPERTY(0x2000090c)                // 800x480\HMINissanResources\HMI\listicon_16px\1030_e.png
    PROPERTY(0x2000090d)                // 800x480\HMINissanResources\HMI\listicon_16px\1030_f.png
    PROPERTY(0x2000090e)                // 800x480\HMINissanResources\HMI\listicon_16px\1030_p.png
    PROPERTY(0x2000090f)                // 800x480\HMINissanResources\HMI\listicon_16px\1030_a.png
    PROPERTY(0x20000910)                // 800x480\HMINissanResources\HMI\listicon_16px\1030_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R2, 6)
    PROPERTY(0x20000911)                // 800x480\HMINissanResources\HMI\listicon_16px\2030_e.png
    PROPERTY(0x20000911)                // 800x480\HMINissanResources\HMI\listicon_16px\2030_e.png
    PROPERTY(0x20000912)                // 800x480\HMINissanResources\HMI\listicon_16px\2030_f.png
    PROPERTY(0x20000913)                // 800x480\HMINissanResources\HMI\listicon_16px\2030_p.png
    PROPERTY(0x20000914)                // 800x480\HMINissanResources\HMI\listicon_16px\2030_a.png
    PROPERTY(0x20000915)                // 800x480\HMINissanResources\HMI\listicon_16px\2030_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R6_13577, 6)
    PROPERTY(0x20000916)                // 800x480\HMINissanResources\HMI\listicon_16px\1031_e.png
    PROPERTY(0x20000916)                // 800x480\HMINissanResources\HMI\listicon_16px\1031_e.png
    PROPERTY(0x20000917)                // 800x480\HMINissanResources\HMI\listicon_16px\1031_f.png
    PROPERTY(0x20000918)                // 800x480\HMINissanResources\HMI\listicon_16px\1031_p.png
    PROPERTY(0x20000919)                // 800x480\HMINissanResources\HMI\listicon_16px\1031_a.png
    PROPERTY(0x2000091a)                // 800x480\HMINissanResources\HMI\listicon_16px\1031_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R7_13578, 6)
    PROPERTY(0x2000091b)                // 800x480\HMINissanResources\HMI\listicon_16px\2031_e.png
    PROPERTY(0x2000091b)                // 800x480\HMINissanResources\HMI\listicon_16px\2031_e.png
    PROPERTY(0x2000091c)                // 800x480\HMINissanResources\HMI\listicon_16px\2031_f.png
    PROPERTY(0x2000091d)                // 800x480\HMINissanResources\HMI\listicon_16px\2031_p.png
    PROPERTY(0x2000091e)                // 800x480\HMINissanResources\HMI\listicon_16px\2031_a.png
    PROPERTY(0x2000091f)                // 800x480\HMINissanResources\HMI\listicon_16px\2031_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R11_13579, 6)
    PROPERTY(0x20000920)                // 800x480\HMINissanResources\HMI\listicon_16px\1032_e.png
    PROPERTY(0x20000920)                // 800x480\HMINissanResources\HMI\listicon_16px\1032_e.png
    PROPERTY(0x20000921)                // 800x480\HMINissanResources\HMI\listicon_16px\1032_f.png
    PROPERTY(0x20000922)                // 800x480\HMINissanResources\HMI\listicon_16px\1032_p.png
    PROPERTY(0x20000923)                // 800x480\HMINissanResources\HMI\listicon_16px\1032_a.png
    PROPERTY(0x20000924)                // 800x480\HMINissanResources\HMI\listicon_16px\1032_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R12_13580, 6)
    PROPERTY(0x20000925)                // 800x480\HMINissanResources\HMI\listicon_16px\2032_e.png
    PROPERTY(0x20000925)                // 800x480\HMINissanResources\HMI\listicon_16px\2032_e.png
    PROPERTY(0x20000926)                // 800x480\HMINissanResources\HMI\listicon_16px\2032_f.png
    PROPERTY(0x20000927)                // 800x480\HMINissanResources\HMI\listicon_16px\2032_p.png
    PROPERTY(0x20000928)                // 800x480\HMINissanResources\HMI\listicon_16px\2032_a.png
    PROPERTY(0x20000929)                // 800x480\HMINissanResources\HMI\listicon_16px\2032_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R16_13581, 6)
    PROPERTY(0x2000092a)                // 800x480\HMINissanResources\HMI\listicon_16px\1033_e.png
    PROPERTY(0x2000092a)                // 800x480\HMINissanResources\HMI\listicon_16px\1033_e.png
    PROPERTY(0x2000092b)                // 800x480\HMINissanResources\HMI\listicon_16px\1033_f.png
    PROPERTY(0x2000092c)                // 800x480\HMINissanResources\HMI\listicon_16px\1033_p.png
    PROPERTY(0x2000092d)                // 800x480\HMINissanResources\HMI\listicon_16px\1033_a.png
    PROPERTY(0x2000092e)                // 800x480\HMINissanResources\HMI\listicon_16px\1033_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R17_13582, 6)
    PROPERTY(0x2000092f)                // 800x480\HMINissanResources\HMI\listicon_16px\2033_e.png
    PROPERTY(0x2000092f)                // 800x480\HMINissanResources\HMI\listicon_16px\2033_e.png
    PROPERTY(0x20000930)                // 800x480\HMINissanResources\HMI\listicon_16px\2033_f.png
    PROPERTY(0x20000931)                // 800x480\HMINissanResources\HMI\listicon_16px\2033_p.png
    PROPERTY(0x20000932)                // 800x480\HMINissanResources\HMI\listicon_16px\2033_a.png
    PROPERTY(0x20000933)                // 800x480\HMINissanResources\HMI\listicon_16px\2033_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R21_13583, 6)
    PROPERTY(0x20000934)                // 800x480\HMINissanResources\HMI\listicon_16px\1034_e.png
    PROPERTY(0x20000934)                // 800x480\HMINissanResources\HMI\listicon_16px\1034_e.png
    PROPERTY(0x20000935)                // 800x480\HMINissanResources\HMI\listicon_16px\1034_f.png
    PROPERTY(0x20000936)                // 800x480\HMINissanResources\HMI\listicon_16px\1034_p.png
    PROPERTY(0x20000937)                // 800x480\HMINissanResources\HMI\listicon_16px\1034_a.png
    PROPERTY(0x20000938)                // 800x480\HMINissanResources\HMI\listicon_16px\1034_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R22, 6)
    PROPERTY(0x20000939)                // 800x480\HMINissanResources\HMI\listicon_16px\2034_e.png
    PROPERTY(0x20000939)                // 800x480\HMINissanResources\HMI\listicon_16px\2034_e.png
    PROPERTY(0x2000093a)                // 800x480\HMINissanResources\HMI\listicon_16px\2034_f.png
    PROPERTY(0x2000093b)                // 800x480\HMINissanResources\HMI\listicon_16px\2034_p.png
    PROPERTY(0x2000093c)                // 800x480\HMINissanResources\HMI\listicon_16px\2034_a.png
    PROPERTY(0x2000093d)                // 800x480\HMINissanResources\HMI\listicon_16px\2034_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R26_13584, 6)
    PROPERTY(0x2000093e)                // 800x480\HMINissanResources\HMI\listicon_16px\1035_e.png
    PROPERTY(0x2000093e)                // 800x480\HMINissanResources\HMI\listicon_16px\1035_e.png
    PROPERTY(0x2000093f)                // 800x480\HMINissanResources\HMI\listicon_16px\1035_f.png
    PROPERTY(0x20000940)                // 800x480\HMINissanResources\HMI\listicon_16px\1035_p.png
    PROPERTY(0x20000941)                // 800x480\HMINissanResources\HMI\listicon_16px\1035_a.png
    PROPERTY(0x20000942)                // 800x480\HMINissanResources\HMI\listicon_16px\1035_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R27_13585, 6)
    PROPERTY(0x20000943)                // 800x480\HMINissanResources\HMI\listicon_16px\2035_e.png
    PROPERTY(0x20000943)                // 800x480\HMINissanResources\HMI\listicon_16px\2035_e.png
    PROPERTY(0x20000944)                // 800x480\HMINissanResources\HMI\listicon_16px\2035_f.png
    PROPERTY(0x20000945)                // 800x480\HMINissanResources\HMI\listicon_16px\2035_p.png
    PROPERTY(0x20000946)                // 800x480\HMINissanResources\HMI\listicon_16px\2035_a.png
    PROPERTY(0x20000947)                // 800x480\HMINissanResources\HMI\listicon_16px\2035_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R31_13586, 6)
    PROPERTY(0x20000948)                // 800x480\HMINissanResources\HMI\listicon_16px\1036_e.png
    PROPERTY(0x20000948)                // 800x480\HMINissanResources\HMI\listicon_16px\1036_e.png
    PROPERTY(0x20000949)                // 800x480\HMINissanResources\HMI\listicon_16px\1036_f.png
    PROPERTY(0x2000094a)                // 800x480\HMINissanResources\HMI\listicon_16px\1036_p.png
    PROPERTY(0x2000094b)                // 800x480\HMINissanResources\HMI\listicon_16px\1036_a.png
    PROPERTY(0x2000094c)                // 800x480\HMINissanResources\HMI\listicon_16px\1036_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R32, 6)
    PROPERTY(0x2000094d)                // 800x480\HMINissanResources\HMI\listicon_16px\2036_e.png
    PROPERTY(0x2000094d)                // 800x480\HMINissanResources\HMI\listicon_16px\2036_e.png
    PROPERTY(0x2000094e)                // 800x480\HMINissanResources\HMI\listicon_16px\2036_f.png
    PROPERTY(0x2000094f)                // 800x480\HMINissanResources\HMI\listicon_16px\2036_p.png
    PROPERTY(0x20000950)                // 800x480\HMINissanResources\HMI\listicon_16px\2036_a.png
    PROPERTY(0x20000951)                // 800x480\HMINissanResources\HMI\listicon_16px\2036_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R36_13587, 6)
    PROPERTY(0x20000952)                // 800x480\HMINissanResources\HMI\listicon_16px\1037_e.png
    PROPERTY(0x20000952)                // 800x480\HMINissanResources\HMI\listicon_16px\1037_e.png
    PROPERTY(0x20000953)                // 800x480\HMINissanResources\HMI\listicon_16px\1037_f.png
    PROPERTY(0x20000954)                // 800x480\HMINissanResources\HMI\listicon_16px\1037_p.png
    PROPERTY(0x20000955)                // 800x480\HMINissanResources\HMI\listicon_16px\1037_a.png
    PROPERTY(0x20000956)                // 800x480\HMINissanResources\HMI\listicon_16px\1037_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R37_13588, 6)
    PROPERTY(0x20000957)                // 800x480\HMINissanResources\HMI\listicon_16px\2037_e.png
    PROPERTY(0x20000957)                // 800x480\HMINissanResources\HMI\listicon_16px\2037_e.png
    PROPERTY(0x20000958)                // 800x480\HMINissanResources\HMI\listicon_16px\2037_f.png
    PROPERTY(0x20000959)                // 800x480\HMINissanResources\HMI\listicon_16px\2037_p.png
    PROPERTY(0x2000095a)                // 800x480\HMINissanResources\HMI\listicon_16px\2037_a.png
    PROPERTY(0x2000095b)                // 800x480\HMINissanResources\HMI\listicon_16px\2037_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R41_13589, 6)
    PROPERTY(0x2000095c)                // 800x480\HMINissanResources\HMI\listicon_16px\1038_e.png
    PROPERTY(0x2000095c)                // 800x480\HMINissanResources\HMI\listicon_16px\1038_e.png
    PROPERTY(0x2000095d)                // 800x480\HMINissanResources\HMI\listicon_16px\1038_f.png
    PROPERTY(0x2000095e)                // 800x480\HMINissanResources\HMI\listicon_16px\1038_p.png
    PROPERTY(0x2000095f)                // 800x480\HMINissanResources\HMI\listicon_16px\1038_a.png
    PROPERTY(0x20000960)                // 800x480\HMINissanResources\HMI\listicon_16px\1038_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R42, 6)
    PROPERTY(0x20000961)                // 800x480\HMINissanResources\HMI\listicon_16px\2038_e.png
    PROPERTY(0x20000961)                // 800x480\HMINissanResources\HMI\listicon_16px\2038_e.png
    PROPERTY(0x20000962)                // 800x480\HMINissanResources\HMI\listicon_16px\2038_f.png
    PROPERTY(0x20000963)                // 800x480\HMINissanResources\HMI\listicon_16px\2038_p.png
    PROPERTY(0x20000964)                // 800x480\HMINissanResources\HMI\listicon_16px\2038_a.png
    PROPERTY(0x20000965)                // 800x480\HMINissanResources\HMI\listicon_16px\2038_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R46_13590, 6)
    PROPERTY(0x20000966)                // 800x480\HMINissanResources\HMI\listicon_16px\1039_e.png
    PROPERTY(0x20000966)                // 800x480\HMINissanResources\HMI\listicon_16px\1039_e.png
    PROPERTY(0x20000967)                // 800x480\HMINissanResources\HMI\listicon_16px\1039_f.png
    PROPERTY(0x20000968)                // 800x480\HMINissanResources\HMI\listicon_16px\1039_p.png
    PROPERTY(0x20000969)                // 800x480\HMINissanResources\HMI\listicon_16px\1039_a.png
    PROPERTY(0x2000096a)                // 800x480\HMINissanResources\HMI\listicon_16px\1039_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R47_13591, 6)
    PROPERTY(0x2000096b)                // 800x480\HMINissanResources\HMI\listicon_16px\2039_e.png
    PROPERTY(0x2000096b)                // 800x480\HMINissanResources\HMI\listicon_16px\2039_e.png
    PROPERTY(0x2000096c)                // 800x480\HMINissanResources\HMI\listicon_16px\2039_f.png
    PROPERTY(0x2000096d)                // 800x480\HMINissanResources\HMI\listicon_16px\2039_p.png
    PROPERTY(0x2000096e)                // 800x480\HMINissanResources\HMI\listicon_16px\2039_a.png
    PROPERTY(0x2000096f)                // 800x480\HMINissanResources\HMI\listicon_16px\2039_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R51_13592, 6)
    PROPERTY(0x20000970)                // 800x480\HMINissanResources\HMI\listicon_16px\103A_e.png
    PROPERTY(0x20000970)                // 800x480\HMINissanResources\HMI\listicon_16px\103A_e.png
    PROPERTY(0x20000971)                // 800x480\HMINissanResources\HMI\listicon_16px\103A_f.png
    PROPERTY(0x20000972)                // 800x480\HMINissanResources\HMI\listicon_16px\103A_p.png
    PROPERTY(0x20000973)                // 800x480\HMINissanResources\HMI\listicon_16px\103A_a.png
    PROPERTY(0x20000974)                // 800x480\HMINissanResources\HMI\listicon_16px\103A_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R52, 6)
    PROPERTY(0x20000975)                // 800x480\HMINissanResources\HMI\listicon_16px\203A_e.png
    PROPERTY(0x20000975)                // 800x480\HMINissanResources\HMI\listicon_16px\203A_e.png
    PROPERTY(0x20000976)                // 800x480\HMINissanResources\HMI\listicon_16px\203A_f.png
    PROPERTY(0x20000977)                // 800x480\HMINissanResources\HMI\listicon_16px\203A_p.png
    PROPERTY(0x20000978)                // 800x480\HMINissanResources\HMI\listicon_16px\203A_a.png
    PROPERTY(0x20000979)                // 800x480\HMINissanResources\HMI\listicon_16px\203A_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R54, 5)
    PROPERTY(0x20000970)                // 800x480\HMINissanResources\HMI\listicon_16px\103A_e.png
    PROPERTY(0x20000970)                // 800x480\HMINissanResources\HMI\listicon_16px\103A_e.png
    PROPERTY(0x20000971)                // 800x480\HMINissanResources\HMI\listicon_16px\103A_f.png
    PROPERTY(0x20000972)                // 800x480\HMINissanResources\HMI\listicon_16px\103A_p.png
    PROPERTY(0x20000973)                // 800x480\HMINissanResources\HMI\listicon_16px\103A_a.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R56_13593, 6)
    PROPERTY(0x2000097a)                // 800x480\HMINissanResources\HMI\listicon_16px\103B_e.png
    PROPERTY(0x2000097a)                // 800x480\HMINissanResources\HMI\listicon_16px\103B_e.png
    PROPERTY(0x2000097b)                // 800x480\HMINissanResources\HMI\listicon_16px\103B_f.png
    PROPERTY(0x2000097c)                // 800x480\HMINissanResources\HMI\listicon_16px\103B_p.png
    PROPERTY(0x2000097d)                // 800x480\HMINissanResources\HMI\listicon_16px\103B_a.png
    PROPERTY(0x2000097e)                // 800x480\HMINissanResources\HMI\listicon_16px\103B_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R57_13594, 6)
    PROPERTY(0x2000097f)                // 800x480\HMINissanResources\HMI\listicon_16px\203B_e.png
    PROPERTY(0x2000097f)                // 800x480\HMINissanResources\HMI\listicon_16px\203B_e.png
    PROPERTY(0x20000980)                // 800x480\HMINissanResources\HMI\listicon_16px\203B_f.png
    PROPERTY(0x20000981)                // 800x480\HMINissanResources\HMI\listicon_16px\203B_p.png
    PROPERTY(0x20000982)                // 800x480\HMINissanResources\HMI\listicon_16px\203B_a.png
    PROPERTY(0x20000983)                // 800x480\HMINissanResources\HMI\listicon_16px\203B_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R59, 6)
    PROPERTY(0x2000097a)                // 800x480\HMINissanResources\HMI\listicon_16px\103B_e.png
    PROPERTY(0x2000097a)                // 800x480\HMINissanResources\HMI\listicon_16px\103B_e.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000097c)                // 800x480\HMINissanResources\HMI\listicon_16px\103B_p.png
    PROPERTY(0x2000097d)                // 800x480\HMINissanResources\HMI\listicon_16px\103B_a.png
    PROPERTY(0x2000097e)                // 800x480\HMINissanResources\HMI\listicon_16px\103B_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R61_13595, 6)
    PROPERTY(0x20000984)                // 800x480\HMINissanResources\HMI\listicon_16px\103C_e.png
    PROPERTY(0x20000984)                // 800x480\HMINissanResources\HMI\listicon_16px\103C_e.png
    PROPERTY(0x20000985)                // 800x480\HMINissanResources\HMI\listicon_16px\103C_f.png
    PROPERTY(0x20000986)                // 800x480\HMINissanResources\HMI\listicon_16px\103C_p.png
    PROPERTY(0x20000987)                // 800x480\HMINissanResources\HMI\listicon_16px\103C_a.png
    PROPERTY(0x20000988)                // 800x480\HMINissanResources\HMI\listicon_16px\103C_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R62, 6)
    PROPERTY(0x20000989)                // 800x480\HMINissanResources\HMI\listicon_16px\203C_e.png
    PROPERTY(0x20000989)                // 800x480\HMINissanResources\HMI\listicon_16px\203C_e.png
    PROPERTY(0x2000098a)                // 800x480\HMINissanResources\HMI\listicon_16px\203C_f.png
    PROPERTY(0x2000098b)                // 800x480\HMINissanResources\HMI\listicon_16px\203C_p.png
    PROPERTY(0x2000098c)                // 800x480\HMINissanResources\HMI\listicon_16px\203C_a.png
    PROPERTY(0x2000098d)                // 800x480\HMINissanResources\HMI\listicon_16px\203C_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R66_13596, 6)
    PROPERTY(0x2000098e)                // 800x480\HMINissanResources\HMI\listicon_16px\103D_e.png
    PROPERTY(0x2000098e)                // 800x480\HMINissanResources\HMI\listicon_16px\103D_e.png
    PROPERTY(0x2000098f)                // 800x480\HMINissanResources\HMI\listicon_16px\103D_f.png
    PROPERTY(0x20000990)                // 800x480\HMINissanResources\HMI\listicon_16px\103D_p.png
    PROPERTY(0x20000991)                // 800x480\HMINissanResources\HMI\listicon_16px\103D_a.png
    PROPERTY(0x20000992)                // 800x480\HMINissanResources\HMI\listicon_16px\103D_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R67_13597, 6)
    PROPERTY(0x20000993)                // 800x480\HMINissanResources\HMI\listicon_16px\203D_e.png
    PROPERTY(0x20000993)                // 800x480\HMINissanResources\HMI\listicon_16px\203D_e.png
    PROPERTY(0x20000994)                // 800x480\HMINissanResources\HMI\listicon_16px\203D_f.png
    PROPERTY(0x20000995)                // 800x480\HMINissanResources\HMI\listicon_16px\203D_p.png
    PROPERTY(0x20000996)                // 800x480\HMINissanResources\HMI\listicon_16px\203D_a.png
    PROPERTY(0x20000997)                // 800x480\HMINissanResources\HMI\listicon_16px\203D_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R71_13598, 6)
    PROPERTY(0x20000998)                // 800x480\HMINissanResources\HMI\listicon_16px\103E_e.png
    PROPERTY(0x20000998)                // 800x480\HMINissanResources\HMI\listicon_16px\103E_e.png
    PROPERTY(0x20000999)                // 800x480\HMINissanResources\HMI\listicon_16px\103E_f.png
    PROPERTY(0x2000099a)                // 800x480\HMINissanResources\HMI\listicon_16px\103E_p.png
    PROPERTY(0x2000099b)                // 800x480\HMINissanResources\HMI\listicon_16px\103E_a.png
    PROPERTY(0x2000099c)                // 800x480\HMINissanResources\HMI\listicon_16px\103E_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R72, 6)
    PROPERTY(0x2000099d)                // 800x480\HMINissanResources\HMI\listicon_16px\203E_e.png
    PROPERTY(0x2000099d)                // 800x480\HMINissanResources\HMI\listicon_16px\203E_e.png
    PROPERTY(0x2000099e)                // 800x480\HMINissanResources\HMI\listicon_16px\203E_f.png
    PROPERTY(0x2000099f)                // 800x480\HMINissanResources\HMI\listicon_16px\203E_p.png
    PROPERTY(0x200009a0)                // 800x480\HMINissanResources\HMI\listicon_16px\203E_a.png
    PROPERTY(0x200009a1)                // 800x480\HMINissanResources\HMI\listicon_16px\203E_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R73, 6)
    PROPERTY(0x2000099d)                // 800x480\HMINissanResources\HMI\listicon_16px\203E_e.png
    PROPERTY(0x2000099d)                // 800x480\HMINissanResources\HMI\listicon_16px\203E_e.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x2000099f)                // 800x480\HMINissanResources\HMI\listicon_16px\203E_p.png
    PROPERTY(0x200009a0)                // 800x480\HMINissanResources\HMI\listicon_16px\203E_a.png
    PROPERTY(0x200009a1)                // 800x480\HMINissanResources\HMI\listicon_16px\203E_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R76_13599, 6)
    PROPERTY(0x200009a2)                // 800x480\HMINissanResources\HMI\listicon_16px\103F_e.png
    PROPERTY(0x200009a2)                // 800x480\HMINissanResources\HMI\listicon_16px\103F_e.png
    PROPERTY(0x200009a3)                // 800x480\HMINissanResources\HMI\listicon_16px\103F_f.png
    PROPERTY(0x200009a4)                // 800x480\HMINissanResources\HMI\listicon_16px\103F_p.png
    PROPERTY(0x200009a5)                // 800x480\HMINissanResources\HMI\listicon_16px\103F_a.png
    PROPERTY(0x200009a6)                // 800x480\HMINissanResources\HMI\listicon_16px\103F_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R77_13600, 6)
    PROPERTY(0x200009a7)                // 800x480\HMINissanResources\HMI\listicon_16px\203F_e.png
    PROPERTY(0x200009a7)                // 800x480\HMINissanResources\HMI\listicon_16px\203F_e.png
    PROPERTY(0x200009a8)                // 800x480\HMINissanResources\HMI\listicon_16px\203F_f.png
    PROPERTY(0x200009a9)                // 800x480\HMINissanResources\HMI\listicon_16px\203F_p.png
    PROPERTY(0x200009aa)                // 800x480\HMINissanResources\HMI\listicon_16px\203F_a.png
    PROPERTY(0x200009ab)                // 800x480\HMINissanResources\HMI\listicon_16px\203F_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R81_13601, 6)
    PROPERTY(0x200009ac)                // 800x480\HMINissanResources\HMI\listicon_16px\1040_e.png
    PROPERTY(0x200009ac)                // 800x480\HMINissanResources\HMI\listicon_16px\1040_e.png
    PROPERTY(0x200009ad)                // 800x480\HMINissanResources\HMI\listicon_16px\1040_f.png
    PROPERTY(0x200009ae)                // 800x480\HMINissanResources\HMI\listicon_16px\1040_p.png
    PROPERTY(0x200009af)                // 800x480\HMINissanResources\HMI\listicon_16px\1040_a.png
    PROPERTY(0x200009b0)                // 800x480\HMINissanResources\HMI\listicon_16px\1040_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R82, 6)
    PROPERTY(0x200009b1)                // 800x480\HMINissanResources\HMI\listicon_16px\2040_e.png
    PROPERTY(0x200009b1)                // 800x480\HMINissanResources\HMI\listicon_16px\2040_e.png
    PROPERTY(0x200009b2)                // 800x480\HMINissanResources\HMI\listicon_16px\2040_f.png
    PROPERTY(0x200009b3)                // 800x480\HMINissanResources\HMI\listicon_16px\2040_p.png
    PROPERTY(0x200009b4)                // 800x480\HMINissanResources\HMI\listicon_16px\2040_a.png
    PROPERTY(0x200009b5)                // 800x480\HMINissanResources\HMI\listicon_16px\2040_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R86_13602, 6)
    PROPERTY(0x200009b6)                // 800x480\HMINissanResources\HMI\listicon_16px\1041_e.png
    PROPERTY(0x200009b6)                // 800x480\HMINissanResources\HMI\listicon_16px\1041_e.png
    PROPERTY(0x200009b7)                // 800x480\HMINissanResources\HMI\listicon_16px\1041_f.png
    PROPERTY(0x200009b8)                // 800x480\HMINissanResources\HMI\listicon_16px\1041_p.png
    PROPERTY(0x200009b9)                // 800x480\HMINissanResources\HMI\listicon_16px\1041_a.png
    PROPERTY(0x200009ba)                // 800x480\HMINissanResources\HMI\listicon_16px\1041_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R87_13603, 6)
    PROPERTY(0x200009bb)                // 800x480\HMINissanResources\HMI\listicon_16px\2041_e.png
    PROPERTY(0x200009bb)                // 800x480\HMINissanResources\HMI\listicon_16px\2041_e.png
    PROPERTY(0x200009bc)                // 800x480\HMINissanResources\HMI\listicon_16px\2041_f.png
    PROPERTY(0x200009bd)                // 800x480\HMINissanResources\HMI\listicon_16px\2041_p.png
    PROPERTY(0x200009be)                // 800x480\HMINissanResources\HMI\listicon_16px\2041_a.png
    PROPERTY(0x200009bf)                // 800x480\HMINissanResources\HMI\listicon_16px\2041_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R91_13604, 6)
    PROPERTY(0x200009c0)                // 800x480\HMINissanResources\HMI\listicon_16px\1042_e.png
    PROPERTY(0x200009c0)                // 800x480\HMINissanResources\HMI\listicon_16px\1042_e.png
    PROPERTY(0x200009c1)                // 800x480\HMINissanResources\HMI\listicon_16px\1042_f.png
    PROPERTY(0x200009c2)                // 800x480\HMINissanResources\HMI\listicon_16px\1042_p.png
    PROPERTY(0x200009c3)                // 800x480\HMINissanResources\HMI\listicon_16px\1042_a.png
    PROPERTY(0x200009c4)                // 800x480\HMINissanResources\HMI\listicon_16px\1042_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R92, 6)
    PROPERTY(0x200009c5)                // 800x480\HMINissanResources\HMI\listicon_16px\2042_e.png
    PROPERTY(0x200009c5)                // 800x480\HMINissanResources\HMI\listicon_16px\2042_e.png
    PROPERTY(0x200009c6)                // 800x480\HMINissanResources\HMI\listicon_16px\2042_f.png
    PROPERTY(0x200009c7)                // 800x480\HMINissanResources\HMI\listicon_16px\2042_p.png
    PROPERTY(0x200009c8)                // 800x480\HMINissanResources\HMI\listicon_16px\2042_a.png
    PROPERTY(0x200009c9)                // 800x480\HMINissanResources\HMI\listicon_16px\2042_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R96_13605, 6)
    PROPERTY(0x200009ca)                // 800x480\HMINissanResources\HMI\listicon_16px\1043_e.png
    PROPERTY(0x200009ca)                // 800x480\HMINissanResources\HMI\listicon_16px\1043_e.png
    PROPERTY(0x200009cb)                // 800x480\HMINissanResources\HMI\listicon_16px\1043_f.png
    PROPERTY(0x200009cc)                // 800x480\HMINissanResources\HMI\listicon_16px\1043_p.png
    PROPERTY(0x200009cd)                // 800x480\HMINissanResources\HMI\listicon_16px\1043_a.png
    PROPERTY(0x200009ce)                // 800x480\HMINissanResources\HMI\listicon_16px\1043_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R97_13606, 6)
    PROPERTY(0x200009cf)                // 800x480\HMINissanResources\HMI\listicon_16px\2043_e.png
    PROPERTY(0x200009cf)                // 800x480\HMINissanResources\HMI\listicon_16px\2043_e.png
    PROPERTY(0x200009d0)                // 800x480\HMINissanResources\HMI\listicon_16px\2043_f.png
    PROPERTY(0x200009d1)                // 800x480\HMINissanResources\HMI\listicon_16px\2043_p.png
    PROPERTY(0x200009d2)                // 800x480\HMINissanResources\HMI\listicon_16px\2043_a.png
    PROPERTY(0x200009d3)                // 800x480\HMINissanResources\HMI\listicon_16px\2043_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R101_13607, 6)
    PROPERTY(0x200009d4)                // 800x480\HMINissanResources\HMI\listicon_16px\1044_e.png
    PROPERTY(0x200009d4)                // 800x480\HMINissanResources\HMI\listicon_16px\1044_e.png
    PROPERTY(0x200009d5)                // 800x480\HMINissanResources\HMI\listicon_16px\1044_f.png
    PROPERTY(0x200009d6)                // 800x480\HMINissanResources\HMI\listicon_16px\1044_p.png
    PROPERTY(0x200009d7)                // 800x480\HMINissanResources\HMI\listicon_16px\1044_a.png
    PROPERTY(0x200009d8)                // 800x480\HMINissanResources\HMI\listicon_16px\1044_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R102, 6)
    PROPERTY(0x200009d9)                // 800x480\HMINissanResources\HMI\listicon_16px\2044_e.png
    PROPERTY(0x200009d9)                // 800x480\HMINissanResources\HMI\listicon_16px\2044_e.png
    PROPERTY(0x200009da)                // 800x480\HMINissanResources\HMI\listicon_16px\2044_f.png
    PROPERTY(0x200009db)                // 800x480\HMINissanResources\HMI\listicon_16px\2044_p.png
    PROPERTY(0x200009dc)                // 800x480\HMINissanResources\HMI\listicon_16px\2044_a.png
    PROPERTY(0x200009dd)                // 800x480\HMINissanResources\HMI\listicon_16px\2044_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R106_13608, 6)
    PROPERTY(0x200009de)                // 800x480\HMINissanResources\HMI\listicon_16px\1045_e.png
    PROPERTY(0x200009de)                // 800x480\HMINissanResources\HMI\listicon_16px\1045_e.png
    PROPERTY(0x200009df)                // 800x480\HMINissanResources\HMI\listicon_16px\1045_f.png
    PROPERTY(0x200009e0)                // 800x480\HMINissanResources\HMI\listicon_16px\1045_p.png
    PROPERTY(0x200009e1)                // 800x480\HMINissanResources\HMI\listicon_16px\1045_a.png
    PROPERTY(0x200009e2)                // 800x480\HMINissanResources\HMI\listicon_16px\1045_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R107_13609, 6)
    PROPERTY(0x200009e3)                // 800x480\HMINissanResources\HMI\listicon_16px\2045_e.png
    PROPERTY(0x200009e3)                // 800x480\HMINissanResources\HMI\listicon_16px\2045_e.png
    PROPERTY(0x200009e4)                // 800x480\HMINissanResources\HMI\listicon_16px\2045_f.png
    PROPERTY(0x200009e5)                // 800x480\HMINissanResources\HMI\listicon_16px\2045_p.png
    PROPERTY(0x200009e6)                // 800x480\HMINissanResources\HMI\listicon_16px\2045_a.png
    PROPERTY(0x200009e7)                // 800x480\HMINissanResources\HMI\listicon_16px\2045_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R111_13610, 6)
    PROPERTY(0x200009e8)                // 800x480\HMINissanResources\HMI\listicon_16px\1046_e.png
    PROPERTY(0x200009e8)                // 800x480\HMINissanResources\HMI\listicon_16px\1046_e.png
    PROPERTY(0x200009e9)                // 800x480\HMINissanResources\HMI\listicon_16px\1046_f.png
    PROPERTY(0x200009ea)                // 800x480\HMINissanResources\HMI\listicon_16px\1046_p.png
    PROPERTY(0x200009eb)                // 800x480\HMINissanResources\HMI\listicon_16px\1046_a.png
    PROPERTY(0x200009ec)                // 800x480\HMINissanResources\HMI\listicon_16px\1046_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R112, 7)
    PROPERTY(0x200009ed)                // 800x480\HMINissanResources\HMI\listicon_16px\2046_e.png
    PROPERTY(0x200009ed)                // 800x480\HMINissanResources\HMI\listicon_16px\2046_e.png
    PROPERTY(0x200009ee)                // 800x480\HMINissanResources\HMI\listicon_16px\2046_f.png
    PROPERTY(0x200009ef)                // 800x480\HMINissanResources\HMI\listicon_16px\2046_p.png
    PROPERTY(0x200009f0)                // 800x480\HMINissanResources\HMI\listicon_16px\2046_a.png
    PROPERTY(0x200009f1)                // 800x480\HMINissanResources\HMI\listicon_16px\2046_a_f.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R113, 6)
    PROPERTY(0x200009ed)                // 800x480\HMINissanResources\HMI\listicon_16px\2046_e.png
    PROPERTY(0x200009ed)                // 800x480\HMINissanResources\HMI\listicon_16px\2046_e.png
    PROPERTY(0x200009ee)                // 800x480\HMINissanResources\HMI\listicon_16px\2046_f.png
    PROPERTY(0x200009ef)                // 800x480\HMINissanResources\HMI\listicon_16px\2046_p.png
    PROPERTY(0x200009f0)                // 800x480\HMINissanResources\HMI\listicon_16px\2046_a.png
    PROPERTY(0x200009f1)                // 800x480\HMINissanResources\HMI\listicon_16px\2046_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R116_13611, 6)
    PROPERTY(0x200009f2)                // 800x480\HMINissanResources\HMI\listicon_16px\1047_e.png
    PROPERTY(0x200009f2)                // 800x480\HMINissanResources\HMI\listicon_16px\1047_e.png
    PROPERTY(0x200009f3)                // 800x480\HMINissanResources\HMI\listicon_16px\1047_f.png
    PROPERTY(0x200009f4)                // 800x480\HMINissanResources\HMI\listicon_16px\1047_p.png
    PROPERTY(0x200009f5)                // 800x480\HMINissanResources\HMI\listicon_16px\1047_a.png
    PROPERTY(0x200009f6)                // 800x480\HMINissanResources\HMI\listicon_16px\1047_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R117_13612, 6)
    PROPERTY(0x200009f7)                // 800x480\HMINissanResources\HMI\listicon_16px\2047_e.png
    PROPERTY(0x200009f7)                // 800x480\HMINissanResources\HMI\listicon_16px\2047_e.png
    PROPERTY(0x200009f8)                // 800x480\HMINissanResources\HMI\listicon_16px\2047_f.png
    PROPERTY(0x200009f9)                // 800x480\HMINissanResources\HMI\listicon_16px\2047_p.png
    PROPERTY(0x200009fa)                // 800x480\HMINissanResources\HMI\listicon_16px\2047_a.png
    PROPERTY(0x200009fb)                // 800x480\HMINissanResources\HMI\listicon_16px\2047_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R121_13613, 6)
    PROPERTY(0x200009fc)                // 800x480\HMINissanResources\HMI\listicon_16px\1048_e.png
    PROPERTY(0x200009fc)                // 800x480\HMINissanResources\HMI\listicon_16px\1048_e.png
    PROPERTY(0x200009fd)                // 800x480\HMINissanResources\HMI\listicon_16px\1048_f.png
    PROPERTY(0x200009fe)                // 800x480\HMINissanResources\HMI\listicon_16px\1048_p.png
    PROPERTY(0x200009ff)                // 800x480\HMINissanResources\HMI\listicon_16px\1048_a.png
    PROPERTY(0x20000a00)                // 800x480\HMINissanResources\HMI\listicon_16px\1048_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R122, 6)
    PROPERTY(0x20000a01)                // 800x480\HMINissanResources\HMI\listicon_16px\2048_e.png
    PROPERTY(0x20000a01)                // 800x480\HMINissanResources\HMI\listicon_16px\2048_e.png
    PROPERTY(0x20000a02)                // 800x480\HMINissanResources\HMI\listicon_16px\2048_f.png
    PROPERTY(0x20000a03)                // 800x480\HMINissanResources\HMI\listicon_16px\2048_p.png
    PROPERTY(0x20000a04)                // 800x480\HMINissanResources\HMI\listicon_16px\2048_a.png
    PROPERTY(0x20000a05)                // 800x480\HMINissanResources\HMI\listicon_16px\2048_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R126_13614, 6)
    PROPERTY(0x20000a06)                // 800x480\HMINissanResources\HMI\listicon_16px\1049_e.png
    PROPERTY(0x20000a06)                // 800x480\HMINissanResources\HMI\listicon_16px\1049_e.png
    PROPERTY(0x20000a07)                // 800x480\HMINissanResources\HMI\listicon_16px\1049_f.png
    PROPERTY(0x20000a08)                // 800x480\HMINissanResources\HMI\listicon_16px\1049_p.png
    PROPERTY(0x20000a09)                // 800x480\HMINissanResources\HMI\listicon_16px\1049_a.png
    PROPERTY(0x20000a0a)                // 800x480\HMINissanResources\HMI\listicon_16px\1049_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R127_13615, 6)
    PROPERTY(0x20000a0b)                // 800x480\HMINissanResources\HMI\listicon_16px\2049_e.png
    PROPERTY(0x20000a0b)                // 800x480\HMINissanResources\HMI\listicon_16px\2049_e.png
    PROPERTY(0x20000a0c)                // 800x480\HMINissanResources\HMI\listicon_16px\2049_f.png
    PROPERTY(0x20000a0d)                // 800x480\HMINissanResources\HMI\listicon_16px\2049_p.png
    PROPERTY(0x20000a0e)                // 800x480\HMINissanResources\HMI\listicon_16px\2049_a.png
    PROPERTY(0x20000a0f)                // 800x480\HMINissanResources\HMI\listicon_16px\2049_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R131_13616, 6)
    PROPERTY(0x20000a10)                // 800x480\HMINissanResources\HMI\listicon_16px\104A_e.png
    PROPERTY(0x20000a10)                // 800x480\HMINissanResources\HMI\listicon_16px\104A_e.png
    PROPERTY(0x20000a11)                // 800x480\HMINissanResources\HMI\listicon_16px\104A_f.png
    PROPERTY(0x20000a12)                // 800x480\HMINissanResources\HMI\listicon_16px\104A_p.png
    PROPERTY(0x20000a13)                // 800x480\HMINissanResources\HMI\listicon_16px\104A_a.png
    PROPERTY(0x20000a14)                // 800x480\HMINissanResources\HMI\listicon_16px\104A_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R132, 6)
    PROPERTY(0x20000a15)                // 800x480\HMINissanResources\HMI\listicon_16px\204A_e.png
    PROPERTY(0x20000a15)                // 800x480\HMINissanResources\HMI\listicon_16px\204A_e.png
    PROPERTY(0x20000a16)                // 800x480\HMINissanResources\HMI\listicon_16px\204A_f.png
    PROPERTY(0x20000a17)                // 800x480\HMINissanResources\HMI\listicon_16px\204A_p.png
    PROPERTY(0x20000a18)                // 800x480\HMINissanResources\HMI\listicon_16px\204A_a.png
    PROPERTY(0x20000a19)                // 800x480\HMINissanResources\HMI\listicon_16px\204A_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R136_13617, 6)
    PROPERTY(0x20000a1a)                // 800x480\HMINissanResources\HMI\listicon_16px\104B_e.png
    PROPERTY(0x20000a1a)                // 800x480\HMINissanResources\HMI\listicon_16px\104B_e.png
    PROPERTY(0x20000a1b)                // 800x480\HMINissanResources\HMI\listicon_16px\104B_f.png
    PROPERTY(0x20000a1c)                // 800x480\HMINissanResources\HMI\listicon_16px\104B_p.png
    PROPERTY(0x20000a1d)                // 800x480\HMINissanResources\HMI\listicon_16px\104B_a.png
    PROPERTY(0x20000a1e)                // 800x480\HMINissanResources\HMI\listicon_16px\104B_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R137_13618, 6)
    PROPERTY(0x20000a1f)                // 800x480\HMINissanResources\HMI\listicon_16px\204B_e.png
    PROPERTY(0x20000a1f)                // 800x480\HMINissanResources\HMI\listicon_16px\204B_e.png
    PROPERTY(0x20000a20)                // 800x480\HMINissanResources\HMI\listicon_16px\204B_f.png
    PROPERTY(0x20000a21)                // 800x480\HMINissanResources\HMI\listicon_16px\204B_p.png
    PROPERTY(0x20000a22)                // 800x480\HMINissanResources\HMI\listicon_16px\204B_a.png
    PROPERTY(0x20000a23)                // 800x480\HMINissanResources\HMI\listicon_16px\204B_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R141_13619, 6)
    PROPERTY(0x20000a24)                // 800x480\HMINissanResources\HMI\listicon_16px\104C_e.png
    PROPERTY(0x20000a24)                // 800x480\HMINissanResources\HMI\listicon_16px\104C_e.png
    PROPERTY(0x20000a25)                // 800x480\HMINissanResources\HMI\listicon_16px\104C_f.png
    PROPERTY(0x20000a26)                // 800x480\HMINissanResources\HMI\listicon_16px\104C_p.png
    PROPERTY(0x20000a27)                // 800x480\HMINissanResources\HMI\listicon_16px\104C_a.png
    PROPERTY(0x20000a28)                // 800x480\HMINissanResources\HMI\listicon_16px\104C_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R142, 6)
    PROPERTY(0x20000a29)                // 800x480\HMINissanResources\HMI\listicon_16px\204C_e.png
    PROPERTY(0x20000a29)                // 800x480\HMINissanResources\HMI\listicon_16px\204C_e.png
    PROPERTY(0x20000a2a)                // 800x480\HMINissanResources\HMI\listicon_16px\204C_f.png
    PROPERTY(0x20000a2b)                // 800x480\HMINissanResources\HMI\listicon_16px\204C_p.png
    PROPERTY(0x20000a2c)                // 800x480\HMINissanResources\HMI\listicon_16px\204C_a.png
    PROPERTY(0x20000a2d)                // 800x480\HMINissanResources\HMI\listicon_16px\204C_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R146_13620, 6)
    PROPERTY(0x20000a2e)                // 800x480\HMINissanResources\HMI\listicon_16px\104D_e.png
    PROPERTY(0x20000a2e)                // 800x480\HMINissanResources\HMI\listicon_16px\104D_e.png
    PROPERTY(0x20000a2f)                // 800x480\HMINissanResources\HMI\listicon_16px\104D_f.png
    PROPERTY(0x20000a30)                // 800x480\HMINissanResources\HMI\listicon_16px\104D_p.png
    PROPERTY(0x20000a31)                // 800x480\HMINissanResources\HMI\listicon_16px\104D_a.png
    PROPERTY(0x20000a32)                // 800x480\HMINissanResources\HMI\listicon_16px\104D_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(ImagePaths_R147_13621, 6)
    PROPERTY(0x20000a33)                // 800x480\HMINissanResources\HMI\listicon_16px\204D_e.png
    PROPERTY(0x20000a33)                // 800x480\HMINissanResources\HMI\listicon_16px\204D_e.png
    PROPERTY(0x20000a34)                // 800x480\HMINissanResources\HMI\listicon_16px\204D_f.png
    PROPERTY(0x20000a35)                // 800x480\HMINissanResources\HMI\listicon_16px\204D_p.png
    PROPERTY(0x20000a36)                // 800x480\HMINissanResources\HMI\listicon_16px\204D_a.png
    PROPERTY(0x20000a37)                // 800x480\HMINissanResources\HMI\listicon_16px\204D_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_TDARRAY(ImagePaths_13622, 151)
    PROPERTY_ARRAY_ROW(ImagePaths_R0)
    PROPERTY_ARRAY_ROW(ImagePaths_R1_13576)
    PROPERTY_ARRAY_ROW(ImagePaths_R2)
    PROPERTY_ARRAY_ROW(ImagePaths_R2)
    PROPERTY_ARRAY_ROW(ImagePaths_R1_13576)
    PROPERTY_ARRAY_ROW(ImagePaths_R2)
    PROPERTY_ARRAY_ROW(ImagePaths_R6_13577)
    PROPERTY_ARRAY_ROW(ImagePaths_R7_13578)
    PROPERTY_ARRAY_ROW(ImagePaths_R7_13578)
    PROPERTY_ARRAY_ROW(ImagePaths_R6_13577)
    PROPERTY_ARRAY_ROW(ImagePaths_R7_13578)
    PROPERTY_ARRAY_ROW(ImagePaths_R11_13579)
    PROPERTY_ARRAY_ROW(ImagePaths_R12_13580)
    PROPERTY_ARRAY_ROW(ImagePaths_R12_13580)
    PROPERTY_ARRAY_ROW(ImagePaths_R11_13579)
    PROPERTY_ARRAY_ROW(ImagePaths_R12_13580)
    PROPERTY_ARRAY_ROW(ImagePaths_R16_13581)
    PROPERTY_ARRAY_ROW(ImagePaths_R17_13582)
    PROPERTY_ARRAY_ROW(ImagePaths_R17_13582)
    PROPERTY_ARRAY_ROW(ImagePaths_R16_13581)
    PROPERTY_ARRAY_ROW(ImagePaths_R17_13582)
    PROPERTY_ARRAY_ROW(ImagePaths_R21_13583)
    PROPERTY_ARRAY_ROW(ImagePaths_R22)
    PROPERTY_ARRAY_ROW(ImagePaths_R22)
    PROPERTY_ARRAY_ROW(ImagePaths_R21_13583)
    PROPERTY_ARRAY_ROW(ImagePaths_R22)
    PROPERTY_ARRAY_ROW(ImagePaths_R26_13584)
    PROPERTY_ARRAY_ROW(ImagePaths_R27_13585)
    PROPERTY_ARRAY_ROW(ImagePaths_R27_13585)
    PROPERTY_ARRAY_ROW(ImagePaths_R26_13584)
    PROPERTY_ARRAY_ROW(ImagePaths_R27_13585)
    PROPERTY_ARRAY_ROW(ImagePaths_R31_13586)
    PROPERTY_ARRAY_ROW(ImagePaths_R32)
    PROPERTY_ARRAY_ROW(ImagePaths_R32)
    PROPERTY_ARRAY_ROW(ImagePaths_R31_13586)
    PROPERTY_ARRAY_ROW(ImagePaths_R32)
    PROPERTY_ARRAY_ROW(ImagePaths_R36_13587)
    PROPERTY_ARRAY_ROW(ImagePaths_R37_13588)
    PROPERTY_ARRAY_ROW(ImagePaths_R37_13588)
    PROPERTY_ARRAY_ROW(ImagePaths_R36_13587)
    PROPERTY_ARRAY_ROW(ImagePaths_R37_13588)
    PROPERTY_ARRAY_ROW(ImagePaths_R41_13589)
    PROPERTY_ARRAY_ROW(ImagePaths_R42)
    PROPERTY_ARRAY_ROW(ImagePaths_R42)
    PROPERTY_ARRAY_ROW(ImagePaths_R41_13589)
    PROPERTY_ARRAY_ROW(ImagePaths_R42)
    PROPERTY_ARRAY_ROW(ImagePaths_R46_13590)
    PROPERTY_ARRAY_ROW(ImagePaths_R47_13591)
    PROPERTY_ARRAY_ROW(ImagePaths_R47_13591)
    PROPERTY_ARRAY_ROW(ImagePaths_R46_13590)
    PROPERTY_ARRAY_ROW(ImagePaths_R47_13591)
    PROPERTY_ARRAY_ROW(ImagePaths_R51_13592)
    PROPERTY_ARRAY_ROW(ImagePaths_R52)
    PROPERTY_ARRAY_ROW(ImagePaths_R52)
    PROPERTY_ARRAY_ROW(ImagePaths_R54)
    PROPERTY_ARRAY_ROW(ImagePaths_R52)
    PROPERTY_ARRAY_ROW(ImagePaths_R56_13593)
    PROPERTY_ARRAY_ROW(ImagePaths_R57_13594)
    PROPERTY_ARRAY_ROW(ImagePaths_R57_13594)
    PROPERTY_ARRAY_ROW(ImagePaths_R59)
    PROPERTY_ARRAY_ROW(ImagePaths_R57_13594)
    PROPERTY_ARRAY_ROW(ImagePaths_R61_13595)
    PROPERTY_ARRAY_ROW(ImagePaths_R62)
    PROPERTY_ARRAY_ROW(ImagePaths_R62)
    PROPERTY_ARRAY_ROW(ImagePaths_R61_13595)
    PROPERTY_ARRAY_ROW(ImagePaths_R62)
    PROPERTY_ARRAY_ROW(ImagePaths_R66_13596)
    PROPERTY_ARRAY_ROW(ImagePaths_R67_13597)
    PROPERTY_ARRAY_ROW(ImagePaths_R67_13597)
    PROPERTY_ARRAY_ROW(ImagePaths_R66_13596)
    PROPERTY_ARRAY_ROW(ImagePaths_R67_13597)
    PROPERTY_ARRAY_ROW(ImagePaths_R71_13598)
    PROPERTY_ARRAY_ROW(ImagePaths_R72)
    PROPERTY_ARRAY_ROW(ImagePaths_R73)
    PROPERTY_ARRAY_ROW(ImagePaths_R71_13598)
    PROPERTY_ARRAY_ROW(ImagePaths_R73)
    PROPERTY_ARRAY_ROW(ImagePaths_R76_13599)
    PROPERTY_ARRAY_ROW(ImagePaths_R77_13600)
    PROPERTY_ARRAY_ROW(ImagePaths_R77_13600)
    PROPERTY_ARRAY_ROW(ImagePaths_R76_13599)
    PROPERTY_ARRAY_ROW(ImagePaths_R77_13600)
    PROPERTY_ARRAY_ROW(ImagePaths_R81_13601)
    PROPERTY_ARRAY_ROW(ImagePaths_R82)
    PROPERTY_ARRAY_ROW(ImagePaths_R82)
    PROPERTY_ARRAY_ROW(ImagePaths_R81_13601)
    PROPERTY_ARRAY_ROW(ImagePaths_R82)
    PROPERTY_ARRAY_ROW(ImagePaths_R86_13602)
    PROPERTY_ARRAY_ROW(ImagePaths_R87_13603)
    PROPERTY_ARRAY_ROW(ImagePaths_R87_13603)
    PROPERTY_ARRAY_ROW(ImagePaths_R86_13602)
    PROPERTY_ARRAY_ROW(ImagePaths_R87_13603)
    PROPERTY_ARRAY_ROW(ImagePaths_R91_13604)
    PROPERTY_ARRAY_ROW(ImagePaths_R92)
    PROPERTY_ARRAY_ROW(ImagePaths_R92)
    PROPERTY_ARRAY_ROW(ImagePaths_R91_13604)
    PROPERTY_ARRAY_ROW(ImagePaths_R92)
    PROPERTY_ARRAY_ROW(ImagePaths_R96_13605)
    PROPERTY_ARRAY_ROW(ImagePaths_R97_13606)
    PROPERTY_ARRAY_ROW(ImagePaths_R97_13606)
    PROPERTY_ARRAY_ROW(ImagePaths_R96_13605)
    PROPERTY_ARRAY_ROW(ImagePaths_R97_13606)
    PROPERTY_ARRAY_ROW(ImagePaths_R101_13607)
    PROPERTY_ARRAY_ROW(ImagePaths_R102)
    PROPERTY_ARRAY_ROW(ImagePaths_R102)
    PROPERTY_ARRAY_ROW(ImagePaths_R101_13607)
    PROPERTY_ARRAY_ROW(ImagePaths_R102)
    PROPERTY_ARRAY_ROW(ImagePaths_R106_13608)
    PROPERTY_ARRAY_ROW(ImagePaths_R107_13609)
    PROPERTY_ARRAY_ROW(ImagePaths_R107_13609)
    PROPERTY_ARRAY_ROW(ImagePaths_R106_13608)
    PROPERTY_ARRAY_ROW(ImagePaths_R107_13609)
    PROPERTY_ARRAY_ROW(ImagePaths_R111_13610)
    PROPERTY_ARRAY_ROW(ImagePaths_R112)
    PROPERTY_ARRAY_ROW(ImagePaths_R113)
    PROPERTY_ARRAY_ROW(ImagePaths_R111_13610)
    PROPERTY_ARRAY_ROW(ImagePaths_R113)
    PROPERTY_ARRAY_ROW(ImagePaths_R116_13611)
    PROPERTY_ARRAY_ROW(ImagePaths_R117_13612)
    PROPERTY_ARRAY_ROW(ImagePaths_R117_13612)
    PROPERTY_ARRAY_ROW(ImagePaths_R116_13611)
    PROPERTY_ARRAY_ROW(ImagePaths_R117_13612)
    PROPERTY_ARRAY_ROW(ImagePaths_R121_13613)
    PROPERTY_ARRAY_ROW(ImagePaths_R122)
    PROPERTY_ARRAY_ROW(ImagePaths_R122)
    PROPERTY_ARRAY_ROW(ImagePaths_R121_13613)
    PROPERTY_ARRAY_ROW(ImagePaths_R122)
    PROPERTY_ARRAY_ROW(ImagePaths_R126_13614)
    PROPERTY_ARRAY_ROW(ImagePaths_R127_13615)
    PROPERTY_ARRAY_ROW(ImagePaths_R127_13615)
    PROPERTY_ARRAY_ROW(ImagePaths_R126_13614)
    PROPERTY_ARRAY_ROW(ImagePaths_R127_13615)
    PROPERTY_ARRAY_ROW(ImagePaths_R131_13616)
    PROPERTY_ARRAY_ROW(ImagePaths_R132)
    PROPERTY_ARRAY_ROW(ImagePaths_R132)
    PROPERTY_ARRAY_ROW(ImagePaths_R131_13616)
    PROPERTY_ARRAY_ROW(ImagePaths_R132)
    PROPERTY_ARRAY_ROW(ImagePaths_R136_13617)
    PROPERTY_ARRAY_ROW(ImagePaths_R137_13618)
    PROPERTY_ARRAY_ROW(ImagePaths_R137_13618)
    PROPERTY_ARRAY_ROW(ImagePaths_R136_13617)
    PROPERTY_ARRAY_ROW(ImagePaths_R137_13618)
    PROPERTY_ARRAY_ROW(ImagePaths_R141_13619)
    PROPERTY_ARRAY_ROW(ImagePaths_R142)
    PROPERTY_ARRAY_ROW(ImagePaths_R142)
    PROPERTY_ARRAY_ROW(ImagePaths_R141_13619)
    PROPERTY_ARRAY_ROW(ImagePaths_R142)
    PROPERTY_ARRAY_ROW(ImagePaths_R146_13620)
    PROPERTY_ARRAY_ROW(ImagePaths_R147_13621)
    PROPERTY_ARRAY_ROW(ImagePaths_R147_13621)
    PROPERTY_ARRAY_ROW(ImagePaths_R146_13620)
    PROPERTY_ARRAY_ROW(ImagePaths_R147_13621)
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SXM_TRAFFIC__StrliSiriusXMAdvisoryMSG, 5)
    PROPERTY(0x8000033c)                // Check Antenna -> Sxm_Fuel__StrliFuelAdvisoryMessage-000
    PROPERTY(0x80000909)                // Traffic data loading -> SXM_TRAFFIC__StrliSiriusXMAdvisoryMSG-001
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x8000086e)                // SiriusXM Traffic is not active. Please refer to SXM channel 1 to call for subscription details. -> TRA__strliSXMTrafficAdvisoryText-003
    PROPERTY(0x8000086f)                // Service temporarily not available -> TRA__strliSXMTravelLinkAdvisoryMessages-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS__strliGetServicecallStatus, 67)
    PROPERTY(0x80000782)                // Connecting to voice menu. Call will be muted for up to 1 minute. -> SYS__strliGetServicecallStatus-000
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x80000782)                // Connecting to voice menu. Call will be muted for up to 1 minute. -> SYS__strliGetServicecallStatus-000
    PROPERTY(0x80000783)                // Confirming account. Call will be muted for up to 1 minute. -> SYS__strliGetServicecallStatus-017
    PROPERTY(0x80000784)                // Connecting to voice menu. Center could not be established. -> SYS__strliGetServicecallStatus-018
    PROPERTY(0x80000785)                // Disconnecting... -> SYS__strliGetServicecallStatus-019
    PROPERTY(0x80000786)                // Connection to voice menu Center lost. -> SYS__strliGetServicecallStatus-020
    PROPERTY(0x80000782)                // Connecting to voice menu. Call will be muted for up to 1 minute. -> SYS__strliGetServicecallStatus-000
    PROPERTY(0x80000787)                // Connection to VoiceMenu Centre Lost. -> SYS__strliGetServicecallStatus-022
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x80000788)                // Voice menu Service not available. -> SYS__strliGetServicecallStatus-024
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x80000783)                // Confirming account. Call will be muted for up to 1 minute. -> SYS__strliGetServicecallStatus-017
    PROPERTY(0x80000782)                // Connecting to voice menu. Call will be muted for up to 1 minute. -> SYS__strliGetServicecallStatus-000
    PROPERTY(0x80000789)                // Sending location. Call will be muted for up to 1 minute. -> SYS__strliGetServicecallStatus-050
    PROPERTY(0x80000782)                // Connecting to voice menu. Call will be muted for up to 1 minute. -> SYS__strliGetServicecallStatus-000
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x8000078a)                // Sending vehicle diagnostic data... -> SYS__strliGetServicecallStatus-063
    PROPERTY(0x8000078a)                // Sending vehicle diagnostic data... -> SYS__strliGetServicecallStatus-063
    PROPERTY(0x8000078b)                // Vehicle diagnostic data sent... -> SYS__strliGetServicecallStatus-065
    PROPERTY(0x8000078c)                // Vehicle Diagnosis Uploading Complete -> SYS__strliGetServicecallStatus-066
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS__strliGetEcallAcnStatus, 67)
    PROPERTY(0x800008d7)                // Connecting to Emergency Assistance. Call may be muted for up to 1 minute. To disconnect push and hold the SOS button for 2 seconds. -> SYS__strliGetEcallAcnStatus-000
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800008d8)                // Connecting to Emergency Assistance. Call will be muted for up to 1 minute. To disconnect push and hold the SOS button for 2 seconds. -> SYS__strliGetEcallAcnStatus-016
    PROPERTY(0x800008d8)                // Connecting to Emergency Assistance. Call will be muted for up to 1 minute. To disconnect push and hold the SOS button for 2 seconds. -> SYS__strliGetEcallAcnStatus-016
    PROPERTY(0x800008d9)                // Connection to Emergency Assistance Center could not be established. -> SYS__strliGetEcallAcnStatus-018
    PROPERTY(0x800008da)                // Disconnecting... -> SYS__strliGetEcallAcnStatus-019
    PROPERTY(0x800008db)                // Connection to Emergency Assistance Center lost. -> SYS__strliGetEcallAcnStatus-020
    PROPERTY(0x800008d8)                // Connecting to Emergency Assistance. Call will be muted for up to 1 minute. To disconnect push and hold the SOS button for 2 seconds. -> SYS__strliGetEcallAcnStatus-016
    PROPERTY(0x800008db)                // Connection to Emergency Assistance Center lost. -> SYS__strliGetEcallAcnStatus-020
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800008dc)                // Emergency Assistance Service not available. -> SYS__strliGetEcallAcnStatus-024
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x80000783)                // Confirming account. Call will be muted for up to 1 minute. -> SYS__strliGetServicecallStatus-017
    PROPERTY(0x800008d8)                // Connecting to Emergency Assistance. Call will be muted for up to 1 minute. To disconnect push and hold the SOS button for 2 seconds. -> SYS__strliGetEcallAcnStatus-016
    PROPERTY(0x80000789)                // Sending location. Call will be muted for up to 1 minute. -> SYS__strliGetServicecallStatus-050
    PROPERTY(0x800008d8)                // Connecting to Emergency Assistance. Call will be muted for up to 1 minute. To disconnect push and hold the SOS button for 2 seconds. -> SYS__strliGetEcallAcnStatus-016
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x8000078a)                // Sending vehicle diagnostic data... -> SYS__strliGetServicecallStatus-063
    PROPERTY(0x8000078a)                // Sending vehicle diagnostic data... -> SYS__strliGetServicecallStatus-063
    PROPERTY(0x800008dd)                // Vehicle diagnostic data sent... -> SYS__strliGetEcallAcnStatus-066
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS__strliGetOnlylAcnStatus, 67)
    PROPERTY(0x800008d7)                // Connecting to Emergency Assistance. Call may be muted for up to 1 minute. To disconnect push and hold the SOS button for 2 seconds. -> SYS__strliGetEcallAcnStatus-000
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800008de)                // Connecting to Emergency Assistance. Call will be muted for up to 1 minute. -> SYS__strliGetOnlylAcnStatus-016
    PROPERTY(0x800008de)                // Connecting to Emergency Assistance. Call will be muted for up to 1 minute. -> SYS__strliGetOnlylAcnStatus-016
    PROPERTY(0x800008df)                // Connection to Emergency Assistance Center could not be established. -> SYS__strliGetOnlylAcnStatus-018
    PROPERTY(0x800008da)                // Disconnecting... -> SYS__strliGetEcallAcnStatus-019
    PROPERTY(0x800008e0)                // Connection to Emergency Assistance Center lost. -> SYS__strliGetOnlylAcnStatus-020
    PROPERTY(0x800008de)                // Connecting to Emergency Assistance. Call will be muted for up to 1 minute. -> SYS__strliGetOnlylAcnStatus-016
    PROPERTY(0x800008e0)                // Connection to Emergency Assistance Center lost. -> SYS__strliGetOnlylAcnStatus-020
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800008e1)                // Emergency Assistance Service not available. -> SYS__strliGetOnlylAcnStatus-024
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x80000783)                // Confirming account. Call will be muted for up to 1 minute. -> SYS__strliGetServicecallStatus-017
    PROPERTY(0x800008de)                // Connecting to Emergency Assistance. Call will be muted for up to 1 minute. -> SYS__strliGetOnlylAcnStatus-016
    PROPERTY(0x80000789)                // Sending location. Call will be muted for up to 1 minute. -> SYS__strliGetServicecallStatus-050
    PROPERTY(0x800008de)                // Connecting to Emergency Assistance. Call will be muted for up to 1 minute. -> SYS__strliGetOnlylAcnStatus-016
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x8000078a)                // Sending vehicle diagnostic data... -> SYS__strliGetServicecallStatus-063
    PROPERTY(0x8000078a)                // Sending vehicle diagnostic data... -> SYS__strliGetServicecallStatus-063
    PROPERTY(0x800008dd)                // Vehicle diagnostic data sent... -> SYS__strliGetEcallAcnStatus-066
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14309, 5)
    PROPERTY(0x20000a3a)                // 800x480\HMINissanResources\HMI\background\popup_background_large_h5.png
    PROPERTY(0x20000a3b)                // 800x480\HMINissanResources\HMI\background\popup_background_large_h4.png
    PROPERTY(0x20000a3c)                // 800x480\HMINissanResources\HMI\background\popup_background_large_h1.png
    PROPERTY(0x20000a3d)                // 800x480\HMINissanResources\HMI\background\popup_background_large_h2.png
    PROPERTY(0x20000a3e)                // 800x480\HMINissanResources\HMI\background\popup_background_large_h3.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_14312, 9)
    PROPERTY(0x20000a3f)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_h2_e.png
    PROPERTY(0x20000a40)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_h2_e_f.png
    PROPERTY(0x20000a41)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_h2_d.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000a3f)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_h2_e.png
    PROPERTY(0x20000a40)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_h2_e_f.png
    PROPERTY(0x20000a42)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_h2_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_14314, 3)
    PROPERTY(0xe003101c)                // Display1: 49, Display2: 28
    PROPERTY(0xe0023014)                // Display1: 35, Display2: 20
    PROPERTY(0xe004d02c)                // Display1: 77, Display2: 44
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14336, 8)
    PROPERTY(0x20000a50)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_alloff.png
    PROPERTY(0x20000a51)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_vent.png
    PROPERTY(0x20000a52)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_b-l.png
    PROPERTY(0x20000a53)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_foot.png
    PROPERTY(0x20000a54)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_d-f.png
    PROPERTY(0x20000902)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_def.png
    PROPERTY(0x20000a55)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_b-l-def.png
    PROPERTY(0x20000a56)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_vent-def.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_14338, 1)
    PROPERTY(0xe001700d)                // Display1: 23, Display2: 13
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14342, 8)
    PROPERTY(0x20000a57)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_0_small.png
    PROPERTY(0x20000a58)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_1_small.png
    PROPERTY(0x20000a59)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_2_small.png
    PROPERTY(0x20000a5a)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_3_small.png
    PROPERTY(0x20000a5b)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_4_small.png
    PROPERTY(0x20000a5c)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_5_small.png
    PROPERTY(0x20000a5d)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_6_small.png
    PROPERTY(0x20000a5e)                // 800x480\HMINissanResources\HMI\HVAC\HVAC_vent_7_small.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14348, 4)
    PROPERTY(0x20000a50)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_alloff.png
    PROPERTY(0x20000a51)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_vent.png
    PROPERTY(0x20000a52)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_b-l.png
    PROPERTY(0x20000a55)                // 800x480\HMINissanResources\HMI\HVAC\icon_airflow_small_b-l-def.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14352, 6)
    PROPERTY(0x2000063d)                // 800x480\HMINissanResources\HMI\color_test\02_color_test_white.png
    PROPERTY(0x2000063c)                // 800x480\HMINissanResources\HMI\color_test\01_color_test_black.png
    PROPERTY(0x2000063e)                // 800x480\HMINissanResources\HMI\color_test\03_color_test_red.png
    PROPERTY(0x2000063f)                // 800x480\HMINissanResources\HMI\color_test\04_color_test_green.png
    PROPERTY(0x20000640)                // 800x480\HMINissanResources\HMI\color_test\05_color_test_blue.png
    PROPERTY(0x20000a5f)                // 800x480\HMINissanResources\HMI\color_test\color_bar.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14538, 13)
    PROPERTY(0x20000a65)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_12.png
    PROPERTY(0x20000a66)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_11.png
    PROPERTY(0x20000a67)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_10.png
    PROPERTY(0x20000a68)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_09.png
    PROPERTY(0x20000a69)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_08.png
    PROPERTY(0x20000a6a)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_07.png
    PROPERTY(0x20000a6b)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_06.png
    PROPERTY(0x20000a6c)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_05.png
    PROPERTY(0x20000a6d)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_04.png
    PROPERTY(0x20000a6e)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_03.png
    PROPERTY(0x20000a6f)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_02.png
    PROPERTY(0x20000a70)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_01.png
    PROPERTY(0x20000a71)                // 800x480\HMINissanResources\HMI\bargraph\zoom_popup_12_steps\zoom_popup_12_00.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14539, 13)
    PROPERTY(0x20000a73)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_yard.png
    PROPERTY(0x20000a73)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_yard.png
    PROPERTY(0x20000a73)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_yard.png
    PROPERTY(0x20000a73)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_yard.png
    PROPERTY(0x20000a74)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_mile.png
    PROPERTY(0x20000a74)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_mile.png
    PROPERTY(0x20000a74)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_mile.png
    PROPERTY(0x20000a74)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_mile.png
    PROPERTY(0x20000a74)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_mile.png
    PROPERTY(0x20000a74)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_mile.png
    PROPERTY(0x20000a74)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_mile.png
    PROPERTY(0x20000a74)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_mile.png
    PROPERTY(0x20000a74)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_yardstick_mile.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_14540, 9)
    PROPERTY(0x20000a75)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_deg_e.png
    PROPERTY(0x20000a76)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_deg_e_f.png
    PROPERTY(0x20000a77)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_deg_d.png
    PROPERTY(0x20000a77)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_deg_d.png
    PROPERTY(0x20000a75)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_deg_e.png
    PROPERTY(0x20000a76)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_deg_e_f.png
    PROPERTY(0x20000a78)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_deg_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_14542, 9)
    PROPERTY(0x20000a79)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_inc_e.png
    PROPERTY(0x20000a7a)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_inc_e_f.png
    PROPERTY(0x20000a7b)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_inc_d.png
    PROPERTY(0x20000a7b)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_inc_d.png
    PROPERTY(0x20000a79)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_inc_e.png
    PROPERTY(0x20000a7a)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_inc_e_f.png
    PROPERTY(0x20000a7c)                // 800x480\HMINissanResources\HMI\button_popup\pupup_btn_inc_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_14593, 9)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000a7d)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_left_d.png
    PROPERTY(0x20000a7d)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_left_d.png
    PROPERTY(0x20000a7e)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_left_e.png
    PROPERTY(0x20000a7f)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_left_e_f.png
    PROPERTY(0x20000a80)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_left_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_14594, 9)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000a81)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_right_d.png
    PROPERTY(0x20000a81)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_right_d.png
    PROPERTY(0x20000a82)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_right_e.png
    PROPERTY(0x20000a83)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_right_e_f.png
    PROPERTY(0x20000a84)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_right_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateImages_14595, 9)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000a85)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_d.png
    PROPERTY(0x20000a85)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_d.png
    PROPERTY(0x20000a86)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_e.png
    PROPERTY(0x20000a87)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_e_f.png
    PROPERTY(0x20000a88)                // 800x480\HMINissanResources\HMI\list_scroller\list_scroller_p.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_14596, 1)
    PROPERTY(0xe005102e)                // Display1: 81, Display2: 46
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(NAV_SYSDLG_NAV_CALC_ROUTE_SYSIND_PROGRESS_Strlist_text, 3)
    PROPERTY(0x80000194)                // Calculating fastest route. -> NAV.SYSDLG_NAV_CALC_ROUTE_SYSIND_PROGRESS.Strlist.text-000
    PROPERTY(0x80000195)                // Calculating eco route. -> NAV.SYSDLG_NAV_CALC_ROUTE_SYSIND_PROGRESS.Strlist.text-001
    PROPERTY(0x80000196)                // Calculating shortest distance. -> NAV.SYSDLG_NAV_CALC_ROUTE_SYSIND_PROGRESS.Strlist.text-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14630, 26)
    PROPERTY(0x20000a89)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_000.png
    PROPERTY(0x20000a8a)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_001.png
    PROPERTY(0x20000a8b)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_002.png
    PROPERTY(0x20000a8c)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_003.png
    PROPERTY(0x20000a8d)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_004.png
    PROPERTY(0x20000a8e)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_005.png
    PROPERTY(0x20000a8f)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_006.png
    PROPERTY(0x20000a90)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_007.png
    PROPERTY(0x20000a91)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_008.png
    PROPERTY(0x20000a92)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_009.png
    PROPERTY(0x20000a93)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_010.png
    PROPERTY(0x20000a94)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_011.png
    PROPERTY(0x20000a95)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_012.png
    PROPERTY(0x20000a96)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_013.png
    PROPERTY(0x20000a97)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_014.png
    PROPERTY(0x20000a98)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_015.png
    PROPERTY(0x20000a99)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_016.png
    PROPERTY(0x20000a9a)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_017.png
    PROPERTY(0x20000a9b)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_018.png
    PROPERTY(0x20000a9c)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_019.png
    PROPERTY(0x20000a9d)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_020.png
    PROPERTY(0x20000a9e)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_021.png
    PROPERTY(0x20000a9f)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_022.png
    PROPERTY(0x20000aa0)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_023.png
    PROPERTY(0x20000aa1)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_024.png
    PROPERTY(0x20000aa2)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_025.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(baselineList_14662, 3)
    PROPERTY(0xe002e01a)                // Display1: 46, Display2: 26
    PROPERTY(0xe0020012)                // Display1: 32, Display2: 18
    PROPERTY(0xe004a02a)                // Display1: 74, Display2: 42
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_14721, 7)
    PROPERTY(0x1000ff00)                // 65280
    PROPERTY(0x1000ff00)                // 65280
    PROPERTY(0x1000ff00)                // 65280
    PROPERTY(0x1000ff00)                // 65280
    PROPERTY(0x1000ff00)                // 65280
    PROPERTY(0x1000ff00)                // 65280
    PROPERTY(0x1000ff00)                // 65280
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(StateColors_14723, 7)
    PROPERTY(0x10ff0000)                // 16711680
    PROPERTY(0x10ff0000)                // 16711680
    PROPERTY(0x10ff0000)                // 16711680
    PROPERTY(0x10ff0000)                // 16711680
    PROPERTY(0x10ff0000)                // 16711680
    PROPERTY(0x10ff0000)                // 16711680
    PROPERTY(0x10ff0000)                // 16711680
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14766, 19)
    PROPERTY(0x20000aa3)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_l_09.png
    PROPERTY(0x20000aa4)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_l_08.png
    PROPERTY(0x20000aa5)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_l_07.png
    PROPERTY(0x20000aa6)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_l_06.png
    PROPERTY(0x20000aa7)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_l_05.png
    PROPERTY(0x20000aa8)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_l_04.png
    PROPERTY(0x20000aa9)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_l_03.png
    PROPERTY(0x20000aaa)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_l_02.png
    PROPERTY(0x20000aab)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_l_01.png
    PROPERTY(0x20000aac)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_n.png
    PROPERTY(0x20000aad)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_r_01.png
    PROPERTY(0x20000aae)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_r_02.png
    PROPERTY(0x20000aaf)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_r_03.png
    PROPERTY(0x20000ab0)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_r_04.png
    PROPERTY(0x20000ab1)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_r_05.png
    PROPERTY(0x20000ab2)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_r_06.png
    PROPERTY(0x20000ab3)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_r_07.png
    PROPERTY(0x20000ab4)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_r_08.png
    PROPERTY(0x20000ab5)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_bal_19_steps\set_popup_bal_r_09.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14767, 4)
    PROPERTY(0x20000ab6)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_brightness_day.png
    PROPERTY(0x20000ab7)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_brightness_night.png
    PROPERTY(0x20000ab8)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_brightness_auto.png
    PROPERTY(0x20000ab8)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_brightness_auto.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strliSkinDayNightModes, 3)
    PROPERTY(0x800002bd)                // Auto -> SET.strliSkinDayNightModes-000
    PROPERTY(0x800002ba)                // Day -> SET.strliSettingsSystemDisplay.ListItemChoiceDisplayMode.ButtonTop.Labeltext.content-001
    PROPERTY(0x800002bb)                // Night -> SET.strliSettingsSystemDisplay.ListItemChoiceDisplayMode.ButtonTop.Labeltext.content-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14776, 3)
    PROPERTY(0x20000aba)                // 800x480\HMINissanResources\HMI\sonar\sonar_Sedan.png
    PROPERTY(0x20000abb)                // 800x480\HMINissanResources\HMI\sonar\sonar_SUV.png
    PROPERTY(0x20000abc)                // 800x480\HMINissanResources\HMI\sonar\sonar_Van.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14778, 11)
    PROPERTY(0x20000abd)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_left_n.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000abe)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_left_g.png
    PROPERTY(0x20000abf)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_left_y.png
    PROPERTY(0x20000ac0)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_left_r.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14780, 11)
    PROPERTY(0x20000ac1)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_center_n.png
    PROPERTY(0x20000ac2)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_center_gg.png
    PROPERTY(0x20000ac3)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_center_g.png
    PROPERTY(0x20000ac4)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_center_y.png
    PROPERTY(0x20000ac5)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_center_r.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14782, 11)
    PROPERTY(0x20000ac6)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_right_n.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000ac7)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_right_g.png
    PROPERTY(0x20000ac8)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_right_y.png
    PROPERTY(0x20000ac9)                // 800x480\HMINissanResources\HMI\sonar\sonar_front_right_r.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14784, 11)
    PROPERTY(0x20000aca)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_left_n.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000acb)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_left_g.png
    PROPERTY(0x20000acc)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_left_y.png
    PROPERTY(0x20000acd)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_left_r.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14786, 11)
    PROPERTY(0x20000ace)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_center_n.png
    PROPERTY(0x20000acf)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_center_gg.png
    PROPERTY(0x20000ad0)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_center_g.png
    PROPERTY(0x20000ad1)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_center_y.png
    PROPERTY(0x20000ad2)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_center_r.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14788, 11)
    PROPERTY(0x20000ad3)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_right_n.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000ad4)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_right_g.png
    PROPERTY(0x20000ad5)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_right_y.png
    PROPERTY(0x20000ad6)                // 800x480\HMINissanResources\HMI\sonar\sonar_rear_right_r.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14852, 41)
    PROPERTY(0x20000ad7)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_00.png
    PROPERTY(0x20000ad8)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_01.png
    PROPERTY(0x20000ad9)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_02.png
    PROPERTY(0x20000ada)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_03.png
    PROPERTY(0x20000adb)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_04.png
    PROPERTY(0x20000adc)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_05.png
    PROPERTY(0x20000add)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_06.png
    PROPERTY(0x20000ade)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_07.png
    PROPERTY(0x20000adf)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_08.png
    PROPERTY(0x20000ae0)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_09.png
    PROPERTY(0x20000ae1)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_10.png
    PROPERTY(0x20000ae2)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_11.png
    PROPERTY(0x20000ae3)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_12.png
    PROPERTY(0x20000ae4)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_13.png
    PROPERTY(0x20000ae5)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_14.png
    PROPERTY(0x20000ae6)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_15.png
    PROPERTY(0x20000ae7)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_16.png
    PROPERTY(0x20000ae8)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_17.png
    PROPERTY(0x20000ae9)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_18.png
    PROPERTY(0x20000aea)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_19.png
    PROPERTY(0x20000aeb)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_20.png
    PROPERTY(0x20000aec)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_21.png
    PROPERTY(0x20000aed)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_22.png
    PROPERTY(0x20000aee)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_23.png
    PROPERTY(0x20000aef)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_24.png
    PROPERTY(0x20000af0)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_25.png
    PROPERTY(0x20000af1)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_26.png
    PROPERTY(0x20000af2)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_27.png
    PROPERTY(0x20000af3)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_28.png
    PROPERTY(0x20000af4)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_29.png
    PROPERTY(0x20000af5)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_30.png
    PROPERTY(0x20000af6)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_31.png
    PROPERTY(0x20000af7)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_32.png
    PROPERTY(0x20000af8)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_33.png
    PROPERTY(0x20000af9)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_34.png
    PROPERTY(0x20000afa)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_35.png
    PROPERTY(0x20000afb)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_36.png
    PROPERTY(0x20000afc)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_37.png
    PROPERTY(0x20000afd)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_38.png
    PROPERTY(0x20000afe)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_39.png
    PROPERTY(0x20000aff)                // 800x480\HMINissanResources\HMI\bargraph\set_popup_40_steps\set_popup_40_40.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14853, 8)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x20000b00)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_volume_traffic.png
    PROPERTY(0x20000b01)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_volume_audio.png
    PROPERTY(0x20000b02)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_volume_nav.png
    PROPERTY(0x20000b03)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_volume_phone.png
    PROPERTY(0x20000b04)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_volume_voice.png
    PROPERTY(0x20000b05)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_volume_sms.png
    PROPERTY(0x20000b04)                // 800x480\HMINissanResources\HMI\settings_volume\set_popup_volume_voice.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14928, 2)
    PROPERTY(0x20000b08)                // 800x480\HMINissanResources\HMI\voice\no_talking_head_icon.png
    PROPERTY(0x20000b09)                // 800x480\HMINissanResources\HMI\voice\talking_head_icon.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SPEECHDIALOG__colrliSDSColorList, 6)
    PROPERTY(0x10ffffff)                // 16777215
    PROPERTY(0x10ffc800)                // 16762880
    PROPERTY(0x1000ff00)                // 65280
    PROPERTY(0x10ffff00)                // 16776960
    PROPERTY(0x10ffc800)                // 16762880
    PROPERTY(0x10ff0000)                // 16711680
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_14995, 41)
    PROPERTY(0x20000001)                // 800x480\__invalid__.png
    PROPERTY(0x200000e4)                // 800x480\HMINissanResources\HMI\listicon_16px\20E0_a_f.png
    PROPERTY(0x200000e4)                // 800x480\HMINissanResources\HMI\listicon_16px\20E0_a_f.png
    PROPERTY(0x200000e4)                // 800x480\HMINissanResources\HMI\listicon_16px\20E0_a_f.png
    PROPERTY(0x200000e4)                // 800x480\HMINissanResources\HMI\listicon_16px\20E0_a_f.png
    PROPERTY(0x200000e4)                // 800x480\HMINissanResources\HMI\listicon_16px\20E0_a_f.png
    PROPERTY(0x200000e9)                // 800x480\HMINissanResources\HMI\listicon_16px\20E1_a_f.png
    PROPERTY(0x200000e9)                // 800x480\HMINissanResources\HMI\listicon_16px\20E1_a_f.png
    PROPERTY(0x200000e9)                // 800x480\HMINissanResources\HMI\listicon_16px\20E1_a_f.png
    PROPERTY(0x200000e9)                // 800x480\HMINissanResources\HMI\listicon_16px\20E1_a_f.png
    PROPERTY(0x200000e9)                // 800x480\HMINissanResources\HMI\listicon_16px\20E1_a_f.png
    PROPERTY(0x200000ee)                // 800x480\HMINissanResources\HMI\listicon_16px\20E2_a_f.png
    PROPERTY(0x200000ee)                // 800x480\HMINissanResources\HMI\listicon_16px\20E2_a_f.png
    PROPERTY(0x200000ee)                // 800x480\HMINissanResources\HMI\listicon_16px\20E2_a_f.png
    PROPERTY(0x200000ee)                // 800x480\HMINissanResources\HMI\listicon_16px\20E2_a_f.png
    PROPERTY(0x200000ee)                // 800x480\HMINissanResources\HMI\listicon_16px\20E2_a_f.png
    PROPERTY(0x200000f3)                // 800x480\HMINissanResources\HMI\listicon_16px\20E3_a_f.png
    PROPERTY(0x200000f3)                // 800x480\HMINissanResources\HMI\listicon_16px\20E3_a_f.png
    PROPERTY(0x200000f3)                // 800x480\HMINissanResources\HMI\listicon_16px\20E3_a_f.png
    PROPERTY(0x200000f3)                // 800x480\HMINissanResources\HMI\listicon_16px\20E3_a_f.png
    PROPERTY(0x200000f3)                // 800x480\HMINissanResources\HMI\listicon_16px\20E3_a_f.png
    PROPERTY(0x200000f8)                // 800x480\HMINissanResources\HMI\listicon_16px\20E4_a_f.png
    PROPERTY(0x200000f8)                // 800x480\HMINissanResources\HMI\listicon_16px\20E4_a_f.png
    PROPERTY(0x200000f8)                // 800x480\HMINissanResources\HMI\listicon_16px\20E4_a_f.png
    PROPERTY(0x200000f8)                // 800x480\HMINissanResources\HMI\listicon_16px\20E4_a_f.png
    PROPERTY(0x200000f8)                // 800x480\HMINissanResources\HMI\listicon_16px\20E4_a_f.png
    PROPERTY(0x200000fd)                // 800x480\HMINissanResources\HMI\listicon_16px\20E5_a_f.png
    PROPERTY(0x200000fd)                // 800x480\HMINissanResources\HMI\listicon_16px\20E5_a_f.png
    PROPERTY(0x200000fd)                // 800x480\HMINissanResources\HMI\listicon_16px\20E5_a_f.png
    PROPERTY(0x200000fd)                // 800x480\HMINissanResources\HMI\listicon_16px\20E5_a_f.png
    PROPERTY(0x200000fd)                // 800x480\HMINissanResources\HMI\listicon_16px\20E5_a_f.png
    PROPERTY(0x20000102)                // 800x480\HMINissanResources\HMI\listicon_16px\20E6_a_f.png
    PROPERTY(0x20000102)                // 800x480\HMINissanResources\HMI\listicon_16px\20E6_a_f.png
    PROPERTY(0x20000102)                // 800x480\HMINissanResources\HMI\listicon_16px\20E6_a_f.png
    PROPERTY(0x20000102)                // 800x480\HMINissanResources\HMI\listicon_16px\20E6_a_f.png
    PROPERTY(0x20000102)                // 800x480\HMINissanResources\HMI\listicon_16px\20E6_a_f.png
    PROPERTY(0x20000107)                // 800x480\HMINissanResources\HMI\listicon_16px\20E7_a_f.png
    PROPERTY(0x20000107)                // 800x480\HMINissanResources\HMI\listicon_16px\20E7_a_f.png
    PROPERTY(0x20000107)                // 800x480\HMINissanResources\HMI\listicon_16px\20E7_a_f.png
    PROPERTY(0x20000107)                // 800x480\HMINissanResources\HMI\listicon_16px\20E7_a_f.png
    PROPERTY(0x20000107)                // 800x480\HMINissanResources\HMI\listicon_16px\20E7_a_f.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Sxm_Fuel__StrliFuelAdvisoryMessage, 5)
    PROPERTY(0x8000033c)                // Check Antenna -> Sxm_Fuel__StrliFuelAdvisoryMessage-000
    PROPERTY(0x8000033d)                // Fuel Prices are loading.  Please wait... -> Sxm_Fuel__StrliFuelAdvisoryMessage-001
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x8000033f)                // SiriusXM Travel Link is not active. Please refer to SXM channel 1 to call for subscription details. -> Sxm_Fuel__StrliFuelAdvisoryMessage-003
    PROPERTY(0x80000340)                // Service not available -> Sxm_Fuel__StrliFuelAdvisoryMessage-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliMoviesAdvisoryMessage, 5)
    PROPERTY(0x8000033c)                // Check Antenna -> Sxm_Fuel__StrliFuelAdvisoryMessage-000
    PROPERTY(0x800006c9)                // Loading movie information. Please wait... -> TRA__strliMoviesAdvisoryMessage-001
    PROPERTY(0x80000639)                // Subscribed -> TRA__SettingsXMAudio1value
    PROPERTY(0x8000033f)                // SiriusXM Travel Link is not active. Please refer to SXM channel 1 to call for subscription details. -> Sxm_Fuel__StrliFuelAdvisoryMessage-003
    PROPERTY(0x80000340)                // Service not available -> Sxm_Fuel__StrliFuelAdvisoryMessage-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__SXM_STOCKS_StrliAdvisorymessage, 5)
    PROPERTY(0x8000033c)                // Check Antenna -> Sxm_Fuel__StrliFuelAdvisoryMessage-000
    PROPERTY(0x80000722)                // Stocks are loading.  Please wait... -> TRA__SXM_STOCKS_StrliAdvisorymessage-001
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x8000033f)                // SiriusXM Travel Link is not active. Please refer to SXM channel 1 to call for subscription details. -> Sxm_Fuel__StrliFuelAdvisoryMessage-003
    PROPERTY(0x80000340)                // Service not available -> Sxm_Fuel__StrliFuelAdvisoryMessage-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Sxm_Weather__strliSXMWeatherAdvisoryMessages, 5)
    PROPERTY(0x8000033c)                // Check Antenna -> Sxm_Fuel__StrliFuelAdvisoryMessage-000
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x8000033f)                // SiriusXM Travel Link is not active. Please refer to SXM channel 1 to call for subscription details. -> Sxm_Fuel__StrliFuelAdvisoryMessage-003
    PROPERTY(0x80000340)                // Service not available -> Sxm_Fuel__StrliFuelAdvisoryMessage-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliSXMTrafficAdvisoryText, 5)
    PROPERTY(0x8000033c)                // Check Antenna -> Sxm_Fuel__StrliFuelAdvisoryMessage-000
    PROPERTY(0x8000086d)                // Traffic Information is Loading. Please Wait... -> TRA__strliSXMTrafficAdvisoryText-001
    PROPERTY(0x80000639)                // Subscribed -> TRA__SettingsXMAudio1value
    PROPERTY(0x8000086e)                // SiriusXM Traffic is not active. Please refer to SXM channel 1 to call for subscription details. -> TRA__strliSXMTrafficAdvisoryText-003
    PROPERTY(0x80000340)                // Service not available -> Sxm_Fuel__StrliFuelAdvisoryMessage-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliSXMTravelLinkAdvisoryMessages, 5)
    PROPERTY(0x8000033c)                // Check Antenna -> Sxm_Fuel__StrliFuelAdvisoryMessage-000
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x8000033f)                // SiriusXM Travel Link is not active. Please refer to SXM channel 1 to call for subscription details. -> Sxm_Fuel__StrliFuelAdvisoryMessage-003
    PROPERTY(0x8000086f)                // Service temporarily not available -> TRA__strliSXMTravelLinkAdvisoryMessages-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_15559, 12)
    PROPERTY(0x20000b0f)                // 800x480\HMINissanResources\HMI\waitanimation\wait_00.png
    PROPERTY(0x20000b10)                // 800x480\HMINissanResources\HMI\waitanimation\wait_01.png
    PROPERTY(0x20000b11)                // 800x480\HMINissanResources\HMI\waitanimation\wait_02.png
    PROPERTY(0x20000b12)                // 800x480\HMINissanResources\HMI\waitanimation\wait_03.png
    PROPERTY(0x20000b13)                // 800x480\HMINissanResources\HMI\waitanimation\wait_04.png
    PROPERTY(0x20000b14)                // 800x480\HMINissanResources\HMI\waitanimation\wait_05.png
    PROPERTY(0x20000b15)                // 800x480\HMINissanResources\HMI\waitanimation\wait_06.png
    PROPERTY(0x20000b16)                // 800x480\HMINissanResources\HMI\waitanimation\wait_07.png
    PROPERTY(0x20000b17)                // 800x480\HMINissanResources\HMI\waitanimation\wait_08.png
    PROPERTY(0x20000b18)                // 800x480\HMINissanResources\HMI\waitanimation\wait_09.png
    PROPERTY(0x20000b19)                // 800x480\HMINissanResources\HMI\waitanimation\wait_10.png
    PROPERTY(0x20000b1a)                // 800x480\HMINissanResources\HMI\waitanimation\wait_11.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Images_15576, 101)
    PROPERTY(0x20000a89)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_000.png
    PROPERTY(0x20000a8a)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_001.png
    PROPERTY(0x20000a8a)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_001.png
    PROPERTY(0x20000a8a)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_001.png
    PROPERTY(0x20000a8a)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_001.png
    PROPERTY(0x20000a8b)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_002.png
    PROPERTY(0x20000a8b)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_002.png
    PROPERTY(0x20000a8b)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_002.png
    PROPERTY(0x20000a8b)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_002.png
    PROPERTY(0x20000a8c)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_003.png
    PROPERTY(0x20000a8c)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_003.png
    PROPERTY(0x20000a8c)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_003.png
    PROPERTY(0x20000a8c)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_003.png
    PROPERTY(0x20000a8d)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_004.png
    PROPERTY(0x20000a8d)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_004.png
    PROPERTY(0x20000a8d)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_004.png
    PROPERTY(0x20000a8d)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_004.png
    PROPERTY(0x20000a8e)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_005.png
    PROPERTY(0x20000a8e)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_005.png
    PROPERTY(0x20000a8e)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_005.png
    PROPERTY(0x20000a8e)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_005.png
    PROPERTY(0x20000a8f)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_006.png
    PROPERTY(0x20000a8f)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_006.png
    PROPERTY(0x20000a8f)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_006.png
    PROPERTY(0x20000a8f)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_006.png
    PROPERTY(0x20000a90)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_007.png
    PROPERTY(0x20000a90)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_007.png
    PROPERTY(0x20000a90)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_007.png
    PROPERTY(0x20000a90)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_007.png
    PROPERTY(0x20000a91)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_008.png
    PROPERTY(0x20000a91)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_008.png
    PROPERTY(0x20000a91)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_008.png
    PROPERTY(0x20000a91)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_008.png
    PROPERTY(0x20000a92)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_009.png
    PROPERTY(0x20000a92)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_009.png
    PROPERTY(0x20000a92)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_009.png
    PROPERTY(0x20000a92)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_009.png
    PROPERTY(0x20000a93)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_010.png
    PROPERTY(0x20000a93)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_010.png
    PROPERTY(0x20000a93)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_010.png
    PROPERTY(0x20000a93)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_010.png
    PROPERTY(0x20000a94)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_011.png
    PROPERTY(0x20000a94)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_011.png
    PROPERTY(0x20000a94)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_011.png
    PROPERTY(0x20000a94)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_011.png
    PROPERTY(0x20000a95)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_012.png
    PROPERTY(0x20000a95)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_012.png
    PROPERTY(0x20000a95)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_012.png
    PROPERTY(0x20000a95)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_012.png
    PROPERTY(0x20000a96)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_013.png
    PROPERTY(0x20000a96)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_013.png
    PROPERTY(0x20000a96)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_013.png
    PROPERTY(0x20000a96)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_013.png
    PROPERTY(0x20000a97)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_014.png
    PROPERTY(0x20000a97)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_014.png
    PROPERTY(0x20000a97)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_014.png
    PROPERTY(0x20000a97)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_014.png
    PROPERTY(0x20000a98)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_015.png
    PROPERTY(0x20000a98)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_015.png
    PROPERTY(0x20000a98)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_015.png
    PROPERTY(0x20000a98)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_015.png
    PROPERTY(0x20000a99)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_016.png
    PROPERTY(0x20000a99)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_016.png
    PROPERTY(0x20000a99)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_016.png
    PROPERTY(0x20000a99)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_016.png
    PROPERTY(0x20000a9a)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_017.png
    PROPERTY(0x20000a9a)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_017.png
    PROPERTY(0x20000a9a)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_017.png
    PROPERTY(0x20000a9a)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_017.png
    PROPERTY(0x20000a9b)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_018.png
    PROPERTY(0x20000a9b)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_018.png
    PROPERTY(0x20000a9b)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_018.png
    PROPERTY(0x20000a9b)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_018.png
    PROPERTY(0x20000a9c)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_019.png
    PROPERTY(0x20000a9c)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_019.png
    PROPERTY(0x20000a9c)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_019.png
    PROPERTY(0x20000a9c)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_019.png
    PROPERTY(0x20000a9d)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_020.png
    PROPERTY(0x20000a9d)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_020.png
    PROPERTY(0x20000a9d)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_020.png
    PROPERTY(0x20000a9d)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_020.png
    PROPERTY(0x20000a9e)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_021.png
    PROPERTY(0x20000a9e)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_021.png
    PROPERTY(0x20000a9e)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_021.png
    PROPERTY(0x20000a9e)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_021.png
    PROPERTY(0x20000a9f)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_022.png
    PROPERTY(0x20000a9f)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_022.png
    PROPERTY(0x20000a9f)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_022.png
    PROPERTY(0x20000a9f)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_022.png
    PROPERTY(0x20000a9f)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_022.png
    PROPERTY(0x20000aa0)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_023.png
    PROPERTY(0x20000aa0)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_023.png
    PROPERTY(0x20000aa0)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_023.png
    PROPERTY(0x20000aa0)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_023.png
    PROPERTY(0x20000aa0)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_023.png
    PROPERTY(0x20000aa1)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_024.png
    PROPERTY(0x20000aa1)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_024.png
    PROPERTY(0x20000aa1)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_024.png
    PROPERTY(0x20000aa1)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_024.png
    PROPERTY(0x20000aa1)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_024.png
    PROPERTY(0x20000aa2)                // 800x480\HMINissanResources\HMI\bargraph\timebar_228x10\timebar_025.png
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(__export_AVDC_StrliMediaBrowseInfo, 10)
    PROPERTY(0x80000014)                // Playlists -> __export_AVDC_StrliMediaBrowseInfo-000
    PROPERTY(0x80000015)                // Artists -> __export_AVDC_StrliMediaBrowseInfo-001
    PROPERTY(0x80000016)                // Albums -> __export_AVDC_StrliMediaBrowseInfo-002
    PROPERTY(0x80000017)                // Songs -> __export_AVDC_StrliMediaBrowseInfo-003
    PROPERTY(0x80000018)                // Genres -> __export_AVDC_StrliMediaBrowseInfo-004
    PROPERTY(0x80000019)                // Composers -> __export_AVDC_StrliMediaBrowseInfo-005
    PROPERTY(0x8000001a)                // Audiobooks -> __export_AVDC_StrliMediaBrowseInfo-006
    PROPERTY(0x8000001b)                // Podcasts -> __export_AVDC_StrliMediaBrowseInfo-007
    PROPERTY(0x8000001c)                // All -> __export_AVDC_StrliMediaBrowseInfo-008
    PROPERTY(0x8000001d)                // Track -> __export_AVDC_StrliMediaBrowseInfo-009
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(__export_Navigation_StrliAPIString, 37)
    PROPERTY(0x8000001e)                // Unnamed road -> __export_Navigation_StrliAPIString-000
    PROPERTY(0x8000001f)                // Sun -> __export_Navigation_StrliAPIString-001
    PROPERTY(0x80000020)                // Mon -> __export_Navigation_StrliAPIString-002
    PROPERTY(0x80000021)                // Tue -> __export_Navigation_StrliAPIString-003
    PROPERTY(0x80000022)                // Wed -> __export_Navigation_StrliAPIString-004
    PROPERTY(0x80000023)                // Thu -> __export_Navigation_StrliAPIString-005
    PROPERTY(0x80000024)                // Fri -> __export_Navigation_StrliAPIString-006
    PROPERTY(0x80000025)                // Sat -> __export_Navigation_StrliAPIString-007
    PROPERTY(0x80000026)                // AM -> __export_Navigation_StrliAPIString-008
    PROPERTY(0x80000027)                // PM -> __export_Navigation_StrliAPIString-009
    PROPERTY(0x80000028)                // Not Available -> __export_Navigation_StrliAPIString-010
    PROPERTY(0x80000029)                // mph -> __export_Navigation_StrliAPIString-011
    PROPERTY(0x8000002a)                // km/h -> __export_Navigation_StrliAPIString-012
    PROPERTY(0x8000002b)                // N -> __export_Navigation_StrliAPIString-013
    PROPERTY(0x8000002c)                // NNE -> __export_Navigation_StrliAPIString-014
    PROPERTY(0x8000002d)                // NE -> __export_Navigation_StrliAPIString-015
    PROPERTY(0x8000002e)                // ENE -> __export_Navigation_StrliAPIString-016
    PROPERTY(0x8000002f)                // E -> __export_Navigation_StrliAPIString-017
    PROPERTY(0x80000030)                // ESE -> __export_Navigation_StrliAPIString-018
    PROPERTY(0x80000031)                // SE -> __export_Navigation_StrliAPIString-019
    PROPERTY(0x80000032)                // SSE -> __export_Navigation_StrliAPIString-020
    PROPERTY(0x80000033)                // S -> __export_Navigation_StrliAPIString-021
    PROPERTY(0x80000034)                // SSW -> __export_Navigation_StrliAPIString-022
    PROPERTY(0x80000035)                // SW -> __export_Navigation_StrliAPIString-023
    PROPERTY(0x80000036)                // WSW -> __export_Navigation_StrliAPIString-024
    PROPERTY(0x80000037)                // W -> __export_Navigation_StrliAPIString-025
    PROPERTY(0x80000038)                // WNW -> __export_Navigation_StrliAPIString-026
    PROPERTY(0x80000039)                // NW -> __export_Navigation_StrliAPIString-027
    PROPERTY(0x8000003a)                // NNW -> __export_Navigation_StrliAPIString-028
    PROPERTY(0x8000003b)                // mi -> __export_Navigation_StrliAPIString-029
    PROPERTY(0x8000003c)                // km -> __export_Navigation_StrliAPIString-030
    PROPERTY(0x8000003d)                // ft -> __export_Navigation_StrliAPIString-031
    PROPERTY(0x8000003e)                // m -> __export_Navigation_StrliAPIString-032
    PROPERTY(0x8000003f)                // in -> __export_Navigation_StrliAPIString-033
    PROPERTY(0x80000040)                // cm -> __export_Navigation_StrliAPIString-034
    PROPERTY(0x80000041)                // yds -> __export_Navigation_StrliAPIString-035
    PROPERTY(0x80000042)                // MAP_DESTINATION -> __export_Navigation_StrliAPIString-036
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(__export_Phone_Strli_Save_custom_Messages, 17)
    PROPERTY(0x80000043)                // (Save custom message here) -> __export_Phone_Strli_Save_custom_Messages-000
    PROPERTY(0x80000044)                // (Save custom message 2 here) -> __export_Phone_Strli_Save_custom_Messages-001
    PROPERTY(0x80000045)                // (Save custom message 3 here) -> __export_Phone_Strli_Save_custom_Messages-002
    PROPERTY(0x80000046)                // (Save custom message 4 here) -> __export_Phone_Strli_Save_custom_Messages-003
    PROPERTY(0x80000047)                // Driving, can't text. -> __export_Phone_Strli_Save_custom_Messages-004
    PROPERTY(0x80000048)                // Sent from -> __export_Phone_Strli_Save_custom_Messages-005
    PROPERTY(0x80000049)                // Yesterday -> __export_Phone_Strli_Save_custom_Messages-006
    PROPERTY(0x8000004a)                // Sunday -> __export_Phone_Strli_Save_custom_Messages-007
    PROPERTY(0x8000004b)                // Monday -> __export_Phone_Strli_Save_custom_Messages-008
    PROPERTY(0x8000004c)                // Tuesday -> __export_Phone_Strli_Save_custom_Messages-009
    PROPERTY(0x8000004d)                // Wednesday -> __export_Phone_Strli_Save_custom_Messages-010
    PROPERTY(0x8000004e)                // Thursday -> __export_Phone_Strli_Save_custom_Messages-011
    PROPERTY(0x8000004f)                // Friday -> __export_Phone_Strli_Save_custom_Messages-012
    PROPERTY(0x80000050)                // Saturday -> __export_Phone_Strli_Save_custom_Messages-013
    PROPERTY(0x80000051)                // Msg  -> __export_Phone_Strli_Save_custom_Messages-014
    PROPERTY(0x80000052)                //  of  -> __export_Phone_Strli_Save_custom_Messages-015
    PROPERTY(0x80000053)                // Private Number -> __export_Phone_Strli_Save_custom_Messages-016
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(__export_SpeechDialog_StrliAPIString, 28)
    PROPERTY(0x80000049)                // Yesterday -> __export_Phone_Strli_Save_custom_Messages-006
    PROPERTY(0x8000004a)                // Sunday -> __export_Phone_Strli_Save_custom_Messages-007
    PROPERTY(0x8000004b)                // Monday -> __export_Phone_Strli_Save_custom_Messages-008
    PROPERTY(0x8000004c)                // Tuesday -> __export_Phone_Strli_Save_custom_Messages-009
    PROPERTY(0x8000004d)                // Wednesday -> __export_Phone_Strli_Save_custom_Messages-010
    PROPERTY(0x8000004e)                // Thursday -> __export_Phone_Strli_Save_custom_Messages-011
    PROPERTY(0x8000004f)                // Friday -> __export_Phone_Strli_Save_custom_Messages-012
    PROPERTY(0x80000050)                // Saturday -> __export_Phone_Strli_Save_custom_Messages-013
    PROPERTY(0x80000051)                // Msg  -> __export_Phone_Strli_Save_custom_Messages-014
    PROPERTY(0x80000052)                //  of  -> __export_Phone_Strli_Save_custom_Messages-015
    PROPERTY(0x80000054)                // Today -> __export_SpeechDialog_StrliAPIString-010
    PROPERTY(0x80000055)                // 1 day  -> __export_SpeechDialog_StrliAPIString-011
    PROPERTY(0x80000056)                // 2 days -> __export_SpeechDialog_StrliAPIString-012
    PROPERTY(0x80000057)                // 3+days -> __export_SpeechDialog_StrliAPIString-013
    PROPERTY(0x80000058)                // km -> __export_SpeechDialog_StrliAPIString-014
    PROPERTY(0x80000059)                // mi -> __export_SpeechDialog_StrliAPIString-015
    PROPERTY(0x8000005a)                // Favorite Teams -> __export_SpeechDialog_StrliAPIString-016
    PROPERTY(0x8000005b)                // Favorites -> __export_SpeechDialog_StrliAPIString-017
    PROPERTY(0x8000005c)                // Football -> __export_SpeechDialog_StrliAPIString-018
    PROPERTY(0x8000005d)                // American Football -> __export_SpeechDialog_StrliAPIString-019
    PROPERTY(0x8000005e)                // Basketball -> __export_SpeechDialog_StrliAPIString-020
    PROPERTY(0x8000005f)                // Baseball -> __export_SpeechDialog_StrliAPIString-021
    PROPERTY(0x80000060)                // Soccer -> __export_SpeechDialog_StrliAPIString-022
    PROPERTY(0x80000061)                // Ice Hockey -> __export_SpeechDialog_StrliAPIString-023
    PROPERTY(0x80000062)                // Hockey -> __export_SpeechDialog_StrliAPIString-024
    PROPERTY(0x80000063)                // Motor Sports -> __export_SpeechDialog_StrliAPIString-025
    PROPERTY(0x80000064)                // Auto Racing -> __export_SpeechDialog_StrliAPIString-026
    PROPERTY(0x80000065)                // Golf -> __export_SpeechDialog_StrliAPIString-027
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(__export_SXM_StrliAPIInfo, 69)
    PROPERTY(0x80000066)                // Rating -> __export_SXM_StrliAPIInfo-000
    PROPERTY(0x80000067)                // Length -> __export_SXM_StrliAPIInfo-001
    PROPERTY(0x80000068)                // Times -> __export_SXM_StrliAPIInfo-002
    PROPERTY(0x80000069)                // Actors -> __export_SXM_StrliAPIInfo-003
    PROPERTY(0x8000006a)                // Synopsis -> __export_SXM_StrliAPIInfo-004
    PROPERTY(0x8000006b)                // Call Theater for Show Times -> __export_SXM_StrliAPIInfo-005
    PROPERTY(0x8000006c)                // Today -> __export_SXM_StrliAPIInfo-006
    PROPERTY(0x8000006d)                // 1 day -> __export_SXM_StrliAPIInfo-007
    PROPERTY(0x80000056)                // 2 days -> __export_SpeechDialog_StrliAPIString-012
    PROPERTY(0x80000057)                // 3+days -> __export_SpeechDialog_StrliAPIString-013
    PROPERTY(0x8000006e)                // None -> __export_SXM_StrliAPIInfo-010
    PROPERTY(0x8000006f)                // Out of Fuel -> __export_SXM_StrliAPIInfo-011
    PROPERTY(0x80000070)                // Last Updated -> __export_SXM_StrliAPIInfo-012
    PROPERTY(0x80000071)                // Amenities -> __export_SXM_StrliAPIInfo-013
    PROPERTY(0x80000072)                // Open 24 Hours -> __export_SXM_StrliAPIInfo-014
    PROPERTY(0x80000073)                // Emergency Road Service -> __export_SXM_StrliAPIInfo-015
    PROPERTY(0x80000074)                // Full Service -> __export_SXM_StrliAPIInfo-016
    PROPERTY(0x80000075)                // Oil Change Service  -> __export_SXM_StrliAPIInfo-017
    PROPERTY(0x80000076)                // Interstate Access (less than .5 miles) -> __export_SXM_StrliAPIInfo-018
    PROPERTY(0x80000077)                // Interstate Access (over .5 miles) -> __export_SXM_StrliAPIInfo-019
    PROPERTY(0x80000078)                // Cash Discount -> __export_SXM_StrliAPIInfo-020
    PROPERTY(0x80000079)                // Convenience Store -> __export_SXM_StrliAPIInfo-021
    PROPERTY(0x8000007a)                // Supermarket -> __export_SXM_StrliAPIInfo-022
    PROPERTY(0x8000007b)                // Snacks/Fast Food -> __export_SXM_StrliAPIInfo-023
    PROPERTY(0x8000007c)                // Restaurant -> __export_SXM_StrliAPIInfo-024
    PROPERTY(0x8000007d)                // Truck Stop -> __export_SXM_StrliAPIInfo-025
    PROPERTY(0x8000007e)                // Truck Stop with Hotel -> __export_SXM_StrliAPIInfo-026
    PROPERTY(0x8000007f)                // Affiliated Service Cards Accepted -> __export_SXM_StrliAPIInfo-027
    PROPERTY(0x80000080)                // All Service Cards Accepted -> __export_SXM_StrliAPIInfo-028
    PROPERTY(0x80000081)                // Credit/Debit Accepted -> __export_SXM_StrliAPIInfo-029
    PROPERTY(0x80000082)                // Public Access -> __export_SXM_StrliAPIInfo-030
    PROPERTY(0x80000083)                // Patrons Only -> __export_SXM_StrliAPIInfo-031
    PROPERTY(0x80000084)                // Cash Accepted -> __export_SXM_StrliAPIInfo-032
    PROPERTY(0x80000085)                // Reservations -> __export_SXM_StrliAPIInfo-033
    PROPERTY(0x80000026)                // AM -> __export_Navigation_StrliAPIString-008
    PROPERTY(0x80000027)                // PM -> __export_Navigation_StrliAPIString-009
    PROPERTY(0x80000086)                // Loading -> __export_SXM_StrliAPIInfo-036
    PROPERTY(0x80000087)                // Unknown -> __export_SXM_StrliAPIInfo-037
    PROPERTY(0x80000058)                // km -> __export_SpeechDialog_StrliAPIString-014
    PROPERTY(0x80000088)                // m -> __export_SXM_StrliAPIInfo-039
    PROPERTY(0x80000059)                // mi -> __export_SpeechDialog_StrliAPIString-015
    PROPERTY(0x80000089)                // yds -> __export_SXM_StrliAPIInfo-041
    PROPERTY(0x8000008a)                // ft -> __export_SXM_StrliAPIInfo-042
    PROPERTY(0x8000008b)                // Fuel Price Info Loading... -> __export_SXM_StrliAPIInfo-043
    PROPERTY(0x8000008c)                // No Price Information -> __export_SXM_StrliAPIInfo-044
    PROPERTY(0x8000008d)                // All Brands -> __export_SXM_StrliAPIInfo-045
    PROPERTY(0x8000008e)                // Preset SXM -> __export_SXM_StrliAPIInfo-046
    PROPERTY(0x8000008f)                // Today's Game -> __export_SXM_StrliAPIInfo-047
    PROPERTY(0x80000090)                // Recent Game -> __export_SXM_StrliAPIInfo-048
    PROPERTY(0x80000091)                // Future Game -> __export_SXM_StrliAPIInfo-049
    PROPERTY(0x80000092)                // Away -> __export_SXM_StrliAPIInfo-050
    PROPERTY(0x80000093)                // Home -> __export_SXM_StrliAPIInfo-051
    PROPERTY(0x80000094)                // Course -> __export_SXM_StrliAPIInfo-052
    PROPERTY(0x80000095)                // Purse -> __export_SXM_StrliAPIInfo-053
    PROPERTY(0x80000096)                // Yardage -> __export_SXM_StrliAPIInfo-054
    PROPERTY(0x80000097)                // Winner -> __export_SXM_StrliAPIInfo-055
    PROPERTY(0x80000098)                // Track -> __export_SXM_StrliAPIInfo-056
    PROPERTY(0x80000099)                // Laps -> __export_SXM_StrliAPIInfo-057
    PROPERTY(0x8000009a)                // Lap -> __export_SXM_StrliAPIInfo-058
    PROPERTY(0x8000009b)                // Leader -> __export_SXM_StrliAPIInfo-059
    PROPERTY(0x8000009c)                // Car -> __export_SXM_StrliAPIInfo-060
    PROPERTY(0x8000009d)                // Favorite -> __export_SXM_StrliAPIInfo-061
    PROPERTY(0x8000009e)                // Football -> __export_SXM_StrliAPIInfo-062
    PROPERTY(0x8000009f)                // Basketball -> __export_SXM_StrliAPIInfo-063
    PROPERTY(0x800000a0)                // Baseball -> __export_SXM_StrliAPIInfo-064
    PROPERTY(0x800000a1)                // Soccer -> __export_SXM_StrliAPIInfo-065
    PROPERTY(0x800000a2)                // Ice Hockey -> __export_SXM_StrliAPIInfo-066
    PROPERTY(0x800000a3)                // Motor Sports -> __export_SXM_StrliAPIInfo-067
    PROPERTY(0x80000065)                // Golf -> __export_SpeechDialog_StrliAPIString-027
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(NAV_strLiRouteSettings_ListItemChoice_content_NorthUp, 2)
    PROPERTY(0x8000017f)                // North -> NAV.strLiRouteSettings.ListItemChoice.content.NorthUp-000
    PROPERTY(0x8000017f)                // North -> NAV.strLiRouteSettings.ListItemChoice.content.NorthUp-000
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(NAV_strLiRouteSettings_ListItemChoice3_2_content_ON, 2)
    PROPERTY(0x800000a5)                // OFF -> CONST.Navigation.Setup.WarningSettings-000
    PROPERTY(0x800000f4)                // ON -> Const_strON
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(NAV_ROUTEOPTIONS_ListItemChoiceAvoidMotorway_content, 2)
    PROPERTY(0x800001db)                // OFF -> NAV_ROUTEOPTIONS.ListItemChoiceAvoiDFerries.content-000
    PROPERTY(0x800001dc)                // ON -> NAV_ROUTEOPTIONS.ListItemChoiceAvoiDFerries.content-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Navigation_Map_GetDistanceToManeuverUnit, 5)
    PROPERTY(0x8000003c)                // km -> __export_Navigation_StrliAPIString-030
    PROPERTY(0x800001e7)                // m -> Navigation.Map.GetDistanceToManeuverUnit-001
    PROPERTY(0x800001e8)                // mi -> Navigation.Map.GetDistanceToManeuverUnit-002
    PROPERTY(0x800001e9)                // yds -> Navigation.Map.GetDistanceToManeuverUnit-003
    PROPERTY(0x800001ea)                // ft -> Navigation.Map.GetDistanceToManeuverUnit-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_bListItemChoiceDistanceUnits_List, 2)
    PROPERTY(0x800002a4)                // km/h -> SET.bListItemChoiceDistanceUnits.List-000
    PROPERTY(0x8000011a)                // mph -> Const_strUnitMph
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strliSettingsAudioTuner_ListItemChoiceRdsReg_content_Auto, 2)
    PROPERTY(0x800000a5)                // OFF -> CONST.Navigation.Setup.WarningSettings-000
    PROPERTY(0x800000f4)                // ON -> Const_strON
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strliSettingsBluetooth_ListItemChoice_Label_content_OnOff, 3)
    PROPERTY(0x800000a5)                // OFF -> CONST.Navigation.Setup.WarningSettings-000
    PROPERTY(0x800000f4)                // ON -> Const_strON
    PROPERTY(0x800000a5)                // OFF -> CONST.Navigation.Setup.WarningSettings-000
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strliSettingsNav_ListItemChoiceDemoMode_content_ON, 2)
    PROPERTY(0x800000a5)                // OFF -> CONST.Navigation.Setup.WarningSettings-000
    PROPERTY(0x800000f4)                // ON -> Const_strON
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strliSettingsNav_ListItemChoicePoiWarning_content_ON, 2)
    PROPERTY(0x800000a5)                // OFF -> CONST.Navigation.Setup.WarningSettings-000
    PROPERTY(0x800000f4)                // ON -> Const_strON
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strliSettingsNav_ListItemChoiceVoiceGuidance_content_ON, 2)
    PROPERTY(0x800000a5)                // OFF -> CONST.Navigation.Setup.WarningSettings-000
    PROPERTY(0x800000f4)                // ON -> Const_strON
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strliSettingsSystemClock_ListItemChoiceDateFormat_ButtonTop_content_dd_mm_yy, 2)
    PROPERTY(0x800002b5)                // DD/MM/YYYY -> SET.strliSettingsSystemClock.ListItemChoiceDateFormat.ButtonTop.content.dd_mm_yy-000
    PROPERTY(0x800002b6)                // MM/DD/YYYY -> SET.strliSettingsSystemClock.ListItemChoiceDateFormat.ButtonTop.content.dd_mm_yy-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strliSettingsSystemDisplay_ListItemChoiceAcousticFeedback_content_On, 2)
    PROPERTY(0x800000a5)                // OFF -> CONST.Navigation.Setup.WarningSettings-000
    PROPERTY(0x800000f4)                // ON -> Const_strON
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SETTINGS_MAP_ListItemChoiceAutoZoom_content, 3)
    PROPERTY(0x80000314)                // FAST -> SETTINGS_MAP.ListItemChoiceAutoZoom.content-000
    PROPERTY(0x80000315)                // ECO -> SETTINGS_MAP.ListItemChoiceAutoZoom.content-001
    PROPERTY(0x80000316)                // SHORT -> SETTINGS_MAP.ListItemChoiceAutoZoom.content-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SPI_strlistSmartphoneAdvisoryPopup_text, 3)
    PROPERTY(0x80000331)                // Smartphone connected and available -> SPI.strlistSmartphoneAdvisoryPopup.text-000
    PROPERTY(0x80000332)                // A compatible smartphone is not connected. Please consult the Owner's portal of the Nissan website for more details. -> SPI.strlistSmartphoneAdvisoryPopup.text-001
    PROPERTY(0x80000333)                // Smartphone App not available -> SPI.strlistSmartphoneAdvisoryPopup.text-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Sxm_Weather__strliSpeedUnitCode, 8)
    PROPERTY(0x80000029)                // mph -> __export_Navigation_StrliAPIString-011
    PROPERTY(0x8000002a)                // km/h -> __export_Navigation_StrliAPIString-012
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x80000356)                // ft -> Sxm_Weather__strliSpeedUnitCode-004
    PROPERTY(0x80000088)                // m -> __export_SXM_StrliAPIInfo-039
    PROPERTY(0x80000357)                // in -> Sxm_Weather__strliSpeedUnitCode-006
    PROPERTY(0x80000358)                // cm -> Sxm_Weather__strliSpeedUnitCode-007
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Sxm_Weather__strliStormTrackerInfoMM, 13)
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x80000359)                // January -> Sxm_Weather__strliStormTrackerInfoMM-001
    PROPERTY(0x8000035a)                // February -> Sxm_Weather__strliStormTrackerInfoMM-002
    PROPERTY(0x8000035b)                // March -> Sxm_Weather__strliStormTrackerInfoMM-003
    PROPERTY(0x8000035c)                // April -> Sxm_Weather__strliStormTrackerInfoMM-004
    PROPERTY(0x8000035d)                // May -> Sxm_Weather__strliStormTrackerInfoMM-005
    PROPERTY(0x8000035e)                // June -> Sxm_Weather__strliStormTrackerInfoMM-006
    PROPERTY(0x8000035f)                // July -> Sxm_Weather__strliStormTrackerInfoMM-007
    PROPERTY(0x80000360)                // August -> Sxm_Weather__strliStormTrackerInfoMM-008
    PROPERTY(0x80000361)                // September -> Sxm_Weather__strliStormTrackerInfoMM-009
    PROPERTY(0x80000362)                // October -> Sxm_Weather__strliStormTrackerInfoMM-010
    PROPERTY(0x80000363)                // November -> Sxm_Weather__strliStormTrackerInfoMM-011
    PROPERTY(0x80000364)                // December -> Sxm_Weather__strliStormTrackerInfoMM-012
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Sxm_Weather__StrLiTempUnit_content_18853, 2)
    PROPERTY(0x8000030e)                // �F -> SETTINGS_INFO_NAR.ListItemChoice_TempUnit.content-000
    PROPERTY(0x8000030f)                // �C -> SETTINGS_INFO_NAR.ListItemChoice_TempUnit.content-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Sxm_Weather__strliWeatherStromType, 12)
    PROPERTY(0x80000087)                // Unknown -> __export_SXM_StrliAPIInfo-037
    PROPERTY(0x80000365)                // Tropical Disturbance -> Sxm_Weather__strliWeatherStromType-001
    PROPERTY(0x80000366)                // Hurricane Category 1 -> Sxm_Weather__strliWeatherStromType-002
    PROPERTY(0x80000367)                // Hurricane Category 2 -> Sxm_Weather__strliWeatherStromType-003
    PROPERTY(0x80000368)                // Hurricane Category 3 -> Sxm_Weather__strliWeatherStromType-004
    PROPERTY(0x80000369)                // Hurricane Category 4 -> Sxm_Weather__strliWeatherStromType-005
    PROPERTY(0x8000036a)                // Hurricane Category 5 -> Sxm_Weather__strliWeatherStromType-006
    PROPERTY(0x8000036b)                // Tropical Storm -> Sxm_Weather__strliWeatherStromType-007
    PROPERTY(0x8000036c)                // Tropical Depression -> Sxm_Weather__strliWeatherStromType-008
    PROPERTY(0x8000036d)                // Typhoon -> Sxm_Weather__strliWeatherStromType-009
    PROPERTY(0x8000036e)                // Super Typhoon -> Sxm_Weather__strliWeatherStromType-010
    PROPERTY(0x8000036f)                // Tropical Cyclone -> Sxm_Weather__strliWeatherStromType-011
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetDABTMCSupportStatus_text, 2)
    PROPERTY(0x800003ac)                // #No translation required -> SYS.strliGetDABTMCSupportStatus.text-000
    PROPERTY(0x800003ad)                // #No translation required -> SYS.strliGetDABTMCSupportStatus.text-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetExtPhoneSignalState_list, 2)
    PROPERTY(0x800003ae)                // Not connected -> SYS.strliGetExtPhoneSignalState.list-000
    PROPERTY(0x800000ad)                // OK -> CONST.strLabelONOff.text.OK
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemConfig_28_0_29__List, 3)
    PROPERTY(0x800003af)                // #Obsolete -> SYS.strliGetSrvSystemConfig(0).List-000
    PROPERTY(0x800003b0)                // #Obsolete -> SYS.strliGetSrvSystemConfig(0).List-001
    PROPERTY(0x800003b1)                // #Obsolete -> SYS.strliGetSrvSystemConfig(0).List-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemConfig_28_1_29__List, 3)
    PROPERTY(0x800003af)                // #Obsolete -> SYS.strliGetSrvSystemConfig(0).List-000
    PROPERTY(0x800003b2)                // #Obsolete -> SYS.strliGetSrvSystemConfig(1).List-001
    PROPERTY(0x800003b3)                // #Obsolete -> SYS.strliGetSrvSystemConfig(1).List-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemConfig_28_11_29__List, 3)
    PROPERTY(0x800003b4)                // #Obsolete -> SYS.strliGetSrvSystemConfig(11).List-000
    PROPERTY(0x800003b2)                // #Obsolete -> SYS.strliGetSrvSystemConfig(1).List-001
    PROPERTY(0x800003b3)                // #Obsolete -> SYS.strliGetSrvSystemConfig(1).List-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemConfig_28_2_29__List, 27)
    PROPERTY(0x800003af)                // #Obsolete -> SYS.strliGetSrvSystemConfig(0).List-000
    PROPERTY(0x800003b5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-001
    PROPERTY(0x800003b6)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-002
    PROPERTY(0x800003b7)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-003
    PROPERTY(0x800003b8)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-004
    PROPERTY(0x800003b9)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-005
    PROPERTY(0x800003ba)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-006
    PROPERTY(0x800003bb)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-007
    PROPERTY(0x800003bc)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-008
    PROPERTY(0x800003bd)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-009
    PROPERTY(0x800003be)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-010
    PROPERTY(0x800003bf)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-011
    PROPERTY(0x800003c0)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-012
    PROPERTY(0x800003c1)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-013
    PROPERTY(0x800003c2)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-014
    PROPERTY(0x800003c3)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-015
    PROPERTY(0x800003c4)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-016
    PROPERTY(0x800003c5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-017
    PROPERTY(0x800003c6)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-018
    PROPERTY(0x800003c7)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-019
    PROPERTY(0x800003c8)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-020
    PROPERTY(0x800003c9)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-021
    PROPERTY(0x800003ca)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-022
    PROPERTY(0x800003cb)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-023
    PROPERTY(0x800003cc)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-024
    PROPERTY(0x800003cd)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-025
    PROPERTY(0x800003ce)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-026
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemConfig_28_3_29__List, 20)
    PROPERTY(0x800003af)                // #Obsolete -> SYS.strliGetSrvSystemConfig(0).List-000
    PROPERTY(0x800003cf)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-001
    PROPERTY(0x800003d0)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-002
    PROPERTY(0x800003d1)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-003
    PROPERTY(0x800003d2)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-004
    PROPERTY(0x800003d3)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-005
    PROPERTY(0x800003b9)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-005
    PROPERTY(0x800003d4)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-007
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemConfig_28_4_29__List, 5)
    PROPERTY(0x800003af)                // #Obsolete -> SYS.strliGetSrvSystemConfig(0).List-000
    PROPERTY(0x800003d6)                // #Obsolete -> SYS.strliGetSrvSystemConfig(4).List-001
    PROPERTY(0x800003d7)                // #Obsolete -> SYS.strliGetSrvSystemConfig(4).List-002
    PROPERTY(0x800000e1)                // #Obsolete -> Const_strJapan
    PROPERTY(0x800000ff)                // #Obsolete -> Const_strRussia
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemConfig_28_5_29__List, 5)
    PROPERTY(0x800003af)                // #Obsolete -> SYS.strliGetSrvSystemConfig(0).List-000
    PROPERTY(0x800003d8)                // #Obsolete -> SYS.strliGetSrvSystemConfig(5).List-001
    PROPERTY(0x800003d9)                // #Obsolete -> SYS.strliGetSrvSystemConfig(5).List-002
    PROPERTY(0x800003da)                // #Obsolete -> SYS.strliGetSrvSystemConfig(5).List-003
    PROPERTY(0x800003db)                // #Obsolete -> SYS.strliGetSrvSystemConfig(5).List-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemConfig_28_6_29__List, 4)
    PROPERTY(0x800003af)                // #Obsolete -> SYS.strliGetSrvSystemConfig(0).List-000
    PROPERTY(0x800003dc)                // #Obsolete -> SYS.strliGetSrvSystemConfig(6).List-001
    PROPERTY(0x800003dd)                // #Obsolete -> SYS.strliGetSrvSystemConfig(6).List-002
    PROPERTY(0x800003de)                // #Obsolete -> SYS.strliGetSrvSystemConfig(6).List-003
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemConfig_28_8_29__List, 20)
    PROPERTY(0x800003af)                // #Obsolete -> SYS.strliGetSrvSystemConfig(0).List-000
    PROPERTY(0x800003d0)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-002
    PROPERTY(0x800003d2)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-004
    PROPERTY(0x800003df)                // #Obsolete -> SYS.strliGetSrvSystemConfig(8).List-003
    PROPERTY(0x800003e0)                // #Obsolete -> SYS.strliGetSrvSystemConfig(8).List-004
    PROPERTY(0x800003b6)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-002
    PROPERTY(0x800003d3)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-005
    PROPERTY(0x800003b9)                // #Obsolete -> SYS.strliGetSrvSystemConfig(2).List-005
    PROPERTY(0x800003e1)                // #Obsolete -> SYS.strliGetSrvSystemConfig(8).List-008
    PROPERTY(0x800003e2)                // #Obsolete -> SYS.strliGetSrvSystemConfig(8).List-009
    PROPERTY(0x800003e3)                // #Obsolete -> SYS.strliGetSrvSystemConfig(8).List-010
    PROPERTY(0x800003e4)                // #Obsolete -> SYS.strliGetSrvSystemConfig(8).List-011
    PROPERTY(0x800003e5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(8).List-012
    PROPERTY(0x800003e6)                // #Obsolete -> SYS.strliGetSrvSystemConfig(8).List-013
    PROPERTY(0x800003e7)                // #Obsolete -> SYS.strliGetSrvSystemConfig(8).List-014
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
    PROPERTY(0x800003d5)                // #Obsolete -> SYS.strliGetSrvSystemConfig(3).List-008
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemSelfTest_28_2_29__List, 6)
    PROPERTY(0x800003e8)                // Unknown -> SYS.strliGetSrvSystemSelfTest(2).List-000
    PROPERTY(0x800000ad)                // OK -> CONST.strLabelONOff.text.OK
    PROPERTY(0x800003e9)                // Short -> SYS.strliGetSrvSystemSelfTest(2).List-002
    PROPERTY(0x80000271)                // Open -> Service__Radio_Antenna_Status-003
    PROPERTY(0x800003ea)                // Over curr. -> SYS.strliGetSrvSystemSelfTest(2).List-004
    PROPERTY(0x800003eb)                // Passive -> SYS.strliGetSrvSystemSelfTest(2).List-005
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemStatus_28_0_29__list, 2)
    PROPERTY(0x800000ef)                // NG -> Const_strNG
    PROPERTY(0x800000ad)                // OK -> CONST.strLabelONOff.text.OK
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SYS_strliGetSrvSystemStatus_28_4_29__list, 4)
    PROPERTY(0x800003f1)                // Unknown -> SYS.strliGetSrvSystemStatus(2).list-002
    PROPERTY(0x800003ed)                // Connected -> SYS.strliGetSrvSystemSelfTest(3).List-001
    PROPERTY(0x80000271)                // Open -> Service__Radio_Antenna_Status-003
    PROPERTY(0x800003f2)                // Short -> SYS.strliGetSrvSystemStatus(4).list-003
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Telematic_strliDayoftheWeek, 7)
    PROPERTY(0x80000433)                // Sunday -> Telematic.strliDayoftheWeek-000
    PROPERTY(0x80000434)                // Monday -> Telematic.strliDayoftheWeek-001
    PROPERTY(0x80000435)                // Tuesday -> Telematic.strliDayoftheWeek-002
    PROPERTY(0x80000436)                // Wednesday -> Telematic.strliDayoftheWeek-003
    PROPERTY(0x80000437)                // Thursday -> Telematic.strliDayoftheWeek-004
    PROPERTY(0x80000438)                // Friday -> Telematic.strliDayoftheWeek-005
    PROPERTY(0x80000439)                // Saturday -> Telematic.strliDayoftheWeek-006
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strErrorMessage, 3)
    PROPERTY(0x80000680)                // The line is busy -> TRA__strErrorMessage-000
    PROPERTY(0x80000681)                // No Network -> TRA__strErrorMessage-001
    PROPERTY(0x80000682)                // No Service -> TRA__strErrorMessage-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliHandSet, 2)
    PROPERTY(0x800006c7)                // Handset -> TRA__strliHandSet-000
    PROPERTY(0x800006c8)                // Privacy Mode -> TRA__strliHandSet-001
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__TestModeLanguageList, 28)
    PROPERTY(0x80000730)                // AUTOMATIC -> TRA__TestModeLanguageList-000
    PROPERTY(0x80000731)                // DEUTSCH -> TRA__TestModeLanguageList-001
    PROPERTY(0x80000732)                // ENGLISH -> TRA__TestModeLanguageList-002
    PROPERTY(0x80000733)                // ESPANOL -> TRA__TestModeLanguageList-003
    PROPERTY(0x80000734)                // FRANCAIS -> TRA__TestModeLanguageList-004
    PROPERTY(0x80000735)                // PORTUGUES -> TRA__TestModeLanguageList-005
    PROPERTY(0x80000736)                // ITALIANO -> TRA__TestModeLanguageList-006
    PROPERTY(0x80000737)                // CZECH -> TRA__TestModeLanguageList-007
    PROPERTY(0x80000738)                // NEDERLANDS -> TRA__TestModeLanguageList-008
    PROPERTY(0x80000739)                // TURKCE -> TRA__TestModeLanguageList-009
    PROPERTY(0x8000073a)                // Russia -> TRA__TestModeLanguageList-010
    PROPERTY(0x80000732)                // ENGLISH -> TRA__TestModeLanguageList-002
    PROPERTY(0x8000073b)                // France -> TRA__TestModeLanguageList-012
    PROPERTY(0x80000733)                // ESPANOL -> TRA__TestModeLanguageList-003
    PROPERTY(0x8000073c)                // DANISH -> TRA__TestModeLanguageList-014
    PROPERTY(0x8000073d)                // SWEDISH -> TRA__TestModeLanguageList-015
    PROPERTY(0x8000073e)                // Finland -> TRA__TestModeLanguageList-016
    PROPERTY(0x8000073f)                // NORWEGIAN -> TRA__TestModeLanguageList-017
    PROPERTY(0x80000740)                // POLISH -> TRA__TestModeLanguageList-018
    PROPERTY(0x80000741)                // SLOVAK -> TRA__TestModeLanguageList-019
    PROPERTY(0x80000742)                // HUNGARIAN -> TRA__TestModeLanguageList-020
    PROPERTY(0x80000743)                // GREEK -> TRA__TestModeLanguageList-021
    PROPERTY(0x80000744)                // BRAZIL -> TRA__TestModeLanguageList-022
    PROPERTY(0x80000745)                // ARABIC -> TRA__TestModeLanguageList-023
    PROPERTY(0x80000746)                // THAI -> TRA__TestModeLanguageList-024
    PROPERTY(0x80000747)                // AUSTRALIAN -> TRA__TestModeLanguageList-025
    PROPERTY(0x80000748)                // UKRAINAN -> TRA__TestModeLanguageList-026
    PROPERTY(0x80000749)                // Unknown -> TRA__TestModeLanguageList-027
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strliSettingsDVD_CMSKIP, 5)
    PROPERTY(0x80000813)                // 15 sec  -> SET.strliSettingsDVD_CMSKIP-000
    PROPERTY(0x80000814)                // OFF -> SET.strliSettingsDVD_CMSKIP-001
    PROPERTY(0x80000815)                // 30 sec -> SET.strliSettingsDVD_CMSKIP-002
    PROPERTY(0x80000816)                // 45 sec  -> SET.strliSettingsDVD_CMSKIP-003
    PROPERTY(0x80000817)                // 60 sec  -> SET.strliSettingsDVD_CMSKIP-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strliSettingsDVD_DISPLAYMODE, 3)
    PROPERTY(0x80000818)                // WIDE -> SET.strliSettingsDVD_DISPLAYMODE-000
    PROPERTY(0x80000819)                // LETTERBOX -> SET.strliSettingsDVD_DISPLAYMODE-001
    PROPERTY(0x8000081a)                // PAN_SCAN -> SET.strliSettingsDVD_DISPLAYMODE-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strliSettingsDVD_DRC, 4)
    PROPERTY(0x80000814)                // OFF -> SET.strliSettingsDVD_CMSKIP-001
    PROPERTY(0x80000818)                // WIDE -> SET.strliSettingsDVD_DISPLAYMODE-000
    PROPERTY(0x8000081b)                // NORMAL -> SET.strliSettingsDVD_DRC-002
    PROPERTY(0x8000081c)                // BOOST -> SET.strliSettingsDVD_DRC-003
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SET_strliSettingsDVD_PLAYMODE, 3)
    PROPERTY(0x80000814)                // OFF -> SET.strliSettingsDVD_CMSKIP-001
    PROPERTY(0x8000081d)                // CHAPTER  -> SET.strliSettingsDVD_PLAYMODE-001
    PROPERTY(0x8000081e)                // TITLE -> SET.strliSettingsDVD_PLAYMODE-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Settings__strliFuelConsumption_Labeltext, 3)
    PROPERTY(0x8000081f)                // km/l -> Settings__strliFuelConsumption.Labeltext-000
    PROPERTY(0x80000820)                // l/100km -> Settings__strliFuelConsumption.Labeltext-001
    PROPERTY(0x80000821)                // MPG -> Settings__strliFuelConsumption.Labeltext-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Settings__strliLaneTiming_Labeltext, 3)
    PROPERTY(0x80000822)                // Early -> Settings__strliLaneTiming.Labeltext-000
    PROPERTY(0x80000823)                // Standard -> Settings__strliLaneTiming.Labeltext-001
    PROPERTY(0x80000824)                // Late -> Settings__strliLaneTiming.Labeltext-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Settings__strliSideIndicatorBrightness_Labeltext, 3)
    PROPERTY(0x80000825)                // Bright -> Settings__strliSideIndicatorBrightness.Labeltext-000
    PROPERTY(0x800007f4)                // Normal -> strliTestmodeANCASCConnection.ListItemChoiceConnectionStatus-000
    PROPERTY(0x80000826)                // Dark -> Settings__strliSideIndicatorBrightness.Labeltext-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Settings__strliWarningVolume_Labeltext, 3)
    PROPERTY(0x800007db)                // High -> RVC__strliSONARVolumeLevelText-002
    PROPERTY(0x800007d8)                // Middle -> RVC__strliSONARSensitivityLevelText-001
    PROPERTY(0x800007da)                // Low -> RVC__strliSONARVolumeLevelText-000
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(SXM_Weather__StrText_UVRiskIndex, 5)
    PROPERTY(0x800008b0)                // Low -> SXM_Weather__StrText_UVRiskIndex-000
    PROPERTY(0x800008b1)                // Moderate -> SXM_Weather__StrText_UVRiskIndex-001
    PROPERTY(0x800008b2)                // High -> SXM_Weather__StrText_UVRiskIndex-002
    PROPERTY(0x800008b3)                // Very High -> SXM_Weather__StrText_UVRiskIndex-003
    PROPERTY(0x800008b4)                // Extreme -> SXM_Weather__StrText_UVRiskIndex-004
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__SXM_Weather_GetSXMPrecipitationUnit, 3)
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x80000358)                // cm -> Sxm_Weather__strliSpeedUnitCode-007
    PROPERTY(0x800008b7)                // inch -> TRA__SXM_Weather_GetSXMPrecipitationUnit-002
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__SXM_Weather_strliGetSXMWindSpeedUnit, 3)
    PROPERTY(0x8000033e)                //  -> Sxm_Fuel__StrliFuelAdvisoryMessage-002
    PROPERTY(0x8000002a)                // km/h -> __export_Navigation_StrliAPIString-012
    PROPERTY(0x80000029)                // mph -> __export_Navigation_StrliAPIString-011
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Sxm_Audio__StrliPresets, 19)
    PROPERTY(0x800001a6)                //  -> NAV.SYSDLG_NAV_POI_USER_DNLPROGRESS_SYSIND.Label2.text
    PROPERTY(0x800008b8)                // Preset SXM 1- 1 -> Sxm_Audio__StrliPresets-001
    PROPERTY(0x800008b9)                // Preset SXM 1- 2 -> Sxm_Audio__StrliPresets-002
    PROPERTY(0x800008ba)                // Preset SXM 1- 3 -> Sxm_Audio__StrliPresets-003
    PROPERTY(0x800008bb)                // Preset SXM 1- 4 -> Sxm_Audio__StrliPresets-004
    PROPERTY(0x800008bc)                // Preset SXM 1- 5 -> Sxm_Audio__StrliPresets-005
    PROPERTY(0x800008bd)                // Preset SXM 1- 6 -> Sxm_Audio__StrliPresets-006
    PROPERTY(0x800008be)                // Preset SXM 2- 1 -> Sxm_Audio__StrliPresets-007
    PROPERTY(0x800008bf)                // Preset SXM 2- 2 -> Sxm_Audio__StrliPresets-008
    PROPERTY(0x800008c0)                // Preset SXM 2- 3 -> Sxm_Audio__StrliPresets-009
    PROPERTY(0x800008c1)                // Preset SXM 2- 4 -> Sxm_Audio__StrliPresets-010
    PROPERTY(0x800008c2)                // Preset SXM 2- 5 -> Sxm_Audio__StrliPresets-011
    PROPERTY(0x800008c3)                // Preset SXM 2- 6 -> Sxm_Audio__StrliPresets-012
    PROPERTY(0x800008c4)                // Preset SXM 3 - 1 -> Sxm_Audio__StrliPresets-013
    PROPERTY(0x800008c5)                // Preset SXM 3 - 2 -> Sxm_Audio__StrliPresets-014
    PROPERTY(0x800008c6)                // Preset SXM 3 - 3 -> Sxm_Audio__StrliPresets-015
    PROPERTY(0x800008c7)                // Preset SXM 3 - 4 -> Sxm_Audio__StrliPresets-016
    PROPERTY(0x800008c8)                // Preset SXM 3 - 5 -> Sxm_Audio__StrliPresets-017
    PROPERTY(0x800008c9)                // Preset SXM 3 - 6 -> Sxm_Audio__StrliPresets-018
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(NAV_MAP__strlstTempUnit_Value, 4)
    PROPERTY(0x4000013c)                // 
    PROPERTY(0x4000301a)                // �C
    PROPERTY(0x40003019)                // �F
    PROPERTY(0x4000013c)                // 
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(Dev_strlist_TestMode_GetActiveBand, 3)
    PROPERTY(0x400001a5)                // FM
    PROPERTY(0x400001b2)                // DAB
    PROPERTY(0x4000017b)                // AM
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strlistOdoDeadReckoning, 9)
    PROPERTY(0x4000a5fe)                // Connected normal
    PROPERTY(0x4000a5ff)                // Connected no calibration
    PROPERTY(0x4000a600)                // Data invalid
    PROPERTY(0x4000a601)                // Internal error
    PROPERTY(0x4000a602)                // No info
    PROPERTY(0x4000a603)                // No movement
    PROPERTY(0x4000765d)                // Error
    PROPERTY(0x4000276f)                // Disconnected
    PROPERTY(0x40002ceb)                // Unknown
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(DEV_strliGetSrvSDCardWriteProtectionStatus_List, 3)
    PROPERTY(0x4000a62b)                // N.A.
    PROPERTY(0x4000a62c)                // WP
    PROPERTY(0x4000a62d)                // noWP
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(DEV_strliGetMediaStatus, 24)
    PROPERTY(0x4000a644)                // unkown
    PROPERTY(0x4000a645)                // NO_MEDIA
    PROPERTY(0x4000a646)                // INSERTION
    PROPERTY(0x4000a647)                // INCORRECT
    PROPERTY(0x40001bed)                // AUDIO
    PROPERTY(0x4000a648)                // DATA
    PROPERTY(0x4000a649)                // DATA_MP3
    PROPERTY(0x4000a64a)                // not used
    PROPERTY(0x4000a64a)                // not used
    PROPERTY(0x4000a64b)                // NAV
    PROPERTY(0x4000a64c)                // DATA_UNKOWN
    PROPERTY(0x4000a64d)                // DATA_MP3_NAV
    PROPERTY(0x4000a64e)                // AUDIO_DATA_MP3
    PROPERTY(0x4000a64f)                // DATA_MP3_NO_NAV
    PROPERTY(0x4000a650)                // DATA_NAV_NO_MP3
    PROPERTY(0x4000a651)                // NO_DATA_MP3
    PROPERTY(0x4000a652)                // NO_DATA_NAV
    PROPERTY(0x4000a653)                // EJECT
    PROPERTY(0x4000a654)                // MEDIA_IN_SLOT
    PROPERTY(0x4000013c)                // 
    PROPERTY(0x4000013c)                // 
    PROPERTY(0x4000013c)                // 
    PROPERTY(0x4000a655)                // DATA_UNSUPPORETD_FS
    PROPERTY(0x4000a656)                // DATA_UNKOWN_FS
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(VOL_iliGetVolumeMapping, 8)
    PROPERTY(0x10000000)                // 0
    PROPERTY(0x10000008)                // 8
    PROPERTY(0x10000005)                // 5
    PROPERTY(0x10000006)                // 6
    PROPERTY(0x10000007)                // 7
    PROPERTY(0x10000009)                // 9
    PROPERTY(0x10000009)                // 9
    PROPERTY(0x10000009)                // 9
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(DEV__strListUSBCardMediaStatus, 4)
    PROPERTY(0x4000a6b5)                // Mass Storage
    PROPERTY(0x40008155)                // iPod
    PROPERTY(0x4000a6b6)                // Unknown Medium
    PROPERTY(0x4000a6b7)                // No Medium
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(DEV_strliGetCDDriveStatus, 3)
    PROPERTY(0x4000013c)                // 
    PROPERTY(0x40000b23)                // OK
    PROPERTY(0x4000a6d4)                // NOT_OK
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliTestModeCountry, 27)
    PROPERTY(0x4000a6e8)                // UNDEFINED
    PROPERTY(0x4000a6e9)                // GERMANY
    PROPERTY(0x4000a6ea)                // UK
    PROPERTY(0x4000a6eb)                // AUSTRALIA
    PROPERTY(0x4000a6ec)                // ITALY
    PROPERTY(0x4000a6ed)                // CZECH_REPUBLIC
    PROPERTY(0x4000a6ee)                // NETHERLANDS
    PROPERTY(0x4000a6ef)                // PORTUGAL
    PROPERTY(0x40003dbd)                // BRAZIL
    PROPERTY(0x40007689)                // RUSSIA
    PROPERTY(0x4000a6f0)                // UKRAINE
    PROPERTY(0x4000a6f1)                // TURKEY
    PROPERTY(0x400054ef)                // USA
    PROPERTY(0x4000a6f2)                // CANADA
    PROPERTY(0x4000a6f3)                // FRANCE
    PROPERTY(0x4000a6f4)                // MEXICO
    PROPERTY(0x4000a6f5)                // SPAIN
    PROPERTY(0x4000a6f6)                // DENMARK
    PROPERTY(0x4000a6f7)                // SWEDEN
    PROPERTY(0x4000a6f8)                // FINLAND
    PROPERTY(0x4000a6f9)                // NORWAY
    PROPERTY(0x4000a6fa)                // POLAND
    PROPERTY(0x4000a6fb)                // SLOVAKIA
    PROPERTY(0x4000a6fc)                // HUNGARY
    PROPERTY(0x4000a6fd)                // GREECE
    PROPERTY(0x4000a6fe)                // SAUDI ARABIA
    PROPERTY(0x4000a6ff)                // THAILAND
END_PROPERTY_ARRAY()

BEGIN_PROPERTY_ARRAY(TRA__strliGender, 3)
    PROPERTY(0x4000765d)                // Error
    PROPERTY(0x4000a703)                // Male
    PROPERTY(0x4000a704)                // Female
END_PROPERTY_ARRAY()

