/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_TCU_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_TCU_Base_H
#define _clHSA_TCU_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_TCU_Base : public clHSA_Base
{
public:

    static clHSA_TCU_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_TCU_Base()        {}

    virtual ulword ulwGetACNStatus( );

    virtual ulword ulwGetECallStatus( );

    virtual ulword ulwGetServiceCallStatus( );

    virtual tbool blIsTCU_Enabled( );

    virtual void vSyncAllInfoFeed( );

    virtual void vToggleProbeInfo( );

    virtual void vProbeInfoSettingEntry( );

    virtual tbool blGetProbeInfo( );

    virtual void vDeleteSharedInfo( );

    virtual void vDeleteHistory( );

    virtual void vResetAllSettings( );

    virtual void vGetUnitId(GUI_String *out_result, ulword ulwUnitID);

    virtual void vStartServiceCall( );

    virtual void vEndServiceCall( );

    virtual void vSetDriverInfoUploadPermit(ulword ulwUploadPermitStatus);

    virtual void vSetDownloadPopupState(ulword ulwstatus);

    virtual ulword ulwGetDriverInfoUploadPermitStatus( );

    virtual void vRequestChannelData(ulword ulwChannelId, ulword ulwChannelContentsId);

    virtual void vCancelRequest(ulword ulwRequestType);

    virtual tbool blIsTCU_VoiceMenuAvailable( );

    virtual tbool blIsTCU_ConnectedSearchAvailable( );

    virtual tbool blIsTCU_MobileInformationAvailable( );

    virtual ulword ulwGetVoiceMenuListCount( );

    virtual void vGetVoiceMenuListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData);

    virtual ulword ulwGetVoiceMenuListValue(ulword ulwListIndex);

    virtual void vConnectedSearchRequest(const GUI_String * SearchString);

    virtual void vPrepareConnectedSearchList( );

    virtual ulword ulwGetConnectedSearchListCount( );

    virtual void vGetConnectedSearchListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData);

    virtual ulword ulwGetConnectedSearchListValue(ulword ulwListIndex);

    virtual void vPrepareGoogleSendToCarList( );

    virtual ulword ulwGetGoogleSendToCarListCount( );

    virtual void vGetGoogleSendToCarListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData);

    virtual ulword ulwGetGoogleSendToCarListValue(ulword ulwListIndex);

    virtual void vGoogleSendToCarListUpdate( );

    virtual void vPrepareDestinationSendToCarFolderList( );

    virtual ulword ulwGetDestinationSendToCarFolderListCount( );

    virtual void vGetDestinationSendToCarFolderList(GUI_String *out_result, ulword ulwListIndex);

    virtual void vDestinationSendToCarChannelListUpdate(ulword ulwListIndex);

    virtual void vPrepareDestinationSendToCarChannelList(ulword ulwListIndex);

    virtual ulword ulwGetDestinationSendToCarChannelListCount( );

    virtual void vGetDestinationSendToCarChannelListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData);

    virtual ulword ulwGetDestinationSendToCarChannelListValue(ulword ulwListIndex);

    virtual void vPrepareJourneyPlannerFolderList( );

    virtual ulword ulwGetJourneyPlannerFolderListCount( );

    virtual void vGetJourneyPlannerFolderList(GUI_String *out_result, ulword ulwListIndex);

    virtual void vPrepareJourneyPlannerMessageList(ulword ulwListIndex);

    virtual ulword ulwGetJourneyPlannerMessageListCount( );

    virtual void vGetJourneyPlannerMessageList(GUI_String *out_result, ulword ulwListIndex);

    virtual void vJourneyPlannerMessageListUpdate(ulword ulwListIndex);

    virtual void vPrepareJourneyPlannerPoiInfo(ulword ulwListIndex);

    virtual void vPrepareSpellerHistoryAvailability(const GUI_String * SearchString);

    virtual ulword ulwIsSpellerHistoryAvailable( );

    virtual void vPrepareSpellerHistoryList(const GUI_String * SearchString);

    virtual ulword ulwSpellerHistoryListCount( );

    virtual void vSpellerHistoryList(GUI_String *out_result, ulword ulwListIndex);

    virtual void vPrepareSpellerEntryField(const GUI_String * EntryFieldValue, ulword ulwSpeller);

    virtual void vSpellerSetMaxCharCount(slword slwCount);

    virtual tbool blSpellerInputOccurred( );

    virtual void vSpellerDiscardInput( );

    virtual void vSpellerDiscardAllInput( );

    virtual void vSpellerSetCharacter(const GUI_String * InputString);

    virtual void vGetSpellerEntryField(GUI_String *out_result);

    virtual void vSpellerGetLetterFunction(GUI_String *out_result);

    virtual ulword ulwSpellerGetCursorPos( );

    virtual void vPoiInfo(GUI_String *out_result, ulword ulwIndex, ulword ulwData);

    virtual tbool blIsPOINumberAvailable(ulword ulwIndex, ulword ulwData);

    virtual void vPoiInfoInfoCallSelect(ulword ulwIndex, ulword ulwData);

    virtual void vPoiInfoInfoMapSelect(ulword ulwIndex, ulword ulwData);

    virtual void vPoiInfoInfoStartSelect(ulword ulwIndex, ulword ulwData);

    virtual ulword ulwGetHeaderIcon( );

    virtual ulword ulwWaitSyncState( );

    virtual void vPrepareMessageHistoryChannelAvailability( );

    virtual void vPrepareMessageHistoryChannelList( );

    virtual ulword ulwGetMessageHistoryChannelListCount( );

    virtual void vGetMessageHistoryChannelList(GUI_String *out_result, ulword ulwListIndex);

    virtual void vPrepareMessageHistoryAutoFeedInfo(ulword ulwListIndex);

    virtual ulword ulwGetAutoPlayCount( );

    virtual ulword ulwGetCurrentAutoPlayIndex( );

    virtual void vGetAutoPlayText(GUI_String *out_result);

    virtual void vGetAutoPlayTitle(GUI_String *out_result);

    virtual void vGetAutoPlayDynamicImageID(GUI_String *out_result);

    virtual void vAutoPlayNextKeyLongPress( );

    virtual void vAutoPlayNextKeyShortPress( );

    virtual void vAutoPlayPreviousKeyLongPress( );

    virtual void vAutoPlayPreviousKeyShortPress( );

    virtual void vAutoPlay_TTSAbort( );

    virtual void vAutoPlay_TTSStart(ulword ulwListIndex);

    virtual void vAutoPlay_Play( );

    virtual ulword ulwGetAutoPlay_Screen( );

    virtual tbool blIsAutoPlay_ShowDetailsAvailable( );

    virtual tbool blIsAutoPlay_DeleteAvailable( );

    virtual void vAutoPlay_Delete(ulword ulwListIndex);

    virtual tbool blIsAutoPlay_PlayEnabled( );

    virtual tbool blIsAutoPlay_GoHereEnabled( );

    virtual tbool blIsAutoPlay_ShowImageEnabled( );

    virtual tbool blIsAutoPlay_CallEnabled( );

    virtual tbool blIsAutoPlay_ShowOnMapEnabled( );

    virtual tbool blIsMessageHistoryAvailable( );

    virtual void vReadSMS( );

    virtual void vIgnoreSMS( );

    virtual void vToggleTestModeTCUAudio( );

    virtual tbool blGetDeveloperTestModeTCUAudioStatus( );

    virtual ulword ulwGetDeveloperTestModeTCUServerListCount( );

    virtual void vGetDeveloperTestModeTCUServerList(GUI_String *out_result, ulword ulwListIndex);

    virtual ulword ulwGetDeveloperTestModeTCUServerListActiveIndex( );

    virtual void vSetDeveloperTestModeTCUServer(ulword ulwListIndex);

    virtual void vPrepareDeveloperTestModeTCUServerlist( );

    virtual ulword ulwAutoPlay_MenuOptionAvailable( );

    virtual void vSetAutoPlayScreenID(ulword ulwData);

    virtual void vSetDriverUploadconfirmation(tbool blMode);

    virtual tbool blGetDriverUploadConfirmation( );

    virtual void vPrepareInformationFolderList( );

    virtual ulword ulwGetInformationFolderListCount( );

    virtual void vGetInformationFolderName(GUI_String *out_result, ulword ulwListIndex);

    virtual void vPrepareInformationChannelList(ulword ulwListIndex);

    virtual ulword ulwGetInformationChannelListCount( );

    virtual void vGetInformationChannelName(GUI_String *out_result, ulword ulwListIndex);

    virtual void vRequestMISChannelData(ulword ulwListIndex);

    virtual void vPrepareMISChannelInfo(ulword ulwListIndex);

    virtual void vPrepareMSChannelMasterData( );

    virtual tbool blIsMyScheduleCMDAvaiable( );

    virtual void vRequestMSChannelData( );

    virtual void vPrepareMSChannelInfo( );

    virtual tbool blIsOpenAutoPlayScreen( );

    virtual void vSetAutoplayContext(ulword ulwData);

    virtual ulword ulwGetAutoplayContext( );

    virtual void vDownloadAdditionalContents( );

    virtual void vDiscardAdditionalContents( );

    virtual tbool blIsTCUConnected( );

protected:
    clHSA_TCU_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_TCU_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_TCU_Base_H

