/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_TCU_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_TCU/clHSA_TCU_Base.h"

clHSA_TCU_Base* clHSA_TCU_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_TCU_Base.cpp.trc.h"
#endif


/**
 * Method: ulwGetACNStatus
  * Provides the state of the ACN received from TCU.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetACNStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetACNStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetECallStatus
  * Provides the state of the ECall received from TCU.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetECallStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetECallStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetServiceCallStatus
  * Provides the state of the ServiceCall received from TCU.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetServiceCallStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetServiceCallStatus not implemented"));
   return 0;
}

/**
 * Method: blIsTCU_Enabled
  * Provides info whether Car Wings should be available or not.
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsTCU_Enabled( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsTCU_Enabled not implemented"));
   return 0;
}

/**
 * Method: vSyncAllInfoFeed
  * This method is called to sync latest updates between backend server and ITM unit
  * NISSAN2.0
 */
void clHSA_TCU_Base::vSyncAllInfoFeed( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vSyncAllInfoFeed not implemented"));
   
}

/**
 * Method: vToggleProbeInfo
  * This method is called enable or disable Send Probe Information
  * NISSAN2.0
 */
void clHSA_TCU_Base::vToggleProbeInfo( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vToggleProbeInfo not implemented"));
   
}

/**
 * Method: vProbeInfoSettingEntry
  * This method should be called when we enter Probe Info Setting Screen
  * NISSAN2.0
 */
void clHSA_TCU_Base::vProbeInfoSettingEntry( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vProbeInfoSettingEntry not implemented"));
   
}

/**
 * Method: blGetProbeInfo
  * This method is acknowledgment for ToggleProbeInfo
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blGetProbeInfo( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blGetProbeInfo not implemented"));
   return 0;
}

/**
 * Method: vDeleteSharedInfo
  * This method is called to delete shared info with nissan
  * NISSAN2.0
 */
void clHSA_TCU_Base::vDeleteSharedInfo( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vDeleteSharedInfo not implemented"));
   
}

/**
 * Method: vDeleteHistory
  * This method is called to delete history of carwing
  * NISSAN2.0
 */
void clHSA_TCU_Base::vDeleteHistory( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vDeleteHistory not implemented"));
   
}

/**
 * Method: vResetAllSettings
  * This method is called to reset carwing's  settings to default state
  * NISSAN2.0
 */
void clHSA_TCU_Base::vResetAllSettings( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vResetAllSettings not implemented"));
   
}

/**
 * Method: vGetUnitId
  * Provides info regarding Unit id, TCU id, Sim id and VIN
  * NISSAN2.0
 */
void clHSA_TCU_Base::vGetUnitId(GUI_String *out_result, ulword ulwUnitID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwUnitID);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetUnitId not implemented"));
   
}

/**
 * Method: vStartServiceCall
  * This method is called to start service call
  * NISSAN2.0
 */
void clHSA_TCU_Base::vStartServiceCall( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vStartServiceCall not implemented"));
   
}

/**
 * Method: vEndServiceCall
  * Inform the GUI about ending of service call
  * NISSAN2.0
 */
void clHSA_TCU_Base::vEndServiceCall( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vEndServiceCall not implemented"));
   
}

/**
 * Method: vSetDriverInfoUploadPermit
  * This method is called to enable or disable the driver information upload
  * NISSAN2.0
 */
void clHSA_TCU_Base::vSetDriverInfoUploadPermit(ulword ulwUploadPermitStatus)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwUploadPermitStatus);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vSetDriverInfoUploadPermit not implemented"));
   
}

/**
 * Method: vSetDownloadPopupState
  * This method is called to enable or disable the driver information upload
  * NISSAN2.0
 */
void clHSA_TCU_Base::vSetDownloadPopupState(ulword ulwstatus)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwstatus);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vSetDownloadPopupState not implemented"));
   
}

/**
 * Method: ulwGetDriverInfoUploadPermitStatus
  * Provides info whether TCU services should be enabled or net, Even Settings option should be disabled. This info Gives driver not agree to use services.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetDriverInfoUploadPermitStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetDriverInfoUploadPermitStatus not implemented"));
   return 0;
}

/**
 * Method: vRequestChannelData
  * Inform the GUI about ending of service call
  * NISSAN2.0
 */
void clHSA_TCU_Base::vRequestChannelData(ulword ulwChannelId, ulword ulwChannelContentsId)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwChannelId);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwChannelContentsId);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vRequestChannelData not implemented"));
   
}

/**
 * Method: vCancelRequest
  * This method is called when user press CANCEL or BACK Key from POI Downloading screen
  * NISSAN2.0
 */
void clHSA_TCU_Base::vCancelRequest(ulword ulwRequestType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRequestType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vCancelRequest not implemented"));
   
}

/**
 * Method: blIsTCU_VoiceMenuAvailable
  * Provides info whether VoiceMenu should be available or not.
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsTCU_VoiceMenuAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsTCU_VoiceMenuAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsTCU_ConnectedSearchAvailable
  * Provides info whether ConnectedSearch should be available or not.
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsTCU_ConnectedSearchAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsTCU_ConnectedSearchAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsTCU_MobileInformationAvailable
  * Provides info whether Journey Planner, G2Car, D2Car should be available or not.
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsTCU_MobileInformationAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsTCU_MobileInformationAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwGetVoiceMenuListCount
  * Provides the number of entries for Connected Search List.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetVoiceMenuListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetVoiceMenuListCount not implemented"));
   return 0;
}

/**
 * Method: vGetVoiceMenuListString
  * Returns information about the text direction and distance of POIs
  * B
 */
void clHSA_TCU_Base::vGetVoiceMenuListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwData);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetVoiceMenuListString not implemented"));
   
}

/**
 * Method: ulwGetVoiceMenuListValue
  * Returns information about the text direction and label icon of POIs
  * B
 */
ulword clHSA_TCU_Base::ulwGetVoiceMenuListValue(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetVoiceMenuListValue not implemented"));
   return 0;
}

/**
 * Method: vConnectedSearchRequest
  * Returns the position of the cursor. The application has to manage the position of the cursor by using the special unicodes F817 and F818. The cursor is independent from the length of the text. "Left" would position the cursor between the last and the last but one  character. "Right" will position the cursor after the last character.
  * NISSAN2.0
 */
void clHSA_TCU_Base::vConnectedSearchRequest(const GUI_String * SearchString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( SearchString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vConnectedSearchRequest not implemented"));
   
}

/**
 * Method: vPrepareConnectedSearchList
  * This method is called to Prepare ConnectedSearch List
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareConnectedSearchList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareConnectedSearchList not implemented"));
   
}

/**
 * Method: ulwGetConnectedSearchListCount
  * Provides the number of entries for Connected Search List.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetConnectedSearchListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetConnectedSearchListCount not implemented"));
   return 0;
}

/**
 * Method: vGetConnectedSearchListString
  * Returns information about the text direction and label icon of POIs
  * B
 */
void clHSA_TCU_Base::vGetConnectedSearchListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwData);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetConnectedSearchListString not implemented"));
   
}

/**
 * Method: ulwGetConnectedSearchListValue
  * Returns information about the text direction and label icon of POIs
  * B
 */
ulword clHSA_TCU_Base::ulwGetConnectedSearchListValue(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetConnectedSearchListValue not implemented"));
   return 0;
}

/**
 * Method: vPrepareGoogleSendToCarList
  * This method is called to Prepare GoogleSendToCar List
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareGoogleSendToCarList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareGoogleSendToCarList not implemented"));
   
}

/**
 * Method: ulwGetGoogleSendToCarListCount
  * Provides the number of entries for GoogleSendToCar List.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetGoogleSendToCarListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetGoogleSendToCarListCount not implemented"));
   return 0;
}

/**
 * Method: vGetGoogleSendToCarListString
  * Returns information about the text direction and label icon of POIs
  * B
 */
void clHSA_TCU_Base::vGetGoogleSendToCarListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwData);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetGoogleSendToCarListString not implemented"));
   
}

/**
 * Method: ulwGetGoogleSendToCarListValue
  * Returns information about the text direction and label icon of POIs
  * B
 */
ulword clHSA_TCU_Base::ulwGetGoogleSendToCarListValue(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetGoogleSendToCarListValue not implemented"));
   return 0;
}

/**
 * Method: vGoogleSendToCarListUpdate
  * User has pressed UPDATE LIST in GoogleSendToCar Screen.
  * NISSAN2.0
 */
void clHSA_TCU_Base::vGoogleSendToCarListUpdate( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vGoogleSendToCarListUpdate not implemented"));
   
}

/**
 * Method: vPrepareDestinationSendToCarFolderList
  * This method is called to Prepare DestinationSendToCarFolder List
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareDestinationSendToCarFolderList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareDestinationSendToCarFolderList not implemented"));
   
}

/**
 * Method: ulwGetDestinationSendToCarFolderListCount
  * Provides the number of entries for DestinationSendToCar List.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetDestinationSendToCarFolderListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetDestinationSendToCarFolderListCount not implemented"));
   return 0;
}

/**
 * Method: vGetDestinationSendToCarFolderList
  * Returns information about the Destination Send to Car
  * B
 */
void clHSA_TCU_Base::vGetDestinationSendToCarFolderList(GUI_String *out_result, ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetDestinationSendToCarFolderList not implemented"));
   
}

/**
 * Method: vDestinationSendToCarChannelListUpdate
  * User has pressed UPDATE LIST in Channel List of Destination Send To Car Channel List Screen.
  * NISSAN2.0
 */
void clHSA_TCU_Base::vDestinationSendToCarChannelListUpdate(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vDestinationSendToCarChannelListUpdate not implemented"));
   
}

/**
 * Method: vPrepareDestinationSendToCarChannelList
  * This method is called to PrepareDestinationSendToCarChannel List
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareDestinationSendToCarChannelList(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareDestinationSendToCarChannelList not implemented"));
   
}

/**
 * Method: ulwGetDestinationSendToCarChannelListCount
  * Provides the number of entries for GoogleSendToCar List.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetDestinationSendToCarChannelListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetDestinationSendToCarChannelListCount not implemented"));
   return 0;
}

/**
 * Method: vGetDestinationSendToCarChannelListString
  * Returns information about the text direction and Distance of POIs
  * B
 */
void clHSA_TCU_Base::vGetDestinationSendToCarChannelListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwData);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetDestinationSendToCarChannelListString not implemented"));
   
}

/**
 * Method: ulwGetDestinationSendToCarChannelListValue
  * Returns information about the text direction and label icon of POIs
  * B
 */
ulword clHSA_TCU_Base::ulwGetDestinationSendToCarChannelListValue(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetDestinationSendToCarChannelListValue not implemented"));
   return 0;
}

/**
 * Method: vPrepareJourneyPlannerFolderList
  * This method is called to PrepareJourneyPlannerFolder List
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareJourneyPlannerFolderList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareJourneyPlannerFolderList not implemented"));
   
}

/**
 * Method: ulwGetJourneyPlannerFolderListCount
  * Provides the number of entries for Journey Planner List.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetJourneyPlannerFolderListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetJourneyPlannerFolderListCount not implemented"));
   return 0;
}

/**
 * Method: vGetJourneyPlannerFolderList
  * Returns information about the Journey Planner
  * B
 */
void clHSA_TCU_Base::vGetJourneyPlannerFolderList(GUI_String *out_result, ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetJourneyPlannerFolderList not implemented"));
   
}

/**
 * Method: vPrepareJourneyPlannerMessageList
  * This method is called to PrepareJourneyPlannerMessage List
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareJourneyPlannerMessageList(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareJourneyPlannerMessageList not implemented"));
   
}

/**
 * Method: ulwGetJourneyPlannerMessageListCount
  * Provides the number of entries for Journey Planner Message List.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetJourneyPlannerMessageListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetJourneyPlannerMessageListCount not implemented"));
   return 0;
}

/**
 * Method: vGetJourneyPlannerMessageList
  * Returns information about the Journey Planner Messages
  * B
 */
void clHSA_TCU_Base::vGetJourneyPlannerMessageList(GUI_String *out_result, ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetJourneyPlannerMessageList not implemented"));
   
}

/**
 * Method: vJourneyPlannerMessageListUpdate
  * User has pressed UPDATE LIST in Journey Planner Screen.
  * NISSAN2.0
 */
void clHSA_TCU_Base::vJourneyPlannerMessageListUpdate(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vJourneyPlannerMessageListUpdate not implemented"));
   
}

/**
 * Method: vPrepareJourneyPlannerPoiInfo
  * This method is called to PrepareJourneyPlanner Poi Info
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareJourneyPlannerPoiInfo(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareJourneyPlannerPoiInfo not implemented"));
   
}

/**
 * Method: vPrepareSpellerHistoryAvailability
  * Trigger HMI to prepare Speller History
  * B
 */
void clHSA_TCU_Base::vPrepareSpellerHistoryAvailability(const GUI_String * SearchString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( SearchString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareSpellerHistoryAvailability not implemented"));
   
}

/**
 * Method: ulwIsSpellerHistoryAvailable
  * To enable or disable History button in Speller Screen
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwIsSpellerHistoryAvailable( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwIsSpellerHistoryAvailable not implemented"));
   return 0;
}

/**
 * Method: vPrepareSpellerHistoryList
  * Trigger HMI to prepare Speller List
  * B
 */
void clHSA_TCU_Base::vPrepareSpellerHistoryList(const GUI_String * SearchString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( SearchString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareSpellerHistoryList not implemented"));
   
}

/**
 * Method: ulwSpellerHistoryListCount
  * Returns the ConnectedSearch History List Count
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwSpellerHistoryListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwSpellerHistoryListCount not implemented"));
   return 0;
}

/**
 * Method: vSpellerHistoryList
  * Returns the Connected Search History List
  * NISSAN2.0
 */
void clHSA_TCU_Base::vSpellerHistoryList(GUI_String *out_result, ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vSpellerHistoryList not implemented"));
   
}

/**
 * Method: vPrepareSpellerEntryField
  * Used to give an initial value to the input field of the speller, and to indicate the active speller.
  * B1Plus
 */
void clHSA_TCU_Base::vPrepareSpellerEntryField(const GUI_String * EntryFieldValue, ulword ulwSpeller)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( EntryFieldValue);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSpeller);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareSpellerEntryField not implemented"));
   
}

/**
 * Method: vSpellerSetMaxCharCount
  * Used to set the max number of characters which can be entered in the SpellerEntryField. The application has to know this value, in order to prevent entering characters after the maximum of allowed characters was reached. 
  * NISSAN2.0
 */
void clHSA_TCU_Base::vSpellerSetMaxCharCount(slword slwCount)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwCount);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vSpellerSetMaxCharCount not implemented"));
   
}

/**
 * Method: blSpellerInputOccurred
  * Used to set the max number of characters which can be entered in the SpellerEntryField. The application has to know this value, in order to prevent entering characters after the maximum of allowed characters was reached. 
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blSpellerInputOccurred( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blSpellerInputOccurred not implemented"));
   return 0;
}

/**
 * Method: vSpellerDiscardInput
  * discards the resultset of the speller input
  * NISSAN2.0
 */
void clHSA_TCU_Base::vSpellerDiscardInput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vSpellerDiscardInput not implemented"));
   
}

/**
 * Method: vSpellerDiscardAllInput
  * discards all input from the speller
  * NISSAN2.0
 */
void clHSA_TCU_Base::vSpellerDiscardAllInput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vSpellerDiscardAllInput not implemented"));
   
}

/**
 * Method: vSpellerSetCharacter
  * Used in the speller to send the character chosen in the widget to the application. Special unicodes which will be sent: F817 (cursor left), F818 (cursor right), F81C (DTMF). This APICall will also be used for deleting characters, by sending the unicode 0008. 
  * NISSAN2.0
 */
void clHSA_TCU_Base::vSpellerSetCharacter(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vSpellerSetCharacter not implemented"));
   
}

/**
 * Method: vGetSpellerEntryField
  * returns the string which will be shown in the input textfield of the speller
  * NISSAN2.0
 */
void clHSA_TCU_Base::vGetSpellerEntryField(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetSpellerEntryField not implemented"));
   
}

/**
 * Method: vSpellerGetLetterFunction
  * Returns the characters which should be displayed enabled in the speller.
  * NISSAN2.0
 */
void clHSA_TCU_Base::vSpellerGetLetterFunction(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vSpellerGetLetterFunction not implemented"));
   
}

/**
 * Method: ulwSpellerGetCursorPos
  * Returns the position of the cursor. The application has to manage the position of the cursor by using the special unicodes F817 and F818. The cursor is independent from the length of the text. "Left" would position the cursor between the last and the last but one  character. "Right" will position the cursor after the last character.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwSpellerGetCursorPos( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwSpellerGetCursorPos not implemented"));
   return 0;
}

/**
 * Method: vPoiInfo
  * Provides the details of the Selected POI.
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPoiInfo(GUI_String *out_result, ulword ulwIndex, ulword ulwData)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwData);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPoiInfo not implemented"));
   
}

/**
 * Method: blIsPOINumberAvailable
  * Provides the details of the Selected POI.
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsPOINumberAvailable(ulword ulwIndex, ulword ulwData)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwData);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsPOINumberAvailable not implemented"));
   return 0;
}

/**
 * Method: vPoiInfoInfoCallSelect
  * CALL pressed on POI info screen.
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPoiInfoInfoCallSelect(ulword ulwIndex, ulword ulwData)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwData);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPoiInfoInfoCallSelect not implemented"));
   
}

/**
 * Method: vPoiInfoInfoMapSelect
  * MAP pressed on POI info screen.
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPoiInfoInfoMapSelect(ulword ulwIndex, ulword ulwData)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwData);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPoiInfoInfoMapSelect not implemented"));
   
}

/**
 * Method: vPoiInfoInfoStartSelect
  * Start pressed on POI info screen.
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPoiInfoInfoStartSelect(ulword ulwIndex, ulword ulwData)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwData);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPoiInfoInfoStartSelect not implemented"));
   
}

/**
 * Method: ulwGetHeaderIcon
  * Provides the Id of Icon type to be shown in Header
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetHeaderIcon( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetHeaderIcon not implemented"));
   return 0;
}

/**
 * Method: ulwWaitSyncState
  * checks if the result of an asynchronous operation is submitted and therefore finished.
  * B1 - New Parameter for B
 */
ulword clHSA_TCU_Base::ulwWaitSyncState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwWaitSyncState not implemented"));
   return 0;
}

/**
 * Method: vPrepareMessageHistoryChannelAvailability
  * This method is called to Check Message History Channel Availability
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareMessageHistoryChannelAvailability( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareMessageHistoryChannelAvailability not implemented"));
   
}

/**
 * Method: vPrepareMessageHistoryChannelList
  * This method is called to Prepare Message History Channel List
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareMessageHistoryChannelList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareMessageHistoryChannelList not implemented"));
   
}

/**
 * Method: ulwGetMessageHistoryChannelListCount
  * Provides the number of entries for MessageHistoryChannelList.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetMessageHistoryChannelListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetMessageHistoryChannelListCount not implemented"));
   return 0;
}

/**
 * Method: vGetMessageHistoryChannelList
  * Returns information about the MessageHistoryChannel List
  * NISSAN2.0
 */
void clHSA_TCU_Base::vGetMessageHistoryChannelList(GUI_String *out_result, ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetMessageHistoryChannelList not implemented"));
   
}

/**
 * Method: vPrepareMessageHistoryAutoFeedInfo
  * This method is called to Prepare Message Auto Feed info for a particular channel
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareMessageHistoryAutoFeedInfo(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareMessageHistoryAutoFeedInfo not implemented"));
   
}

/**
 * Method: ulwGetAutoPlayCount
  * Returns Image count for Autoplay List
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetAutoPlayCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetAutoPlayCount not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentAutoPlayIndex
  * Returns the loaded image number
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetCurrentAutoPlayIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetCurrentAutoPlayIndex not implemented"));
   return 0;
}

/**
 * Method: vGetAutoPlayText
  * Returns the loaded text information
  * NISSAN2.0
 */
void clHSA_TCU_Base::vGetAutoPlayText(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetAutoPlayText not implemented"));
   
}

/**
 * Method: vGetAutoPlayTitle
  * Returns the loaded image number
  * NISSAN2.0
 */
void clHSA_TCU_Base::vGetAutoPlayTitle(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetAutoPlayTitle not implemented"));
   
}

/**
 * Method: vGetAutoPlayDynamicImageID
  * Returns Image information for Autoplay List
  * NISSAN2.0
 */
void clHSA_TCU_Base::vGetAutoPlayDynamicImageID(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetAutoPlayDynamicImageID not implemented"));
   
}

/**
 * Method: vAutoPlayNextKeyLongPress
  * Next Key Long Press on AutoPlay Screen
  * NISSAN2.0
 */
void clHSA_TCU_Base::vAutoPlayNextKeyLongPress( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vAutoPlayNextKeyLongPress not implemented"));
   
}

/**
 * Method: vAutoPlayNextKeyShortPress
  * Next Key Short Press on AutoPlay Screen
  * NISSAN2.0
 */
void clHSA_TCU_Base::vAutoPlayNextKeyShortPress( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vAutoPlayNextKeyShortPress not implemented"));
   
}

/**
 * Method: vAutoPlayPreviousKeyLongPress
  * Previous Key Long Press on AutoPlay Screen
  * NISSAN2.0
 */
void clHSA_TCU_Base::vAutoPlayPreviousKeyLongPress( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vAutoPlayPreviousKeyLongPress not implemented"));
   
}

/**
 * Method: vAutoPlayPreviousKeyShortPress
  * Previous Key Short Press on AutoPlay Screen
  * NISSAN2.0
 */
void clHSA_TCU_Base::vAutoPlayPreviousKeyShortPress( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vAutoPlayPreviousKeyShortPress not implemented"));
   
}

/**
 * Method: vAutoPlay_TTSAbort
  * Abort TTS in AutoPlay Screen
  * NISSAN2.0
 */
void clHSA_TCU_Base::vAutoPlay_TTSAbort( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vAutoPlay_TTSAbort not implemented"));
   
}

/**
 * Method: vAutoPlay_TTSStart
  * Start TTS in AutoPlay Screen
  * NISSAN2.0
 */
void clHSA_TCU_Base::vAutoPlay_TTSStart(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vAutoPlay_TTSStart not implemented"));
   
}

/**
 * Method: vAutoPlay_Play
  * Play Button pressed on Auto Play Menu
  * NISSAN2.0
 */
void clHSA_TCU_Base::vAutoPlay_Play( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vAutoPlay_Play not implemented"));
   
}

/**
 * Method: ulwGetAutoPlay_Screen
  * Return which scrren should be shown
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetAutoPlay_Screen( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetAutoPlay_Screen not implemented"));
   return 0;
}

/**
 * Method: blIsAutoPlay_ShowDetailsAvailable
  * ShowDetails button to be shown on Auto Play Menu
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsAutoPlay_ShowDetailsAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsAutoPlay_ShowDetailsAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsAutoPlay_DeleteAvailable
  * Delete button to be shown on Auto Play Menu
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsAutoPlay_DeleteAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsAutoPlay_DeleteAvailable not implemented"));
   return 0;
}

/**
 * Method: vAutoPlay_Delete
  * Delete Button Pressed on AutoPlay menu 
  * NISSAN2.0
 */
void clHSA_TCU_Base::vAutoPlay_Delete(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vAutoPlay_Delete not implemented"));
   
}

/**
 * Method: blIsAutoPlay_PlayEnabled
  * Is Play Button press enabled on Auto Play Menu
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsAutoPlay_PlayEnabled( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsAutoPlay_PlayEnabled not implemented"));
   return 0;
}

/**
 * Method: blIsAutoPlay_GoHereEnabled
  * Go Here button Enabled on Auto Play Menu
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsAutoPlay_GoHereEnabled( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsAutoPlay_GoHereEnabled not implemented"));
   return 0;
}

/**
 * Method: blIsAutoPlay_ShowImageEnabled
  * Show image button Enabled on Auto Play Menu
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsAutoPlay_ShowImageEnabled( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsAutoPlay_ShowImageEnabled not implemented"));
   return 0;
}

/**
 * Method: blIsAutoPlay_CallEnabled
  * Call button Enabled on Auto Play Menu
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsAutoPlay_CallEnabled( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsAutoPlay_CallEnabled not implemented"));
   return 0;
}

/**
 * Method: blIsAutoPlay_ShowOnMapEnabled
  * Show On Map button Enabled on Auto Play Menu
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsAutoPlay_ShowOnMapEnabled( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsAutoPlay_ShowOnMapEnabled not implemented"));
   return 0;
}

/**
 * Method: blIsMessageHistoryAvailable
  * Provides info whether Message History should be available or not.
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsMessageHistoryAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsMessageHistoryAvailable not implemented"));
   return 0;
}

/**
 * Method: vReadSMS
  * This method is called when user selects READ when SMS is received 
  * NISSAN2.0
 */
void clHSA_TCU_Base::vReadSMS( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vReadSMS not implemented"));
   
}

/**
 * Method: vIgnoreSMS
  * This method is called when user selects IGNORE when SMS is received 
  * NISSAN2.0
 */
void clHSA_TCU_Base::vIgnoreSMS( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vIgnoreSMS not implemented"));
   
}

/**
 * Method: vToggleTestModeTCUAudio
  * This method is called to turn ON/OFF the TCU Audio Route
  * NISSAN2.0
 */
void clHSA_TCU_Base::vToggleTestModeTCUAudio( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vToggleTestModeTCUAudio not implemented"));
   
}

/**
 * Method: blGetDeveloperTestModeTCUAudioStatus
  * This method is called to set the TCU Audio status for GUI
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blGetDeveloperTestModeTCUAudioStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blGetDeveloperTestModeTCUAudioStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetDeveloperTestModeTCUServerListCount
  * This method is called to get the TCU server list count
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetDeveloperTestModeTCUServerListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetDeveloperTestModeTCUServerListCount not implemented"));
   return 0;
}

/**
 * Method: vGetDeveloperTestModeTCUServerList
  * This method is called to get the TCU Server names
  * NISSAN2.0
 */
void clHSA_TCU_Base::vGetDeveloperTestModeTCUServerList(GUI_String *out_result, ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetDeveloperTestModeTCUServerList not implemented"));
   
}

/**
 * Method: ulwGetDeveloperTestModeTCUServerListActiveIndex
  * This method is called to get active TCU server
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetDeveloperTestModeTCUServerListActiveIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetDeveloperTestModeTCUServerListActiveIndex not implemented"));
   return 0;
}

/**
 * Method: vSetDeveloperTestModeTCUServer
  * This method is called to set the TCU server for GUI
  * NISSAN2.0
 */
void clHSA_TCU_Base::vSetDeveloperTestModeTCUServer(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vSetDeveloperTestModeTCUServer not implemented"));
   
}

/**
 * Method: vPrepareDeveloperTestModeTCUServerlist
  * This method is called to prepare the TCU server for GUI
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareDeveloperTestModeTCUServerlist( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareDeveloperTestModeTCUServerlist not implemented"));
   
}

/**
 * Method: ulwAutoPlay_MenuOptionAvailable
  *  Button activated in Auto Play Menu Screen
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwAutoPlay_MenuOptionAvailable( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwAutoPlay_MenuOptionAvailable not implemented"));
   return 0;
}

/**
 * Method: vSetAutoPlayScreenID
  * This method is called to prepare the TCU server for GUI
  * NISSAN2.0
 */
void clHSA_TCU_Base::vSetAutoPlayScreenID(ulword ulwData)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwData);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vSetAutoPlayScreenID not implemented"));
   
}

/**
 * Method: vSetDriverUploadconfirmation
  * Set the status of the yes button to disbale
  * 
 */
void clHSA_TCU_Base::vSetDriverUploadconfirmation(tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vSetDriverUploadconfirmation not implemented"));
   
}

/**
 * Method: blGetDriverUploadConfirmation
  * Get the status of the yes button to disbale.
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blGetDriverUploadConfirmation( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blGetDriverUploadConfirmation not implemented"));
   return 0;
}

/**
 * Method: vPrepareInformationFolderList
  * This method is called to Prepare Information Folder List
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareInformationFolderList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareInformationFolderList not implemented"));
   
}

/**
 * Method: ulwGetInformationFolderListCount
  * Provides the number of entries for Information List.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetInformationFolderListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetInformationFolderListCount not implemented"));
   return 0;
}

/**
 * Method: vGetInformationFolderName
  * Returns name of folder at index
  * B
 */
void clHSA_TCU_Base::vGetInformationFolderName(GUI_String *out_result, ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetInformationFolderName not implemented"));
   
}

/**
 * Method: vPrepareInformationChannelList
  * This method is called to Prepare Information Channel List
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareInformationChannelList(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareInformationChannelList not implemented"));
   
}

/**
 * Method: ulwGetInformationChannelListCount
  * Provides the number of entries for Information Channel List.
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetInformationChannelListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetInformationChannelListCount not implemented"));
   return 0;
}

/**
 * Method: vGetInformationChannelName
  * Returns information about the Information Channel Name
  * B
 */
void clHSA_TCU_Base::vGetInformationChannelName(GUI_String *out_result, ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vGetInformationChannelName not implemented"));
   
}

/**
 * Method: vRequestMISChannelData
  * Get call when user select MIS channel, start download channel here.
  * NISSAN2.0
 */
void clHSA_TCU_Base::vRequestMISChannelData(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vRequestMISChannelData not implemented"));
   
}

/**
 * Method: vPrepareMISChannelInfo
  * This method is called to Prepare MIS Channel Info to show in auto play screen
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareMISChannelInfo(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareMISChannelInfo not implemented"));
   
}

/**
 * Method: vPrepareMSChannelMasterData
  * Prepare MS channel master data.
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareMSChannelMasterData( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareMSChannelMasterData not implemented"));
   
}

/**
 * Method: blIsMyScheduleCMDAvaiable
  * Check CMD belong to MS is available in database.
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsMyScheduleCMDAvaiable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsMyScheduleCMDAvaiable not implemented"));
   return 0;
}

/**
 * Method: vRequestMSChannelData
  * Get call when user select My Schedule menu, start download channel here.
  * NISSAN2.0
 */
void clHSA_TCU_Base::vRequestMSChannelData( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vRequestMSChannelData not implemented"));
   
}

/**
 * Method: vPrepareMSChannelInfo
  * This method is called to Prepare MS Channel Info to show in auto play screen
  * NISSAN2.0
 */
void clHSA_TCU_Base::vPrepareMSChannelInfo( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vPrepareMSChannelInfo not implemented"));
   
}

/**
 * Method: blIsOpenAutoPlayScreen
  * To be call from GUI, to know should open auto play screen or not.
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsOpenAutoPlayScreen( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsOpenAutoPlayScreen not implemented"));
   return 0;
}

/**
 * Method: vSetAutoplayContext
  * This method is called by GUI to set entrance context
  * NISSAN2.0
 */
void clHSA_TCU_Base::vSetAutoplayContext(ulword ulwData)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwData);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_TCU::vSetAutoplayContext not implemented"));
   
}

/**
 * Method: ulwGetAutoplayContext
  * Get call by GUI when go out of AutoPlay screen
  * NISSAN2.0
 */
ulword clHSA_TCU_Base::ulwGetAutoplayContext( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_TCU::ulwGetAutoplayContext not implemented"));
   return 0;
}

/**
 * Method: vDownloadAdditionalContents
  * This method is called when user selects YES to confirm download additional contents
  * NISSAN2.0
 */
void clHSA_TCU_Base::vDownloadAdditionalContents( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vDownloadAdditionalContents not implemented"));
   
}

/**
 * Method: vDiscardAdditionalContents
  * This method is called when user selects NO to discard additional contents
  * NISSAN2.0
 */
void clHSA_TCU_Base::vDiscardAdditionalContents( )
{
   
   ETG_TRACE_USR4(("function void clHSA_TCU::vDiscardAdditionalContents not implemented"));
   
}

/**
 * Method: blIsTCUConnected
  * This function use to check TCU connected status by GUI.
  * NISSAN2.0
 */
tbool clHSA_TCU_Base::blIsTCUConnected( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_TCU::blIsTCUConnected not implemented"));
   return 0;
}

