/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_TCU_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_TCU_Wrapper.h"
#include "clHSA_TCU_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_TCU_Trace.h"
#include "hmi_trace.h"

ulword HSA_TCU__ulwGetACNStatus( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_ACN_STATUS  ) ); 
        }
      ret=pInst->ulwGetACNStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_ACN_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_TCU__ulwGetECallStatus( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_E_CALL_STATUS  ) ); 
        }
      ret=pInst->ulwGetECallStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_E_CALL_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_TCU__ulwGetServiceCallStatus( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_SERVICE_CALL_STATUS  ) ); 
        }
      ret=pInst->ulwGetServiceCallStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_SERVICE_CALL_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_TCU__blIsTCU_Enabled( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_TCU__ENABLED  ) ); 
        }
      ret=pInst->blIsTCU_Enabled();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_TCU__ENABLED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vSyncAllInfoFeed( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SYNC_ALL_INFO_FEED  ) ); 
        }
      pInst->vSyncAllInfoFeed();

    }
}

void HSA_TCU__vToggleProbeInfo( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_PROBE_INFO  ) ); 
        }
      pInst->vToggleProbeInfo();

    }
}

void HSA_TCU__vProbeInfoSettingEntry( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PROBE_INFO_SETTING_ENTRY  ) ); 
        }
      pInst->vProbeInfoSettingEntry();

    }
}

tbool HSA_TCU__blGetProbeInfo( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_PROBE_INFO  ) ); 
        }
      ret=pInst->blGetProbeInfo();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_PROBE_INFO | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vDeleteSharedInfo( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__DELETE_SHARED_INFO  ) ); 
        }
      pInst->vDeleteSharedInfo();

    }
}

void HSA_TCU__vDeleteHistory( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__DELETE_HISTORY  ) ); 
        }
      pInst->vDeleteHistory();

    }
}

void HSA_TCU__vResetAllSettings( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__RESET_ALL_SETTINGS  ) ); 
        }
      pInst->vResetAllSettings();

    }
}

void HSA_TCU__vGetUnitId(GUI_String *out_result, ulword ulwUnitID)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_UNIT_ID | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwUnitID); 
        }
      pInst->vGetUnitId(out_result, ulwUnitID);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_UNIT_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_TCU__vStartServiceCall( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__START_SERVICE_CALL  ) ); 
        }
      pInst->vStartServiceCall();

    }
}

void HSA_TCU__vEndServiceCall( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__END_SERVICE_CALL  ) ); 
        }
      pInst->vEndServiceCall();

    }
}

void HSA_TCU__vSetDriverInfoUploadPermit(ulword ulwUploadPermitStatus)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SET_DRIVER_INFO_UPLOAD_PERMIT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwUploadPermitStatus); 
        }
      pInst->vSetDriverInfoUploadPermit(ulwUploadPermitStatus);

    }
}

void HSA_TCU__vSetDownloadPopupState(ulword ulwstatus)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SET_DOWNLOAD_POPUP_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwstatus); 
        }
      pInst->vSetDownloadPopupState(ulwstatus);

    }
}

ulword HSA_TCU__ulwGetDriverInfoUploadPermitStatus( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DRIVER_INFO_UPLOAD_PERMIT_STATUS  ) ); 
        }
      ret=pInst->ulwGetDriverInfoUploadPermitStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DRIVER_INFO_UPLOAD_PERMIT_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vRequestChannelData(ulword ulwChannelId, ulword ulwChannelContentsId)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__REQUEST_CHANNEL_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwChannelId); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__REQUEST_CHANNEL_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwChannelContentsId); 
        }
      pInst->vRequestChannelData(ulwChannelId, ulwChannelContentsId);

    }
}

void HSA_TCU__vCancelRequest(ulword ulwRequestType)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__CANCEL_REQUEST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRequestType); 
        }
      pInst->vCancelRequest(ulwRequestType);

    }
}

tbool HSA_TCU__blIsTCU_VoiceMenuAvailable( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_TCU__VOICE_MENU_AVAILABLE  ) ); 
        }
      ret=pInst->blIsTCU_VoiceMenuAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_TCU__VOICE_MENU_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_TCU__blIsTCU_ConnectedSearchAvailable( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_TCU__CONNECTED_SEARCH_AVAILABLE  ) ); 
        }
      ret=pInst->blIsTCU_ConnectedSearchAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_TCU__CONNECTED_SEARCH_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_TCU__blIsTCU_MobileInformationAvailable( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_TCU__MOBILE_INFORMATION_AVAILABLE  ) ); 
        }
      ret=pInst->blIsTCU_MobileInformationAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_TCU__MOBILE_INFORMATION_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_TCU__ulwGetVoiceMenuListCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_MENU_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetVoiceMenuListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_MENU_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGetVoiceMenuListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_MENU_LIST_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_MENU_LIST_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwData); 
        }
      pInst->vGetVoiceMenuListString(out_result, ulwIndex, ulwData);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_MENU_LIST_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_TCU__ulwGetVoiceMenuListValue(ulword ulwListIndex)
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_MENU_LIST_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      ret=pInst->ulwGetVoiceMenuListValue(ulwListIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_MENU_LIST_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vConnectedSearchRequest(const GUI_String * SearchString)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__CONNECTED_SEARCH_REQUEST | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)SearchString->ulwLen_+1, SearchString->pubBuffer_);
         }
      pInst->vConnectedSearchRequest( SearchString);

    }
}

void HSA_TCU__vPrepareConnectedSearchList( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_CONNECTED_SEARCH_LIST  ) ); 
        }
      pInst->vPrepareConnectedSearchList();

    }
}

ulword HSA_TCU__ulwGetConnectedSearchListCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_SEARCH_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetConnectedSearchListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_SEARCH_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGetConnectedSearchListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_SEARCH_LIST_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_SEARCH_LIST_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwData); 
        }
      pInst->vGetConnectedSearchListString(out_result, ulwIndex, ulwData);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_SEARCH_LIST_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_TCU__ulwGetConnectedSearchListValue(ulword ulwListIndex)
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_SEARCH_LIST_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      ret=pInst->ulwGetConnectedSearchListValue(ulwListIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_SEARCH_LIST_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vPrepareGoogleSendToCarList( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_GOOGLE_SEND_TO_CAR_LIST  ) ); 
        }
      pInst->vPrepareGoogleSendToCarList();

    }
}

ulword HSA_TCU__ulwGetGoogleSendToCarListCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_GOOGLE_SEND_TO_CAR_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetGoogleSendToCarListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_GOOGLE_SEND_TO_CAR_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGetGoogleSendToCarListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_GOOGLE_SEND_TO_CAR_LIST_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_GOOGLE_SEND_TO_CAR_LIST_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwData); 
        }
      pInst->vGetGoogleSendToCarListString(out_result, ulwIndex, ulwData);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_GOOGLE_SEND_TO_CAR_LIST_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_TCU__ulwGetGoogleSendToCarListValue(ulword ulwListIndex)
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_GOOGLE_SEND_TO_CAR_LIST_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      ret=pInst->ulwGetGoogleSendToCarListValue(ulwListIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_GOOGLE_SEND_TO_CAR_LIST_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGoogleSendToCarListUpdate( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GOOGLE_SEND_TO_CAR_LIST_UPDATE  ) ); 
        }
      pInst->vGoogleSendToCarListUpdate();

    }
}

void HSA_TCU__vPrepareDestinationSendToCarFolderList( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_DESTINATION_SEND_TO_CAR_FOLDER_LIST  ) ); 
        }
      pInst->vPrepareDestinationSendToCarFolderList();

    }
}

ulword HSA_TCU__ulwGetDestinationSendToCarFolderListCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_FOLDER_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetDestinationSendToCarFolderListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_FOLDER_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGetDestinationSendToCarFolderList(GUI_String *out_result, ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_FOLDER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vGetDestinationSendToCarFolderList(out_result, ulwListIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_FOLDER_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_TCU__vDestinationSendToCarChannelListUpdate(ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__DESTINATION_SEND_TO_CAR_CHANNEL_LIST_UPDATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vDestinationSendToCarChannelListUpdate(ulwListIndex);

    }
}

void HSA_TCU__vPrepareDestinationSendToCarChannelList(ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_DESTINATION_SEND_TO_CAR_CHANNEL_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vPrepareDestinationSendToCarChannelList(ulwListIndex);

    }
}

ulword HSA_TCU__ulwGetDestinationSendToCarChannelListCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_CHANNEL_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetDestinationSendToCarChannelListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_CHANNEL_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGetDestinationSendToCarChannelListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_CHANNEL_LIST_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_CHANNEL_LIST_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwData); 
        }
      pInst->vGetDestinationSendToCarChannelListString(out_result, ulwIndex, ulwData);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_CHANNEL_LIST_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_TCU__ulwGetDestinationSendToCarChannelListValue(ulword ulwListIndex)
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_CHANNEL_LIST_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      ret=pInst->ulwGetDestinationSendToCarChannelListValue(ulwListIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_CHANNEL_LIST_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vPrepareJourneyPlannerFolderList( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_JOURNEY_PLANNER_FOLDER_LIST  ) ); 
        }
      pInst->vPrepareJourneyPlannerFolderList();

    }
}

ulword HSA_TCU__ulwGetJourneyPlannerFolderListCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_JOURNEY_PLANNER_FOLDER_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetJourneyPlannerFolderListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_JOURNEY_PLANNER_FOLDER_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGetJourneyPlannerFolderList(GUI_String *out_result, ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_JOURNEY_PLANNER_FOLDER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vGetJourneyPlannerFolderList(out_result, ulwListIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_JOURNEY_PLANNER_FOLDER_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_TCU__vPrepareJourneyPlannerMessageList(ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_JOURNEY_PLANNER_MESSAGE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vPrepareJourneyPlannerMessageList(ulwListIndex);

    }
}

ulword HSA_TCU__ulwGetJourneyPlannerMessageListCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_JOURNEY_PLANNER_MESSAGE_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetJourneyPlannerMessageListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_JOURNEY_PLANNER_MESSAGE_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGetJourneyPlannerMessageList(GUI_String *out_result, ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_JOURNEY_PLANNER_MESSAGE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vGetJourneyPlannerMessageList(out_result, ulwListIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_JOURNEY_PLANNER_MESSAGE_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_TCU__vJourneyPlannerMessageListUpdate(ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__JOURNEY_PLANNER_MESSAGE_LIST_UPDATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vJourneyPlannerMessageListUpdate(ulwListIndex);

    }
}

void HSA_TCU__vPrepareJourneyPlannerPoiInfo(ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_JOURNEY_PLANNER_POI_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vPrepareJourneyPlannerPoiInfo(ulwListIndex);

    }
}

void HSA_TCU__vPrepareSpellerHistoryAvailability(const GUI_String * SearchString)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_SPELLER_HISTORY_AVAILABILITY | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)SearchString->ulwLen_+1, SearchString->pubBuffer_);
         }
      pInst->vPrepareSpellerHistoryAvailability( SearchString);

    }
}

ulword HSA_TCU__ulwIsSpellerHistoryAvailable( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_SPELLER_HISTORY_AVAILABLE  ) ); 
        }
      ret=pInst->ulwIsSpellerHistoryAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_SPELLER_HISTORY_AVAILABLE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vPrepareSpellerHistoryList(const GUI_String * SearchString)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_SPELLER_HISTORY_LIST | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)SearchString->ulwLen_+1, SearchString->pubBuffer_);
         }
      pInst->vPrepareSpellerHistoryList( SearchString);

    }
}

ulword HSA_TCU__ulwSpellerHistoryListCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_HISTORY_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwSpellerHistoryListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_HISTORY_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vSpellerHistoryList(GUI_String *out_result, ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_HISTORY_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vSpellerHistoryList(out_result, ulwListIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_HISTORY_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_TCU__vPrepareSpellerEntryField(const GUI_String * EntryFieldValue, ulword ulwSpeller)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_SPELLER_ENTRY_FIELD | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)EntryFieldValue->ulwLen_+1, EntryFieldValue->pubBuffer_);
             poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_SPELLER_ENTRY_FIELD | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSpeller); 
        }
      pInst->vPrepareSpellerEntryField( EntryFieldValue, ulwSpeller);

    }
}

void HSA_TCU__vSpellerSetMaxCharCount(slword slwCount)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_MAX_CHAR_COUNT | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwCount); 
        }
      pInst->vSpellerSetMaxCharCount(slwCount);

    }
}

tbool HSA_TCU__blSpellerInputOccurred( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INPUT_OCCURRED  ) ); 
        }
      ret=pInst->blSpellerInputOccurred();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INPUT_OCCURRED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vSpellerDiscardInput( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_DISCARD_INPUT  ) ); 
        }
      pInst->vSpellerDiscardInput();

    }
}

void HSA_TCU__vSpellerDiscardAllInput( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_DISCARD_ALL_INPUT  ) ); 
        }
      pInst->vSpellerDiscardAllInput();

    }
}

void HSA_TCU__vSpellerSetCharacter(const GUI_String * InputString)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_CHARACTER | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSpellerSetCharacter( InputString);

    }
}

void HSA_TCU__vGetSpellerEntryField(GUI_String *out_result)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_ENTRY_FIELD  ) ); 
        }
      pInst->vGetSpellerEntryField(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_ENTRY_FIELD | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_TCU__vSpellerGetLetterFunction(GUI_String *out_result)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_LETTER_FUNCTION  ) ); 
        }
      pInst->vSpellerGetLetterFunction(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_LETTER_FUNCTION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_TCU__ulwSpellerGetCursorPos( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS  ) ); 
        }
      ret=pInst->ulwSpellerGetCursorPos();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vPoiInfo(GUI_String *out_result, ulword ulwIndex, ulword ulwData)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__POI_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__POI_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwData); 
        }
      pInst->vPoiInfo(out_result, ulwIndex, ulwData);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__POI_INFO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_TCU__blIsPOINumberAvailable(ulword ulwIndex, ulword ulwData)
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_POI_NUMBER_AVAILABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_POI_NUMBER_AVAILABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwData); 
        }
      ret=pInst->blIsPOINumberAvailable(ulwIndex, ulwData);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_POI_NUMBER_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vPoiInfoInfoCallSelect(ulword ulwIndex, ulword ulwData)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__POI_INFO_INFO_CALL_SELECT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__POI_INFO_INFO_CALL_SELECT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwData); 
        }
      pInst->vPoiInfoInfoCallSelect(ulwIndex, ulwData);

    }
}

void HSA_TCU__vPoiInfoInfoMapSelect(ulword ulwIndex, ulword ulwData)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__POI_INFO_INFO_MAP_SELECT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__POI_INFO_INFO_MAP_SELECT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwData); 
        }
      pInst->vPoiInfoInfoMapSelect(ulwIndex, ulwData);

    }
}

void HSA_TCU__vPoiInfoInfoStartSelect(ulword ulwIndex, ulword ulwData)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__POI_INFO_INFO_START_SELECT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__POI_INFO_INFO_START_SELECT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwData); 
        }
      pInst->vPoiInfoInfoStartSelect(ulwIndex, ulwData);

    }
}

ulword HSA_TCU__ulwGetHeaderIcon( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_HEADER_ICON  ) ); 
        }
      ret=pInst->ulwGetHeaderIcon();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_HEADER_ICON | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_TCU__ulwWaitSyncState( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_STATE  ) ); 
        }
      ret=pInst->ulwWaitSyncState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vPrepareMessageHistoryChannelAvailability( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_MESSAGE_HISTORY_CHANNEL_AVAILABILITY  ) ); 
        }
      pInst->vPrepareMessageHistoryChannelAvailability();

    }
}

void HSA_TCU__vPrepareMessageHistoryChannelList( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_MESSAGE_HISTORY_CHANNEL_LIST  ) ); 
        }
      pInst->vPrepareMessageHistoryChannelList();

    }
}

ulword HSA_TCU__ulwGetMessageHistoryChannelListCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_MESSAGE_HISTORY_CHANNEL_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetMessageHistoryChannelListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_MESSAGE_HISTORY_CHANNEL_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGetMessageHistoryChannelList(GUI_String *out_result, ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_MESSAGE_HISTORY_CHANNEL_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vGetMessageHistoryChannelList(out_result, ulwListIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_MESSAGE_HISTORY_CHANNEL_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_TCU__vPrepareMessageHistoryAutoFeedInfo(ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_MESSAGE_HISTORY_AUTO_FEED_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vPrepareMessageHistoryAutoFeedInfo(ulwListIndex);

    }
}

ulword HSA_TCU__ulwGetAutoPlayCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_PLAY_COUNT  ) ); 
        }
      ret=pInst->ulwGetAutoPlayCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_PLAY_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_TCU__ulwGetCurrentAutoPlayIndex( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_AUTO_PLAY_INDEX  ) ); 
        }
      ret=pInst->ulwGetCurrentAutoPlayIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_AUTO_PLAY_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGetAutoPlayText(GUI_String *out_result)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_PLAY_TEXT  ) ); 
        }
      pInst->vGetAutoPlayText(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_PLAY_TEXT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_TCU__vGetAutoPlayTitle(GUI_String *out_result)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_PLAY_TITLE  ) ); 
        }
      pInst->vGetAutoPlayTitle(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_PLAY_TITLE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_TCU__vGetAutoPlayDynamicImageID(GUI_String *out_result)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_PLAY_DYNAMIC_IMAGE_ID  ) ); 
        }
      pInst->vGetAutoPlayDynamicImageID(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_PLAY_DYNAMIC_IMAGE_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_TCU__vAutoPlayNextKeyLongPress( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__AUTO_PLAY_NEXT_KEY_LONG_PRESS  ) ); 
        }
      pInst->vAutoPlayNextKeyLongPress();

    }
}

void HSA_TCU__vAutoPlayNextKeyShortPress( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__AUTO_PLAY_NEXT_KEY_SHORT_PRESS  ) ); 
        }
      pInst->vAutoPlayNextKeyShortPress();

    }
}

void HSA_TCU__vAutoPlayPreviousKeyLongPress( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__AUTO_PLAY_PREVIOUS_KEY_LONG_PRESS  ) ); 
        }
      pInst->vAutoPlayPreviousKeyLongPress();

    }
}

void HSA_TCU__vAutoPlayPreviousKeyShortPress( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__AUTO_PLAY_PREVIOUS_KEY_SHORT_PRESS  ) ); 
        }
      pInst->vAutoPlayPreviousKeyShortPress();

    }
}

void HSA_TCU__vAutoPlay_TTSAbort( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__AUTO_PLAY_TTS_ABORT  ) ); 
        }
      pInst->vAutoPlay_TTSAbort();

    }
}

void HSA_TCU__vAutoPlay_TTSStart(ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__AUTO_PLAY_TTS_START | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vAutoPlay_TTSStart(ulwListIndex);

    }
}

void HSA_TCU__vAutoPlay_Play( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__AUTO_PLAY__PLAY  ) ); 
        }
      pInst->vAutoPlay_Play();

    }
}

ulword HSA_TCU__ulwGetAutoPlay_Screen( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_PLAY__SCREEN  ) ); 
        }
      ret=pInst->ulwGetAutoPlay_Screen();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_PLAY__SCREEN | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_TCU__blIsAutoPlay_ShowDetailsAvailable( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__SHOW_DETAILS_AVAILABLE  ) ); 
        }
      ret=pInst->blIsAutoPlay_ShowDetailsAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__SHOW_DETAILS_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_TCU__blIsAutoPlay_DeleteAvailable( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__DELETE_AVAILABLE  ) ); 
        }
      ret=pInst->blIsAutoPlay_DeleteAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__DELETE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vAutoPlay_Delete(ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__AUTO_PLAY__DELETE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vAutoPlay_Delete(ulwListIndex);

    }
}

tbool HSA_TCU__blIsAutoPlay_PlayEnabled( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__PLAY_ENABLED  ) ); 
        }
      ret=pInst->blIsAutoPlay_PlayEnabled();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__PLAY_ENABLED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_TCU__blIsAutoPlay_GoHereEnabled( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__GO_HERE_ENABLED  ) ); 
        }
      ret=pInst->blIsAutoPlay_GoHereEnabled();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__GO_HERE_ENABLED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_TCU__blIsAutoPlay_ShowImageEnabled( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__SHOW_IMAGE_ENABLED  ) ); 
        }
      ret=pInst->blIsAutoPlay_ShowImageEnabled();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__SHOW_IMAGE_ENABLED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_TCU__blIsAutoPlay_CallEnabled( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__CALL_ENABLED  ) ); 
        }
      ret=pInst->blIsAutoPlay_CallEnabled();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__CALL_ENABLED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_TCU__blIsAutoPlay_ShowOnMapEnabled( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__SHOW_ON_MAP_ENABLED  ) ); 
        }
      ret=pInst->blIsAutoPlay_ShowOnMapEnabled();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_AUTO_PLAY__SHOW_ON_MAP_ENABLED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_TCU__blIsMessageHistoryAvailable( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_MESSAGE_HISTORY_AVAILABLE  ) ); 
        }
      ret=pInst->blIsMessageHistoryAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_MESSAGE_HISTORY_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vReadSMS( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__READ_SMS  ) ); 
        }
      pInst->vReadSMS();

    }
}

void HSA_TCU__vIgnoreSMS( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IGNORE_SMS  ) ); 
        }
      pInst->vIgnoreSMS();

    }
}

void HSA_TCU__vToggleTestModeTCUAudio( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_TEST_MODE_TCU_AUDIO  ) ); 
        }
      pInst->vToggleTestModeTCUAudio();

    }
}

tbool HSA_TCU__blGetDeveloperTestModeTCUAudioStatus( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DEVELOPER_TEST_MODE_TCU_AUDIO_STATUS  ) ); 
        }
      ret=pInst->blGetDeveloperTestModeTCUAudioStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DEVELOPER_TEST_MODE_TCU_AUDIO_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_TCU__ulwGetDeveloperTestModeTCUServerListCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DEVELOPER_TEST_MODE_TCU_SERVER_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetDeveloperTestModeTCUServerListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DEVELOPER_TEST_MODE_TCU_SERVER_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGetDeveloperTestModeTCUServerList(GUI_String *out_result, ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DEVELOPER_TEST_MODE_TCU_SERVER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vGetDeveloperTestModeTCUServerList(out_result, ulwListIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DEVELOPER_TEST_MODE_TCU_SERVER_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_TCU__ulwGetDeveloperTestModeTCUServerListActiveIndex( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DEVELOPER_TEST_MODE_TCU_SERVER_LIST_ACTIVE_INDEX  ) ); 
        }
      ret=pInst->ulwGetDeveloperTestModeTCUServerListActiveIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DEVELOPER_TEST_MODE_TCU_SERVER_LIST_ACTIVE_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vSetDeveloperTestModeTCUServer(ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SET_DEVELOPER_TEST_MODE_TCU_SERVER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vSetDeveloperTestModeTCUServer(ulwListIndex);

    }
}

void HSA_TCU__vPrepareDeveloperTestModeTCUServerlist( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_DEVELOPER_TEST_MODE_TCU_SERVERLIST  ) ); 
        }
      pInst->vPrepareDeveloperTestModeTCUServerlist();

    }
}

ulword HSA_TCU__ulwAutoPlay_MenuOptionAvailable( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__AUTO_PLAY__MENU_OPTION_AVAILABLE  ) ); 
        }
      ret=pInst->ulwAutoPlay_MenuOptionAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__AUTO_PLAY__MENU_OPTION_AVAILABLE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vSetAutoPlayScreenID(ulword ulwData)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SET_AUTO_PLAY_SCREEN_ID | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwData); 
        }
      pInst->vSetAutoPlayScreenID(ulwData);

    }
}

void HSA_TCU__vSetDriverUploadconfirmation(tbool blMode)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SET_DRIVER_UPLOADCONFIRMATION | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vSetDriverUploadconfirmation(blMode);

    }
}

tbool HSA_TCU__blGetDriverUploadConfirmation( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DRIVER_UPLOAD_CONFIRMATION  ) ); 
        }
      ret=pInst->blGetDriverUploadConfirmation();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_DRIVER_UPLOAD_CONFIRMATION | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vPrepareInformationFolderList( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_INFORMATION_FOLDER_LIST  ) ); 
        }
      pInst->vPrepareInformationFolderList();

    }
}

ulword HSA_TCU__ulwGetInformationFolderListCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_INFORMATION_FOLDER_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetInformationFolderListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_INFORMATION_FOLDER_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGetInformationFolderName(GUI_String *out_result, ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_INFORMATION_FOLDER_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vGetInformationFolderName(out_result, ulwListIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_INFORMATION_FOLDER_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_TCU__vPrepareInformationChannelList(ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_INFORMATION_CHANNEL_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vPrepareInformationChannelList(ulwListIndex);

    }
}

ulword HSA_TCU__ulwGetInformationChannelListCount( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_INFORMATION_CHANNEL_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetInformationChannelListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_INFORMATION_CHANNEL_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vGetInformationChannelName(GUI_String *out_result, ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_INFORMATION_CHANNEL_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vGetInformationChannelName(out_result, ulwListIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_INFORMATION_CHANNEL_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_TCU__vRequestMISChannelData(ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__REQUEST_MIS_CHANNEL_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vRequestMISChannelData(ulwListIndex);

    }
}

void HSA_TCU__vPrepareMISChannelInfo(ulword ulwListIndex)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_MIS_CHANNEL_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vPrepareMISChannelInfo(ulwListIndex);

    }
}

void HSA_TCU__vPrepareMSChannelMasterData( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_MS_CHANNEL_MASTER_DATA  ) ); 
        }
      pInst->vPrepareMSChannelMasterData();

    }
}

tbool HSA_TCU__blIsMyScheduleCMDAvaiable( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_MY_SCHEDULE_CMD_AVAIABLE  ) ); 
        }
      ret=pInst->blIsMyScheduleCMDAvaiable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_MY_SCHEDULE_CMD_AVAIABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vRequestMSChannelData( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__REQUEST_MS_CHANNEL_DATA  ) ); 
        }
      pInst->vRequestMSChannelData();

    }
}

void HSA_TCU__vPrepareMSChannelInfo( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__PREPARE_MS_CHANNEL_INFO  ) ); 
        }
      pInst->vPrepareMSChannelInfo();

    }
}

tbool HSA_TCU__blIsOpenAutoPlayScreen( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_OPEN_AUTO_PLAY_SCREEN  ) ); 
        }
      ret=pInst->blIsOpenAutoPlayScreen();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_OPEN_AUTO_PLAY_SCREEN | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vSetAutoplayContext(ulword ulwData)
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__SET_AUTOPLAY_CONTEXT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwData); 
        }
      pInst->vSetAutoplayContext(ulwData);

    }
}

ulword HSA_TCU__ulwGetAutoplayContext( )
{
    ulword ret = 0;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_AUTOPLAY_CONTEXT  ) ); 
        }
      ret=pInst->ulwGetAutoplayContext();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__GET_AUTOPLAY_CONTEXT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_TCU__vDownloadAdditionalContents( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__DOWNLOAD_ADDITIONAL_CONTENTS  ) ); 
        }
      pInst->vDownloadAdditionalContents();

    }
}

void HSA_TCU__vDiscardAdditionalContents( )
{
    
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__DISCARD_ADDITIONAL_CONTENTS  ) ); 
        }
      pInst->vDiscardAdditionalContents();

    }
}

tbool HSA_TCU__blIsTCUConnected( )
{
    tbool ret = false;
    clHSA_TCU_Base *pInst=clHSA_TCU_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_TCU_CONNECTED  ) ); 
        }
      ret=pInst->blIsTCUConnected();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TCU), (tU16)(HSA_API_ENTRYPOINT__IS_TCU_CONNECTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

#ifdef __cplusplus
}
#endif

