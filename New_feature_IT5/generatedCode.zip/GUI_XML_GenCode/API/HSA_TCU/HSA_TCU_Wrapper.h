/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_TCU_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_TCU_Wrapper_H
#define _HSA_TCU_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: GetACNStatus
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetACNStatus( void);

/**
 * Function: GetECallStatus
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetECallStatus( void);

/**
 * Function: GetServiceCallStatus
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetServiceCallStatus( void);

/**
 * Function: IsTCU_Enabled
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsTCU_Enabled( void);

/**
 * Function: SyncAllInfoFeed
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vSyncAllInfoFeed( void);

/**
 * Function: ToggleProbeInfo
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vToggleProbeInfo( void);

/**
 * Function: ProbeInfoSettingEntry
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vProbeInfoSettingEntry( void);

/**
 * Function: GetProbeInfo
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blGetProbeInfo( void);

/**
 * Function: DeleteSharedInfo
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vDeleteSharedInfo( void);

/**
 * Function: DeleteHistory
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vDeleteHistory( void);

/**
 * Function: ResetAllSettings
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vResetAllSettings( void);

/**
 * Function: GetUnitId
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vGetUnitId(GUI_String *out_result, ulword ulwUnitID);

/**
 * Function: StartServiceCall
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vStartServiceCall( void);

/**
 * Function: EndServiceCall
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vEndServiceCall( void);

/**
 * Function: SetDriverInfoUploadPermit
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vSetDriverInfoUploadPermit(ulword ulwUploadPermitStatus);

/**
 * Function: SetDownloadPopupState
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vSetDownloadPopupState(ulword ulwstatus);

/**
 * Function: GetDriverInfoUploadPermitStatus
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetDriverInfoUploadPermitStatus( void);

/**
 * Function: RequestChannelData
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vRequestChannelData(ulword ulwChannelId, ulword ulwChannelContentsId);

/**
 * Function: CancelRequest
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vCancelRequest(ulword ulwRequestType);

/**
 * Function: IsTCU_VoiceMenuAvailable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsTCU_VoiceMenuAvailable( void);

/**
 * Function: IsTCU_ConnectedSearchAvailable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsTCU_ConnectedSearchAvailable( void);

/**
 * Function: IsTCU_MobileInformationAvailable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsTCU_MobileInformationAvailable( void);

/**
 * Function: GetVoiceMenuListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetVoiceMenuListCount( void);

/**
 * Function: GetVoiceMenuListString
 * B
 * NISSAN
 */
void HSA_TCU__vGetVoiceMenuListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData);

/**
 * Function: GetVoiceMenuListValue
 * B
 * NISSAN
 */
ulword HSA_TCU__ulwGetVoiceMenuListValue(ulword ulwListIndex);

/**
 * Function: ConnectedSearchRequest
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vConnectedSearchRequest(const GUI_String * SearchString);

/**
 * Function: PrepareConnectedSearchList
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareConnectedSearchList( void);

/**
 * Function: GetConnectedSearchListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetConnectedSearchListCount( void);

/**
 * Function: GetConnectedSearchListString
 * B
 * NISSAN
 */
void HSA_TCU__vGetConnectedSearchListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData);

/**
 * Function: GetConnectedSearchListValue
 * B
 * NISSAN
 */
ulword HSA_TCU__ulwGetConnectedSearchListValue(ulword ulwListIndex);

/**
 * Function: PrepareGoogleSendToCarList
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareGoogleSendToCarList( void);

/**
 * Function: GetGoogleSendToCarListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetGoogleSendToCarListCount( void);

/**
 * Function: GetGoogleSendToCarListString
 * B
 * NISSAN
 */
void HSA_TCU__vGetGoogleSendToCarListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData);

/**
 * Function: GetGoogleSendToCarListValue
 * B
 * NISSAN
 */
ulword HSA_TCU__ulwGetGoogleSendToCarListValue(ulword ulwListIndex);

/**
 * Function: GoogleSendToCarListUpdate
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vGoogleSendToCarListUpdate( void);

/**
 * Function: PrepareDestinationSendToCarFolderList
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareDestinationSendToCarFolderList( void);

/**
 * Function: GetDestinationSendToCarFolderListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetDestinationSendToCarFolderListCount( void);

/**
 * Function: GetDestinationSendToCarFolderList
 * B
 * NISSAN
 */
void HSA_TCU__vGetDestinationSendToCarFolderList(GUI_String *out_result, ulword ulwListIndex);

/**
 * Function: DestinationSendToCarChannelListUpdate
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vDestinationSendToCarChannelListUpdate(ulword ulwListIndex);

/**
 * Function: PrepareDestinationSendToCarChannelList
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareDestinationSendToCarChannelList(ulword ulwListIndex);

/**
 * Function: GetDestinationSendToCarChannelListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetDestinationSendToCarChannelListCount( void);

/**
 * Function: GetDestinationSendToCarChannelListString
 * B
 * NISSAN
 */
void HSA_TCU__vGetDestinationSendToCarChannelListString(GUI_String *out_result, ulword ulwIndex, ulword ulwData);

/**
 * Function: GetDestinationSendToCarChannelListValue
 * B
 * NISSAN
 */
ulword HSA_TCU__ulwGetDestinationSendToCarChannelListValue(ulword ulwListIndex);

/**
 * Function: PrepareJourneyPlannerFolderList
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareJourneyPlannerFolderList( void);

/**
 * Function: GetJourneyPlannerFolderListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetJourneyPlannerFolderListCount( void);

/**
 * Function: GetJourneyPlannerFolderList
 * B
 * NISSAN
 */
void HSA_TCU__vGetJourneyPlannerFolderList(GUI_String *out_result, ulword ulwListIndex);

/**
 * Function: PrepareJourneyPlannerMessageList
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareJourneyPlannerMessageList(ulword ulwListIndex);

/**
 * Function: GetJourneyPlannerMessageListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetJourneyPlannerMessageListCount( void);

/**
 * Function: GetJourneyPlannerMessageList
 * B
 * NISSAN
 */
void HSA_TCU__vGetJourneyPlannerMessageList(GUI_String *out_result, ulword ulwListIndex);

/**
 * Function: JourneyPlannerMessageListUpdate
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vJourneyPlannerMessageListUpdate(ulword ulwListIndex);

/**
 * Function: PrepareJourneyPlannerPoiInfo
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareJourneyPlannerPoiInfo(ulword ulwListIndex);

/**
 * Function: PrepareSpellerHistoryAvailability
 * B
 * NISSAN
 */
void HSA_TCU__vPrepareSpellerHistoryAvailability(const GUI_String * SearchString);

/**
 * Function: IsSpellerHistoryAvailable
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwIsSpellerHistoryAvailable( void);

/**
 * Function: PrepareSpellerHistoryList
 * B
 * NISSAN
 */
void HSA_TCU__vPrepareSpellerHistoryList(const GUI_String * SearchString);

/**
 * Function: SpellerHistoryListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwSpellerHistoryListCount( void);

/**
 * Function: SpellerHistoryList
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vSpellerHistoryList(GUI_String *out_result, ulword ulwListIndex);

/**
 * Function: PrepareSpellerEntryField
 * B1Plus
 * NISSAN
 */
void HSA_TCU__vPrepareSpellerEntryField(const GUI_String * EntryFieldValue, ulword ulwSpeller);

/**
 * Function: SpellerSetMaxCharCount
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vSpellerSetMaxCharCount(slword slwCount);

/**
 * Function: SpellerInputOccurred
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blSpellerInputOccurred( void);

/**
 * Function: SpellerDiscardInput
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vSpellerDiscardInput( void);

/**
 * Function: SpellerDiscardAllInput
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vSpellerDiscardAllInput( void);

/**
 * Function: SpellerSetCharacter
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vSpellerSetCharacter(const GUI_String * InputString);

/**
 * Function: GetSpellerEntryField
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vGetSpellerEntryField(GUI_String *out_result);

/**
 * Function: SpellerGetLetterFunction
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vSpellerGetLetterFunction(GUI_String *out_result);

/**
 * Function: SpellerGetCursorPos
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwSpellerGetCursorPos( void);

/**
 * Function: PoiInfo
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPoiInfo(GUI_String *out_result, ulword ulwIndex, ulword ulwData);

/**
 * Function: IsPOINumberAvailable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsPOINumberAvailable(ulword ulwIndex, ulword ulwData);

/**
 * Function: PoiInfoInfoCallSelect
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPoiInfoInfoCallSelect(ulword ulwIndex, ulword ulwData);

/**
 * Function: PoiInfoInfoMapSelect
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPoiInfoInfoMapSelect(ulword ulwIndex, ulword ulwData);

/**
 * Function: PoiInfoInfoStartSelect
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPoiInfoInfoStartSelect(ulword ulwIndex, ulword ulwData);

/**
 * Function: GetHeaderIcon
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetHeaderIcon( void);

/**
 * Function: WaitSyncState
 * B1 - New Parameter for B
 * NISSAN
 */
ulword HSA_TCU__ulwWaitSyncState( void);

/**
 * Function: PrepareMessageHistoryChannelAvailability
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareMessageHistoryChannelAvailability( void);

/**
 * Function: PrepareMessageHistoryChannelList
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareMessageHistoryChannelList( void);

/**
 * Function: GetMessageHistoryChannelListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetMessageHistoryChannelListCount( void);

/**
 * Function: GetMessageHistoryChannelList
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vGetMessageHistoryChannelList(GUI_String *out_result, ulword ulwListIndex);

/**
 * Function: PrepareMessageHistoryAutoFeedInfo
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareMessageHistoryAutoFeedInfo(ulword ulwListIndex);

/**
 * Function: GetAutoPlayCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetAutoPlayCount( void);

/**
 * Function: GetCurrentAutoPlayIndex
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetCurrentAutoPlayIndex( void);

/**
 * Function: GetAutoPlayText
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vGetAutoPlayText(GUI_String *out_result);

/**
 * Function: GetAutoPlayTitle
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vGetAutoPlayTitle(GUI_String *out_result);

/**
 * Function: GetAutoPlayDynamicImageID
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vGetAutoPlayDynamicImageID(GUI_String *out_result);

/**
 * Function: AutoPlayNextKeyLongPress
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vAutoPlayNextKeyLongPress( void);

/**
 * Function: AutoPlayNextKeyShortPress
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vAutoPlayNextKeyShortPress( void);

/**
 * Function: AutoPlayPreviousKeyLongPress
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vAutoPlayPreviousKeyLongPress( void);

/**
 * Function: AutoPlayPreviousKeyShortPress
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vAutoPlayPreviousKeyShortPress( void);

/**
 * Function: AutoPlay_TTSAbort
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vAutoPlay_TTSAbort( void);

/**
 * Function: AutoPlay_TTSStart
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vAutoPlay_TTSStart(ulword ulwListIndex);

/**
 * Function: AutoPlay_Play
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vAutoPlay_Play( void);

/**
 * Function: GetAutoPlay_Screen
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetAutoPlay_Screen( void);

/**
 * Function: IsAutoPlay_ShowDetailsAvailable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsAutoPlay_ShowDetailsAvailable( void);

/**
 * Function: IsAutoPlay_DeleteAvailable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsAutoPlay_DeleteAvailable( void);

/**
 * Function: AutoPlay_Delete
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vAutoPlay_Delete(ulword ulwListIndex);

/**
 * Function: IsAutoPlay_PlayEnabled
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsAutoPlay_PlayEnabled( void);

/**
 * Function: IsAutoPlay_GoHereEnabled
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsAutoPlay_GoHereEnabled( void);

/**
 * Function: IsAutoPlay_ShowImageEnabled
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsAutoPlay_ShowImageEnabled( void);

/**
 * Function: IsAutoPlay_CallEnabled
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsAutoPlay_CallEnabled( void);

/**
 * Function: IsAutoPlay_ShowOnMapEnabled
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsAutoPlay_ShowOnMapEnabled( void);

/**
 * Function: IsMessageHistoryAvailable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsMessageHistoryAvailable( void);

/**
 * Function: ReadSMS
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vReadSMS( void);

/**
 * Function: IgnoreSMS
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vIgnoreSMS( void);

/**
 * Function: ToggleTestModeTCUAudio
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vToggleTestModeTCUAudio( void);

/**
 * Function: GetDeveloperTestModeTCUAudioStatus
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blGetDeveloperTestModeTCUAudioStatus( void);

/**
 * Function: GetDeveloperTestModeTCUServerListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetDeveloperTestModeTCUServerListCount( void);

/**
 * Function: GetDeveloperTestModeTCUServerList
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vGetDeveloperTestModeTCUServerList(GUI_String *out_result, ulword ulwListIndex);

/**
 * Function: GetDeveloperTestModeTCUServerListActiveIndex
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetDeveloperTestModeTCUServerListActiveIndex( void);

/**
 * Function: SetDeveloperTestModeTCUServer
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vSetDeveloperTestModeTCUServer(ulword ulwListIndex);

/**
 * Function: PrepareDeveloperTestModeTCUServerlist
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareDeveloperTestModeTCUServerlist( void);

/**
 * Function: AutoPlay_MenuOptionAvailable
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwAutoPlay_MenuOptionAvailable( void);

/**
 * Function: SetAutoPlayScreenID
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vSetAutoPlayScreenID(ulword ulwData);

/**
 * Function: SetDriverUploadconfirmation
 * 
 * NISSAN
 */
void HSA_TCU__vSetDriverUploadconfirmation(tbool blMode);

/**
 * Function: GetDriverUploadConfirmation
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blGetDriverUploadConfirmation( void);

/**
 * Function: PrepareInformationFolderList
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareInformationFolderList( void);

/**
 * Function: GetInformationFolderListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetInformationFolderListCount( void);

/**
 * Function: GetInformationFolderName
 * B
 * NISSAN
 */
void HSA_TCU__vGetInformationFolderName(GUI_String *out_result, ulword ulwListIndex);

/**
 * Function: PrepareInformationChannelList
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareInformationChannelList(ulword ulwListIndex);

/**
 * Function: GetInformationChannelListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetInformationChannelListCount( void);

/**
 * Function: GetInformationChannelName
 * B
 * NISSAN
 */
void HSA_TCU__vGetInformationChannelName(GUI_String *out_result, ulword ulwListIndex);

/**
 * Function: RequestMISChannelData
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vRequestMISChannelData(ulword ulwListIndex);

/**
 * Function: PrepareMISChannelInfo
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareMISChannelInfo(ulword ulwListIndex);

/**
 * Function: PrepareMSChannelMasterData
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareMSChannelMasterData( void);

/**
 * Function: IsMyScheduleCMDAvaiable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsMyScheduleCMDAvaiable( void);

/**
 * Function: RequestMSChannelData
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vRequestMSChannelData( void);

/**
 * Function: PrepareMSChannelInfo
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vPrepareMSChannelInfo( void);

/**
 * Function: IsOpenAutoPlayScreen
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsOpenAutoPlayScreen( void);

/**
 * Function: SetAutoplayContext
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vSetAutoplayContext(ulword ulwData);

/**
 * Function: GetAutoplayContext
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_TCU__ulwGetAutoplayContext( void);

/**
 * Function: DownloadAdditionalContents
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vDownloadAdditionalContents( void);

/**
 * Function: DiscardAdditionalContents
 * NISSAN2.0
 * NISSAN
 */
void HSA_TCU__vDiscardAdditionalContents( void);

/**
 * Function: IsTCUConnected
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_TCU__blIsTCUConnected( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_TCU_H

