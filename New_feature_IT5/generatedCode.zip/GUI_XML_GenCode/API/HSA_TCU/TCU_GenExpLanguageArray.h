/*Exported Language Array from the model - TCU*/
/*  This file has been generated on 05.12.2014 16:38 */
/*
 *  This file contains the definition of exported language content.
 *  The String lists with the translation that are to be exported
 *  from the model are listed here in the array structure
 *  
 *  Please note that:
 *    - Translations are provided in the following language order
 *    - English US
 *    - French CAN
 *    - Spanish Standard Latin
 *    - Dutch
 *    - German
 *    - Italian
 *    - Portuguese
 *    - Russian
 *    - Turkish
 *    - English UK
 *    - French
 *    - Spanish
 *    - Danish
 *    - Swedish
 *    - Finnish
 *    - Norwegian
 *    - Polish
 *    - Slovak
 *    - Czech
 *    - Hungarian
 *    - Greek
 *    - Brazilian
 *    - Arabic
 *    - Thai
 *    - Australian
 *
 *    This list is the same as used in the Model
 *
 *  The following macros are used:
 *
 *    CONTENT_LANGUAGE_COUNT(LanguageCount)
 *       Provides the count value to indicate the number of translations
 *    CONTENT_LANGUAGE_ARRAY(DeviceName) 
 *       Provides the start of the Array with Device name to which the 
 *       array belongs
 *    CONTENT_INDEX_START(Index Value)
 *       mark the start of Each string followed by the array of
 *       translations
 *    CONTENT_LANGUAGE(ContentID)
 *       provides the content ID for the translated string
 *    CONTENT_INDEX_END
 *       marks the end of Each string translation set
 *    CONTENT_END(value)
 *       End of the complete array
 *
 */


CONTENT_BEGIN()
#ifndef CONTENT_EXP_LANGUAGE_COUNT
   #define CONTENT_EXP_LANGUAGE_COUNT       25
#endif // #ifndef CONTENT_EXP_LANGUAGE_COUNT
CONTENT_LANGUAGE_ARRAY(TCU)

CONTENT_END()
