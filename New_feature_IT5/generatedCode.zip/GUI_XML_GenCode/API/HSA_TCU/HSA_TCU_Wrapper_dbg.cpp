/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_TCU_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_TCU_Wrapper_dbg.h"
#include "clHSA_TCU_Base.h"
#include "HSA_TCU_Trace.h"
#include "HSA_TCU_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_TCU_Wrapper_dbg::~clHSA_TCU_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_TCU_Wrapper_dbg::clHSA_TCU_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_TCU_Wrapper_dbg::clHSA_TCU_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_TCU_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_TCU_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__GET_ACN_STATUS:

            HSA_TCU__ulwGetACNStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_E_CALL_STATUS:

            HSA_TCU__ulwGetECallStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_SERVICE_CALL_STATUS:

            HSA_TCU__ulwGetServiceCallStatus();
            break;

        case HSA_API_ENTRYPOINT__IS_TCU__ENABLED:

            HSA_TCU__blIsTCU_Enabled();
            break;

        case HSA_API_ENTRYPOINT__SYNC_ALL_INFO_FEED:

            HSA_TCU__vSyncAllInfoFeed();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_PROBE_INFO:

            HSA_TCU__vToggleProbeInfo();
            break;

        case HSA_API_ENTRYPOINT__PROBE_INFO_SETTING_ENTRY:

            HSA_TCU__vProbeInfoSettingEntry();
            break;

        case HSA_API_ENTRYPOINT__GET_PROBE_INFO:

            HSA_TCU__blGetProbeInfo();
            break;

        case HSA_API_ENTRYPOINT__DELETE_SHARED_INFO:

            HSA_TCU__vDeleteSharedInfo();
            break;

        case HSA_API_ENTRYPOINT__DELETE_HISTORY:

            HSA_TCU__vDeleteHistory();
            break;

        case HSA_API_ENTRYPOINT__RESET_ALL_SETTINGS:

            HSA_TCU__vResetAllSettings();
            break;

        case HSA_API_ENTRYPOINT__GET_UNIT_ID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vGetUnitId(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__START_SERVICE_CALL:

            HSA_TCU__vStartServiceCall();
            break;

        case HSA_API_ENTRYPOINT__END_SERVICE_CALL:

            HSA_TCU__vEndServiceCall();
            break;

        case HSA_API_ENTRYPOINT__SET_DRIVER_INFO_UPLOAD_PERMIT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vSetDriverInfoUploadPermit(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DOWNLOAD_POPUP_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vSetDownloadPopupState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DRIVER_INFO_UPLOAD_PERMIT_STATUS:

            HSA_TCU__ulwGetDriverInfoUploadPermitStatus();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_CHANNEL_DATA:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vRequestChannelData(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__CANCEL_REQUEST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vCancelRequest(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_TCU__VOICE_MENU_AVAILABLE:

            HSA_TCU__blIsTCU_VoiceMenuAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_TCU__CONNECTED_SEARCH_AVAILABLE:

            HSA_TCU__blIsTCU_ConnectedSearchAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_TCU__MOBILE_INFORMATION_AVAILABLE:

            HSA_TCU__blIsTCU_MobileInformationAvailable();
            break;

        case HSA_API_ENTRYPOINT__GET_VOICE_MENU_LIST_COUNT:

            HSA_TCU__ulwGetVoiceMenuListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_VOICE_MENU_LIST_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_TCU__vGetVoiceMenuListString(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_VOICE_MENU_LIST_VALUE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__ulwGetVoiceMenuListValue(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__CONNECTED_SEARCH_REQUEST:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_TCU__vConnectedSearchRequest(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_CONNECTED_SEARCH_LIST:

            HSA_TCU__vPrepareConnectedSearchList();
            break;

        case HSA_API_ENTRYPOINT__GET_CONNECTED_SEARCH_LIST_COUNT:

            HSA_TCU__ulwGetConnectedSearchListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_CONNECTED_SEARCH_LIST_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_TCU__vGetConnectedSearchListString(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_CONNECTED_SEARCH_LIST_VALUE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__ulwGetConnectedSearchListValue(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_GOOGLE_SEND_TO_CAR_LIST:

            HSA_TCU__vPrepareGoogleSendToCarList();
            break;

        case HSA_API_ENTRYPOINT__GET_GOOGLE_SEND_TO_CAR_LIST_COUNT:

            HSA_TCU__ulwGetGoogleSendToCarListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_GOOGLE_SEND_TO_CAR_LIST_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_TCU__vGetGoogleSendToCarListString(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_GOOGLE_SEND_TO_CAR_LIST_VALUE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__ulwGetGoogleSendToCarListValue(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GOOGLE_SEND_TO_CAR_LIST_UPDATE:

            HSA_TCU__vGoogleSendToCarListUpdate();
            break;

        case HSA_API_ENTRYPOINT__PREPARE_DESTINATION_SEND_TO_CAR_FOLDER_LIST:

            HSA_TCU__vPrepareDestinationSendToCarFolderList();
            break;

        case HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_FOLDER_LIST_COUNT:

            HSA_TCU__ulwGetDestinationSendToCarFolderListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_FOLDER_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vGetDestinationSendToCarFolderList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__DESTINATION_SEND_TO_CAR_CHANNEL_LIST_UPDATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vDestinationSendToCarChannelListUpdate(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_DESTINATION_SEND_TO_CAR_CHANNEL_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vPrepareDestinationSendToCarChannelList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_CHANNEL_LIST_COUNT:

            HSA_TCU__ulwGetDestinationSendToCarChannelListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_CHANNEL_LIST_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_TCU__vGetDestinationSendToCarChannelListString(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_DESTINATION_SEND_TO_CAR_CHANNEL_LIST_VALUE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__ulwGetDestinationSendToCarChannelListValue(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_JOURNEY_PLANNER_FOLDER_LIST:

            HSA_TCU__vPrepareJourneyPlannerFolderList();
            break;

        case HSA_API_ENTRYPOINT__GET_JOURNEY_PLANNER_FOLDER_LIST_COUNT:

            HSA_TCU__ulwGetJourneyPlannerFolderListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_JOURNEY_PLANNER_FOLDER_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vGetJourneyPlannerFolderList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_JOURNEY_PLANNER_MESSAGE_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vPrepareJourneyPlannerMessageList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_JOURNEY_PLANNER_MESSAGE_LIST_COUNT:

            HSA_TCU__ulwGetJourneyPlannerMessageListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_JOURNEY_PLANNER_MESSAGE_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vGetJourneyPlannerMessageList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__JOURNEY_PLANNER_MESSAGE_LIST_UPDATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vJourneyPlannerMessageListUpdate(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_JOURNEY_PLANNER_POI_INFO:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vPrepareJourneyPlannerPoiInfo(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_SPELLER_HISTORY_AVAILABILITY:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_TCU__vPrepareSpellerHistoryAvailability(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_SPELLER_HISTORY_AVAILABLE:

            HSA_TCU__ulwIsSpellerHistoryAvailable();
            break;

        case HSA_API_ENTRYPOINT__PREPARE_SPELLER_HISTORY_LIST:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_TCU__vPrepareSpellerHistoryList(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_HISTORY_LIST_COUNT:

            HSA_TCU__ulwSpellerHistoryListCount();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_HISTORY_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vSpellerHistoryList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_SPELLER_ENTRY_FIELD:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vPrepareSpellerEntryField(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_MAX_CHAR_COUNT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam1); 

            HSA_TCU__vSpellerSetMaxCharCount(slParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_INPUT_OCCURRED:

            HSA_TCU__blSpellerInputOccurred();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_DISCARD_INPUT:

            HSA_TCU__vSpellerDiscardInput();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_DISCARD_ALL_INPUT:

            HSA_TCU__vSpellerDiscardAllInput();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_CHARACTER:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_TCU__vSpellerSetCharacter(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SPELLER_ENTRY_FIELD:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_TCU__vGetSpellerEntryField(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_LETTER_FUNCTION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_TCU__vSpellerGetLetterFunction(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS:

            HSA_TCU__ulwSpellerGetCursorPos();
            break;

        case HSA_API_ENTRYPOINT__POI_INFO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_TCU__vPoiInfo(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__IS_POI_NUMBER_AVAILABLE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__blIsPOINumberAvailable(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__POI_INFO_INFO_CALL_SELECT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vPoiInfoInfoCallSelect(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__POI_INFO_INFO_MAP_SELECT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vPoiInfoInfoMapSelect(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__POI_INFO_INFO_START_SELECT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vPoiInfoInfoStartSelect(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_HEADER_ICON:

            HSA_TCU__ulwGetHeaderIcon();
            break;

        case HSA_API_ENTRYPOINT__WAIT_SYNC_STATE:

            HSA_TCU__ulwWaitSyncState();
            break;

        case HSA_API_ENTRYPOINT__PREPARE_MESSAGE_HISTORY_CHANNEL_AVAILABILITY:

            HSA_TCU__vPrepareMessageHistoryChannelAvailability();
            break;

        case HSA_API_ENTRYPOINT__PREPARE_MESSAGE_HISTORY_CHANNEL_LIST:

            HSA_TCU__vPrepareMessageHistoryChannelList();
            break;

        case HSA_API_ENTRYPOINT__GET_MESSAGE_HISTORY_CHANNEL_LIST_COUNT:

            HSA_TCU__ulwGetMessageHistoryChannelListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_MESSAGE_HISTORY_CHANNEL_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vGetMessageHistoryChannelList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_MESSAGE_HISTORY_AUTO_FEED_INFO:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vPrepareMessageHistoryAutoFeedInfo(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_AUTO_PLAY_COUNT:

            HSA_TCU__ulwGetAutoPlayCount();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_AUTO_PLAY_INDEX:

            HSA_TCU__ulwGetCurrentAutoPlayIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_AUTO_PLAY_TEXT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_TCU__vGetAutoPlayText(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_AUTO_PLAY_TITLE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_TCU__vGetAutoPlayTitle(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_AUTO_PLAY_DYNAMIC_IMAGE_ID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_TCU__vGetAutoPlayDynamicImageID(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__AUTO_PLAY_NEXT_KEY_LONG_PRESS:

            HSA_TCU__vAutoPlayNextKeyLongPress();
            break;

        case HSA_API_ENTRYPOINT__AUTO_PLAY_NEXT_KEY_SHORT_PRESS:

            HSA_TCU__vAutoPlayNextKeyShortPress();
            break;

        case HSA_API_ENTRYPOINT__AUTO_PLAY_PREVIOUS_KEY_LONG_PRESS:

            HSA_TCU__vAutoPlayPreviousKeyLongPress();
            break;

        case HSA_API_ENTRYPOINT__AUTO_PLAY_PREVIOUS_KEY_SHORT_PRESS:

            HSA_TCU__vAutoPlayPreviousKeyShortPress();
            break;

        case HSA_API_ENTRYPOINT__AUTO_PLAY_TTS_ABORT:

            HSA_TCU__vAutoPlay_TTSAbort();
            break;

        case HSA_API_ENTRYPOINT__AUTO_PLAY_TTS_START:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vAutoPlay_TTSStart(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__AUTO_PLAY__PLAY:

            HSA_TCU__vAutoPlay_Play();
            break;

        case HSA_API_ENTRYPOINT__GET_AUTO_PLAY__SCREEN:

            HSA_TCU__ulwGetAutoPlay_Screen();
            break;

        case HSA_API_ENTRYPOINT__IS_AUTO_PLAY__SHOW_DETAILS_AVAILABLE:

            HSA_TCU__blIsAutoPlay_ShowDetailsAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_AUTO_PLAY__DELETE_AVAILABLE:

            HSA_TCU__blIsAutoPlay_DeleteAvailable();
            break;

        case HSA_API_ENTRYPOINT__AUTO_PLAY__DELETE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vAutoPlay_Delete(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_AUTO_PLAY__PLAY_ENABLED:

            HSA_TCU__blIsAutoPlay_PlayEnabled();
            break;

        case HSA_API_ENTRYPOINT__IS_AUTO_PLAY__GO_HERE_ENABLED:

            HSA_TCU__blIsAutoPlay_GoHereEnabled();
            break;

        case HSA_API_ENTRYPOINT__IS_AUTO_PLAY__SHOW_IMAGE_ENABLED:

            HSA_TCU__blIsAutoPlay_ShowImageEnabled();
            break;

        case HSA_API_ENTRYPOINT__IS_AUTO_PLAY__CALL_ENABLED:

            HSA_TCU__blIsAutoPlay_CallEnabled();
            break;

        case HSA_API_ENTRYPOINT__IS_AUTO_PLAY__SHOW_ON_MAP_ENABLED:

            HSA_TCU__blIsAutoPlay_ShowOnMapEnabled();
            break;

        case HSA_API_ENTRYPOINT__IS_MESSAGE_HISTORY_AVAILABLE:

            HSA_TCU__blIsMessageHistoryAvailable();
            break;

        case HSA_API_ENTRYPOINT__READ_SMS:

            HSA_TCU__vReadSMS();
            break;

        case HSA_API_ENTRYPOINT__IGNORE_SMS:

            HSA_TCU__vIgnoreSMS();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_TEST_MODE_TCU_AUDIO:

            HSA_TCU__vToggleTestModeTCUAudio();
            break;

        case HSA_API_ENTRYPOINT__GET_DEVELOPER_TEST_MODE_TCU_AUDIO_STATUS:

            HSA_TCU__blGetDeveloperTestModeTCUAudioStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_DEVELOPER_TEST_MODE_TCU_SERVER_LIST_COUNT:

            HSA_TCU__ulwGetDeveloperTestModeTCUServerListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_DEVELOPER_TEST_MODE_TCU_SERVER_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vGetDeveloperTestModeTCUServerList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DEVELOPER_TEST_MODE_TCU_SERVER_LIST_ACTIVE_INDEX:

            HSA_TCU__ulwGetDeveloperTestModeTCUServerListActiveIndex();
            break;

        case HSA_API_ENTRYPOINT__SET_DEVELOPER_TEST_MODE_TCU_SERVER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vSetDeveloperTestModeTCUServer(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_DEVELOPER_TEST_MODE_TCU_SERVERLIST:

            HSA_TCU__vPrepareDeveloperTestModeTCUServerlist();
            break;

        case HSA_API_ENTRYPOINT__AUTO_PLAY__MENU_OPTION_AVAILABLE:

            HSA_TCU__ulwAutoPlay_MenuOptionAvailable();
            break;

        case HSA_API_ENTRYPOINT__SET_AUTO_PLAY_SCREEN_ID:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vSetAutoPlayScreenID(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DRIVER_UPLOADCONFIRMATION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_TCU__vSetDriverUploadconfirmation(usParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DRIVER_UPLOAD_CONFIRMATION:

            HSA_TCU__blGetDriverUploadConfirmation();
            break;

        case HSA_API_ENTRYPOINT__PREPARE_INFORMATION_FOLDER_LIST:

            HSA_TCU__vPrepareInformationFolderList();
            break;

        case HSA_API_ENTRYPOINT__GET_INFORMATION_FOLDER_LIST_COUNT:

            HSA_TCU__ulwGetInformationFolderListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_INFORMATION_FOLDER_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vGetInformationFolderName(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_INFORMATION_CHANNEL_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vPrepareInformationChannelList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_INFORMATION_CHANNEL_LIST_COUNT:

            HSA_TCU__ulwGetInformationChannelListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_INFORMATION_CHANNEL_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_TCU__vGetInformationChannelName(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_MIS_CHANNEL_DATA:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vRequestMISChannelData(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_MIS_CHANNEL_INFO:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vPrepareMISChannelInfo(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_MS_CHANNEL_MASTER_DATA:

            HSA_TCU__vPrepareMSChannelMasterData();
            break;

        case HSA_API_ENTRYPOINT__IS_MY_SCHEDULE_CMD_AVAIABLE:

            HSA_TCU__blIsMyScheduleCMDAvaiable();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_MS_CHANNEL_DATA:

            HSA_TCU__vRequestMSChannelData();
            break;

        case HSA_API_ENTRYPOINT__PREPARE_MS_CHANNEL_INFO:

            HSA_TCU__vPrepareMSChannelInfo();
            break;

        case HSA_API_ENTRYPOINT__IS_OPEN_AUTO_PLAY_SCREEN:

            HSA_TCU__blIsOpenAutoPlayScreen();
            break;

        case HSA_API_ENTRYPOINT__SET_AUTOPLAY_CONTEXT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_TCU__vSetAutoplayContext(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_AUTOPLAY_CONTEXT:

            HSA_TCU__ulwGetAutoplayContext();
            break;

        case HSA_API_ENTRYPOINT__DOWNLOAD_ADDITIONAL_CONTENTS:

            HSA_TCU__vDownloadAdditionalContents();
            break;

        case HSA_API_ENTRYPOINT__DISCARD_ADDITIONAL_CONTENTS:

            HSA_TCU__vDiscardAdditionalContents();
            break;

        case HSA_API_ENTRYPOINT__IS_TCU_CONNECTED:

            HSA_TCU__blIsTCUConnected();
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

