/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_Navigation_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_Navigation_Base_H
#define _clHSA_Navigation_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_Navigation_Base : public clHSA_Base
{
public:

    static clHSA_Navigation_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_Navigation_Base()        {}

    virtual void vSetupToggleHighwayEntrancePictureState( );

    virtual tbool blSetupGetHighwayEntrancePictureState( );

    virtual tbool blSetupGetSpeedLimit( );

    virtual void vSetupSetSpeedLimit(tbool blMode);

    virtual void vRequestNAVTEQFilename( );

    virtual void vGetNAVTEQFilename(GUI_String *out_result);

    virtual void vGetNAVTEQCheckDigit(GUI_String *out_result);

    virtual void vSetDemoPositionFromMapInput( );

    virtual void vMapInputSave_Home(const GUI_String * InputString);

    virtual void vStoreCurrPositionAsWayPoint(const GUI_String * InputString);

    virtual void vPOISearchNearByFoodStart_NAR( );

    virtual void vPOISearchNearbyATMStart( );

    virtual void vStoreCurrentDestAsWayPoint( );

    virtual void vStoreCurDestAsWayPoint(ulword ulwListEntryNr);

    virtual void vGetSkippedWaypointName(GUI_String *out_result);

    virtual void vSkipWaypointAndStartRouteGuidance( );

    virtual void vPOISelectByCategory_NAR( );

    virtual void vPOIAlongRoutePrepareSearchEngine( );

    virtual void vPoiSetCategoryAlongRoute(ulword ulwCategoryNo);

    virtual ulword ulwIsListPrepared_NAR( );

    virtual void vGetPOICategoryList_NAR(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vSaveHouseNo_NAR(ulword ulwType);

    virtual void vGetCurrentCountryCarPlate(GUI_String *out_result);

    virtual void vInitializeSpeedProfile( );

    virtual void vToggleUserSpeedProfile( );

    virtual tbool blIsUserSpeedProfileOn( );

    virtual void vSetSpeedProfile(ulword ulwSpeedProfile, tbool blSpeedProfileDirection);

    virtual void vGetSpeedProfile(GUI_String *out_result, ulword ulwSpeedProfile);

    virtual void vConfirmSpeedProfile( );

    virtual void vGetLanguageDependentStrings(GUI_String *out_result, ulword ulwType);

    virtual tbool blIsLIMServiceAvailable( );

    virtual ulword ulwGetCurrentCountryIndex( );

    virtual void vSDGetInfo(GUI_String *out_result);

    virtual void vMapInputPrepareSaving( );

    virtual void vMapInputGetNameForDestIdent(GUI_String *out_result);

    virtual void vDestEntrySave(ulword ulwSave);

    virtual void vUPSGetSelectedPOI(GUI_String *out_result);

    virtual void vUPSPOIPrepareGuidanceFromDetails( );

    virtual tbool blIsUPSCategoryPrepared( );

    virtual tbool blOnUPSDataUpdate( );

    virtual tbool blIsUPSPOIListPrepared( );

    virtual ulword ulwGetUPSDistance( );

    virtual ulword ulwGetPOIProximityWarning( );

    virtual void vGetUPSPOIDetail(GUI_String *out_result);

    virtual void vFlagEntryPrepareSaving( );

    virtual void vFlagEntrySave( );

    virtual tbool blIsCategoryRestorePossible( );

    virtual void vRestoreCategory( );

    virtual ulword ulwGetUPSProximityWarning( );

    virtual void vToggleSetPOIProximityWarning( );

    virtual void vDeleteUPS( );

    virtual ulword ulwUPSDeleteState( );

    virtual void vSetUPSDistance(ulword ulwState);

    virtual ulword ulwGetTravelAdvantageValues(ulword ulwRouteType);

    virtual void vDynRouteConsiderUpdate(ulword ulwRouteType);

    virtual void vGetCurrentCode(GUI_String *out_result);

    virtual tbool blIsUPSDataAvailableInSystem( );

    virtual void vStartListCategory( );

    virtual tbool blIsUPSDataAvailable( );

    virtual ulword ulwGetUPSDownloadProgress( );

    virtual ulword ulwGetUPSDownloadState( );

    virtual void vStopUPSDownload( );

    virtual void vStartUPSDownload( );

    virtual void vToggleLaneInformation( );

    virtual tbool blSetupGetLaneGuidanceSymbolsState( );

    virtual ulword ulwGetUPSCategoryCount( );

    virtual void vGetUPSCategoryList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vUPSSetCategory(ulword ulwListEntryNr);

    virtual ulword ulwGetUPSPOICount( );

    virtual void vGetUPSPOIList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vUPSGetSelectedCategory(GUI_String *out_result);

    virtual void vUPSGETDetails(ulword ulwListEntryNr);

    virtual ulword ulwGetUPSERRORPOICount( );

    virtual void vGetUPSERRORList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vRepeatLastNavigationAnnouncement( );

    virtual tbool blCurrentCarPositionAvailable( );

    virtual tbool blCurrentCarPositionValidOnMap( );

    virtual tbool blComplexEntryDisclaimerSpeedThresholdAchieved( );

    virtual slword slwConvertToDynamicIndex_RouteManeuverList(ulword ulwUniqueId);

    virtual slword slwConvertToUniqueId_RouteManeuverList( );

    virtual tbool blCurrentDestinationIsStartable( );

    virtual void vDecreaseAnnounceVolume( );

    virtual void vDeleteCurrentDestination( );

    virtual tbool blDemoStartLocationAvailable( );

    virtual void vDestEntryGetAddress(GUI_String *out_result, ulword ulwType);

    virtual void vDestEntryActivateNavDestFormItem(ulword ulwItem);

    virtual void vRestoreDestEntryActivateNavDestFormItem(ulword ulwItem);

    virtual void vDestEntryGetFavourite(GUI_String *out_result, ulword ulwType);

    virtual void vDestEntryGetPOI(GUI_String *out_result, ulword ulwType);

    virtual void vDestEntryGetPOILastDest(GUI_String *out_result);

    virtual void vDestEntryGetHome(GUI_String *out_result, ulword ulwType);

    virtual void vDestEntryGetGeoPos(GUI_String *out_result, ulword ulwType);

    virtual void vDestEntryInit( );

    virtual void vDestEntryInitWithCountry( );

    virtual tbool blDestEntryIsValid( );

    virtual tbool blDestEntryGetHouseNumberAvailability( );

    virtual tbool blDestMemDestEntryChanged( );

    virtual tbool blIsDestinationOFFMap( );

    virtual tbool blGetRouteBlockSelection( );

    virtual void vDestEntryPrepareGuidance( );

    virtual void vDestEntryPrepareSaving( );

    virtual void vDestEntryRenameFavorite( );

    virtual void vDestEntrySelectAddr(ulword ulwListEntryNr);

    virtual void vDestentrySelectWayPoint(ulword ulwListEntryNr);

    virtual void vDestEntrySetData(ulword ulwType, ulword ulwListEntryNr);

    virtual void vDestEntrySetDataCityToCityCenter( );

    virtual void vDestEntryGetDataShort(GUI_String *out_result, ulword ulwType);

    virtual tbool blDestEntryCategoryIsPossible(ulword ulwType);

    virtual void vFlagDestGetName(GUI_String *out_result);

    virtual void vFlagDestSave(const GUI_String * InputString);

    virtual ulword ulwFlagDestSaveState( );

    virtual ulword ulwGetActiveAverageSpeed( );

    virtual tbool blGetCalcRouteFails( );

    virtual ulword ulwGetCalcRouteIsRunning( );

    virtual ulword ulwGetCalcRouteProgress( );

    virtual void vGetCurrentDestination(GUI_String *out_result, ulword ulwType);

    virtual void vGetCurrentDestinationData(GUI_String *out_result);

    virtual void vGetCurrentDestinationDetail(GUI_String *out_result, ulword ulwDetail);

    virtual void vGetCurrentWaypointForSave(GUI_String *out_result);

    virtual void vGetCurrentDestinationShort(GUI_String *out_result);

    virtual void vGetCurrentIntDestDetail(GUI_String *out_result, ulword ulwDetail);

    virtual void vSetDisambiguationCityCenterItem(ulword ulwListEntryNr);

    virtual void vGetDisambiguationCityCenterList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetDisambiguationCityCenterItemCount( );

    virtual void vGetDisambiguationList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vSetDisambiguationItem(ulword ulwListEntryNr);

    virtual ulword ulwGetDisambiguationItemCount( );

    virtual ulword ulwGetGuidanceState( );

    virtual ulword ulwGetIntermediateDestinationGuidanceState( );

    virtual void vSetLastGuidanceState(ulword ulwState);

    virtual void vRestartRouteGuidance( );

    virtual tbool blGetLastGuidanceState( );

    virtual void vGetPositionDataDetail(GUI_String *out_result, ulword ulwDetail);

    virtual void vGetPositionDataShort(GUI_String *out_result);

    virtual tbool blGetTemporaryMode( );

    virtual void vHomeDestGetDataShort(GUI_String *out_result, ulword ulwType);

    virtual tbool blHomeDestIsGeoPos( );

    virtual void vHomeDestInit( );

    virtual tbool blHomeDestIsDefined( );

    virtual void vHomeSaveCCP(const GUI_String * InputString);

    virtual void vDestEntrySave_Home(const GUI_String * InputString);

    virtual void vStoreMainDestination( );

    virtual void vStoreCurDestFromWaypointList(ulword ulwListEntryNr);

    virtual void vHomePrepareGuidance( );

    virtual void vHomeCheckAvailability( );

    virtual void vIncreaseAnnounceVolume( );

    virtual void vInit( );

    virtual void vIntDestDeleteIntermediate( );

    virtual void vIntDestReplaceMainDest( );

    virtual void vIntDestInsertIntermediate( );

    virtual void vIntDestReplaceIntermediate( );

    virtual tbool blIsAvailableStreetsInCity( );

    virtual tbool blIsDestinationUnique( );

    virtual tbool blIsHNDefined( );

    virtual tbool blIsCrossingAvailable( );

    virtual tbool blIsHouseNumberUnique( );

    virtual tbool blIsCityCenterUnique( );

    virtual ulword ulwIsInitialized( );

    virtual ulword ulwIsDataAvailable( );

    virtual tbool blIsNaviDataAvailable(ulword ulwSource);

    virtual void vLastCurrentDestPrepareGuidance( );

    virtual ulword ulwMemoryClearState( );

    virtual ulword ulwMemoryEntryType( );

    virtual ulword ulwWaypointMemoryEntryType( );

    virtual ulword ulwGetSelectedWaypointIndex( );

    virtual ulword ulwMemoryIntDestEntryType( );

    virtual void vMemoryDestMemClear(ulword ulwSource);

    virtual tbool blMemoryDestMemExistsName( );

    virtual void vMemoryDestMemGetList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwMemoryDestMemGetListCount( );

    virtual void vMemoryDestMemInputFilterString(const GUI_String * InputString);

    virtual tbool blMemoryDestMemIsEmpty( );

    virtual tbool blMemoryDestMemIsFull( );

    virtual void vMemoryDestMemPrepareGuidance(ulword ulwListEntryNr);

    virtual void vMemoryDestMemPrepareList( );

    virtual void vMemoryDestMemPrepareSearch( );

    virtual void vMemoryDestMemGetSearchList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwMemoryDestMemGetSearchListCount( );

    virtual void vMemoryDestMemActivateSearch( );

    virtual ulword ulwMemoryDestMemSaveState( );

    virtual void vMemoryDestMemGetInfoShort(GUI_String *out_result);

    virtual ulword ulwMemoryDestMemDeleteState( );

    virtual void vMemoryLastDestClear( );

    virtual void vMemoryLastDestGetInfo(GUI_String *out_result);

    virtual void vMemoryLastDestGetInfoShort(GUI_String *out_result);

    virtual void vMemoryLastDestGetList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwMemoryLastDestGetListCount( );

    virtual tbool blMemoryLastDestListEmpty( );

    virtual void vMemoryLastDestPrepareGuidance(ulword ulwListEntryNr);

    virtual void vMemoryLastDestSelectForSaving(ulword ulwListEntryNr);

    virtual void vMemoryLastDestPrepareList( );

    virtual void vHNMatchForReduction( );

    virtual void vPOIPrepareSearchEngine( );

    virtual ulword ulwPOIGetResultCount( );

    virtual tbool blPOISearchIsAvailable( );

    virtual tbool blPOISearchStringIsServiceable( );

    virtual void vPOISearchParamSetCharacter(const GUI_String * InputString);

    virtual void vGetPOISpellerSearchString(GUI_String *out_result);

    virtual void vPOISearchParamSetCurrentCarPosition( );

    virtual void vPOISearchParamSetLocation( );

    virtual void vPOISearchParamSetDestination( );

    virtual void vPOISearchProgressGetRadius(GUI_String *out_result);

    virtual void vSpellerGetPOISearchInput(GUI_String *out_result);

    virtual void vPOISelectForSaving(ulword ulwListEntryNr);

    virtual void vPOISelectForSavingFromDetail( );

    virtual void vPOITopSelectForSaving(ulword ulwListEntryNr);

    virtual void vPOITopSelectForSavingFromDetail( );

    virtual ulword ulwPOISearchResultCount( );

    virtual void vPOISearchResultGetListString(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr);

    virtual ulword ulwPOISearchResultGetListValue(ulword ulwCell, ulword ulwListEntryNr);

    virtual void vPOISearchResultGetSelectedData(GUI_String *out_result);

    virtual tbool blPOISearchResultGetSelectedHasAdditionalInfo( );

    virtual void vPOISearchResultListSelectForDetails(ulword ulwListEntryNr);

    virtual ulword ulwPOIGetCurrentDetailViewIndex( );

    virtual void vPOIPrepareGuidance(ulword ulwListEntryNr);

    virtual void vPOIPrepareGuidanceFromDetails( );

    virtual void vPOITopPrepareGuidance(ulword ulwListEntryNr);

    virtual void vPOIEditLocationInit( );

    virtual void vPOISearchStart( );

    virtual void vPOISearchGasStationStart( );

    virtual void vPOISearchParkingAreaStart( );

    virtual ulword ulwPOISearchState( );

    virtual void vTelematicParamSetAroundCarPosition( );

    virtual void vTelematicSearchAroundCity( );

    virtual void vTelematicSearchAroundDest( );

    virtual void vXMParamSetAroundCarPosition( );

    virtual void vXMSearchAroundCity( );

    virtual void vXMSearchAroundDest( );

    virtual void vTelematicPOIPrepareGuidanceFromDetails( );

    virtual void vPOISearchStop( );

    virtual void vPOITopSearchStop( );

    virtual void vRecalculateRoute( );

    virtual void vRouteBlockCongestionAheadApply( );

    virtual void vRouteBlockCongestionAheadDecrease( );

    virtual void vRouteBlockCongestionAheadGetLength(GUI_String *out_result);

    virtual void vRouteBlockCongestionAheadIncrease( );

    virtual void vRouteBlockDiscardEntries( );

    virtual void vRouteCriteriaApplyInput( );

    virtual void vRouteCriteriaInit( );

    virtual void vRouteCriteriaAvoidVignetteGetList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vRouteCriteriaAvoidVignetteGetCheckbox(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwRouteCriteriaAvoidVignetteListCount( );

    virtual void vRouteCriteriaAvoidVignetteToggleItem(ulword ulwListEntryNr);

    virtual ulword ulwRouteCriteriaGetState(ulword ulwType);

    virtual void vRouteCriteriaSetState(ulword ulwType, ulword ulwState);

    virtual ulword ulwRouteGuidanceGetMode( );

    virtual void vRouteGuidanceGetRemainingDistance(GUI_String *out_result);

    virtual void vRouteGuidanceGetRemainingTime(GUI_String *out_result);

    virtual void vRouteGuidanceStart( );

    virtual void vRouteGuidanceStartDemo( );

    virtual void vRouteGuidanceStart_Waypoint( );

    virtual void vRouteGuidanceStartDemo_Waypoint( );

    virtual void vRouteGuidanceStartPOI( );

    virtual void vRouteGuidanceStop( );

    virtual void vRouteManeuverDetailData(GUI_String *out_result);

    virtual void vRouteManeuverActivateDetailData(ulword ulwListEntryNr);

    virtual void vRouteManeuverGetList(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr);

    virtual ulword ulwRouteManeuverGetDisTimeUnits(ulword ulwListEntryNr);

    virtual ulword ulwRouteManeuverMessageIconLabel(ulword ulwListEntryNr);

    virtual void vSetWaypointForPOISearch(ulword ulwListEntryNr);

    virtual ulword ulwWaypointIconLabel(ulword ulwListEntryNr);

    virtual ulword ulwRouteManeuverMarkedLockElement(ulword ulwListEntryNr);

    virtual ulword ulwRouteManeuverGetListCount( );

    virtual ulword ulwRouteManeuverGetSubItemCount( );

    virtual tbool blRouteManeuverListIsAvailable( );

    virtual tbool blRouteBlockIsLockLimitExceeded( );

    virtual void vRouteManeuverPrepareList( );

    virtual void vRouteManeuverMarkLockElementIncrease( );

    virtual void vRouteManeuverMarkLockElementDecrease( );

    virtual void vRouteManeuverSetMarkLockElement(ulword ulwListEntryNr);

    virtual void vRouteManeuverSetMarkLockFirstElement(ulword ulwListEntryNr);

    virtual void vRouteManeuverSetMarkLockFirstElementFromDetails( );

    virtual void vRouteManeuverSetMarkLockLastElementFromDetails( );

    virtual void vRouteManeuverSetMarkLockLastElement(ulword ulwListEntryNr);

    virtual tbool blRouteManeuverMarkLockMode( );

    virtual void vRouteManeuverSetMarkLockMode(tbool blMode);

    virtual tbool blRouteManeuverIsCongestionDefined( );

    virtual void vRouteManeuverDeleteCongestion( );

    virtual void vRouteManeuverListClosed( );

    virtual ulword ulwRouteManeuverPrepareListState( );

    virtual void vEnterMoveMode(ulword ulwPressedDynamicIndex);

    virtual void vListEntryMoveDown(ulword ulwMovedDynamicIndex);

    virtual void vListEntryMoveUp(ulword ulwMovedDynamicIndex);

    virtual void vAbortMoveMode( );

    virtual void vLeaveMoveMode( );

    virtual ulword ulwWaypointGetCurrentMoveIndex( );

    virtual void vDeleteAndInsertWaypoint(ulword ulwListEntryNumber);

    virtual void vDeleteWaypoint(ulword ulwListEntryNumber);

    virtual tbool blRouteOptionDynRouteGetState( );

    virtual void vRouteOptionDynRouteSetState(tbool blMode);

    virtual ulword ulwRouteOptionGetState( );

    virtual void vRouteOptionSetState(ulword ulwState);

    virtual void vSetCurrentPositionAsHomeDest( );

    virtual void vSetTemporaryMode(tbool blMode);

    virtual void vSetDemoPosition( );

    virtual ulword ulwSetupGetAnnouncement( );

    virtual ulword ulwSetupGetAutozoom( );

    virtual tbool blSetupGetDemoMode( );

    virtual tbool blSetupDeactivateDemoModeSetting( );

    virtual tbool blSetupOptionsChanged( );

    virtual void vSetupSetAutozoom(ulword ulwMode);

    virtual void vSetupSetDemoMode(tbool blMode);

    virtual void vSpellerInitInput(ulword ulwType);

    virtual void vSpellerInitRestore(ulword ulwType);

    virtual void vSpellerCharacterInput(const GUI_String * InputString);

    virtual void vSpellerDiscardAllInput( );

    virtual void vSpellerGetNameInput(GUI_String *out_result);

    virtual void vSpellerSetNameInput( );

    virtual ulword ulwSpellerMatchGetCount(ulword ulwType);

    virtual ulword ulwMatchGetListCount(ulword ulwType);

    virtual void vSpellerMatchGetFirst(GUI_String *out_result, ulword ulwType);

    virtual void vSpellerGetFavSearchInput(GUI_String *out_result);

    virtual tbool blSpellerInputOccurred( );

    virtual void vSpellerMatchGetList(GUI_String *out_result, ulword ulwType, ulword ulwListEntryNr);

    virtual void vSpellerMatchActivateList(ulword ulwType);

    virtual void vSpellerMatchActivateListRestore(ulword ulwType);

    virtual void vSpellerMatchGetPossibleLetters(GUI_String *out_result);

    virtual tbool blSpellerInvertGetLetterFunction( );

    virtual void vSpellerGetHighlightedText(GUI_String *out_result, ulword ulwType);

    virtual tbool blSpellerEnableMatchSpeller( );

    virtual tbool blSpellerEnableHouseNumSpeller( );

    virtual ulword ulwSpellerGetCursorPos( );

    virtual void vSpellerSetMaxCharCount(ulword ulwCount);

    virtual void vSpellerSetInitialText(const GUI_String * InitialString);

    virtual void vStartEditingDemoMode( );

    virtual void vStopEditingDemoMode( );

    virtual void vStopCalcRoute( );

    virtual ulword ulwWaitSyncState(ulword ulwType);

    virtual void vRouteOptionDynRouteUserConfirm( );

    virtual ulword ulwGetDynRouteOption( );

    virtual void vSetDynRouteOption(ulword ulwMode);

    virtual tbool blIsMemoryLimitReached( );

    virtual void vShowCategoryList( );

    virtual void vGetHouseNo_NAR(GUI_String *out_result);

    virtual void vPoiSetCategory_NAR(ulword ulwListEntryNr);

    virtual ulword ulwGetPOIListType( );

    virtual tbool blIsPOICategoryListPrepared(ulword ulwType);

    virtual ulword ulwGetPOICategoryCount( );

    virtual ulword ulwGetPOIAttributeCount( );

    virtual void vRestorePOICategoryList( );

    virtual ulword ulwGetLastPOIListSelIndex( );

    virtual void vPOIGetSelectedCategory(GUI_String *out_result);

    virtual void vMemoryWaypointPrepareList( );

    virtual void vExitWaypointList( );

    virtual ulword ulwMemoryWaypointGetListCount( );

    virtual void vMemoryWaypointGetList(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr);

    virtual ulword ulwMemoryWaypointGetDirection(ulword ulwListEntryNr);

    virtual tbool blMemoryWaypointMemIsFull( );

    virtual void vWaypointPrepareSaving( );

    virtual ulword ulwRouteManeuverGetListUnit( );

    virtual ulword ulwPOISearchResultGetListUnit( );

    virtual ulword ulwGetPositionDataDetailUnit( );

    virtual ulword ulwMemoryWaypointGetListUnit( );

    virtual void vSetGnsssatSystemType(ulword ulwGnssType);

    virtual ulword ulwGetGnsssatSystemType( );

    virtual ulword ulwGetLanguageDependentStringsUnit( );

    virtual void vDestEntryGetWaypoint(GUI_String *out_result, ulword ulwType);

    virtual tbool blStreetPossibleAfterCity( );

    virtual ulword ulwDestEntryGetSDSInputType( );

    virtual void vTCUJourneyPrepareGuidance( );

    virtual void vTcuJourneyPrepareShowOnMap( );

    virtual void vSetTCUModeActive( );

    virtual void vGetSelectedPoiCategory(GUI_String *out_result);

protected:
    clHSA_Navigation_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_Navigation_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_Navigation_Base_H

