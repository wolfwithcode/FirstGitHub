/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Navigation_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_Navigation_Wrapper.h"
#include "clHSA_Navigation_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_Navigation_Trace.h"
#include "hmi_trace.h"

void HSA_Navigation__vSetupToggleHighwayEntrancePictureState( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_TOGGLE_HIGHWAY_ENTRANCE_PICTURE_STATE  ) ); 
        }
      pInst->vSetupToggleHighwayEntrancePictureState();

    }
}

tbool HSA_Navigation__blSetupGetHighwayEntrancePictureState( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_HIGHWAY_ENTRANCE_PICTURE_STATE  ) ); 
        }
      ret=pInst->blSetupGetHighwayEntrancePictureState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_HIGHWAY_ENTRANCE_PICTURE_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blSetupGetSpeedLimit( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_SPEED_LIMIT  ) ); 
        }
      ret=pInst->blSetupGetSpeedLimit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_SPEED_LIMIT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSetupSetSpeedLimit(tbool blMode)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_SET_SPEED_LIMIT | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vSetupSetSpeedLimit(blMode);

    }
}

void HSA_Navigation__vRequestNAVTEQFilename( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__REQUEST_NAVTEQ_FILENAME  ) ); 
        }
      pInst->vRequestNAVTEQFilename();

    }
}

void HSA_Navigation__vGetNAVTEQFilename(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_NAVTEQ_FILENAME  ) ); 
        }
      pInst->vGetNAVTEQFilename(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_NAVTEQ_FILENAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vGetNAVTEQCheckDigit(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_NAVTEQ_CHECK_DIGIT  ) ); 
        }
      pInst->vGetNAVTEQCheckDigit(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_NAVTEQ_CHECK_DIGIT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vSetDemoPositionFromMapInput( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_DEMO_POSITION_FROM_MAP_INPUT  ) ); 
        }
      pInst->vSetDemoPositionFromMapInput();

    }
}

void HSA_Navigation__vMapInputSave_Home(const GUI_String * InputString)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MAP_INPUT_SAVE__HOME | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vMapInputSave_Home( InputString);

    }
}

void HSA_Navigation__vStoreCurrPositionAsWayPoint(const GUI_String * InputString)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__STORE_CURR_POSITION_AS_WAY_POINT | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vStoreCurrPositionAsWayPoint( InputString);

    }
}

void HSA_Navigation__vPOISearchNearByFoodStart_NAR( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_NEAR_BY_FOOD_START_NAR  ) ); 
        }
      pInst->vPOISearchNearByFoodStart_NAR();

    }
}

void HSA_Navigation__vPOISearchNearbyATMStart( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_NEARBY_ATM_START  ) ); 
        }
      pInst->vPOISearchNearbyATMStart();

    }
}

void HSA_Navigation__vStoreCurrentDestAsWayPoint( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__STORE_CURRENT_DEST_AS_WAY_POINT  ) ); 
        }
      pInst->vStoreCurrentDestAsWayPoint();

    }
}

void HSA_Navigation__vStoreCurDestAsWayPoint(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__STORE_CUR_DEST_AS_WAY_POINT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vStoreCurDestAsWayPoint(ulwListEntryNr);

    }
}

void HSA_Navigation__vGetSkippedWaypointName(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_SKIPPED_WAYPOINT_NAME  ) ); 
        }
      pInst->vGetSkippedWaypointName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_SKIPPED_WAYPOINT_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vSkipWaypointAndStartRouteGuidance( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SKIP_WAYPOINT_AND_START_ROUTE_GUIDANCE  ) ); 
        }
      pInst->vSkipWaypointAndStartRouteGuidance();

    }
}

void HSA_Navigation__vPOISelectByCategory_NAR( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SELECT_BY_CATEGORY_NAR  ) ); 
        }
      pInst->vPOISelectByCategory_NAR();

    }
}

void HSA_Navigation__vPOIAlongRoutePrepareSearchEngine( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_ALONG_ROUTE_PREPARE_SEARCH_ENGINE  ) ); 
        }
      pInst->vPOIAlongRoutePrepareSearchEngine();

    }
}

void HSA_Navigation__vPoiSetCategoryAlongRoute(ulword ulwCategoryNo)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SET_CATEGORY_ALONG_ROUTE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCategoryNo); 
        }
      pInst->vPoiSetCategoryAlongRoute(ulwCategoryNo);

    }
}

ulword HSA_Navigation__ulwIsListPrepared_NAR( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_LIST_PREPARED_NAR  ) ); 
        }
      ret=pInst->ulwIsListPrepared_NAR();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_LIST_PREPARED_NAR | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vGetPOICategoryList_NAR(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POI_CATEGORY_LIST_NAR | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetPOICategoryList_NAR(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POI_CATEGORY_LIST_NAR | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vSaveHouseNo_NAR(ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SAVE_HOUSE_NO_NAR | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vSaveHouseNo_NAR(ulwType);

    }
}

void HSA_Navigation__vGetCurrentCountryCarPlate(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_COUNTRY_CAR_PLATE  ) ); 
        }
      pInst->vGetCurrentCountryCarPlate(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_COUNTRY_CAR_PLATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vInitializeSpeedProfile( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__INITIALIZE_SPEED_PROFILE  ) ); 
        }
      pInst->vInitializeSpeedProfile();

    }
}

void HSA_Navigation__vToggleUserSpeedProfile( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_USER_SPEED_PROFILE  ) ); 
        }
      pInst->vToggleUserSpeedProfile();

    }
}

tbool HSA_Navigation__blIsUserSpeedProfileOn( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_USER_SPEED_PROFILE_ON  ) ); 
        }
      ret=pInst->blIsUserSpeedProfileOn();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_USER_SPEED_PROFILE_ON | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSetSpeedProfile(ulword ulwSpeedProfile, tbool blSpeedProfileDirection)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_SPEED_PROFILE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSpeedProfile); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_SPEED_PROFILE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blSpeedProfileDirection); 
        }
      pInst->vSetSpeedProfile(ulwSpeedProfile, blSpeedProfileDirection);

    }
}

void HSA_Navigation__vGetSpeedProfile(GUI_String *out_result, ulword ulwSpeedProfile)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_SPEED_PROFILE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSpeedProfile); 
        }
      pInst->vGetSpeedProfile(out_result, ulwSpeedProfile);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_SPEED_PROFILE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vConfirmSpeedProfile( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__CONFIRM_SPEED_PROFILE  ) ); 
        }
      pInst->vConfirmSpeedProfile();

    }
}

void HSA_Navigation__vGetLanguageDependentStrings(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_LANGUAGE_DEPENDENT_STRINGS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vGetLanguageDependentStrings(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_LANGUAGE_DEPENDENT_STRINGS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Navigation__blIsLIMServiceAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_LIM_SERVICE_AVAILABLE  ) ); 
        }
      ret=pInst->blIsLIMServiceAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_LIM_SERVICE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetCurrentCountryIndex( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_COUNTRY_INDEX  ) ); 
        }
      ret=pInst->ulwGetCurrentCountryIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_COUNTRY_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSDGetInfo(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SD_GET_INFO  ) ); 
        }
      pInst->vSDGetInfo(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SD_GET_INFO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vMapInputPrepareSaving( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MAP_INPUT_PREPARE_SAVING  ) ); 
        }
      pInst->vMapInputPrepareSaving();

    }
}

void HSA_Navigation__vMapInputGetNameForDestIdent(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MAP_INPUT_GET_NAME_FOR_DEST_IDENT  ) ); 
        }
      pInst->vMapInputGetNameForDestIdent(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MAP_INPUT_GET_NAME_FOR_DEST_IDENT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vDestEntrySave(ulword ulwSave)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_SAVE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSave); 
        }
      pInst->vDestEntrySave(ulwSave);

    }
}

void HSA_Navigation__vUPSGetSelectedPOI(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__UPS_GET_SELECTED_POI  ) ); 
        }
      pInst->vUPSGetSelectedPOI(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__UPS_GET_SELECTED_POI | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vUPSPOIPrepareGuidanceFromDetails( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__UPSPOI_PREPARE_GUIDANCE_FROM_DETAILS  ) ); 
        }
      pInst->vUPSPOIPrepareGuidanceFromDetails();

    }
}

tbool HSA_Navigation__blIsUPSCategoryPrepared( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_UPS_CATEGORY_PREPARED  ) ); 
        }
      ret=pInst->blIsUPSCategoryPrepared();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_UPS_CATEGORY_PREPARED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blOnUPSDataUpdate( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ON_UPS_DATA_UPDATE  ) ); 
        }
      ret=pInst->blOnUPSDataUpdate();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ON_UPS_DATA_UPDATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blIsUPSPOIListPrepared( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_UPSPOI_LIST_PREPARED  ) ); 
        }
      ret=pInst->blIsUPSPOIListPrepared();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_UPSPOI_LIST_PREPARED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetUPSDistance( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPS_DISTANCE  ) ); 
        }
      ret=pInst->ulwGetUPSDistance();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPS_DISTANCE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetPOIProximityWarning( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POI_PROXIMITY_WARNING  ) ); 
        }
      ret=pInst->ulwGetPOIProximityWarning();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POI_PROXIMITY_WARNING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vGetUPSPOIDetail(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPSPOI_DETAIL  ) ); 
        }
      pInst->vGetUPSPOIDetail(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPSPOI_DETAIL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vFlagEntryPrepareSaving( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__FLAG_ENTRY_PREPARE_SAVING  ) ); 
        }
      pInst->vFlagEntryPrepareSaving();

    }
}

void HSA_Navigation__vFlagEntrySave( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__FLAG_ENTRY_SAVE  ) ); 
        }
      pInst->vFlagEntrySave();

    }
}

tbool HSA_Navigation__blIsCategoryRestorePossible( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_CATEGORY_RESTORE_POSSIBLE  ) ); 
        }
      ret=pInst->blIsCategoryRestorePossible();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_CATEGORY_RESTORE_POSSIBLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vRestoreCategory( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__RESTORE_CATEGORY  ) ); 
        }
      pInst->vRestoreCategory();

    }
}

ulword HSA_Navigation__ulwGetUPSProximityWarning( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPS_PROXIMITY_WARNING  ) ); 
        }
      ret=pInst->ulwGetUPSProximityWarning();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPS_PROXIMITY_WARNING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vToggleSetPOIProximityWarning( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_SET_POI_PROXIMITY_WARNING  ) ); 
        }
      pInst->vToggleSetPOIProximityWarning();

    }
}

void HSA_Navigation__vDeleteUPS( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DELETE_UPS  ) ); 
        }
      pInst->vDeleteUPS();

    }
}

ulword HSA_Navigation__ulwUPSDeleteState( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__UPS_DELETE_STATE  ) ); 
        }
      ret=pInst->ulwUPSDeleteState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__UPS_DELETE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSetUPSDistance(ulword ulwState)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_UPS_DISTANCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwState); 
        }
      pInst->vSetUPSDistance(ulwState);

    }
}

ulword HSA_Navigation__ulwGetTravelAdvantageValues(ulword ulwRouteType)
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_TRAVEL_ADVANTAGE_VALUES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRouteType); 
        }
      ret=pInst->ulwGetTravelAdvantageValues(ulwRouteType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_TRAVEL_ADVANTAGE_VALUES | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vDynRouteConsiderUpdate(ulword ulwRouteType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DYN_ROUTE_CONSIDER_UPDATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRouteType); 
        }
      pInst->vDynRouteConsiderUpdate(ulwRouteType);

    }
}

void HSA_Navigation__vGetCurrentCode(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CODE  ) ); 
        }
      pInst->vGetCurrentCode(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CODE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Navigation__blIsUPSDataAvailableInSystem( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_UPS_DATA_AVAILABLE_IN_SYSTEM  ) ); 
        }
      ret=pInst->blIsUPSDataAvailableInSystem();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_UPS_DATA_AVAILABLE_IN_SYSTEM | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vStartListCategory( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__START_LIST_CATEGORY  ) ); 
        }
      pInst->vStartListCategory();

    }
}

tbool HSA_Navigation__blIsUPSDataAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_UPS_DATA_AVAILABLE  ) ); 
        }
      ret=pInst->blIsUPSDataAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_UPS_DATA_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetUPSDownloadProgress( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPS_DOWNLOAD_PROGRESS  ) ); 
        }
      ret=pInst->ulwGetUPSDownloadProgress();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPS_DOWNLOAD_PROGRESS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetUPSDownloadState( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPS_DOWNLOAD_STATE  ) ); 
        }
      ret=pInst->ulwGetUPSDownloadState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPS_DOWNLOAD_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vStopUPSDownload( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__STOP_UPS_DOWNLOAD  ) ); 
        }
      pInst->vStopUPSDownload();

    }
}

void HSA_Navigation__vStartUPSDownload( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__START_UPS_DOWNLOAD  ) ); 
        }
      pInst->vStartUPSDownload();

    }
}

void HSA_Navigation__vToggleLaneInformation( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_LANE_INFORMATION  ) ); 
        }
      pInst->vToggleLaneInformation();

    }
}

tbool HSA_Navigation__blSetupGetLaneGuidanceSymbolsState( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_LANE_GUIDANCE_SYMBOLS_STATE  ) ); 
        }
      ret=pInst->blSetupGetLaneGuidanceSymbolsState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_LANE_GUIDANCE_SYMBOLS_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetUPSCategoryCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPS_CATEGORY_COUNT  ) ); 
        }
      ret=pInst->ulwGetUPSCategoryCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPS_CATEGORY_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vGetUPSCategoryList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPS_CATEGORY_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetUPSCategoryList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPS_CATEGORY_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vUPSSetCategory(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__UPS_SET_CATEGORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vUPSSetCategory(ulwListEntryNr);

    }
}

ulword HSA_Navigation__ulwGetUPSPOICount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPSPOI_COUNT  ) ); 
        }
      ret=pInst->ulwGetUPSPOICount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPSPOI_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vGetUPSPOIList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPSPOI_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetUPSPOIList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPSPOI_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vUPSGetSelectedCategory(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__UPS_GET_SELECTED_CATEGORY  ) ); 
        }
      pInst->vUPSGetSelectedCategory(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__UPS_GET_SELECTED_CATEGORY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vUPSGETDetails(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__UPSGET_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vUPSGETDetails(ulwListEntryNr);

    }
}

ulword HSA_Navigation__ulwGetUPSERRORPOICount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPSERRORPOI_COUNT  ) ); 
        }
      ret=pInst->ulwGetUPSERRORPOICount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPSERRORPOI_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vGetUPSERRORList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPSERROR_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetUPSERRORList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_UPSERROR_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vRepeatLastNavigationAnnouncement( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__REPEAT_LAST_NAVIGATION_ANNOUNCEMENT  ) ); 
        }
      pInst->vRepeatLastNavigationAnnouncement();

    }
}

tbool HSA_Navigation__blCurrentCarPositionAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__CURRENT_CAR_POSITION_AVAILABLE  ) ); 
        }
      ret=pInst->blCurrentCarPositionAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__CURRENT_CAR_POSITION_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blCurrentCarPositionValidOnMap( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__CURRENT_CAR_POSITION_VALID_ON_MAP  ) ); 
        }
      ret=pInst->blCurrentCarPositionValidOnMap();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__CURRENT_CAR_POSITION_VALID_ON_MAP | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blComplexEntryDisclaimerSpeedThresholdAchieved( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__COMPLEX_ENTRY_DISCLAIMER_SPEED_THRESHOLD_ACHIEVED  ) ); 
        }
      ret=pInst->blComplexEntryDisclaimerSpeedThresholdAchieved();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__COMPLEX_ENTRY_DISCLAIMER_SPEED_THRESHOLD_ACHIEVED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

slword HSA_Navigation__slwConvertToDynamicIndex_RouteManeuverList(ulword ulwUniqueId)
{
    slword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_DYNAMIC_INDEX__ROUTE_MANEUVER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwUniqueId); 
        }
      ret=pInst->slwConvertToDynamicIndex_RouteManeuverList(ulwUniqueId);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_DYNAMIC_INDEX__ROUTE_MANEUVER_LIST | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Navigation__slwConvertToUniqueId_RouteManeuverList( )
{
    slword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_UNIQUE_ID__ROUTE_MANEUVER_LIST  ) ); 
        }
      ret=pInst->slwConvertToUniqueId_RouteManeuverList();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_UNIQUE_ID__ROUTE_MANEUVER_LIST | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blCurrentDestinationIsStartable( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__CURRENT_DESTINATION_IS_STARTABLE  ) ); 
        }
      ret=pInst->blCurrentDestinationIsStartable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__CURRENT_DESTINATION_IS_STARTABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vDecreaseAnnounceVolume( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DECREASE_ANNOUNCE_VOLUME  ) ); 
        }
      pInst->vDecreaseAnnounceVolume();

    }
}

void HSA_Navigation__vDeleteCurrentDestination( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DELETE_CURRENT_DESTINATION  ) ); 
        }
      pInst->vDeleteCurrentDestination();

    }
}

tbool HSA_Navigation__blDemoStartLocationAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEMO_START_LOCATION_AVAILABLE  ) ); 
        }
      ret=pInst->blDemoStartLocationAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEMO_START_LOCATION_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vDestEntryGetAddress(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_ADDRESS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vDestEntryGetAddress(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_ADDRESS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vDestEntryActivateNavDestFormItem(ulword ulwItem)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_ACTIVATE_NAV_DEST_FORM_ITEM | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwItem); 
        }
      pInst->vDestEntryActivateNavDestFormItem(ulwItem);

    }
}

void HSA_Navigation__vRestoreDestEntryActivateNavDestFormItem(ulword ulwItem)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__RESTORE_DEST_ENTRY_ACTIVATE_NAV_DEST_FORM_ITEM | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwItem); 
        }
      pInst->vRestoreDestEntryActivateNavDestFormItem(ulwItem);

    }
}

void HSA_Navigation__vDestEntryGetFavourite(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_FAVOURITE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vDestEntryGetFavourite(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_FAVOURITE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vDestEntryGetPOI(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_POI | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vDestEntryGetPOI(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_POI | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vDestEntryGetPOILastDest(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_POI_LAST_DEST  ) ); 
        }
      pInst->vDestEntryGetPOILastDest(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_POI_LAST_DEST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vDestEntryGetHome(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_HOME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vDestEntryGetHome(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_HOME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vDestEntryGetGeoPos(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_GEO_POS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vDestEntryGetGeoPos(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_GEO_POS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vDestEntryInit( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_INIT  ) ); 
        }
      pInst->vDestEntryInit();

    }
}

void HSA_Navigation__vDestEntryInitWithCountry( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_INIT_WITH_COUNTRY  ) ); 
        }
      pInst->vDestEntryInitWithCountry();

    }
}

tbool HSA_Navigation__blDestEntryIsValid( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_IS_VALID  ) ); 
        }
      ret=pInst->blDestEntryIsValid();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_IS_VALID | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blDestEntryGetHouseNumberAvailability( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_HOUSE_NUMBER_AVAILABILITY  ) ); 
        }
      ret=pInst->blDestEntryGetHouseNumberAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_HOUSE_NUMBER_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blDestMemDestEntryChanged( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_MEM_DEST_ENTRY_CHANGED  ) ); 
        }
      ret=pInst->blDestMemDestEntryChanged();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_MEM_DEST_ENTRY_CHANGED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blIsDestinationOFFMap( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_DESTINATION_OFF_MAP  ) ); 
        }
      ret=pInst->blIsDestinationOFFMap();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_DESTINATION_OFF_MAP | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blGetRouteBlockSelection( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_ROUTE_BLOCK_SELECTION  ) ); 
        }
      ret=pInst->blGetRouteBlockSelection();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_ROUTE_BLOCK_SELECTION | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vDestEntryPrepareGuidance( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_PREPARE_GUIDANCE  ) ); 
        }
      pInst->vDestEntryPrepareGuidance();

    }
}

void HSA_Navigation__vDestEntryPrepareSaving( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_PREPARE_SAVING  ) ); 
        }
      pInst->vDestEntryPrepareSaving();

    }
}

void HSA_Navigation__vDestEntryRenameFavorite( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_RENAME_FAVORITE  ) ); 
        }
      pInst->vDestEntryRenameFavorite();

    }
}

void HSA_Navigation__vDestEntrySelectAddr(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_SELECT_ADDR | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vDestEntrySelectAddr(ulwListEntryNr);

    }
}

void HSA_Navigation__vDestentrySelectWayPoint(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DESTENTRY_SELECT_WAY_POINT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vDestentrySelectWayPoint(ulwListEntryNr);

    }
}

void HSA_Navigation__vDestEntrySetData(ulword ulwType, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_SET_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_SET_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vDestEntrySetData(ulwType, ulwListEntryNr);

    }
}

void HSA_Navigation__vDestEntrySetDataCityToCityCenter( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_SET_DATA_CITY_TO_CITY_CENTER  ) ); 
        }
      pInst->vDestEntrySetDataCityToCityCenter();

    }
}

void HSA_Navigation__vDestEntryGetDataShort(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_DATA_SHORT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vDestEntryGetDataShort(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_DATA_SHORT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Navigation__blDestEntryCategoryIsPossible(ulword ulwType)
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_CATEGORY_IS_POSSIBLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      ret=pInst->blDestEntryCategoryIsPossible(ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_CATEGORY_IS_POSSIBLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vFlagDestGetName(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__FLAG_DEST_GET_NAME  ) ); 
        }
      pInst->vFlagDestGetName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__FLAG_DEST_GET_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vFlagDestSave(const GUI_String * InputString)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__FLAG_DEST_SAVE | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vFlagDestSave( InputString);

    }
}

ulword HSA_Navigation__ulwFlagDestSaveState( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__FLAG_DEST_SAVE_STATE  ) ); 
        }
      ret=pInst->ulwFlagDestSaveState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__FLAG_DEST_SAVE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetActiveAverageSpeed( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_AVERAGE_SPEED  ) ); 
        }
      ret=pInst->ulwGetActiveAverageSpeed();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_AVERAGE_SPEED | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blGetCalcRouteFails( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CALC_ROUTE_FAILS  ) ); 
        }
      ret=pInst->blGetCalcRouteFails();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CALC_ROUTE_FAILS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetCalcRouteIsRunning( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CALC_ROUTE_IS_RUNNING  ) ); 
        }
      ret=pInst->ulwGetCalcRouteIsRunning();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CALC_ROUTE_IS_RUNNING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetCalcRouteProgress( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CALC_ROUTE_PROGRESS  ) ); 
        }
      ret=pInst->ulwGetCalcRouteProgress();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CALC_ROUTE_PROGRESS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vGetCurrentDestination(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DESTINATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vGetCurrentDestination(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DESTINATION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vGetCurrentDestinationData(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DESTINATION_DATA  ) ); 
        }
      pInst->vGetCurrentDestinationData(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DESTINATION_DATA | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vGetCurrentDestinationDetail(GUI_String *out_result, ulword ulwDetail)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DESTINATION_DETAIL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDetail); 
        }
      pInst->vGetCurrentDestinationDetail(out_result, ulwDetail);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DESTINATION_DETAIL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vGetCurrentWaypointForSave(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WAYPOINT_FOR_SAVE  ) ); 
        }
      pInst->vGetCurrentWaypointForSave(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WAYPOINT_FOR_SAVE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vGetCurrentDestinationShort(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DESTINATION_SHORT  ) ); 
        }
      pInst->vGetCurrentDestinationShort(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DESTINATION_SHORT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vGetCurrentIntDestDetail(GUI_String *out_result, ulword ulwDetail)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_INT_DEST_DETAIL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDetail); 
        }
      pInst->vGetCurrentIntDestDetail(out_result, ulwDetail);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_INT_DEST_DETAIL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vSetDisambiguationCityCenterItem(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_DISAMBIGUATION_CITY_CENTER_ITEM | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetDisambiguationCityCenterItem(ulwListEntryNr);

    }
}

void HSA_Navigation__vGetDisambiguationCityCenterList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_DISAMBIGUATION_CITY_CENTER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDisambiguationCityCenterList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_DISAMBIGUATION_CITY_CENTER_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation__ulwGetDisambiguationCityCenterItemCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_DISAMBIGUATION_CITY_CENTER_ITEM_COUNT  ) ); 
        }
      ret=pInst->ulwGetDisambiguationCityCenterItemCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_DISAMBIGUATION_CITY_CENTER_ITEM_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vGetDisambiguationList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_DISAMBIGUATION_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDisambiguationList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_DISAMBIGUATION_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vSetDisambiguationItem(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_DISAMBIGUATION_ITEM | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetDisambiguationItem(ulwListEntryNr);

    }
}

ulword HSA_Navigation__ulwGetDisambiguationItemCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_DISAMBIGUATION_ITEM_COUNT  ) ); 
        }
      ret=pInst->ulwGetDisambiguationItemCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_DISAMBIGUATION_ITEM_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetGuidanceState( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_GUIDANCE_STATE  ) ); 
        }
      ret=pInst->ulwGetGuidanceState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_GUIDANCE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetIntermediateDestinationGuidanceState( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_INTERMEDIATE_DESTINATION_GUIDANCE_STATE  ) ); 
        }
      ret=pInst->ulwGetIntermediateDestinationGuidanceState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_INTERMEDIATE_DESTINATION_GUIDANCE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSetLastGuidanceState(ulword ulwState)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_LAST_GUIDANCE_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwState); 
        }
      pInst->vSetLastGuidanceState(ulwState);

    }
}

void HSA_Navigation__vRestartRouteGuidance( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__RESTART_ROUTE_GUIDANCE  ) ); 
        }
      pInst->vRestartRouteGuidance();

    }
}

tbool HSA_Navigation__blGetLastGuidanceState( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_GUIDANCE_STATE  ) ); 
        }
      ret=pInst->blGetLastGuidanceState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_GUIDANCE_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vGetPositionDataDetail(GUI_String *out_result, ulword ulwDetail)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POSITION_DATA_DETAIL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDetail); 
        }
      pInst->vGetPositionDataDetail(out_result, ulwDetail);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POSITION_DATA_DETAIL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vGetPositionDataShort(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POSITION_DATA_SHORT  ) ); 
        }
      pInst->vGetPositionDataShort(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POSITION_DATA_SHORT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Navigation__blGetTemporaryMode( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_TEMPORARY_MODE  ) ); 
        }
      ret=pInst->blGetTemporaryMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_TEMPORARY_MODE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vHomeDestGetDataShort(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__HOME_DEST_GET_DATA_SHORT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vHomeDestGetDataShort(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__HOME_DEST_GET_DATA_SHORT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Navigation__blHomeDestIsGeoPos( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__HOME_DEST_IS_GEO_POS  ) ); 
        }
      ret=pInst->blHomeDestIsGeoPos();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__HOME_DEST_IS_GEO_POS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vHomeDestInit( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__HOME_DEST_INIT  ) ); 
        }
      pInst->vHomeDestInit();

    }
}

tbool HSA_Navigation__blHomeDestIsDefined( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__HOME_DEST_IS_DEFINED  ) ); 
        }
      ret=pInst->blHomeDestIsDefined();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__HOME_DEST_IS_DEFINED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vHomeSaveCCP(const GUI_String * InputString)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__HOME_SAVE_CCP | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vHomeSaveCCP( InputString);

    }
}

void HSA_Navigation__vDestEntrySave_Home(const GUI_String * InputString)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_SAVE__HOME | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vDestEntrySave_Home( InputString);

    }
}

void HSA_Navigation__vStoreMainDestination( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__STORE_MAIN_DESTINATION  ) ); 
        }
      pInst->vStoreMainDestination();

    }
}

void HSA_Navigation__vStoreCurDestFromWaypointList(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__STORE_CUR_DEST_FROM_WAYPOINT_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vStoreCurDestFromWaypointList(ulwListEntryNr);

    }
}

void HSA_Navigation__vHomePrepareGuidance( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__HOME_PREPARE_GUIDANCE  ) ); 
        }
      pInst->vHomePrepareGuidance();

    }
}

void HSA_Navigation__vHomeCheckAvailability( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__HOME_CHECK_AVAILABILITY  ) ); 
        }
      pInst->vHomeCheckAvailability();

    }
}

void HSA_Navigation__vIncreaseAnnounceVolume( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__INCREASE_ANNOUNCE_VOLUME  ) ); 
        }
      pInst->vIncreaseAnnounceVolume();

    }
}

void HSA_Navigation__vInit( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__INIT  ) ); 
        }
      pInst->vInit();

    }
}

void HSA_Navigation__vIntDestDeleteIntermediate( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__INT_DEST_DELETE_INTERMEDIATE  ) ); 
        }
      pInst->vIntDestDeleteIntermediate();

    }
}

void HSA_Navigation__vIntDestReplaceMainDest( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__INT_DEST_REPLACE_MAIN_DEST  ) ); 
        }
      pInst->vIntDestReplaceMainDest();

    }
}

void HSA_Navigation__vIntDestInsertIntermediate( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__INT_DEST_INSERT_INTERMEDIATE  ) ); 
        }
      pInst->vIntDestInsertIntermediate();

    }
}

void HSA_Navigation__vIntDestReplaceIntermediate( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__INT_DEST_REPLACE_INTERMEDIATE  ) ); 
        }
      pInst->vIntDestReplaceIntermediate();

    }
}

tbool HSA_Navigation__blIsAvailableStreetsInCity( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_AVAILABLE_STREETS_IN_CITY  ) ); 
        }
      ret=pInst->blIsAvailableStreetsInCity();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_AVAILABLE_STREETS_IN_CITY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blIsDestinationUnique( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_DESTINATION_UNIQUE  ) ); 
        }
      ret=pInst->blIsDestinationUnique();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_DESTINATION_UNIQUE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blIsHNDefined( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_HN_DEFINED  ) ); 
        }
      ret=pInst->blIsHNDefined();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_HN_DEFINED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blIsCrossingAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_CROSSING_AVAILABLE  ) ); 
        }
      ret=pInst->blIsCrossingAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_CROSSING_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blIsHouseNumberUnique( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_HOUSE_NUMBER_UNIQUE  ) ); 
        }
      ret=pInst->blIsHouseNumberUnique();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_HOUSE_NUMBER_UNIQUE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blIsCityCenterUnique( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_CITY_CENTER_UNIQUE  ) ); 
        }
      ret=pInst->blIsCityCenterUnique();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_CITY_CENTER_UNIQUE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwIsInitialized( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_INITIALIZED  ) ); 
        }
      ret=pInst->ulwIsInitialized();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_INITIALIZED | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwIsDataAvailable( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_DATA_AVAILABLE  ) ); 
        }
      ret=pInst->ulwIsDataAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_DATA_AVAILABLE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blIsNaviDataAvailable(ulword ulwSource)
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_NAVI_DATA_AVAILABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSource); 
        }
      ret=pInst->blIsNaviDataAvailable(ulwSource);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_NAVI_DATA_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vLastCurrentDestPrepareGuidance( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__LAST_CURRENT_DEST_PREPARE_GUIDANCE  ) ); 
        }
      pInst->vLastCurrentDestPrepareGuidance();

    }
}

ulword HSA_Navigation__ulwMemoryClearState( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_CLEAR_STATE  ) ); 
        }
      ret=pInst->ulwMemoryClearState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_CLEAR_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwMemoryEntryType( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_ENTRY_TYPE  ) ); 
        }
      ret=pInst->ulwMemoryEntryType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_ENTRY_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwWaypointMemoryEntryType( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__WAYPOINT_MEMORY_ENTRY_TYPE  ) ); 
        }
      ret=pInst->ulwWaypointMemoryEntryType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__WAYPOINT_MEMORY_ENTRY_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetSelectedWaypointIndex( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_WAYPOINT_INDEX  ) ); 
        }
      ret=pInst->ulwGetSelectedWaypointIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_WAYPOINT_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwMemoryIntDestEntryType( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_INT_DEST_ENTRY_TYPE  ) ); 
        }
      ret=pInst->ulwMemoryIntDestEntryType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_INT_DEST_ENTRY_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vMemoryDestMemClear(ulword ulwSource)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_CLEAR | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSource); 
        }
      pInst->vMemoryDestMemClear(ulwSource);

    }
}

tbool HSA_Navigation__blMemoryDestMemExistsName( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_EXISTS_NAME  ) ); 
        }
      ret=pInst->blMemoryDestMemExistsName();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_EXISTS_NAME | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vMemoryDestMemGetList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vMemoryDestMemGetList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation__ulwMemoryDestMemGetListCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwMemoryDestMemGetListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vMemoryDestMemInputFilterString(const GUI_String * InputString)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_INPUT_FILTER_STRING | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vMemoryDestMemInputFilterString( InputString);

    }
}

tbool HSA_Navigation__blMemoryDestMemIsEmpty( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_IS_EMPTY  ) ); 
        }
      ret=pInst->blMemoryDestMemIsEmpty();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_IS_EMPTY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blMemoryDestMemIsFull( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_IS_FULL  ) ); 
        }
      ret=pInst->blMemoryDestMemIsFull();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_IS_FULL | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vMemoryDestMemPrepareGuidance(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_PREPARE_GUIDANCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vMemoryDestMemPrepareGuidance(ulwListEntryNr);

    }
}

void HSA_Navigation__vMemoryDestMemPrepareList( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_PREPARE_LIST  ) ); 
        }
      pInst->vMemoryDestMemPrepareList();

    }
}

void HSA_Navigation__vMemoryDestMemPrepareSearch( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_PREPARE_SEARCH  ) ); 
        }
      pInst->vMemoryDestMemPrepareSearch();

    }
}

void HSA_Navigation__vMemoryDestMemGetSearchList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_SEARCH_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vMemoryDestMemGetSearchList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_SEARCH_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation__ulwMemoryDestMemGetSearchListCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_SEARCH_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwMemoryDestMemGetSearchListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_SEARCH_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vMemoryDestMemActivateSearch( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_ACTIVATE_SEARCH  ) ); 
        }
      pInst->vMemoryDestMemActivateSearch();

    }
}

ulword HSA_Navigation__ulwMemoryDestMemSaveState( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_SAVE_STATE  ) ); 
        }
      ret=pInst->ulwMemoryDestMemSaveState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_SAVE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vMemoryDestMemGetInfoShort(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_INFO_SHORT  ) ); 
        }
      pInst->vMemoryDestMemGetInfoShort(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_INFO_SHORT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation__ulwMemoryDestMemDeleteState( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_DELETE_STATE  ) ); 
        }
      ret=pInst->ulwMemoryDestMemDeleteState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_DELETE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vMemoryLastDestClear( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_CLEAR  ) ); 
        }
      pInst->vMemoryLastDestClear();

    }
}

void HSA_Navigation__vMemoryLastDestGetInfo(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_GET_INFO  ) ); 
        }
      pInst->vMemoryLastDestGetInfo(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_GET_INFO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vMemoryLastDestGetInfoShort(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_GET_INFO_SHORT  ) ); 
        }
      pInst->vMemoryLastDestGetInfoShort(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_GET_INFO_SHORT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vMemoryLastDestGetList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_GET_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vMemoryLastDestGetList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_GET_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation__ulwMemoryLastDestGetListCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_GET_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwMemoryLastDestGetListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_GET_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blMemoryLastDestListEmpty( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_LIST_EMPTY  ) ); 
        }
      ret=pInst->blMemoryLastDestListEmpty();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_LIST_EMPTY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vMemoryLastDestPrepareGuidance(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_PREPARE_GUIDANCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vMemoryLastDestPrepareGuidance(ulwListEntryNr);

    }
}

void HSA_Navigation__vMemoryLastDestSelectForSaving(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_SELECT_FOR_SAVING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vMemoryLastDestSelectForSaving(ulwListEntryNr);

    }
}

void HSA_Navigation__vMemoryLastDestPrepareList( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_PREPARE_LIST  ) ); 
        }
      pInst->vMemoryLastDestPrepareList();

    }
}

void HSA_Navigation__vHNMatchForReduction( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__HN_MATCH_FOR_REDUCTION  ) ); 
        }
      pInst->vHNMatchForReduction();

    }
}

void HSA_Navigation__vPOIPrepareSearchEngine( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_PREPARE_SEARCH_ENGINE  ) ); 
        }
      pInst->vPOIPrepareSearchEngine();

    }
}

ulword HSA_Navigation__ulwPOIGetResultCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_GET_RESULT_COUNT  ) ); 
        }
      ret=pInst->ulwPOIGetResultCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_GET_RESULT_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blPOISearchIsAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_IS_AVAILABLE  ) ); 
        }
      ret=pInst->blPOISearchIsAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_IS_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blPOISearchStringIsServiceable( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_STRING_IS_SERVICEABLE  ) ); 
        }
      ret=pInst->blPOISearchStringIsServiceable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_STRING_IS_SERVICEABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vPOISearchParamSetCharacter(const GUI_String * InputString)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_PARAM_SET_CHARACTER | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vPOISearchParamSetCharacter( InputString);

    }
}

void HSA_Navigation__vGetPOISpellerSearchString(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POI_SPELLER_SEARCH_STRING  ) ); 
        }
      pInst->vGetPOISpellerSearchString(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POI_SPELLER_SEARCH_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vPOISearchParamSetCurrentCarPosition( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_PARAM_SET_CURRENT_CAR_POSITION  ) ); 
        }
      pInst->vPOISearchParamSetCurrentCarPosition();

    }
}

void HSA_Navigation__vPOISearchParamSetLocation( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_PARAM_SET_LOCATION  ) ); 
        }
      pInst->vPOISearchParamSetLocation();

    }
}

void HSA_Navigation__vPOISearchParamSetDestination( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_PARAM_SET_DESTINATION  ) ); 
        }
      pInst->vPOISearchParamSetDestination();

    }
}

void HSA_Navigation__vPOISearchProgressGetRadius(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_PROGRESS_GET_RADIUS  ) ); 
        }
      pInst->vPOISearchProgressGetRadius(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_PROGRESS_GET_RADIUS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vSpellerGetPOISearchInput(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_POI_SEARCH_INPUT  ) ); 
        }
      pInst->vSpellerGetPOISearchInput(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_POI_SEARCH_INPUT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vPOISelectForSaving(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SELECT_FOR_SAVING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vPOISelectForSaving(ulwListEntryNr);

    }
}

void HSA_Navigation__vPOISelectForSavingFromDetail( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SELECT_FOR_SAVING_FROM_DETAIL  ) ); 
        }
      pInst->vPOISelectForSavingFromDetail();

    }
}

void HSA_Navigation__vPOITopSelectForSaving(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_TOP_SELECT_FOR_SAVING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vPOITopSelectForSaving(ulwListEntryNr);

    }
}

void HSA_Navigation__vPOITopSelectForSavingFromDetail( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_TOP_SELECT_FOR_SAVING_FROM_DETAIL  ) ); 
        }
      pInst->vPOITopSelectForSavingFromDetail();

    }
}

ulword HSA_Navigation__ulwPOISearchResultCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_COUNT  ) ); 
        }
      ret=pInst->ulwPOISearchResultCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vPOISearchResultGetListString(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_LIST_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCell); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_LIST_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vPOISearchResultGetListString(out_result, ulwCell, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_LIST_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation__ulwPOISearchResultGetListValue(ulword ulwCell, ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_LIST_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCell); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_LIST_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwPOISearchResultGetListValue(ulwCell, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_LIST_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vPOISearchResultGetSelectedData(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_SELECTED_DATA  ) ); 
        }
      pInst->vPOISearchResultGetSelectedData(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_SELECTED_DATA | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Navigation__blPOISearchResultGetSelectedHasAdditionalInfo( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_SELECTED_HAS_ADDITIONAL_INFO  ) ); 
        }
      ret=pInst->blPOISearchResultGetSelectedHasAdditionalInfo();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_SELECTED_HAS_ADDITIONAL_INFO | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vPOISearchResultListSelectForDetails(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_LIST_SELECT_FOR_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vPOISearchResultListSelectForDetails(ulwListEntryNr);

    }
}

ulword HSA_Navigation__ulwPOIGetCurrentDetailViewIndex( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_GET_CURRENT_DETAIL_VIEW_INDEX  ) ); 
        }
      ret=pInst->ulwPOIGetCurrentDetailViewIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_GET_CURRENT_DETAIL_VIEW_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vPOIPrepareGuidance(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_PREPARE_GUIDANCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vPOIPrepareGuidance(ulwListEntryNr);

    }
}

void HSA_Navigation__vPOIPrepareGuidanceFromDetails( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_PREPARE_GUIDANCE_FROM_DETAILS  ) ); 
        }
      pInst->vPOIPrepareGuidanceFromDetails();

    }
}

void HSA_Navigation__vPOITopPrepareGuidance(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_TOP_PREPARE_GUIDANCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vPOITopPrepareGuidance(ulwListEntryNr);

    }
}

void HSA_Navigation__vPOIEditLocationInit( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_EDIT_LOCATION_INIT  ) ); 
        }
      pInst->vPOIEditLocationInit();

    }
}

void HSA_Navigation__vPOISearchStart( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_START  ) ); 
        }
      pInst->vPOISearchStart();

    }
}

void HSA_Navigation__vPOISearchGasStationStart( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_GAS_STATION_START  ) ); 
        }
      pInst->vPOISearchGasStationStart();

    }
}

void HSA_Navigation__vPOISearchParkingAreaStart( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_PARKING_AREA_START  ) ); 
        }
      pInst->vPOISearchParkingAreaStart();

    }
}

ulword HSA_Navigation__ulwPOISearchState( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_STATE  ) ); 
        }
      ret=pInst->ulwPOISearchState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vTelematicParamSetAroundCarPosition( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__TELEMATIC_PARAM_SET_AROUND_CAR_POSITION  ) ); 
        }
      pInst->vTelematicParamSetAroundCarPosition();

    }
}

void HSA_Navigation__vTelematicSearchAroundCity( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__TELEMATIC_SEARCH_AROUND_CITY  ) ); 
        }
      pInst->vTelematicSearchAroundCity();

    }
}

void HSA_Navigation__vTelematicSearchAroundDest( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__TELEMATIC_SEARCH_AROUND_DEST  ) ); 
        }
      pInst->vTelematicSearchAroundDest();

    }
}

void HSA_Navigation__vXMParamSetAroundCarPosition( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__XM_PARAM_SET_AROUND_CAR_POSITION  ) ); 
        }
      pInst->vXMParamSetAroundCarPosition();

    }
}

void HSA_Navigation__vXMSearchAroundCity( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__XM_SEARCH_AROUND_CITY  ) ); 
        }
      pInst->vXMSearchAroundCity();

    }
}

void HSA_Navigation__vXMSearchAroundDest( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__XM_SEARCH_AROUND_DEST  ) ); 
        }
      pInst->vXMSearchAroundDest();

    }
}

void HSA_Navigation__vTelematicPOIPrepareGuidanceFromDetails( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__TELEMATIC_POI_PREPARE_GUIDANCE_FROM_DETAILS  ) ); 
        }
      pInst->vTelematicPOIPrepareGuidanceFromDetails();

    }
}

void HSA_Navigation__vPOISearchStop( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_STOP  ) ); 
        }
      pInst->vPOISearchStop();

    }
}

void HSA_Navigation__vPOITopSearchStop( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_TOP_SEARCH_STOP  ) ); 
        }
      pInst->vPOITopSearchStop();

    }
}

void HSA_Navigation__vRecalculateRoute( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__RECALCULATE_ROUTE  ) ); 
        }
      pInst->vRecalculateRoute();

    }
}

void HSA_Navigation__vRouteBlockCongestionAheadApply( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_BLOCK_CONGESTION_AHEAD_APPLY  ) ); 
        }
      pInst->vRouteBlockCongestionAheadApply();

    }
}

void HSA_Navigation__vRouteBlockCongestionAheadDecrease( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_BLOCK_CONGESTION_AHEAD_DECREASE  ) ); 
        }
      pInst->vRouteBlockCongestionAheadDecrease();

    }
}

void HSA_Navigation__vRouteBlockCongestionAheadGetLength(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_BLOCK_CONGESTION_AHEAD_GET_LENGTH  ) ); 
        }
      pInst->vRouteBlockCongestionAheadGetLength(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_BLOCK_CONGESTION_AHEAD_GET_LENGTH | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vRouteBlockCongestionAheadIncrease( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_BLOCK_CONGESTION_AHEAD_INCREASE  ) ); 
        }
      pInst->vRouteBlockCongestionAheadIncrease();

    }
}

void HSA_Navigation__vRouteBlockDiscardEntries( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_BLOCK_DISCARD_ENTRIES  ) ); 
        }
      pInst->vRouteBlockDiscardEntries();

    }
}

void HSA_Navigation__vRouteCriteriaApplyInput( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_APPLY_INPUT  ) ); 
        }
      pInst->vRouteCriteriaApplyInput();

    }
}

void HSA_Navigation__vRouteCriteriaInit( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_INIT  ) ); 
        }
      pInst->vRouteCriteriaInit();

    }
}

void HSA_Navigation__vRouteCriteriaAvoidVignetteGetList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_AVOID_VIGNETTE_GET_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRouteCriteriaAvoidVignetteGetList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_AVOID_VIGNETTE_GET_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vRouteCriteriaAvoidVignetteGetCheckbox(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_AVOID_VIGNETTE_GET_CHECKBOX | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRouteCriteriaAvoidVignetteGetCheckbox(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_AVOID_VIGNETTE_GET_CHECKBOX | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation__ulwRouteCriteriaAvoidVignetteListCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_AVOID_VIGNETTE_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwRouteCriteriaAvoidVignetteListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_AVOID_VIGNETTE_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vRouteCriteriaAvoidVignetteToggleItem(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_AVOID_VIGNETTE_TOGGLE_ITEM | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRouteCriteriaAvoidVignetteToggleItem(ulwListEntryNr);

    }
}

ulword HSA_Navigation__ulwRouteCriteriaGetState(ulword ulwType)
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_GET_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      ret=pInst->ulwRouteCriteriaGetState(ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_GET_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vRouteCriteriaSetState(ulword ulwType, ulword ulwState)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_SET_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_CRITERIA_SET_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwState); 
        }
      pInst->vRouteCriteriaSetState(ulwType, ulwState);

    }
}

ulword HSA_Navigation__ulwRouteGuidanceGetMode( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_GET_MODE  ) ); 
        }
      ret=pInst->ulwRouteGuidanceGetMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_GET_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vRouteGuidanceGetRemainingDistance(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_GET_REMAINING_DISTANCE  ) ); 
        }
      pInst->vRouteGuidanceGetRemainingDistance(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_GET_REMAINING_DISTANCE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vRouteGuidanceGetRemainingTime(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_GET_REMAINING_TIME  ) ); 
        }
      pInst->vRouteGuidanceGetRemainingTime(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_GET_REMAINING_TIME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vRouteGuidanceStart( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_START  ) ); 
        }
      pInst->vRouteGuidanceStart();

    }
}

void HSA_Navigation__vRouteGuidanceStartDemo( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_START_DEMO  ) ); 
        }
      pInst->vRouteGuidanceStartDemo();

    }
}

void HSA_Navigation__vRouteGuidanceStart_Waypoint( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_START__WAYPOINT  ) ); 
        }
      pInst->vRouteGuidanceStart_Waypoint();

    }
}

void HSA_Navigation__vRouteGuidanceStartDemo_Waypoint( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_START_DEMO__WAYPOINT  ) ); 
        }
      pInst->vRouteGuidanceStartDemo_Waypoint();

    }
}

void HSA_Navigation__vRouteGuidanceStartPOI( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_START_POI  ) ); 
        }
      pInst->vRouteGuidanceStartPOI();

    }
}

void HSA_Navigation__vRouteGuidanceStop( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_STOP  ) ); 
        }
      pInst->vRouteGuidanceStop();

    }
}

void HSA_Navigation__vRouteManeuverDetailData(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_DETAIL_DATA  ) ); 
        }
      pInst->vRouteManeuverDetailData(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_DETAIL_DATA | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vRouteManeuverActivateDetailData(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_ACTIVATE_DETAIL_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRouteManeuverActivateDetailData(ulwListEntryNr);

    }
}

void HSA_Navigation__vRouteManeuverGetList(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCell); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRouteManeuverGetList(out_result, ulwCell, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation__ulwRouteManeuverGetDisTimeUnits(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_DIS_TIME_UNITS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwRouteManeuverGetDisTimeUnits(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_DIS_TIME_UNITS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwRouteManeuverMessageIconLabel(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MESSAGE_ICON_LABEL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwRouteManeuverMessageIconLabel(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MESSAGE_ICON_LABEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSetWaypointForPOISearch(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_WAYPOINT_FOR_POI_SEARCH | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetWaypointForPOISearch(ulwListEntryNr);

    }
}

ulword HSA_Navigation__ulwWaypointIconLabel(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__WAYPOINT_ICON_LABEL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwWaypointIconLabel(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__WAYPOINT_ICON_LABEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwRouteManeuverMarkedLockElement(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MARKED_LOCK_ELEMENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwRouteManeuverMarkedLockElement(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MARKED_LOCK_ELEMENT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwRouteManeuverGetListCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwRouteManeuverGetListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwRouteManeuverGetSubItemCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_SUB_ITEM_COUNT  ) ); 
        }
      ret=pInst->ulwRouteManeuverGetSubItemCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_SUB_ITEM_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blRouteManeuverListIsAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_LIST_IS_AVAILABLE  ) ); 
        }
      ret=pInst->blRouteManeuverListIsAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_LIST_IS_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blRouteBlockIsLockLimitExceeded( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_BLOCK_IS_LOCK_LIMIT_EXCEEDED  ) ); 
        }
      ret=pInst->blRouteBlockIsLockLimitExceeded();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_BLOCK_IS_LOCK_LIMIT_EXCEEDED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vRouteManeuverPrepareList( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_PREPARE_LIST  ) ); 
        }
      pInst->vRouteManeuverPrepareList();

    }
}

void HSA_Navigation__vRouteManeuverMarkLockElementIncrease( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MARK_LOCK_ELEMENT_INCREASE  ) ); 
        }
      pInst->vRouteManeuverMarkLockElementIncrease();

    }
}

void HSA_Navigation__vRouteManeuverMarkLockElementDecrease( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MARK_LOCK_ELEMENT_DECREASE  ) ); 
        }
      pInst->vRouteManeuverMarkLockElementDecrease();

    }
}

void HSA_Navigation__vRouteManeuverSetMarkLockElement(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_SET_MARK_LOCK_ELEMENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRouteManeuverSetMarkLockElement(ulwListEntryNr);

    }
}

void HSA_Navigation__vRouteManeuverSetMarkLockFirstElement(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_SET_MARK_LOCK_FIRST_ELEMENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRouteManeuverSetMarkLockFirstElement(ulwListEntryNr);

    }
}

void HSA_Navigation__vRouteManeuverSetMarkLockFirstElementFromDetails( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_SET_MARK_LOCK_FIRST_ELEMENT_FROM_DETAILS  ) ); 
        }
      pInst->vRouteManeuverSetMarkLockFirstElementFromDetails();

    }
}

void HSA_Navigation__vRouteManeuverSetMarkLockLastElementFromDetails( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_SET_MARK_LOCK_LAST_ELEMENT_FROM_DETAILS  ) ); 
        }
      pInst->vRouteManeuverSetMarkLockLastElementFromDetails();

    }
}

void HSA_Navigation__vRouteManeuverSetMarkLockLastElement(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_SET_MARK_LOCK_LAST_ELEMENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRouteManeuverSetMarkLockLastElement(ulwListEntryNr);

    }
}

tbool HSA_Navigation__blRouteManeuverMarkLockMode( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MARK_LOCK_MODE  ) ); 
        }
      ret=pInst->blRouteManeuverMarkLockMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MARK_LOCK_MODE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vRouteManeuverSetMarkLockMode(tbool blMode)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_SET_MARK_LOCK_MODE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vRouteManeuverSetMarkLockMode(blMode);

    }
}

tbool HSA_Navigation__blRouteManeuverIsCongestionDefined( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_IS_CONGESTION_DEFINED  ) ); 
        }
      ret=pInst->blRouteManeuverIsCongestionDefined();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_IS_CONGESTION_DEFINED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vRouteManeuverDeleteCongestion( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_DELETE_CONGESTION  ) ); 
        }
      pInst->vRouteManeuverDeleteCongestion();

    }
}

void HSA_Navigation__vRouteManeuverListClosed( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_LIST_CLOSED  ) ); 
        }
      pInst->vRouteManeuverListClosed();

    }
}

ulword HSA_Navigation__ulwRouteManeuverPrepareListState( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_PREPARE_LIST_STATE  ) ); 
        }
      ret=pInst->ulwRouteManeuverPrepareListState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_PREPARE_LIST_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vEnterMoveMode(ulword ulwPressedDynamicIndex)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ENTER_MOVE_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPressedDynamicIndex); 
        }
      pInst->vEnterMoveMode(ulwPressedDynamicIndex);

    }
}

void HSA_Navigation__vListEntryMoveDown(ulword ulwMovedDynamicIndex)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__LIST_ENTRY_MOVE_DOWN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMovedDynamicIndex); 
        }
      pInst->vListEntryMoveDown(ulwMovedDynamicIndex);

    }
}

void HSA_Navigation__vListEntryMoveUp(ulword ulwMovedDynamicIndex)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__LIST_ENTRY_MOVE_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMovedDynamicIndex); 
        }
      pInst->vListEntryMoveUp(ulwMovedDynamicIndex);

    }
}

void HSA_Navigation__vAbortMoveMode( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ABORT_MOVE_MODE  ) ); 
        }
      pInst->vAbortMoveMode();

    }
}

void HSA_Navigation__vLeaveMoveMode( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__LEAVE_MOVE_MODE  ) ); 
        }
      pInst->vLeaveMoveMode();

    }
}

ulword HSA_Navigation__ulwWaypointGetCurrentMoveIndex( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__WAYPOINT_GET_CURRENT_MOVE_INDEX  ) ); 
        }
      ret=pInst->ulwWaypointGetCurrentMoveIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__WAYPOINT_GET_CURRENT_MOVE_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vDeleteAndInsertWaypoint(ulword ulwListEntryNumber)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DELETE_AND_INSERT_WAYPOINT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      pInst->vDeleteAndInsertWaypoint(ulwListEntryNumber);

    }
}

void HSA_Navigation__vDeleteWaypoint(ulword ulwListEntryNumber)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DELETE_WAYPOINT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      pInst->vDeleteWaypoint(ulwListEntryNumber);

    }
}

tbool HSA_Navigation__blRouteOptionDynRouteGetState( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_OPTION_DYN_ROUTE_GET_STATE  ) ); 
        }
      ret=pInst->blRouteOptionDynRouteGetState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_OPTION_DYN_ROUTE_GET_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vRouteOptionDynRouteSetState(tbool blMode)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_OPTION_DYN_ROUTE_SET_STATE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vRouteOptionDynRouteSetState(blMode);

    }
}

ulword HSA_Navigation__ulwRouteOptionGetState( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_OPTION_GET_STATE  ) ); 
        }
      ret=pInst->ulwRouteOptionGetState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_OPTION_GET_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vRouteOptionSetState(ulword ulwState)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_OPTION_SET_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwState); 
        }
      pInst->vRouteOptionSetState(ulwState);

    }
}

void HSA_Navigation__vSetCurrentPositionAsHomeDest( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_CURRENT_POSITION_AS_HOME_DEST  ) ); 
        }
      pInst->vSetCurrentPositionAsHomeDest();

    }
}

void HSA_Navigation__vSetTemporaryMode(tbool blMode)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_TEMPORARY_MODE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vSetTemporaryMode(blMode);

    }
}

void HSA_Navigation__vSetDemoPosition( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_DEMO_POSITION  ) ); 
        }
      pInst->vSetDemoPosition();

    }
}

ulword HSA_Navigation__ulwSetupGetAnnouncement( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_ANNOUNCEMENT  ) ); 
        }
      ret=pInst->ulwSetupGetAnnouncement();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_ANNOUNCEMENT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwSetupGetAutozoom( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_AUTOZOOM  ) ); 
        }
      ret=pInst->ulwSetupGetAutozoom();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_AUTOZOOM | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blSetupGetDemoMode( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_DEMO_MODE  ) ); 
        }
      ret=pInst->blSetupGetDemoMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_DEMO_MODE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blSetupDeactivateDemoModeSetting( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_DEACTIVATE_DEMO_MODE_SETTING  ) ); 
        }
      ret=pInst->blSetupDeactivateDemoModeSetting();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_DEACTIVATE_DEMO_MODE_SETTING | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blSetupOptionsChanged( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_OPTIONS_CHANGED  ) ); 
        }
      ret=pInst->blSetupOptionsChanged();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_OPTIONS_CHANGED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSetupSetAutozoom(ulword ulwMode)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_SET_AUTOZOOM | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vSetupSetAutozoom(ulwMode);

    }
}

void HSA_Navigation__vSetupSetDemoMode(tbool blMode)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SETUP_SET_DEMO_MODE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vSetupSetDemoMode(blMode);

    }
}

void HSA_Navigation__vSpellerInitInput(ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INIT_INPUT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vSpellerInitInput(ulwType);

    }
}

void HSA_Navigation__vSpellerInitRestore(ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INIT_RESTORE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vSpellerInitRestore(ulwType);

    }
}

void HSA_Navigation__vSpellerCharacterInput(const GUI_String * InputString)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_CHARACTER_INPUT | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSpellerCharacterInput( InputString);

    }
}

void HSA_Navigation__vSpellerDiscardAllInput( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_DISCARD_ALL_INPUT  ) ); 
        }
      pInst->vSpellerDiscardAllInput();

    }
}

void HSA_Navigation__vSpellerGetNameInput(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_NAME_INPUT  ) ); 
        }
      pInst->vSpellerGetNameInput(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_NAME_INPUT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vSpellerSetNameInput( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_NAME_INPUT  ) ); 
        }
      pInst->vSpellerSetNameInput();

    }
}

ulword HSA_Navigation__ulwSpellerMatchGetCount(ulword ulwType)
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_COUNT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      ret=pInst->ulwSpellerMatchGetCount(ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwMatchGetListCount(ulword ulwType)
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MATCH_GET_LIST_COUNT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      ret=pInst->ulwMatchGetListCount(ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MATCH_GET_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSpellerMatchGetFirst(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_FIRST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vSpellerMatchGetFirst(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_FIRST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vSpellerGetFavSearchInput(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_FAV_SEARCH_INPUT  ) ); 
        }
      pInst->vSpellerGetFavSearchInput(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_FAV_SEARCH_INPUT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Navigation__blSpellerInputOccurred( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INPUT_OCCURRED  ) ); 
        }
      ret=pInst->blSpellerInputOccurred();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INPUT_OCCURRED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSpellerMatchGetList(GUI_String *out_result, ulword ulwType, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSpellerMatchGetList(out_result, ulwType, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vSpellerMatchActivateList(ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_ACTIVATE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vSpellerMatchActivateList(ulwType);

    }
}

void HSA_Navigation__vSpellerMatchActivateListRestore(ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_ACTIVATE_LIST_RESTORE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vSpellerMatchActivateListRestore(ulwType);

    }
}

void HSA_Navigation__vSpellerMatchGetPossibleLetters(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_POSSIBLE_LETTERS  ) ); 
        }
      pInst->vSpellerMatchGetPossibleLetters(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_POSSIBLE_LETTERS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Navigation__blSpellerInvertGetLetterFunction( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION  ) ); 
        }
      ret=pInst->blSpellerInvertGetLetterFunction();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSpellerGetHighlightedText(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_HIGHLIGHTED_TEXT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vSpellerGetHighlightedText(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_HIGHLIGHTED_TEXT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Navigation__blSpellerEnableMatchSpeller( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_ENABLE_MATCH_SPELLER  ) ); 
        }
      ret=pInst->blSpellerEnableMatchSpeller();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_ENABLE_MATCH_SPELLER | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blSpellerEnableHouseNumSpeller( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_ENABLE_HOUSE_NUM_SPELLER  ) ); 
        }
      ret=pInst->blSpellerEnableHouseNumSpeller();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_ENABLE_HOUSE_NUM_SPELLER | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwSpellerGetCursorPos( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS  ) ); 
        }
      ret=pInst->ulwSpellerGetCursorPos();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSpellerSetMaxCharCount(ulword ulwCount)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_MAX_CHAR_COUNT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCount); 
        }
      pInst->vSpellerSetMaxCharCount(ulwCount);

    }
}

void HSA_Navigation__vSpellerSetInitialText(const GUI_String * InitialString)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_INITIAL_TEXT | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InitialString->ulwLen_+1, InitialString->pubBuffer_);
         }
      pInst->vSpellerSetInitialText( InitialString);

    }
}

void HSA_Navigation__vStartEditingDemoMode( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__START_EDITING_DEMO_MODE  ) ); 
        }
      pInst->vStartEditingDemoMode();

    }
}

void HSA_Navigation__vStopEditingDemoMode( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__STOP_EDITING_DEMO_MODE  ) ); 
        }
      pInst->vStopEditingDemoMode();

    }
}

void HSA_Navigation__vStopCalcRoute( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__STOP_CALC_ROUTE  ) ); 
        }
      pInst->vStopCalcRoute();

    }
}

ulword HSA_Navigation__ulwWaitSyncState(ulword ulwType)
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      ret=pInst->ulwWaitSyncState(ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vRouteOptionDynRouteUserConfirm( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_OPTION_DYN_ROUTE_USER_CONFIRM  ) ); 
        }
      pInst->vRouteOptionDynRouteUserConfirm();

    }
}

ulword HSA_Navigation__ulwGetDynRouteOption( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_DYN_ROUTE_OPTION  ) ); 
        }
      ret=pInst->ulwGetDynRouteOption();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_DYN_ROUTE_OPTION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSetDynRouteOption(ulword ulwMode)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_DYN_ROUTE_OPTION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vSetDynRouteOption(ulwMode);

    }
}

tbool HSA_Navigation__blIsMemoryLimitReached( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_MEMORY_LIMIT_REACHED  ) ); 
        }
      ret=pInst->blIsMemoryLimitReached();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_MEMORY_LIMIT_REACHED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vShowCategoryList( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SHOW_CATEGORY_LIST  ) ); 
        }
      pInst->vShowCategoryList();

    }
}

void HSA_Navigation__vGetHouseNo_NAR(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_HOUSE_NO_NAR  ) ); 
        }
      pInst->vGetHouseNo_NAR(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_HOUSE_NO_NAR | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vPoiSetCategory_NAR(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SET_CATEGORY_NAR | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vPoiSetCategory_NAR(ulwListEntryNr);

    }
}

ulword HSA_Navigation__ulwGetPOIListType( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POI_LIST_TYPE  ) ); 
        }
      ret=pInst->ulwGetPOIListType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POI_LIST_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blIsPOICategoryListPrepared(ulword ulwType)
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_POI_CATEGORY_LIST_PREPARED | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      ret=pInst->blIsPOICategoryListPrepared(ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__IS_POI_CATEGORY_LIST_PREPARED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetPOICategoryCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POI_CATEGORY_COUNT  ) ); 
        }
      ret=pInst->ulwGetPOICategoryCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POI_CATEGORY_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetPOIAttributeCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POI_ATTRIBUTE_COUNT  ) ); 
        }
      ret=pInst->ulwGetPOIAttributeCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POI_ATTRIBUTE_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vRestorePOICategoryList( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__RESTORE_POI_CATEGORY_LIST  ) ); 
        }
      pInst->vRestorePOICategoryList();

    }
}

ulword HSA_Navigation__ulwGetLastPOIListSelIndex( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_POI_LIST_SEL_INDEX  ) ); 
        }
      ret=pInst->ulwGetLastPOIListSelIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_POI_LIST_SEL_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vPOIGetSelectedCategory(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_GET_SELECTED_CATEGORY  ) ); 
        }
      pInst->vPOIGetSelectedCategory(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_GET_SELECTED_CATEGORY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation__vMemoryWaypointPrepareList( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_PREPARE_LIST  ) ); 
        }
      pInst->vMemoryWaypointPrepareList();

    }
}

void HSA_Navigation__vExitWaypointList( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__EXIT_WAYPOINT_LIST  ) ); 
        }
      pInst->vExitWaypointList();

    }
}

ulword HSA_Navigation__ulwMemoryWaypointGetListCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwMemoryWaypointGetListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vMemoryWaypointGetList(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCell); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vMemoryWaypointGetList(out_result, ulwCell, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation__ulwMemoryWaypointGetDirection(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_DIRECTION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwMemoryWaypointGetDirection(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_DIRECTION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation__blMemoryWaypointMemIsFull( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_MEM_IS_FULL  ) ); 
        }
      ret=pInst->blMemoryWaypointMemIsFull();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_MEM_IS_FULL | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vWaypointPrepareSaving( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__WAYPOINT_PREPARE_SAVING  ) ); 
        }
      pInst->vWaypointPrepareSaving();

    }
}

ulword HSA_Navigation__ulwRouteManeuverGetListUnit( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_LIST_UNIT  ) ); 
        }
      ret=pInst->ulwRouteManeuverGetListUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_LIST_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwPOISearchResultGetListUnit( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_LIST_UNIT  ) ); 
        }
      ret=pInst->ulwPOISearchResultGetListUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_LIST_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetPositionDataDetailUnit( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POSITION_DATA_DETAIL_UNIT  ) ); 
        }
      ret=pInst->ulwGetPositionDataDetailUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_POSITION_DATA_DETAIL_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwMemoryWaypointGetListUnit( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_LIST_UNIT  ) ); 
        }
      ret=pInst->ulwMemoryWaypointGetListUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_LIST_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vSetGnsssatSystemType(ulword ulwGnssType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_GNSSSAT_SYSTEM_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwGnssType); 
        }
      pInst->vSetGnsssatSystemType(ulwGnssType);

    }
}

ulword HSA_Navigation__ulwGetGnsssatSystemType( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_GNSSSAT_SYSTEM_TYPE  ) ); 
        }
      ret=pInst->ulwGetGnsssatSystemType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_GNSSSAT_SYSTEM_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwGetLanguageDependentStringsUnit( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_LANGUAGE_DEPENDENT_STRINGS_UNIT  ) ); 
        }
      ret=pInst->ulwGetLanguageDependentStringsUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_LANGUAGE_DEPENDENT_STRINGS_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vDestEntryGetWaypoint(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_WAYPOINT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vDestEntryGetWaypoint(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_WAYPOINT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Navigation__blStreetPossibleAfterCity( )
{
    tbool ret = false;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__STREET_POSSIBLE_AFTER_CITY  ) ); 
        }
      ret=pInst->blStreetPossibleAfterCity();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__STREET_POSSIBLE_AFTER_CITY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation__ulwDestEntryGetSDSInputType( )
{
    ulword ret = 0;
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_SDS_INPUT_TYPE  ) ); 
        }
      ret=pInst->ulwDestEntryGetSDSInputType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__DEST_ENTRY_GET_SDS_INPUT_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation__vTCUJourneyPrepareGuidance( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__TCU_JOURNEY_PREPARE_GUIDANCE  ) ); 
        }
      pInst->vTCUJourneyPrepareGuidance();

    }
}

void HSA_Navigation__vTcuJourneyPrepareShowOnMap( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__TCU_JOURNEY_PREPARE_SHOW_ON_MAP  ) ); 
        }
      pInst->vTcuJourneyPrepareShowOnMap();

    }
}

void HSA_Navigation__vSetTCUModeActive( )
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__SET_TCU_MODE_ACTIVE  ) ); 
        }
      pInst->vSetTCUModeActive();

    }
}

void HSA_Navigation__vGetSelectedPoiCategory(GUI_String *out_result)
{
    
    clHSA_Navigation_Base *pInst=clHSA_Navigation_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_POI_CATEGORY  ) ); 
        }
      pInst->vGetSelectedPoiCategory(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_POI_CATEGORY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

#ifdef __cplusplus
}
#endif

