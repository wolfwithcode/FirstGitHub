/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Navigation_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_Navigation_Wrapper_H
#define _HSA_Navigation_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: SetupToggleHighwayEntrancePictureState
 * NISSAN 2.0
 * NISSAN
 */
void HSA_Navigation__vSetupToggleHighwayEntrancePictureState( void);

/**
 * Function: SetupGetHighwayEntrancePictureState
 * NISSAN 2.0
 * NISSAN
 */
tbool HSA_Navigation__blSetupGetHighwayEntrancePictureState( void);

/**
 * Function: SetupGetSpeedLimit
 * NISSAN 2.0
 * NISSAN
 */
tbool HSA_Navigation__blSetupGetSpeedLimit( void);

/**
 * Function: SetupSetSpeedLimit
 * NISSAN 2.0
 * NISSAN
 */
void HSA_Navigation__vSetupSetSpeedLimit(tbool blMode);

/**
 * Function: RequestNAVTEQFilename
 * NISSAN 1.5
 * NISSAN
 */
void HSA_Navigation__vRequestNAVTEQFilename( void);

/**
 * Function: GetNAVTEQFilename
 * NISSAN 1.5
 * NISSAN
 */
void HSA_Navigation__vGetNAVTEQFilename(GUI_String *out_result);

/**
 * Function: GetNAVTEQCheckDigit
 * NISSAN 1.5
 * NISSAN
 */
void HSA_Navigation__vGetNAVTEQCheckDigit(GUI_String *out_result);

/**
 * Function: SetDemoPositionFromMapInput
 * NISSAN UP2
 * NISSAN
 */
void HSA_Navigation__vSetDemoPositionFromMapInput( void);

/**
 * Function: MapInputSave_Home
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vMapInputSave_Home(const GUI_String * InputString);

/**
 * Function: StoreCurrPositionAsWayPoint
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vStoreCurrPositionAsWayPoint(const GUI_String * InputString);

/**
 * Function: POISearchNearByFoodStart_NAR
 * NISSAN_NAR
 * NISSAN
 */
void HSA_Navigation__vPOISearchNearByFoodStart_NAR( void);

/**
 * Function: POISearchNearbyATMStart
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vPOISearchNearbyATMStart( void);

/**
 * Function: StoreCurrentDestAsWayPoint
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vStoreCurrentDestAsWayPoint( void);

/**
 * Function: StoreCurDestAsWayPoint
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vStoreCurDestAsWayPoint(ulword ulwListEntryNr);

/**
 * Function: GetSkippedWaypointName
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vGetSkippedWaypointName(GUI_String *out_result);

/**
 * Function: SkipWaypointAndStartRouteGuidance
 * B1
 * NISSAN
 */
void HSA_Navigation__vSkipWaypointAndStartRouteGuidance( void);

/**
 * Function: POISelectByCategory_NAR
 * NISSAN_NAR
 * NISSAN
 */
void HSA_Navigation__vPOISelectByCategory_NAR( void);

/**
 * Function: POIAlongRoutePrepareSearchEngine
 * NISSAN 2.0
 * NISSAN
 */
void HSA_Navigation__vPOIAlongRoutePrepareSearchEngine( void);

/**
 * Function: PoiSetCategoryAlongRoute
 * NISSAN 2.0
 * NISSAN
 */
void HSA_Navigation__vPoiSetCategoryAlongRoute(ulword ulwCategoryNo);

/**
 * Function: IsListPrepared_NAR
 * NISSAN_NAR
 * NISSAN
 */
ulword HSA_Navigation__ulwIsListPrepared_NAR( void);

/**
 * Function: GetPOICategoryList_NAR
 * NISSAN_NAR
 * NISSAN
 */
void HSA_Navigation__vGetPOICategoryList_NAR(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: SaveHouseNo_NAR
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vSaveHouseNo_NAR(ulword ulwType);

/**
 * Function: GetCurrentCountryCarPlate
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vGetCurrentCountryCarPlate(GUI_String *out_result);

/**
 * Function: InitializeSpeedProfile
 * NISSAN 1.5
 * NISSAN
 */
void HSA_Navigation__vInitializeSpeedProfile( void);

/**
 * Function: ToggleUserSpeedProfile
 * NISSAN 1.5
 * NISSAN
 */
void HSA_Navigation__vToggleUserSpeedProfile( void);

/**
 * Function: IsUserSpeedProfileOn
 * NISSAN 1.5
 * NISSAN
 */
tbool HSA_Navigation__blIsUserSpeedProfileOn( void);

/**
 * Function: SetSpeedProfile
 * NISSAN 1.5
 * NISSAN
 */
void HSA_Navigation__vSetSpeedProfile(ulword ulwSpeedProfile, tbool blSpeedProfileDirection);

/**
 * Function: GetSpeedProfile
 * NISSAN 1.5
 * NISSAN
 */
void HSA_Navigation__vGetSpeedProfile(GUI_String *out_result, ulword ulwSpeedProfile);

/**
 * Function: ConfirmSpeedProfile
 * NISSAN 1.5
 * NISSAN
 */
void HSA_Navigation__vConfirmSpeedProfile( void);

/**
 * Function: GetLanguageDependentStrings
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vGetLanguageDependentStrings(GUI_String *out_result, ulword ulwType);

/**
 * Function: IsLIMServiceAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation__blIsLIMServiceAvailable( void);

/**
 * Function: GetCurrentCountryIndex
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetCurrentCountryIndex( void);

/**
 * Function: SDGetInfo
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vSDGetInfo(GUI_String *out_result);

/**
 * Function: MapInputPrepareSaving
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vMapInputPrepareSaving( void);

/**
 * Function: MapInputGetNameForDestIdent
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vMapInputGetNameForDestIdent(GUI_String *out_result);

/**
 * Function: DestEntrySave
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vDestEntrySave(ulword ulwSave);

/**
 * Function: UPSGetSelectedPOI
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vUPSGetSelectedPOI(GUI_String *out_result);

/**
 * Function: UPSPOIPrepareGuidanceFromDetails
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vUPSPOIPrepareGuidanceFromDetails( void);

/**
 * Function: IsUPSCategoryPrepared
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation__blIsUPSCategoryPrepared( void);

/**
 * Function: OnUPSDataUpdate
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation__blOnUPSDataUpdate( void);

/**
 * Function: IsUPSPOIListPrepared
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation__blIsUPSPOIListPrepared( void);

/**
 * Function: GetUPSDistance
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetUPSDistance( void);

/**
 * Function: GetPOIProximityWarning
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetPOIProximityWarning( void);

/**
 * Function: GetUPSPOIDetail
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vGetUPSPOIDetail(GUI_String *out_result);

/**
 * Function: FlagEntryPrepareSaving
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vFlagEntryPrepareSaving( void);

/**
 * Function: FlagEntrySave
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vFlagEntrySave( void);

/**
 * Function: IsCategoryRestorePossible
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation__blIsCategoryRestorePossible( void);

/**
 * Function: RestoreCategory
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vRestoreCategory( void);

/**
 * Function: GetUPSProximityWarning
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetUPSProximityWarning( void);

/**
 * Function: ToggleSetPOIProximityWarning
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vToggleSetPOIProximityWarning( void);

/**
 * Function: DeleteUPS
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vDeleteUPS( void);

/**
 * Function: UPSDeleteState
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwUPSDeleteState( void);

/**
 * Function: SetUPSDistance
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vSetUPSDistance(ulword ulwState);

/**
 * Function: GetTravelAdvantageValues
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetTravelAdvantageValues(ulword ulwRouteType);

/**
 * Function: DynRouteConsiderUpdate
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vDynRouteConsiderUpdate(ulword ulwRouteType);

/**
 * Function: GetCurrentCode
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vGetCurrentCode(GUI_String *out_result);

/**
 * Function: IsUPSDataAvailableInSystem
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation__blIsUPSDataAvailableInSystem( void);

/**
 * Function: StartListCategory
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vStartListCategory( void);

/**
 * Function: IsUPSDataAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation__blIsUPSDataAvailable( void);

/**
 * Function: GetUPSDownloadProgress
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetUPSDownloadProgress( void);

/**
 * Function: GetUPSDownloadState
 * NISSAN 1.5
 * NISSAN
 */
ulword HSA_Navigation__ulwGetUPSDownloadState( void);

/**
 * Function: StopUPSDownload
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vStopUPSDownload( void);

/**
 * Function: StartUPSDownload
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vStartUPSDownload( void);

/**
 * Function: ToggleLaneInformation
 * Nissan 2.0
 * NISSAN
 */
void HSA_Navigation__vToggleLaneInformation( void);

/**
 * Function: SetupGetLaneGuidanceSymbolsState
 * 
 * NISSAN
 */
tbool HSA_Navigation__blSetupGetLaneGuidanceSymbolsState( void);

/**
 * Function: GetUPSCategoryCount
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetUPSCategoryCount( void);

/**
 * Function: GetUPSCategoryList
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vGetUPSCategoryList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: UPSSetCategory
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vUPSSetCategory(ulword ulwListEntryNr);

/**
 * Function: GetUPSPOICount
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetUPSPOICount( void);

/**
 * Function: GetUPSPOIList
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vGetUPSPOIList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: UPSGetSelectedCategory
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vUPSGetSelectedCategory(GUI_String *out_result);

/**
 * Function: UPSGETDetails
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vUPSGETDetails(ulword ulwListEntryNr);

/**
 * Function: GetUPSERRORPOICount
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetUPSERRORPOICount( void);

/**
 * Function: GetUPSERRORList
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vGetUPSERRORList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: RepeatLastNavigationAnnouncement
 * B
 * NISSAN
 */
void HSA_Navigation__vRepeatLastNavigationAnnouncement( void);

/**
 * Function: CurrentCarPositionAvailable
 * B1
 * NISSAN
 */
tbool HSA_Navigation__blCurrentCarPositionAvailable( void);

/**
 * Function: CurrentCarPositionValidOnMap
 * B1
 * NISSAN
 */
tbool HSA_Navigation__blCurrentCarPositionValidOnMap( void);

/**
 * Function: ComplexEntryDisclaimerSpeedThresholdAchieved
 * B
 * NISSAN
 */
tbool HSA_Navigation__blComplexEntryDisclaimerSpeedThresholdAchieved( void);

/**
 * Function: ConvertToDynamicIndex_RouteManeuverList
 * B
 * NISSAN
 */
slword HSA_Navigation__slwConvertToDynamicIndex_RouteManeuverList(ulword ulwUniqueId);

/**
 * Function: ConvertToUniqueId_RouteManeuverList
 * B
 * NISSAN
 */
slword HSA_Navigation__slwConvertToUniqueId_RouteManeuverList( void);

/**
 * Function: CurrentDestinationIsStartable
 * B
 * NISSAN
 */
tbool HSA_Navigation__blCurrentDestinationIsStartable( void);

/**
 * Function: DecreaseAnnounceVolume
 * B1
 * NISSAN
 */
void HSA_Navigation__vDecreaseAnnounceVolume( void);

/**
 * Function: DeleteCurrentDestination
 * B
 * NISSAN
 */
void HSA_Navigation__vDeleteCurrentDestination( void);

/**
 * Function: DemoStartLocationAvailable
 * B1
 * NISSAN
 */
tbool HSA_Navigation__blDemoStartLocationAvailable( void);

/**
 * Function: DestEntryGetAddress
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryGetAddress(GUI_String *out_result, ulword ulwType);

/**
 * Function: DestEntryActivateNavDestFormItem
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryActivateNavDestFormItem(ulword ulwItem);

/**
 * Function: RestoreDestEntryActivateNavDestFormItem
 * B
 * NISSAN
 */
void HSA_Navigation__vRestoreDestEntryActivateNavDestFormItem(ulword ulwItem);

/**
 * Function: DestEntryGetFavourite
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryGetFavourite(GUI_String *out_result, ulword ulwType);

/**
 * Function: DestEntryGetPOI
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryGetPOI(GUI_String *out_result, ulword ulwType);

/**
 * Function: DestEntryGetPOILastDest
 * MMS-230849
 * NISSAN
 */
void HSA_Navigation__vDestEntryGetPOILastDest(GUI_String *out_result);

/**
 * Function: DestEntryGetHome
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryGetHome(GUI_String *out_result, ulword ulwType);

/**
 * Function: DestEntryGetGeoPos
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryGetGeoPos(GUI_String *out_result, ulword ulwType);

/**
 * Function: DestEntryInit
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryInit( void);

/**
 * Function: DestEntryInitWithCountry
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryInitWithCountry( void);

/**
 * Function: DestEntryIsValid
 * B
 * NISSAN
 */
tbool HSA_Navigation__blDestEntryIsValid( void);

/**
 * Function: DestEntryGetHouseNumberAvailability
 * B
 * NISSAN
 */
tbool HSA_Navigation__blDestEntryGetHouseNumberAvailability( void);

/**
 * Function: DestMemDestEntryChanged
 * B
 * NISSAN
 */
tbool HSA_Navigation__blDestMemDestEntryChanged( void);

/**
 * Function: IsDestinationOFFMap
 * B
 * NISSAN
 */
tbool HSA_Navigation__blIsDestinationOFFMap( void);

/**
 * Function: GetRouteBlockSelection
 * NISSAN_LCN2Kai
 * NISSAN
 */
tbool HSA_Navigation__blGetRouteBlockSelection( void);

/**
 * Function: DestEntryPrepareGuidance
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryPrepareGuidance( void);

/**
 * Function: DestEntryPrepareSaving
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryPrepareSaving( void);

/**
 * Function: DestEntryRenameFavorite
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryRenameFavorite( void);

/**
 * Function: DestEntrySelectAddr
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntrySelectAddr(ulword ulwListEntryNr);

/**
 * Function: DestentrySelectWayPoint
 * B
 * NISSAN
 */
void HSA_Navigation__vDestentrySelectWayPoint(ulword ulwListEntryNr);

/**
 * Function: DestEntrySetData
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntrySetData(ulword ulwType, ulword ulwListEntryNr);

/**
 * Function: DestEntrySetDataCityToCityCenter
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntrySetDataCityToCityCenter( void);

/**
 * Function: DestEntryGetDataShort
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryGetDataShort(GUI_String *out_result, ulword ulwType);

/**
 * Function: DestEntryCategoryIsPossible
 * B
 * NISSAN
 */
tbool HSA_Navigation__blDestEntryCategoryIsPossible(ulword ulwType);

/**
 * Function: FlagDestGetName
 * B-deprecated
 * NISSAN
 */
void HSA_Navigation__vFlagDestGetName(GUI_String *out_result);

/**
 * Function: FlagDestSave
 * B
 * NISSAN
 */
void HSA_Navigation__vFlagDestSave(const GUI_String * InputString);

/**
 * Function: FlagDestSaveState
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwFlagDestSaveState( void);

/**
 * Function: GetActiveAverageSpeed
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwGetActiveAverageSpeed( void);

/**
 * Function: GetCalcRouteFails
 * B1
 * NISSAN
 */
tbool HSA_Navigation__blGetCalcRouteFails( void);

/**
 * Function: GetCalcRouteIsRunning
 * B1
 * NISSAN
 */
ulword HSA_Navigation__ulwGetCalcRouteIsRunning( void);

/**
 * Function: GetCalcRouteProgress
 * B1
 * NISSAN
 */
ulword HSA_Navigation__ulwGetCalcRouteProgress( void);

/**
 * Function: GetCurrentDestination
 * B
 * NISSAN
 */
void HSA_Navigation__vGetCurrentDestination(GUI_String *out_result, ulword ulwType);

/**
 * Function: GetCurrentDestinationData
 * B
 * NISSAN
 */
void HSA_Navigation__vGetCurrentDestinationData(GUI_String *out_result);

/**
 * Function: GetCurrentDestinationDetail
 * B1
 * NISSAN
 */
void HSA_Navigation__vGetCurrentDestinationDetail(GUI_String *out_result, ulword ulwDetail);

/**
 * Function: GetCurrentWaypointForSave
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation__vGetCurrentWaypointForSave(GUI_String *out_result);

/**
 * Function: GetCurrentDestinationShort
 * B
 * NISSAN
 */
void HSA_Navigation__vGetCurrentDestinationShort(GUI_String *out_result);

/**
 * Function: GetCurrentIntDestDetail
 * B
 * NISSAN
 */
void HSA_Navigation__vGetCurrentIntDestDetail(GUI_String *out_result, ulword ulwDetail);

/**
 * Function: SetDisambiguationCityCenterItem
 * B
 * NISSAN
 */
void HSA_Navigation__vSetDisambiguationCityCenterItem(ulword ulwListEntryNr);

/**
 * Function: GetDisambiguationCityCenterList
 * B
 * NISSAN
 */
void HSA_Navigation__vGetDisambiguationCityCenterList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetDisambiguationCityCenterItemCount
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwGetDisambiguationCityCenterItemCount( void);

/**
 * Function: GetDisambiguationList
 * B
 * NISSAN
 */
void HSA_Navigation__vGetDisambiguationList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: SetDisambiguationItem
 * B
 * NISSAN
 */
void HSA_Navigation__vSetDisambiguationItem(ulword ulwListEntryNr);

/**
 * Function: GetDisambiguationItemCount
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwGetDisambiguationItemCount( void);

/**
 * Function: GetGuidanceState
 * B1
 * NISSAN
 */
ulword HSA_Navigation__ulwGetGuidanceState( void);

/**
 * Function: GetIntermediateDestinationGuidanceState
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwGetIntermediateDestinationGuidanceState( void);

/**
 * Function: SetLastGuidanceState
 * B
 * NISSAN
 */
void HSA_Navigation__vSetLastGuidanceState(ulword ulwState);

/**
 * Function: RestartRouteGuidance
 * B
 * NISSAN
 */
void HSA_Navigation__vRestartRouteGuidance( void);

/**
 * Function: GetLastGuidanceState
 * B
 * NISSAN
 */
tbool HSA_Navigation__blGetLastGuidanceState( void);

/**
 * Function: GetPositionDataDetail
 * B1
 * NISSAN
 */
void HSA_Navigation__vGetPositionDataDetail(GUI_String *out_result, ulword ulwDetail);

/**
 * Function: GetPositionDataShort
 * B
 * NISSAN
 */
void HSA_Navigation__vGetPositionDataShort(GUI_String *out_result);

/**
 * Function: GetTemporaryMode
 * B
 * NISSAN
 */
tbool HSA_Navigation__blGetTemporaryMode( void);

/**
 * Function: HomeDestGetDataShort
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vHomeDestGetDataShort(GUI_String *out_result, ulword ulwType);

/**
 * Function: HomeDestIsGeoPos
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation__blHomeDestIsGeoPos( void);

/**
 * Function: HomeDestInit
 * B
 * NISSAN
 */
void HSA_Navigation__vHomeDestInit( void);

/**
 * Function: HomeDestIsDefined
 * B
 * NISSAN
 */
tbool HSA_Navigation__blHomeDestIsDefined( void);

/**
 * Function: HomeSaveCCP
 * B
 * NISSAN
 */
void HSA_Navigation__vHomeSaveCCP(const GUI_String * InputString);

/**
 * Function: DestEntrySave_Home
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vDestEntrySave_Home(const GUI_String * InputString);

/**
 * Function: StoreMainDestination
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vStoreMainDestination( void);

/**
 * Function: StoreCurDestFromWaypointList
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vStoreCurDestFromWaypointList(ulword ulwListEntryNr);

/**
 * Function: HomePrepareGuidance
 * B
 * NISSAN
 */
void HSA_Navigation__vHomePrepareGuidance( void);

/**
 * Function: HomeCheckAvailability
 * B
 * NISSAN
 */
void HSA_Navigation__vHomeCheckAvailability( void);

/**
 * Function: IncreaseAnnounceVolume
 * B1
 * NISSAN
 */
void HSA_Navigation__vIncreaseAnnounceVolume( void);

/**
 * Function: Init
 * B1
 * NISSAN
 */
void HSA_Navigation__vInit( void);

/**
 * Function: IntDestDeleteIntermediate
 * B
 * NISSAN
 */
void HSA_Navigation__vIntDestDeleteIntermediate( void);

/**
 * Function: IntDestReplaceMainDest
 * B
 * NISSAN
 */
void HSA_Navigation__vIntDestReplaceMainDest( void);

/**
 * Function: IntDestInsertIntermediate
 * B
 * NISSAN
 */
void HSA_Navigation__vIntDestInsertIntermediate( void);

/**
 * Function: IntDestReplaceIntermediate
 * B
 * NISSAN
 */
void HSA_Navigation__vIntDestReplaceIntermediate( void);

/**
 * Function: IsAvailableStreetsInCity
 * B
 * NISSAN
 */
tbool HSA_Navigation__blIsAvailableStreetsInCity( void);

/**
 * Function: IsDestinationUnique
 * B
 * NISSAN
 */
tbool HSA_Navigation__blIsDestinationUnique( void);

/**
 * Function: IsHNDefined
 * B
 * NISSAN
 */
tbool HSA_Navigation__blIsHNDefined( void);

/**
 * Function: IsCrossingAvailable
 * B
 * NISSAN
 */
tbool HSA_Navigation__blIsCrossingAvailable( void);

/**
 * Function: IsHouseNumberUnique
 * B
 * NISSAN
 */
tbool HSA_Navigation__blIsHouseNumberUnique( void);

/**
 * Function: IsCityCenterUnique
 * B
 * NISSAN
 */
tbool HSA_Navigation__blIsCityCenterUnique( void);

/**
 * Function: IsInitialized
 * B1
 * NISSAN
 */
ulword HSA_Navigation__ulwIsInitialized( void);

/**
 * Function: IsDataAvailable
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwIsDataAvailable( void);

/**
 * Function: IsNaviDataAvailable
 * B1
 * NISSAN
 */
tbool HSA_Navigation__blIsNaviDataAvailable(ulword ulwSource);

/**
 * Function: LastCurrentDestPrepareGuidance
 * B
 * NISSAN
 */
void HSA_Navigation__vLastCurrentDestPrepareGuidance( void);

/**
 * Function: MemoryClearState
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwMemoryClearState( void);

/**
 * Function: MemoryEntryType
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwMemoryEntryType( void);

/**
 * Function: WaypointMemoryEntryType
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwWaypointMemoryEntryType( void);

/**
 * Function: GetSelectedWaypointIndex
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwGetSelectedWaypointIndex( void);

/**
 * Function: MemoryIntDestEntryType
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwMemoryIntDestEntryType( void);

/**
 * Function: MemoryDestMemClear
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryDestMemClear(ulword ulwSource);

/**
 * Function: MemoryDestMemExistsName
 * B
 * NISSAN
 */
tbool HSA_Navigation__blMemoryDestMemExistsName( void);

/**
 * Function: MemoryDestMemGetList
 * B1
 * NISSAN
 */
void HSA_Navigation__vMemoryDestMemGetList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: MemoryDestMemGetListCount
 * B1
 * NISSAN
 */
ulword HSA_Navigation__ulwMemoryDestMemGetListCount( void);

/**
 * Function: MemoryDestMemInputFilterString
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryDestMemInputFilterString(const GUI_String * InputString);

/**
 * Function: MemoryDestMemIsEmpty
 * B
 * NISSAN
 */
tbool HSA_Navigation__blMemoryDestMemIsEmpty( void);

/**
 * Function: MemoryDestMemIsFull
 * B
 * NISSAN
 */
tbool HSA_Navigation__blMemoryDestMemIsFull( void);

/**
 * Function: MemoryDestMemPrepareGuidance
 * B1
 * NISSAN
 */
void HSA_Navigation__vMemoryDestMemPrepareGuidance(ulword ulwListEntryNr);

/**
 * Function: MemoryDestMemPrepareList
 * B1
 * NISSAN
 */
void HSA_Navigation__vMemoryDestMemPrepareList( void);

/**
 * Function: MemoryDestMemPrepareSearch
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryDestMemPrepareSearch( void);

/**
 * Function: MemoryDestMemGetSearchList
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryDestMemGetSearchList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: MemoryDestMemGetSearchListCount
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwMemoryDestMemGetSearchListCount( void);

/**
 * Function: MemoryDestMemActivateSearch
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryDestMemActivateSearch( void);

/**
 * Function: MemoryDestMemSaveState
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwMemoryDestMemSaveState( void);

/**
 * Function: MemoryDestMemGetInfoShort
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryDestMemGetInfoShort(GUI_String *out_result);

/**
 * Function: MemoryDestMemDeleteState
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwMemoryDestMemDeleteState( void);

/**
 * Function: MemoryLastDestClear
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryLastDestClear( void);

/**
 * Function: MemoryLastDestGetInfo
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryLastDestGetInfo(GUI_String *out_result);

/**
 * Function: MemoryLastDestGetInfoShort
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryLastDestGetInfoShort(GUI_String *out_result);

/**
 * Function: MemoryLastDestGetList
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryLastDestGetList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: MemoryLastDestGetListCount
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwMemoryLastDestGetListCount( void);

/**
 * Function: MemoryLastDestListEmpty
 * B
 * NISSAN
 */
tbool HSA_Navigation__blMemoryLastDestListEmpty( void);

/**
 * Function: MemoryLastDestPrepareGuidance
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryLastDestPrepareGuidance(ulword ulwListEntryNr);

/**
 * Function: MemoryLastDestSelectForSaving
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryLastDestSelectForSaving(ulword ulwListEntryNr);

/**
 * Function: MemoryLastDestPrepareList
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryLastDestPrepareList( void);

/**
 * Function: HNMatchForReduction
 * B
 * NISSAN
 */
void HSA_Navigation__vHNMatchForReduction( void);

/**
 * Function: POIPrepareSearchEngine
 * B
 * NISSAN
 */
void HSA_Navigation__vPOIPrepareSearchEngine( void);

/**
 * Function: POIGetResultCount
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwPOIGetResultCount( void);

/**
 * Function: POISearchIsAvailable
 * B
 * NISSAN
 */
tbool HSA_Navigation__blPOISearchIsAvailable( void);

/**
 * Function: POISearchStringIsServiceable
 * B
 * NISSAN
 */
tbool HSA_Navigation__blPOISearchStringIsServiceable( void);

/**
 * Function: POISearchParamSetCharacter
 * B-Not in use
 * NISSAN
 */
void HSA_Navigation__vPOISearchParamSetCharacter(const GUI_String * InputString);

/**
 * Function: GetPOISpellerSearchString
 * B
 * NISSAN
 */
void HSA_Navigation__vGetPOISpellerSearchString(GUI_String *out_result);

/**
 * Function: POISearchParamSetCurrentCarPosition
 * B
 * NISSAN
 */
void HSA_Navigation__vPOISearchParamSetCurrentCarPosition( void);

/**
 * Function: POISearchParamSetLocation
 * B
 * NISSAN
 */
void HSA_Navigation__vPOISearchParamSetLocation( void);

/**
 * Function: POISearchParamSetDestination
 * B-Deprecated
 * NISSAN
 */
void HSA_Navigation__vPOISearchParamSetDestination( void);

/**
 * Function: POISearchProgressGetRadius
 * B
 * NISSAN
 */
void HSA_Navigation__vPOISearchProgressGetRadius(GUI_String *out_result);

/**
 * Function: SpellerGetPOISearchInput
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerGetPOISearchInput(GUI_String *out_result);

/**
 * Function: POISelectForSaving
 * B
 * NISSAN
 */
void HSA_Navigation__vPOISelectForSaving(ulword ulwListEntryNr);

/**
 * Function: POISelectForSavingFromDetail
 * B
 * NISSAN
 */
void HSA_Navigation__vPOISelectForSavingFromDetail( void);

/**
 * Function: POITopSelectForSaving
 * B
 * NISSAN
 */
void HSA_Navigation__vPOITopSelectForSaving(ulword ulwListEntryNr);

/**
 * Function: POITopSelectForSavingFromDetail
 * B
 * NISSAN
 */
void HSA_Navigation__vPOITopSelectForSavingFromDetail( void);

/**
 * Function: POISearchResultCount
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwPOISearchResultCount( void);

/**
 * Function: POISearchResultGetListString
 * B
 * NISSAN
 */
void HSA_Navigation__vPOISearchResultGetListString(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr);

/**
 * Function: POISearchResultGetListValue
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwPOISearchResultGetListValue(ulword ulwCell, ulword ulwListEntryNr);

/**
 * Function: POISearchResultGetSelectedData
 * B
 * NISSAN
 */
void HSA_Navigation__vPOISearchResultGetSelectedData(GUI_String *out_result);

/**
 * Function: POISearchResultGetSelectedHasAdditionalInfo
 * B
 * NISSAN
 */
tbool HSA_Navigation__blPOISearchResultGetSelectedHasAdditionalInfo( void);

/**
 * Function: POISearchResultListSelectForDetails
 * B
 * NISSAN
 */
void HSA_Navigation__vPOISearchResultListSelectForDetails(ulword ulwListEntryNr);

/**
 * Function: POIGetCurrentDetailViewIndex
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwPOIGetCurrentDetailViewIndex( void);

/**
 * Function: POIPrepareGuidance
 * B
 * NISSAN
 */
void HSA_Navigation__vPOIPrepareGuidance(ulword ulwListEntryNr);

/**
 * Function: POIPrepareGuidanceFromDetails
 * B
 * NISSAN
 */
void HSA_Navigation__vPOIPrepareGuidanceFromDetails( void);

/**
 * Function: POITopPrepareGuidance
 * B
 * NISSAN
 */
void HSA_Navigation__vPOITopPrepareGuidance(ulword ulwListEntryNr);

/**
 * Function: POIEditLocationInit
 * B
 * NISSAN
 */
void HSA_Navigation__vPOIEditLocationInit( void);

/**
 * Function: POISearchStart
 * B
 * NISSAN
 */
void HSA_Navigation__vPOISearchStart( void);

/**
 * Function: POISearchGasStationStart
 * B
 * NISSAN
 */
void HSA_Navigation__vPOISearchGasStationStart( void);

/**
 * Function: POISearchParkingAreaStart
 * B
 * NISSAN
 */
void HSA_Navigation__vPOISearchParkingAreaStart( void);

/**
 * Function: POISearchState
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwPOISearchState( void);

/**
 * Function: TelematicParamSetAroundCarPosition
 * B
 * NISSAN
 */
void HSA_Navigation__vTelematicParamSetAroundCarPosition( void);

/**
 * Function: TelematicSearchAroundCity
 * B
 * NISSAN
 */
void HSA_Navigation__vTelematicSearchAroundCity( void);

/**
 * Function: TelematicSearchAroundDest
 * B
 * NISSAN
 */
void HSA_Navigation__vTelematicSearchAroundDest( void);

/**
 * Function: XMParamSetAroundCarPosition
 * B
 * NISSAN
 */
void HSA_Navigation__vXMParamSetAroundCarPosition( void);

/**
 * Function: XMSearchAroundCity
 * B
 * NISSAN
 */
void HSA_Navigation__vXMSearchAroundCity( void);

/**
 * Function: XMSearchAroundDest
 * B
 * NISSAN
 */
void HSA_Navigation__vXMSearchAroundDest( void);

/**
 * Function: TelematicPOIPrepareGuidanceFromDetails
 * B
 * NISSAN
 */
void HSA_Navigation__vTelematicPOIPrepareGuidanceFromDetails( void);

/**
 * Function: POISearchStop
 * B
 * NISSAN
 */
void HSA_Navigation__vPOISearchStop( void);

/**
 * Function: POITopSearchStop
 * C
 * NISSAN
 */
void HSA_Navigation__vPOITopSearchStop( void);

/**
 * Function: RecalculateRoute
 * B1
 * NISSAN
 */
void HSA_Navigation__vRecalculateRoute( void);

/**
 * Function: RouteBlockCongestionAheadApply
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteBlockCongestionAheadApply( void);

/**
 * Function: RouteBlockCongestionAheadDecrease
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteBlockCongestionAheadDecrease( void);

/**
 * Function: RouteBlockCongestionAheadGetLength
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteBlockCongestionAheadGetLength(GUI_String *out_result);

/**
 * Function: RouteBlockCongestionAheadIncrease
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteBlockCongestionAheadIncrease( void);

/**
 * Function: RouteBlockDiscardEntries
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteBlockDiscardEntries( void);

/**
 * Function: RouteCriteriaApplyInput
 * B1
 * NISSAN
 */
void HSA_Navigation__vRouteCriteriaApplyInput( void);

/**
 * Function: RouteCriteriaInit
 * B2
 * NISSAN
 */
void HSA_Navigation__vRouteCriteriaInit( void);

/**
 * Function: RouteCriteriaAvoidVignetteGetList
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteCriteriaAvoidVignetteGetList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: RouteCriteriaAvoidVignetteGetCheckbox
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteCriteriaAvoidVignetteGetCheckbox(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: RouteCriteriaAvoidVignetteListCount
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwRouteCriteriaAvoidVignetteListCount( void);

/**
 * Function: RouteCriteriaAvoidVignetteToggleItem
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteCriteriaAvoidVignetteToggleItem(ulword ulwListEntryNr);

/**
 * Function: RouteCriteriaGetState
 * NISSAN 2.0
 * NISSAN
 */
ulword HSA_Navigation__ulwRouteCriteriaGetState(ulword ulwType);

/**
 * Function: RouteCriteriaSetState
 * NISSAN 2.0
 * NISSAN
 */
void HSA_Navigation__vRouteCriteriaSetState(ulword ulwType, ulword ulwState);

/**
 * Function: RouteGuidanceGetMode
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwRouteGuidanceGetMode( void);

/**
 * Function: RouteGuidanceGetRemainingDistance
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteGuidanceGetRemainingDistance(GUI_String *out_result);

/**
 * Function: RouteGuidanceGetRemainingTime
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteGuidanceGetRemainingTime(GUI_String *out_result);

/**
 * Function: RouteGuidanceStart
 * B1
 * NISSAN
 */
void HSA_Navigation__vRouteGuidanceStart( void);

/**
 * Function: RouteGuidanceStartDemo
 * B1
 * NISSAN
 */
void HSA_Navigation__vRouteGuidanceStartDemo( void);

/**
 * Function: RouteGuidanceStart_Waypoint
 * B1
 * NISSAN
 */
void HSA_Navigation__vRouteGuidanceStart_Waypoint( void);

/**
 * Function: RouteGuidanceStartDemo_Waypoint
 * B1
 * NISSAN
 */
void HSA_Navigation__vRouteGuidanceStartDemo_Waypoint( void);

/**
 * Function: RouteGuidanceStartPOI
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteGuidanceStartPOI( void);

/**
 * Function: RouteGuidanceStop
 * B1
 * NISSAN
 */
void HSA_Navigation__vRouteGuidanceStop( void);

/**
 * Function: RouteManeuverDetailData
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverDetailData(GUI_String *out_result);

/**
 * Function: RouteManeuverActivateDetailData
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverActivateDetailData(ulword ulwListEntryNr);

/**
 * Function: RouteManeuverGetList
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverGetList(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr);

/**
 * Function: RouteManeuverGetDisTimeUnits
 * B-Deprecated
 * NISSAN
 */
ulword HSA_Navigation__ulwRouteManeuverGetDisTimeUnits(ulword ulwListEntryNr);

/**
 * Function: RouteManeuverMessageIconLabel
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwRouteManeuverMessageIconLabel(ulword ulwListEntryNr);

/**
 * Function: SetWaypointForPOISearch
 * B
 * NISSAN
 */
void HSA_Navigation__vSetWaypointForPOISearch(ulword ulwListEntryNr);

/**
 * Function: WaypointIconLabel
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwWaypointIconLabel(ulword ulwListEntryNr);

/**
 * Function: RouteManeuverMarkedLockElement
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwRouteManeuverMarkedLockElement(ulword ulwListEntryNr);

/**
 * Function: RouteManeuverGetListCount
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwRouteManeuverGetListCount( void);

/**
 * Function: RouteManeuverGetSubItemCount
 * BPlus
 * NISSAN
 */
ulword HSA_Navigation__ulwRouteManeuverGetSubItemCount( void);

/**
 * Function: RouteManeuverListIsAvailable
 * B
 * NISSAN
 */
tbool HSA_Navigation__blRouteManeuverListIsAvailable( void);

/**
 * Function: RouteBlockIsLockLimitExceeded
 * B
 * NISSAN
 */
tbool HSA_Navigation__blRouteBlockIsLockLimitExceeded( void);

/**
 * Function: RouteManeuverPrepareList
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverPrepareList( void);

/**
 * Function: RouteManeuverMarkLockElementIncrease
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverMarkLockElementIncrease( void);

/**
 * Function: RouteManeuverMarkLockElementDecrease
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverMarkLockElementDecrease( void);

/**
 * Function: RouteManeuverSetMarkLockElement
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverSetMarkLockElement(ulword ulwListEntryNr);

/**
 * Function: RouteManeuverSetMarkLockFirstElement
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverSetMarkLockFirstElement(ulword ulwListEntryNr);

/**
 * Function: RouteManeuverSetMarkLockFirstElementFromDetails
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverSetMarkLockFirstElementFromDetails( void);

/**
 * Function: RouteManeuverSetMarkLockLastElementFromDetails
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverSetMarkLockLastElementFromDetails( void);

/**
 * Function: RouteManeuverSetMarkLockLastElement
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverSetMarkLockLastElement(ulword ulwListEntryNr);

/**
 * Function: RouteManeuverMarkLockMode
 * B
 * NISSAN
 */
tbool HSA_Navigation__blRouteManeuverMarkLockMode( void);

/**
 * Function: RouteManeuverSetMarkLockMode
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverSetMarkLockMode(tbool blMode);

/**
 * Function: RouteManeuverIsCongestionDefined
 * B
 * NISSAN
 */
tbool HSA_Navigation__blRouteManeuverIsCongestionDefined( void);

/**
 * Function: RouteManeuverDeleteCongestion
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverDeleteCongestion( void);

/**
 * Function: RouteManeuverListClosed
 * B
 * NISSAN
 */
void HSA_Navigation__vRouteManeuverListClosed( void);

/**
 * Function: RouteManeuverPrepareListState
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwRouteManeuverPrepareListState( void);

/**
 * Function: EnterMoveMode
 * B
 * NISSAN
 */
void HSA_Navigation__vEnterMoveMode(ulword ulwPressedDynamicIndex);

/**
 * Function: ListEntryMoveDown
 * B
 * NISSAN
 */
void HSA_Navigation__vListEntryMoveDown(ulword ulwMovedDynamicIndex);

/**
 * Function: ListEntryMoveUp
 * B
 * NISSAN
 */
void HSA_Navigation__vListEntryMoveUp(ulword ulwMovedDynamicIndex);

/**
 * Function: AbortMoveMode
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vAbortMoveMode( void);

/**
 * Function: LeaveMoveMode
 * NISSAN LCN2
 * NISSAN
 */
void HSA_Navigation__vLeaveMoveMode( void);

/**
 * Function: WaypointGetCurrentMoveIndex
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwWaypointGetCurrentMoveIndex( void);

/**
 * Function: DeleteAndInsertWaypoint
 * NISSAN LCN 2
 * NISSAN
 */
void HSA_Navigation__vDeleteAndInsertWaypoint(ulword ulwListEntryNumber);

/**
 * Function: DeleteWaypoint
 * NISSAN LCN 2
 * NISSAN
 */
void HSA_Navigation__vDeleteWaypoint(ulword ulwListEntryNumber);

/**
 * Function: RouteOptionDynRouteGetState
 * B1
 * NISSAN
 */
tbool HSA_Navigation__blRouteOptionDynRouteGetState( void);

/**
 * Function: RouteOptionDynRouteSetState
 * B1
 * NISSAN
 */
void HSA_Navigation__vRouteOptionDynRouteSetState(tbool blMode);

/**
 * Function: RouteOptionGetState
 * B1
 * NISSAN
 */
ulword HSA_Navigation__ulwRouteOptionGetState( void);

/**
 * Function: RouteOptionSetState
 * B1
 * NISSAN
 */
void HSA_Navigation__vRouteOptionSetState(ulword ulwState);

/**
 * Function: SetCurrentPositionAsHomeDest
 * B
 * NISSAN
 */
void HSA_Navigation__vSetCurrentPositionAsHomeDest( void);

/**
 * Function: SetTemporaryMode
 * B1
 * NISSAN
 */
void HSA_Navigation__vSetTemporaryMode(tbool blMode);

/**
 * Function: SetDemoPosition
 * B
 * NISSAN
 */
void HSA_Navigation__vSetDemoPosition( void);

/**
 * Function: SetupGetAnnouncement
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwSetupGetAnnouncement( void);

/**
 * Function: SetupGetAutozoom
 * 
 * NISSAN
 */
ulword HSA_Navigation__ulwSetupGetAutozoom( void);

/**
 * Function: SetupGetDemoMode
 * B1
 * NISSAN
 */
tbool HSA_Navigation__blSetupGetDemoMode( void);

/**
 * Function: SetupDeactivateDemoModeSetting
 * B1
 * NISSAN
 */
tbool HSA_Navigation__blSetupDeactivateDemoModeSetting( void);

/**
 * Function: SetupOptionsChanged
 * B2
 * NISSAN
 */
tbool HSA_Navigation__blSetupOptionsChanged( void);

/**
 * Function: SetupSetAutozoom
 * 
 * NISSAN
 */
void HSA_Navigation__vSetupSetAutozoom(ulword ulwMode);

/**
 * Function: SetupSetDemoMode
 * B1
 * NISSAN
 */
void HSA_Navigation__vSetupSetDemoMode(tbool blMode);

/**
 * Function: SpellerInitInput
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerInitInput(ulword ulwType);

/**
 * Function: SpellerInitRestore
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerInitRestore(ulword ulwType);

/**
 * Function: SpellerCharacterInput
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerCharacterInput(const GUI_String * InputString);

/**
 * Function: SpellerDiscardAllInput
 * NIKAI-4796
 * NISSAN
 */
void HSA_Navigation__vSpellerDiscardAllInput( void);

/**
 * Function: SpellerGetNameInput
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerGetNameInput(GUI_String *out_result);

/**
 * Function: SpellerSetNameInput
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerSetNameInput( void);

/**
 * Function: SpellerMatchGetCount
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwSpellerMatchGetCount(ulword ulwType);

/**
 * Function: MatchGetListCount
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwMatchGetListCount(ulword ulwType);

/**
 * Function: SpellerMatchGetFirst
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerMatchGetFirst(GUI_String *out_result, ulword ulwType);

/**
 * Function: SpellerGetFavSearchInput
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerGetFavSearchInput(GUI_String *out_result);

/**
 * Function: SpellerInputOccurred
 * B
 * NISSAN
 */
tbool HSA_Navigation__blSpellerInputOccurred( void);

/**
 * Function: SpellerMatchGetList
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerMatchGetList(GUI_String *out_result, ulword ulwType, ulword ulwListEntryNr);

/**
 * Function: SpellerMatchActivateList
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerMatchActivateList(ulword ulwType);

/**
 * Function: SpellerMatchActivateListRestore
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerMatchActivateListRestore(ulword ulwType);

/**
 * Function: SpellerMatchGetPossibleLetters
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerMatchGetPossibleLetters(GUI_String *out_result);

/**
 * Function: SpellerInvertGetLetterFunction
 * B
 * NISSAN
 */
tbool HSA_Navigation__blSpellerInvertGetLetterFunction( void);

/**
 * Function: SpellerGetHighlightedText
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerGetHighlightedText(GUI_String *out_result, ulword ulwType);

/**
 * Function: SpellerEnableMatchSpeller
 * B
 * NISSAN
 */
tbool HSA_Navigation__blSpellerEnableMatchSpeller( void);

/**
 * Function: SpellerEnableHouseNumSpeller
 * B
 * NISSAN
 */
tbool HSA_Navigation__blSpellerEnableHouseNumSpeller( void);

/**
 * Function: SpellerGetCursorPos
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwSpellerGetCursorPos( void);

/**
 * Function: SpellerSetMaxCharCount
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerSetMaxCharCount(ulword ulwCount);

/**
 * Function: SpellerSetInitialText
 * B
 * NISSAN
 */
void HSA_Navigation__vSpellerSetInitialText(const GUI_String * InitialString);

/**
 * Function: StartEditingDemoMode
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vStartEditingDemoMode( void);

/**
 * Function: StopEditingDemoMode
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vStopEditingDemoMode( void);

/**
 * Function: StopCalcRoute
 * B1
 * NISSAN
 */
void HSA_Navigation__vStopCalcRoute( void);

/**
 * Function: WaitSyncState
 * B1 - New Parameter for B
 * NISSAN
 */
ulword HSA_Navigation__ulwWaitSyncState(ulword ulwType);

/**
 * Function: RouteOptionDynRouteUserConfirm
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vRouteOptionDynRouteUserConfirm( void);

/**
 * Function: GetDynRouteOption
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetDynRouteOption( void);

/**
 * Function: SetDynRouteOption
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vSetDynRouteOption(ulword ulwMode);

/**
 * Function: IsMemoryLimitReached
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation__blIsMemoryLimitReached( void);

/**
 * Function: ShowCategoryList
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vShowCategoryList( void);

/**
 * Function: GetHouseNo_NAR
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vGetHouseNo_NAR(GUI_String *out_result);

/**
 * Function: PoiSetCategory_NAR
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vPoiSetCategory_NAR(ulword ulwListEntryNr);

/**
 * Function: GetPOIListType
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetPOIListType( void);

/**
 * Function: IsPOICategoryListPrepared
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation__blIsPOICategoryListPrepared(ulword ulwType);

/**
 * Function: GetPOICategoryCount
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetPOICategoryCount( void);

/**
 * Function: GetPOIAttributeCount
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetPOIAttributeCount( void);

/**
 * Function: RestorePOICategoryList
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vRestorePOICategoryList( void);

/**
 * Function: GetLastPOIListSelIndex
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetLastPOIListSelIndex( void);

/**
 * Function: POIGetSelectedCategory
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vPOIGetSelectedCategory(GUI_String *out_result);

/**
 * Function: MemoryWaypointPrepareList
 * B
 * NISSAN
 */
void HSA_Navigation__vMemoryWaypointPrepareList( void);

/**
 * Function: ExitWaypointList
 * B
 * NISSAN
 */
void HSA_Navigation__vExitWaypointList( void);

/**
 * Function: MemoryWaypointGetListCount
 * B
 * NISSAN
 */
ulword HSA_Navigation__ulwMemoryWaypointGetListCount( void);

/**
 * Function: MemoryWaypointGetList
 * /
 * NISSAN
 */
void HSA_Navigation__vMemoryWaypointGetList(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr);

/**
 * Function: MemoryWaypointGetDirection
 * /
 * NISSAN
 */
ulword HSA_Navigation__ulwMemoryWaypointGetDirection(ulword ulwListEntryNr);

/**
 * Function: MemoryWaypointMemIsFull
 * B
 * NISSAN
 */
tbool HSA_Navigation__blMemoryWaypointMemIsFull( void);

/**
 * Function: WaypointPrepareSaving
 * B
 * NISSAN
 */
void HSA_Navigation__vWaypointPrepareSaving( void);

/**
 * Function: RouteManeuverGetListUnit
 * D
 * NISSAN
 */
ulword HSA_Navigation__ulwRouteManeuverGetListUnit( void);

/**
 * Function: POISearchResultGetListUnit
 * D
 * NISSAN
 */
ulword HSA_Navigation__ulwPOISearchResultGetListUnit( void);

/**
 * Function: GetPositionDataDetailUnit
 * D
 * NISSAN
 */
ulword HSA_Navigation__ulwGetPositionDataDetailUnit( void);

/**
 * Function: MemoryWaypointGetListUnit
 * D
 * NISSAN
 */
ulword HSA_Navigation__ulwMemoryWaypointGetListUnit( void);

/**
 * Function: SetGnsssatSystemType
 * NISSAN 2.0
 * NISSAN
 */
void HSA_Navigation__vSetGnsssatSystemType(ulword ulwGnssType);

/**
 * Function: GetGnsssatSystemType
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation__ulwGetGnsssatSystemType( void);

/**
 * Function: GetLanguageDependentStringsUnit
 * D
 * NISSAN
 */
ulword HSA_Navigation__ulwGetLanguageDependentStringsUnit( void);

/**
 * Function: DestEntryGetWaypoint
 * B
 * NISSAN
 */
void HSA_Navigation__vDestEntryGetWaypoint(GUI_String *out_result, ulword ulwType);

/**
 * Function: StreetPossibleAfterCity
 * B
 * NISSAN
 */
tbool HSA_Navigation__blStreetPossibleAfterCity( void);

/**
 * Function: DestEntryGetSDSInputType
 * D
 * NISSAN
 */
ulword HSA_Navigation__ulwDestEntryGetSDSInputType( void);

/**
 * Function: TCUJourneyPrepareGuidance
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vTCUJourneyPrepareGuidance( void);

/**
 * Function: TcuJourneyPrepareShowOnMap
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vTcuJourneyPrepareShowOnMap( void);

/**
 * Function: SetTCUModeActive
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vSetTCUModeActive( void);

/**
 * Function: GetSelectedPoiCategory
 * NISSAN
 * NISSAN
 */
void HSA_Navigation__vGetSelectedPoiCategory(GUI_String *out_result);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_Navigation_H

