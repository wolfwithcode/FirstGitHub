/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_Navigation_Map_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_Navigation_Map_Base_H
#define _clHSA_Navigation_Map_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_Navigation_Map_Base : public clHSA_Base
{
public:

    static clHSA_Navigation_Map_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_Navigation_Map_Base()        {}

    virtual void vSetSplitScreenConf(ulword ulwConfType);

    virtual ulword ulwGetSplitScreenState( );

    virtual void vSetSplitScreenLock(ulword ulwLockMode);

    virtual ulword ulwGetSplitScreenLockState( );

    virtual void vSetDestFlagForNewMapCenter(ulword ulwFlagType);

    virtual tbool blIsCameraWarningAvailable( );

    virtual tbool blIsCurveWarningAvailable( );

    virtual tbool blIsOverSpeedWarningAvailable( );

    virtual tbool blIsWarningDistanceAvailable( );

    virtual tbool blIsLaneDisplayAvailable( );

    virtual tbool blIsLaneGuidanceLeftVisible( );

    virtual tbool blIsLaneGuidanceCenterVisible( );

    virtual void vGetLaneGuidanceSymbols(GUI_String *out_result);

    virtual void vCameraWarningGetValue(GUI_String *out_result);

    virtual ulword ulwCameraWarningGetUnit( );

    virtual ulword ulwCurvewarningGetValue( );

    virtual ulword ulwLaneDisplayGetValue( );

    virtual void vToggleCurveWarning( );

    virtual ulword ulwGetCurveWarningState( );

    virtual void vToggleOverSpeedWarning( );

    virtual ulword ulwGetOverSpeedWarningState( );

    virtual void vGetOverSpeedThreshold(GUI_String *out_result);

    virtual void vOverSpeedThresholdHandling(ulword ulwConfType);

    virtual void vSetDragMapMode(ulword ulwOperationMode);

    virtual tbool blGetActDestFlagType( );

    virtual tbool blIsDestFlagMoved( );

    virtual tbool blFlagDestEntryIsValid( );

    virtual tbool blCarPositionIsValid( );

    virtual void vGetFlagDestName(GUI_String *out_result);

    virtual tbool blGetMapRepresentationMode(ulword ulwMode);

    virtual void vSetMapRepresentationMode2DCarHeading(ulword ulwState);

    virtual void vSetMapRepresentationMode2DNorth(ulword ulwState);

    virtual void vSetMapRepresentationMode3DCarHeading(ulword ulwState);

    virtual void vToggleMapOrientation( );

    virtual void vTogglePOILabelState(ulword ulwPOIListitem);

    virtual tbool blGetPOILabelState(ulword ulwPOIListitem);

    virtual void vPOILabelApplyInput( );

    virtual ulword ulwGetMapOrientation( );

    virtual void vSetVoiceGuidance(tbool blNaviVoice);

    virtual tbool blGetVoiceGuidance( );

    virtual void vToggleUserMap( );

    virtual ulword ulwGetUserMap( );

    virtual void vInitMap(ulword ulwMapType);

    virtual tbool blIsMapVisible(ulword ulwMapType);

    virtual void vMapTouched( );

    virtual void vMapReleased(slword slwPosX, slword slwPosY);

    virtual void vMapDragged(slword slwDeltaX, slword slwDeltaY, ulword ulwPenState);

    virtual void vMapDraggedAbsPos(slword slwLastAbsX, slword slwLastAbsY, slword slwMovedToAbsX, slword slwMovedToAbsY);

    virtual tbool blIsDestFlagSet( );

    virtual void vAutoZoomActivate(tbool blState);

    virtual tbool blAutoZoomActive( );

    virtual tbool blControlBarStateGet( );

    virtual void vControlBarStateToggle( );

    virtual void vDraw( );

    virtual void vDrawStop( );

    virtual void vDrawCarsor( );

    virtual void vHideCarsor( );

    virtual ulword ulwGetActiveGuidanceSymbol( );

    virtual ulword ulwGetBarGraphSymbol( );

    virtual ulword ulwGetActiveTimeDisplay( );

    virtual void vGetActiveTimeDisplayValue(GUI_String *out_result, ulword ulwMode);

    virtual ulword ulwGetCurrentNorthUpSymbol( );

    virtual void vGetCurrentStreet(GUI_String *out_result);

    virtual void vGetDistanceToDestination(GUI_String *out_result);

    virtual ulword ulwGetDistanceToDestinationUnit( );

    virtual void vGetDistanceToManeuver(GUI_String *out_result);

    virtual ulword ulwGetDistanceToManeuverUnit( );

    virtual void vGetTurnToStreet(GUI_String *out_result);

    virtual void vInit( );

    virtual ulword ulwIsInitialized( );

    virtual tbool blIsDriveManeuverPresent( );

    virtual tbool blShowTurnToStreet( );

    virtual tbool blShowDistanceToManeuver( );

    virtual tbool blShowActiveGuidanceSymbol( );

    virtual ulword ulwMainZoomGetValue( );

    virtual void vMainZoomInStep( );

    virtual void vMainZoomOutStep( );

    virtual void vSetActiveTimeDisplay(ulword ulwMode);

    virtual tbool blIsBargraphActive( );

    virtual ulword ulwGetBargraphValue( );

    virtual tbool blIsSpeedLimitAvailable( );

    virtual ulword ulwIsRouteCompletelyCalculated( );

    virtual void vSpeedLimitGetValue(GUI_String *out_result);

    virtual void vSplitScreenClose( );

    virtual ulword ulwSplitScreenGetMapPosition( );

    virtual ulword ulwSplitScreenRightColumnElementStart( );

    virtual void vGetHWETurnToStreet(GUI_String *out_result);

    virtual void vGetHWESignPost(GUI_String *out_result);

    virtual void vGetHWENumber(GUI_String *out_result);

    virtual ulword ulwGetHWESignpostBGImgIndex( );

    virtual ulword ulwGetHWESignpostTextColor( );

    virtual ulword ulwGetHWEInfoPosition( );

    virtual void vSetFramerateToLow( );

    virtual void vSetFramerateToNormal( );

    virtual tbool blSetupGetPresetInfoAvailability( );

    virtual void vTogglePresetInfoState( );

    virtual ulword ulwGetActWeatherMapType( );

    virtual void vPrepareWeatherMap(ulword ulwWeatherMapType);

    virtual tbool blHasWeatherMapLoadingStarted( );

    virtual void vGetStormCellMovementSpeed(GUI_String *out_result);

    virtual void vGetStormCellEchoTopHeight(GUI_String *out_result);

    virtual void vGetStormCellIssueTime(GUI_String *out_result);

    virtual void vClearStormCellPickedData( );

    virtual ulword ulwGetNumberOfStormTracks( );

    virtual void vGetStormTrackerName(GUI_String *out_result);

    virtual ulword ulwGetStormTrackerInfoWeatherStromType( );

    virtual void vGetStormTrackerInfoSpeed(GUI_String *out_result);

    virtual void vGetStormTrackerInfoMaxSustainedWinds(GUI_String *out_result);

    virtual void vGetStormTrackerInfoGusts(GUI_String *out_result);

    virtual void vGetStormTrackerInfoPressure(GUI_String *out_result);

    virtual void vGetStormTrackerInfoIssueTime(GUI_String *out_result);

    virtual ulword ulwGetStormTrackerInfoDateMM( );

    virtual ulword ulwGetStormTrackerInfoDateDD( );

    virtual ulword ulwGetStormTrackerInfoDateYYYY( );

    virtual void vClearStormTrackerInfoPickedData( );

    virtual void vPOIMapPrepareGuidance(ulword ulwListEntryNr);

    virtual ulword ulwGetPOIListCount( );

    virtual void vGetPOIListString(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr);

    virtual ulword ulwGetPOIListValue(ulword ulwCell, ulword ulwListEntryNr);

    virtual void vPOIActivateDetails(ulword ulwListEntryNr);

    virtual ulword ulwPOIMapGetListUnit( );

    virtual void vSetWeatherMapLegendDisplayState( );

    virtual tbool blGetWeatherMapLegendDisplayState( );

    virtual void vSetCrossHairVisible(tbool blVisibility);

    virtual void vITCommanderRelease( );

    virtual void vITCommanderPress(ulword ulwDirectionValue, tbool blReleaseType);

    virtual void vITCommanderSelect(ulword ulwPosX, ulword ulwPosY);

    virtual void vSwitchRoadActivate( );

    virtual void vSwitchRoadDeactivate( );

    virtual void vSwitchRoadToggle( );

    virtual ulword ulwSwitchRoadGetStatus( );

    virtual ulword ulwSwitchRoadGetCurrentRoadNumber( );

    virtual ulword ulwSwitchRoadGetNumberOfRoads( );

protected:
    clHSA_Navigation_Map_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_Navigation_Map_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_Navigation_Map_Base_H

