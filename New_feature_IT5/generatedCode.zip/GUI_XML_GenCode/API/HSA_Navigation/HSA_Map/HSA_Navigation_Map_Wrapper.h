/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Navigation_Map_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_Navigation_Map_Wrapper_H
#define _HSA_Navigation_Map_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: SetSplitScreenConf
 * B2
 * NISSAN
 */
void HSA_Navigation_Map__vSetSplitScreenConf(ulword ulwConfType);

/**
 * Function: GetSplitScreenState
 * B2
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetSplitScreenState( void);

/**
 * Function: SetSplitScreenLock
 * B2
 * NISSAN
 */
void HSA_Navigation_Map__vSetSplitScreenLock(ulword ulwLockMode);

/**
 * Function: GetSplitScreenLockState
 * B2
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetSplitScreenLockState( void);

/**
 * Function: SetDestFlagForNewMapCenter
 * NISSAN LCN NAR
 * NISSAN
 */
void HSA_Navigation_Map__vSetDestFlagForNewMapCenter(ulword ulwFlagType);

/**
 * Function: IsCameraWarningAvailable
 * Nissan 2.0
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsCameraWarningAvailable( void);

/**
 * Function: IsCurveWarningAvailable
 * Nissan 2.0
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsCurveWarningAvailable( void);

/**
 * Function: IsOverSpeedWarningAvailable
 * Nissan 2.0
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsOverSpeedWarningAvailable( void);

/**
 * Function: IsWarningDistanceAvailable
 * Nissan 2.0
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsWarningDistanceAvailable( void);

/**
 * Function: IsLaneDisplayAvailable
 * Nissan 2.0
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsLaneDisplayAvailable( void);

/**
 * Function: IsLaneGuidanceLeftVisible
 * Nissan 2.0
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsLaneGuidanceLeftVisible( void);

/**
 * Function: IsLaneGuidanceCenterVisible
 * Nissan 2.0
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsLaneGuidanceCenterVisible( void);

/**
 * Function: GetLaneGuidanceSymbols
 * B
 * NISSAN
 */
void HSA_Navigation_Map__vGetLaneGuidanceSymbols(GUI_String *out_result);

/**
 * Function: CameraWarningGetValue
 * Nissan 2.0
 * NISSAN
 */
void HSA_Navigation_Map__vCameraWarningGetValue(GUI_String *out_result);

/**
 * Function: CameraWarningGetUnit
 * Nissan 2.0
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwCameraWarningGetUnit( void);

/**
 * Function: CurvewarningGetValue
 * Nissan 2.0
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwCurvewarningGetValue( void);

/**
 * Function: LaneDisplayGetValue
 * Nissan 2.0
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwLaneDisplayGetValue( void);

/**
 * Function: ToggleCurveWarning
 * Nissan 2.0
 * NISSAN
 */
void HSA_Navigation_Map__vToggleCurveWarning( void);

/**
 * Function: GetCurveWarningState
 * Nissan 2.0
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetCurveWarningState( void);

/**
 * Function: ToggleOverSpeedWarning
 * Nissan 2.0
 * NISSAN
 */
void HSA_Navigation_Map__vToggleOverSpeedWarning( void);

/**
 * Function: GetOverSpeedWarningState
 * Nissan 2.0
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetOverSpeedWarningState( void);

/**
 * Function: GetOverSpeedThreshold
 * Nissan 2.0
 * NISSAN
 */
void HSA_Navigation_Map__vGetOverSpeedThreshold(GUI_String *out_result);

/**
 * Function: OverSpeedThresholdHandling
 * Nissan 2.0
 * NISSAN
 */
void HSA_Navigation_Map__vOverSpeedThresholdHandling(ulword ulwConfType);

/**
 * Function: SetDragMapMode
 * NISSAN LCN NAR
 * NISSAN
 */
void HSA_Navigation_Map__vSetDragMapMode(ulword ulwOperationMode);

/**
 * Function: GetActDestFlagType
 * NISSAN LCN NAR
 * NISSAN
 */
tbool HSA_Navigation_Map__blGetActDestFlagType( void);

/**
 * Function: IsDestFlagMoved
 * NISSAN LCN NAR
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsDestFlagMoved( void);

/**
 * Function: FlagDestEntryIsValid
 * NISSAN LCN QQ
 * NISSAN
 */
tbool HSA_Navigation_Map__blFlagDestEntryIsValid( void);

/**
 * Function: CarPositionIsValid
 * NISSAN LCN QQ
 * NISSAN
 */
tbool HSA_Navigation_Map__blCarPositionIsValid( void);

/**
 * Function: GetFlagDestName
 * NISSAN
 * NISSAN
 */
void HSA_Navigation_Map__vGetFlagDestName(GUI_String *out_result);

/**
 * Function: GetMapRepresentationMode
 * 
 * NISSAN
 */
tbool HSA_Navigation_Map__blGetMapRepresentationMode(ulword ulwMode);

/**
 * Function: SetMapRepresentationMode2DCarHeading
 * 
 * NISSAN
 */
void HSA_Navigation_Map__vSetMapRepresentationMode2DCarHeading(ulword ulwState);

/**
 * Function: SetMapRepresentationMode2DNorth
 * 
 * NISSAN
 */
void HSA_Navigation_Map__vSetMapRepresentationMode2DNorth(ulword ulwState);

/**
 * Function: SetMapRepresentationMode3DCarHeading
 * 
 * NISSAN
 */
void HSA_Navigation_Map__vSetMapRepresentationMode3DCarHeading(ulword ulwState);

/**
 * Function: ToggleMapOrientation
 * NISSAN
 * NISSAN
 */
void HSA_Navigation_Map__vToggleMapOrientation( void);

/**
 * Function: TogglePOILabelState
 * NISSAN 1.5
 * NISSAN
 */
void HSA_Navigation_Map__vTogglePOILabelState(ulword ulwPOIListitem);

/**
 * Function: GetPOILabelState
 * NISSAN 1.5
 * NISSAN
 */
tbool HSA_Navigation_Map__blGetPOILabelState(ulword ulwPOIListitem);

/**
 * Function: POILabelApplyInput
 * NISSAN 1.5
 * NISSAN
 */
void HSA_Navigation_Map__vPOILabelApplyInput( void);

/**
 * Function: GetMapOrientation
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetMapOrientation( void);

/**
 * Function: SetVoiceGuidance
 * NISSAN
 * NISSAN
 */
void HSA_Navigation_Map__vSetVoiceGuidance(tbool blNaviVoice);

/**
 * Function: GetVoiceGuidance
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation_Map__blGetVoiceGuidance( void);

/**
 * Function: ToggleUserMap
 * NISSAN
 * NISSAN
 */
void HSA_Navigation_Map__vToggleUserMap( void);

/**
 * Function: GetUserMap
 * NISSAN
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetUserMap( void);

/**
 * Function: InitMap
 * NISSAN
 * NISSAN
 */
void HSA_Navigation_Map__vInitMap(ulword ulwMapType);

/**
 * Function: IsMapVisible
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsMapVisible(ulword ulwMapType);

/**
 * Function: MapTouched
 * NISSAN
 * NISSAN
 */
void HSA_Navigation_Map__vMapTouched( void);

/**
 * Function: MapReleased
 * NISSAN
 * NISSAN
 */
void HSA_Navigation_Map__vMapReleased(slword slwPosX, slword slwPosY);

/**
 * Function: MapDragged
 * NISSAN
 * NISSAN
 */
void HSA_Navigation_Map__vMapDragged(slword slwDeltaX, slword slwDeltaY, ulword ulwPenState);

/**
 * Function: MapDraggedAbsPos
 * LCN2kai
 * NISSAN
 */
void HSA_Navigation_Map__vMapDraggedAbsPos(slword slwLastAbsX, slword slwLastAbsY, slword slwMovedToAbsX, slword slwMovedToAbsY);

/**
 * Function: IsDestFlagSet
 * NISSAN
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsDestFlagSet( void);

/**
 * Function: AutoZoomActivate
 * B
 * NISSAN
 */
void HSA_Navigation_Map__vAutoZoomActivate(tbool blState);

/**
 * Function: AutoZoomActive
 * B
 * NISSAN
 */
tbool HSA_Navigation_Map__blAutoZoomActive( void);

/**
 * Function: ControlBarStateGet
 * B1-Deprecated
 * NISSAN
 */
tbool HSA_Navigation_Map__blControlBarStateGet( void);

/**
 * Function: ControlBarStateToggle
 * B1-Deprecated
 * NISSAN
 */
void HSA_Navigation_Map__vControlBarStateToggle( void);

/**
 * Function: Draw
 * B1
 * NISSAN
 */
void HSA_Navigation_Map__vDraw( void);

/**
 * Function: DrawStop
 * B
 * NISSAN
 */
void HSA_Navigation_Map__vDrawStop( void);

/**
 * Function: DrawCarsor
 * B1-Deprecated
 * NISSAN
 */
void HSA_Navigation_Map__vDrawCarsor( void);

/**
 * Function: HideCarsor
 * B1-Deprecated
 * NISSAN
 */
void HSA_Navigation_Map__vHideCarsor( void);

/**
 * Function: GetActiveGuidanceSymbol
 * B1
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetActiveGuidanceSymbol( void);

/**
 * Function: GetBarGraphSymbol
 * B
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetBarGraphSymbol( void);

/**
 * Function: GetActiveTimeDisplay
 * B1
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetActiveTimeDisplay( void);

/**
 * Function: GetActiveTimeDisplayValue
 * B1
 * NISSAN
 */
void HSA_Navigation_Map__vGetActiveTimeDisplayValue(GUI_String *out_result, ulword ulwMode);

/**
 * Function: GetCurrentNorthUpSymbol
 * B1
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetCurrentNorthUpSymbol( void);

/**
 * Function: GetCurrentStreet
 * B1
 * NISSAN
 */
void HSA_Navigation_Map__vGetCurrentStreet(GUI_String *out_result);

/**
 * Function: GetDistanceToDestination
 * B1
 * NISSAN
 */
void HSA_Navigation_Map__vGetDistanceToDestination(GUI_String *out_result);

/**
 * Function: GetDistanceToDestinationUnit
 * D
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetDistanceToDestinationUnit( void);

/**
 * Function: GetDistanceToManeuver
 * B1
 * NISSAN
 */
void HSA_Navigation_Map__vGetDistanceToManeuver(GUI_String *out_result);

/**
 * Function: GetDistanceToManeuverUnit
 * D
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetDistanceToManeuverUnit( void);

/**
 * Function: GetTurnToStreet
 * B1
 * NISSAN
 */
void HSA_Navigation_Map__vGetTurnToStreet(GUI_String *out_result);

/**
 * Function: Init
 * B1
 * NISSAN
 */
void HSA_Navigation_Map__vInit( void);

/**
 * Function: IsInitialized
 * B
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwIsInitialized( void);

/**
 * Function: IsDriveManeuverPresent
 * B2
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsDriveManeuverPresent( void);

/**
 * Function: ShowTurnToStreet
 * B
 * NISSAN
 */
tbool HSA_Navigation_Map__blShowTurnToStreet( void);

/**
 * Function: ShowDistanceToManeuver
 * B
 * NISSAN
 */
tbool HSA_Navigation_Map__blShowDistanceToManeuver( void);

/**
 * Function: ShowActiveGuidanceSymbol
 * B
 * NISSAN
 */
tbool HSA_Navigation_Map__blShowActiveGuidanceSymbol( void);

/**
 * Function: MainZoomGetValue
 * B
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwMainZoomGetValue( void);

/**
 * Function: MainZoomInStep
 * B-Deprecated
 * NISSAN
 */
void HSA_Navigation_Map__vMainZoomInStep( void);

/**
 * Function: MainZoomOutStep
 * B-Deprecated
 * NISSAN
 */
void HSA_Navigation_Map__vMainZoomOutStep( void);

/**
 * Function: SetActiveTimeDisplay
 * B1
 * NISSAN
 */
void HSA_Navigation_Map__vSetActiveTimeDisplay(ulword ulwMode);

/**
 * Function: IsBargraphActive
 * NISSAN 1.5
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsBargraphActive( void);

/**
 * Function: GetBargraphValue
 * NISSAN 1.5
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetBargraphValue( void);

/**
 * Function: IsSpeedLimitAvailable
 * NISSAN 2.0
 * NISSAN
 */
tbool HSA_Navigation_Map__blIsSpeedLimitAvailable( void);

/**
 * Function: IsRouteCompletelyCalculated
 * 
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwIsRouteCompletelyCalculated( void);

/**
 * Function: SpeedLimitGetValue
 * NISSAN 2.0
 * NISSAN
 */
void HSA_Navigation_Map__vSpeedLimitGetValue(GUI_String *out_result);

/**
 * Function: SplitScreenClose
 * VWLL RNS315 China
 * NISSAN
 */
void HSA_Navigation_Map__vSplitScreenClose( void);

/**
 * Function: SplitScreenGetMapPosition
 * VWLL RNS315 China
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwSplitScreenGetMapPosition( void);

/**
 * Function: SplitScreenRightColumnElementStart
 * VWLL RNS315 China
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwSplitScreenRightColumnElementStart( void);

/**
 * Function: GetHWETurnToStreet
 * NISSAN 2.0
 * NISSAN
 */
void HSA_Navigation_Map__vGetHWETurnToStreet(GUI_String *out_result);

/**
 * Function: GetHWESignPost
 * NISSAN 2.0
 * NISSAN
 */
void HSA_Navigation_Map__vGetHWESignPost(GUI_String *out_result);

/**
 * Function: GetHWENumber
 * NISSAN 2.0
 * NISSAN
 */
void HSA_Navigation_Map__vGetHWENumber(GUI_String *out_result);

/**
 * Function: GetHWESignpostBGImgIndex
 * NISSAN 2.0
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetHWESignpostBGImgIndex( void);

/**
 * Function: GetHWESignpostTextColor
 * NISSAN 2.0
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetHWESignpostTextColor( void);

/**
 * Function: GetHWEInfoPosition
 * NISSAN 2.0
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetHWEInfoPosition( void);

/**
 * Function: SetFramerateToLow
 * NISSAN LCN2KAI
 * NISSAN
 */
void HSA_Navigation_Map__vSetFramerateToLow( void);

/**
 * Function: SetFramerateToNormal
 * NISSAN LCN2KAI
 * NISSAN
 */
void HSA_Navigation_Map__vSetFramerateToNormal( void);

/**
 * Function: SetupGetPresetInfoAvailability
 * 
 * NISSAN
 */
tbool HSA_Navigation_Map__blSetupGetPresetInfoAvailability( void);

/**
 * Function: TogglePresetInfoState
 * Nissan 2.0
 * NISSAN
 */
void HSA_Navigation_Map__vTogglePresetInfoState( void);

/**
 * Function: GetActWeatherMapType
 * LCN2Kai
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetActWeatherMapType( void);

/**
 * Function: PrepareWeatherMap
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation_Map__vPrepareWeatherMap(ulword ulwWeatherMapType);

/**
 * Function: HasWeatherMapLoadingStarted
 * LCN2Kai
 * NISSAN
 */
tbool HSA_Navigation_Map__blHasWeatherMapLoadingStarted( void);

/**
 * Function: GetStormCellMovementSpeed
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation_Map__vGetStormCellMovementSpeed(GUI_String *out_result);

/**
 * Function: GetStormCellEchoTopHeight
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation_Map__vGetStormCellEchoTopHeight(GUI_String *out_result);

/**
 * Function: GetStormCellIssueTime
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation_Map__vGetStormCellIssueTime(GUI_String *out_result);

/**
 * Function: ClearStormCellPickedData
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation_Map__vClearStormCellPickedData( void);

/**
 * Function: GetNumberOfStormTracks
 * LCN2Kai
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetNumberOfStormTracks( void);

/**
 * Function: GetStormTrackerName
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation_Map__vGetStormTrackerName(GUI_String *out_result);

/**
 * Function: GetStormTrackerInfoWeatherStromType
 * LCN2Kai
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetStormTrackerInfoWeatherStromType( void);

/**
 * Function: GetStormTrackerInfoSpeed
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation_Map__vGetStormTrackerInfoSpeed(GUI_String *out_result);

/**
 * Function: GetStormTrackerInfoMaxSustainedWinds
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation_Map__vGetStormTrackerInfoMaxSustainedWinds(GUI_String *out_result);

/**
 * Function: GetStormTrackerInfoGusts
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation_Map__vGetStormTrackerInfoGusts(GUI_String *out_result);

/**
 * Function: GetStormTrackerInfoPressure
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation_Map__vGetStormTrackerInfoPressure(GUI_String *out_result);

/**
 * Function: GetStormTrackerInfoIssueTime
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation_Map__vGetStormTrackerInfoIssueTime(GUI_String *out_result);

/**
 * Function: GetStormTrackerInfoDateMM
 * LCN2Kai
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetStormTrackerInfoDateMM( void);

/**
 * Function: GetStormTrackerInfoDateDD
 * LCN2Kai
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetStormTrackerInfoDateDD( void);

/**
 * Function: GetStormTrackerInfoDateYYYY
 * LCN2Kai
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetStormTrackerInfoDateYYYY( void);

/**
 * Function: ClearStormTrackerInfoPickedData
 * LCN2Kai
 * NISSAN
 */
void HSA_Navigation_Map__vClearStormTrackerInfoPickedData( void);

/**
 * Function: POIMapPrepareGuidance
 * B
 * NISSAN
 */
void HSA_Navigation_Map__vPOIMapPrepareGuidance(ulword ulwListEntryNr);

/**
 * Function: GetPOIListCount
 * Nissan LCN2KAI
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetPOIListCount( void);

/**
 * Function: GetPOIListString
 * Nissan LCN2KAI
 * NISSAN
 */
void HSA_Navigation_Map__vGetPOIListString(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr);

/**
 * Function: GetPOIListValue
 * Nissan LCN2KAI
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwGetPOIListValue(ulword ulwCell, ulword ulwListEntryNr);

/**
 * Function: POIActivateDetails
 * Nissan LCN2KAI
 * NISSAN
 */
void HSA_Navigation_Map__vPOIActivateDetails(ulword ulwListEntryNr);

/**
 * Function: POIMapGetListUnit
 * D
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwPOIMapGetListUnit( void);

/**
 * Function: SetWeatherMapLegendDisplayState
 * Nissan LCN2KAI
 * NISSAN
 */
void HSA_Navigation_Map__vSetWeatherMapLegendDisplayState( void);

/**
 * Function: GetWeatherMapLegendDisplayState
 * Nissan LCN2KAI
 * NISSAN
 */
tbool HSA_Navigation_Map__blGetWeatherMapLegendDisplayState( void);

/**
 * Function: SetCrossHairVisible
 * NISSAN ITG5
 * NISSAN
 */
void HSA_Navigation_Map__vSetCrossHairVisible(tbool blVisibility);

/**
 * Function: ITCommanderRelease
 * NISSAN ITG5
 * NISSAN
 */
void HSA_Navigation_Map__vITCommanderRelease( void);

/**
 * Function: ITCommanderPress
 * NISSAN ITG5
 * NISSAN
 */
void HSA_Navigation_Map__vITCommanderPress(ulword ulwDirectionValue, tbool blReleaseType);

/**
 * Function: ITCommanderSelect
 * NISSAN ITG5
 * NISSAN
 */
void HSA_Navigation_Map__vITCommanderSelect(ulword ulwPosX, ulword ulwPosY);

/**
 * Function: SwitchRoadActivate
 * NISSAN ITG5
 * NISSAN
 */
void HSA_Navigation_Map__vSwitchRoadActivate( void);

/**
 * Function: SwitchRoadDeactivate
 *  NISSAN ITG5
 * NISSAN
 */
void HSA_Navigation_Map__vSwitchRoadDeactivate( void);

/**
 * Function: SwitchRoadToggle
 *  NISSAN ITG5
 * NISSAN
 */
void HSA_Navigation_Map__vSwitchRoadToggle( void);

/**
 * Function: SwitchRoadGetStatus
 *  NISSAN ITG5
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwSwitchRoadGetStatus( void);

/**
 * Function: SwitchRoadGetCurrentRoadNumber
 *  NISSAN ITG5
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwSwitchRoadGetCurrentRoadNumber( void);

/**
 * Function: SwitchRoadGetNumberOfRoads
 *  NISSAN ITG5
 * NISSAN
 */
ulword HSA_Navigation_Map__ulwSwitchRoadGetNumberOfRoads( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_Navigation_Map_H

