/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_Navigation_Map_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_Navigation/HSA_Map/clHSA_Navigation_Map_Base.h"

clHSA_Navigation_Map_Base* clHSA_Navigation_Map_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_Navigation_Map_Base.cpp.trc.h"
#endif


/**
 * Method: vSetSplitScreenConf
  * gives a confimation to the requested split screen state to control activation
  * B2
 */
void clHSA_Navigation_Map_Base::vSetSplitScreenConf(ulword ulwConfType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwConfType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetSplitScreenConf not implemented"));
   
}

/**
 * Method: ulwGetSplitScreenState
  * Returns the actual state of the HSI layer state machine for split screen control
  * B2
 */
ulword clHSA_Navigation_Map_Base::ulwGetSplitScreenState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetSplitScreenState not implemented"));
   return 0;
}

/**
 * Method: vSetSplitScreenLock
  * the HMI wishes to abort or to lock any split screen displaying or enables it again
  * B2
 */
void clHSA_Navigation_Map_Base::vSetSplitScreenLock(ulword ulwLockMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLockMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetSplitScreenLock not implemented"));
   
}

/**
 * Method: ulwGetSplitScreenLockState
  * Returns if displaying of a split is enabled or locked
  * B2
 */
ulword clHSA_Navigation_Map_Base::ulwGetSplitScreenLockState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetSplitScreenLockState not implemented"));
   return 0;
}

/**
 * Method: vSetDestFlagForNewMapCenter
  * determine WGS84 coordinate for the last destination and set the requested flag on that position. Operation is finished, after WaitSyncState(0) has returned TRUE
  * NISSAN LCN NAR
 */
void clHSA_Navigation_Map_Base::vSetDestFlagForNewMapCenter(ulword ulwFlagType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwFlagType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetDestFlagForNewMapCenter not implemented"));
   
}

/**
 * Method: blIsCameraWarningAvailable
  * Checking availabilty of camera warning
  * Nissan 2.0
 */
tbool clHSA_Navigation_Map_Base::blIsCameraWarningAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsCameraWarningAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsCurveWarningAvailable
  * Checking availabilty of curve warning
  * Nissan 2.0
 */
tbool clHSA_Navigation_Map_Base::blIsCurveWarningAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsCurveWarningAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsOverSpeedWarningAvailable
  * Checking availabilty of overspeed warning
  * Nissan 2.0
 */
tbool clHSA_Navigation_Map_Base::blIsOverSpeedWarningAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsOverSpeedWarningAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsWarningDistanceAvailable
  * Checking availability of distance to next camera, speedlimit or curve warning
  * Nissan 2.0
 */
tbool clHSA_Navigation_Map_Base::blIsWarningDistanceAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsWarningDistanceAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsLaneDisplayAvailable
  * Checking availabilty of Lane Info
  * Nissan 2.0
 */
tbool clHSA_Navigation_Map_Base::blIsLaneDisplayAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsLaneDisplayAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsLaneGuidanceLeftVisible
  * Checking availabilty of Lane Info
  * Nissan 2.0
 */
tbool clHSA_Navigation_Map_Base::blIsLaneGuidanceLeftVisible( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsLaneGuidanceLeftVisible not implemented"));
   return 0;
}

/**
 * Method: blIsLaneGuidanceCenterVisible
  * Checking availabilty of Lane Info
  * Nissan 2.0
 */
tbool clHSA_Navigation_Map_Base::blIsLaneGuidanceCenterVisible( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsLaneGuidanceCenterVisible not implemented"));
   return 0;
}

/**
 * Method: vGetLaneGuidanceSymbols
  * Returns the symbols for lane guidance as text (left and right border symbols and arrow symbols). 
  * B
 */
void clHSA_Navigation_Map_Base::vGetLaneGuidanceSymbols(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetLaneGuidanceSymbols not implemented"));
   
}

/**
 * Method: vCameraWarningGetValue
  * Take void as parameter and Returns the CameraWarning Distance(int)value as string 
  * Nissan 2.0
 */
void clHSA_Navigation_Map_Base::vCameraWarningGetValue(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vCameraWarningGetValue not implemented"));
   
}

/**
 * Method: ulwCameraWarningGetUnit
  * Take void as parameter and Returns the CameraWarning Distance's units as an index 
  * Nissan 2.0
 */
ulword clHSA_Navigation_Map_Base::ulwCameraWarningGetUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwCameraWarningGetUnit not implemented"));
   return 0;
}

/**
 * Method: ulwCurvewarningGetValue
  * Take void as parameter and Returns CurveWarning value as int value and depending upon that int ,an image will be selected array of images based on index value 
  * Nissan 2.0
 */
ulword clHSA_Navigation_Map_Base::ulwCurvewarningGetValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwCurvewarningGetValue not implemented"));
   return 0;
}

/**
 * Method: ulwLaneDisplayGetValue
  * Take void as parameter and Returns LaneDisplay value as int value and depending upon that int ,an image will be selected array of images based on index value   
  * Nissan 2.0
 */
ulword clHSA_Navigation_Map_Base::ulwLaneDisplayGetValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwLaneDisplayGetValue not implemented"));
   return 0;
}

/**
 * Method: vToggleCurveWarning
  * Toggle CurveWarning 0 for off, 1 for on, 2 for on+beep 
  * Nissan 2.0
 */
void clHSA_Navigation_Map_Base::vToggleCurveWarning( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vToggleCurveWarning not implemented"));
   
}

/**
 * Method: ulwGetCurveWarningState
  * User can activate/deactivate the curve warning in setup. This API will return the curve warning settting by the user
  * Nissan 2.0
 */
ulword clHSA_Navigation_Map_Base::ulwGetCurveWarningState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetCurveWarningState not implemented"));
   return 0;
}

/**
 * Method: vToggleOverSpeedWarning
  * Toggle OverSpeedWarning 0 for off, 1 for on, 2 for on+beep 
  * Nissan 2.0
 */
void clHSA_Navigation_Map_Base::vToggleOverSpeedWarning( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vToggleOverSpeedWarning not implemented"));
   
}

/**
 * Method: ulwGetOverSpeedWarningState
  * User can set the Overspeed warning in setup. This API will return the overspeed settting by the user
  * Nissan 2.0
 */
ulword clHSA_Navigation_Map_Base::ulwGetOverSpeedWarningState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetOverSpeedWarningState not implemented"));
   return 0;
}

/**
 * Method: vGetOverSpeedThreshold
  * User can set the Overspeed threshold- This API will return the set overspeed set by the user
  * Nissan 2.0
 */
void clHSA_Navigation_Map_Base::vGetOverSpeedThreshold(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetOverSpeedThreshold not implemented"));
   
}

/**
 * Method: vOverSpeedThresholdHandling
  * OverSpeedThreshold  change by encoder. 0 for decrement, 1 for increment
  * Nissan 2.0
 */
void clHSA_Navigation_Map_Base::vOverSpeedThresholdHandling(ulword ulwConfType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwConfType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vOverSpeedThresholdHandling not implemented"));
   
}

/**
 * Method: vSetDragMapMode
  * defines the mode for the 2D_SCROLLMAP, which operations are possible
  * NISSAN LCN NAR
 */
void clHSA_Navigation_Map_Base::vSetDragMapMode(ulword ulwOperationMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwOperationMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetDragMapMode not implemented"));
   
}

/**
 * Method: blGetActDestFlagType
  * returns the actual preselected FlagType for user operation of destination setting
  * NISSAN LCN NAR
 */
tbool clHSA_Navigation_Map_Base::blGetActDestFlagType( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blGetActDestFlagType not implemented"));
   return 0;
}

/**
 * Method: blIsDestFlagMoved
  * returns whether the destination has been moved to another position
  * NISSAN LCN NAR
 */
tbool clHSA_Navigation_Map_Base::blIsDestFlagMoved( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsDestFlagMoved not implemented"));
   return 0;
}

/**
 * Method: blFlagDestEntryIsValid
  * returns whether the 'MapFlagDest'-Object is valid (able to guide or not)
  * NISSAN LCN QQ
 */
tbool clHSA_Navigation_Map_Base::blFlagDestEntryIsValid( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blFlagDestEntryIsValid not implemented"));
   return 0;
}

/**
 * Method: blCarPositionIsValid
  * returns whether the 'CarPosition' for starting map calculation is valid (scrolling is allowed or not)
  * NISSAN LCN QQ
 */
tbool clHSA_Navigation_Map_Base::blCarPositionIsValid( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blCarPositionIsValid not implemented"));
   return 0;
}

/**
 * Method: vGetFlagDestName
  * Returns the current street name
  * NISSAN
 */
void clHSA_Navigation_Map_Base::vGetFlagDestName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetFlagDestName not implemented"));
   
}

/**
 * Method: blGetMapRepresentationMode
  * Returns the status of map representation variants.
  * 
 */
tbool clHSA_Navigation_Map_Base::blGetMapRepresentationMode(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blGetMapRepresentationMode not implemented"));
   return 0;
}

/**
 * Method: vSetMapRepresentationMode2DCarHeading
  * Activates or deactivates the map representation mode "2D Car heading".
  * 
 */
void clHSA_Navigation_Map_Base::vSetMapRepresentationMode2DCarHeading(ulword ulwState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetMapRepresentationMode2DCarHeading not implemented"));
   
}

/**
 * Method: vSetMapRepresentationMode2DNorth
  * Activates or deactivates the map representation mode "2D North up".
  * 
 */
void clHSA_Navigation_Map_Base::vSetMapRepresentationMode2DNorth(ulword ulwState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetMapRepresentationMode2DNorth not implemented"));
   
}

/**
 * Method: vSetMapRepresentationMode3DCarHeading
  * Activates or deactivates the map representation mode "3D Car heading".
  * 
 */
void clHSA_Navigation_Map_Base::vSetMapRepresentationMode3DCarHeading(ulword ulwState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetMapRepresentationMode3DCarHeading not implemented"));
   
}

/**
 * Method: vToggleMapOrientation
  * toggles the map orientation for 2D_MAP between HEAD_UP and NORTH_UP, for 3D there is only HEAD_UP is supported
  * NISSAN
 */
void clHSA_Navigation_Map_Base::vToggleMapOrientation( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vToggleMapOrientation not implemented"));
   
}

/**
 * Method: vTogglePOILabelState
  * Toggles the POI Label States 
  * NISSAN 1.5
 */
void clHSA_Navigation_Map_Base::vTogglePOILabelState(ulword ulwPOIListitem)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPOIListitem);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vTogglePOILabelState not implemented"));
   
}

/**
 * Method: blGetPOILabelState
  * Get the each POI Toggle state
  * NISSAN 1.5
 */
tbool clHSA_Navigation_Map_Base::blGetPOILabelState(ulword ulwPOIListitem)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPOIListitem);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blGetPOILabelState not implemented"));
   return 0;
}

/**
 * Method: vPOILabelApplyInput
  * Apply the POI configuration to MAP
  * NISSAN 1.5
 */
void clHSA_Navigation_Map_Base::vPOILabelApplyInput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vPOILabelApplyInput not implemented"));
   
}

/**
 * Method: ulwGetMapOrientation
  * Returns the active map orientation (HEAD_UP / NORTH_UP in 2D_MAP mode, HEAD_UP only in 3D_MAP mode) 
  * NISSAN
 */
ulword clHSA_Navigation_Map_Base::ulwGetMapOrientation( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetMapOrientation not implemented"));
   return 0;
}

/**
 * Method: vSetVoiceGuidance
  * To set the voice Guidance ON/OFF
  * NISSAN
 */
void clHSA_Navigation_Map_Base::vSetVoiceGuidance(tbool blNaviVoice)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blNaviVoice);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetVoiceGuidance not implemented"));
   
}

/**
 * Method: blGetVoiceGuidance
  * To get the Current Navi Voice guidance state
  * NISSAN
 */
tbool clHSA_Navigation_Map_Base::blGetVoiceGuidance( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blGetVoiceGuidance not implemented"));
   return 0;
}

/**
 * Method: vToggleUserMap
  * toggles the user activated map mode between 2D_MAP and 3D_MAP
  * NISSAN
 */
void clHSA_Navigation_Map_Base::vToggleUserMap( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vToggleUserMap not implemented"));
   
}

/**
 * Method: ulwGetUserMap
  * Returns the active user map mode
  * NISSAN
 */
ulword clHSA_Navigation_Map_Base::ulwGetUserMap( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetUserMap not implemented"));
   return 0;
}

/**
 * Method: vInitMap
  * initializes the requested map
  * NISSAN
 */
void clHSA_Navigation_Map_Base::vInitMap(ulword ulwMapType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMapType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vInitMap not implemented"));
   
}

/**
 * Method: blIsMapVisible
  * returns whether the MapType to be checked is active or not
  * NISSAN
 */
tbool clHSA_Navigation_Map_Base::blIsMapVisible(ulword ulwMapType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMapType);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsMapVisible not implemented"));
   return 0;
}

/**
 * Method: vMapTouched
  * first PenDown action in 2D_SCROLLMAP removes always a destination flag
  * NISSAN
 */
void clHSA_Navigation_Map_Base::vMapTouched( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vMapTouched not implemented"));
   
}

/**
 * Method: vMapReleased
  * PenUp whitout any movement sets a destination flag in 2D_SCROLLMAP
  * NISSAN
 */
void clHSA_Navigation_Map_Base::vMapReleased(slword slwPosX, slword slwPosY)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwPosX);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwPosY);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vMapReleased not implemented"));
   
}

/**
 * Method: vMapDragged
  * PenDown movement freezes and drags a map in 2D_SCROLLMAP
  * NISSAN
 */
void clHSA_Navigation_Map_Base::vMapDragged(slword slwDeltaX, slword slwDeltaY, ulword ulwPenState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwDeltaX);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwDeltaY);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPenState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vMapDragged not implemented"));
   
}

/**
 * Method: vMapDraggedAbsPos
  * to be called if the absolute values with start and end position for the movement of the ScrollMap are given
  * LCN2kai
 */
void clHSA_Navigation_Map_Base::vMapDraggedAbsPos(slword slwLastAbsX, slword slwLastAbsY, slword slwMovedToAbsX, slword slwMovedToAbsY)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwLastAbsX);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwLastAbsY);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwMovedToAbsX);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwMovedToAbsY);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vMapDraggedAbsPos not implemented"));
   
}

/**
 * Method: blIsDestFlagSet
  * returns whether a destination flag is set in 2D_SCROLLMAP
  * NISSAN
 */
tbool clHSA_Navigation_Map_Base::blIsDestFlagSet( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsDestFlagSet not implemented"));
   return 0;
}

/**
 * Method: vAutoZoomActivate
  * Activates or deactivates the auto-zoom even it was already (de-) activated
  * B
 */
void clHSA_Navigation_Map_Base::vAutoZoomActivate(tbool blState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vAutoZoomActivate not implemented"));
   
}

/**
 * Method: blAutoZoomActive
  * Returns whether the map zoomes automatically or not
  * B
 */
tbool clHSA_Navigation_Map_Base::blAutoZoomActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blAutoZoomActive not implemented"));
   return 0;
}

/**
 * Method: blControlBarStateGet
  * returns weather the contolbar in shown or not (just an data-container)
  * B1-Deprecated
 */
tbool clHSA_Navigation_Map_Base::blControlBarStateGet( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blControlBarStateGet not implemented"));
   return 0;
}

/**
 * Method: vControlBarStateToggle
  * toggles the state of the controlbar, it it is shown or hided
  * B1-Deprecated
 */
void clHSA_Navigation_Map_Base::vControlBarStateToggle( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vControlBarStateToggle not implemented"));
   
}

/**
 * Method: vDraw
  * Comment to draw the map
  * B1
 */
void clHSA_Navigation_Map_Base::vDraw( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vDraw not implemented"));
   
}

/**
 * Method: vDrawStop
  * Comment to stop drawing the map
  * B
 */
void clHSA_Navigation_Map_Base::vDrawStop( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vDrawStop not implemented"));
   
}

/**
 * Method: vDrawCarsor
  * Comment to draw the carsor
  * B1-Deprecated
 */
void clHSA_Navigation_Map_Base::vDrawCarsor( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vDrawCarsor not implemented"));
   
}

/**
 * Method: vHideCarsor
  * Comment to hide the carsor
  * B1-Deprecated
 */
void clHSA_Navigation_Map_Base::vHideCarsor( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vHideCarsor not implemented"));
   
}

/**
 * Method: ulwGetActiveGuidanceSymbol
  * Returns the current type of guidance-symbol to draw in Map
  * B1
 */
ulword clHSA_Navigation_Map_Base::ulwGetActiveGuidanceSymbol( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetActiveGuidanceSymbol not implemented"));
   return 0;
}

/**
 * Method: ulwGetBarGraphSymbol
  * Returns the current bar graph symbol
  * B
 */
ulword clHSA_Navigation_Map_Base::ulwGetBarGraphSymbol( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetBarGraphSymbol not implemented"));
   return 0;
}

/**
 * Method: ulwGetActiveTimeDisplay
  * Returns which time (arrival or drive) should be shown
  * B1
 */
ulword clHSA_Navigation_Map_Base::ulwGetActiveTimeDisplay( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetActiveTimeDisplay not implemented"));
   return 0;
}

/**
 * Method: vGetActiveTimeDisplayValue
  * Returns the corresponding  time (arrival (ETA) or drive (RTT)) value
  * B1
 */
void clHSA_Navigation_Map_Base::vGetActiveTimeDisplayValue(GUI_String *out_result, ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetActiveTimeDisplayValue not implemented"));
   
}

/**
 * Method: ulwGetCurrentNorthUpSymbol
  * Returns the current type of NorthUp-symbol to draw in Map
  * B1
 */
ulword clHSA_Navigation_Map_Base::ulwGetCurrentNorthUpSymbol( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetCurrentNorthUpSymbol not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentStreet
  * Returns the current street name
  * B1
 */
void clHSA_Navigation_Map_Base::vGetCurrentStreet(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetCurrentStreet not implemented"));
   
}

/**
 * Method: vGetDistanceToDestination
  * Returns the Distance to destination in 100 m steps
  * B1
 */
void clHSA_Navigation_Map_Base::vGetDistanceToDestination(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetDistanceToDestination not implemented"));
   
}

/**
 * Method: ulwGetDistanceToDestinationUnit
  * Returns the Distance unit index to destination
  * D
 */
ulword clHSA_Navigation_Map_Base::ulwGetDistanceToDestinationUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetDistanceToDestinationUnit not implemented"));
   return 0;
}

/**
 * Method: vGetDistanceToManeuver
  * Returns the Distance to next maneuver.
  * B1
 */
void clHSA_Navigation_Map_Base::vGetDistanceToManeuver(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetDistanceToManeuver not implemented"));
   
}

/**
 * Method: ulwGetDistanceToManeuverUnit
  * Returns the Distance unit index to next maneuver.
  * D
 */
ulword clHSA_Navigation_Map_Base::ulwGetDistanceToManeuverUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetDistanceToManeuverUnit not implemented"));
   return 0;
}

/**
 * Method: vGetTurnToStreet
  * Returns the TurnTo street name
  * B1
 */
void clHSA_Navigation_Map_Base::vGetTurnToStreet(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetTurnToStreet not implemented"));
   
}

/**
 * Method: vInit
  * Initializes the map
  * B1
 */
void clHSA_Navigation_Map_Base::vInit( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vInit not implemented"));
   
}

/**
 * Method: ulwIsInitialized
  * checks if the map-device is initialized
  * B
 */
ulword clHSA_Navigation_Map_Base::ulwIsInitialized( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwIsInitialized not implemented"));
   return 0;
}

/**
 * Method: blIsDriveManeuverPresent
  * returns currently a driving maneuver is present
  * B2
 */
tbool clHSA_Navigation_Map_Base::blIsDriveManeuverPresent( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsDriveManeuverPresent not implemented"));
   return 0;
}

/**
 * Method: blShowTurnToStreet
  * Returns the turn to street indication state
  * B
 */
tbool clHSA_Navigation_Map_Base::blShowTurnToStreet( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blShowTurnToStreet not implemented"));
   return 0;
}

/**
 * Method: blShowDistanceToManeuver
  * Returns the distance to maneuver indication state
  * B
 */
tbool clHSA_Navigation_Map_Base::blShowDistanceToManeuver( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blShowDistanceToManeuver not implemented"));
   return 0;
}

/**
 * Method: blShowActiveGuidanceSymbol
  * Returns the active guidance symbol state
  * B
 */
tbool clHSA_Navigation_Map_Base::blShowActiveGuidanceSymbol( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blShowActiveGuidanceSymbol not implemented"));
   return 0;
}

/**
 * Method: ulwMainZoomGetValue
  * Gets the current zoom-value
  * B
 */
ulword clHSA_Navigation_Map_Base::ulwMainZoomGetValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwMainZoomGetValue not implemented"));
   return 0;
}

/**
 * Method: vMainZoomInStep
  * Decreases the current zoom (zoom in) by one large-step, until the minimum (1) is reached
  * B-Deprecated
 */
void clHSA_Navigation_Map_Base::vMainZoomInStep( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vMainZoomInStep not implemented"));
   
}

/**
 * Method: vMainZoomOutStep
  * Increases the current zoom (zoom out) by one large-step, until the maximum (6) is reached
  * B-Deprecated
 */
void clHSA_Navigation_Map_Base::vMainZoomOutStep( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vMainZoomOutStep not implemented"));
   
}

/**
 * Method: vSetActiveTimeDisplay
  * sets the new time which shold be shown
  * B1
 */
void clHSA_Navigation_Map_Base::vSetActiveTimeDisplay(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetActiveTimeDisplay not implemented"));
   
}

/**
 * Method: blIsBargraphActive
  * Returns, if there is a bargraph to next maneuver point
  * NISSAN 1.5
 */
tbool clHSA_Navigation_Map_Base::blIsBargraphActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsBargraphActive not implemented"));
   return 0;
}

/**
 * Method: ulwGetBargraphValue
  * Gets the current bargraph value, if available
  * NISSAN 1.5
 */
ulword clHSA_Navigation_Map_Base::ulwGetBargraphValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetBargraphValue not implemented"));
   return 0;
}

/**
 * Method: blIsSpeedLimitAvailable
  * Returns if a speed limit is currently present.
  * NISSAN 2.0
 */
tbool clHSA_Navigation_Map_Base::blIsSpeedLimitAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blIsSpeedLimitAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwIsRouteCompletelyCalculated
  * Returns the status of the route calculation to ensure that the survey map could be displayed correctly with all informations determined. 
  * 
 */
ulword clHSA_Navigation_Map_Base::ulwIsRouteCompletelyCalculated( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwIsRouteCompletelyCalculated not implemented"));
   return 0;
}

/**
 * Method: vSpeedLimitGetValue
  * To display the value provided by HMI-Navserver
  * NISSAN 2.0
 */
void clHSA_Navigation_Map_Base::vSpeedLimitGetValue(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSpeedLimitGetValue not implemented"));
   
}

/**
 * Method: vSplitScreenClose
  * Closes the split screen by user touch on the map if highway entrance picture is visible.
  * VWLL RNS315 China
 */
void clHSA_Navigation_Map_Base::vSplitScreenClose( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSplitScreenClose not implemented"));
   
}

/**
 * Method: ulwSplitScreenGetMapPosition
  * returns where the map is situated in split screen mode
  * VWLL RNS315 China
 */
ulword clHSA_Navigation_Map_Base::ulwSplitScreenGetMapPosition( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwSplitScreenGetMapPosition not implemented"));
   return 0;
}

/**
 * Method: ulwSplitScreenRightColumnElementStart
  * Returns the right column element start of split screen.
  * VWLL RNS315 China
 */
ulword clHSA_Navigation_Map_Base::ulwSplitScreenRightColumnElementStart( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwSplitScreenRightColumnElementStart not implemented"));
   return 0;
}

/**
 * Method: vGetHWETurnToStreet
  * To get turn to streetname in Highway entrance/exit pictures on Map
  * NISSAN 2.0
 */
void clHSA_Navigation_Map_Base::vGetHWETurnToStreet(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetHWETurnToStreet not implemented"));
   
}

/**
 * Method: vGetHWESignPost
  * To get signpost in Highway entrance/exit pictures on Map
  * NISSAN 2.0
 */
void clHSA_Navigation_Map_Base::vGetHWESignPost(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetHWESignPost not implemented"));
   
}

/**
 * Method: vGetHWENumber
  * To get HWENumber in Highway entrance/exit pictures on Map
  * NISSAN 2.0
 */
void clHSA_Navigation_Map_Base::vGetHWENumber(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetHWENumber not implemented"));
   
}

/**
 * Method: ulwGetHWESignpostBGImgIndex
  * To get the Background Image Configuration.
  * NISSAN 2.0
 */
ulword clHSA_Navigation_Map_Base::ulwGetHWESignpostBGImgIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetHWESignpostBGImgIndex not implemented"));
   return 0;
}

/**
 * Method: ulwGetHWESignpostTextColor
  * To get the Text Color, which is also the Exit Number Box Border color.
  * NISSAN 2.0
 */
ulword clHSA_Navigation_Map_Base::ulwGetHWESignpostTextColor( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetHWESignpostTextColor not implemented"));
   return 0;
}

/**
 * Method: ulwGetHWEInfoPosition
  * returns the actual position for the highway exit info (road sign information) overlapping the HEG picture
  * NISSAN 2.0
 */
ulword clHSA_Navigation_Map_Base::ulwGetHWEInfoPosition( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetHWEInfoPosition not implemented"));
   return 0;
}

/**
 * Method: vSetFramerateToLow
  * Lowers the map update rate when entering into SDS context
  * NISSAN LCN2KAI
 */
void clHSA_Navigation_Map_Base::vSetFramerateToLow( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetFramerateToLow not implemented"));
   
}

/**
 * Method: vSetFramerateToNormal
  * Sets the map update rate to normal from low when entering the Map context
  * NISSAN LCN2KAI
 */
void clHSA_Navigation_Map_Base::vSetFramerateToNormal( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetFramerateToNormal not implemented"));
   
}

/**
 * Method: blSetupGetPresetInfoAvailability
  * Returns whether the Preset information option in the map is turned on or off 
  * 
 */
tbool clHSA_Navigation_Map_Base::blSetupGetPresetInfoAvailability( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blSetupGetPresetInfoAvailability not implemented"));
   return 0;
}

/**
 * Method: vTogglePresetInfoState
  * Toggle the Preset Information setting 0 for off, 1 for on 
  * Nissan 2.0
 */
void clHSA_Navigation_Map_Base::vTogglePresetInfoState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vTogglePresetInfoState not implemented"));
   
}

/**
 * Method: ulwGetActWeatherMapType
  * returns the actual memorized weather map type
  * LCN2Kai
 */
ulword clHSA_Navigation_Map_Base::ulwGetActWeatherMapType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetActWeatherMapType not implemented"));
   return 0;
}

/**
 * Method: vPrepareWeatherMap
  * All required weather information are requested if a special weather map is entered first time. Except for WeatherMapType == END_SHOWING a following WaitSyncState(0) step is expected
  * LCN2Kai
 */
void clHSA_Navigation_Map_Base::vPrepareWeatherMap(ulword ulwWeatherMapType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwWeatherMapType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vPrepareWeatherMap not implemented"));
   
}

/**
 * Method: blHasWeatherMapLoadingStarted
  * returns the state of weather data loading
  * LCN2Kai
 */
tbool clHSA_Navigation_Map_Base::blHasWeatherMapLoadingStarted( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blHasWeatherMapLoadingStarted not implemented"));
   return 0;
}

/**
 * Method: vGetStormCellMovementSpeed
  * returns the actual movement speed of the picked storm cell
  * LCN2Kai
 */
void clHSA_Navigation_Map_Base::vGetStormCellMovementSpeed(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetStormCellMovementSpeed not implemented"));
   
}

/**
 * Method: vGetStormCellEchoTopHeight
  * returns the actual echo top height of the picked storm cell
  * LCN2Kai
 */
void clHSA_Navigation_Map_Base::vGetStormCellEchoTopHeight(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetStormCellEchoTopHeight not implemented"));
   
}

/**
 * Method: vGetStormCellIssueTime
  * returns the observation time of the picked storm cell
  * LCN2Kai
 */
void clHSA_Navigation_Map_Base::vGetStormCellIssueTime(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetStormCellIssueTime not implemented"));
   
}

/**
 * Method: vClearStormCellPickedData
  * to be called by the menu after overlay window has shown the StormCellInfo
  * LCN2Kai
 */
void clHSA_Navigation_Map_Base::vClearStormCellPickedData( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vClearStormCellPickedData not implemented"));
   
}

/**
 * Method: ulwGetNumberOfStormTracks
  * Returns the Number of StormTracks.
  * LCN2Kai
 */
ulword clHSA_Navigation_Map_Base::ulwGetNumberOfStormTracks( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetNumberOfStormTracks not implemented"));
   return 0;
}

/**
 * Method: vGetStormTrackerName
  * returns the name of the picked strom tracker info
  * LCN2Kai
 */
void clHSA_Navigation_Map_Base::vGetStormTrackerName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetStormTrackerName not implemented"));
   
}

/**
 * Method: ulwGetStormTrackerInfoWeatherStromType
  * returns the storm type of the picked strom tracker info
  * LCN2Kai
 */
ulword clHSA_Navigation_Map_Base::ulwGetStormTrackerInfoWeatherStromType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetStormTrackerInfoWeatherStromType not implemented"));
   return 0;
}

/**
 * Method: vGetStormTrackerInfoSpeed
  * returns the storm travelling speed of the picked strom tracker info
  * LCN2Kai
 */
void clHSA_Navigation_Map_Base::vGetStormTrackerInfoSpeed(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetStormTrackerInfoSpeed not implemented"));
   
}

/**
 * Method: vGetStormTrackerInfoMaxSustainedWinds
  * returns the max. wind speed in knots of the picked strom tracker info
  * LCN2Kai
 */
void clHSA_Navigation_Map_Base::vGetStormTrackerInfoMaxSustainedWinds(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetStormTrackerInfoMaxSustainedWinds not implemented"));
   
}

/**
 * Method: vGetStormTrackerInfoGusts
  * returns the Gusts speed in knots of the picked strom tracker info
  * LCN2Kai
 */
void clHSA_Navigation_Map_Base::vGetStormTrackerInfoGusts(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetStormTrackerInfoGusts not implemented"));
   
}

/**
 * Method: vGetStormTrackerInfoPressure
  * returns the pressure value in Pascal of the picked strom tracker info
  * LCN2Kai
 */
void clHSA_Navigation_Map_Base::vGetStormTrackerInfoPressure(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetStormTrackerInfoPressure not implemented"));
   
}

/**
 * Method: vGetStormTrackerInfoIssueTime
  * returns the timestamp of the picked strom tracker info
  * LCN2Kai
 */
void clHSA_Navigation_Map_Base::vGetStormTrackerInfoIssueTime(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetStormTrackerInfoIssueTime not implemented"));
   
}

/**
 * Method: ulwGetStormTrackerInfoDateMM
  * returns the month number of date of the picked strom tracker info
  * LCN2Kai
 */
ulword clHSA_Navigation_Map_Base::ulwGetStormTrackerInfoDateMM( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetStormTrackerInfoDateMM not implemented"));
   return 0;
}

/**
 * Method: ulwGetStormTrackerInfoDateDD
  * returns the day number of the date of the picked strom tracker info
  * LCN2Kai
 */
ulword clHSA_Navigation_Map_Base::ulwGetStormTrackerInfoDateDD( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetStormTrackerInfoDateDD not implemented"));
   return 0;
}

/**
 * Method: ulwGetStormTrackerInfoDateYYYY
  * returns the year number of the date of the picked strom tracker info
  * LCN2Kai
 */
ulword clHSA_Navigation_Map_Base::ulwGetStormTrackerInfoDateYYYY( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetStormTrackerInfoDateYYYY not implemented"));
   return 0;
}

/**
 * Method: vClearStormTrackerInfoPickedData
  * to be called by the menu after overlay window has shown the StormTrackerInfo
  * LCN2Kai
 */
void clHSA_Navigation_Map_Base::vClearStormTrackerInfoPickedData( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vClearStormTrackerInfoPickedData not implemented"));
   
}

/**
 * Method: vPOIMapPrepareGuidance
  * selects an entry from the Multi POI-Result-List to prepare it for route guidance
  * B
 */
void clHSA_Navigation_Map_Base::vPOIMapPrepareGuidance(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vPOIMapPrepareGuidance not implemented"));
   
}

/**
 * Method: ulwGetPOIListCount
  * returns the number of found POIs at selected Position
  * Nissan LCN2KAI
 */
ulword clHSA_Navigation_Map_Base::ulwGetPOIListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetPOIListCount not implemented"));
   return 0;
}

/**
 * Method: vGetPOIListString
  * gets information about the found POI-entries
  * Nissan LCN2KAI
 */
void clHSA_Navigation_Map_Base::vGetPOIListString(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCell);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vGetPOIListString not implemented"));
   
}

/**
 * Method: ulwGetPOIListValue
  * Returns information about the direction and category of POIs
  * Nissan LCN2KAI
 */
ulword clHSA_Navigation_Map_Base::ulwGetPOIListValue(ulword ulwCell, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCell);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwGetPOIListValue not implemented"));
   return 0;
}

/**
 * Method: vPOIActivateDetails
  * selects an entry of the POI-List to resolve extended information
  * Nissan LCN2KAI
 */
void clHSA_Navigation_Map_Base::vPOIActivateDetails(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vPOIActivateDetails not implemented"));
   
}

/**
 * Method: ulwPOIMapGetListUnit
  * Returns the Distance unit to POI Map search list items
  * D
 */
ulword clHSA_Navigation_Map_Base::ulwPOIMapGetListUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwPOIMapGetListUnit not implemented"));
   return 0;
}

/**
 * Method: vSetWeatherMapLegendDisplayState
  * Toggles the current state of legend image display on weather map
  * Nissan LCN2KAI
 */
void clHSA_Navigation_Map_Base::vSetWeatherMapLegendDisplayState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetWeatherMapLegendDisplayState not implemented"));
   
}

/**
 * Method: blGetWeatherMapLegendDisplayState
  * Gets the current display status of legend image on weather map
  * Nissan LCN2KAI
 */
tbool clHSA_Navigation_Map_Base::blGetWeatherMapLegendDisplayState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation_Map::blGetWeatherMapLegendDisplayState not implemented"));
   return 0;
}

/**
 * Method: vSetCrossHairVisible
  * Describes if the CrossHair is shown or not on Map
  * NISSAN ITG5
 */
void clHSA_Navigation_Map_Base::vSetCrossHairVisible(tbool blVisibility)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blVisibility);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSetCrossHairVisible not implemented"));
   
}

/**
 * Method: vITCommanderRelease
  * Describes that the user has released the IT Commander direction button 
  * NISSAN ITG5
 */
void clHSA_Navigation_Map_Base::vITCommanderRelease( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vITCommanderRelease not implemented"));
   
}

/**
 * Method: vITCommanderPress
  * Describes which direction button is pressed on Encoder(IT Commander)
  * NISSAN ITG5
 */
void clHSA_Navigation_Map_Base::vITCommanderPress(ulword ulwDirectionValue, tbool blReleaseType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDirectionValue);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blReleaseType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vITCommanderPress not implemented"));
   
}

/**
 * Method: vITCommanderSelect
  * Represents destination seletion using IT commander. Should be the crosshair position
  * NISSAN ITG5
 */
void clHSA_Navigation_Map_Base::vITCommanderSelect(ulword ulwPosX, ulword ulwPosY)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPosX);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPosY);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vITCommanderSelect not implemented"));
   
}

/**
 * Method: vSwitchRoadActivate
  * Activates the switch road functionality in the NAV application
  * NISSAN ITG5
 */
void clHSA_Navigation_Map_Base::vSwitchRoadActivate( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSwitchRoadActivate not implemented"));
   
}

/**
 * Method: vSwitchRoadDeactivate
  * Deactivates the switch road functionality in the NAV application
  *  NISSAN ITG5
 */
void clHSA_Navigation_Map_Base::vSwitchRoadDeactivate( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSwitchRoadDeactivate not implemented"));
   
}

/**
 * Method: vSwitchRoadToggle
  * Switches the road if roads to switch on are available.
  *  NISSAN ITG5
 */
void clHSA_Navigation_Map_Base::vSwitchRoadToggle( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation_Map::vSwitchRoadToggle not implemented"));
   
}

/**
 * Method: ulwSwitchRoadGetStatus
  * Returns the status of the SwitchRoad application.
  *  NISSAN ITG5
 */
ulword clHSA_Navigation_Map_Base::ulwSwitchRoadGetStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwSwitchRoadGetStatus not implemented"));
   return 0;
}

/**
 * Method: ulwSwitchRoadGetCurrentRoadNumber
  * Returns the current road number.
  *  NISSAN ITG5
 */
ulword clHSA_Navigation_Map_Base::ulwSwitchRoadGetCurrentRoadNumber( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwSwitchRoadGetCurrentRoadNumber not implemented"));
   return 0;
}

/**
 * Method: ulwSwitchRoadGetNumberOfRoads
  * Returns the number of roads.
  *  NISSAN ITG5
 */
ulword clHSA_Navigation_Map_Base::ulwSwitchRoadGetNumberOfRoads( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation_Map::ulwSwitchRoadGetNumberOfRoads not implemented"));
   return 0;
}

