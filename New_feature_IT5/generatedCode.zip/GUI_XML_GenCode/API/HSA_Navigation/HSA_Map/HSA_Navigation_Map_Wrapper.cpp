/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Navigation_Map_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_Navigation_Map_Wrapper.h"
#include "clHSA_Navigation_Map_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_Navigation_Map_Trace.h"
#include "hmi_trace.h"

void HSA_Navigation_Map__vSetSplitScreenConf(ulword ulwConfType)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_SPLIT_SCREEN_CONF | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwConfType); 
        }
      pInst->vSetSplitScreenConf(ulwConfType);

    }
}

ulword HSA_Navigation_Map__ulwGetSplitScreenState( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_SPLIT_SCREEN_STATE  ) ); 
        }
      ret=pInst->ulwGetSplitScreenState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_SPLIT_SCREEN_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vSetSplitScreenLock(ulword ulwLockMode)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_SPLIT_SCREEN_LOCK | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLockMode); 
        }
      pInst->vSetSplitScreenLock(ulwLockMode);

    }
}

ulword HSA_Navigation_Map__ulwGetSplitScreenLockState( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_SPLIT_SCREEN_LOCK_STATE  ) ); 
        }
      ret=pInst->ulwGetSplitScreenLockState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_SPLIT_SCREEN_LOCK_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vSetDestFlagForNewMapCenter(ulword ulwFlagType)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_DEST_FLAG_FOR_NEW_MAP_CENTER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwFlagType); 
        }
      pInst->vSetDestFlagForNewMapCenter(ulwFlagType);

    }
}

tbool HSA_Navigation_Map__blIsCameraWarningAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_CAMERA_WARNING_AVAILABLE  ) ); 
        }
      ret=pInst->blIsCameraWarningAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_CAMERA_WARNING_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blIsCurveWarningAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_CURVE_WARNING_AVAILABLE  ) ); 
        }
      ret=pInst->blIsCurveWarningAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_CURVE_WARNING_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blIsOverSpeedWarningAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_OVER_SPEED_WARNING_AVAILABLE  ) ); 
        }
      ret=pInst->blIsOverSpeedWarningAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_OVER_SPEED_WARNING_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blIsWarningDistanceAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_WARNING_DISTANCE_AVAILABLE  ) ); 
        }
      ret=pInst->blIsWarningDistanceAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_WARNING_DISTANCE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blIsLaneDisplayAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_LANE_DISPLAY_AVAILABLE  ) ); 
        }
      ret=pInst->blIsLaneDisplayAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_LANE_DISPLAY_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blIsLaneGuidanceLeftVisible( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_LANE_GUIDANCE_LEFT_VISIBLE  ) ); 
        }
      ret=pInst->blIsLaneGuidanceLeftVisible();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_LANE_GUIDANCE_LEFT_VISIBLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blIsLaneGuidanceCenterVisible( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_LANE_GUIDANCE_CENTER_VISIBLE  ) ); 
        }
      ret=pInst->blIsLaneGuidanceCenterVisible();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_LANE_GUIDANCE_CENTER_VISIBLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vGetLaneGuidanceSymbols(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_LANE_GUIDANCE_SYMBOLS  ) ); 
        }
      pInst->vGetLaneGuidanceSymbols(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_LANE_GUIDANCE_SYMBOLS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vCameraWarningGetValue(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CAMERA_WARNING_GET_VALUE  ) ); 
        }
      pInst->vCameraWarningGetValue(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CAMERA_WARNING_GET_VALUE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation_Map__ulwCameraWarningGetUnit( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CAMERA_WARNING_GET_UNIT  ) ); 
        }
      ret=pInst->ulwCameraWarningGetUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CAMERA_WARNING_GET_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwCurvewarningGetValue( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CURVEWARNING_GET_VALUE  ) ); 
        }
      ret=pInst->ulwCurvewarningGetValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CURVEWARNING_GET_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwLaneDisplayGetValue( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__LANE_DISPLAY_GET_VALUE  ) ); 
        }
      ret=pInst->ulwLaneDisplayGetValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__LANE_DISPLAY_GET_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vToggleCurveWarning( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_CURVE_WARNING  ) ); 
        }
      pInst->vToggleCurveWarning();

    }
}

ulword HSA_Navigation_Map__ulwGetCurveWarningState( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_CURVE_WARNING_STATE  ) ); 
        }
      ret=pInst->ulwGetCurveWarningState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_CURVE_WARNING_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vToggleOverSpeedWarning( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_OVER_SPEED_WARNING  ) ); 
        }
      pInst->vToggleOverSpeedWarning();

    }
}

ulword HSA_Navigation_Map__ulwGetOverSpeedWarningState( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_OVER_SPEED_WARNING_STATE  ) ); 
        }
      ret=pInst->ulwGetOverSpeedWarningState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_OVER_SPEED_WARNING_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vGetOverSpeedThreshold(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_OVER_SPEED_THRESHOLD  ) ); 
        }
      pInst->vGetOverSpeedThreshold(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_OVER_SPEED_THRESHOLD | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vOverSpeedThresholdHandling(ulword ulwConfType)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__OVER_SPEED_THRESHOLD_HANDLING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwConfType); 
        }
      pInst->vOverSpeedThresholdHandling(ulwConfType);

    }
}

void HSA_Navigation_Map__vSetDragMapMode(ulword ulwOperationMode)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_DRAG_MAP_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwOperationMode); 
        }
      pInst->vSetDragMapMode(ulwOperationMode);

    }
}

tbool HSA_Navigation_Map__blGetActDestFlagType( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_ACT_DEST_FLAG_TYPE  ) ); 
        }
      ret=pInst->blGetActDestFlagType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_ACT_DEST_FLAG_TYPE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blIsDestFlagMoved( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_DEST_FLAG_MOVED  ) ); 
        }
      ret=pInst->blIsDestFlagMoved();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_DEST_FLAG_MOVED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blFlagDestEntryIsValid( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__FLAG_DEST_ENTRY_IS_VALID  ) ); 
        }
      ret=pInst->blFlagDestEntryIsValid();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__FLAG_DEST_ENTRY_IS_VALID | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blCarPositionIsValid( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CAR_POSITION_IS_VALID  ) ); 
        }
      ret=pInst->blCarPositionIsValid();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CAR_POSITION_IS_VALID | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vGetFlagDestName(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_FLAG_DEST_NAME  ) ); 
        }
      pInst->vGetFlagDestName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_FLAG_DEST_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Navigation_Map__blGetMapRepresentationMode(ulword ulwMode)
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_MAP_REPRESENTATION_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      ret=pInst->blGetMapRepresentationMode(ulwMode);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_MAP_REPRESENTATION_MODE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vSetMapRepresentationMode2DCarHeading(ulword ulwState)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_MAP_REPRESENTATION_MODE2D_CAR_HEADING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwState); 
        }
      pInst->vSetMapRepresentationMode2DCarHeading(ulwState);

    }
}

void HSA_Navigation_Map__vSetMapRepresentationMode2DNorth(ulword ulwState)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_MAP_REPRESENTATION_MODE2D_NORTH | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwState); 
        }
      pInst->vSetMapRepresentationMode2DNorth(ulwState);

    }
}

void HSA_Navigation_Map__vSetMapRepresentationMode3DCarHeading(ulword ulwState)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_MAP_REPRESENTATION_MODE3D_CAR_HEADING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwState); 
        }
      pInst->vSetMapRepresentationMode3DCarHeading(ulwState);

    }
}

void HSA_Navigation_Map__vToggleMapOrientation( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_MAP_ORIENTATION  ) ); 
        }
      pInst->vToggleMapOrientation();

    }
}

void HSA_Navigation_Map__vTogglePOILabelState(ulword ulwPOIListitem)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_POI_LABEL_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPOIListitem); 
        }
      pInst->vTogglePOILabelState(ulwPOIListitem);

    }
}

tbool HSA_Navigation_Map__blGetPOILabelState(ulword ulwPOIListitem)
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_POI_LABEL_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPOIListitem); 
        }
      ret=pInst->blGetPOILabelState(ulwPOIListitem);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_POI_LABEL_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vPOILabelApplyInput( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__POI_LABEL_APPLY_INPUT  ) ); 
        }
      pInst->vPOILabelApplyInput();

    }
}

ulword HSA_Navigation_Map__ulwGetMapOrientation( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_MAP_ORIENTATION  ) ); 
        }
      ret=pInst->ulwGetMapOrientation();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_MAP_ORIENTATION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vSetVoiceGuidance(tbool blNaviVoice)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_VOICE_GUIDANCE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blNaviVoice); 
        }
      pInst->vSetVoiceGuidance(blNaviVoice);

    }
}

tbool HSA_Navigation_Map__blGetVoiceGuidance( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_GUIDANCE  ) ); 
        }
      ret=pInst->blGetVoiceGuidance();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_GUIDANCE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vToggleUserMap( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_USER_MAP  ) ); 
        }
      pInst->vToggleUserMap();

    }
}

ulword HSA_Navigation_Map__ulwGetUserMap( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_USER_MAP  ) ); 
        }
      ret=pInst->ulwGetUserMap();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_USER_MAP | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vInitMap(ulword ulwMapType)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__INIT_MAP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMapType); 
        }
      pInst->vInitMap(ulwMapType);

    }
}

tbool HSA_Navigation_Map__blIsMapVisible(ulword ulwMapType)
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_MAP_VISIBLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMapType); 
        }
      ret=pInst->blIsMapVisible(ulwMapType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_MAP_VISIBLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vMapTouched( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAP_TOUCHED  ) ); 
        }
      pInst->vMapTouched();

    }
}

void HSA_Navigation_Map__vMapReleased(slword slwPosX, slword slwPosY)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAP_RELEASED | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwPosX); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAP_RELEASED | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwPosY); 
        }
      pInst->vMapReleased(slwPosX, slwPosY);

    }
}

void HSA_Navigation_Map__vMapDragged(slword slwDeltaX, slword slwDeltaY, ulword ulwPenState)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAP_DRAGGED | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwDeltaX); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAP_DRAGGED | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwDeltaY); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAP_DRAGGED | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPenState); 
        }
      pInst->vMapDragged(slwDeltaX, slwDeltaY, ulwPenState);

    }
}

void HSA_Navigation_Map__vMapDraggedAbsPos(slword slwLastAbsX, slword slwLastAbsY, slword slwMovedToAbsX, slword slwMovedToAbsY)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAP_DRAGGED_ABS_POS | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwLastAbsX); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAP_DRAGGED_ABS_POS | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwLastAbsY); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAP_DRAGGED_ABS_POS | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwMovedToAbsX); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAP_DRAGGED_ABS_POS | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwMovedToAbsY); 
        }
      pInst->vMapDraggedAbsPos(slwLastAbsX, slwLastAbsY, slwMovedToAbsX, slwMovedToAbsY);

    }
}

tbool HSA_Navigation_Map__blIsDestFlagSet( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_DEST_FLAG_SET  ) ); 
        }
      ret=pInst->blIsDestFlagSet();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_DEST_FLAG_SET | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vAutoZoomActivate(tbool blState)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__AUTO_ZOOM_ACTIVATE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blState); 
        }
      pInst->vAutoZoomActivate(blState);

    }
}

tbool HSA_Navigation_Map__blAutoZoomActive( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__AUTO_ZOOM_ACTIVE  ) ); 
        }
      ret=pInst->blAutoZoomActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__AUTO_ZOOM_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blControlBarStateGet( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CONTROL_BAR_STATE_GET  ) ); 
        }
      ret=pInst->blControlBarStateGet();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CONTROL_BAR_STATE_GET | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vControlBarStateToggle( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CONTROL_BAR_STATE_TOGGLE  ) ); 
        }
      pInst->vControlBarStateToggle();

    }
}

void HSA_Navigation_Map__vDraw( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__DRAW  ) ); 
        }
      pInst->vDraw();

    }
}

void HSA_Navigation_Map__vDrawStop( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__DRAW_STOP  ) ); 
        }
      pInst->vDrawStop();

    }
}

void HSA_Navigation_Map__vDrawCarsor( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__DRAW_CARSOR  ) ); 
        }
      pInst->vDrawCarsor();

    }
}

void HSA_Navigation_Map__vHideCarsor( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__HIDE_CARSOR  ) ); 
        }
      pInst->vHideCarsor();

    }
}

ulword HSA_Navigation_Map__ulwGetActiveGuidanceSymbol( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_GUIDANCE_SYMBOL  ) ); 
        }
      ret=pInst->ulwGetActiveGuidanceSymbol();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_GUIDANCE_SYMBOL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwGetBarGraphSymbol( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_BAR_GRAPH_SYMBOL  ) ); 
        }
      ret=pInst->ulwGetBarGraphSymbol();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_BAR_GRAPH_SYMBOL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwGetActiveTimeDisplay( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_TIME_DISPLAY  ) ); 
        }
      ret=pInst->ulwGetActiveTimeDisplay();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_TIME_DISPLAY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vGetActiveTimeDisplayValue(GUI_String *out_result, ulword ulwMode)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_TIME_DISPLAY_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vGetActiveTimeDisplayValue(out_result, ulwMode);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_TIME_DISPLAY_VALUE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation_Map__ulwGetCurrentNorthUpSymbol( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_NORTH_UP_SYMBOL  ) ); 
        }
      ret=pInst->ulwGetCurrentNorthUpSymbol();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_NORTH_UP_SYMBOL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vGetCurrentStreet(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_STREET  ) ); 
        }
      pInst->vGetCurrentStreet(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_STREET | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vGetDistanceToDestination(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_DISTANCE_TO_DESTINATION  ) ); 
        }
      pInst->vGetDistanceToDestination(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_DISTANCE_TO_DESTINATION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation_Map__ulwGetDistanceToDestinationUnit( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_DISTANCE_TO_DESTINATION_UNIT  ) ); 
        }
      ret=pInst->ulwGetDistanceToDestinationUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_DISTANCE_TO_DESTINATION_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vGetDistanceToManeuver(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_DISTANCE_TO_MANEUVER  ) ); 
        }
      pInst->vGetDistanceToManeuver(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_DISTANCE_TO_MANEUVER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation_Map__ulwGetDistanceToManeuverUnit( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_DISTANCE_TO_MANEUVER_UNIT  ) ); 
        }
      ret=pInst->ulwGetDistanceToManeuverUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_DISTANCE_TO_MANEUVER_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vGetTurnToStreet(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_TURN_TO_STREET  ) ); 
        }
      pInst->vGetTurnToStreet(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_TURN_TO_STREET | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vInit( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__INIT  ) ); 
        }
      pInst->vInit();

    }
}

ulword HSA_Navigation_Map__ulwIsInitialized( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_INITIALIZED  ) ); 
        }
      ret=pInst->ulwIsInitialized();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_INITIALIZED | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blIsDriveManeuverPresent( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_DRIVE_MANEUVER_PRESENT  ) ); 
        }
      ret=pInst->blIsDriveManeuverPresent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_DRIVE_MANEUVER_PRESENT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blShowTurnToStreet( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SHOW_TURN_TO_STREET  ) ); 
        }
      ret=pInst->blShowTurnToStreet();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SHOW_TURN_TO_STREET | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blShowDistanceToManeuver( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SHOW_DISTANCE_TO_MANEUVER  ) ); 
        }
      ret=pInst->blShowDistanceToManeuver();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SHOW_DISTANCE_TO_MANEUVER | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blShowActiveGuidanceSymbol( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SHOW_ACTIVE_GUIDANCE_SYMBOL  ) ); 
        }
      ret=pInst->blShowActiveGuidanceSymbol();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SHOW_ACTIVE_GUIDANCE_SYMBOL | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwMainZoomGetValue( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAIN_ZOOM_GET_VALUE  ) ); 
        }
      ret=pInst->ulwMainZoomGetValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAIN_ZOOM_GET_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vMainZoomInStep( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAIN_ZOOM_IN_STEP  ) ); 
        }
      pInst->vMainZoomInStep();

    }
}

void HSA_Navigation_Map__vMainZoomOutStep( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__MAIN_ZOOM_OUT_STEP  ) ); 
        }
      pInst->vMainZoomOutStep();

    }
}

void HSA_Navigation_Map__vSetActiveTimeDisplay(ulword ulwMode)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_ACTIVE_TIME_DISPLAY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vSetActiveTimeDisplay(ulwMode);

    }
}

tbool HSA_Navigation_Map__blIsBargraphActive( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_BARGRAPH_ACTIVE  ) ); 
        }
      ret=pInst->blIsBargraphActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_BARGRAPH_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwGetBargraphValue( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_BARGRAPH_VALUE  ) ); 
        }
      ret=pInst->ulwGetBargraphValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_BARGRAPH_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Navigation_Map__blIsSpeedLimitAvailable( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_SPEED_LIMIT_AVAILABLE  ) ); 
        }
      ret=pInst->blIsSpeedLimitAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_SPEED_LIMIT_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwIsRouteCompletelyCalculated( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_ROUTE_COMPLETELY_CALCULATED  ) ); 
        }
      ret=pInst->ulwIsRouteCompletelyCalculated();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IS_ROUTE_COMPLETELY_CALCULATED | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vSpeedLimitGetValue(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SPEED_LIMIT_GET_VALUE  ) ); 
        }
      pInst->vSpeedLimitGetValue(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SPEED_LIMIT_GET_VALUE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vSplitScreenClose( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SPLIT_SCREEN_CLOSE  ) ); 
        }
      pInst->vSplitScreenClose();

    }
}

ulword HSA_Navigation_Map__ulwSplitScreenGetMapPosition( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SPLIT_SCREEN_GET_MAP_POSITION  ) ); 
        }
      ret=pInst->ulwSplitScreenGetMapPosition();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SPLIT_SCREEN_GET_MAP_POSITION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwSplitScreenRightColumnElementStart( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SPLIT_SCREEN_RIGHT_COLUMN_ELEMENT_START  ) ); 
        }
      ret=pInst->ulwSplitScreenRightColumnElementStart();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SPLIT_SCREEN_RIGHT_COLUMN_ELEMENT_START | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vGetHWETurnToStreet(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_HWE_TURN_TO_STREET  ) ); 
        }
      pInst->vGetHWETurnToStreet(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_HWE_TURN_TO_STREET | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vGetHWESignPost(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_HWE_SIGN_POST  ) ); 
        }
      pInst->vGetHWESignPost(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_HWE_SIGN_POST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vGetHWENumber(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_HWE_NUMBER  ) ); 
        }
      pInst->vGetHWENumber(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_HWE_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation_Map__ulwGetHWESignpostBGImgIndex( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_HWE_SIGNPOST_BG_IMG_INDEX  ) ); 
        }
      ret=pInst->ulwGetHWESignpostBGImgIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_HWE_SIGNPOST_BG_IMG_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwGetHWESignpostTextColor( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_HWE_SIGNPOST_TEXT_COLOR  ) ); 
        }
      ret=pInst->ulwGetHWESignpostTextColor();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_HWE_SIGNPOST_TEXT_COLOR | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwGetHWEInfoPosition( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_HWE_INFO_POSITION  ) ); 
        }
      ret=pInst->ulwGetHWEInfoPosition();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_HWE_INFO_POSITION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vSetFramerateToLow( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_FRAMERATE_TO_LOW  ) ); 
        }
      pInst->vSetFramerateToLow();

    }
}

void HSA_Navigation_Map__vSetFramerateToNormal( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_FRAMERATE_TO_NORMAL  ) ); 
        }
      pInst->vSetFramerateToNormal();

    }
}

tbool HSA_Navigation_Map__blSetupGetPresetInfoAvailability( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_PRESET_INFO_AVAILABILITY  ) ); 
        }
      ret=pInst->blSetupGetPresetInfoAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_PRESET_INFO_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vTogglePresetInfoState( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_PRESET_INFO_STATE  ) ); 
        }
      pInst->vTogglePresetInfoState();

    }
}

ulword HSA_Navigation_Map__ulwGetActWeatherMapType( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_ACT_WEATHER_MAP_TYPE  ) ); 
        }
      ret=pInst->ulwGetActWeatherMapType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_ACT_WEATHER_MAP_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vPrepareWeatherMap(ulword ulwWeatherMapType)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__PREPARE_WEATHER_MAP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwWeatherMapType); 
        }
      pInst->vPrepareWeatherMap(ulwWeatherMapType);

    }
}

tbool HSA_Navigation_Map__blHasWeatherMapLoadingStarted( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__HAS_WEATHER_MAP_LOADING_STARTED  ) ); 
        }
      ret=pInst->blHasWeatherMapLoadingStarted();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__HAS_WEATHER_MAP_LOADING_STARTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vGetStormCellMovementSpeed(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_CELL_MOVEMENT_SPEED  ) ); 
        }
      pInst->vGetStormCellMovementSpeed(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_CELL_MOVEMENT_SPEED | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vGetStormCellEchoTopHeight(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_CELL_ECHO_TOP_HEIGHT  ) ); 
        }
      pInst->vGetStormCellEchoTopHeight(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_CELL_ECHO_TOP_HEIGHT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vGetStormCellIssueTime(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_CELL_ISSUE_TIME  ) ); 
        }
      pInst->vGetStormCellIssueTime(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_CELL_ISSUE_TIME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vClearStormCellPickedData( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CLEAR_STORM_CELL_PICKED_DATA  ) ); 
        }
      pInst->vClearStormCellPickedData();

    }
}

ulword HSA_Navigation_Map__ulwGetNumberOfStormTracks( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_NUMBER_OF_STORM_TRACKS  ) ); 
        }
      ret=pInst->ulwGetNumberOfStormTracks();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_NUMBER_OF_STORM_TRACKS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vGetStormTrackerName(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_NAME  ) ); 
        }
      pInst->vGetStormTrackerName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation_Map__ulwGetStormTrackerInfoWeatherStromType( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_WEATHER_STROM_TYPE  ) ); 
        }
      ret=pInst->ulwGetStormTrackerInfoWeatherStromType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_WEATHER_STROM_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vGetStormTrackerInfoSpeed(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_SPEED  ) ); 
        }
      pInst->vGetStormTrackerInfoSpeed(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_SPEED | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vGetStormTrackerInfoMaxSustainedWinds(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_MAX_SUSTAINED_WINDS  ) ); 
        }
      pInst->vGetStormTrackerInfoMaxSustainedWinds(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_MAX_SUSTAINED_WINDS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vGetStormTrackerInfoGusts(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_GUSTS  ) ); 
        }
      pInst->vGetStormTrackerInfoGusts(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_GUSTS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vGetStormTrackerInfoPressure(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_PRESSURE  ) ); 
        }
      pInst->vGetStormTrackerInfoPressure(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_PRESSURE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Navigation_Map__vGetStormTrackerInfoIssueTime(GUI_String *out_result)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_ISSUE_TIME  ) ); 
        }
      pInst->vGetStormTrackerInfoIssueTime(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_ISSUE_TIME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation_Map__ulwGetStormTrackerInfoDateMM( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_DATE_MM  ) ); 
        }
      ret=pInst->ulwGetStormTrackerInfoDateMM();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_DATE_MM | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwGetStormTrackerInfoDateDD( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_DATE_DD  ) ); 
        }
      ret=pInst->ulwGetStormTrackerInfoDateDD();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_DATE_DD | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwGetStormTrackerInfoDateYYYY( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_DATE_YYYY  ) ); 
        }
      ret=pInst->ulwGetStormTrackerInfoDateYYYY();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_DATE_YYYY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vClearStormTrackerInfoPickedData( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__CLEAR_STORM_TRACKER_INFO_PICKED_DATA  ) ); 
        }
      pInst->vClearStormTrackerInfoPickedData();

    }
}

void HSA_Navigation_Map__vPOIMapPrepareGuidance(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__POI_MAP_PREPARE_GUIDANCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vPOIMapPrepareGuidance(ulwListEntryNr);

    }
}

ulword HSA_Navigation_Map__ulwGetPOIListCount( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_POI_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetPOIListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_POI_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vGetPOIListString(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_POI_LIST_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCell); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_POI_LIST_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetPOIListString(out_result, ulwCell, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_POI_LIST_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Navigation_Map__ulwGetPOIListValue(ulword ulwCell, ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_POI_LIST_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCell); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_POI_LIST_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetPOIListValue(ulwCell, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_POI_LIST_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vPOIActivateDetails(ulword ulwListEntryNr)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__POI_ACTIVATE_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vPOIActivateDetails(ulwListEntryNr);

    }
}

ulword HSA_Navigation_Map__ulwPOIMapGetListUnit( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__POI_MAP_GET_LIST_UNIT  ) ); 
        }
      ret=pInst->ulwPOIMapGetListUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__POI_MAP_GET_LIST_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vSetWeatherMapLegendDisplayState( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_WEATHER_MAP_LEGEND_DISPLAY_STATE  ) ); 
        }
      pInst->vSetWeatherMapLegendDisplayState();

    }
}

tbool HSA_Navigation_Map__blGetWeatherMapLegendDisplayState( )
{
    tbool ret = false;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_WEATHER_MAP_LEGEND_DISPLAY_STATE  ) ); 
        }
      ret=pInst->blGetWeatherMapLegendDisplayState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__GET_WEATHER_MAP_LEGEND_DISPLAY_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Navigation_Map__vSetCrossHairVisible(tbool blVisibility)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SET_CROSS_HAIR_VISIBLE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blVisibility); 
        }
      pInst->vSetCrossHairVisible(blVisibility);

    }
}

void HSA_Navigation_Map__vITCommanderRelease( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IT_COMMANDER_RELEASE  ) ); 
        }
      pInst->vITCommanderRelease();

    }
}

void HSA_Navigation_Map__vITCommanderPress(ulword ulwDirectionValue, tbool blReleaseType)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IT_COMMANDER_PRESS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDirectionValue); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IT_COMMANDER_PRESS | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blReleaseType); 
        }
      pInst->vITCommanderPress(ulwDirectionValue, blReleaseType);

    }
}

void HSA_Navigation_Map__vITCommanderSelect(ulword ulwPosX, ulword ulwPosY)
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IT_COMMANDER_SELECT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPosX); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__IT_COMMANDER_SELECT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPosY); 
        }
      pInst->vITCommanderSelect(ulwPosX, ulwPosY);

    }
}

void HSA_Navigation_Map__vSwitchRoadActivate( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SWITCH_ROAD_ACTIVATE  ) ); 
        }
      pInst->vSwitchRoadActivate();

    }
}

void HSA_Navigation_Map__vSwitchRoadDeactivate( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SWITCH_ROAD_DEACTIVATE  ) ); 
        }
      pInst->vSwitchRoadDeactivate();

    }
}

void HSA_Navigation_Map__vSwitchRoadToggle( )
{
    
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SWITCH_ROAD_TOGGLE  ) ); 
        }
      pInst->vSwitchRoadToggle();

    }
}

ulword HSA_Navigation_Map__ulwSwitchRoadGetStatus( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SWITCH_ROAD_GET_STATUS  ) ); 
        }
      ret=pInst->ulwSwitchRoadGetStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SWITCH_ROAD_GET_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwSwitchRoadGetCurrentRoadNumber( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SWITCH_ROAD_GET_CURRENT_ROAD_NUMBER  ) ); 
        }
      ret=pInst->ulwSwitchRoadGetCurrentRoadNumber();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SWITCH_ROAD_GET_CURRENT_ROAD_NUMBER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Navigation_Map__ulwSwitchRoadGetNumberOfRoads( )
{
    ulword ret = 0;
    clHSA_Navigation_Map_Base *pInst=clHSA_Navigation_Map_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SWITCH_ROAD_GET_NUMBER_OF_ROADS  ) ); 
        }
      ret=pInst->ulwSwitchRoadGetNumberOfRoads();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_NAVIGATION_MAP), (tU16)(HSA_API_ENTRYPOINT__SWITCH_ROAD_GET_NUMBER_OF_ROADS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

#ifdef __cplusplus
}
#endif

