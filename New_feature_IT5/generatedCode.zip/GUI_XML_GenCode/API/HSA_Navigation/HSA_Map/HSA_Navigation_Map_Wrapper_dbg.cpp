/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Navigation_Map_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_Navigation_Map_Wrapper_dbg.h"
#include "clHSA_Navigation_Map_Base.h"
#include "HSA_Navigation_Map_Trace.h"
#include "HSA_Navigation_Map_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_Navigation_Map_Wrapper_dbg::~clHSA_Navigation_Map_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_Navigation_Map_Wrapper_dbg::clHSA_Navigation_Map_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_Navigation_Map_Wrapper_dbg::clHSA_Navigation_Map_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_Navigation_Map_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_Navigation_Map_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__SET_SPLIT_SCREEN_CONF:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vSetSplitScreenConf(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SPLIT_SCREEN_STATE:

            HSA_Navigation_Map__ulwGetSplitScreenState();
            break;

        case HSA_API_ENTRYPOINT__SET_SPLIT_SCREEN_LOCK:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vSetSplitScreenLock(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SPLIT_SCREEN_LOCK_STATE:

            HSA_Navigation_Map__ulwGetSplitScreenLockState();
            break;

        case HSA_API_ENTRYPOINT__SET_DEST_FLAG_FOR_NEW_MAP_CENTER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vSetDestFlagForNewMapCenter(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_CAMERA_WARNING_AVAILABLE:

            HSA_Navigation_Map__blIsCameraWarningAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_CURVE_WARNING_AVAILABLE:

            HSA_Navigation_Map__blIsCurveWarningAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_OVER_SPEED_WARNING_AVAILABLE:

            HSA_Navigation_Map__blIsOverSpeedWarningAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_WARNING_DISTANCE_AVAILABLE:

            HSA_Navigation_Map__blIsWarningDistanceAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_LANE_DISPLAY_AVAILABLE:

            HSA_Navigation_Map__blIsLaneDisplayAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_LANE_GUIDANCE_LEFT_VISIBLE:

            HSA_Navigation_Map__blIsLaneGuidanceLeftVisible();
            break;

        case HSA_API_ENTRYPOINT__IS_LANE_GUIDANCE_CENTER_VISIBLE:

            HSA_Navigation_Map__blIsLaneGuidanceCenterVisible();
            break;

        case HSA_API_ENTRYPOINT__GET_LANE_GUIDANCE_SYMBOLS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetLaneGuidanceSymbols(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__CAMERA_WARNING_GET_VALUE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vCameraWarningGetValue(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__CAMERA_WARNING_GET_UNIT:

            HSA_Navigation_Map__ulwCameraWarningGetUnit();
            break;

        case HSA_API_ENTRYPOINT__CURVEWARNING_GET_VALUE:

            HSA_Navigation_Map__ulwCurvewarningGetValue();
            break;

        case HSA_API_ENTRYPOINT__LANE_DISPLAY_GET_VALUE:

            HSA_Navigation_Map__ulwLaneDisplayGetValue();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_CURVE_WARNING:

            HSA_Navigation_Map__vToggleCurveWarning();
            break;

        case HSA_API_ENTRYPOINT__GET_CURVE_WARNING_STATE:

            HSA_Navigation_Map__ulwGetCurveWarningState();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_OVER_SPEED_WARNING:

            HSA_Navigation_Map__vToggleOverSpeedWarning();
            break;

        case HSA_API_ENTRYPOINT__GET_OVER_SPEED_WARNING_STATE:

            HSA_Navigation_Map__ulwGetOverSpeedWarningState();
            break;

        case HSA_API_ENTRYPOINT__GET_OVER_SPEED_THRESHOLD:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetOverSpeedThreshold(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__OVER_SPEED_THRESHOLD_HANDLING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vOverSpeedThresholdHandling(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DRAG_MAP_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vSetDragMapMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACT_DEST_FLAG_TYPE:

            HSA_Navigation_Map__blGetActDestFlagType();
            break;

        case HSA_API_ENTRYPOINT__IS_DEST_FLAG_MOVED:

            HSA_Navigation_Map__blIsDestFlagMoved();
            break;

        case HSA_API_ENTRYPOINT__FLAG_DEST_ENTRY_IS_VALID:

            HSA_Navigation_Map__blFlagDestEntryIsValid();
            break;

        case HSA_API_ENTRYPOINT__CAR_POSITION_IS_VALID:

            HSA_Navigation_Map__blCarPositionIsValid();
            break;

        case HSA_API_ENTRYPOINT__GET_FLAG_DEST_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetFlagDestName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_MAP_REPRESENTATION_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__blGetMapRepresentationMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_MAP_REPRESENTATION_MODE2D_CAR_HEADING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vSetMapRepresentationMode2DCarHeading(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_MAP_REPRESENTATION_MODE2D_NORTH:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vSetMapRepresentationMode2DNorth(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_MAP_REPRESENTATION_MODE3D_CAR_HEADING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vSetMapRepresentationMode3DCarHeading(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_MAP_ORIENTATION:

            HSA_Navigation_Map__vToggleMapOrientation();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_POI_LABEL_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vTogglePOILabelState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_POI_LABEL_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__blGetPOILabelState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__POI_LABEL_APPLY_INPUT:

            HSA_Navigation_Map__vPOILabelApplyInput();
            break;

        case HSA_API_ENTRYPOINT__GET_MAP_ORIENTATION:

            HSA_Navigation_Map__ulwGetMapOrientation();
            break;

        case HSA_API_ENTRYPOINT__SET_VOICE_GUIDANCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Navigation_Map__vSetVoiceGuidance(usParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_VOICE_GUIDANCE:

            HSA_Navigation_Map__blGetVoiceGuidance();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_USER_MAP:

            HSA_Navigation_Map__vToggleUserMap();
            break;

        case HSA_API_ENTRYPOINT__GET_USER_MAP:

            HSA_Navigation_Map__ulwGetUserMap();
            break;

        case HSA_API_ENTRYPOINT__INIT_MAP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vInitMap(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_MAP_VISIBLE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__blIsMapVisible(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__MAP_TOUCHED:

            HSA_Navigation_Map__vMapTouched();
            break;

        case HSA_API_ENTRYPOINT__MAP_RELEASED:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam2); 

            HSA_Navigation_Map__vMapReleased(slParam1, slParam2);
            break;

        case HSA_API_ENTRYPOINT__MAP_DRAGGED:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Navigation_Map__vMapDragged(slParam1, slParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__MAP_DRAGGED_ABS_POS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam3); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam4); 

            HSA_Navigation_Map__vMapDraggedAbsPos(slParam1, slParam2, slParam3, slParam4);
            break;

        case HSA_API_ENTRYPOINT__IS_DEST_FLAG_SET:

            HSA_Navigation_Map__blIsDestFlagSet();
            break;

        case HSA_API_ENTRYPOINT__AUTO_ZOOM_ACTIVATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Navigation_Map__vAutoZoomActivate(usParam1);
            break;

        case HSA_API_ENTRYPOINT__AUTO_ZOOM_ACTIVE:

            HSA_Navigation_Map__blAutoZoomActive();
            break;

        case HSA_API_ENTRYPOINT__CONTROL_BAR_STATE_GET:

            HSA_Navigation_Map__blControlBarStateGet();
            break;

        case HSA_API_ENTRYPOINT__CONTROL_BAR_STATE_TOGGLE:

            HSA_Navigation_Map__vControlBarStateToggle();
            break;

        case HSA_API_ENTRYPOINT__DRAW:

            HSA_Navigation_Map__vDraw();
            break;

        case HSA_API_ENTRYPOINT__DRAW_STOP:

            HSA_Navigation_Map__vDrawStop();
            break;

        case HSA_API_ENTRYPOINT__DRAW_CARSOR:

            HSA_Navigation_Map__vDrawCarsor();
            break;

        case HSA_API_ENTRYPOINT__HIDE_CARSOR:

            HSA_Navigation_Map__vHideCarsor();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_GUIDANCE_SYMBOL:

            HSA_Navigation_Map__ulwGetActiveGuidanceSymbol();
            break;

        case HSA_API_ENTRYPOINT__GET_BAR_GRAPH_SYMBOL:

            HSA_Navigation_Map__ulwGetBarGraphSymbol();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_TIME_DISPLAY:

            HSA_Navigation_Map__ulwGetActiveTimeDisplay();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_TIME_DISPLAY_VALUE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation_Map__vGetActiveTimeDisplayValue(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_NORTH_UP_SYMBOL:

            HSA_Navigation_Map__ulwGetCurrentNorthUpSymbol();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_STREET:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetCurrentStreet(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DISTANCE_TO_DESTINATION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetDistanceToDestination(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DISTANCE_TO_DESTINATION_UNIT:

            HSA_Navigation_Map__ulwGetDistanceToDestinationUnit();
            break;

        case HSA_API_ENTRYPOINT__GET_DISTANCE_TO_MANEUVER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetDistanceToManeuver(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DISTANCE_TO_MANEUVER_UNIT:

            HSA_Navigation_Map__ulwGetDistanceToManeuverUnit();
            break;

        case HSA_API_ENTRYPOINT__GET_TURN_TO_STREET:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetTurnToStreet(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__INIT:

            HSA_Navigation_Map__vInit();
            break;

        case HSA_API_ENTRYPOINT__IS_INITIALIZED:

            HSA_Navigation_Map__ulwIsInitialized();
            break;

        case HSA_API_ENTRYPOINT__IS_DRIVE_MANEUVER_PRESENT:

            HSA_Navigation_Map__blIsDriveManeuverPresent();
            break;

        case HSA_API_ENTRYPOINT__SHOW_TURN_TO_STREET:

            HSA_Navigation_Map__blShowTurnToStreet();
            break;

        case HSA_API_ENTRYPOINT__SHOW_DISTANCE_TO_MANEUVER:

            HSA_Navigation_Map__blShowDistanceToManeuver();
            break;

        case HSA_API_ENTRYPOINT__SHOW_ACTIVE_GUIDANCE_SYMBOL:

            HSA_Navigation_Map__blShowActiveGuidanceSymbol();
            break;

        case HSA_API_ENTRYPOINT__MAIN_ZOOM_GET_VALUE:

            HSA_Navigation_Map__ulwMainZoomGetValue();
            break;

        case HSA_API_ENTRYPOINT__MAIN_ZOOM_IN_STEP:

            HSA_Navigation_Map__vMainZoomInStep();
            break;

        case HSA_API_ENTRYPOINT__MAIN_ZOOM_OUT_STEP:

            HSA_Navigation_Map__vMainZoomOutStep();
            break;

        case HSA_API_ENTRYPOINT__SET_ACTIVE_TIME_DISPLAY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vSetActiveTimeDisplay(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_BARGRAPH_ACTIVE:

            HSA_Navigation_Map__blIsBargraphActive();
            break;

        case HSA_API_ENTRYPOINT__GET_BARGRAPH_VALUE:

            HSA_Navigation_Map__ulwGetBargraphValue();
            break;

        case HSA_API_ENTRYPOINT__IS_SPEED_LIMIT_AVAILABLE:

            HSA_Navigation_Map__blIsSpeedLimitAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_ROUTE_COMPLETELY_CALCULATED:

            HSA_Navigation_Map__ulwIsRouteCompletelyCalculated();
            break;

        case HSA_API_ENTRYPOINT__SPEED_LIMIT_GET_VALUE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vSpeedLimitGetValue(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPLIT_SCREEN_CLOSE:

            HSA_Navigation_Map__vSplitScreenClose();
            break;

        case HSA_API_ENTRYPOINT__SPLIT_SCREEN_GET_MAP_POSITION:

            HSA_Navigation_Map__ulwSplitScreenGetMapPosition();
            break;

        case HSA_API_ENTRYPOINT__SPLIT_SCREEN_RIGHT_COLUMN_ELEMENT_START:

            HSA_Navigation_Map__ulwSplitScreenRightColumnElementStart();
            break;

        case HSA_API_ENTRYPOINT__GET_HWE_TURN_TO_STREET:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetHWETurnToStreet(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_HWE_SIGN_POST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetHWESignPost(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_HWE_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetHWENumber(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_HWE_SIGNPOST_BG_IMG_INDEX:

            HSA_Navigation_Map__ulwGetHWESignpostBGImgIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_HWE_SIGNPOST_TEXT_COLOR:

            HSA_Navigation_Map__ulwGetHWESignpostTextColor();
            break;

        case HSA_API_ENTRYPOINT__GET_HWE_INFO_POSITION:

            HSA_Navigation_Map__ulwGetHWEInfoPosition();
            break;

        case HSA_API_ENTRYPOINT__SET_FRAMERATE_TO_LOW:

            HSA_Navigation_Map__vSetFramerateToLow();
            break;

        case HSA_API_ENTRYPOINT__SET_FRAMERATE_TO_NORMAL:

            HSA_Navigation_Map__vSetFramerateToNormal();
            break;

        case HSA_API_ENTRYPOINT__SETUP_GET_PRESET_INFO_AVAILABILITY:

            HSA_Navigation_Map__blSetupGetPresetInfoAvailability();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_PRESET_INFO_STATE:

            HSA_Navigation_Map__vTogglePresetInfoState();
            break;

        case HSA_API_ENTRYPOINT__GET_ACT_WEATHER_MAP_TYPE:

            HSA_Navigation_Map__ulwGetActWeatherMapType();
            break;

        case HSA_API_ENTRYPOINT__PREPARE_WEATHER_MAP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vPrepareWeatherMap(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__HAS_WEATHER_MAP_LOADING_STARTED:

            HSA_Navigation_Map__blHasWeatherMapLoadingStarted();
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_CELL_MOVEMENT_SPEED:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetStormCellMovementSpeed(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_CELL_ECHO_TOP_HEIGHT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetStormCellEchoTopHeight(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_CELL_ISSUE_TIME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetStormCellIssueTime(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__CLEAR_STORM_CELL_PICKED_DATA:

            HSA_Navigation_Map__vClearStormCellPickedData();
            break;

        case HSA_API_ENTRYPOINT__GET_NUMBER_OF_STORM_TRACKS:

            HSA_Navigation_Map__ulwGetNumberOfStormTracks();
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_TRACKER_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetStormTrackerName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_WEATHER_STROM_TYPE:

            HSA_Navigation_Map__ulwGetStormTrackerInfoWeatherStromType();
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_SPEED:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetStormTrackerInfoSpeed(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_MAX_SUSTAINED_WINDS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetStormTrackerInfoMaxSustainedWinds(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_GUSTS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetStormTrackerInfoGusts(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_PRESSURE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetStormTrackerInfoPressure(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_ISSUE_TIME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation_Map__vGetStormTrackerInfoIssueTime(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_DATE_MM:

            HSA_Navigation_Map__ulwGetStormTrackerInfoDateMM();
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_DATE_DD:

            HSA_Navigation_Map__ulwGetStormTrackerInfoDateDD();
            break;

        case HSA_API_ENTRYPOINT__GET_STORM_TRACKER_INFO_DATE_YYYY:

            HSA_Navigation_Map__ulwGetStormTrackerInfoDateYYYY();
            break;

        case HSA_API_ENTRYPOINT__CLEAR_STORM_TRACKER_INFO_PICKED_DATA:

            HSA_Navigation_Map__vClearStormTrackerInfoPickedData();
            break;

        case HSA_API_ENTRYPOINT__POI_MAP_PREPARE_GUIDANCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vPOIMapPrepareGuidance(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_POI_LIST_COUNT:

            HSA_Navigation_Map__ulwGetPOIListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_POI_LIST_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Navigation_Map__vGetPOIListString(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_POI_LIST_VALUE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation_Map__ulwGetPOIListValue(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__POI_ACTIVATE_DETAILS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation_Map__vPOIActivateDetails(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__POI_MAP_GET_LIST_UNIT:

            HSA_Navigation_Map__ulwPOIMapGetListUnit();
            break;

        case HSA_API_ENTRYPOINT__SET_WEATHER_MAP_LEGEND_DISPLAY_STATE:

            HSA_Navigation_Map__vSetWeatherMapLegendDisplayState();
            break;

        case HSA_API_ENTRYPOINT__GET_WEATHER_MAP_LEGEND_DISPLAY_STATE:

            HSA_Navigation_Map__blGetWeatherMapLegendDisplayState();
            break;

        case HSA_API_ENTRYPOINT__SET_CROSS_HAIR_VISIBLE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Navigation_Map__vSetCrossHairVisible(usParam1);
            break;

        case HSA_API_ENTRYPOINT__IT_COMMANDER_RELEASE:

            HSA_Navigation_Map__vITCommanderRelease();
            break;

        case HSA_API_ENTRYPOINT__IT_COMMANDER_PRESS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam2); 

            HSA_Navigation_Map__vITCommanderPress(ulParam1, usParam2);
            break;

        case HSA_API_ENTRYPOINT__IT_COMMANDER_SELECT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation_Map__vITCommanderSelect(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SWITCH_ROAD_ACTIVATE:

            HSA_Navigation_Map__vSwitchRoadActivate();
            break;

        case HSA_API_ENTRYPOINT__SWITCH_ROAD_DEACTIVATE:

            HSA_Navigation_Map__vSwitchRoadDeactivate();
            break;

        case HSA_API_ENTRYPOINT__SWITCH_ROAD_TOGGLE:

            HSA_Navigation_Map__vSwitchRoadToggle();
            break;

        case HSA_API_ENTRYPOINT__SWITCH_ROAD_GET_STATUS:

            HSA_Navigation_Map__ulwSwitchRoadGetStatus();
            break;

        case HSA_API_ENTRYPOINT__SWITCH_ROAD_GET_CURRENT_ROAD_NUMBER:

            HSA_Navigation_Map__ulwSwitchRoadGetCurrentRoadNumber();
            break;

        case HSA_API_ENTRYPOINT__SWITCH_ROAD_GET_NUMBER_OF_ROADS:

            HSA_Navigation_Map__ulwSwitchRoadGetNumberOfRoads();
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

