/*Exported Language Array from the model - Navigation*/
/*  This file has been generated on 05.12.2014 16:38 */
/*
 *  This file contains the definition of exported language content.
 *  The String lists with the translation that are to be exported
 *  from the model are listed here in the array structure
 *  
 *  Please note that:
 *    - Translations are provided in the following language order
 *    - English US
 *    - French CAN
 *    - Spanish Standard Latin
 *    - Dutch
 *    - German
 *    - Italian
 *    - Portuguese
 *    - Russian
 *    - Turkish
 *    - English UK
 *    - French
 *    - Spanish
 *    - Danish
 *    - Swedish
 *    - Finnish
 *    - Norwegian
 *    - Polish
 *    - Slovak
 *    - Czech
 *    - Hungarian
 *    - Greek
 *    - Brazilian
 *    - Arabic
 *    - Thai
 *    - Australian
 *
 *    This list is the same as used in the Model
 *
 *  The following macros are used:
 *
 *    CONTENT_LANGUAGE_COUNT(LanguageCount)
 *       Provides the count value to indicate the number of translations
 *    CONTENT_LANGUAGE_ARRAY(DeviceName) 
 *       Provides the start of the Array with Device name to which the 
 *       array belongs
 *    CONTENT_INDEX_START(Index Value)
 *       mark the start of Each string followed by the array of
 *       translations
 *    CONTENT_LANGUAGE(ContentID)
 *       provides the content ID for the translated string
 *    CONTENT_INDEX_END
 *       marks the end of Each string translation set
 *    CONTENT_END(value)
 *       End of the complete array
 *
 */


CONTENT_BEGIN()
#ifndef CONTENT_EXP_LANGUAGE_COUNT
   #define CONTENT_EXP_LANGUAGE_COUNT       25
#endif // #ifndef CONTENT_EXP_LANGUAGE_COUNT
CONTENT_LANGUAGE_ARRAY(Navigation)

#ifdef CONTENT_LANGUAGE
    //STRING_START(0)
    CONTENT_LANGUAGE(0x40004c4d)                                      // 0x8000001e: Unnamed road
    CONTENT_LANGUAGE(0x40004c4e)                                      // 0x8000001e: Route inconnue
    CONTENT_LANGUAGE(0x40004c4f)                                      // 0x8000001e: Carretera desconocida
    CONTENT_LANGUAGE(0x40004c50)                                      // 0x8000001e: Onbekende weg
    CONTENT_LANGUAGE(0x40004c51)                                      // 0x8000001e: Unbekann. Str.
    CONTENT_LANGUAGE(0x40004c52)                                      // 0x8000001e: Strada sconosciuta
    CONTENT_LANGUAGE(0x40004c53)                                      // 0x8000001e: Estrada desconhecida
    CONTENT_LANGUAGE(0x40004c54)                                      // 0x8000001e: ??????????? ?????? 
    CONTENT_LANGUAGE(0x40004c55)                                      // 0x8000001e: Bilinmeyen yol
    CONTENT_LANGUAGE(0x40004c4d)                                      // 0x8000001e: Unnamed road
    CONTENT_LANGUAGE(0x40004c4e)                                      // 0x8000001e: Route inconnue
    CONTENT_LANGUAGE(0x40004c56)                                      // 0x8000001e: Carr. descon.
    CONTENT_LANGUAGE(0x40004c57)                                      // 0x8000001e: Ukendt vej
    CONTENT_LANGUAGE(0x40004c58)                                      // 0x8000001e: Ok�nd v�g
    CONTENT_LANGUAGE(0x40004c59)                                      // 0x8000001e: Tuntematon tie
    CONTENT_LANGUAGE(0x40004c5a)                                      // 0x8000001e: Ukjent vei
    CONTENT_LANGUAGE(0x40004c5b)                                      // 0x8000001e: Nieznana droga
    CONTENT_LANGUAGE(0x40004c5c)                                      // 0x8000001e: Nezn�ma cesta
    CONTENT_LANGUAGE(0x40004c5d)                                      // 0x8000001e: Nezn�m� silnice
    CONTENT_LANGUAGE(0x40004c5e)                                      // 0x8000001e: Ismeretlen �t
    CONTENT_LANGUAGE(0x40004c5f)                                      // 0x8000001e: ???????? ??????
    CONTENT_LANGUAGE(0x40004c60)                                      // 0x8000001e: Rodovia desconhecida
    CONTENT_LANGUAGE(0x40004c61)                                      // 0x8000001e: ???? ??? ?????
    CONTENT_LANGUAGE(0x40004c62)                                      // 0x8000001e: ???????????????
    CONTENT_LANGUAGE(0x40004c63)                                      // 0x8000001e: ?????.??????
    //STRING_END()
    //STRING_START(1)
    CONTENT_LANGUAGE(0x40004c3f)                                      // 0x8000001f: Sun
    CONTENT_LANGUAGE(0x40004c64)                                      // 0x8000001f: Dim
    CONTENT_LANGUAGE(0x40004c65)                                      // 0x8000001f: Dom
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000001f: #No translation required
    //STRING_END()
    //STRING_START(2)
    CONTENT_LANGUAGE(0x40004c40)                                      // 0x80000020: Mon
    CONTENT_LANGUAGE(0x40004c67)                                      // 0x80000020: Lun
    CONTENT_LANGUAGE(0x40004c67)                                      // 0x80000020: Lun
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000020: #No translation required
    //STRING_END()
    //STRING_START(3)
    CONTENT_LANGUAGE(0x40004c41)                                      // 0x80000021: Tue
    CONTENT_LANGUAGE(0x40004c68)                                      // 0x80000021: Mar
    CONTENT_LANGUAGE(0x40004c68)                                      // 0x80000021: Mar
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000021: #No translation required
    //STRING_END()
    //STRING_START(4)
    CONTENT_LANGUAGE(0x40004c42)                                      // 0x80000022: Wed
    CONTENT_LANGUAGE(0x40004c69)                                      // 0x80000022: Mer
    CONTENT_LANGUAGE(0x40004c6a)                                      // 0x80000022: Mi�
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000022: #No translation required
    //STRING_END()
    //STRING_START(5)
    CONTENT_LANGUAGE(0x40004c43)                                      // 0x80000023: Thu
    CONTENT_LANGUAGE(0x40004c6b)                                      // 0x80000023: Jeu
    CONTENT_LANGUAGE(0x40004c6c)                                      // 0x80000023: Jue
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000023: #No translation required
    //STRING_END()
    //STRING_START(6)
    CONTENT_LANGUAGE(0x40004c44)                                      // 0x80000024: Fri
    CONTENT_LANGUAGE(0x40004c6d)                                      // 0x80000024: Ven
    CONTENT_LANGUAGE(0x40004c6e)                                      // 0x80000024: Vie
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000024: #No translation required
    //STRING_END()
    //STRING_START(7)
    CONTENT_LANGUAGE(0x40004c45)                                      // 0x80000025: Sat
    CONTENT_LANGUAGE(0x40004c6f)                                      // 0x80000025: Sam
    CONTENT_LANGUAGE(0x40004c70)                                      // 0x80000025: S�b
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000025: #No translation required
    //STRING_END()
    //STRING_START(8)
    CONTENT_LANGUAGE(0x4000017b)                                      // 0x80000026: AM
    CONTENT_LANGUAGE(0x4000017b)                                      // 0x80000026: AM
    CONTENT_LANGUAGE(0x4000017b)                                      // 0x80000026: AM
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    //STRING_END()
    //STRING_START(9)
    CONTENT_LANGUAGE(0x4000089f)                                      // 0x80000027: PM
    CONTENT_LANGUAGE(0x4000089f)                                      // 0x80000027: PM
    CONTENT_LANGUAGE(0x4000089f)                                      // 0x80000027: PM
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    //STRING_END()
    //STRING_START(10)
    CONTENT_LANGUAGE(0x400027e4)                                      // 0x80000028: Not Available
    CONTENT_LANGUAGE(0x40004c71)                                      // 0x80000028: Non disponible
    CONTENT_LANGUAGE(0x40004c72)                                      // 0x80000028: No disponible
    CONTENT_LANGUAGE(0x40004c73)                                      // 0x80000028: Niet beschikb.
    CONTENT_LANGUAGE(0x40004c74)                                      // 0x80000028: Nicht verf�gbar
    CONTENT_LANGUAGE(0x40004c75)                                      // 0x80000028: Non disponibile
    CONTENT_LANGUAGE(0x40004c76)                                      // 0x80000028: N�o dispon�vel
    CONTENT_LANGUAGE(0x40004c77)                                      // 0x80000028: ??????????
    CONTENT_LANGUAGE(0x40004c78)                                      // 0x80000028: Mevcut de?il
    CONTENT_LANGUAGE(0x400027e4)                                      // 0x80000028: Not Available
    CONTENT_LANGUAGE(0x40004c71)                                      // 0x80000028: Non disponible
    CONTENT_LANGUAGE(0x40004c72)                                      // 0x80000028: No disponible
    CONTENT_LANGUAGE(0x40004c79)                                      // 0x80000028: Ikke t. r�digh.
    CONTENT_LANGUAGE(0x40004c7a)                                      // 0x80000028: Ej tillg�nglig
    CONTENT_LANGUAGE(0x40004c7b)                                      // 0x80000028: Ei k�ytett�v.
    CONTENT_LANGUAGE(0x40004c7c)                                      // 0x80000028: Ikke tilgjeng.
    CONTENT_LANGUAGE(0x40004c7d)                                      // 0x80000028: Niedost?pny
    CONTENT_LANGUAGE(0x40004c7e)                                      // 0x80000028: Nie je k disp.
    CONTENT_LANGUAGE(0x40004c7f)                                      // 0x80000028: Nen� k dispozici
    CONTENT_LANGUAGE(0x40004c80)                                      // 0x80000028: Nem el�rhet?
    CONTENT_LANGUAGE(0x40004c81)                                      // 0x80000028: ?? ?????????
    CONTENT_LANGUAGE(0x40004c76)                                      // 0x80000028: N�o dispon�vel
    CONTENT_LANGUAGE(0x40004c82)                                      // 0x80000028: ??? ????
    CONTENT_LANGUAGE(0x40004c83)                                      // 0x80000028: ????????
    CONTENT_LANGUAGE(0x40004c77)                                      // 0x80000028: ??????????
    //STRING_END()
    //STRING_START(11)
    CONTENT_LANGUAGE(0x40004c46)                                      // 0x80000029: mph
    CONTENT_LANGUAGE(0x40004c46)                                      // 0x80000029: mph
    CONTENT_LANGUAGE(0x40004c46)                                      // 0x80000029: mph
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000029: #No translation required
    //STRING_END()
    //STRING_START(12)
    CONTENT_LANGUAGE(0x40004c84)                                      // 0x8000002a: km/h
    CONTENT_LANGUAGE(0x40004c84)                                      // 0x8000002a: km/h
    CONTENT_LANGUAGE(0x40004c84)                                      // 0x8000002a: km/h
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002a: #No translation required
    //STRING_END()
    //STRING_START(13)
    CONTENT_LANGUAGE(0x4000305e)                                      // 0x8000002b: N
    CONTENT_LANGUAGE(0x4000305e)                                      // 0x8000002b: N
    CONTENT_LANGUAGE(0x4000305e)                                      // 0x8000002b: N
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002b: #No translation required
    //STRING_END()
    //STRING_START(14)
    CONTENT_LANGUAGE(0x4000305f)                                      // 0x8000002c: NNE
    CONTENT_LANGUAGE(0x4000305f)                                      // 0x8000002c: NNE
    CONTENT_LANGUAGE(0x4000305f)                                      // 0x8000002c: NNE
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002c: #No translation required
    //STRING_END()
    //STRING_START(15)
    CONTENT_LANGUAGE(0x40003060)                                      // 0x8000002d: NE
    CONTENT_LANGUAGE(0x40003060)                                      // 0x8000002d: NE
    CONTENT_LANGUAGE(0x40003060)                                      // 0x8000002d: NE
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002d: #No translation required
    //STRING_END()
    //STRING_START(16)
    CONTENT_LANGUAGE(0x40003061)                                      // 0x8000002e: ENE
    CONTENT_LANGUAGE(0x40003061)                                      // 0x8000002e: ENE
    CONTENT_LANGUAGE(0x40003061)                                      // 0x8000002e: ENE
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002e: #No translation required
    //STRING_END()
    //STRING_START(17)
    CONTENT_LANGUAGE(0x40003062)                                      // 0x8000002f: E
    CONTENT_LANGUAGE(0x40003062)                                      // 0x8000002f: E
    CONTENT_LANGUAGE(0x40003062)                                      // 0x8000002f: E
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000002f: #No translation required
    //STRING_END()
    //STRING_START(18)
    CONTENT_LANGUAGE(0x40003063)                                      // 0x80000030: ESE
    CONTENT_LANGUAGE(0x40003063)                                      // 0x80000030: ESE
    CONTENT_LANGUAGE(0x40003063)                                      // 0x80000030: ESE
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000030: #No translation required
    //STRING_END()
    //STRING_START(19)
    CONTENT_LANGUAGE(0x40003064)                                      // 0x80000031: SE
    CONTENT_LANGUAGE(0x40003064)                                      // 0x80000031: SE
    CONTENT_LANGUAGE(0x40003064)                                      // 0x80000031: SE
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000031: #No translation required
    //STRING_END()
    //STRING_START(20)
    CONTENT_LANGUAGE(0x40003065)                                      // 0x80000032: SSE
    CONTENT_LANGUAGE(0x40003065)                                      // 0x80000032: SSE
    CONTENT_LANGUAGE(0x40003065)                                      // 0x80000032: SSE
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000032: #No translation required
    //STRING_END()
    //STRING_START(21)
    CONTENT_LANGUAGE(0x40002590)                                      // 0x80000033: S
    CONTENT_LANGUAGE(0x40002590)                                      // 0x80000033: S
    CONTENT_LANGUAGE(0x40002590)                                      // 0x80000033: S
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000033: #No translation required
    //STRING_END()
    //STRING_START(22)
    CONTENT_LANGUAGE(0x40003066)                                      // 0x80000034: SSW
    CONTENT_LANGUAGE(0x40004c85)                                      // 0x80000034: SSO
    CONTENT_LANGUAGE(0x40004c85)                                      // 0x80000034: SSO
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000034: #No translation required
    //STRING_END()
    //STRING_START(23)
    CONTENT_LANGUAGE(0x40003067)                                      // 0x80000035: SW
    CONTENT_LANGUAGE(0x40004c86)                                      // 0x80000035: SO
    CONTENT_LANGUAGE(0x40004c86)                                      // 0x80000035: SO
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000035: #No translation required
    //STRING_END()
    //STRING_START(24)
    CONTENT_LANGUAGE(0x40003068)                                      // 0x80000036: WSW
    CONTENT_LANGUAGE(0x40004c87)                                      // 0x80000036: OSO
    CONTENT_LANGUAGE(0x40004c87)                                      // 0x80000036: OSO
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000036: #No translation required
    //STRING_END()
    //STRING_START(25)
    CONTENT_LANGUAGE(0x40003069)                                      // 0x80000037: W
    CONTENT_LANGUAGE(0x40004c88)                                      // 0x80000037: O
    CONTENT_LANGUAGE(0x40004c88)                                      // 0x80000037: O
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000037: #No translation required
    //STRING_END()
    //STRING_START(26)
    CONTENT_LANGUAGE(0x4000306a)                                      // 0x80000038: WNW
    CONTENT_LANGUAGE(0x40004c89)                                      // 0x80000038: ONO
    CONTENT_LANGUAGE(0x40004c89)                                      // 0x80000038: ONO
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000038: #No translation required
    //STRING_END()
    //STRING_START(27)
    CONTENT_LANGUAGE(0x4000306b)                                      // 0x80000039: NW
    CONTENT_LANGUAGE(0x40004147)                                      // 0x80000039: NO
    CONTENT_LANGUAGE(0x40004147)                                      // 0x80000039: NO
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000039: #No translation required
    //STRING_END()
    //STRING_START(28)
    CONTENT_LANGUAGE(0x4000306c)                                      // 0x8000003a: NNW
    CONTENT_LANGUAGE(0x40004c8a)                                      // 0x8000003a: NNO
    CONTENT_LANGUAGE(0x40004c8a)                                      // 0x8000003a: NNO
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000003a: #No translation required
    //STRING_END()
    //STRING_START(29)
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x40004c8b)                                      // 0x8000003b: ??
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x8000003b: mi
    CONTENT_LANGUAGE(0x40004c8c)                                      // 0x8000003b: ???
    CONTENT_LANGUAGE(0x40004c8d)                                      // 0x8000003b: ????
    CONTENT_LANGUAGE(0x40004c8e)                                      // 0x8000003b: ????
    //STRING_END()
    //STRING_START(30)
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x40004c8f)                                      // 0x8000003c: ??
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x8000003c: km
    CONTENT_LANGUAGE(0x40004c90)                                      // 0x8000003c: ??
    CONTENT_LANGUAGE(0x40004c91)                                      // 0x8000003c: ??.
    CONTENT_LANGUAGE(0x40004c8f)                                      // 0x8000003c: ??
    //STRING_END()
    //STRING_START(31)
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x40004c92)                                      // 0x8000003d: ???
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000003d: ft
    CONTENT_LANGUAGE(0x40004c93)                                      // 0x8000003d: ???
    CONTENT_LANGUAGE(0x40004c94)                                      // 0x8000003d: ???
    CONTENT_LANGUAGE(0x40004c95)                                      // 0x8000003d: ????
    //STRING_END()
    //STRING_START(32)
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x40004c96)                                      // 0x8000003e: ?
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x8000003e: m
    CONTENT_LANGUAGE(0x40004c97)                                      // 0x8000003e: ?
    CONTENT_LANGUAGE(0x40004c98)                                      // 0x8000003e: ?.
    CONTENT_LANGUAGE(0x40004c8e)                                      // 0x8000003e: ????
    //STRING_END()
    //STRING_START(33)
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c99)                                      // 0x8000003f: inch
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c9a)                                      // 0x8000003f: poll
    CONTENT_LANGUAGE(0x40004c9b)                                      // 0x8000003f: pol
    CONTENT_LANGUAGE(0x40004c9c)                                      // 0x8000003f: ????
    CONTENT_LANGUAGE(0x40004c9d)                                      // 0x8000003f: in�
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c9e)                                      // 0x8000003f: po
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c48)                                      // 0x8000003f: in
    CONTENT_LANGUAGE(0x40004c9b)                                      // 0x8000003f: pol
    CONTENT_LANGUAGE(0x40004c9f)                                      // 0x8000003f: ????
    CONTENT_LANGUAGE(0x40004ca0)                                      // 0x8000003f: ????
    CONTENT_LANGUAGE(0x40004c9c)                                      // 0x8000003f: ????
    //STRING_END()
    //STRING_START(34)
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004ca1)                                      // 0x80000040: ??
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004c49)                                      // 0x80000040: cm
    CONTENT_LANGUAGE(0x40004ca2)                                      // 0x80000040: ??
    CONTENT_LANGUAGE(0x40004ca3)                                      // 0x80000040: ??.
    CONTENT_LANGUAGE(0x40004ca1)                                      // 0x80000040: ??
    //STRING_END()
    //STRING_START(35)
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x40004ca4)                                      // 0x80000041: ???
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x40004ca5)                                      // 0x80000041: yd
    CONTENT_LANGUAGE(0x40004ca5)                                      // 0x80000041: yd
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000041: yds
    CONTENT_LANGUAGE(0x40004ca6)                                      // 0x80000041: ????
    CONTENT_LANGUAGE(0x40004ca7)                                      // 0x80000041: ???
    CONTENT_LANGUAGE(0x40004ca4)                                      // 0x80000041: ???
    //STRING_END()
    //STRING_START(36)
    CONTENT_LANGUAGE(0x40004c4b)                                      // 0x80000042: MAP_DESTINATION
    CONTENT_LANGUAGE(0x40004ca8)                                      // 0x80000042: CARTE_DESTINATION
    CONTENT_LANGUAGE(0x40004ca9)                                      // 0x80000042: MAPA_DESTINO
    CONTENT_LANGUAGE(0x40004caa)                                      // 0x80000042: KAART_BESTEMMING
    CONTENT_LANGUAGE(0x40004cab)                                      // 0x80000042: KARTE_ZIEL
    CONTENT_LANGUAGE(0x40004cac)                                      // 0x80000042: MAPPA_DESTINAZIONE
    CONTENT_LANGUAGE(0x40004ca9)                                      // 0x80000042: MAPA_DESTINO
    CONTENT_LANGUAGE(0x40004cad)                                      // 0x80000042: ???? ?? ?????
    CONTENT_LANGUAGE(0x40004cae)                                      // 0x80000042: HAR?TA_HEDEF
    CONTENT_LANGUAGE(0x40004c4b)                                      // 0x80000042: MAP_DESTINATION
    CONTENT_LANGUAGE(0x40004ca8)                                      // 0x80000042: CARTE_DESTINATION
    CONTENT_LANGUAGE(0x40004ca9)                                      // 0x80000042: MAPA_DESTINO
    CONTENT_LANGUAGE(0x40004caf)                                      // 0x80000042: KORT_DESTINATION 
    CONTENT_LANGUAGE(0x40004cb0)                                      // 0x80000042: KARTA_RESM�L
    CONTENT_LANGUAGE(0x40004cb1)                                      // 0x80000042: KARTTA_M��R�NP��
    CONTENT_LANGUAGE(0x40004cb2)                                      // 0x80000042: KART_DESTINASJON
    CONTENT_LANGUAGE(0x40004cb3)                                      // 0x80000042: MAPA_CEL
    CONTENT_LANGUAGE(0x40004cb4)                                      // 0x80000042: MAPA_CIE?
    CONTENT_LANGUAGE(0x40004cb5)                                      // 0x80000042: MAPA_C�L
    CONTENT_LANGUAGE(0x40004cb6)                                      // 0x80000042: T�RK�P_C�L
    CONTENT_LANGUAGE(0x40004cb7)                                      // 0x80000042: ??????_??????????
    CONTENT_LANGUAGE(0x40004ca9)                                      // 0x80000042: MAPA_DESTINO
    CONTENT_LANGUAGE(0x40004cb8)                                      // 0x80000042: ?????_??????
    CONTENT_LANGUAGE(0x40004cb9)                                      // 0x80000042: ??????_???????
    CONTENT_LANGUAGE(0x40004cba)                                      // 0x80000042: ?????_????
    //STRING_END()
#endif // #ifdef CONTENT_LANGUAGE

CONTENT_END()
