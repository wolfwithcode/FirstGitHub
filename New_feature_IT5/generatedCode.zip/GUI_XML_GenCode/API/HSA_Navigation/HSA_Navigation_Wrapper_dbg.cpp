/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Navigation_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_Navigation_Wrapper_dbg.h"
#include "clHSA_Navigation_Base.h"
#include "HSA_Navigation_Trace.h"
#include "HSA_Navigation_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_Navigation_Wrapper_dbg::~clHSA_Navigation_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_Navigation_Wrapper_dbg::clHSA_Navigation_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_Navigation_Wrapper_dbg::clHSA_Navigation_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_Navigation_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_Navigation_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__SETUP_TOGGLE_HIGHWAY_ENTRANCE_PICTURE_STATE:

            HSA_Navigation__vSetupToggleHighwayEntrancePictureState();
            break;

        case HSA_API_ENTRYPOINT__SETUP_GET_HIGHWAY_ENTRANCE_PICTURE_STATE:

            HSA_Navigation__blSetupGetHighwayEntrancePictureState();
            break;

        case HSA_API_ENTRYPOINT__SETUP_GET_SPEED_LIMIT:

            HSA_Navigation__blSetupGetSpeedLimit();
            break;

        case HSA_API_ENTRYPOINT__SETUP_SET_SPEED_LIMIT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Navigation__vSetupSetSpeedLimit(usParam1);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_NAVTEQ_FILENAME:

            HSA_Navigation__vRequestNAVTEQFilename();
            break;

        case HSA_API_ENTRYPOINT__GET_NAVTEQ_FILENAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetNAVTEQFilename(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_NAVTEQ_CHECK_DIGIT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetNAVTEQCheckDigit(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DEMO_POSITION_FROM_MAP_INPUT:

            HSA_Navigation__vSetDemoPositionFromMapInput();
            break;

        case HSA_API_ENTRYPOINT__MAP_INPUT_SAVE__HOME:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Navigation__vMapInputSave_Home(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__STORE_CURR_POSITION_AS_WAY_POINT:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Navigation__vStoreCurrPositionAsWayPoint(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_NEAR_BY_FOOD_START_NAR:

            HSA_Navigation__vPOISearchNearByFoodStart_NAR();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_NEARBY_ATM_START:

            HSA_Navigation__vPOISearchNearbyATMStart();
            break;

        case HSA_API_ENTRYPOINT__STORE_CURRENT_DEST_AS_WAY_POINT:

            HSA_Navigation__vStoreCurrentDestAsWayPoint();
            break;

        case HSA_API_ENTRYPOINT__STORE_CUR_DEST_AS_WAY_POINT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vStoreCurDestAsWayPoint(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SKIPPED_WAYPOINT_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetSkippedWaypointName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SKIP_WAYPOINT_AND_START_ROUTE_GUIDANCE:

            HSA_Navigation__vSkipWaypointAndStartRouteGuidance();
            break;

        case HSA_API_ENTRYPOINT__POI_SELECT_BY_CATEGORY_NAR:

            HSA_Navigation__vPOISelectByCategory_NAR();
            break;

        case HSA_API_ENTRYPOINT__POI_ALONG_ROUTE_PREPARE_SEARCH_ENGINE:

            HSA_Navigation__vPOIAlongRoutePrepareSearchEngine();
            break;

        case HSA_API_ENTRYPOINT__POI_SET_CATEGORY_ALONG_ROUTE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vPoiSetCategoryAlongRoute(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_LIST_PREPARED_NAR:

            HSA_Navigation__ulwIsListPrepared_NAR();
            break;

        case HSA_API_ENTRYPOINT__GET_POI_CATEGORY_LIST_NAR:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vGetPOICategoryList_NAR(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SAVE_HOUSE_NO_NAR:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSaveHouseNo_NAR(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_COUNTRY_CAR_PLATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetCurrentCountryCarPlate(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__INITIALIZE_SPEED_PROFILE:

            HSA_Navigation__vInitializeSpeedProfile();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_USER_SPEED_PROFILE:

            HSA_Navigation__vToggleUserSpeedProfile();
            break;

        case HSA_API_ENTRYPOINT__IS_USER_SPEED_PROFILE_ON:

            HSA_Navigation__blIsUserSpeedProfileOn();
            break;

        case HSA_API_ENTRYPOINT__SET_SPEED_PROFILE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam2); 

            HSA_Navigation__vSetSpeedProfile(ulParam1, usParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SPEED_PROFILE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vGetSpeedProfile(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__CONFIRM_SPEED_PROFILE:

            HSA_Navigation__vConfirmSpeedProfile();
            break;

        case HSA_API_ENTRYPOINT__GET_LANGUAGE_DEPENDENT_STRINGS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vGetLanguageDependentStrings(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__IS_LIM_SERVICE_AVAILABLE:

            HSA_Navigation__blIsLIMServiceAvailable();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_COUNTRY_INDEX:

            HSA_Navigation__ulwGetCurrentCountryIndex();
            break;

        case HSA_API_ENTRYPOINT__SD_GET_INFO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vSDGetInfo(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__MAP_INPUT_PREPARE_SAVING:

            HSA_Navigation__vMapInputPrepareSaving();
            break;

        case HSA_API_ENTRYPOINT__MAP_INPUT_GET_NAME_FOR_DEST_IDENT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vMapInputGetNameForDestIdent(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_SAVE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vDestEntrySave(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__UPS_GET_SELECTED_POI:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vUPSGetSelectedPOI(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__UPSPOI_PREPARE_GUIDANCE_FROM_DETAILS:

            HSA_Navigation__vUPSPOIPrepareGuidanceFromDetails();
            break;

        case HSA_API_ENTRYPOINT__IS_UPS_CATEGORY_PREPARED:

            HSA_Navigation__blIsUPSCategoryPrepared();
            break;

        case HSA_API_ENTRYPOINT__ON_UPS_DATA_UPDATE:

            HSA_Navigation__blOnUPSDataUpdate();
            break;

        case HSA_API_ENTRYPOINT__IS_UPSPOI_LIST_PREPARED:

            HSA_Navigation__blIsUPSPOIListPrepared();
            break;

        case HSA_API_ENTRYPOINT__GET_UPS_DISTANCE:

            HSA_Navigation__ulwGetUPSDistance();
            break;

        case HSA_API_ENTRYPOINT__GET_POI_PROXIMITY_WARNING:

            HSA_Navigation__ulwGetPOIProximityWarning();
            break;

        case HSA_API_ENTRYPOINT__GET_UPSPOI_DETAIL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetUPSPOIDetail(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__FLAG_ENTRY_PREPARE_SAVING:

            HSA_Navigation__vFlagEntryPrepareSaving();
            break;

        case HSA_API_ENTRYPOINT__FLAG_ENTRY_SAVE:

            HSA_Navigation__vFlagEntrySave();
            break;

        case HSA_API_ENTRYPOINT__IS_CATEGORY_RESTORE_POSSIBLE:

            HSA_Navigation__blIsCategoryRestorePossible();
            break;

        case HSA_API_ENTRYPOINT__RESTORE_CATEGORY:

            HSA_Navigation__vRestoreCategory();
            break;

        case HSA_API_ENTRYPOINT__GET_UPS_PROXIMITY_WARNING:

            HSA_Navigation__ulwGetUPSProximityWarning();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_SET_POI_PROXIMITY_WARNING:

            HSA_Navigation__vToggleSetPOIProximityWarning();
            break;

        case HSA_API_ENTRYPOINT__DELETE_UPS:

            HSA_Navigation__vDeleteUPS();
            break;

        case HSA_API_ENTRYPOINT__UPS_DELETE_STATE:

            HSA_Navigation__ulwUPSDeleteState();
            break;

        case HSA_API_ENTRYPOINT__SET_UPS_DISTANCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSetUPSDistance(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TRAVEL_ADVANTAGE_VALUES:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__ulwGetTravelAdvantageValues(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DYN_ROUTE_CONSIDER_UPDATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vDynRouteConsiderUpdate(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_CODE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetCurrentCode(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_UPS_DATA_AVAILABLE_IN_SYSTEM:

            HSA_Navigation__blIsUPSDataAvailableInSystem();
            break;

        case HSA_API_ENTRYPOINT__START_LIST_CATEGORY:

            HSA_Navigation__vStartListCategory();
            break;

        case HSA_API_ENTRYPOINT__IS_UPS_DATA_AVAILABLE:

            HSA_Navigation__blIsUPSDataAvailable();
            break;

        case HSA_API_ENTRYPOINT__GET_UPS_DOWNLOAD_PROGRESS:

            HSA_Navigation__ulwGetUPSDownloadProgress();
            break;

        case HSA_API_ENTRYPOINT__GET_UPS_DOWNLOAD_STATE:

            HSA_Navigation__ulwGetUPSDownloadState();
            break;

        case HSA_API_ENTRYPOINT__STOP_UPS_DOWNLOAD:

            HSA_Navigation__vStopUPSDownload();
            break;

        case HSA_API_ENTRYPOINT__START_UPS_DOWNLOAD:

            HSA_Navigation__vStartUPSDownload();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_LANE_INFORMATION:

            HSA_Navigation__vToggleLaneInformation();
            break;

        case HSA_API_ENTRYPOINT__SETUP_GET_LANE_GUIDANCE_SYMBOLS_STATE:

            HSA_Navigation__blSetupGetLaneGuidanceSymbolsState();
            break;

        case HSA_API_ENTRYPOINT__GET_UPS_CATEGORY_COUNT:

            HSA_Navigation__ulwGetUPSCategoryCount();
            break;

        case HSA_API_ENTRYPOINT__GET_UPS_CATEGORY_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vGetUPSCategoryList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__UPS_SET_CATEGORY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vUPSSetCategory(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_UPSPOI_COUNT:

            HSA_Navigation__ulwGetUPSPOICount();
            break;

        case HSA_API_ENTRYPOINT__GET_UPSPOI_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vGetUPSPOIList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__UPS_GET_SELECTED_CATEGORY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vUPSGetSelectedCategory(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__UPSGET_DETAILS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vUPSGETDetails(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_UPSERRORPOI_COUNT:

            HSA_Navigation__ulwGetUPSERRORPOICount();
            break;

        case HSA_API_ENTRYPOINT__GET_UPSERROR_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vGetUPSERRORList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__REPEAT_LAST_NAVIGATION_ANNOUNCEMENT:

            HSA_Navigation__vRepeatLastNavigationAnnouncement();
            break;

        case HSA_API_ENTRYPOINT__CURRENT_CAR_POSITION_AVAILABLE:

            HSA_Navigation__blCurrentCarPositionAvailable();
            break;

        case HSA_API_ENTRYPOINT__CURRENT_CAR_POSITION_VALID_ON_MAP:

            HSA_Navigation__blCurrentCarPositionValidOnMap();
            break;

        case HSA_API_ENTRYPOINT__COMPLEX_ENTRY_DISCLAIMER_SPEED_THRESHOLD_ACHIEVED:

            HSA_Navigation__blComplexEntryDisclaimerSpeedThresholdAchieved();
            break;

        case HSA_API_ENTRYPOINT__CONVERT_TO_DYNAMIC_INDEX__ROUTE_MANEUVER_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__slwConvertToDynamicIndex_RouteManeuverList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__CONVERT_TO_UNIQUE_ID__ROUTE_MANEUVER_LIST:

            HSA_Navigation__slwConvertToUniqueId_RouteManeuverList();
            break;

        case HSA_API_ENTRYPOINT__CURRENT_DESTINATION_IS_STARTABLE:

            HSA_Navigation__blCurrentDestinationIsStartable();
            break;

        case HSA_API_ENTRYPOINT__DECREASE_ANNOUNCE_VOLUME:

            HSA_Navigation__vDecreaseAnnounceVolume();
            break;

        case HSA_API_ENTRYPOINT__DELETE_CURRENT_DESTINATION:

            HSA_Navigation__vDeleteCurrentDestination();
            break;

        case HSA_API_ENTRYPOINT__DEMO_START_LOCATION_AVAILABLE:

            HSA_Navigation__blDemoStartLocationAvailable();
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_GET_ADDRESS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vDestEntryGetAddress(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_ACTIVATE_NAV_DEST_FORM_ITEM:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vDestEntryActivateNavDestFormItem(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__RESTORE_DEST_ENTRY_ACTIVATE_NAV_DEST_FORM_ITEM:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vRestoreDestEntryActivateNavDestFormItem(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_GET_FAVOURITE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vDestEntryGetFavourite(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_GET_POI:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vDestEntryGetPOI(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_GET_POI_LAST_DEST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vDestEntryGetPOILastDest(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_GET_HOME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vDestEntryGetHome(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_GET_GEO_POS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vDestEntryGetGeoPos(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_INIT:

            HSA_Navigation__vDestEntryInit();
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_INIT_WITH_COUNTRY:

            HSA_Navigation__vDestEntryInitWithCountry();
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_IS_VALID:

            HSA_Navigation__blDestEntryIsValid();
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_GET_HOUSE_NUMBER_AVAILABILITY:

            HSA_Navigation__blDestEntryGetHouseNumberAvailability();
            break;

        case HSA_API_ENTRYPOINT__DEST_MEM_DEST_ENTRY_CHANGED:

            HSA_Navigation__blDestMemDestEntryChanged();
            break;

        case HSA_API_ENTRYPOINT__IS_DESTINATION_OFF_MAP:

            HSA_Navigation__blIsDestinationOFFMap();
            break;

        case HSA_API_ENTRYPOINT__GET_ROUTE_BLOCK_SELECTION:

            HSA_Navigation__blGetRouteBlockSelection();
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_PREPARE_GUIDANCE:

            HSA_Navigation__vDestEntryPrepareGuidance();
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_PREPARE_SAVING:

            HSA_Navigation__vDestEntryPrepareSaving();
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_RENAME_FAVORITE:

            HSA_Navigation__vDestEntryRenameFavorite();
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_SELECT_ADDR:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vDestEntrySelectAddr(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DESTENTRY_SELECT_WAY_POINT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vDestentrySelectWayPoint(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_SET_DATA:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vDestEntrySetData(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_SET_DATA_CITY_TO_CITY_CENTER:

            HSA_Navigation__vDestEntrySetDataCityToCityCenter();
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_GET_DATA_SHORT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vDestEntryGetDataShort(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_CATEGORY_IS_POSSIBLE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__blDestEntryCategoryIsPossible(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__FLAG_DEST_GET_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vFlagDestGetName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__FLAG_DEST_SAVE:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Navigation__vFlagDestSave(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__FLAG_DEST_SAVE_STATE:

            HSA_Navigation__ulwFlagDestSaveState();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_AVERAGE_SPEED:

            HSA_Navigation__ulwGetActiveAverageSpeed();
            break;

        case HSA_API_ENTRYPOINT__GET_CALC_ROUTE_FAILS:

            HSA_Navigation__blGetCalcRouteFails();
            break;

        case HSA_API_ENTRYPOINT__GET_CALC_ROUTE_IS_RUNNING:

            HSA_Navigation__ulwGetCalcRouteIsRunning();
            break;

        case HSA_API_ENTRYPOINT__GET_CALC_ROUTE_PROGRESS:

            HSA_Navigation__ulwGetCalcRouteProgress();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_DESTINATION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vGetCurrentDestination(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_DESTINATION_DATA:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetCurrentDestinationData(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_DESTINATION_DETAIL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vGetCurrentDestinationDetail(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_WAYPOINT_FOR_SAVE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetCurrentWaypointForSave(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_DESTINATION_SHORT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetCurrentDestinationShort(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_INT_DEST_DETAIL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vGetCurrentIntDestDetail(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_DISAMBIGUATION_CITY_CENTER_ITEM:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSetDisambiguationCityCenterItem(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DISAMBIGUATION_CITY_CENTER_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vGetDisambiguationCityCenterList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DISAMBIGUATION_CITY_CENTER_ITEM_COUNT:

            HSA_Navigation__ulwGetDisambiguationCityCenterItemCount();
            break;

        case HSA_API_ENTRYPOINT__GET_DISAMBIGUATION_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vGetDisambiguationList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_DISAMBIGUATION_ITEM:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSetDisambiguationItem(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DISAMBIGUATION_ITEM_COUNT:

            HSA_Navigation__ulwGetDisambiguationItemCount();
            break;

        case HSA_API_ENTRYPOINT__GET_GUIDANCE_STATE:

            HSA_Navigation__ulwGetGuidanceState();
            break;

        case HSA_API_ENTRYPOINT__GET_INTERMEDIATE_DESTINATION_GUIDANCE_STATE:

            HSA_Navigation__ulwGetIntermediateDestinationGuidanceState();
            break;

        case HSA_API_ENTRYPOINT__SET_LAST_GUIDANCE_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSetLastGuidanceState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__RESTART_ROUTE_GUIDANCE:

            HSA_Navigation__vRestartRouteGuidance();
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_GUIDANCE_STATE:

            HSA_Navigation__blGetLastGuidanceState();
            break;

        case HSA_API_ENTRYPOINT__GET_POSITION_DATA_DETAIL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vGetPositionDataDetail(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_POSITION_DATA_SHORT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetPositionDataShort(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TEMPORARY_MODE:

            HSA_Navigation__blGetTemporaryMode();
            break;

        case HSA_API_ENTRYPOINT__HOME_DEST_GET_DATA_SHORT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vHomeDestGetDataShort(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__HOME_DEST_IS_GEO_POS:

            HSA_Navigation__blHomeDestIsGeoPos();
            break;

        case HSA_API_ENTRYPOINT__HOME_DEST_INIT:

            HSA_Navigation__vHomeDestInit();
            break;

        case HSA_API_ENTRYPOINT__HOME_DEST_IS_DEFINED:

            HSA_Navigation__blHomeDestIsDefined();
            break;

        case HSA_API_ENTRYPOINT__HOME_SAVE_CCP:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Navigation__vHomeSaveCCP(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_SAVE__HOME:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Navigation__vDestEntrySave_Home(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__STORE_MAIN_DESTINATION:

            HSA_Navigation__vStoreMainDestination();
            break;

        case HSA_API_ENTRYPOINT__STORE_CUR_DEST_FROM_WAYPOINT_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vStoreCurDestFromWaypointList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__HOME_PREPARE_GUIDANCE:

            HSA_Navigation__vHomePrepareGuidance();
            break;

        case HSA_API_ENTRYPOINT__HOME_CHECK_AVAILABILITY:

            HSA_Navigation__vHomeCheckAvailability();
            break;

        case HSA_API_ENTRYPOINT__INCREASE_ANNOUNCE_VOLUME:

            HSA_Navigation__vIncreaseAnnounceVolume();
            break;

        case HSA_API_ENTRYPOINT__INIT:

            HSA_Navigation__vInit();
            break;

        case HSA_API_ENTRYPOINT__INT_DEST_DELETE_INTERMEDIATE:

            HSA_Navigation__vIntDestDeleteIntermediate();
            break;

        case HSA_API_ENTRYPOINT__INT_DEST_REPLACE_MAIN_DEST:

            HSA_Navigation__vIntDestReplaceMainDest();
            break;

        case HSA_API_ENTRYPOINT__INT_DEST_INSERT_INTERMEDIATE:

            HSA_Navigation__vIntDestInsertIntermediate();
            break;

        case HSA_API_ENTRYPOINT__INT_DEST_REPLACE_INTERMEDIATE:

            HSA_Navigation__vIntDestReplaceIntermediate();
            break;

        case HSA_API_ENTRYPOINT__IS_AVAILABLE_STREETS_IN_CITY:

            HSA_Navigation__blIsAvailableStreetsInCity();
            break;

        case HSA_API_ENTRYPOINT__IS_DESTINATION_UNIQUE:

            HSA_Navigation__blIsDestinationUnique();
            break;

        case HSA_API_ENTRYPOINT__IS_HN_DEFINED:

            HSA_Navigation__blIsHNDefined();
            break;

        case HSA_API_ENTRYPOINT__IS_CROSSING_AVAILABLE:

            HSA_Navigation__blIsCrossingAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_HOUSE_NUMBER_UNIQUE:

            HSA_Navigation__blIsHouseNumberUnique();
            break;

        case HSA_API_ENTRYPOINT__IS_CITY_CENTER_UNIQUE:

            HSA_Navigation__blIsCityCenterUnique();
            break;

        case HSA_API_ENTRYPOINT__IS_INITIALIZED:

            HSA_Navigation__ulwIsInitialized();
            break;

        case HSA_API_ENTRYPOINT__IS_DATA_AVAILABLE:

            HSA_Navigation__ulwIsDataAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_NAVI_DATA_AVAILABLE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__blIsNaviDataAvailable(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__LAST_CURRENT_DEST_PREPARE_GUIDANCE:

            HSA_Navigation__vLastCurrentDestPrepareGuidance();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_CLEAR_STATE:

            HSA_Navigation__ulwMemoryClearState();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_ENTRY_TYPE:

            HSA_Navigation__ulwMemoryEntryType();
            break;

        case HSA_API_ENTRYPOINT__WAYPOINT_MEMORY_ENTRY_TYPE:

            HSA_Navigation__ulwWaypointMemoryEntryType();
            break;

        case HSA_API_ENTRYPOINT__GET_SELECTED_WAYPOINT_INDEX:

            HSA_Navigation__ulwGetSelectedWaypointIndex();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_INT_DEST_ENTRY_TYPE:

            HSA_Navigation__ulwMemoryIntDestEntryType();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_CLEAR:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vMemoryDestMemClear(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_EXISTS_NAME:

            HSA_Navigation__blMemoryDestMemExistsName();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vMemoryDestMemGetList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_LIST_COUNT:

            HSA_Navigation__ulwMemoryDestMemGetListCount();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_INPUT_FILTER_STRING:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Navigation__vMemoryDestMemInputFilterString(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_IS_EMPTY:

            HSA_Navigation__blMemoryDestMemIsEmpty();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_IS_FULL:

            HSA_Navigation__blMemoryDestMemIsFull();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_PREPARE_GUIDANCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vMemoryDestMemPrepareGuidance(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_PREPARE_LIST:

            HSA_Navigation__vMemoryDestMemPrepareList();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_PREPARE_SEARCH:

            HSA_Navigation__vMemoryDestMemPrepareSearch();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_SEARCH_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vMemoryDestMemGetSearchList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_SEARCH_LIST_COUNT:

            HSA_Navigation__ulwMemoryDestMemGetSearchListCount();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_ACTIVATE_SEARCH:

            HSA_Navigation__vMemoryDestMemActivateSearch();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_SAVE_STATE:

            HSA_Navigation__ulwMemoryDestMemSaveState();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_GET_INFO_SHORT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vMemoryDestMemGetInfoShort(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_DEST_MEM_DELETE_STATE:

            HSA_Navigation__ulwMemoryDestMemDeleteState();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_CLEAR:

            HSA_Navigation__vMemoryLastDestClear();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_GET_INFO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vMemoryLastDestGetInfo(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_GET_INFO_SHORT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vMemoryLastDestGetInfoShort(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_GET_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vMemoryLastDestGetList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_GET_LIST_COUNT:

            HSA_Navigation__ulwMemoryLastDestGetListCount();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_LIST_EMPTY:

            HSA_Navigation__blMemoryLastDestListEmpty();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_PREPARE_GUIDANCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vMemoryLastDestPrepareGuidance(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_SELECT_FOR_SAVING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vMemoryLastDestSelectForSaving(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_LAST_DEST_PREPARE_LIST:

            HSA_Navigation__vMemoryLastDestPrepareList();
            break;

        case HSA_API_ENTRYPOINT__HN_MATCH_FOR_REDUCTION:

            HSA_Navigation__vHNMatchForReduction();
            break;

        case HSA_API_ENTRYPOINT__POI_PREPARE_SEARCH_ENGINE:

            HSA_Navigation__vPOIPrepareSearchEngine();
            break;

        case HSA_API_ENTRYPOINT__POI_GET_RESULT_COUNT:

            HSA_Navigation__ulwPOIGetResultCount();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_IS_AVAILABLE:

            HSA_Navigation__blPOISearchIsAvailable();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_STRING_IS_SERVICEABLE:

            HSA_Navigation__blPOISearchStringIsServiceable();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_PARAM_SET_CHARACTER:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Navigation__vPOISearchParamSetCharacter(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_POI_SPELLER_SEARCH_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetPOISpellerSearchString(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_PARAM_SET_CURRENT_CAR_POSITION:

            HSA_Navigation__vPOISearchParamSetCurrentCarPosition();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_PARAM_SET_LOCATION:

            HSA_Navigation__vPOISearchParamSetLocation();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_PARAM_SET_DESTINATION:

            HSA_Navigation__vPOISearchParamSetDestination();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_PROGRESS_GET_RADIUS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vPOISearchProgressGetRadius(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_POI_SEARCH_INPUT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vSpellerGetPOISearchInput(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__POI_SELECT_FOR_SAVING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vPOISelectForSaving(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__POI_SELECT_FOR_SAVING_FROM_DETAIL:

            HSA_Navigation__vPOISelectForSavingFromDetail();
            break;

        case HSA_API_ENTRYPOINT__POI_TOP_SELECT_FOR_SAVING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vPOITopSelectForSaving(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__POI_TOP_SELECT_FOR_SAVING_FROM_DETAIL:

            HSA_Navigation__vPOITopSelectForSavingFromDetail();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_COUNT:

            HSA_Navigation__ulwPOISearchResultCount();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_LIST_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Navigation__vPOISearchResultGetListString(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_LIST_VALUE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__ulwPOISearchResultGetListValue(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_SELECTED_DATA:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vPOISearchResultGetSelectedData(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_SELECTED_HAS_ADDITIONAL_INFO:

            HSA_Navigation__blPOISearchResultGetSelectedHasAdditionalInfo();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_LIST_SELECT_FOR_DETAILS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vPOISearchResultListSelectForDetails(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__POI_GET_CURRENT_DETAIL_VIEW_INDEX:

            HSA_Navigation__ulwPOIGetCurrentDetailViewIndex();
            break;

        case HSA_API_ENTRYPOINT__POI_PREPARE_GUIDANCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vPOIPrepareGuidance(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__POI_PREPARE_GUIDANCE_FROM_DETAILS:

            HSA_Navigation__vPOIPrepareGuidanceFromDetails();
            break;

        case HSA_API_ENTRYPOINT__POI_TOP_PREPARE_GUIDANCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vPOITopPrepareGuidance(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__POI_EDIT_LOCATION_INIT:

            HSA_Navigation__vPOIEditLocationInit();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_START:

            HSA_Navigation__vPOISearchStart();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_GAS_STATION_START:

            HSA_Navigation__vPOISearchGasStationStart();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_PARKING_AREA_START:

            HSA_Navigation__vPOISearchParkingAreaStart();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_STATE:

            HSA_Navigation__ulwPOISearchState();
            break;

        case HSA_API_ENTRYPOINT__TELEMATIC_PARAM_SET_AROUND_CAR_POSITION:

            HSA_Navigation__vTelematicParamSetAroundCarPosition();
            break;

        case HSA_API_ENTRYPOINT__TELEMATIC_SEARCH_AROUND_CITY:

            HSA_Navigation__vTelematicSearchAroundCity();
            break;

        case HSA_API_ENTRYPOINT__TELEMATIC_SEARCH_AROUND_DEST:

            HSA_Navigation__vTelematicSearchAroundDest();
            break;

        case HSA_API_ENTRYPOINT__XM_PARAM_SET_AROUND_CAR_POSITION:

            HSA_Navigation__vXMParamSetAroundCarPosition();
            break;

        case HSA_API_ENTRYPOINT__XM_SEARCH_AROUND_CITY:

            HSA_Navigation__vXMSearchAroundCity();
            break;

        case HSA_API_ENTRYPOINT__XM_SEARCH_AROUND_DEST:

            HSA_Navigation__vXMSearchAroundDest();
            break;

        case HSA_API_ENTRYPOINT__TELEMATIC_POI_PREPARE_GUIDANCE_FROM_DETAILS:

            HSA_Navigation__vTelematicPOIPrepareGuidanceFromDetails();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_STOP:

            HSA_Navigation__vPOISearchStop();
            break;

        case HSA_API_ENTRYPOINT__POI_TOP_SEARCH_STOP:

            HSA_Navigation__vPOITopSearchStop();
            break;

        case HSA_API_ENTRYPOINT__RECALCULATE_ROUTE:

            HSA_Navigation__vRecalculateRoute();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_BLOCK_CONGESTION_AHEAD_APPLY:

            HSA_Navigation__vRouteBlockCongestionAheadApply();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_BLOCK_CONGESTION_AHEAD_DECREASE:

            HSA_Navigation__vRouteBlockCongestionAheadDecrease();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_BLOCK_CONGESTION_AHEAD_GET_LENGTH:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vRouteBlockCongestionAheadGetLength(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_BLOCK_CONGESTION_AHEAD_INCREASE:

            HSA_Navigation__vRouteBlockCongestionAheadIncrease();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_BLOCK_DISCARD_ENTRIES:

            HSA_Navigation__vRouteBlockDiscardEntries();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_CRITERIA_APPLY_INPUT:

            HSA_Navigation__vRouteCriteriaApplyInput();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_CRITERIA_INIT:

            HSA_Navigation__vRouteCriteriaInit();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_CRITERIA_AVOID_VIGNETTE_GET_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vRouteCriteriaAvoidVignetteGetList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_CRITERIA_AVOID_VIGNETTE_GET_CHECKBOX:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vRouteCriteriaAvoidVignetteGetCheckbox(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_CRITERIA_AVOID_VIGNETTE_LIST_COUNT:

            HSA_Navigation__ulwRouteCriteriaAvoidVignetteListCount();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_CRITERIA_AVOID_VIGNETTE_TOGGLE_ITEM:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vRouteCriteriaAvoidVignetteToggleItem(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_CRITERIA_GET_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__ulwRouteCriteriaGetState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_CRITERIA_SET_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vRouteCriteriaSetState(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_GET_MODE:

            HSA_Navigation__ulwRouteGuidanceGetMode();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_GET_REMAINING_DISTANCE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vRouteGuidanceGetRemainingDistance(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_GET_REMAINING_TIME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vRouteGuidanceGetRemainingTime(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_START:

            HSA_Navigation__vRouteGuidanceStart();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_START_DEMO:

            HSA_Navigation__vRouteGuidanceStartDemo();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_START__WAYPOINT:

            HSA_Navigation__vRouteGuidanceStart_Waypoint();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_START_DEMO__WAYPOINT:

            HSA_Navigation__vRouteGuidanceStartDemo_Waypoint();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_START_POI:

            HSA_Navigation__vRouteGuidanceStartPOI();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_GUIDANCE_STOP:

            HSA_Navigation__vRouteGuidanceStop();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_DETAIL_DATA:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vRouteManeuverDetailData(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_ACTIVATE_DETAIL_DATA:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vRouteManeuverActivateDetailData(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Navigation__vRouteManeuverGetList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_DIS_TIME_UNITS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__ulwRouteManeuverGetDisTimeUnits(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MESSAGE_ICON_LABEL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__ulwRouteManeuverMessageIconLabel(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_WAYPOINT_FOR_POI_SEARCH:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSetWaypointForPOISearch(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__WAYPOINT_ICON_LABEL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__ulwWaypointIconLabel(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MARKED_LOCK_ELEMENT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__ulwRouteManeuverMarkedLockElement(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_LIST_COUNT:

            HSA_Navigation__ulwRouteManeuverGetListCount();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_SUB_ITEM_COUNT:

            HSA_Navigation__ulwRouteManeuverGetSubItemCount();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_LIST_IS_AVAILABLE:

            HSA_Navigation__blRouteManeuverListIsAvailable();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_BLOCK_IS_LOCK_LIMIT_EXCEEDED:

            HSA_Navigation__blRouteBlockIsLockLimitExceeded();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_PREPARE_LIST:

            HSA_Navigation__vRouteManeuverPrepareList();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MARK_LOCK_ELEMENT_INCREASE:

            HSA_Navigation__vRouteManeuverMarkLockElementIncrease();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MARK_LOCK_ELEMENT_DECREASE:

            HSA_Navigation__vRouteManeuverMarkLockElementDecrease();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_SET_MARK_LOCK_ELEMENT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vRouteManeuverSetMarkLockElement(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_SET_MARK_LOCK_FIRST_ELEMENT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vRouteManeuverSetMarkLockFirstElement(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_SET_MARK_LOCK_FIRST_ELEMENT_FROM_DETAILS:

            HSA_Navigation__vRouteManeuverSetMarkLockFirstElementFromDetails();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_SET_MARK_LOCK_LAST_ELEMENT_FROM_DETAILS:

            HSA_Navigation__vRouteManeuverSetMarkLockLastElementFromDetails();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_SET_MARK_LOCK_LAST_ELEMENT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vRouteManeuverSetMarkLockLastElement(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_MARK_LOCK_MODE:

            HSA_Navigation__blRouteManeuverMarkLockMode();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_SET_MARK_LOCK_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Navigation__vRouteManeuverSetMarkLockMode(usParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_IS_CONGESTION_DEFINED:

            HSA_Navigation__blRouteManeuverIsCongestionDefined();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_DELETE_CONGESTION:

            HSA_Navigation__vRouteManeuverDeleteCongestion();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_LIST_CLOSED:

            HSA_Navigation__vRouteManeuverListClosed();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_PREPARE_LIST_STATE:

            HSA_Navigation__ulwRouteManeuverPrepareListState();
            break;

        case HSA_API_ENTRYPOINT__ENTER_MOVE_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vEnterMoveMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__LIST_ENTRY_MOVE_DOWN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vListEntryMoveDown(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__LIST_ENTRY_MOVE_UP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vListEntryMoveUp(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ABORT_MOVE_MODE:

            HSA_Navigation__vAbortMoveMode();
            break;

        case HSA_API_ENTRYPOINT__LEAVE_MOVE_MODE:

            HSA_Navigation__vLeaveMoveMode();
            break;

        case HSA_API_ENTRYPOINT__WAYPOINT_GET_CURRENT_MOVE_INDEX:

            HSA_Navigation__ulwWaypointGetCurrentMoveIndex();
            break;

        case HSA_API_ENTRYPOINT__DELETE_AND_INSERT_WAYPOINT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vDeleteAndInsertWaypoint(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DELETE_WAYPOINT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vDeleteWaypoint(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_OPTION_DYN_ROUTE_GET_STATE:

            HSA_Navigation__blRouteOptionDynRouteGetState();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_OPTION_DYN_ROUTE_SET_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Navigation__vRouteOptionDynRouteSetState(usParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_OPTION_GET_STATE:

            HSA_Navigation__ulwRouteOptionGetState();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_OPTION_SET_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vRouteOptionSetState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_CURRENT_POSITION_AS_HOME_DEST:

            HSA_Navigation__vSetCurrentPositionAsHomeDest();
            break;

        case HSA_API_ENTRYPOINT__SET_TEMPORARY_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Navigation__vSetTemporaryMode(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DEMO_POSITION:

            HSA_Navigation__vSetDemoPosition();
            break;

        case HSA_API_ENTRYPOINT__SETUP_GET_ANNOUNCEMENT:

            HSA_Navigation__ulwSetupGetAnnouncement();
            break;

        case HSA_API_ENTRYPOINT__SETUP_GET_AUTOZOOM:

            HSA_Navigation__ulwSetupGetAutozoom();
            break;

        case HSA_API_ENTRYPOINT__SETUP_GET_DEMO_MODE:

            HSA_Navigation__blSetupGetDemoMode();
            break;

        case HSA_API_ENTRYPOINT__SETUP_DEACTIVATE_DEMO_MODE_SETTING:

            HSA_Navigation__blSetupDeactivateDemoModeSetting();
            break;

        case HSA_API_ENTRYPOINT__SETUP_OPTIONS_CHANGED:

            HSA_Navigation__blSetupOptionsChanged();
            break;

        case HSA_API_ENTRYPOINT__SETUP_SET_AUTOZOOM:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSetupSetAutozoom(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SETUP_SET_DEMO_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Navigation__vSetupSetDemoMode(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_INIT_INPUT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSpellerInitInput(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_INIT_RESTORE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSpellerInitRestore(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_CHARACTER_INPUT:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Navigation__vSpellerCharacterInput(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_DISCARD_ALL_INPUT:

            HSA_Navigation__vSpellerDiscardAllInput();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_NAME_INPUT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vSpellerGetNameInput(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_NAME_INPUT:

            HSA_Navigation__vSpellerSetNameInput();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_COUNT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__ulwSpellerMatchGetCount(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__MATCH_GET_LIST_COUNT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__ulwMatchGetListCount(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_FIRST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vSpellerMatchGetFirst(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_FAV_SEARCH_INPUT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vSpellerGetFavSearchInput(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_INPUT_OCCURRED:

            HSA_Navigation__blSpellerInputOccurred();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Navigation__vSpellerMatchGetList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_MATCH_ACTIVATE_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSpellerMatchActivateList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_MATCH_ACTIVATE_LIST_RESTORE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSpellerMatchActivateListRestore(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_POSSIBLE_LETTERS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vSpellerMatchGetPossibleLetters(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION:

            HSA_Navigation__blSpellerInvertGetLetterFunction();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_HIGHLIGHTED_TEXT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vSpellerGetHighlightedText(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_ENABLE_MATCH_SPELLER:

            HSA_Navigation__blSpellerEnableMatchSpeller();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_ENABLE_HOUSE_NUM_SPELLER:

            HSA_Navigation__blSpellerEnableHouseNumSpeller();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS:

            HSA_Navigation__ulwSpellerGetCursorPos();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_MAX_CHAR_COUNT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSpellerSetMaxCharCount(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_INITIAL_TEXT:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Navigation__vSpellerSetInitialText(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__START_EDITING_DEMO_MODE:

            HSA_Navigation__vStartEditingDemoMode();
            break;

        case HSA_API_ENTRYPOINT__STOP_EDITING_DEMO_MODE:

            HSA_Navigation__vStopEditingDemoMode();
            break;

        case HSA_API_ENTRYPOINT__STOP_CALC_ROUTE:

            HSA_Navigation__vStopCalcRoute();
            break;

        case HSA_API_ENTRYPOINT__WAIT_SYNC_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__ulwWaitSyncState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ROUTE_OPTION_DYN_ROUTE_USER_CONFIRM:

            HSA_Navigation__vRouteOptionDynRouteUserConfirm();
            break;

        case HSA_API_ENTRYPOINT__GET_DYN_ROUTE_OPTION:

            HSA_Navigation__ulwGetDynRouteOption();
            break;

        case HSA_API_ENTRYPOINT__SET_DYN_ROUTE_OPTION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSetDynRouteOption(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_MEMORY_LIMIT_REACHED:

            HSA_Navigation__blIsMemoryLimitReached();
            break;

        case HSA_API_ENTRYPOINT__SHOW_CATEGORY_LIST:

            HSA_Navigation__vShowCategoryList();
            break;

        case HSA_API_ENTRYPOINT__GET_HOUSE_NO_NAR:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetHouseNo_NAR(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__POI_SET_CATEGORY_NAR:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vPoiSetCategory_NAR(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_POI_LIST_TYPE:

            HSA_Navigation__ulwGetPOIListType();
            break;

        case HSA_API_ENTRYPOINT__IS_POI_CATEGORY_LIST_PREPARED:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__blIsPOICategoryListPrepared(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_POI_CATEGORY_COUNT:

            HSA_Navigation__ulwGetPOICategoryCount();
            break;

        case HSA_API_ENTRYPOINT__GET_POI_ATTRIBUTE_COUNT:

            HSA_Navigation__ulwGetPOIAttributeCount();
            break;

        case HSA_API_ENTRYPOINT__RESTORE_POI_CATEGORY_LIST:

            HSA_Navigation__vRestorePOICategoryList();
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_POI_LIST_SEL_INDEX:

            HSA_Navigation__ulwGetLastPOIListSelIndex();
            break;

        case HSA_API_ENTRYPOINT__POI_GET_SELECTED_CATEGORY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vPOIGetSelectedCategory(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_PREPARE_LIST:

            HSA_Navigation__vMemoryWaypointPrepareList();
            break;

        case HSA_API_ENTRYPOINT__EXIT_WAYPOINT_LIST:

            HSA_Navigation__vExitWaypointList();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_LIST_COUNT:

            HSA_Navigation__ulwMemoryWaypointGetListCount();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Navigation__vMemoryWaypointGetList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_DIRECTION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__ulwMemoryWaypointGetDirection(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_MEM_IS_FULL:

            HSA_Navigation__blMemoryWaypointMemIsFull();
            break;

        case HSA_API_ENTRYPOINT__WAYPOINT_PREPARE_SAVING:

            HSA_Navigation__vWaypointPrepareSaving();
            break;

        case HSA_API_ENTRYPOINT__ROUTE_MANEUVER_GET_LIST_UNIT:

            HSA_Navigation__ulwRouteManeuverGetListUnit();
            break;

        case HSA_API_ENTRYPOINT__POI_SEARCH_RESULT_GET_LIST_UNIT:

            HSA_Navigation__ulwPOISearchResultGetListUnit();
            break;

        case HSA_API_ENTRYPOINT__GET_POSITION_DATA_DETAIL_UNIT:

            HSA_Navigation__ulwGetPositionDataDetailUnit();
            break;

        case HSA_API_ENTRYPOINT__MEMORY_WAYPOINT_GET_LIST_UNIT:

            HSA_Navigation__ulwMemoryWaypointGetListUnit();
            break;

        case HSA_API_ENTRYPOINT__SET_GNSSSAT_SYSTEM_TYPE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Navigation__vSetGnsssatSystemType(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_GNSSSAT_SYSTEM_TYPE:

            HSA_Navigation__ulwGetGnsssatSystemType();
            break;

        case HSA_API_ENTRYPOINT__GET_LANGUAGE_DEPENDENT_STRINGS_UNIT:

            HSA_Navigation__ulwGetLanguageDependentStringsUnit();
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_GET_WAYPOINT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Navigation__vDestEntryGetWaypoint(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__STREET_POSSIBLE_AFTER_CITY:

            HSA_Navigation__blStreetPossibleAfterCity();
            break;

        case HSA_API_ENTRYPOINT__DEST_ENTRY_GET_SDS_INPUT_TYPE:

            HSA_Navigation__ulwDestEntryGetSDSInputType();
            break;

        case HSA_API_ENTRYPOINT__TCU_JOURNEY_PREPARE_GUIDANCE:

            HSA_Navigation__vTCUJourneyPrepareGuidance();
            break;

        case HSA_API_ENTRYPOINT__TCU_JOURNEY_PREPARE_SHOW_ON_MAP:

            HSA_Navigation__vTcuJourneyPrepareShowOnMap();
            break;

        case HSA_API_ENTRYPOINT__SET_TCU_MODE_ACTIVE:

            HSA_Navigation__vSetTCUModeActive();
            break;

        case HSA_API_ENTRYPOINT__GET_SELECTED_POI_CATEGORY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Navigation__vGetSelectedPoiCategory(&gsParam1);
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

