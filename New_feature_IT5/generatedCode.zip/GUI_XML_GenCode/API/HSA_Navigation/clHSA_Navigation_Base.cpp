/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_Navigation_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_Navigation/clHSA_Navigation_Base.h"

clHSA_Navigation_Base* clHSA_Navigation_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_Navigation_Base.cpp.trc.h"
#endif


/**
 * Method: vSetupToggleHighwayEntrancePictureState
  * To activate/deactivate Highway entrance/exit pictures on Map
  * NISSAN 2.0
 */
void clHSA_Navigation_Base::vSetupToggleHighwayEntrancePictureState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetupToggleHighwayEntrancePictureState not implemented"));
   
}

/**
 * Method: blSetupGetHighwayEntrancePictureState
  * Status of activated/deactivated Highway entrance/exit pictures on Map
  * NISSAN 2.0
 */
tbool clHSA_Navigation_Base::blSetupGetHighwayEntrancePictureState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blSetupGetHighwayEntrancePictureState not implemented"));
   return 0;
}

/**
 * Method: blSetupGetSpeedLimit
  * Status of activated/deactivated SpeedLimit display on Map
  * NISSAN 2.0
 */
tbool clHSA_Navigation_Base::blSetupGetSpeedLimit( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blSetupGetSpeedLimit not implemented"));
   return 0;
}

/**
 * Method: vSetupSetSpeedLimit
  * To activate/deactivate SpeedLimit display on Map
  * NISSAN 2.0
 */
void clHSA_Navigation_Base::vSetupSetSpeedLimit(tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetupSetSpeedLimit not implemented"));
   
}

/**
 * Method: vRequestNAVTEQFilename
  * Request the name of NAVTEQ preloaded POI file from FFS
  * NISSAN 1.5
 */
void clHSA_Navigation_Base::vRequestNAVTEQFilename( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRequestNAVTEQFilename not implemented"));
   
}

/**
 * Method: vGetNAVTEQFilename
  * Get the file name of NAVTEQ preloaded POI file from FFS
  * NISSAN 1.5
 */
void clHSA_Navigation_Base::vGetNAVTEQFilename(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetNAVTEQFilename not implemented"));
   
}

/**
 * Method: vGetNAVTEQCheckDigit
  * Get the NAVTEQ Check Digit number 
  * NISSAN 1.5
 */
void clHSA_Navigation_Base::vGetNAVTEQCheckDigit(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetNAVTEQCheckDigit not implemented"));
   
}

/**
 * Method: vSetDemoPositionFromMapInput
  * Indicates that the map input postion is in relation to demo mode start position.
  * NISSAN UP2
 */
void clHSA_Navigation_Base::vSetDemoPositionFromMapInput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetDemoPositionFromMapInput not implemented"));
   
}

/**
 * Method: vMapInputSave_Home
  * Saves the actual map input location as home destination under the name given as input string
  * NISSAN
 */
void clHSA_Navigation_Base::vMapInputSave_Home(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMapInputSave_Home not implemented"));
   
}

/**
 * Method: vStoreCurrPositionAsWayPoint
  * Saves the Current Position as Waypointt under the name given as input string
  * NISSAN
 */
void clHSA_Navigation_Base::vStoreCurrPositionAsWayPoint(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vStoreCurrPositionAsWayPoint not implemented"));
   
}

/**
 * Method: vPOISearchNearByFoodStart_NAR
  * starts POI-search for near by food 
  * NISSAN_NAR
 */
void clHSA_Navigation_Base::vPOISearchNearByFoodStart_NAR( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchNearByFoodStart_NAR not implemented"));
   
}

/**
 * Method: vPOISearchNearbyATMStart
  * starts POI-search for near by ATMs 
  * NISSAN
 */
void clHSA_Navigation_Base::vPOISearchNearbyATMStart( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchNearbyATMStart not implemented"));
   
}

/**
 * Method: vStoreCurrentDestAsWayPoint
  * Stores current destination as waypoint
  * NISSAN
 */
void clHSA_Navigation_Base::vStoreCurrentDestAsWayPoint( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vStoreCurrentDestAsWayPoint not implemented"));
   
}

/**
 * Method: vStoreCurDestAsWayPoint
  * Stores the current destination chosen from the waypointlist as waypoint
  * NISSAN
 */
void clHSA_Navigation_Base::vStoreCurDestAsWayPoint(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vStoreCurDestAsWayPoint not implemented"));
   
}

/**
 * Method: vGetSkippedWaypointName
  * Returns the short name of Destination that will be skipped
  * NISSAN
 */
void clHSA_Navigation_Base::vGetSkippedWaypointName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetSkippedWaypointName not implemented"));
   
}

/**
 * Method: vSkipWaypointAndStartRouteGuidance
  * calculates the current route and start the guidance by skipping the non reachable waypoint
  * B1
 */
void clHSA_Navigation_Base::vSkipWaypointAndStartRouteGuidance( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vSkipWaypointAndStartRouteGuidance not implemented"));
   
}

/**
 * Method: vPOISelectByCategory_NAR
  * Prepare the system to select by category
  * NISSAN_NAR
 */
void clHSA_Navigation_Base::vPOISelectByCategory_NAR( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISelectByCategory_NAR not implemented"));
   
}

/**
 * Method: vPOIAlongRoutePrepareSearchEngine
  * Prepares the POIAlongRoute Search mechanism
  * NISSAN 2.0
 */
void clHSA_Navigation_Base::vPOIAlongRoutePrepareSearchEngine( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOIAlongRoutePrepareSearchEngine not implemented"));
   
}

/**
 * Method: vPoiSetCategoryAlongRoute
  * Prepare the system to set POI category along the route
  * NISSAN 2.0
 */
void clHSA_Navigation_Base::vPoiSetCategoryAlongRoute(ulword ulwCategoryNo)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCategoryNo);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vPoiSetCategoryAlongRoute not implemented"));
   
}

/**
 * Method: ulwIsListPrepared_NAR
  * Gives the type of list prepared
  * NISSAN_NAR
 */
ulword clHSA_Navigation_Base::ulwIsListPrepared_NAR( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwIsListPrepared_NAR not implemented"));
   return 0;
}

/**
 * Method: vGetPOICategoryList_NAR
  * Get the entries for showing the list
  * NISSAN_NAR
 */
void clHSA_Navigation_Base::vGetPOICategoryList_NAR(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetPOICategoryList_NAR not implemented"));
   
}

/**
 * Method: vSaveHouseNo_NAR
  * Saves the house number and refines for street speller
  * NISSAN
 */
void clHSA_Navigation_Base::vSaveHouseNo_NAR(ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSaveHouseNo_NAR not implemented"));
   
}

/**
 * Method: vGetCurrentCountryCarPlate
  *  The user sees the car plate as Country name.
  * NISSAN
 */
void clHSA_Navigation_Base::vGetCurrentCountryCarPlate(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetCurrentCountryCarPlate not implemented"));
   
}

/**
 * Method: vInitializeSpeedProfile
  *  This function is used to initialize the speed profile values
  * NISSAN 1.5
 */
void clHSA_Navigation_Base::vInitializeSpeedProfile( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vInitializeSpeedProfile not implemented"));
   
}

/**
 * Method: vToggleUserSpeedProfile
  *  Toggle the speed profile setting 0 for off, 1 for on
  * NISSAN 1.5
 */
void clHSA_Navigation_Base::vToggleUserSpeedProfile( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vToggleUserSpeedProfile not implemented"));
   
}

/**
 * Method: blIsUserSpeedProfileOn
  *  Get state of speed profile setting 
  * NISSAN 1.5
 */
tbool clHSA_Navigation_Base::blIsUserSpeedProfileOn( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsUserSpeedProfileOn not implemented"));
   return 0;
}

/**
 * Method: vSetSpeedProfile
  * Setting value for speed profile
  * NISSAN 1.5
 */
void clHSA_Navigation_Base::vSetSpeedProfile(ulword ulwSpeedProfile, tbool blSpeedProfileDirection)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSpeedProfile);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blSpeedProfileDirection);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetSpeedProfile not implemented"));
   
}

/**
 * Method: vGetSpeedProfile
  * Get the speed profile for Motorway, Major roads, Local Roads
  * NISSAN 1.5
 */
void clHSA_Navigation_Base::vGetSpeedProfile(GUI_String *out_result, ulword ulwSpeedProfile)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSpeedProfile);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetSpeedProfile not implemented"));
   
}

/**
 * Method: vConfirmSpeedProfile
  *  Confirm speed profile setting to HMI Navi server
  * NISSAN 1.5
 */
void clHSA_Navigation_Base::vConfirmSpeedProfile( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vConfirmSpeedProfile not implemented"));
   
}

/**
 * Method: vGetLanguageDependentStrings
  * returns value of the data requested
  * NISSAN
 */
void clHSA_Navigation_Base::vGetLanguageDependentStrings(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetLanguageDependentStrings not implemented"));
   
}

/**
 * Method: blIsLIMServiceAvailable
  * Checks if for LOCATION INPUT service is available
  * NISSAN
 */
tbool clHSA_Navigation_Base::blIsLIMServiceAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsLIMServiceAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentCountryIndex
  * Returns the index of the current country in the country list
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetCurrentCountryIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetCurrentCountryIndex not implemented"));
   return 0;
}

/**
 * Method: vSDGetInfo
  * Gets detailed information about the SD database
  * NISSAN
 */
void clHSA_Navigation_Base::vSDGetInfo(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSDGetInfo not implemented"));
   
}

/**
 * Method: vMapInputPrepareSaving
  * offers the blob data information of MapDestFlag in DPNAVI_CURR_DEST_DESCRIPTOR
  * NISSAN
 */
void clHSA_Navigation_Base::vMapInputPrepareSaving( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vMapInputPrepareSaving not implemented"));
   
}

/**
 * Method: vMapInputGetNameForDestIdent
  * Gets a name proposal to be displayed in speller line
  * NISSAN
 */
void clHSA_Navigation_Base::vMapInputGetNameForDestIdent(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMapInputGetNameForDestIdent not implemented"));
   
}

/**
 * Method: vDestEntrySave
  * saves the destination data to the new entered name to the selected memory.
  * NISSAN
 */
void clHSA_Navigation_Base::vDestEntrySave(ulword ulwSave)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSave);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntrySave not implemented"));
   
}

/**
 * Method: vUPSGetSelectedPOI
  * USERPOI Related; gets the name of the POI for proximity warning
  * NISSAN
 */
void clHSA_Navigation_Base::vUPSGetSelectedPOI(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vUPSGetSelectedPOI not implemented"));
   
}

/**
 * Method: vUPSPOIPrepareGuidanceFromDetails
  * prepares the selected entry for starting the guidance
  * NISSAN
 */
void clHSA_Navigation_Base::vUPSPOIPrepareGuidanceFromDetails( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vUPSPOIPrepareGuidanceFromDetails not implemented"));
   
}

/**
 * Method: blIsUPSCategoryPrepared
  * checks if category list is prepared
  * NISSAN
 */
tbool clHSA_Navigation_Base::blIsUPSCategoryPrepared( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsUPSCategoryPrepared not implemented"));
   return 0;
}

/**
 * Method: blOnUPSDataUpdate
  * dummy bool function for new POI event
  * NISSAN
 */
tbool clHSA_Navigation_Base::blOnUPSDataUpdate( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blOnUPSDataUpdate not implemented"));
   return 0;
}

/**
 * Method: blIsUPSPOIListPrepared
  * checks if POI list is prepared
  * NISSAN
 */
tbool clHSA_Navigation_Base::blIsUPSPOIListPrepared( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsUPSPOIListPrepared not implemented"));
   return 0;
}

/**
 * Method: ulwGetUPSDistance
  * Returns the current distance set by the user
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetUPSDistance( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetUPSDistance not implemented"));
   return 0;
}

/**
 * Method: ulwGetPOIProximityWarning
  * Returns the current proximity off/on/on+beep set by the user
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetPOIProximityWarning( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetPOIProximityWarning not implemented"));
   return 0;
}

/**
 * Method: vGetUPSPOIDetail
  * POI related details
  * NISSAN
 */
void clHSA_Navigation_Base::vGetUPSPOIDetail(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetUPSPOIDetail not implemented"));
   
}

/**
 * Method: vFlagEntryPrepareSaving
  * Indicate to Prepare to store of Flagdata into favourite list
  * NISSAN
 */
void clHSA_Navigation_Base::vFlagEntryPrepareSaving( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vFlagEntryPrepareSaving not implemented"));
   
}

/**
 * Method: vFlagEntrySave
  * Indicate to store the flag data into Favourite List
  * NISSAN
 */
void clHSA_Navigation_Base::vFlagEntrySave( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vFlagEntrySave not implemented"));
   
}

/**
 * Method: blIsCategoryRestorePossible
  * checks if the category screen is available on back button
  * NISSAN
 */
tbool clHSA_Navigation_Base::blIsCategoryRestorePossible( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsCategoryRestorePossible not implemented"));
   return 0;
}

/**
 * Method: vRestoreCategory
  * Restore the category on back button
  * NISSAN
 */
void clHSA_Navigation_Base::vRestoreCategory( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRestoreCategory not implemented"));
   
}

/**
 * Method: ulwGetUPSProximityWarning
  * sets the distance for proximity warnings
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetUPSProximityWarning( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetUPSProximityWarning not implemented"));
   return 0;
}

/**
 * Method: vToggleSetPOIProximityWarning
  * Toggle POI Warning: 0 for off, 1 for on, 2 for on+beep 
  * NISSAN
 */
void clHSA_Navigation_Base::vToggleSetPOIProximityWarning( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vToggleSetPOIProximityWarning not implemented"));
   
}

/**
 * Method: vDeleteUPS
  * delete the user pois in the USB
  * NISSAN
 */
void clHSA_Navigation_Base::vDeleteUPS( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vDeleteUPS not implemented"));
   
}

/**
 * Method: ulwUPSDeleteState
  * returns the state of user poi delete
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwUPSDeleteState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwUPSDeleteState not implemented"));
   return 0;
}

/**
 * Method: vSetUPSDistance
  * sets the distance for proximity warnings
  * NISSAN
 */
void clHSA_Navigation_Base::vSetUPSDistance(ulword ulwState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetUPSDistance not implemented"));
   
}

/**
 * Method: ulwGetTravelAdvantageValues
  * Returns the Travel Time Advantage on new route as well as time delay on current route
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetTravelAdvantageValues(ulword ulwRouteType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRouteType);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetTravelAdvantageValues not implemented"));
   return 0;
}

/**
 * Method: vDynRouteConsiderUpdate
  * Determines whether to stay on the old route or Consider New Route
  * NISSAN
 */
void clHSA_Navigation_Base::vDynRouteConsiderUpdate(ulword ulwRouteType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRouteType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDynRouteConsiderUpdate not implemented"));
   
}

/**
 * Method: vGetCurrentCode
  * CyrillicSpeller related gets the country name
  * NISSAN
 */
void clHSA_Navigation_Base::vGetCurrentCode(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetCurrentCode not implemented"));
   
}

/**
 * Method: blIsUPSDataAvailableInSystem
  * checks if data is already available in the system
  * NISSAN
 */
tbool clHSA_Navigation_Base::blIsUPSDataAvailableInSystem( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsUPSDataAvailableInSystem not implemented"));
   return 0;
}

/**
 * Method: vStartListCategory
  * Start listing categories from the FFS
  * NISSAN
 */
void clHSA_Navigation_Base::vStartListCategory( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vStartListCategory not implemented"));
   
}

/**
 * Method: blIsUPSDataAvailable
  * USERPOI Related; checks if UPS data is already available in the USB
  * NISSAN
 */
tbool clHSA_Navigation_Base::blIsUPSDataAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsUPSDataAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwGetUPSDownloadProgress
  * USERPOI Related; gets the value of progress of downloading the userpois to SD
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetUPSDownloadProgress( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetUPSDownloadProgress not implemented"));
   return 0;
}

/**
 * Method: ulwGetUPSDownloadState
  * USERPOI Related; gets the value of download state
  * NISSAN 1.5
 */
ulword clHSA_Navigation_Base::ulwGetUPSDownloadState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetUPSDownloadState not implemented"));
   return 0;
}

/**
 * Method: vStopUPSDownload
  * USERPOI Related; cancels tthe download of UPS onto USB
  * NISSAN
 */
void clHSA_Navigation_Base::vStopUPSDownload( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vStopUPSDownload not implemented"));
   
}

/**
 * Method: vStartUPSDownload
  * USERPOI Related; Start tthe download of UPS onto USB
  * NISSAN
 */
void clHSA_Navigation_Base::vStartUPSDownload( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vStartUPSDownload not implemented"));
   
}

/**
 * Method: vToggleLaneInformation
  * Toggle the Lane Information setting 0 for off, 1 for on 
  * Nissan 2.0
 */
void clHSA_Navigation_Base::vToggleLaneInformation( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vToggleLaneInformation not implemented"));
   
}

/**
 * Method: blSetupGetLaneGuidanceSymbolsState
  * Returns whether the lane guidance option in the map is turned on or off (the lane guidance symbols are displayed in the map screen or not).
  * 
 */
tbool clHSA_Navigation_Base::blSetupGetLaneGuidanceSymbolsState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blSetupGetLaneGuidanceSymbolsState not implemented"));
   return 0;
}

/**
 * Method: ulwGetUPSCategoryCount
  * USERPOI Related; get count of categories available
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetUPSCategoryCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetUPSCategoryCount not implemented"));
   return 0;
}

/**
 * Method: vGetUPSCategoryList
  * USERPOI Related; gets the entries of the category list
  * NISSAN
 */
void clHSA_Navigation_Base::vGetUPSCategoryList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetUPSCategoryList not implemented"));
   
}

/**
 * Method: vUPSSetCategory
  * USERPOI Related; selects a category from the list
  * NISSAN
 */
void clHSA_Navigation_Base::vUPSSetCategory(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vUPSSetCategory not implemented"));
   
}

/**
 * Method: ulwGetUPSPOICount
  * USERPOI Related; get count of categories available
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetUPSPOICount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetUPSPOICount not implemented"));
   return 0;
}

/**
 * Method: vGetUPSPOIList
  * USERPOI Related; gets the entries of the category list
  * NISSAN
 */
void clHSA_Navigation_Base::vGetUPSPOIList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetUPSPOIList not implemented"));
   
}

/**
 * Method: vUPSGetSelectedCategory
  * USERPOI Related; gets the name of the selected category
  * NISSAN
 */
void clHSA_Navigation_Base::vUPSGetSelectedCategory(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vUPSGetSelectedCategory not implemented"));
   
}

/**
 * Method: vUPSGETDetails
  * USERPOI Related; selects an entry of the POI-Result-List to resolve extended information
  * NISSAN
 */
void clHSA_Navigation_Base::vUPSGETDetails(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vUPSGETDetails not implemented"));
   
}

/**
 * Method: ulwGetUPSERRORPOICount
  * get count of POI's which have the error 
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetUPSERRORPOICount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetUPSERRORPOICount not implemented"));
   return 0;
}

/**
 * Method: vGetUPSERRORList
  * gets the entries of the ERROR LIST
  * NISSAN
 */
void clHSA_Navigation_Base::vGetUPSERRORList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetUPSERRORList not implemented"));
   
}

/**
 * Method: vRepeatLastNavigationAnnouncement
  * Retriggers the last navigation announcement
  * B
 */
void clHSA_Navigation_Base::vRepeatLastNavigationAnnouncement( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRepeatLastNavigationAnnouncement not implemented"));
   
}

/**
 * Method: blCurrentCarPositionAvailable
  * Checks if a current car position is available
  * B1
 */
tbool clHSA_Navigation_Base::blCurrentCarPositionAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blCurrentCarPositionAvailable not implemented"));
   return 0;
}

/**
 * Method: blCurrentCarPositionValidOnMap
  * Checks if a current car position is valid for data carrier
  * B1
 */
tbool clHSA_Navigation_Base::blCurrentCarPositionValidOnMap( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blCurrentCarPositionValidOnMap not implemented"));
   return 0;
}

/**
 * Method: blComplexEntryDisclaimerSpeedThresholdAchieved
  * gives indication, whether the threshold to trigger the complex entry disclaimer is achieved or not
  * B
 */
tbool clHSA_Navigation_Base::blComplexEntryDisclaimerSpeedThresholdAchieved( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blComplexEntryDisclaimerSpeedThresholdAchieved not implemented"));
   return 0;
}

/**
 * Method: slwConvertToDynamicIndex_RouteManeuverList
  * used for the highly dynamic list
  * B
 */
slword clHSA_Navigation_Base::slwConvertToDynamicIndex_RouteManeuverList(ulword ulwUniqueId)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwUniqueId);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Navigation::slwConvertToDynamicIndex_RouteManeuverList not implemented"));
   return 0;
}

/**
 * Method: slwConvertToUniqueId_RouteManeuverList
  * used for the highly dynamic list
  * B
 */
slword clHSA_Navigation_Base::slwConvertToUniqueId_RouteManeuverList( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_Navigation::slwConvertToUniqueId_RouteManeuverList not implemented"));
   return 0;
}

/**
 * Method: blCurrentDestinationIsStartable
  * checks, if the current destination (or POI) is valid to start calculating the route checks the current destination (or POI).
  * B
 */
tbool clHSA_Navigation_Base::blCurrentDestinationIsStartable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blCurrentDestinationIsStartable not implemented"));
   return 0;
}

/**
 * Method: vDecreaseAnnounceVolume
  * decreases the volume of the navigation announcement
  * B1
 */
void clHSA_Navigation_Base::vDecreaseAnnounceVolume( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vDecreaseAnnounceVolume not implemented"));
   
}

/**
 * Method: vDeleteCurrentDestination
  * delete all information of the selected type about the current destination
  * B
 */
void clHSA_Navigation_Base::vDeleteCurrentDestination( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vDeleteCurrentDestination not implemented"));
   
}

/**
 * Method: blDemoStartLocationAvailable
  * Checks if a demo start location is available
  * B1
 */
tbool clHSA_Navigation_Base::blDemoStartLocationAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blDemoStartLocationAvailable not implemented"));
   return 0;
}

/**
 * Method: vDestEntryGetAddress
  * returns the current data for the navigation destination form address
  * B
 */
void clHSA_Navigation_Base::vDestEntryGetAddress(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryGetAddress not implemented"));
   
}

/**
 * Method: vDestEntryActivateNavDestFormItem
  * activates the corresponding item choosen in the navigation destination form
  * B
 */
void clHSA_Navigation_Base::vDestEntryActivateNavDestFormItem(ulword ulwItem)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwItem);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryActivateNavDestFormItem not implemented"));
   
}

/**
 * Method: vRestoreDestEntryActivateNavDestFormItem
  * Restore the corresponding navigation destination form item
  * B
 */
void clHSA_Navigation_Base::vRestoreDestEntryActivateNavDestFormItem(ulword ulwItem)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwItem);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRestoreDestEntryActivateNavDestFormItem not implemented"));
   
}

/**
 * Method: vDestEntryGetFavourite
  * returns the current data for the navigation destination form favourite
  * B
 */
void clHSA_Navigation_Base::vDestEntryGetFavourite(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryGetFavourite not implemented"));
   
}

/**
 * Method: vDestEntryGetPOI
  * returns the current data for the navigation destination form searchcenter poi 
  * B
 */
void clHSA_Navigation_Base::vDestEntryGetPOI(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryGetPOI not implemented"));
   
}

/**
 * Method: vDestEntryGetPOILastDest
  * returns the current data for the navigation destination form POI entry from last destination,(excluding the User Given Name)
  * MMS-230849
 */
void clHSA_Navigation_Base::vDestEntryGetPOILastDest(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryGetPOILastDest not implemented"));
   
}

/**
 * Method: vDestEntryGetHome
  * returns the current data for the navigation destination form home address
  * B
 */
void clHSA_Navigation_Base::vDestEntryGetHome(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryGetHome not implemented"));
   
}

/**
 * Method: vDestEntryGetGeoPos
  * returns the current data for the navigation destination geo position
  * B
 */
void clHSA_Navigation_Base::vDestEntryGetGeoPos(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryGetGeoPos not implemented"));
   
}

/**
 * Method: vDestEntryInit
  * Initializes a 'NewDest'-Object and copies the content of the current-destination
  * B
 */
void clHSA_Navigation_Base::vDestEntryInit( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryInit not implemented"));
   
}

/**
 * Method: vDestEntryInitWithCountry
  * Initializes a 'NewDest'-Object and copies the content of the current-destination, additionally restores the country
  * B
 */
void clHSA_Navigation_Base::vDestEntryInitWithCountry( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryInitWithCountry not implemented"));
   
}

/**
 * Method: blDestEntryIsValid
  * returns whether the 'NewDest'-Object is valid (able to guide) or not
  * B
 */
tbool clHSA_Navigation_Base::blDestEntryIsValid( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blDestEntryIsValid not implemented"));
   return 0;
}

/**
 * Method: blDestEntryGetHouseNumberAvailability
  * returns whether  the given house number exits
  * B
 */
tbool clHSA_Navigation_Base::blDestEntryGetHouseNumberAvailability( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blDestEntryGetHouseNumberAvailability not implemented"));
   return 0;
}

/**
 * Method: blDestMemDestEntryChanged
  * returns whether a dest entry item of the favourite entry is changed or not.
  * B
 */
tbool clHSA_Navigation_Base::blDestMemDestEntryChanged( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blDestMemDestEntryChanged not implemented"));
   return 0;
}

/**
 * Method: blIsDestinationOFFMap
  * returns whether a saved destination entry is off map or not
  * B
 */
tbool clHSA_Navigation_Base::blIsDestinationOFFMap( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsDestinationOFFMap not implemented"));
   return 0;
}

/**
 * Method: blGetRouteBlockSelection
  * returns whether a segment of the route list is selected for blockage
  * NISSAN_LCN2Kai
 */
tbool clHSA_Navigation_Base::blGetRouteBlockSelection( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blGetRouteBlockSelection not implemented"));
   return 0;
}

/**
 * Method: vDestEntryPrepareGuidance
  * prepares the selected entry for starting the guidance
  * B
 */
void clHSA_Navigation_Base::vDestEntryPrepareGuidance( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryPrepareGuidance not implemented"));
   
}

/**
 * Method: vDestEntryPrepareSaving
  * prepares the selected entry for saving it
  * B
 */
void clHSA_Navigation_Base::vDestEntryPrepareSaving( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryPrepareSaving not implemented"));
   
}

/**
 * Method: vDestEntryRenameFavorite
  * renames the favorite.
  * B
 */
void clHSA_Navigation_Base::vDestEntryRenameFavorite( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryRenameFavorite not implemented"));
   
}

/**
 * Method: vDestEntrySelectAddr
  * to select the specified address entry for displaying in navigation destination form
  * B
 */
void clHSA_Navigation_Base::vDestEntrySelectAddr(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntrySelectAddr not implemented"));
   
}

/**
 * Method: vDestentrySelectWayPoint
  * to select the specified address entry for displaying in navigation destination form
  * B
 */
void clHSA_Navigation_Base::vDestentrySelectWayPoint(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestentrySelectWayPoint not implemented"));
   
}

/**
 * Method: vDestEntrySetData
  * sets new data/input of the 'NewDest'-Object of the selected type
  * B
 */
void clHSA_Navigation_Base::vDestEntrySetData(ulword ulwType, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntrySetData not implemented"));
   
}

/**
 * Method: vDestEntrySetDataCityToCityCenter
  * sets the city input data to the city center destination input item
  * B
 */
void clHSA_Navigation_Base::vDestEntrySetDataCityToCityCenter( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntrySetDataCityToCityCenter not implemented"));
   
}

/**
 * Method: vDestEntryGetDataShort
  * information about the current activated dest entry item of the corresponding nav dest form item
  * B
 */
void clHSA_Navigation_Base::vDestEntryGetDataShort(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryGetDataShort not implemented"));
   
}

/**
 * Method: blDestEntryCategoryIsPossible
  * returns whether the  destentry of the index categories is valid or not
  * B
 */
tbool clHSA_Navigation_Base::blDestEntryCategoryIsPossible(ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blDestEntryCategoryIsPossible not implemented"));
   return 0;
}

/**
 * Method: vFlagDestGetName
  * returns the name of the flag-dest. returns an empty string if flagdest was not set
  * B-deprecated
 */
void clHSA_Navigation_Base::vFlagDestGetName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vFlagDestGetName not implemented"));
   
}

/**
 * Method: vFlagDestSave
  * saves the current car-position as flagdest and take the input string as stored name.
  * B
 */
void clHSA_Navigation_Base::vFlagDestSave(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vFlagDestSave not implemented"));
   
}

/**
 * Method: ulwFlagDestSaveState
  * returns  the state of saving of a flag destination into favourites list 
  * B
 */
ulword clHSA_Navigation_Base::ulwFlagDestSaveState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwFlagDestSaveState not implemented"));
   return 0;
}

/**
 * Method: ulwGetActiveAverageSpeed
  * returns the current setting of average speed in
  * B
 */
ulword clHSA_Navigation_Base::ulwGetActiveAverageSpeed( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetActiveAverageSpeed not implemented"));
   return 0;
}

/**
 * Method: blGetCalcRouteFails
  * returns if Route-Calculation fails or not
  * B1
 */
tbool clHSA_Navigation_Base::blGetCalcRouteFails( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blGetCalcRouteFails not implemented"));
   return 0;
}

/**
 * Method: ulwGetCalcRouteIsRunning
  * returns if Route-Calculation is running or not
  * B1
 */
ulword clHSA_Navigation_Base::ulwGetCalcRouteIsRunning( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetCalcRouteIsRunning not implemented"));
   return 0;
}

/**
 * Method: ulwGetCalcRouteProgress
  * gets the value of progress of calculating the route in percent
  * B1
 */
ulword clHSA_Navigation_Base::ulwGetCalcRouteProgress( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetCalcRouteProgress not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentDestination
  * gets detailed information of the selected type about the current destination
  * B
 */
void clHSA_Navigation_Base::vGetCurrentDestination(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetCurrentDestination not implemented"));
   
}

/**
 * Method: vGetCurrentDestinationData
  * gets with newlines formatted short information about the current destination (Not the currently entered od edited)
  * B
 */
void clHSA_Navigation_Base::vGetCurrentDestinationData(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetCurrentDestinationData not implemented"));
   
}

/**
 * Method: vGetCurrentDestinationDetail
  * detailed information on the current destination 
  * B1
 */
void clHSA_Navigation_Base::vGetCurrentDestinationDetail(GUI_String *out_result, ulword ulwDetail)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDetail);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetCurrentDestinationDetail not implemented"));
   
}

/**
 * Method: vGetCurrentWaypointForSave
  * gets the short name of the waypoint to be stored
  * LCN2Kai
 */
void clHSA_Navigation_Base::vGetCurrentWaypointForSave(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetCurrentWaypointForSave not implemented"));
   
}

/**
 * Method: vGetCurrentDestinationShort
  * gets a short information about the current destination (Not the currently entered od edited)
  * B
 */
void clHSA_Navigation_Base::vGetCurrentDestinationShort(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetCurrentDestinationShort not implemented"));
   
}

/**
 * Method: vGetCurrentIntDestDetail
  * detailed information on the intermediate destination 
  * B
 */
void clHSA_Navigation_Base::vGetCurrentIntDestDetail(GUI_String *out_result, ulword ulwDetail)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDetail);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetCurrentIntDestDetail not implemented"));
   
}

/**
 * Method: vSetDisambiguationCityCenterItem
  * sets the corresponding entry of the disambiguation list
  * B
 */
void clHSA_Navigation_Base::vSetDisambiguationCityCenterItem(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetDisambiguationCityCenterItem not implemented"));
   
}

/**
 * Method: vGetDisambiguationCityCenterList
  * gets the entries of the City center disambiguation list
  * B
 */
void clHSA_Navigation_Base::vGetDisambiguationCityCenterList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetDisambiguationCityCenterList not implemented"));
   
}

/**
 * Method: ulwGetDisambiguationCityCenterItemCount
  * get count of disambiguation city center items
  * B
 */
ulword clHSA_Navigation_Base::ulwGetDisambiguationCityCenterItemCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetDisambiguationCityCenterItemCount not implemented"));
   return 0;
}

/**
 * Method: vGetDisambiguationList
  * gets the entries of the disambiguation list
  * B
 */
void clHSA_Navigation_Base::vGetDisambiguationList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetDisambiguationList not implemented"));
   
}

/**
 * Method: vSetDisambiguationItem
  * sets the corresponding entries of the disambiguation list
  * B
 */
void clHSA_Navigation_Base::vSetDisambiguationItem(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetDisambiguationItem not implemented"));
   
}

/**
 * Method: ulwGetDisambiguationItemCount
  * get count of disambiguation items
  * B
 */
ulword clHSA_Navigation_Base::ulwGetDisambiguationItemCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetDisambiguationItemCount not implemented"));
   return 0;
}

/**
 * Method: ulwGetGuidanceState
  * Returns wether navi is currently guiding or not
  * B1
 */
ulword clHSA_Navigation_Base::ulwGetGuidanceState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetGuidanceState not implemented"));
   return 0;
}

/**
 * Method: ulwGetIntermediateDestinationGuidanceState
  * Returns wether navi is currently guiding with a intermediate destination
  * B
 */
ulword clHSA_Navigation_Base::ulwGetIntermediateDestinationGuidanceState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetIntermediateDestinationGuidanceState not implemented"));
   return 0;
}

/**
 * Method: vSetLastGuidanceState
  * sets the last guidance state
  * B
 */
void clHSA_Navigation_Base::vSetLastGuidanceState(ulword ulwState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetLastGuidanceState not implemented"));
   
}

/**
 * Method: vRestartRouteGuidance
  * Restarts the route guidance
  * B
 */
void clHSA_Navigation_Base::vRestartRouteGuidance( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRestartRouteGuidance not implemented"));
   
}

/**
 * Method: blGetLastGuidanceState
  * Returns wether the navigation is guiding or not before Clamp 15 off.
  * B
 */
tbool clHSA_Navigation_Base::blGetLastGuidanceState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blGetLastGuidanceState not implemented"));
   return 0;
}

/**
 * Method: vGetPositionDataDetail
  * Gets detailed information about the current position
  * B1
 */
void clHSA_Navigation_Base::vGetPositionDataDetail(GUI_String *out_result, ulword ulwDetail)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDetail);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetPositionDataDetail not implemented"));
   
}

/**
 * Method: vGetPositionDataShort
  * Gets information about the current position in a very short description
  * B
 */
void clHSA_Navigation_Base::vGetPositionDataShort(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetPositionDataShort not implemented"));
   
}

/**
 * Method: blGetTemporaryMode
  * returns wheater the next Guidance that will be started is in DemoMode or not
  * B
 */
tbool clHSA_Navigation_Base::blGetTemporaryMode( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blGetTemporaryMode not implemented"));
   return 0;
}

/**
 * Method: vHomeDestGetDataShort
  * returns information about home-destination entry. 
  * NISSAN
 */
void clHSA_Navigation_Base::vHomeDestGetDataShort(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vHomeDestGetDataShort not implemented"));
   
}

/**
 * Method: blHomeDestIsGeoPos
  * returns whether the underlied home-destination information are defined as regular destination entries or as geo coordinates with latitude and longitude indications
  * NISSAN
 */
tbool clHSA_Navigation_Base::blHomeDestIsGeoPos( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blHomeDestIsGeoPos not implemented"));
   return 0;
}

/**
 * Method: vHomeDestInit
  * Initializes a '#'-Object an copies the content of the current-homedest or predefines all entries of the  'NewDest'-Object 
  * B
 */
void clHSA_Navigation_Base::vHomeDestInit( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vHomeDestInit not implemented"));
   
}

/**
 * Method: blHomeDestIsDefined
  * returns whether a home-destination is defined or not
  * B
 */
tbool clHSA_Navigation_Base::blHomeDestIsDefined( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blHomeDestIsDefined not implemented"));
   return 0;
}

/**
 * Method: vHomeSaveCCP
  * save the current car position as new home destination
  * B
 */
void clHSA_Navigation_Base::vHomeSaveCCP(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vHomeSaveCCP not implemented"));
   
}

/**
 * Method: vDestEntrySave_Home
  * Saves the home destination under the name given as input string
  * NISSAN
 */
void clHSA_Navigation_Base::vDestEntrySave_Home(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntrySave_Home not implemented"));
   
}

/**
 * Method: vStoreMainDestination
  * Store the Main Destination
  * NISSAN
 */
void clHSA_Navigation_Base::vStoreMainDestination( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vStoreMainDestination not implemented"));
   
}

/**
 * Method: vStoreCurDestFromWaypointList
  * Store the Current destination from the waypoint list
  * NISSAN
 */
void clHSA_Navigation_Base::vStoreCurDestFromWaypointList(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vStoreCurDestFromWaypointList not implemented"));
   
}

/**
 * Method: vHomePrepareGuidance
  * prepares the home entry for starting the guidance
  * B
 */
void clHSA_Navigation_Base::vHomePrepareGuidance( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vHomePrepareGuidance not implemented"));
   
}

/**
 * Method: vHomeCheckAvailability
  * trigger a check for the home destination availability
  * B
 */
void clHSA_Navigation_Base::vHomeCheckAvailability( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vHomeCheckAvailability not implemented"));
   
}

/**
 * Method: vIncreaseAnnounceVolume
  * increases the volume of the navigation announcement
  * B1
 */
void clHSA_Navigation_Base::vIncreaseAnnounceVolume( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vIncreaseAnnounceVolume not implemented"));
   
}

/**
 * Method: vInit
  * Initializes the device
  * B1
 */
void clHSA_Navigation_Base::vInit( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vInit not implemented"));
   
}

/**
 * Method: vIntDestDeleteIntermediate
  * Deletes the intermediate destination for route guidance
  * B
 */
void clHSA_Navigation_Base::vIntDestDeleteIntermediate( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vIntDestDeleteIntermediate not implemented"));
   
}

/**
 * Method: vIntDestReplaceMainDest
  * Sets a new main destination and replace therefore the old one
  * B
 */
void clHSA_Navigation_Base::vIntDestReplaceMainDest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vIntDestReplaceMainDest not implemented"));
   
}

/**
 * Method: vIntDestInsertIntermediate
  * Insert a intermediate destination and keeps the current main destination
  * B
 */
void clHSA_Navigation_Base::vIntDestInsertIntermediate( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vIntDestInsertIntermediate not implemented"));
   
}

/**
 * Method: vIntDestReplaceIntermediate
  * Keeps the current main destination and replace the old intermediate destination with the new desitnation
  * B
 */
void clHSA_Navigation_Base::vIntDestReplaceIntermediate( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vIntDestReplaceIntermediate not implemented"));
   
}

/**
 * Method: blIsAvailableStreetsInCity
  * checks if at least one street is available for the currently selected city
  * B
 */
tbool clHSA_Navigation_Base::blIsAvailableStreetsInCity( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsAvailableStreetsInCity not implemented"));
   return 0;
}

/**
 * Method: blIsDestinationUnique
  * Checks if the destination is unique
  * B
 */
tbool clHSA_Navigation_Base::blIsDestinationUnique( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsDestinationUnique not implemented"));
   return 0;
}

/**
 * Method: blIsHNDefined
  * Checks if for the given street is a house number available
  * B
 */
tbool clHSA_Navigation_Base::blIsHNDefined( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsHNDefined not implemented"));
   return 0;
}

/**
 * Method: blIsCrossingAvailable
  * Checks if for the given street is a crossing available
  * B
 */
tbool clHSA_Navigation_Base::blIsCrossingAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsCrossingAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsHouseNumberUnique
  * checks if the given house number is unique
  * B
 */
tbool clHSA_Navigation_Base::blIsHouseNumberUnique( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsHouseNumberUnique not implemented"));
   return 0;
}

/**
 * Method: blIsCityCenterUnique
  * checks if the given city center is unique
  * B
 */
tbool clHSA_Navigation_Base::blIsCityCenterUnique( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsCityCenterUnique not implemented"));
   return 0;
}

/**
 * Method: ulwIsInitialized
  * checks if the navigation-device is initialized
  * B1
 */
ulword clHSA_Navigation_Base::ulwIsInitialized( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwIsInitialized not implemented"));
   return 0;
}

/**
 * Method: ulwIsDataAvailable
  * checks if a navigation database carrier is available (sd card and cd)
  * B
 */
ulword clHSA_Navigation_Base::ulwIsDataAvailable( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwIsDataAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsNaviDataAvailable
  * Returns whether the selected source contains navi data
  * B1
 */
tbool clHSA_Navigation_Base::blIsNaviDataAvailable(ulword ulwSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSource);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsNaviDataAvailable not implemented"));
   return 0;
}

/**
 * Method: vLastCurrentDestPrepareGuidance
  * To restart guidance with the last current destination
  * B
 */
void clHSA_Navigation_Base::vLastCurrentDestPrepareGuidance( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vLastCurrentDestPrepareGuidance not implemented"));
   
}

/**
 * Method: ulwMemoryClearState
  * Returns whether progress of clearing the memory is finished
  * B
 */
ulword clHSA_Navigation_Base::ulwMemoryClearState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwMemoryClearState not implemented"));
   return 0;
}

/**
 * Method: ulwMemoryEntryType
  * Returns whether the memory entry is a regular navigation destination form item given in the last destination list, POI defined entry, flag dest entry, a home address dest, a geopos item, geopos stored item or a regular item in the favourites list. 
  * B
 */
ulword clHSA_Navigation_Base::ulwMemoryEntryType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwMemoryEntryType not implemented"));
   return 0;
}

/**
 * Method: ulwWaypointMemoryEntryType
  * Returns whether the memory entry is a regular navigation destination form item given in the last destination list, POI defined entry, flag dest entry, a home address dest, a geopos item, geopos stored item or a regular item in the favourites list. 
  * B
 */
ulword clHSA_Navigation_Base::ulwWaypointMemoryEntryType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwWaypointMemoryEntryType not implemented"));
   return 0;
}

/**
 * Method: ulwGetSelectedWaypointIndex
  * Returns the index+1 of the selected waypoint  
  * B
 */
ulword clHSA_Navigation_Base::ulwGetSelectedWaypointIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetSelectedWaypointIndex not implemented"));
   return 0;
}

/**
 * Method: ulwMemoryIntDestEntryType
  * Returns whether the memory intermediate destination entry is a regular navigation destination formual item, POI defined entry, flag dest entry, a home address dest, geopos item, geopos stored item.
  * B
 */
ulword clHSA_Navigation_Base::ulwMemoryIntDestEntryType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwMemoryIntDestEntryType not implemented"));
   return 0;
}

/**
 * Method: vMemoryDestMemClear
  * clears all entries in the destination memory
  * B
 */
void clHSA_Navigation_Base::vMemoryDestMemClear(ulword ulwSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSource);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryDestMemClear not implemented"));
   
}

/**
 * Method: blMemoryDestMemExistsName
  * returns whether entry of spellerinputeditname is unique
  * B
 */
tbool clHSA_Navigation_Base::blMemoryDestMemExistsName( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blMemoryDestMemExistsName not implemented"));
   return 0;
}

/**
 * Method: vMemoryDestMemGetList
  * requested item of the dest-mem-list, the string contains a device dependent type of string
  * B1
 */
void clHSA_Navigation_Base::vMemoryDestMemGetList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryDestMemGetList not implemented"));
   
}

/**
 * Method: ulwMemoryDestMemGetListCount
  * get count of items
  * B1
 */
ulword clHSA_Navigation_Base::ulwMemoryDestMemGetListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwMemoryDestMemGetListCount not implemented"));
   return 0;
}

/**
 * Method: vMemoryDestMemInputFilterString
  * addes a search-string to the speller-object, prefetches the resultlist, prefetches the result-count
  * B
 */
void clHSA_Navigation_Base::vMemoryDestMemInputFilterString(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryDestMemInputFilterString not implemented"));
   
}

/**
 * Method: blMemoryDestMemIsEmpty
  * returns whether the destination memory is empty or not
  * B
 */
tbool clHSA_Navigation_Base::blMemoryDestMemIsEmpty( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blMemoryDestMemIsEmpty not implemented"));
   return 0;
}

/**
 * Method: blMemoryDestMemIsFull
  * returns whether the destination memory is full or not
  * B
 */
tbool clHSA_Navigation_Base::blMemoryDestMemIsFull( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blMemoryDestMemIsFull not implemented"));
   return 0;
}

/**
 * Method: vMemoryDestMemPrepareGuidance
  * prepares the selected entry for starting the guidance
  * B1
 */
void clHSA_Navigation_Base::vMemoryDestMemPrepareGuidance(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryDestMemPrepareGuidance not implemented"));
   
}

/**
 * Method: vMemoryDestMemPrepareList
  * Prepares the Dest Mem (adress, favourite) List to show
  * B1
 */
void clHSA_Navigation_Base::vMemoryDestMemPrepareList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryDestMemPrepareList not implemented"));
   
}

/**
 * Method: vMemoryDestMemPrepareSearch
  * destination memory
  * B
 */
void clHSA_Navigation_Base::vMemoryDestMemPrepareSearch( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryDestMemPrepareSearch not implemented"));
   
}

/**
 * Method: vMemoryDestMemGetSearchList
  * requested item of the dest-mem-list, the string contains a device dependent type of string
  * B
 */
void clHSA_Navigation_Base::vMemoryDestMemGetSearchList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryDestMemGetSearchList not implemented"));
   
}

/**
 * Method: ulwMemoryDestMemGetSearchListCount
  * get count of favourites search list items
  * B
 */
ulword clHSA_Navigation_Base::ulwMemoryDestMemGetSearchListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwMemoryDestMemGetSearchListCount not implemented"));
   return 0;
}

/**
 * Method: vMemoryDestMemActivateSearch
  * count of favourites search list items
  * B
 */
void clHSA_Navigation_Base::vMemoryDestMemActivateSearch( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryDestMemActivateSearch not implemented"));
   
}

/**
 * Method: ulwMemoryDestMemSaveState
  * returns  the state of saving of a destination into favourites list 
  * B
 */
ulword clHSA_Navigation_Base::ulwMemoryDestMemSaveState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwMemoryDestMemSaveState not implemented"));
   return 0;
}

/**
 * Method: vMemoryDestMemGetInfoShort
  * information about the current selected entry, which should be stored dest-mem-list, as one short string.
  * B
 */
void clHSA_Navigation_Base::vMemoryDestMemGetInfoShort(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryDestMemGetInfoShort not implemented"));
   
}

/**
 * Method: ulwMemoryDestMemDeleteState
  * returns  the state of deleting a destination from the favourites list 
  * B
 */
ulword clHSA_Navigation_Base::ulwMemoryDestMemDeleteState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwMemoryDestMemDeleteState not implemented"));
   return 0;
}

/**
 * Method: vMemoryLastDestClear
  * clears all entries in the last dest memory
  * B
 */
void clHSA_Navigation_Base::vMemoryLastDestClear( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryLastDestClear not implemented"));
   
}

/**
 * Method: vMemoryLastDestGetInfo
  * information about the current selected entry of the last-dest-list
  * B
 */
void clHSA_Navigation_Base::vMemoryLastDestGetInfo(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryLastDestGetInfo not implemented"));
   
}

/**
 * Method: vMemoryLastDestGetInfoShort
  * information about the current selected entry of the last-dest-list-item as one short string
  * B
 */
void clHSA_Navigation_Base::vMemoryLastDestGetInfoShort(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryLastDestGetInfoShort not implemented"));
   
}

/**
 * Method: vMemoryLastDestGetList
  * requested item of the last-dest-list, the string contains a device dependent type of string
  * B
 */
void clHSA_Navigation_Base::vMemoryLastDestGetList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryLastDestGetList not implemented"));
   
}

/**
 * Method: ulwMemoryLastDestGetListCount
  * gets the count of items in the MemoryLastDestGetList-list
  * B
 */
ulword clHSA_Navigation_Base::ulwMemoryLastDestGetListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwMemoryLastDestGetListCount not implemented"));
   return 0;
}

/**
 * Method: blMemoryLastDestListEmpty
  * returns whether there were some last destinations saved or not
  * B
 */
tbool clHSA_Navigation_Base::blMemoryLastDestListEmpty( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blMemoryLastDestListEmpty not implemented"));
   return 0;
}

/**
 * Method: vMemoryLastDestPrepareGuidance
  * prepares the selected entry for starting the guidance
  * B
 */
void clHSA_Navigation_Base::vMemoryLastDestPrepareGuidance(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryLastDestPrepareGuidance not implemented"));
   
}

/**
 * Method: vMemoryLastDestSelectForSaving
  * select an item of the list and prepares it for saving into memory
  * B
 */
void clHSA_Navigation_Base::vMemoryLastDestSelectForSaving(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryLastDestSelectForSaving not implemented"));
   
}

/**
 * Method: vMemoryLastDestPrepareList
  * Prepares the Last Dest Mem list to show
  * B
 */
void clHSA_Navigation_Base::vMemoryLastDestPrepareList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryLastDestPrepareList not implemented"));
   
}

/**
 * Method: vHNMatchForReduction
  * Match the house number input to the given street
  * B
 */
void clHSA_Navigation_Base::vHNMatchForReduction( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vHNMatchForReduction not implemented"));
   
}

/**
 * Method: vPOIPrepareSearchEngine
  * Prepares the POI Search mechanism
  * B
 */
void clHSA_Navigation_Base::vPOIPrepareSearchEngine( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOIPrepareSearchEngine not implemented"));
   
}

/**
 * Method: ulwPOIGetResultCount
  * gets the number of items in the POI result list
  * B
 */
ulword clHSA_Navigation_Base::ulwPOIGetResultCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwPOIGetResultCount not implemented"));
   return 0;
}

/**
 * Method: blPOISearchIsAvailable
  * returns wether searching for POI's is possible or not
  * B
 */
tbool clHSA_Navigation_Base::blPOISearchIsAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blPOISearchIsAvailable not implemented"));
   return 0;
}

/**
 * Method: blPOISearchStringIsServiceable
  * returns wether the search string for POI's is serviceable or not
  * B
 */
tbool clHSA_Navigation_Base::blPOISearchStringIsServiceable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blPOISearchStringIsServiceable not implemented"));
   return 0;
}

/**
 * Method: vPOISearchParamSetCharacter
  * sets the character for POI-Name to search for when starting by POISearchStart
  * B-Not in use
 */
void clHSA_Navigation_Base::vPOISearchParamSetCharacter(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchParamSetCharacter not implemented"));
   
}

/**
 * Method: vGetPOISpellerSearchString
  * gets search string for POI-by name
  * B
 */
void clHSA_Navigation_Base::vGetPOISpellerSearchString(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetPOISpellerSearchString not implemented"));
   
}

/**
 * Method: vPOISearchParamSetCurrentCarPosition
  * activates searching parameter for POIs around the current car position
  * B
 */
void clHSA_Navigation_Base::vPOISearchParamSetCurrentCarPosition( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchParamSetCurrentCarPosition not implemented"));
   
}

/**
 * Method: vPOISearchParamSetLocation
  * activates searching parameter for POIs around the given location
  * B
 */
void clHSA_Navigation_Base::vPOISearchParamSetLocation( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchParamSetLocation not implemented"));
   
}

/**
 * Method: vPOISearchParamSetDestination
  * activates searching parameter for POIs around the current destination
  * B-Deprecated
 */
void clHSA_Navigation_Base::vPOISearchParamSetDestination( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchParamSetDestination not implemented"));
   
}

/**
 * Method: vPOISearchProgressGetRadius
  * returns the radius in which the poi's are going to be searched
  * B
 */
void clHSA_Navigation_Base::vPOISearchProgressGetRadius(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchProgressGetRadius not implemented"));
   
}

/**
 * Method: vSpellerGetPOISearchInput
  * Gets the input from the freetext speller in POI context.
  * B
 */
void clHSA_Navigation_Base::vSpellerGetPOISearchInput(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerGetPOISearchInput not implemented"));
   
}

/**
 * Method: vPOISelectForSaving
  * select an item of the list and prepares it for saving into memory
  * B
 */
void clHSA_Navigation_Base::vPOISelectForSaving(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISelectForSaving not implemented"));
   
}

/**
 * Method: vPOISelectForSavingFromDetail
  * select the item from the detail view and prepares it for saving into memory
  * B
 */
void clHSA_Navigation_Base::vPOISelectForSavingFromDetail( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISelectForSavingFromDetail not implemented"));
   
}

/**
 * Method: vPOITopSelectForSaving
  * select an item of the list and prepares it for saving into memory
  * B
 */
void clHSA_Navigation_Base::vPOITopSelectForSaving(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOITopSelectForSaving not implemented"));
   
}

/**
 * Method: vPOITopSelectForSavingFromDetail
  * select the item from the detail view and prepares it for saving into memory
  * B
 */
void clHSA_Navigation_Base::vPOITopSelectForSavingFromDetail( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOITopSelectForSavingFromDetail not implemented"));
   
}

/**
 * Method: ulwPOISearchResultCount
  * returns the number of found results after starting poi-search
  * B
 */
ulword clHSA_Navigation_Base::ulwPOISearchResultCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwPOISearchResultCount not implemented"));
   return 0;
}

/**
 * Method: vPOISearchResultGetListString
  * gets information about the found POI-entries
  * B
 */
void clHSA_Navigation_Base::vPOISearchResultGetListString(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCell);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchResultGetListString not implemented"));
   
}

/**
 * Method: ulwPOISearchResultGetListValue
  * Returns information about the direction and category of POIs
  * B
 */
ulword clHSA_Navigation_Base::ulwPOISearchResultGetListValue(ulword ulwCell, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCell);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwPOISearchResultGetListValue not implemented"));
   return 0;
}

/**
 * Method: vPOISearchResultGetSelectedData
  * gets detailed information about the selected POI-entry
  * B
 */
void clHSA_Navigation_Base::vPOISearchResultGetSelectedData(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchResultGetSelectedData not implemented"));
   
}

/**
 * Method: blPOISearchResultGetSelectedHasAdditionalInfo
  * Returns whether additional information of the selected POI-Result-Entry are availiable or not
  * B
 */
tbool clHSA_Navigation_Base::blPOISearchResultGetSelectedHasAdditionalInfo( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blPOISearchResultGetSelectedHasAdditionalInfo not implemented"));
   return 0;
}

/**
 * Method: vPOISearchResultListSelectForDetails
  * selects an entry of the POI-Result-List to resolve extended information
  * B
 */
void clHSA_Navigation_Base::vPOISearchResultListSelectForDetails(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchResultListSelectForDetails not implemented"));
   
}

/**
 * Method: ulwPOIGetCurrentDetailViewIndex
  * gets the last selected index for Detailed View in POI list
  * B
 */
ulword clHSA_Navigation_Base::ulwPOIGetCurrentDetailViewIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwPOIGetCurrentDetailViewIndex not implemented"));
   return 0;
}

/**
 * Method: vPOIPrepareGuidance
  * selects an entry of the POI-Result-List to prepare it for route guidance
  * B
 */
void clHSA_Navigation_Base::vPOIPrepareGuidance(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOIPrepareGuidance not implemented"));
   
}

/**
 * Method: vPOIPrepareGuidanceFromDetails
  * prepare a POI entry from detail view for route guidance
  * B
 */
void clHSA_Navigation_Base::vPOIPrepareGuidanceFromDetails( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOIPrepareGuidanceFromDetails not implemented"));
   
}

/**
 * Method: vPOITopPrepareGuidance
  * selects an entry of the POI Top-Result-List to prepare it for route guidance
  * B
 */
void clHSA_Navigation_Base::vPOITopPrepareGuidance(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOITopPrepareGuidance not implemented"));
   
}

/**
 * Method: vPOIEditLocationInit
  * Inits the POI input location mode in navigation destination form
  * B
 */
void clHSA_Navigation_Base::vPOIEditLocationInit( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOIEditLocationInit not implemented"));
   
}

/**
 * Method: vPOISearchStart
  * starts POI-search
  * B
 */
void clHSA_Navigation_Base::vPOISearchStart( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchStart not implemented"));
   
}

/**
 * Method: vPOISearchGasStationStart
  * starts POI-search for gas station
  * B
 */
void clHSA_Navigation_Base::vPOISearchGasStationStart( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchGasStationStart not implemented"));
   
}

/**
 * Method: vPOISearchParkingAreaStart
  * starts POI-search for parking areas
  * B
 */
void clHSA_Navigation_Base::vPOISearchParkingAreaStart( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchParkingAreaStart not implemented"));
   
}

/**
 * Method: ulwPOISearchState
  * returns the state of poi search
  * B
 */
ulword clHSA_Navigation_Base::ulwPOISearchState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwPOISearchState not implemented"));
   return 0;
}

/**
 * Method: vTelematicParamSetAroundCarPosition
  * activates searching parameter for telematic request around the current car position, gets latlong and city name.
  * B
 */
void clHSA_Navigation_Base::vTelematicParamSetAroundCarPosition( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vTelematicParamSetAroundCarPosition not implemented"));
   
}

/**
 * Method: vTelematicSearchAroundCity
  * for telematic request, gets the latlong values and city name around a city 
  * B
 */
void clHSA_Navigation_Base::vTelematicSearchAroundCity( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vTelematicSearchAroundCity not implemented"));
   
}

/**
 * Method: vTelematicSearchAroundDest
  * for telematic request, gets the latlong values and city name around destination 
  * B
 */
void clHSA_Navigation_Base::vTelematicSearchAroundDest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vTelematicSearchAroundDest not implemented"));
   
}

/**
 * Method: vXMParamSetAroundCarPosition
  * activates searching parameter for XM request around the current car position, gets latlong and city name.
  * B
 */
void clHSA_Navigation_Base::vXMParamSetAroundCarPosition( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vXMParamSetAroundCarPosition not implemented"));
   
}

/**
 * Method: vXMSearchAroundCity
  * for xm request, gets the latlong values and city name around a city 
  * B
 */
void clHSA_Navigation_Base::vXMSearchAroundCity( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vXMSearchAroundCity not implemented"));
   
}

/**
 * Method: vXMSearchAroundDest
  * for xm request, gets the latlong values and city name around destination. 
  * B
 */
void clHSA_Navigation_Base::vXMSearchAroundDest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vXMSearchAroundDest not implemented"));
   
}

/**
 * Method: vTelematicPOIPrepareGuidanceFromDetails
  * prepare a GOOGLE POI entry from detail view for route guidance
  * B
 */
void clHSA_Navigation_Base::vTelematicPOIPrepareGuidanceFromDetails( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vTelematicPOIPrepareGuidanceFromDetails not implemented"));
   
}

/**
 * Method: vPOISearchStop
  * cancels the running POI-search
  * B
 */
void clHSA_Navigation_Base::vPOISearchStop( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOISearchStop not implemented"));
   
}

/**
 * Method: vPOITopSearchStop
  * Cancels the POI-Top-search (gas stations, parking) if it is running (could also be called if the search is not running anymore).
  * C
 */
void clHSA_Navigation_Base::vPOITopSearchStop( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOITopSearchStop not implemented"));
   
}

/**
 * Method: vRecalculateRoute
  * Recalculates the route to the selected destination
  * B1
 */
void clHSA_Navigation_Base::vRecalculateRoute( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRecalculateRoute not implemented"));
   
}

/**
 * Method: vRouteBlockCongestionAheadApply
  * Sets the selected route blocks to the congestion area
  * B
 */
void clHSA_Navigation_Base::vRouteBlockCongestionAheadApply( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteBlockCongestionAheadApply not implemented"));
   
}

/**
 * Method: vRouteBlockCongestionAheadDecrease
  * Decreases the length of the congestion
  * B
 */
void clHSA_Navigation_Base::vRouteBlockCongestionAheadDecrease( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteBlockCongestionAheadDecrease not implemented"));
   
}

/**
 * Method: vRouteBlockCongestionAheadGetLength
  * returns the current setted length of the congestion ahead incl. distance and d-unit
  * B
 */
void clHSA_Navigation_Base::vRouteBlockCongestionAheadGetLength(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteBlockCongestionAheadGetLength not implemented"));
   
}

/**
 * Method: vRouteBlockCongestionAheadIncrease
  * increases the length of the congestion
  * B
 */
void clHSA_Navigation_Base::vRouteBlockCongestionAheadIncrease( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteBlockCongestionAheadIncrease not implemented"));
   
}

/**
 * Method: vRouteBlockDiscardEntries
  * discards all done entries while setting up a blocking section but not finalized with lock end
  * B
 */
void clHSA_Navigation_Base::vRouteBlockDiscardEntries( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteBlockDiscardEntries not implemented"));
   
}

/**
 * Method: vRouteCriteriaApplyInput
  * Validates entered Route-Options/Criterias
  * B1
 */
void clHSA_Navigation_Base::vRouteCriteriaApplyInput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteCriteriaApplyInput not implemented"));
   
}

/**
 * Method: vRouteCriteriaInit
  * Indicates the entry of Route-Options/Criterias context
  * B2
 */
void clHSA_Navigation_Base::vRouteCriteriaInit( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteCriteriaInit not implemented"));
   
}

/**
 * Method: vRouteCriteriaAvoidVignetteGetList
  * To manage avoid countries with vignette
  * B
 */
void clHSA_Navigation_Base::vRouteCriteriaAvoidVignetteGetList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteCriteriaAvoidVignetteGetList not implemented"));
   
}

/**
 * Method: vRouteCriteriaAvoidVignetteGetCheckbox
  * Get text value to display checkbox value for enabled and disabled
  * B
 */
void clHSA_Navigation_Base::vRouteCriteriaAvoidVignetteGetCheckbox(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteCriteriaAvoidVignetteGetCheckbox not implemented"));
   
}

/**
 * Method: ulwRouteCriteriaAvoidVignetteListCount
  * get count of vignette list items
  * B
 */
ulword clHSA_Navigation_Base::ulwRouteCriteriaAvoidVignetteListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwRouteCriteriaAvoidVignetteListCount not implemented"));
   return 0;
}

/**
 * Method: vRouteCriteriaAvoidVignetteToggleItem
  * Toggles the current value of the Vignette item list
  * B
 */
void clHSA_Navigation_Base::vRouteCriteriaAvoidVignetteToggleItem(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteCriteriaAvoidVignetteToggleItem not implemented"));
   
}

/**
 * Method: ulwRouteCriteriaGetState
  * Gets the state of several route-criterias
  * NISSAN 2.0
 */
ulword clHSA_Navigation_Base::ulwRouteCriteriaGetState(ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwRouteCriteriaGetState not implemented"));
   return 0;
}

/**
 * Method: vRouteCriteriaSetState
  * Set a new state of several route-criterias
  * NISSAN 2.0
 */
void clHSA_Navigation_Base::vRouteCriteriaSetState(ulword ulwType, ulword ulwState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteCriteriaSetState not implemented"));
   
}

/**
 * Method: ulwRouteGuidanceGetMode
  * returns whether the navi is in mode onroad or offroad
  * B
 */
ulword clHSA_Navigation_Base::ulwRouteGuidanceGetMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwRouteGuidanceGetMode not implemented"));
   return 0;
}

/**
 * Method: vRouteGuidanceGetRemainingDistance
  * gets the remaining distance (using current unit) until reaching the destination/stopover...
  * B
 */
void clHSA_Navigation_Base::vRouteGuidanceGetRemainingDistance(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteGuidanceGetRemainingDistance not implemented"));
   
}

/**
 * Method: vRouteGuidanceGetRemainingTime
  * gets the remaining time until reaching the destination/stopover...
  * B
 */
void clHSA_Navigation_Base::vRouteGuidanceGetRemainingTime(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteGuidanceGetRemainingTime not implemented"));
   
}

/**
 * Method: vRouteGuidanceStart
  * calculates the current route and start the guidance in a normal mode using the current destination if the route was already calculated, the gudiance starts immediatly DEMO-Mode will be switched off (if activated)
  * B1
 */
void clHSA_Navigation_Base::vRouteGuidanceStart( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteGuidanceStart not implemented"));
   
}

/**
 * Method: vRouteGuidanceStartDemo
  * calculates the current route and start the guidance in a demo mode using the current destination if the route was already calculated, the gudiance starts immediatly
  * B1
 */
void clHSA_Navigation_Base::vRouteGuidanceStartDemo( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteGuidanceStartDemo not implemented"));
   
}

/**
 * Method: vRouteGuidanceStart_Waypoint
  * calculates the current route and start the guidance in a normal mode using the current destination if the route was already calculated, the gudiance starts immediatly DEMO-Mode will be switched off (if activated)
  * B1
 */
void clHSA_Navigation_Base::vRouteGuidanceStart_Waypoint( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteGuidanceStart_Waypoint not implemented"));
   
}

/**
 * Method: vRouteGuidanceStartDemo_Waypoint
  * calculates the current route and start the guidance in a demo mode using the current destination if the route was already calculated, the gudiance starts immediatly
  * B1
 */
void clHSA_Navigation_Base::vRouteGuidanceStartDemo_Waypoint( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteGuidanceStartDemo_Waypoint not implemented"));
   
}

/**
 * Method: vRouteGuidanceStartPOI
  * calculates the current route and start the guidance in a normal mode using the current selected POI if the route was already calculated, the gudiance starts immediatly DEMO-Mode will be switched off (if activated)
  * B
 */
void clHSA_Navigation_Base::vRouteGuidanceStartPOI( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteGuidanceStartPOI not implemented"));
   
}

/**
 * Method: vRouteGuidanceStop
  * stops the current route-guidance immediatly
  * B1
 */
void clHSA_Navigation_Base::vRouteGuidanceStop( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteGuidanceStop not implemented"));
   
}

/**
 * Method: vRouteManeuverDetailData
  * returns detail data about the current selected item of the current route or maneuver
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverDetailData(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverDetailData not implemented"));
   
}

/**
 * Method: vRouteManeuverActivateDetailData
  * returns detail data about the current selected item of the current route or maneuver
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverActivateDetailData(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverActivateDetailData not implemented"));
   
}

/**
 * Method: vRouteManeuverGetList
  * requested item of the route maneuver list, the string contains a device dependent type of string
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverGetList(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCell);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverGetList not implemented"));
   
}

/**
 * Method: ulwRouteManeuverGetDisTimeUnits
  * request the unit item
  * B-Deprecated
 */
ulword clHSA_Navigation_Base::ulwRouteManeuverGetDisTimeUnits(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwRouteManeuverGetDisTimeUnits not implemented"));
   return 0;
}

/**
 * Method: ulwRouteManeuverMessageIconLabel
  * Get the route maneuver message list icons as a String in the corresponding font size. Unicode values will be described as icons will be delivered.
  * B
 */
ulword clHSA_Navigation_Base::ulwRouteManeuverMessageIconLabel(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwRouteManeuverMessageIconLabel not implemented"));
   return 0;
}

/**
 * Method: vSetWaypointForPOISearch
  * select an item of the list and prepares it for searching POIs
  * B
 */
void clHSA_Navigation_Base::vSetWaypointForPOISearch(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetWaypointForPOISearch not implemented"));
   
}

/**
 * Method: ulwWaypointIconLabel
  * Get the Icon of the destination in the waypoint list.
  * B
 */
ulword clHSA_Navigation_Base::ulwWaypointIconLabel(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwWaypointIconLabel not implemented"));
   return 0;
}

/**
 * Method: ulwRouteManeuverMarkedLockElement
  * Get the route maneuver  list item that is marked as "down".
  * B
 */
ulword clHSA_Navigation_Base::ulwRouteManeuverMarkedLockElement(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwRouteManeuverMarkedLockElement not implemented"));
   return 0;
}

/**
 * Method: ulwRouteManeuverGetListCount
  * get count of the main items
  * B
 */
ulword clHSA_Navigation_Base::ulwRouteManeuverGetListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwRouteManeuverGetListCount not implemented"));
   return 0;
}

/**
 * Method: ulwRouteManeuverGetSubItemCount
  * get count of sub items for the corresponding main item
  * BPlus
 */
ulword clHSA_Navigation_Base::ulwRouteManeuverGetSubItemCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwRouteManeuverGetSubItemCount not implemented"));
   return 0;
}

/**
 * Method: blRouteManeuverListIsAvailable
  * returns wether the complete maneuverlist is available or not
  * B
 */
tbool clHSA_Navigation_Base::blRouteManeuverListIsAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blRouteManeuverListIsAvailable not implemented"));
   return 0;
}

/**
 * Method: blRouteBlockIsLockLimitExceeded
  * returns wether it is not possible to add further elements to the locking queue form the route maneuver list.
  * B
 */
tbool clHSA_Navigation_Base::blRouteBlockIsLockLimitExceeded( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blRouteBlockIsLockLimitExceeded not implemented"));
   return 0;
}

/**
 * Method: vRouteManeuverPrepareList
  * Prepares the route maneuver list to be shown
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverPrepareList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverPrepareList not implemented"));
   
}

/**
 * Method: vRouteManeuverMarkLockElementIncrease
  * Increases the marking  of route maneuver list elements
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverMarkLockElementIncrease( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverMarkLockElementIncrease not implemented"));
   
}

/**
 * Method: vRouteManeuverMarkLockElementDecrease
  * Decreases the marking  of route maneuver list elements
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverMarkLockElementDecrease( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverMarkLockElementDecrease not implemented"));
   
}

/**
 * Method: vRouteManeuverSetMarkLockElement
  * Set a the marking of route maneuver list element to a specified one list entry index
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverSetMarkLockElement(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverSetMarkLockElement not implemented"));
   
}

/**
 * Method: vRouteManeuverSetMarkLockFirstElement
  * Set the marking of route maneuver list to the first element
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverSetMarkLockFirstElement(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverSetMarkLockFirstElement not implemented"));
   
}

/**
 * Method: vRouteManeuverSetMarkLockFirstElementFromDetails
  * Set the marking of route maneuver list to the current element choosen in detail view of route maneuver list
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverSetMarkLockFirstElementFromDetails( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverSetMarkLockFirstElementFromDetails not implemented"));
   
}

/**
 * Method: vRouteManeuverSetMarkLockLastElementFromDetails
  * Set the marking of route maneuver list to the current element choosen in detail view of route maneuver list
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverSetMarkLockLastElementFromDetails( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverSetMarkLockLastElementFromDetails not implemented"));
   
}

/**
 * Method: vRouteManeuverSetMarkLockLastElement
  * Set a the marking of route maneuver list to the last element
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverSetMarkLockLastElement(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverSetMarkLockLastElement not implemented"));
   
}

/**
 * Method: blRouteManeuverMarkLockMode
  * returns if the route maneuver list is in mark lock element mode
  * B
 */
tbool clHSA_Navigation_Base::blRouteManeuverMarkLockMode( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blRouteManeuverMarkLockMode not implemented"));
   return 0;
}

/**
 * Method: vRouteManeuverSetMarkLockMode
  * Set the mark lock element mode
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverSetMarkLockMode(tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverSetMarkLockMode not implemented"));
   
}

/**
 * Method: blRouteManeuverIsCongestionDefined
  * Returns wheather a congestion within the route maneuver list is already defined 
  * B
 */
tbool clHSA_Navigation_Base::blRouteManeuverIsCongestionDefined( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blRouteManeuverIsCongestionDefined not implemented"));
   return 0;
}

/**
 * Method: vRouteManeuverDeleteCongestion
  * Deletes the congestion set within the route maneuver list
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverDeleteCongestion( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverDeleteCongestion not implemented"));
   
}

/**
 * Method: vRouteManeuverListClosed
  * Indicates that the route maneuver list is closed and not needed anymore
  * B
 */
void clHSA_Navigation_Base::vRouteManeuverListClosed( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteManeuverListClosed not implemented"));
   
}

/**
 * Method: ulwRouteManeuverPrepareListState
  * Returns the current status of route maneuver list initialization process
  * B
 */
ulword clHSA_Navigation_Base::ulwRouteManeuverPrepareListState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwRouteManeuverPrepareListState not implemented"));
   return 0;
}

/**
 * Method: vEnterMoveMode
  * Prepare List for Entering in move mode
  * B
 */
void clHSA_Navigation_Base::vEnterMoveMode(ulword ulwPressedDynamicIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPressedDynamicIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vEnterMoveMode not implemented"));
   
}

/**
 * Method: vListEntryMoveDown
  * Move the element down
  * B
 */
void clHSA_Navigation_Base::vListEntryMoveDown(ulword ulwMovedDynamicIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMovedDynamicIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vListEntryMoveDown not implemented"));
   
}

/**
 * Method: vListEntryMoveUp
  * Move the element UP
  * B
 */
void clHSA_Navigation_Base::vListEntryMoveUp(ulword ulwMovedDynamicIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMovedDynamicIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vListEntryMoveUp not implemented"));
   
}

/**
 * Method: vAbortMoveMode
  * The HK Press abort the move mode
  * NISSAN
 */
void clHSA_Navigation_Base::vAbortMoveMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vAbortMoveMode not implemented"));
   
}

/**
 * Method: vLeaveMoveMode
  * Accept the new position  and leave the move mode
  * NISSAN LCN2
 */
void clHSA_Navigation_Base::vLeaveMoveMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vLeaveMoveMode not implemented"));
   
}

/**
 * Method: ulwWaypointGetCurrentMoveIndex
  * Gets the dynamic index of selected waypoint. 
  * B
 */
ulword clHSA_Navigation_Base::ulwWaypointGetCurrentMoveIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwWaypointGetCurrentMoveIndex not implemented"));
   return 0;
}

/**
 * Method: vDeleteAndInsertWaypoint
  * This function is used for deleting a waypoint and Inserting a newone
  * NISSAN LCN 2
 */
void clHSA_Navigation_Base::vDeleteAndInsertWaypoint(ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDeleteAndInsertWaypoint not implemented"));
   
}

/**
 * Method: vDeleteWaypoint
  * This function is used for deleting a waypoint 
  * NISSAN LCN 2
 */
void clHSA_Navigation_Base::vDeleteWaypoint(ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDeleteWaypoint not implemented"));
   
}

/**
 * Method: blRouteOptionDynRouteGetState
  * gets the current mode of the setting 'dynamic route'
  * B1
 */
tbool clHSA_Navigation_Base::blRouteOptionDynRouteGetState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blRouteOptionDynRouteGetState not implemented"));
   return 0;
}

/**
 * Method: vRouteOptionDynRouteSetState
  * selects a new mode of the setting 'dynamic route'
  * B1
 */
void clHSA_Navigation_Base::vRouteOptionDynRouteSetState(tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteOptionDynRouteSetState not implemented"));
   
}

/**
 * Method: ulwRouteOptionGetState
  * gets the current guidancemode
  * B1
 */
ulword clHSA_Navigation_Base::ulwRouteOptionGetState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwRouteOptionGetState not implemented"));
   return 0;
}

/**
 * Method: vRouteOptionSetState
  * selects a new guidancemode
  * B1
 */
void clHSA_Navigation_Base::vRouteOptionSetState(ulword ulwState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteOptionSetState not implemented"));
   
}

/**
 * Method: vSetCurrentPositionAsHomeDest
  * sets current position as home destination
  * B
 */
void clHSA_Navigation_Base::vSetCurrentPositionAsHomeDest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetCurrentPositionAsHomeDest not implemented"));
   
}

/**
 * Method: vSetTemporaryMode
  * Indicates that the next Guidance that will be started is in DemoMode or not
  * B1
 */
void clHSA_Navigation_Base::vSetTemporaryMode(tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetTemporaryMode not implemented"));
   
}

/**
 * Method: vSetDemoPosition
  * Indicates that the current destination input is in relation to demo mode start position.
  * B
 */
void clHSA_Navigation_Base::vSetDemoPosition( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetDemoPosition not implemented"));
   
}

/**
 * Method: ulwSetupGetAnnouncement
  * returns the current setting of Navigation-Announcement
  * B
 */
ulword clHSA_Navigation_Base::ulwSetupGetAnnouncement( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwSetupGetAnnouncement not implemented"));
   return 0;
}

/**
 * Method: ulwSetupGetAutozoom
  * Returns whether the autozoom option in the map is turned on or off.
  * 
 */
ulword clHSA_Navigation_Base::ulwSetupGetAutozoom( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwSetupGetAutozoom not implemented"));
   return 0;
}

/**
 * Method: blSetupGetDemoMode
  * returns whether the device is in simulating-mode or not
  * B1
 */
tbool clHSA_Navigation_Base::blSetupGetDemoMode( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blSetupGetDemoMode not implemented"));
   return 0;
}

/**
 * Method: blSetupDeactivateDemoModeSetting
  * returns whether the Demo setting should be enabled or not
  * B1
 */
tbool clHSA_Navigation_Base::blSetupDeactivateDemoModeSetting( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blSetupDeactivateDemoModeSetting not implemented"));
   return 0;
}

/**
 * Method: blSetupOptionsChanged
  * Returns whether it is necessary to recalucate the current activ route
  * B2
 */
tbool clHSA_Navigation_Base::blSetupOptionsChanged( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blSetupOptionsChanged not implemented"));
   return 0;
}

/**
 * Method: vSetupSetAutozoom
  * setting the autozoom in the map
  * 
 */
void clHSA_Navigation_Base::vSetupSetAutozoom(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetupSetAutozoom not implemented"));
   
}

/**
 * Method: vSetupSetDemoMode
  * setting the demo-mode of the device, could switch off autmatically by calling RouteGuidanceStart instead of RouteGuidanceStartDemo
  * B1
 */
void clHSA_Navigation_Base::vSetupSetDemoMode(tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetupSetDemoMode not implemented"));
   
}

/**
 * Method: vSpellerInitInput
  * Initialize a speller-item of the selected type
  * B
 */
void clHSA_Navigation_Base::vSpellerInitInput(ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerInitInput not implemented"));
   
}

/**
 * Method: vSpellerInitRestore
  * Initialize and restore the input of a speller-item of the selected type
  * B
 */
void clHSA_Navigation_Base::vSpellerInitRestore(ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerInitRestore not implemented"));
   
}

/**
 * Method: vSpellerCharacterInput
  * enter one character of  (speller input function)
  * B
 */
void clHSA_Navigation_Base::vSpellerCharacterInput(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerCharacterInput not implemented"));
   
}

/**
 * Method: vSpellerDiscardAllInput
  * discards all input from the speller
  * NIKAI-4796
 */
void clHSA_Navigation_Base::vSpellerDiscardAllInput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerDiscardAllInput not implemented"));
   
}

/**
 * Method: vSpellerGetNameInput
  * Get the input from the speller for the given name 
  * B
 */
void clHSA_Navigation_Base::vSpellerGetNameInput(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerGetNameInput not implemented"));
   
}

/**
 * Method: vSpellerSetNameInput
  * Set the name for the given input from the speller 
  * B
 */
void clHSA_Navigation_Base::vSpellerSetNameInput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerSetNameInput not implemented"));
   
}

/**
 * Method: ulwSpellerMatchGetCount
  * count the results, if Speller input was not called before, the whole resultset will be counted
  * B
 */
ulword clHSA_Navigation_Base::ulwSpellerMatchGetCount(ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwSpellerMatchGetCount not implemented"));
   return 0;
}

/**
 * Method: ulwMatchGetListCount
  * Necessary for proper procedure of exonym and the avoidance of rotations (VW feature) in navigation destination match lists.
  * B
 */
ulword clHSA_Navigation_Base::ulwMatchGetListCount(ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwMatchGetListCount not implemented"));
   return 0;
}

/**
 * Method: vSpellerMatchGetFirst
  * gets the first match if the spellertype is a matchspeller or Speller input was called, else the first entry in the dataset will be returned 
  * B
 */
void clHSA_Navigation_Base::vSpellerMatchGetFirst(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerMatchGetFirst not implemented"));
   
}

/**
 * Method: vSpellerGetFavSearchInput
  * gets the input from textinput speller. 
  * B
 */
void clHSA_Navigation_Base::vSpellerGetFavSearchInput(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerGetFavSearchInput not implemented"));
   
}

/**
 * Method: blSpellerInputOccurred
  * returns whether a speller input occurred and a character is given for Navigation.SpellerMatchGetFirst
  * B
 */
tbool clHSA_Navigation_Base::blSpellerInputOccurred( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blSpellerInputOccurred not implemented"));
   return 0;
}

/**
 * Method: vSpellerMatchGetList
  * gets the entry of the match-resultset or database
  * B
 */
void clHSA_Navigation_Base::vSpellerMatchGetList(GUI_String *out_result, ulword ulwType, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerMatchGetList not implemented"));
   
}

/**
 * Method: vSpellerMatchActivateList
  * activates the entry of the match-resultset or database
  * B
 */
void clHSA_Navigation_Base::vSpellerMatchActivateList(ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerMatchActivateList not implemented"));
   
}

/**
 * Method: vSpellerMatchActivateListRestore
  * restores the entry of the match-resultset or database before disambiguation list has been entered
  * B
 */
void clHSA_Navigation_Base::vSpellerMatchActivateListRestore(ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerMatchActivateListRestore not implemented"));
   
}

/**
 * Method: vSpellerMatchGetPossibleLetters
  * returns a string list that contains all letters which are possible to get the next valid match-result
  * B
 */
void clHSA_Navigation_Base::vSpellerMatchGetPossibleLetters(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerMatchGetPossibleLetters not implemented"));
   
}

/**
 * Method: blSpellerInvertGetLetterFunction
  * Inverts the logic of the SpellerGetLetterFunction. Has to be set by the application, for example in a freetext-speller, in order to disable some buttons and, at the same time, to enable the cursor-buttons and alt/sub/nr. 
  * B
 */
tbool clHSA_Navigation_Base::blSpellerInvertGetLetterFunction( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blSpellerInvertGetLetterFunction not implemented"));
   return 0;
}

/**
 * Method: vSpellerGetHighlightedText
  * The initial text set by the APICall GetSpellerEntryField, wil be taken as proposal and will be sent to the entry field. This proposal can be displayed inverted by using the property "matchText". If only one character is entered, this proposal will be discarded and this function returns an empty string. If the cursor is moved,  this method also returns an empty string.
  * B
 */
void clHSA_Navigation_Base::vSpellerGetHighlightedText(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerGetHighlightedText not implemented"));
   
}

/**
 * Method: blSpellerEnableMatchSpeller
  * During matching, the user shouldn't be able to to enter characters or to change the position of the cursor. This is why in this case the speller must be disabled .
  * B
 */
tbool clHSA_Navigation_Base::blSpellerEnableMatchSpeller( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blSpellerEnableMatchSpeller not implemented"));
   return 0;
}

/**
 * Method: blSpellerEnableHouseNumSpeller
  * During matching, the user shouldn't be able to to enter characters or to change the position of the cursor. This is why in this case the speller must be disabled .
  * B
 */
tbool clHSA_Navigation_Base::blSpellerEnableHouseNumSpeller( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blSpellerEnableHouseNumSpeller not implemented"));
   return 0;
}

/**
 * Method: ulwSpellerGetCursorPos
  * Returns the position of the cursor. The application has to manage the position of the cursor by using the special unicodes F817 and F818. The cursor is independent from the length of the text. "Left" would position the cursor between the last and the last but one  character. "Right" will position the cursor after the last character.
  * B
 */
ulword clHSA_Navigation_Base::ulwSpellerGetCursorPos( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwSpellerGetCursorPos not implemented"));
   return 0;
}

/**
 * Method: vSpellerSetMaxCharCount
  * Used to set the max number of characters which can be entered in the SpellerEntryField. The application has to know this value, in order to prevent entering characters after the maximum of allowed characters was reached. 
  * B
 */
void clHSA_Navigation_Base::vSpellerSetMaxCharCount(ulword ulwCount)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCount);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerSetMaxCharCount not implemented"));
   
}

/**
 * Method: vSpellerSetInitialText
  * Sets the inital text for the entry field of a speller. The appllication must handle the text internally which is provided by getText() and getHighlightedText() respectively. It is important to provide the text as a highlighted text. If setCharacter() will be called with a letter the text will be substituted by this. If the setCharacter() will be called with a special character (cursor left or cursor right, see setCharacter function) the text value will be taken and provided by the getText(). The cursor position will be set to the last index if cursor right or before the last index if cursor left. Additional chars set by setCharacter() will be added at the current cursorpos.
  * B
 */
void clHSA_Navigation_Base::vSpellerSetInitialText(const GUI_String * InitialString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InitialString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSpellerSetInitialText not implemented"));
   
}

/**
 * Method: vStartEditingDemoMode
  * This call signalizes to the application that we are currently entering the demo mode starting point, meaning that in the view NAV_DEST_FORM_ADR, all calls to Navigation.DestEntryGetAddress(Type x) need to return the information relevant to the demo mode starting point (not the last entered regular destination).
  * NISSAN
 */
void clHSA_Navigation_Base::vStartEditingDemoMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vStartEditingDemoMode not implemented"));
   
}

/**
 * Method: vStopEditingDemoMode
  * This call signalizes to the application that we are no longer entering the demo mode starting point, meaning that in  the view NAV_DEST_FORM_ADR, all calls to Navigation.DestEntryGetAddress(Type x) need to return the regular destination information (no longer the demo mode starting point information).
  * NISSAN
 */
void clHSA_Navigation_Base::vStopEditingDemoMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vStopEditingDemoMode not implemented"));
   
}

/**
 * Method: vStopCalcRoute
  * stops calculating the route immediatly
  * B1
 */
void clHSA_Navigation_Base::vStopCalcRoute( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vStopCalcRoute not implemented"));
   
}

/**
 * Method: ulwWaitSyncState
  * checks if the result of an asynchronous operation is submitted and therefore finished.
  * B1 - New Parameter for B
 */
ulword clHSA_Navigation_Base::ulwWaitSyncState(ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwWaitSyncState not implemented"));
   return 0;
}

/**
 * Method: vRouteOptionDynRouteUserConfirm
  * Sets the Dynamic Route option to User Confrim
  * NISSAN
 */
void clHSA_Navigation_Base::vRouteOptionDynRouteUserConfirm( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRouteOptionDynRouteUserConfirm not implemented"));
   
}

/**
 * Method: ulwGetDynRouteOption
  * gets the current mode of the setting 'dynamic route'
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetDynRouteOption( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetDynRouteOption not implemented"));
   return 0;
}

/**
 * Method: vSetDynRouteOption
  * selects a new mode of the setting 'dynamic route'
  * NISSAN
 */
void clHSA_Navigation_Base::vSetDynRouteOption(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetDynRouteOption not implemented"));
   
}

/**
 * Method: blIsMemoryLimitReached
  * checks if the memory limit is reached
  * NISSAN
 */
tbool clHSA_Navigation_Base::blIsMemoryLimitReached( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsMemoryLimitReached not implemented"));
   return 0;
}

/**
 * Method: vShowCategoryList
  * show the category list
  * NISSAN
 */
void clHSA_Navigation_Base::vShowCategoryList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vShowCategoryList not implemented"));
   
}

/**
 * Method: vGetHouseNo_NAR
  * Provides the last selected House no 
  * NISSAN
 */
void clHSA_Navigation_Base::vGetHouseNo_NAR(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetHouseNo_NAR not implemented"));
   
}

/**
 * Method: vPoiSetCategory_NAR
  * Select one item from the list
  * NISSAN
 */
void clHSA_Navigation_Base::vPoiSetCategory_NAR(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vPoiSetCategory_NAR not implemented"));
   
}

/**
 * Method: ulwGetPOIListType
  * Returns the type of list available in the navi
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetPOIListType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetPOIListType not implemented"));
   return 0;
}

/**
 * Method: blIsPOICategoryListPrepared
  * checks if the new list is prepared
  * NISSAN
 */
tbool clHSA_Navigation_Base::blIsPOICategoryListPrepared(ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blIsPOICategoryListPrepared not implemented"));
   return 0;
}

/**
 * Method: ulwGetPOICategoryCount
  * If category list is available get the count
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetPOICategoryCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetPOICategoryCount not implemented"));
   return 0;
}

/**
 * Method: ulwGetPOIAttributeCount
  * If attribute list is available get the count
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetPOIAttributeCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetPOIAttributeCount not implemented"));
   return 0;
}

/**
 * Method: vRestorePOICategoryList
  * The HK return for POI by Catgeory 
  * NISSAN
 */
void clHSA_Navigation_Base::vRestorePOICategoryList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vRestorePOICategoryList not implemented"));
   
}

/**
 * Method: ulwGetLastPOIListSelIndex
  * Get the User Selected Index of the previous POI Category or POI Attribute List
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetLastPOIListSelIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetLastPOIListSelIndex not implemented"));
   return 0;
}

/**
 * Method: vPOIGetSelectedCategory
  * POI BY Category; gets the name of the selected category
  * NISSAN
 */
void clHSA_Navigation_Base::vPOIGetSelectedCategory(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vPOIGetSelectedCategory not implemented"));
   
}

/**
 * Method: vMemoryWaypointPrepareList
  * Prepares the Tour list to be shown
  * B
 */
void clHSA_Navigation_Base::vMemoryWaypointPrepareList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryWaypointPrepareList not implemented"));
   
}

/**
 * Method: vExitWaypointList
  * Indicates that context is out of waypoint list
  * B
 */
void clHSA_Navigation_Base::vExitWaypointList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vExitWaypointList not implemented"));
   
}

/**
 * Method: ulwMemoryWaypointGetListCount
  * get count of the main items
  * B
 */
ulword clHSA_Navigation_Base::ulwMemoryWaypointGetListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwMemoryWaypointGetListCount not implemented"));
   return 0;
}

/**
 * Method: vMemoryWaypointGetList
  * requested item of the tour list, the string contains a device dependent type of string
  * /
 */
void clHSA_Navigation_Base::vMemoryWaypointGetList(GUI_String *out_result, ulword ulwCell, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCell);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vMemoryWaypointGetList not implemented"));
   
}

/**
 * Method: ulwMemoryWaypointGetDirection
  * direction of the requested item of the tour list is obtained
  * /
 */
ulword clHSA_Navigation_Base::ulwMemoryWaypointGetDirection(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwMemoryWaypointGetDirection not implemented"));
   return 0;
}

/**
 * Method: blMemoryWaypointMemIsFull
  * returns whether the destination memory is full or not
  * B
 */
tbool clHSA_Navigation_Base::blMemoryWaypointMemIsFull( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blMemoryWaypointMemIsFull not implemented"));
   return 0;
}

/**
 * Method: vWaypointPrepareSaving
  * prepares the selected entry for saving it
  * B
 */
void clHSA_Navigation_Base::vWaypointPrepareSaving( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vWaypointPrepareSaving not implemented"));
   
}

/**
 * Method: ulwRouteManeuverGetListUnit
  * Returns the Distance unit to Route list item
  * D
 */
ulword clHSA_Navigation_Base::ulwRouteManeuverGetListUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwRouteManeuverGetListUnit not implemented"));
   return 0;
}

/**
 * Method: ulwPOISearchResultGetListUnit
  * Returns the Distance unit to POI search list items
  * D
 */
ulword clHSA_Navigation_Base::ulwPOISearchResultGetListUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwPOISearchResultGetListUnit not implemented"));
   return 0;
}

/**
 * Method: ulwGetPositionDataDetailUnit
  * Returns the Distance unit of altitude
  * D
 */
ulword clHSA_Navigation_Base::ulwGetPositionDataDetailUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetPositionDataDetailUnit not implemented"));
   return 0;
}

/**
 * Method: ulwMemoryWaypointGetListUnit
  * Returns the Distance unit of Waypoint distance
  * D
 */
ulword clHSA_Navigation_Base::ulwMemoryWaypointGetListUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwMemoryWaypointGetListUnit not implemented"));
   return 0;
}

/**
 * Method: vSetGnsssatSystemType
  * To Set the GNSS system to GPS or GLONASS
  * NISSAN 2.0
 */
void clHSA_Navigation_Base::vSetGnsssatSystemType(ulword ulwGnssType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwGnssType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetGnsssatSystemType not implemented"));
   
}

/**
 * Method: ulwGetGnsssatSystemType
  * To Get the GNSS system status
  * NISSAN
 */
ulword clHSA_Navigation_Base::ulwGetGnsssatSystemType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetGnsssatSystemType not implemented"));
   return 0;
}

/**
 * Method: ulwGetLanguageDependentStringsUnit
  * Returns the Distance unit of EN_UPS_POI_DISTANCE
  * D
 */
ulword clHSA_Navigation_Base::ulwGetLanguageDependentStringsUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwGetLanguageDependentStringsUnit not implemented"));
   return 0;
}

/**
 * Method: vDestEntryGetWaypoint
  * returns the current data for the navigation destination form favourite
  * B
 */
void clHSA_Navigation_Base::vDestEntryGetWaypoint(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vDestEntryGetWaypoint not implemented"));
   
}

/**
 * Method: blStreetPossibleAfterCity
  * returns  whether streets are available after city 
  * B
 */
tbool clHSA_Navigation_Base::blStreetPossibleAfterCity( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Navigation::blStreetPossibleAfterCity not implemented"));
   return 0;
}

/**
 * Method: ulwDestEntryGetSDSInputType
  * returns the input path from SDS
  * D
 */
ulword clHSA_Navigation_Base::ulwDestEntryGetSDSInputType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Navigation::ulwDestEntryGetSDSInputType not implemented"));
   return 0;
}

/**
 * Method: vTCUJourneyPrepareGuidance
  * prepares the TCU entries for starting the guidance
  * NISSAN
 */
void clHSA_Navigation_Base::vTCUJourneyPrepareGuidance( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vTCUJourneyPrepareGuidance not implemented"));
   
}

/**
 * Method: vTcuJourneyPrepareShowOnMap
  * prepares the TCU entries for showing on the map
  * NISSAN
 */
void clHSA_Navigation_Base::vTcuJourneyPrepareShowOnMap( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vTcuJourneyPrepareShowOnMap not implemented"));
   
}

/**
 * Method: vSetTCUModeActive
  * indicates that the TCU route Guidance has to be started
  * NISSAN
 */
void clHSA_Navigation_Base::vSetTCUModeActive( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Navigation::vSetTCUModeActive not implemented"));
   
}

/**
 * Method: vGetSelectedPoiCategory
  * Returns the Selected POI Category Name
  * NISSAN
 */
void clHSA_Navigation_Base::vGetSelectedPoiCategory(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Navigation::vGetSelectedPoiCategory not implemented"));
   
}

