/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_HMIFW_Test_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_HMIFW_Test_Base_H
#define _clHSA_HMIFW_Test_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_HMIFW_Test_Base : public clHSA_Base
{
public:

    static clHSA_HMIFW_Test_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_HMIFW_Test_Base()        {}

    virtual void vLoadTestDynImage(ulword ulwDynImgID);

    virtual void vToggleDayNightMode( );

    virtual void vGetDynamicImagePath(GUI_String *out_result, ulword ulwDynImgSet);

    virtual void vGetDocContent(GUI_String *out_result, const GUI_String * path);

    virtual ulword ulwGetDocSize(const GUI_String * path);

    virtual void vGetColorCharString(GUI_String *out_result, ulword ulwtextType);

protected:
    clHSA_HMIFW_Test_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_HMIFW_Test_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_HMIFW_Test_Base_H

