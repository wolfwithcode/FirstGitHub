/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_HMIFW_Test_Trace.h
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
#ifndef _HSA_HMIFW_Test_TRACE_H
#define _HSA_HMIFW_Test_TRACE_H
 

/**** Trace defines for HSA_HMIFW_Test ****/

#define HSA_API_ENTRYPOINT__LOAD_TEST_DYN_IMAGE 0x1

#define HSA_API_ENTRYPOINT__TOGGLE_DAY_NIGHT_MODE 0x2

#define HSA_API_ENTRYPOINT__GET_DYNAMIC_IMAGE_PATH 0x3

#define HSA_API_ENTRYPOINT__GET_DOC_CONTENT 0x4

#define HSA_API_ENTRYPOINT__GET_DOC_SIZE 0x5

#define HSA_API_ENTRYPOINT__GET_COLOR_CHAR_STRING 0x6

#endif  //#ifndef _HSA_HMIFW_Test_TRACE_H

