/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_HMIFW_Test_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_HMIFW_Test_Wrapper.h"
#include "clHSA_HMIFW_Test_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_HMIFW_Test_Trace.h"
#include "hmi_trace.h"

void HSA_HMIFW_Test__vLoadTestDynImage(ulword ulwDynImgID)
{
    
    clHSA_HMIFW_Test_Base *pInst=clHSA_HMIFW_Test_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_HMIFW_TEST), (tU16)(HSA_API_ENTRYPOINT__LOAD_TEST_DYN_IMAGE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDynImgID); 
        }
      pInst->vLoadTestDynImage(ulwDynImgID);

    }
}

void HSA_HMIFW_Test__vToggleDayNightMode( )
{
    
    clHSA_HMIFW_Test_Base *pInst=clHSA_HMIFW_Test_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_HMIFW_TEST), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_DAY_NIGHT_MODE  ) ); 
        }
      pInst->vToggleDayNightMode();

    }
}

void HSA_HMIFW_Test__vGetDynamicImagePath(GUI_String *out_result, ulword ulwDynImgSet)
{
    
    clHSA_HMIFW_Test_Base *pInst=clHSA_HMIFW_Test_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_HMIFW_TEST), (tU16)(HSA_API_ENTRYPOINT__GET_DYNAMIC_IMAGE_PATH | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDynImgSet); 
        }
      pInst->vGetDynamicImagePath(out_result, ulwDynImgSet);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_HMIFW_TEST), (tU16)(HSA_API_ENTRYPOINT__GET_DYNAMIC_IMAGE_PATH | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_HMIFW_Test__vGetDocContent(GUI_String *out_result, const GUI_String * path)
{
    
    clHSA_HMIFW_Test_Base *pInst=clHSA_HMIFW_Test_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_HMIFW_TEST), (tU16)(HSA_API_ENTRYPOINT__GET_DOC_CONTENT | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)path->ulwLen_+1, path->pubBuffer_);
         }
      pInst->vGetDocContent(out_result,  path);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_HMIFW_TEST), (tU16)(HSA_API_ENTRYPOINT__GET_DOC_CONTENT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_HMIFW_Test__ulwGetDocSize(const GUI_String * path)
{
    ulword ret = 0;
    clHSA_HMIFW_Test_Base *pInst=clHSA_HMIFW_Test_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_HMIFW_TEST), (tU16)(HSA_API_ENTRYPOINT__GET_DOC_SIZE | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)path->ulwLen_+1, path->pubBuffer_);
         }
      ret=pInst->ulwGetDocSize( path);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_HMIFW_TEST), (tU16)(HSA_API_ENTRYPOINT__GET_DOC_SIZE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_HMIFW_Test__vGetColorCharString(GUI_String *out_result, ulword ulwtextType)
{
    
    clHSA_HMIFW_Test_Base *pInst=clHSA_HMIFW_Test_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_HMIFW_TEST), (tU16)(HSA_API_ENTRYPOINT__GET_COLOR_CHAR_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwtextType); 
        }
      pInst->vGetColorCharString(out_result, ulwtextType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_HMIFW_TEST), (tU16)(HSA_API_ENTRYPOINT__GET_COLOR_CHAR_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

#ifdef __cplusplus
}
#endif

