/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_HMIFW_Test_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_HMIFW_Test/clHSA_HMIFW_Test_Base.h"

clHSA_HMIFW_Test_Base* clHSA_HMIFW_Test_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_HMIFW_Test_Base.cpp.trc.h"
#endif


/**
 * Method: vLoadTestDynImage
  * Load a test image
  * 
 */
void clHSA_HMIFW_Test_Base::vLoadTestDynImage(ulword ulwDynImgID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDynImgID);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_HMIFW_Test::vLoadTestDynImage not implemented"));
   
}

/**
 * Method: vToggleDayNightMode
  * toggle between day and night
  * 
 */
void clHSA_HMIFW_Test_Base::vToggleDayNightMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_HMIFW_Test::vToggleDayNightMode not implemented"));
   
}

/**
 * Method: vGetDynamicImagePath
  * get the path of the dynamic images
  * 
 */
void clHSA_HMIFW_Test_Base::vGetDynamicImagePath(GUI_String *out_result, ulword ulwDynImgSet)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDynImgSet);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_HMIFW_Test::vGetDynamicImagePath not implemented"));
   
}

/**
 * Method: vGetDocContent
  * get the document byte stream
  * 
 */
void clHSA_HMIFW_Test_Base::vGetDocContent(GUI_String *out_result, const GUI_String * path)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( path);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_HMIFW_Test::vGetDocContent not implemented"));
   
}

/**
 * Method: ulwGetDocSize
  * get the open source license documentation
  * 
 */
ulword clHSA_HMIFW_Test_Base::ulwGetDocSize(const GUI_String * path)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( path);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_HMIFW_Test::ulwGetDocSize not implemented"));
   return 0;
}

/**
 * Method: vGetColorCharString
  * get the color information as a character code
  * 
 */
void clHSA_HMIFW_Test_Base::vGetColorCharString(GUI_String *out_result, ulword ulwtextType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwtextType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_HMIFW_Test::vGetColorCharString not implemented"));
   
}

