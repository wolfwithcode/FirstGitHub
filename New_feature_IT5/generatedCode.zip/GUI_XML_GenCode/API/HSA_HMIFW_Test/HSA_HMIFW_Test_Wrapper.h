/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_HMIFW_Test_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_HMIFW_Test_Wrapper_H
#define _HSA_HMIFW_Test_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: LoadTestDynImage
 * 
 * NISSAN
 */
void HSA_HMIFW_Test__vLoadTestDynImage(ulword ulwDynImgID);

/**
 * Function: ToggleDayNightMode
 * 
 * NISSAN
 */
void HSA_HMIFW_Test__vToggleDayNightMode( void);

/**
 * Function: GetDynamicImagePath
 * 
 * NISSAN
 */
void HSA_HMIFW_Test__vGetDynamicImagePath(GUI_String *out_result, ulword ulwDynImgSet);

/**
 * Function: GetDocContent
 * 
 * NISSAN
 */
void HSA_HMIFW_Test__vGetDocContent(GUI_String *out_result, const GUI_String * path);

/**
 * Function: GetDocSize
 * 
 * NISSAN
 */
ulword HSA_HMIFW_Test__ulwGetDocSize(const GUI_String * path);

/**
 * Function: GetColorCharString
 * 
 * NISSAN
 */
void HSA_HMIFW_Test__vGetColorCharString(GUI_String *out_result, ulword ulwtextType);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_HMIFW_Test_H

