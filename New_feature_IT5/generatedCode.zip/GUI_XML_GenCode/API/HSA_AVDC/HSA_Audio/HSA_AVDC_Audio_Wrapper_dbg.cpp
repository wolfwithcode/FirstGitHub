/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_AVDC_Audio_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_AVDC_Audio_Wrapper_dbg.h"
#include "clHSA_AVDC_Audio_Base.h"
#include "HSA_AVDC_Audio_Trace.h"
#include "HSA_AVDC_Audio_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_AVDC_Audio_Wrapper_dbg::~clHSA_AVDC_Audio_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_AVDC_Audio_Wrapper_dbg::clHSA_AVDC_Audio_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_AVDC_Audio_Wrapper_dbg::clHSA_AVDC_Audio_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_AVDC_Audio_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_AVDC_Audio_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__SET_PLAY:

            HSA_AVDC_Audio__vSetPlay();
            break;

        case HSA_API_ENTRYPOINT__SET_STOP:

            HSA_AVDC_Audio__vSetStop();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_MDI:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC_Audio__vActivateMDI(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC_Audio__vActivateMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_NEXT_TRACK:

            HSA_AVDC_Audio__vActivateNextTrack();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_PREVIOUS_TRACK:

            HSA_AVDC_Audio__vActivatePreviousTrack();
            break;

        case HSA_API_ENTRYPOINT__FAST_FORWARD:

            HSA_AVDC_Audio__vFastForward();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_BROWSER_ITEM:

            HSA_AVDC_Audio__slwGetActiveBrowserItem();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_MDI_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_AVDC_Audio__vGetActiveMDIName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_MDI_NUMBER:

            HSA_AVDC_Audio__ulwGetActiveMDINumber();
            break;

        case HSA_API_ENTRYPOINT__GET_ARTIST_NAME_DISPLAY_LINES_NR:

            HSA_AVDC_Audio__ulwGetArtistNameDisplayLinesNr();
            break;

        case HSA_API_ENTRYPOINT__IS_INDEXING_COMPLETE:

            HSA_AVDC_Audio__blIsIndexingComplete();
            break;

        case HSA_API_ENTRYPOINT__GET_INDEXING_STATUS:

            HSA_AVDC_Audio__ulwGetIndexingStatus();
            break;

        case HSA_API_ENTRYPOINT__START_IPOD_INDEXING:

            HSA_AVDC_Audio__blStartIpodIndexing();
            break;

        case HSA_API_ENTRYPOINT__GET_INDEXING_STATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_AVDC_Audio__vGetIndexingState(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_COVER_ART_IMAGE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_AVDC_Audio__vGetCoverArtImage(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_COVER_ART_IMAGE_INFO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_AVDC_Audio__vGetCoverArtImageInfo(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_AUDIO_SOURCE_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC_Audio__ulwGetAudioSourceState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_BT_AUDIO_FILE_INFO_TYPE:

            HSA_AVDC_Audio__ulwGetBTAudioFileInfoType();
            break;

        case HSA_API_ENTRYPOINT__GET_CD_TYPE:

            HSA_AVDC_Audio__ulwGetCDType();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_CDC_DISC_NR:

            HSA_AVDC_Audio__slwGetCurrentCDCDiscNr();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_MODE:

            HSA_AVDC_Audio__ulwGetCurrentMode();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_TRACK_EXTRA_INFO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_AVDC_Audio__vGetCurrentTrackExtraInfo(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_TRACK_INFO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2);

            HSA_AVDC_Audio__vGetCurrentTrackInfo(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_TRACK_NR:

            HSA_AVDC_Audio__ulwGetCurrentTrackNr();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_MEDIALIST_IDENTIFIER:

            HSA_AVDC_Audio__ulwGetCurrentMedialistIdentifier();
            break;

        case HSA_API_ENTRYPOINT__GET_ELAPSED_TIME_OF_TRACK:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_AVDC_Audio__vGetElapsedTimeOfTrack(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ELAPSED_TIME_OF_TRACK_IN_SECONDS:

            HSA_AVDC_Audio__ulwGetElapsedTimeOfTrackInSeconds();
            break;

        case HSA_API_ENTRYPOINT__GET_INCLUDE_SUB_FOLDERS_STATE:

            HSA_AVDC_Audio__blGetIncludeSubFoldersState();
            break;

        case HSA_API_ENTRYPOINT__GET_MDI_ACTIVATING_STATE:

            HSA_AVDC_Audio__ulwGetMDIActivatingState();
            break;

        case HSA_API_ENTRYPOINT__GET_MDI_FILE_INFO_TYPE:

            HSA_AVDC_Audio__ulwGetMDIFileInfoType();
            break;

        case HSA_API_ENTRYPOINT__GET_MDI_LIST_COUNT:

            HSA_AVDC_Audio__ulwGetMDIListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_MDI_LIST_ITEMS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_AVDC_Audio__vGetMDIListItems(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_MDI_LIST_LOADING_STATE:

            HSA_AVDC_Audio__ulwGetMDIListLoadingState();
            break;

        case HSA_API_ENTRYPOINT__GET_MDI_OPERATION_STATE:

            HSA_AVDC_Audio__ulwGetMDIOperationState();
            break;

        case HSA_API_ENTRYPOINT__GET_REMAINING_TIME_OF_TRACK:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_AVDC_Audio__vGetRemainingTimeOfTrack(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TITLE_NAME_DISPLAY_LINES_NR:

            HSA_AVDC_Audio__ulwGetTitleNameDisplayLinesNr();
            break;

        case HSA_API_ENTRYPOINT__GET_TOTAL_TIME_OF_TRACK_IN_SECONDS:

            HSA_AVDC_Audio__ulwGetTotalTimeOfTrackInSeconds();
            break;

        case HSA_API_ENTRYPOINT__GET_VBR:

            HSA_AVDC_Audio__slwGetVBR();
            break;

        case HSA_API_ENTRYPOINT__IS_BT_AUDIO_ACTIVE:

            HSA_AVDC_Audio__blIsBTAudioActive();
            break;

        case HSA_API_ENTRYPOINT__IS_CDC_DISC_LOADING:

            HSA_AVDC_Audio__ulwIsCDCDiscLoading();
            break;

        case HSA_API_ENTRYPOINT__IS_CHECKING_AUDIO_FILES_FOR_OPENING:

            HSA_AVDC_Audio__ulwIsCheckingAudioFilesForOpening();
            break;

        case HSA_API_ENTRYPOINT__IS_CHECKING_AUDIO_FILES_FOR_PLAYING:

            HSA_AVDC_Audio__ulwIsCheckingAudioFilesForPlaying();
            break;

        case HSA_API_ENTRYPOINT__IS_FUNCTION_MIX_ALL_AVAILABLE:

            HSA_AVDC_Audio__blIsFunctionMixAllAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_FUNCTION_MIX_AVAILABLE:

            HSA_AVDC_Audio__blIsFunctionMixAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_FUNCTION_MIX_FOLDER_AVAILABLE:

            HSA_AVDC_Audio__blIsFunctionMixFolderAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_FUNCTION_MIX_PLAYLIST_AVAILABLE:

            HSA_AVDC_Audio__blIsFunctionMixPlaylistAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_FUNCTION_REPEAT_CD_AVAILABLE:

            HSA_AVDC_Audio__blIsFunctionRepeatCDAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_FUNCTION_REPEAT_FOLDER_AVAILABLE:

            HSA_AVDC_Audio__blIsFunctionRepeatFolderAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_FUNCTION_REPEAT_PLAYLIST_AVAILABLE:

            HSA_AVDC_Audio__blIsFunctionRepeatPlaylistAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_FUNCTION_REPEAT_TRACK_AVAILABLE:

            HSA_AVDC_Audio__blIsFunctionRepeatTrackAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_FUNCTION_SCAN_AVAILABLE:

            HSA_AVDC_Audio__blIsFunctionScanAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_MDI_LIST_AVAILABLE:

            HSA_AVDC_Audio__blIsMDIListAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_SELECTED_LIST_ITEM_INFO_AVAILABLE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC_Audio__ulwIsSelectedListItemInfoAvailable(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_SELECTED_TITLE_LIST_ITEM_INFO_AVAILABLE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC_Audio__ulwIsSelectedTitleListItemInfoAvailable(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__LOAD_MDI_LIST:

            HSA_AVDC_Audio__ulwLoadMDIList();
            break;

        case HSA_API_ENTRYPOINT__REWIND:

            HSA_AVDC_Audio__vRewind();
            break;

        case HSA_API_ENTRYPOINT__STOP_FAST_FORWARD:

            HSA_AVDC_Audio__vStopFastForward();
            break;

        case HSA_API_ENTRYPOINT__STOP_REWIND:

            HSA_AVDC_Audio__vStopRewind();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_BT_AUDIO_STATE:

            HSA_AVDC_Audio__vToggleBTAudioState();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_INCLUDE_SUB_FOLDERS_STATE:

            HSA_AVDC_Audio__vToggleIncludeSubFoldersState();
            break;

        case HSA_API_ENTRYPOINT__GET_PANDORA_STATION_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_AVDC_Audio__vGetPandoraStationName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_PANDORA_ERROR_MESSAGE:

            HSA_AVDC_Audio__ulwGetPandoraErrorMessage();
            break;

        case HSA_API_ENTRYPOINT__GET_PANDORA_STATION_ICON:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_AVDC_Audio__vGetPandoraStationIcon(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_PANDORA_RATING_ICON:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_AVDC_Audio__vGetPandoraRatingIcon(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_PANDORA_PLAY_STATUS:

            HSA_AVDC_Audio__blGetPandoraPlayStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_PANDORA_LOADING_STATUS:

            HSA_AVDC_Audio__blGetPandoraLoadingStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_PANDORA_LIST_LOADING_STATUS:

            HSA_AVDC_Audio__blGetPandoraListLoadingStatus();
            break;

        case HSA_API_ENTRYPOINT__IS_PANDORA_RATING_ALLOWED:

            HSA_AVDC_Audio__blIsPandoraRatingAllowed();
            break;

        case HSA_API_ENTRYPOINT__IS_PANDORA_THUMBS_UP:

            HSA_AVDC_Audio__blIsPandoraThumbsUp();
            break;

        case HSA_API_ENTRYPOINT__IS_PANDORA_THUMBS_DOWN:

            HSA_AVDC_Audio__blIsPandoraThumbsDown();
            break;

        case HSA_API_ENTRYPOINT__IS_PANDORA_BOOK_MARK_ALLOWED:

            HSA_AVDC_Audio__blIsPandoraBookMarkAllowed();
            break;

        case HSA_API_ENTRYPOINT__IS_PANDORA_NEW_STATION_CREATION_ALLOWED:

            HSA_AVDC_Audio__blIsPandoraNewStationCreationAllowed();
            break;

        case HSA_API_ENTRYPOINT__IS_PANDORA_STATION_DELETION_ALLOWED:

            HSA_AVDC_Audio__blIsPandoraStationDeletionAllowed();
            break;

        case HSA_API_ENTRYPOINT__IS_PANDORA_SOURCE_ACTIVE:

            HSA_AVDC_Audio__blIsPandoraSourceActive();
            break;

        case HSA_API_ENTRYPOINT__IS_PANDORA_NO_STATION_ACTIVE:

            HSA_AVDC_Audio__blIsPandoraNoStationActive();
            break;

        case HSA_API_ENTRYPOINT__PANDORA_PLAY_CONTROL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC_Audio__vPandoraPlayControl(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PANDORA_TRACK_RATING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC_Audio__vPandoraTrackRating(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__LOAD_PANDORA_STATION_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC_Audio__vLoadPandoraStationList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PANDORA_STATION_CREATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC_Audio__vPandoraStationCreate(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PANDORA_STATION_SELECT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC_Audio__vPandoraStationSelect(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PANDORA_STATION_DELETE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC_Audio__vPandoraStationDelete(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PANDORA_BOOK_MARK:

            HSA_AVDC_Audio__vPandoraBookMark();
            break;

        case HSA_API_ENTRYPOINT__PANDORA_SKIP_TRACK:

            HSA_AVDC_Audio__vPandoraSkipTrack();
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

