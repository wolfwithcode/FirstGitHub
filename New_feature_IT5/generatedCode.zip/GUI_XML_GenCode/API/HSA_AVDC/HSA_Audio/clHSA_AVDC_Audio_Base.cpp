/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_AVDC_Audio_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_AVDC/HSA_Audio/clHSA_AVDC_Audio_Base.h"

clHSA_AVDC_Audio_Base* clHSA_AVDC_Audio_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_AVDC_Audio_Base.cpp.trc.h"
#endif


/**
 * Method: vSetPlay
  * Set play
  * NISSAN
 */
void clHSA_AVDC_Audio_Base::vSetPlay( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vSetPlay not implemented"));
   
}

/**
 * Method: vSetStop
  * Set stop
  * NISSAN
 */
void clHSA_AVDC_Audio_Base::vSetStop( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vSetStop not implemented"));
   
}

/**
 * Method: vActivateMDI
  * Activates the selected mobile device from the MDI list (see media setup menu).
  * B
 */
void clHSA_AVDC_Audio_Base::vActivateMDI(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vActivateMDI not implemented"));
   
}

/**
 * Method: vActivateMode
  * Activates or deactivates the selected mode (Scan/ Mix/ Repeat). Only one of them can be active. The mode which was active before will be deactivated. Hint: For portable devices this function must be linked to the concerning BAP functions. See Function Catalog - MDI.
  * B
 */
void clHSA_AVDC_Audio_Base::vActivateMode(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vActivateMode not implemented"));
   
}

/**
 * Method: vActivateNextTrack
  * Starts playing the next track Hint: For portable devices this function must be linked to the concerning BAP functions. See Function Catalog - MDI.
  * B1
 */
void clHSA_AVDC_Audio_Base::vActivateNextTrack( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vActivateNextTrack not implemented"));
   
}

/**
 * Method: vActivatePreviousTrack
  * Starts playing the previous track if the function is called during the first 2 s of the current track. If the current track is playing longer than 2s jump to the beginning of the current track. Hint: For portable devices this function must be linked to the concerning BAP functions. See Function Catalog - MDI.
  * B1
 */
void clHSA_AVDC_Audio_Base::vActivatePreviousTrack( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vActivatePreviousTrack not implemented"));
   
}

/**
 * Method: vFastForward
  * Starts the function fast forward on the current track. Hint: For portable devices this function must be linked to the concerning BAP functions. See Function Catalog - MDI.
  * B1
 */
void clHSA_AVDC_Audio_Base::vFastForward( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vFastForward not implemented"));
   
}

/**
 * Method: slwGetActiveBrowserItem
  * Returns the index of the active file/ folder/ playlist in the current browser-level. Returns -1 when no file/ folder/ playlist is active in the current browsing-level
  * B2
 */
slword clHSA_AVDC_Audio_Base::slwGetActiveBrowserItem( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_AVDC_Audio::slwGetActiveBrowserItem not implemented"));
   return 0;
}

/**
 * Method: vGetActiveMDIName
  * Returns the name of the active portable device.
  * B
 */
void clHSA_AVDC_Audio_Base::vGetActiveMDIName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vGetActiveMDIName not implemented"));
   
}

/**
 * Method: ulwGetActiveMDINumber
  * Returns the index of the active portable device( the position of this device inside the MDI list (ListEntryNr)). 
  * B
 */
ulword clHSA_AVDC_Audio_Base::ulwGetActiveMDINumber( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetActiveMDINumber not implemented"));
   return 0;
}

/**
 * Method: ulwGetArtistNameDisplayLinesNr
  * Returns the number of lines needed to display the ArtistName
  * B1 [will always return 1]
 */
ulword clHSA_AVDC_Audio_Base::ulwGetArtistNameDisplayLinesNr( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetArtistNameDisplayLinesNr not implemented"));
   return 0;
}

/**
 * Method: blIsIndexingComplete
  * Returns the state of indexing completed or not. 
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blIsIndexingComplete( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsIndexingComplete not implemented"));
   return 0;
}

/**
 * Method: ulwGetIndexingStatus
  * Returns the value of the Indexing State of iPod  
  * B
 */
ulword clHSA_AVDC_Audio_Base::ulwGetIndexingStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetIndexingStatus not implemented"));
   return 0;
}

/**
 * Method: blStartIpodIndexing
  * Triggers HMI to start Indexing
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blStartIpodIndexing( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blStartIpodIndexing not implemented"));
   return 0;
}

/**
 * Method: vGetIndexingState
  * Returns the indexing state of the Active media devices. 
  * B1
 */
void clHSA_AVDC_Audio_Base::vGetIndexingState(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vGetIndexingState not implemented"));
   
}

/**
 * Method: vGetCoverArtImage
  * Returns the cover art image of the currently playing track. 
  * B1
 */
void clHSA_AVDC_Audio_Base::vGetCoverArtImage(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vGetCoverArtImage not implemented"));
   
}

/**
 * Method: vGetCoverArtImageInfo
  * Returns information about the current track album art image.
  * B1
 */
void clHSA_AVDC_Audio_Base::vGetCoverArtImageInfo(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vGetCoverArtImageInfo not implemented"));
   
}

/**
 * Method: ulwGetAudioSourceState
  * Returns the state of the available audio source.
  * B1
 */
ulword clHSA_AVDC_Audio_Base::ulwGetAudioSourceState(ulword ulwEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetAudioSourceState not implemented"));
   return 0;
}

/**
 * Method: ulwGetBTAudioFileInfoType
  * Returns the type of the file information for the active file when BT is the active media source. (ID3 tag or device name). 
  * B
 */
ulword clHSA_AVDC_Audio_Base::ulwGetBTAudioFileInfoType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetBTAudioFileInfoType not implemented"));
   return 0;
}

/**
 * Method: ulwGetCDType
  * Returns the datatype of the current disc 
  * B1
 */
ulword clHSA_AVDC_Audio_Base::ulwGetCDType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetCDType not implemented"));
   return 0;
}

/**
 * Method: slwGetCurrentCDCDiscNr
  * Returns the number of the active disc of the cd changer. If no disc is active the function returns -1.
  * B
 */
slword clHSA_AVDC_Audio_Base::slwGetCurrentCDCDiscNr( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_AVDC_Audio::slwGetCurrentCDCDiscNr not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentMode
  * Returns the active mode of the player functions ( scan, mix, repeat). If the state changes, the new state has to be sent. Hint: For portable devices this function must be linked to the concerning BAP functions. See Function Catalog - MDI.
  * B1
 */
ulword clHSA_AVDC_Audio_Base::ulwGetCurrentMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetCurrentMode not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentTrackExtraInfo
  * Returns extra-information about the current track: FileName, FolderName
  * B
 */
void clHSA_AVDC_Audio_Base::vGetCurrentTrackExtraInfo(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vGetCurrentTrackExtraInfo not implemented"));
   
}

/**
 * Method: vGetCurrentTrackInfo
  * Returns information about the current track. If there is no trackname available return the filename. For mobile devices this function must be linked to the BAP functions: CurrentTitleInfo and CurrentFileName. See Function Catalog - MDI.
  * B1
 */
void clHSA_AVDC_Audio_Base::vGetCurrentTrackInfo(GUI_String *out_result, ulword uwArrayIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(uwArrayIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vGetCurrentTrackInfo not implemented"));
   
}

/**
 * Method: ulwGetCurrentTrackNr
  * Returns the track number of the current track. 
  * B1
 */
ulword clHSA_AVDC_Audio_Base::ulwGetCurrentTrackNr( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetCurrentTrackNr not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentMedialistIdentifier
  * Returns a value which can be used to identify lists and folders. The value returned should be the same when the same folder is queried. It should differ if another folder is shown. The value is to be used as a hash-key. Ordering and number range make no diffrence.
  * B1
 */
ulword clHSA_AVDC_Audio_Base::ulwGetCurrentMedialistIdentifier( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetCurrentMedialistIdentifier not implemented"));
   return 0;
}

/**
 * Method: vGetElapsedTimeOfTrack
  * Returns the elapsed time of the current track as a formatted string (See FMT_PLAYTIME in the GUICatalog). See HMI-Statechart Mediaplayer page 5. Hint: For portable devices this function must be linked to the concerning BAP functions. See Function Catalog - MDI. 
  * B1
 */
void clHSA_AVDC_Audio_Base::vGetElapsedTimeOfTrack(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vGetElapsedTimeOfTrack not implemented"));
   
}

/**
 * Method: ulwGetElapsedTimeOfTrackInSeconds
  * Returns the elapsed time of the current track in seconds. See HMI-Statechart Mediaplayer page 5. Note: returns 0 if variable bit rate (VBR). Hint: For portable devices this function must be linked to the concerning BAP functions. See Function Catalog - MDI.
  * B1
 */
ulword clHSA_AVDC_Audio_Base::ulwGetElapsedTimeOfTrackInSeconds( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetElapsedTimeOfTrackInSeconds not implemented"));
   return 0;
}

/**
 * Method: blGetIncludeSubFoldersState
  * Returns wheather the scan/ mix/ repeat operations will consider also the subfolders of a folder
  * B
 */
tbool clHSA_AVDC_Audio_Base::blGetIncludeSubFoldersState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blGetIncludeSubFoldersState not implemented"));
   return 0;
}

/**
 * Method: ulwGetMDIActivatingState
  * returns a status regarding the activating-operation of a MDI
  * B
 */
ulword clHSA_AVDC_Audio_Base::ulwGetMDIActivatingState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetMDIActivatingState not implemented"));
   return 0;
}

/**
 * Method: ulwGetMDIFileInfoType
  * Returns the type of the file information for the active file. (ID3 tag or title name or file number or no information) This can be requested with the corresponding BAP functions. See Function Catalog - MDI.
  * B
 */
ulword clHSA_AVDC_Audio_Base::ulwGetMDIFileInfoType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetMDIFileInfoType not implemented"));
   return 0;
}

/**
 * Method: ulwGetMDIListCount
  * Returns the number of mobile devices.
  * B
 */
ulword clHSA_AVDC_Audio_Base::ulwGetMDIListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetMDIListCount not implemented"));
   return 0;
}

/**
 * Method: vGetMDIListItems
  * Returns a string with  the names of  the connected MDIs
  * B
 */
void clHSA_AVDC_Audio_Base::vGetMDIListItems(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vGetMDIListItems not implemented"));
   
}

/**
 * Method: ulwGetMDIListLoadingState
  * Returns 1 if the list of MDIs is completely loaded, 0 if the loading process is still in progress.
  * B
 */
ulword clHSA_AVDC_Audio_Base::ulwGetMDIListLoadingState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetMDIListLoadingState not implemented"));
   return 0;
}

/**
 * Method: ulwGetMDIOperationState
  * Returns the operation state of the portable device. This can be requested with the concerning BAP functions. See Function Catalog - MDI.
  * B
 */
ulword clHSA_AVDC_Audio_Base::ulwGetMDIOperationState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetMDIOperationState not implemented"));
   return 0;
}

/**
 * Method: vGetRemainingTimeOfTrack
  * Returns the remaining time of the current track as a formatted string (See FMT_PLAYTIME_REMAIN in the GUICatalog). See HMI-Statechart Mediaplayer page 5. Hint: For portable devices this function must be linked to the concerning BAP functions. See Function Catalog - MDI.
  * B1
 */
void clHSA_AVDC_Audio_Base::vGetRemainingTimeOfTrack(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vGetRemainingTimeOfTrack not implemented"));
   
}

/**
 * Method: ulwGetTitleNameDisplayLinesNr
  * Returns the number of lines needed to display theTitleName
  * B1 [will always return 1]
 */
ulword clHSA_AVDC_Audio_Base::ulwGetTitleNameDisplayLinesNr( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetTitleNameDisplayLinesNr not implemented"));
   return 0;
}

/**
 * Method: ulwGetTotalTimeOfTrackInSeconds
  * Returns the total time of the current track in seconds. See HMI-Statechart Mediaplayer page 5. Note: returns 0 if variable bit rate (VBR).
  * B1
 */
ulword clHSA_AVDC_Audio_Base::ulwGetTotalTimeOfTrackInSeconds( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetTotalTimeOfTrackInSeconds not implemented"));
   return 0;
}

/**
 * Method: slwGetVBR
  * Returns wheather the selected title has a variable bitrate. This information is needed to disable the progress bar if no time information is available. See HMI-Statechart Mediaplayer page AudioPlayer_Main.
  * B1
 */
slword clHSA_AVDC_Audio_Base::slwGetVBR( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_AVDC_Audio::slwGetVBR not implemented"));
   return 0;
}

/**
 * Method: blIsBTAudioActive
  * Returns the availability of the BT-Audio source (used in media-setup)
  * B
 */
tbool clHSA_AVDC_Audio_Base::blIsBTAudioActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsBTAudioActive not implemented"));
   return 0;
}

/**
 * Method: ulwIsCDCDiscLoading
  * new - returns the disc loading status in CD-Changer
  * B
 */
ulword clHSA_AVDC_Audio_Base::ulwIsCDCDiscLoading( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwIsCDCDiscLoading not implemented"));
   return 0;
}

/**
 * Method: ulwIsCheckingAudioFilesForOpening
  * Used to open/ close a waiting screen when a folder is opened. The waiting screen is shown as long as this APICall returns 1. If the APICall returns 0, the waiting screen is closed
  * B2
 */
ulword clHSA_AVDC_Audio_Base::ulwIsCheckingAudioFilesForOpening( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwIsCheckingAudioFilesForOpening not implemented"));
   return 0;
}

/**
 * Method: ulwIsCheckingAudioFilesForPlaying
  * Used to open/ close a waiting screen when a folder is chosen to be played. The waiting screen is shown as long as this APICall returns 1. If the APICall returns 0, the waiting screen is closed
  * B2
 */
ulword clHSA_AVDC_Audio_Base::ulwIsCheckingAudioFilesForPlaying( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwIsCheckingAudioFilesForPlaying not implemented"));
   return 0;
}

/**
 * Method: blIsFunctionMixAllAvailable
  * Returns the availability of the function Mix all.
  * B
 */
tbool clHSA_AVDC_Audio_Base::blIsFunctionMixAllAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsFunctionMixAllAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsFunctionMixAvailable
  * Returns the availability of the function "Mix".
  * B
 */
tbool clHSA_AVDC_Audio_Base::blIsFunctionMixAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsFunctionMixAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsFunctionMixFolderAvailable
  * Returns the availability of the function "MixFolder".
  * B
 */
tbool clHSA_AVDC_Audio_Base::blIsFunctionMixFolderAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsFunctionMixFolderAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsFunctionMixPlaylistAvailable
  * Returns the availability of the function "MixPlaylist".
  * B
 */
tbool clHSA_AVDC_Audio_Base::blIsFunctionMixPlaylistAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsFunctionMixPlaylistAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsFunctionRepeatCDAvailable
  * Returns the availability of the function RepeatCD.
  * B
 */
tbool clHSA_AVDC_Audio_Base::blIsFunctionRepeatCDAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsFunctionRepeatCDAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsFunctionRepeatFolderAvailable
  * Returns the availability of the function "RepeatFolder".
  * B
 */
tbool clHSA_AVDC_Audio_Base::blIsFunctionRepeatFolderAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsFunctionRepeatFolderAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsFunctionRepeatPlaylistAvailable
  * Returns the availability of the function "RepeaPlaylistt".
  * B
 */
tbool clHSA_AVDC_Audio_Base::blIsFunctionRepeatPlaylistAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsFunctionRepeatPlaylistAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsFunctionRepeatTrackAvailable
  * Returns the availability of the function "RepeatTrack".
  * B
 */
tbool clHSA_AVDC_Audio_Base::blIsFunctionRepeatTrackAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsFunctionRepeatTrackAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsFunctionScanAvailable
  * Returns the availability of the function "Scan".
  * B
 */
tbool clHSA_AVDC_Audio_Base::blIsFunctionScanAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsFunctionScanAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsMDIListAvailable
  * Returns if the connected MDI box or UHV MM supports a list with available portable devices.
  * B
 */
tbool clHSA_AVDC_Audio_Base::blIsMDIListAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsMDIListAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwIsSelectedListItemInfoAvailable
  * Returns 1 - if Info about focused item in the Browser available 0 - if Info not available 2 - waiting for information
  * B2
 */
ulword clHSA_AVDC_Audio_Base::ulwIsSelectedListItemInfoAvailable(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwIsSelectedListItemInfoAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwIsSelectedTitleListItemInfoAvailable
  * Returns 1 - if Info about focused item in the TitleList available 0 - if Info not available 2 - waiting for information
  * B
 */
ulword clHSA_AVDC_Audio_Base::ulwIsSelectedTitleListItemInfoAvailable(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwIsSelectedTitleListItemInfoAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwLoadMDIList
  * Start loading the list of available portable devices. Should return an INT value: 0 = while loading 1 = when loaded
  * B
 */
ulword clHSA_AVDC_Audio_Base::ulwLoadMDIList( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwLoadMDIList not implemented"));
   return 0;
}

/**
 * Method: vRewind
  * Rewinds the current track. For mobile devices this function must be linked to the BAP function: "MDStatus.SetGet.FastBackward". See Function Catalog - MDI.
  * B1
 */
void clHSA_AVDC_Audio_Base::vRewind( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vRewind not implemented"));
   
}

/**
 * Method: vStopFastForward
  * Stops fast forwrding the current track.
  * B1
 */
void clHSA_AVDC_Audio_Base::vStopFastForward( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vStopFastForward not implemented"));
   
}

/**
 * Method: vStopRewind
  * Stops rewinding the current track.
  * B1
 */
void clHSA_AVDC_Audio_Base::vStopRewind( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vStopRewind not implemented"));
   
}

/**
 * Method: vToggleBTAudioState
  * Sets the state of the BT-Audio source (used in media-setup)
  * B
 */
void clHSA_AVDC_Audio_Base::vToggleBTAudioState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vToggleBTAudioState not implemented"));
   
}

/**
 * Method: vToggleIncludeSubFoldersState
  * Sets the state of the "Scan/ mix/ repeat with subfolders" option
  * B
 */
void clHSA_AVDC_Audio_Base::vToggleIncludeSubFoldersState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vToggleIncludeSubFoldersState not implemented"));
   
}

/**
 * Method: vGetPandoraStationName
  * Gets the name of the active Pandora station. If no name is available, send an empty string.
  * B1
 */
void clHSA_AVDC_Audio_Base::vGetPandoraStationName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vGetPandoraStationName not implemented"));
   
}

/**
 * Method: ulwGetPandoraErrorMessage
  *  Returns the integer value corresponding to the current Pandora error popup message. Returns 0 if there is no Error message
  * NISSAN
 */
ulword clHSA_AVDC_Audio_Base::ulwGetPandoraErrorMessage( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC_Audio::ulwGetPandoraErrorMessage not implemented"));
   return 0;
}

/**
 * Method: vGetPandoraStationIcon
  * Returns the UTF8 value of Icon in the stationlist,Mainly Icon for quickmix...
  * NISSAN 1.5
 */
void clHSA_AVDC_Audio_Base::vGetPandoraStationIcon(GUI_String *out_result, ulword ulwDynamicIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDynamicIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vGetPandoraStationIcon not implemented"));
   
}

/**
 * Method: vGetPandoraRatingIcon
  * Returns the unicode value of Icons for the Thumbs up/down
  * NISSAN 1.5
 */
void clHSA_AVDC_Audio_Base::vGetPandoraRatingIcon(GUI_String *out_result, ulword ulwRatingIcon)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRatingIcon);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vGetPandoraRatingIcon not implemented"));
   
}

/**
 * Method: blGetPandoraPlayStatus
  * Gets the current Station Play Status
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blGetPandoraPlayStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blGetPandoraPlayStatus not implemented"));
   return 0;
}

/**
 * Method: blGetPandoraLoadingStatus
  * Gets Whether data is still in Loading state, in this Scenario Wait animation needs to be shown. Different API used for list
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blGetPandoraLoadingStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blGetPandoraLoadingStatus not implemented"));
   return 0;
}

/**
 * Method: blGetPandoraListLoadingStatus
  * Gets Whether List data is still in Loading state, in this Scenario Wait animation needs to be shown.
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blGetPandoraListLoadingStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blGetPandoraListLoadingStatus not implemented"));
   return 0;
}

/**
 * Method: blIsPandoraRatingAllowed
  * Informs whether Rating is allowed for this track.If it returns false,Rating Icons shall be greyed out
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blIsPandoraRatingAllowed( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsPandoraRatingAllowed not implemented"));
   return 0;
}

/**
 * Method: blIsPandoraThumbsUp
  * Informs whether current track is rated Thumbs up
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blIsPandoraThumbsUp( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsPandoraThumbsUp not implemented"));
   return 0;
}

/**
 * Method: blIsPandoraThumbsDown
  * Informs whether current track is rated Thumbs Down
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blIsPandoraThumbsDown( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsPandoraThumbsDown not implemented"));
   return 0;
}

/**
 * Method: blIsPandoraBookMarkAllowed
  * Informs whether current track can be Bookmarked. If it returns FALSE bookmark option shall be greyed out.
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blIsPandoraBookMarkAllowed( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsPandoraBookMarkAllowed not implemented"));
   return 0;
}

/**
 * Method: blIsPandoraNewStationCreationAllowed
  * Informs whether New station from Artist/song is allowed or not.If false Option should be greyed out
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blIsPandoraNewStationCreationAllowed( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsPandoraNewStationCreationAllowed not implemented"));
   return 0;
}

/**
 * Method: blIsPandoraStationDeletionAllowed
  * Informs whether Station deletion is allowed
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blIsPandoraStationDeletionAllowed( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsPandoraStationDeletionAllowed not implemented"));
   return 0;
}

/**
 * Method: blIsPandoraSourceActive
  * Returns whether current active Source is Pandora or not.May be useful for decision to show Popup
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blIsPandoraSourceActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsPandoraSourceActive not implemented"));
   return 0;
}

/**
 * Method: blIsPandoraNoStationActive
  * Returns whether any station is active, this shall be required to prompt Station List to user on Selection of Pandora source.
  * B1
 */
tbool clHSA_AVDC_Audio_Base::blIsPandoraNoStationActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC_Audio::blIsPandoraNoStationActive not implemented"));
   return 0;
}

/**
 * Method: vPandoraPlayControl
  * Informs user action of Play/Pause
  * B1
 */
void clHSA_AVDC_Audio_Base::vPandoraPlayControl(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vPandoraPlayControl not implemented"));
   
}

/**
 * Method: vPandoraTrackRating
  * Informs user action Rating to Pandora server
  * B1
 */
void clHSA_AVDC_Audio_Base::vPandoraTrackRating(ulword ulwRating)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRating);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vPandoraTrackRating not implemented"));
   
}

/**
 * Method: vLoadPandoraStationList
  * Call to activate Station List OR Delete list
  * B1
 */
void clHSA_AVDC_Audio_Base::vLoadPandoraStationList(ulword ulwListType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vLoadPandoraStationList not implemented"));
   
}

/**
 * Method: vPandoraStationCreate
  * Call to Create new Pandora station
  * B1
 */
void clHSA_AVDC_Audio_Base::vPandoraStationCreate(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vPandoraStationCreate not implemented"));
   
}

/**
 * Method: vPandoraStationSelect
  * This API is called when user selects new station to play from List
  * 
 */
void clHSA_AVDC_Audio_Base::vPandoraStationSelect(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vPandoraStationSelect not implemented"));
   
}

/**
 * Method: vPandoraStationDelete
  * This API is called when user Confirms to delete a station from Delete List
  * 
 */
void clHSA_AVDC_Audio_Base::vPandoraStationDelete(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vPandoraStationDelete not implemented"));
   
}

/**
 * Method: vPandoraBookMark
  * This api called when user Bookmarks the current song
  * 
 */
void clHSA_AVDC_Audio_Base::vPandoraBookMark( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vPandoraBookMark not implemented"));
   
}

/**
 * Method: vPandoraSkipTrack
  * This api called when user Skips track
  * 
 */
void clHSA_AVDC_Audio_Base::vPandoraSkipTrack( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC_Audio::vPandoraSkipTrack not implemented"));
   
}

