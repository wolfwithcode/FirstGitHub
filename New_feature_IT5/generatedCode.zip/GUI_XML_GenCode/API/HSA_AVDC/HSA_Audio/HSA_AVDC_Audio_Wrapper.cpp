/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_AVDC_Audio_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_AVDC_Audio_Wrapper.h"
#include "clHSA_AVDC_Audio_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_AVDC_Audio_Trace.h"
#include "hmi_trace.h"

void HSA_AVDC_Audio__vSetPlay( )
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SET_PLAY  ) ); 
        }
      pInst->vSetPlay();

    }
}

void HSA_AVDC_Audio__vSetStop( )
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SET_STOP  ) ); 
        }
      pInst->vSetStop();

    }
}

void HSA_AVDC_Audio__vActivateMDI(ulword ulwListEntryNr)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_MDI | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vActivateMDI(ulwListEntryNr);

    }
}

void HSA_AVDC_Audio__vActivateMode(ulword ulwMode)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vActivateMode(ulwMode);

    }
}

void HSA_AVDC_Audio__vActivateNextTrack( )
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_NEXT_TRACK  ) ); 
        }
      pInst->vActivateNextTrack();

    }
}

void HSA_AVDC_Audio__vActivatePreviousTrack( )
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_PREVIOUS_TRACK  ) ); 
        }
      pInst->vActivatePreviousTrack();

    }
}

void HSA_AVDC_Audio__vFastForward( )
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__FAST_FORWARD  ) ); 
        }
      pInst->vFastForward();

    }
}

slword HSA_AVDC_Audio__slwGetActiveBrowserItem( )
{
    slword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_BROWSER_ITEM  ) ); 
        }
      ret=pInst->slwGetActiveBrowserItem();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_BROWSER_ITEM | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC_Audio__vGetActiveMDIName(GUI_String *out_result)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_MDI_NAME  ) ); 
        }
      pInst->vGetActiveMDIName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_MDI_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_AVDC_Audio__ulwGetActiveMDINumber( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_MDI_NUMBER  ) ); 
        }
      ret=pInst->ulwGetActiveMDINumber();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_MDI_NUMBER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwGetArtistNameDisplayLinesNr( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ARTIST_NAME_DISPLAY_LINES_NR  ) ); 
        }
      ret=pInst->ulwGetArtistNameDisplayLinesNr();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ARTIST_NAME_DISPLAY_LINES_NR | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsIndexingComplete( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_INDEXING_COMPLETE  ) ); 
        }
      ret=pInst->blIsIndexingComplete();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_INDEXING_COMPLETE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwGetIndexingStatus( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_INDEXING_STATUS  ) ); 
        }
      ret=pInst->ulwGetIndexingStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_INDEXING_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blStartIpodIndexing( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__START_IPOD_INDEXING  ) ); 
        }
      ret=pInst->blStartIpodIndexing();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__START_IPOD_INDEXING | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC_Audio__vGetIndexingState(GUI_String *out_result)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_INDEXING_STATE  ) ); 
        }
      pInst->vGetIndexingState(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_INDEXING_STATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_AVDC_Audio__vGetCoverArtImage(GUI_String *out_result)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_COVER_ART_IMAGE  ) ); 
        }
      pInst->vGetCoverArtImage(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_COVER_ART_IMAGE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_AVDC_Audio__vGetCoverArtImageInfo(GUI_String *out_result)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_COVER_ART_IMAGE_INFO  ) ); 
        }
      pInst->vGetCoverArtImageInfo(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_COVER_ART_IMAGE_INFO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_AVDC_Audio__ulwGetAudioSourceState(ulword ulwEntryNr)
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_AUDIO_SOURCE_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
        }
      ret=pInst->ulwGetAudioSourceState(ulwEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_AUDIO_SOURCE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwGetBTAudioFileInfoType( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_BT_AUDIO_FILE_INFO_TYPE  ) ); 
        }
      ret=pInst->ulwGetBTAudioFileInfoType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_BT_AUDIO_FILE_INFO_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwGetCDType( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CD_TYPE  ) ); 
        }
      ret=pInst->ulwGetCDType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CD_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_AVDC_Audio__slwGetCurrentCDCDiscNr( )
{
    slword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CDC_DISC_NR  ) ); 
        }
      ret=pInst->slwGetCurrentCDCDiscNr();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CDC_DISC_NR | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwGetCurrentMode( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MODE  ) ); 
        }
      ret=pInst->ulwGetCurrentMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC_Audio__vGetCurrentTrackExtraInfo(GUI_String *out_result)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TRACK_EXTRA_INFO  ) ); 
        }
      pInst->vGetCurrentTrackExtraInfo(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TRACK_EXTRA_INFO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_AVDC_Audio__vGetCurrentTrackInfo(GUI_String *out_result, ulword uwArrayIndex)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TRACK_INFO )  );
             poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TRACK_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&uwArrayIndex); 
        }
      pInst->vGetCurrentTrackInfo(out_result, uwArrayIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TRACK_INFO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_AVDC_Audio__ulwGetCurrentTrackNr( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TRACK_NR  ) ); 
        }
      ret=pInst->ulwGetCurrentTrackNr();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TRACK_NR | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwGetCurrentMedialistIdentifier( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MEDIALIST_IDENTIFIER  ) ); 
        }
      ret=pInst->ulwGetCurrentMedialistIdentifier();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MEDIALIST_IDENTIFIER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC_Audio__vGetElapsedTimeOfTrack(GUI_String *out_result)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ELAPSED_TIME_OF_TRACK  ) ); 
        }
      pInst->vGetElapsedTimeOfTrack(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ELAPSED_TIME_OF_TRACK | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_AVDC_Audio__ulwGetElapsedTimeOfTrackInSeconds( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ELAPSED_TIME_OF_TRACK_IN_SECONDS  ) ); 
        }
      ret=pInst->ulwGetElapsedTimeOfTrackInSeconds();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ELAPSED_TIME_OF_TRACK_IN_SECONDS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blGetIncludeSubFoldersState( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_INCLUDE_SUB_FOLDERS_STATE  ) ); 
        }
      ret=pInst->blGetIncludeSubFoldersState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_INCLUDE_SUB_FOLDERS_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwGetMDIActivatingState( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_ACTIVATING_STATE  ) ); 
        }
      ret=pInst->ulwGetMDIActivatingState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_ACTIVATING_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwGetMDIFileInfoType( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_FILE_INFO_TYPE  ) ); 
        }
      ret=pInst->ulwGetMDIFileInfoType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_FILE_INFO_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwGetMDIListCount( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetMDIListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC_Audio__vGetMDIListItems(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_LIST_ITEMS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetMDIListItems(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_LIST_ITEMS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_AVDC_Audio__ulwGetMDIListLoadingState( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_LIST_LOADING_STATE  ) ); 
        }
      ret=pInst->ulwGetMDIListLoadingState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_LIST_LOADING_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwGetMDIOperationState( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_OPERATION_STATE  ) ); 
        }
      ret=pInst->ulwGetMDIOperationState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_OPERATION_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC_Audio__vGetRemainingTimeOfTrack(GUI_String *out_result)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_REMAINING_TIME_OF_TRACK  ) ); 
        }
      pInst->vGetRemainingTimeOfTrack(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_REMAINING_TIME_OF_TRACK | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_AVDC_Audio__ulwGetTitleNameDisplayLinesNr( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_TITLE_NAME_DISPLAY_LINES_NR  ) ); 
        }
      ret=pInst->ulwGetTitleNameDisplayLinesNr();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_TITLE_NAME_DISPLAY_LINES_NR | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwGetTotalTimeOfTrackInSeconds( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_TOTAL_TIME_OF_TRACK_IN_SECONDS  ) ); 
        }
      ret=pInst->ulwGetTotalTimeOfTrackInSeconds();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_TOTAL_TIME_OF_TRACK_IN_SECONDS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_AVDC_Audio__slwGetVBR( )
{
    slword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_VBR  ) ); 
        }
      ret=pInst->slwGetVBR();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_VBR | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsBTAudioActive( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_BT_AUDIO_ACTIVE  ) ); 
        }
      ret=pInst->blIsBTAudioActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_BT_AUDIO_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwIsCDCDiscLoading( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CDC_DISC_LOADING  ) ); 
        }
      ret=pInst->ulwIsCDCDiscLoading();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CDC_DISC_LOADING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwIsCheckingAudioFilesForOpening( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CHECKING_AUDIO_FILES_FOR_OPENING  ) ); 
        }
      ret=pInst->ulwIsCheckingAudioFilesForOpening();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CHECKING_AUDIO_FILES_FOR_OPENING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwIsCheckingAudioFilesForPlaying( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CHECKING_AUDIO_FILES_FOR_PLAYING  ) ); 
        }
      ret=pInst->ulwIsCheckingAudioFilesForPlaying();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CHECKING_AUDIO_FILES_FOR_PLAYING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsFunctionMixAllAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_MIX_ALL_AVAILABLE  ) ); 
        }
      ret=pInst->blIsFunctionMixAllAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_MIX_ALL_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsFunctionMixAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_MIX_AVAILABLE  ) ); 
        }
      ret=pInst->blIsFunctionMixAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_MIX_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsFunctionMixFolderAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_MIX_FOLDER_AVAILABLE  ) ); 
        }
      ret=pInst->blIsFunctionMixFolderAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_MIX_FOLDER_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsFunctionMixPlaylistAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_MIX_PLAYLIST_AVAILABLE  ) ); 
        }
      ret=pInst->blIsFunctionMixPlaylistAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_MIX_PLAYLIST_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsFunctionRepeatCDAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_REPEAT_CD_AVAILABLE  ) ); 
        }
      ret=pInst->blIsFunctionRepeatCDAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_REPEAT_CD_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsFunctionRepeatFolderAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_REPEAT_FOLDER_AVAILABLE  ) ); 
        }
      ret=pInst->blIsFunctionRepeatFolderAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_REPEAT_FOLDER_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsFunctionRepeatPlaylistAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_REPEAT_PLAYLIST_AVAILABLE  ) ); 
        }
      ret=pInst->blIsFunctionRepeatPlaylistAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_REPEAT_PLAYLIST_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsFunctionRepeatTrackAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_REPEAT_TRACK_AVAILABLE  ) ); 
        }
      ret=pInst->blIsFunctionRepeatTrackAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_REPEAT_TRACK_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsFunctionScanAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_SCAN_AVAILABLE  ) ); 
        }
      ret=pInst->blIsFunctionScanAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_FUNCTION_SCAN_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsMDIListAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_MDI_LIST_AVAILABLE  ) ); 
        }
      ret=pInst->blIsMDIListAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_MDI_LIST_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwIsSelectedListItemInfoAvailable(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_SELECTED_LIST_ITEM_INFO_AVAILABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwIsSelectedListItemInfoAvailable(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_SELECTED_LIST_ITEM_INFO_AVAILABLE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwIsSelectedTitleListItemInfoAvailable(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_SELECTED_TITLE_LIST_ITEM_INFO_AVAILABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwIsSelectedTitleListItemInfoAvailable(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_SELECTED_TITLE_LIST_ITEM_INFO_AVAILABLE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC_Audio__ulwLoadMDIList( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__LOAD_MDI_LIST  ) ); 
        }
      ret=pInst->ulwLoadMDIList();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__LOAD_MDI_LIST | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC_Audio__vRewind( )
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__REWIND  ) ); 
        }
      pInst->vRewind();

    }
}

void HSA_AVDC_Audio__vStopFastForward( )
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__STOP_FAST_FORWARD  ) ); 
        }
      pInst->vStopFastForward();

    }
}

void HSA_AVDC_Audio__vStopRewind( )
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__STOP_REWIND  ) ); 
        }
      pInst->vStopRewind();

    }
}

void HSA_AVDC_Audio__vToggleBTAudioState( )
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_BT_AUDIO_STATE  ) ); 
        }
      pInst->vToggleBTAudioState();

    }
}

void HSA_AVDC_Audio__vToggleIncludeSubFoldersState( )
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_INCLUDE_SUB_FOLDERS_STATE  ) ); 
        }
      pInst->vToggleIncludeSubFoldersState();

    }
}

void HSA_AVDC_Audio__vGetPandoraStationName(GUI_String *out_result)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_STATION_NAME  ) ); 
        }
      pInst->vGetPandoraStationName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_STATION_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_AVDC_Audio__ulwGetPandoraErrorMessage( )
{
    ulword ret = 0;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_ERROR_MESSAGE  ) ); 
        }
      ret=pInst->ulwGetPandoraErrorMessage();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_ERROR_MESSAGE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC_Audio__vGetPandoraStationIcon(GUI_String *out_result, ulword ulwDynamicIndex)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_STATION_ICON | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDynamicIndex); 
        }
      pInst->vGetPandoraStationIcon(out_result, ulwDynamicIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_STATION_ICON | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_AVDC_Audio__vGetPandoraRatingIcon(GUI_String *out_result, ulword ulwRatingIcon)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_RATING_ICON | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRatingIcon); 
        }
      pInst->vGetPandoraRatingIcon(out_result, ulwRatingIcon);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_RATING_ICON | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_AVDC_Audio__blGetPandoraPlayStatus( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_PLAY_STATUS  ) ); 
        }
      ret=pInst->blGetPandoraPlayStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_PLAY_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blGetPandoraLoadingStatus( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_LOADING_STATUS  ) ); 
        }
      ret=pInst->blGetPandoraLoadingStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_LOADING_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blGetPandoraListLoadingStatus( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_LIST_LOADING_STATUS  ) ); 
        }
      ret=pInst->blGetPandoraListLoadingStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PANDORA_LIST_LOADING_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsPandoraRatingAllowed( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_RATING_ALLOWED  ) ); 
        }
      ret=pInst->blIsPandoraRatingAllowed();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_RATING_ALLOWED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsPandoraThumbsUp( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_THUMBS_UP  ) ); 
        }
      ret=pInst->blIsPandoraThumbsUp();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_THUMBS_UP | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsPandoraThumbsDown( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_THUMBS_DOWN  ) ); 
        }
      ret=pInst->blIsPandoraThumbsDown();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_THUMBS_DOWN | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsPandoraBookMarkAllowed( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_BOOK_MARK_ALLOWED  ) ); 
        }
      ret=pInst->blIsPandoraBookMarkAllowed();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_BOOK_MARK_ALLOWED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsPandoraNewStationCreationAllowed( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_NEW_STATION_CREATION_ALLOWED  ) ); 
        }
      ret=pInst->blIsPandoraNewStationCreationAllowed();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_NEW_STATION_CREATION_ALLOWED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsPandoraStationDeletionAllowed( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_STATION_DELETION_ALLOWED  ) ); 
        }
      ret=pInst->blIsPandoraStationDeletionAllowed();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_STATION_DELETION_ALLOWED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsPandoraSourceActive( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_SOURCE_ACTIVE  ) ); 
        }
      ret=pInst->blIsPandoraSourceActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_SOURCE_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC_Audio__blIsPandoraNoStationActive( )
{
    tbool ret = false;
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_NO_STATION_ACTIVE  ) ); 
        }
      ret=pInst->blIsPandoraNoStationActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_PANDORA_NO_STATION_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC_Audio__vPandoraPlayControl(ulword ulwMode)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__PANDORA_PLAY_CONTROL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vPandoraPlayControl(ulwMode);

    }
}

void HSA_AVDC_Audio__vPandoraTrackRating(ulword ulwRating)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__PANDORA_TRACK_RATING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRating); 
        }
      pInst->vPandoraTrackRating(ulwRating);

    }
}

void HSA_AVDC_Audio__vLoadPandoraStationList(ulword ulwListType)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__LOAD_PANDORA_STATION_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListType); 
        }
      pInst->vLoadPandoraStationList(ulwListType);

    }
}

void HSA_AVDC_Audio__vPandoraStationCreate(ulword ulwMode)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__PANDORA_STATION_CREATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vPandoraStationCreate(ulwMode);

    }
}

void HSA_AVDC_Audio__vPandoraStationSelect(ulword ulwListIndex)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__PANDORA_STATION_SELECT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vPandoraStationSelect(ulwListIndex);

    }
}

void HSA_AVDC_Audio__vPandoraStationDelete(ulword ulwListIndex)
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__PANDORA_STATION_DELETE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vPandoraStationDelete(ulwListIndex);

    }
}

void HSA_AVDC_Audio__vPandoraBookMark( )
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__PANDORA_BOOK_MARK  ) ); 
        }
      pInst->vPandoraBookMark();

    }
}

void HSA_AVDC_Audio__vPandoraSkipTrack( )
{
    
    clHSA_AVDC_Audio_Base *pInst=clHSA_AVDC_Audio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC_AUDIO), (tU16)(HSA_API_ENTRYPOINT__PANDORA_SKIP_TRACK  ) ); 
        }
      pInst->vPandoraSkipTrack();

    }
}

#ifdef __cplusplus
}
#endif

