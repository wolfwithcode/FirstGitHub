/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_AVDC_Audio_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_AVDC_Audio_Wrapper_H
#define _HSA_AVDC_Audio_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: SetPlay
 * NISSAN
 * NISSAN
 */
void HSA_AVDC_Audio__vSetPlay( void);

/**
 * Function: SetStop
 * NISSAN
 * NISSAN
 */
void HSA_AVDC_Audio__vSetStop( void);

/**
 * Function: ActivateMDI
 * B
 * NISSAN
 */
void HSA_AVDC_Audio__vActivateMDI(ulword ulwListEntryNr);

/**
 * Function: ActivateMode
 * B
 * NISSAN
 */
void HSA_AVDC_Audio__vActivateMode(ulword ulwMode);

/**
 * Function: ActivateNextTrack
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vActivateNextTrack( void);

/**
 * Function: ActivatePreviousTrack
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vActivatePreviousTrack( void);

/**
 * Function: FastForward
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vFastForward( void);

/**
 * Function: GetActiveBrowserItem
 * B2
 * NISSAN
 */
slword HSA_AVDC_Audio__slwGetActiveBrowserItem( void);

/**
 * Function: GetActiveMDIName
 * B
 * NISSAN
 */
void HSA_AVDC_Audio__vGetActiveMDIName(GUI_String *out_result);

/**
 * Function: GetActiveMDINumber
 * B
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetActiveMDINumber( void);

/**
 * Function: GetArtistNameDisplayLinesNr
 * B1 [will always return 1]
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetArtistNameDisplayLinesNr( void);

/**
 * Function: IsIndexingComplete
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsIndexingComplete( void);

/**
 * Function: GetIndexingStatus
 * B
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetIndexingStatus( void);

/**
 * Function: StartIpodIndexing
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blStartIpodIndexing( void);

/**
 * Function: GetIndexingState
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vGetIndexingState(GUI_String *out_result);

/**
 * Function: GetCoverArtImage
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vGetCoverArtImage(GUI_String *out_result);

/**
 * Function: GetCoverArtImageInfo
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vGetCoverArtImageInfo(GUI_String *out_result);

/**
 * Function: GetAudioSourceState
 * B1
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetAudioSourceState(ulword ulwEntryNr);

/**
 * Function: GetBTAudioFileInfoType
 * B
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetBTAudioFileInfoType( void);

/**
 * Function: GetCDType
 * B1
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetCDType( void);

/**
 * Function: GetCurrentCDCDiscNr
 * B
 * NISSAN
 */
slword HSA_AVDC_Audio__slwGetCurrentCDCDiscNr( void);

/**
 * Function: GetCurrentMode
 * B1
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetCurrentMode( void);

/**
 * Function: GetCurrentTrackExtraInfo
 * B
 * NISSAN
 */
void HSA_AVDC_Audio__vGetCurrentTrackExtraInfo(GUI_String *out_result);

/**
 * Function: GetCurrentTrackInfo
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vGetCurrentTrackInfo(GUI_String *out_result, ulword uwArrayIndex);

/**
 * Function: GetCurrentTrackNr
 * B1
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetCurrentTrackNr( void);

/**
 * Function: GetCurrentMedialistIdentifier
 * B1
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetCurrentMedialistIdentifier( void);

/**
 * Function: GetElapsedTimeOfTrack
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vGetElapsedTimeOfTrack(GUI_String *out_result);

/**
 * Function: GetElapsedTimeOfTrackInSeconds
 * B1
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetElapsedTimeOfTrackInSeconds( void);

/**
 * Function: GetIncludeSubFoldersState
 * B
 * NISSAN
 */
tbool HSA_AVDC_Audio__blGetIncludeSubFoldersState( void);

/**
 * Function: GetMDIActivatingState
 * B
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetMDIActivatingState( void);

/**
 * Function: GetMDIFileInfoType
 * B
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetMDIFileInfoType( void);

/**
 * Function: GetMDIListCount
 * B
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetMDIListCount( void);

/**
 * Function: GetMDIListItems
 * B
 * NISSAN
 */
void HSA_AVDC_Audio__vGetMDIListItems(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetMDIListLoadingState
 * B
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetMDIListLoadingState( void);

/**
 * Function: GetMDIOperationState
 * B
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetMDIOperationState( void);

/**
 * Function: GetRemainingTimeOfTrack
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vGetRemainingTimeOfTrack(GUI_String *out_result);

/**
 * Function: GetTitleNameDisplayLinesNr
 * B1 [will always return 1]
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetTitleNameDisplayLinesNr( void);

/**
 * Function: GetTotalTimeOfTrackInSeconds
 * B1
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetTotalTimeOfTrackInSeconds( void);

/**
 * Function: GetVBR
 * B1
 * NISSAN
 */
slword HSA_AVDC_Audio__slwGetVBR( void);

/**
 * Function: IsBTAudioActive
 * B
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsBTAudioActive( void);

/**
 * Function: IsCDCDiscLoading
 * B
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwIsCDCDiscLoading( void);

/**
 * Function: IsCheckingAudioFilesForOpening
 * B2
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwIsCheckingAudioFilesForOpening( void);

/**
 * Function: IsCheckingAudioFilesForPlaying
 * B2
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwIsCheckingAudioFilesForPlaying( void);

/**
 * Function: IsFunctionMixAllAvailable
 * B
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsFunctionMixAllAvailable( void);

/**
 * Function: IsFunctionMixAvailable
 * B
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsFunctionMixAvailable( void);

/**
 * Function: IsFunctionMixFolderAvailable
 * B
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsFunctionMixFolderAvailable( void);

/**
 * Function: IsFunctionMixPlaylistAvailable
 * B
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsFunctionMixPlaylistAvailable( void);

/**
 * Function: IsFunctionRepeatCDAvailable
 * B
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsFunctionRepeatCDAvailable( void);

/**
 * Function: IsFunctionRepeatFolderAvailable
 * B
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsFunctionRepeatFolderAvailable( void);

/**
 * Function: IsFunctionRepeatPlaylistAvailable
 * B
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsFunctionRepeatPlaylistAvailable( void);

/**
 * Function: IsFunctionRepeatTrackAvailable
 * B
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsFunctionRepeatTrackAvailable( void);

/**
 * Function: IsFunctionScanAvailable
 * B
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsFunctionScanAvailable( void);

/**
 * Function: IsMDIListAvailable
 * B
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsMDIListAvailable( void);

/**
 * Function: IsSelectedListItemInfoAvailable
 * B2
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwIsSelectedListItemInfoAvailable(ulword ulwListEntryNr);

/**
 * Function: IsSelectedTitleListItemInfoAvailable
 * B
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwIsSelectedTitleListItemInfoAvailable(ulword ulwListEntryNr);

/**
 * Function: LoadMDIList
 * B
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwLoadMDIList( void);

/**
 * Function: Rewind
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vRewind( void);

/**
 * Function: StopFastForward
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vStopFastForward( void);

/**
 * Function: StopRewind
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vStopRewind( void);

/**
 * Function: ToggleBTAudioState
 * B
 * NISSAN
 */
void HSA_AVDC_Audio__vToggleBTAudioState( void);

/**
 * Function: ToggleIncludeSubFoldersState
 * B
 * NISSAN
 */
void HSA_AVDC_Audio__vToggleIncludeSubFoldersState( void);

/**
 * Function: GetPandoraStationName
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vGetPandoraStationName(GUI_String *out_result);

/**
 * Function: GetPandoraErrorMessage
 * NISSAN
 * NISSAN
 */
ulword HSA_AVDC_Audio__ulwGetPandoraErrorMessage( void);

/**
 * Function: GetPandoraStationIcon
 * NISSAN 1.5
 * NISSAN
 */
void HSA_AVDC_Audio__vGetPandoraStationIcon(GUI_String *out_result, ulword ulwDynamicIndex);

/**
 * Function: GetPandoraRatingIcon
 * NISSAN 1.5
 * NISSAN
 */
void HSA_AVDC_Audio__vGetPandoraRatingIcon(GUI_String *out_result, ulword ulwRatingIcon);

/**
 * Function: GetPandoraPlayStatus
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blGetPandoraPlayStatus( void);

/**
 * Function: GetPandoraLoadingStatus
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blGetPandoraLoadingStatus( void);

/**
 * Function: GetPandoraListLoadingStatus
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blGetPandoraListLoadingStatus( void);

/**
 * Function: IsPandoraRatingAllowed
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsPandoraRatingAllowed( void);

/**
 * Function: IsPandoraThumbsUp
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsPandoraThumbsUp( void);

/**
 * Function: IsPandoraThumbsDown
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsPandoraThumbsDown( void);

/**
 * Function: IsPandoraBookMarkAllowed
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsPandoraBookMarkAllowed( void);

/**
 * Function: IsPandoraNewStationCreationAllowed
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsPandoraNewStationCreationAllowed( void);

/**
 * Function: IsPandoraStationDeletionAllowed
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsPandoraStationDeletionAllowed( void);

/**
 * Function: IsPandoraSourceActive
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsPandoraSourceActive( void);

/**
 * Function: IsPandoraNoStationActive
 * B1
 * NISSAN
 */
tbool HSA_AVDC_Audio__blIsPandoraNoStationActive( void);

/**
 * Function: PandoraPlayControl
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vPandoraPlayControl(ulword ulwMode);

/**
 * Function: PandoraTrackRating
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vPandoraTrackRating(ulword ulwRating);

/**
 * Function: LoadPandoraStationList
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vLoadPandoraStationList(ulword ulwListType);

/**
 * Function: PandoraStationCreate
 * B1
 * NISSAN
 */
void HSA_AVDC_Audio__vPandoraStationCreate(ulword ulwMode);

/**
 * Function: PandoraStationSelect
 * 
 * NISSAN
 */
void HSA_AVDC_Audio__vPandoraStationSelect(ulword ulwListIndex);

/**
 * Function: PandoraStationDelete
 * 
 * NISSAN
 */
void HSA_AVDC_Audio__vPandoraStationDelete(ulword ulwListIndex);

/**
 * Function: PandoraBookMark
 * 
 * NISSAN
 */
void HSA_AVDC_Audio__vPandoraBookMark( void);

/**
 * Function: PandoraSkipTrack
 * 
 * NISSAN
 */
void HSA_AVDC_Audio__vPandoraSkipTrack( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_AVDC_Audio_H

