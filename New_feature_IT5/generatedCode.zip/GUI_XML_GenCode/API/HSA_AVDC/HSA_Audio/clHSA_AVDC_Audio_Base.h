/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_AVDC_Audio_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_AVDC_Audio_Base_H
#define _clHSA_AVDC_Audio_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_AVDC_Audio_Base : public clHSA_Base
{
public:

    static clHSA_AVDC_Audio_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_AVDC_Audio_Base()        {}

    virtual void vSetPlay( );

    virtual void vSetStop( );

    virtual void vActivateMDI(ulword ulwListEntryNr);

    virtual void vActivateMode(ulword ulwMode);

    virtual void vActivateNextTrack( );

    virtual void vActivatePreviousTrack( );

    virtual void vFastForward( );

    virtual slword slwGetActiveBrowserItem( );

    virtual void vGetActiveMDIName(GUI_String *out_result);

    virtual ulword ulwGetActiveMDINumber( );

    virtual ulword ulwGetArtistNameDisplayLinesNr( );

    virtual tbool blIsIndexingComplete( );

    virtual ulword ulwGetIndexingStatus( );

    virtual tbool blStartIpodIndexing( );

    virtual void vGetIndexingState(GUI_String *out_result);

    virtual void vGetCoverArtImage(GUI_String *out_result);

    virtual void vGetCoverArtImageInfo(GUI_String *out_result);

    virtual ulword ulwGetAudioSourceState(ulword ulwEntryNr);

    virtual ulword ulwGetBTAudioFileInfoType( );

    virtual ulword ulwGetCDType( );

    virtual slword slwGetCurrentCDCDiscNr( );

    virtual ulword ulwGetCurrentMode( );

    virtual void vGetCurrentTrackExtraInfo(GUI_String *out_result);

    virtual void vGetCurrentTrackInfo(GUI_String *out_result, ulword uwArrayIndex);

    virtual ulword ulwGetCurrentTrackNr( );

    virtual ulword ulwGetCurrentMedialistIdentifier( );

    virtual void vGetElapsedTimeOfTrack(GUI_String *out_result);

    virtual ulword ulwGetElapsedTimeOfTrackInSeconds( );

    virtual tbool blGetIncludeSubFoldersState( );

    virtual ulword ulwGetMDIActivatingState( );

    virtual ulword ulwGetMDIFileInfoType( );

    virtual ulword ulwGetMDIListCount( );

    virtual void vGetMDIListItems(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetMDIListLoadingState( );

    virtual ulword ulwGetMDIOperationState( );

    virtual void vGetRemainingTimeOfTrack(GUI_String *out_result);

    virtual ulword ulwGetTitleNameDisplayLinesNr( );

    virtual ulword ulwGetTotalTimeOfTrackInSeconds( );

    virtual slword slwGetVBR( );

    virtual tbool blIsBTAudioActive( );

    virtual ulword ulwIsCDCDiscLoading( );

    virtual ulword ulwIsCheckingAudioFilesForOpening( );

    virtual ulword ulwIsCheckingAudioFilesForPlaying( );

    virtual tbool blIsFunctionMixAllAvailable( );

    virtual tbool blIsFunctionMixAvailable( );

    virtual tbool blIsFunctionMixFolderAvailable( );

    virtual tbool blIsFunctionMixPlaylistAvailable( );

    virtual tbool blIsFunctionRepeatCDAvailable( );

    virtual tbool blIsFunctionRepeatFolderAvailable( );

    virtual tbool blIsFunctionRepeatPlaylistAvailable( );

    virtual tbool blIsFunctionRepeatTrackAvailable( );

    virtual tbool blIsFunctionScanAvailable( );

    virtual tbool blIsMDIListAvailable( );

    virtual ulword ulwIsSelectedListItemInfoAvailable(ulword ulwListEntryNr);

    virtual ulword ulwIsSelectedTitleListItemInfoAvailable(ulword ulwListEntryNr);

    virtual ulword ulwLoadMDIList( );

    virtual void vRewind( );

    virtual void vStopFastForward( );

    virtual void vStopRewind( );

    virtual void vToggleBTAudioState( );

    virtual void vToggleIncludeSubFoldersState( );

    virtual void vGetPandoraStationName(GUI_String *out_result);

    virtual ulword ulwGetPandoraErrorMessage( );

    virtual void vGetPandoraStationIcon(GUI_String *out_result, ulword ulwDynamicIndex);

    virtual void vGetPandoraRatingIcon(GUI_String *out_result, ulword ulwRatingIcon);

    virtual tbool blGetPandoraPlayStatus( );

    virtual tbool blGetPandoraLoadingStatus( );

    virtual tbool blGetPandoraListLoadingStatus( );

    virtual tbool blIsPandoraRatingAllowed( );

    virtual tbool blIsPandoraThumbsUp( );

    virtual tbool blIsPandoraThumbsDown( );

    virtual tbool blIsPandoraBookMarkAllowed( );

    virtual tbool blIsPandoraNewStationCreationAllowed( );

    virtual tbool blIsPandoraStationDeletionAllowed( );

    virtual tbool blIsPandoraSourceActive( );

    virtual tbool blIsPandoraNoStationActive( );

    virtual void vPandoraPlayControl(ulword ulwMode);

    virtual void vPandoraTrackRating(ulword ulwRating);

    virtual void vLoadPandoraStationList(ulword ulwListType);

    virtual void vPandoraStationCreate(ulword ulwMode);

    virtual void vPandoraStationSelect(ulword ulwListIndex);

    virtual void vPandoraStationDelete(ulword ulwListIndex);

    virtual void vPandoraBookMark( );

    virtual void vPandoraSkipTrack( );

protected:
    clHSA_AVDC_Audio_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_AVDC_Audio_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_AVDC_Audio_Base_H

