/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_AVDC_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_AVDC_Wrapper_H
#define _HSA_AVDC_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: QSInitQuickSearch
 * NISSAN 1.5
 * NISSAN
 */
void HSA_AVDC__vQSInitQuickSearch(ulword ulwListPos);

/**
 * Function: GetQSCurrentCharacterGroup
 * NISSAN 1.5
 * NISSAN
 */
void HSA_AVDC__vGetQSCurrentCharacterGroup(GUI_String *out_result);

/**
 * Function: SetQSIncreaseCurrentCharacterGroup
 * NISSAN 1.5
 * NISSAN
 */
void HSA_AVDC__vSetQSIncreaseCurrentCharacterGroup( void);

/**
 * Function: SetQSDecreaseCurrentCharacterGroup
 * NISSAN 1.5
 * NISSAN
 */
void HSA_AVDC__vSetQSDecreaseCurrentCharacterGroup( void);

/**
 * Function: QSStartSearch
 * NISSAN 1.5
 * NISSAN
 */
void HSA_AVDC__vQSStartSearch( void);

/**
 * Function: GetQSCurrentCharacterGroupIndex
 * NISSAN 1.5
 * NISSAN
 */
ulword HSA_AVDC__ulwGetQSCurrentCharacterGroupIndex( void);

/**
 * Function: GetQSOptionVisibility
 * NISSAN 1.5
 * NISSAN
 */
tbool HSA_AVDC__blGetQSOptionVisibility( void);

/**
 * Function: GetAVDCListPosition
 * NISSAN 1.5
 * NISSAN
 */
ulword HSA_AVDC__ulwGetAVDCListPosition( void);

/**
 * Function: IsMixmodeComplete
 * NISSAN 1.5
 * NISSAN
 */
tbool HSA_AVDC__blIsMixmodeComplete( void);

/**
 * Function: IsUSBConnected
 * NISSAN LCN2Kai
 * NISSAN
 */
tbool HSA_AVDC__blIsUSBConnected( void);

/**
 * Function: DisplayAllField
 * NISSAN 2
 * NISSAN
 */
tbool HSA_AVDC__blDisplayAllField( void);

/**
 * Function: ToggleSources_MFL_Order
 * NISSAN
 * NISSAN
 */
void HSA_AVDC__vToggleSources_MFL_Order( void);

/**
 * Function: GetCurrentAuxSource
 * NISSAN
 * NISSAN
 */
ulword HSA_AVDC__ulwGetCurrentAuxSource( void);

/**
 * Function: ToggleAvailableAuxSources
 * NISSAN
 * NISSAN
 */
void HSA_AVDC__vToggleAvailableAuxSources( void);

/**
 * Function: ActivateDisc
 * B
 * NISSAN
 */
void HSA_AVDC__vActivateDisc(ulword ulwEntryNr);

/**
 * Function: ActivateNextDisc
 * B
 * NISSAN
 */
void HSA_AVDC__vActivateNextDisc( void);

/**
 * Function: CancelCheckSelectedItem
 * B
 * NISSAN
 */
void HSA_AVDC__vCancelCheckSelectedItem( void);

/**
 * Function: ChangeBrowserScreen
 * B
 * NISSAN
 */
void HSA_AVDC__vChangeBrowserScreen( void);

/**
 * Function: EnterCategory
 * B
 * NISSAN
 */
void HSA_AVDC__vEnterCategory(ulword ulwParamContext, ulword ulwCategoryType);

/**
 * Function: GetBrowserType
 * B
 * NISSAN
 */
ulword HSA_AVDC__ulwGetBrowserType( void);

/**
 * Function: GetCurrentUSBPlayer
 * B
 * NISSAN
 */
slword HSA_AVDC__slwGetCurrentUSBPlayer( void);

/**
 * Function: GetCurrentModeForTextDisplay
 * B1
 * NISSAN
 */
ulword HSA_AVDC__ulwGetCurrentModeForTextDisplay( void);

/**
 * Function: GetCurrentModeForTextDisplay_MP
 * B1
 * NISSAN
 */
ulword HSA_AVDC__ulwGetCurrentModeForTextDisplay_MP( void);

/**
 * Function: EnterSelectedItem
 * B2
 * NISSAN
 */
void HSA_AVDC__vEnterSelectedItem(ulword ulwEntryNr);

/**
 * Function: ExitBrowser
 * B
 * NISSAN
 */
void HSA_AVDC__vExitBrowser( void);

/**
 * Function: EjectDisc
 * B
 * NISSAN
 */
void HSA_AVDC__vEjectDisc( void);

/**
 * Function: GetAUX2InputState
 * B
 * NISSAN
 */
tbool HSA_AVDC__blGetAUX2InputState( void);

/**
 * Function: GetAUXInputLevel
 * B1
 * NISSAN
 */
ulword HSA_AVDC__ulwGetAUXInputLevel( void);

/**
 * Function: GetBrowserItemCount
 * B2
 * NISSAN
 */
ulword HSA_AVDC__ulwGetBrowserItemCount( void);

/**
 * Function: GetBrowserItemName
 * B2
 * NISSAN
 */
void HSA_AVDC__vGetBrowserItemName(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetBrowserItemTrackNr
 * B2
 * NISSAN
 */
void HSA_AVDC__vGetBrowserItemTrackNr(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetBrowserItemType
 * B2
 * NISSAN
 */
ulword HSA_AVDC__ulwGetBrowserItemType(ulword ulwListEntryNr);

/**
 * Function: GetBrowserItemTypeString
 * B2
 * NISSAN
 */
void HSA_AVDC__vGetBrowserItemTypeString(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetBrowserLoadingState
 * B2
 * NISSAN
 */
ulword HSA_AVDC__ulwGetBrowserLoadingState( void);

/**
 * Function: GetCDCDiscState
 * B
 * NISSAN
 */
ulword HSA_AVDC__ulwGetCDCDiscState(ulword ulwEntryNr);

/**
 * Function: GetCDCNumberOfDiscs
 * 
 * NISSAN
 */
ulword HSA_AVDC__ulwGetCDCNumberOfDiscs( void);

/**
 * Function: GetCurrentFolderLevel
 * B2
 * NISSAN
 */
ulword HSA_AVDC__ulwGetCurrentFolderLevel( void);

/**
 * Function: GetCurrentSource
 * B1
 * NISSAN
 */
slword HSA_AVDC__slwGetCurrentSource( void);

/**
 * Function: GetFollowModeItem
 * 
 * NISSAN
 */
ulword HSA_AVDC__ulwGetFollowModeItem( void);

/**
 * Function: GetMDIInputLevel
 * B
 * NISSAN
 */
ulword HSA_AVDC__ulwGetMDIInputLevel( void);

/**
 * Function: GetPath
 * B2
 * NISSAN
 */
void HSA_AVDC__vGetPath(GUI_String *out_result);

/**
 * Function: GetRequestInfoState
 * B2
 * NISSAN
 */
ulword HSA_AVDC__ulwGetRequestInfoState( void);

/**
 * Function: GetSelectedItemInfo
 * B2
 * NISSAN
 */
void HSA_AVDC__vGetSelectedItemInfo(GUI_String *out_result, ulword uwArrayIndex, ulword ulwListEntryNr);

/**
 * Function: GoToRootFolder
 * B2
 * NISSAN
 */
void HSA_AVDC__vGoToRootFolder( void);

/**
 * Function: GoToUpperLevel
 * B2
 * NISSAN
 */
void HSA_AVDC__vGoToUpperLevel( void);

/**
 * Function: IsInfoAvailable
 * B
 * NISSAN
 */
ulword HSA_AVDC__ulwIsInfoAvailable( void);

/**
 * Function: IsMDIAvailable
 * B
 * NISSAN
 */
tbool HSA_AVDC__blIsMDIAvailable( void);

/**
 * Function: IsMDITrackListAvailable
 * B
 * NISSAN
 */
tbool HSA_AVDC__blIsMDITrackListAvailable( void);

/**
 * Function: IsMediaAvailable
 * B1
 * NISSAN
 */
ulword HSA_AVDC__ulwIsMediaAvailable( void);

/**
 * Function: LeaveSource
 * B
 * NISSAN
 */
void HSA_AVDC__vLeaveSource( void);

/**
 * Function: LoadBrowser
 * B2
 * NISSAN
 */
void HSA_AVDC__vLoadBrowser( void);

/**
 * Function: PlaySelectedItem
 * B2
 * NISSAN
 */
void HSA_AVDC__vPlaySelectedItem(ulword ulwEntryNr);

/**
 * Function: PrepareSelectedListItemInfo
 * B1
 * NISSAN
 */
void HSA_AVDC__vPrepareSelectedListItemInfo(ulword ulwListEntryNr);

/**
 * Function: SetAUXInputLevel
 * B1
 * NISSAN
 */
void HSA_AVDC__vSetAUXInputLevel(ulword ulwLevel);

/**
 * Function: SetMDIInputLevel
 * B
 * NISSAN
 */
void HSA_AVDC__vSetMDIInputLevel(ulword ulwLevel);

/**
 * Function: SetSource
 * B1
 * NISSAN
 */
void HSA_AVDC__vSetSource(ulword ulwSource);

/**
 * Function: StopFollowMode
 * B
 * NISSAN
 */
void HSA_AVDC__vStopFollowMode( void);

/**
 * Function: ToggleAUX2InputState
 * B
 * NISSAN
 */
void HSA_AVDC__vToggleAUX2InputState( void);

/**
 * Function: ToggleAvailableSources
 * B1
 * NISSAN
 */
void HSA_AVDC__vToggleAvailableSources( void);

/**
 * Function: GetCurrentRepeatMode
 * PT1
 * NISSAN
 */
ulword HSA_AVDC__ulwGetCurrentRepeatMode( void);

/**
 * Function: IsIPODPlaystatusAvailable
 * NISSAN LCN2
 * NISSAN
 */
tbool HSA_AVDC__blIsIPODPlaystatusAvailable( void);

/**
 * Function: IsIPODIndexPlayable
 * NISSAN LCN2
 * NISSAN
 */
tbool HSA_AVDC__blIsIPODIndexPlayable(ulword ulwListEntryNr);

/**
 * Function: GetCurrentMixMode
 * PT1
 * NISSAN
 */
ulword HSA_AVDC__ulwGetCurrentMixMode( void);

/**
 * Function: FolderSkip
 * ITGH5SD
 * NISSAN
 */
void HSA_AVDC__vFolderSkip(ulword ulwSkipDirection);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_AVDC_H

