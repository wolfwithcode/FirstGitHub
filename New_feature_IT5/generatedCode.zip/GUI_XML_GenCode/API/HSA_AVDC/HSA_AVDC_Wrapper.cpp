/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_AVDC_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_AVDC_Wrapper.h"
#include "clHSA_AVDC_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_AVDC_Trace.h"
#include "hmi_trace.h"

void HSA_AVDC__vQSInitQuickSearch(ulword ulwListPos)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__QS_INIT_QUICK_SEARCH | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListPos); 
        }
      pInst->vQSInitQuickSearch(ulwListPos);

    }
}

void HSA_AVDC__vGetQSCurrentCharacterGroup(GUI_String *out_result)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_QS_CURRENT_CHARACTER_GROUP  ) ); 
        }
      pInst->vGetQSCurrentCharacterGroup(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_QS_CURRENT_CHARACTER_GROUP | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_AVDC__vSetQSIncreaseCurrentCharacterGroup( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__SET_QS_INCREASE_CURRENT_CHARACTER_GROUP  ) ); 
        }
      pInst->vSetQSIncreaseCurrentCharacterGroup();

    }
}

void HSA_AVDC__vSetQSDecreaseCurrentCharacterGroup( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__SET_QS_DECREASE_CURRENT_CHARACTER_GROUP  ) ); 
        }
      pInst->vSetQSDecreaseCurrentCharacterGroup();

    }
}

void HSA_AVDC__vQSStartSearch( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__QS_START_SEARCH  ) ); 
        }
      pInst->vQSStartSearch();

    }
}

ulword HSA_AVDC__ulwGetQSCurrentCharacterGroupIndex( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_QS_CURRENT_CHARACTER_GROUP_INDEX  ) ); 
        }
      ret=pInst->ulwGetQSCurrentCharacterGroupIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_QS_CURRENT_CHARACTER_GROUP_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC__blGetQSOptionVisibility( )
{
    tbool ret = false;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_QS_OPTION_VISIBILITY  ) ); 
        }
      ret=pInst->blGetQSOptionVisibility();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_QS_OPTION_VISIBILITY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC__ulwGetAVDCListPosition( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_AVDC_LIST_POSITION  ) ); 
        }
      ret=pInst->ulwGetAVDCListPosition();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_AVDC_LIST_POSITION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC__blIsMixmodeComplete( )
{
    tbool ret = false;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_MIXMODE_COMPLETE  ) ); 
        }
      ret=pInst->blIsMixmodeComplete();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_MIXMODE_COMPLETE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC__blIsUSBConnected( )
{
    tbool ret = false;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_USB_CONNECTED  ) ); 
        }
      ret=pInst->blIsUSBConnected();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_USB_CONNECTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC__blDisplayAllField( )
{
    tbool ret = false;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__DISPLAY_ALL_FIELD  ) ); 
        }
      ret=pInst->blDisplayAllField();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__DISPLAY_ALL_FIELD | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC__vToggleSources_MFL_Order( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_SOURCES_MFL__ORDER  ) ); 
        }
      pInst->vToggleSources_MFL_Order();

    }
}

ulword HSA_AVDC__ulwGetCurrentAuxSource( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_AUX_SOURCE  ) ); 
        }
      ret=pInst->ulwGetCurrentAuxSource();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_AUX_SOURCE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC__vToggleAvailableAuxSources( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_AVAILABLE_AUX_SOURCES  ) ); 
        }
      pInst->vToggleAvailableAuxSources();

    }
}

void HSA_AVDC__vActivateDisc(ulword ulwEntryNr)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_DISC | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
        }
      pInst->vActivateDisc(ulwEntryNr);

    }
}

void HSA_AVDC__vActivateNextDisc( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_NEXT_DISC  ) ); 
        }
      pInst->vActivateNextDisc();

    }
}

void HSA_AVDC__vCancelCheckSelectedItem( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__CANCEL_CHECK_SELECTED_ITEM  ) ); 
        }
      pInst->vCancelCheckSelectedItem();

    }
}

void HSA_AVDC__vChangeBrowserScreen( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__CHANGE_BROWSER_SCREEN  ) ); 
        }
      pInst->vChangeBrowserScreen();

    }
}

void HSA_AVDC__vEnterCategory(ulword ulwParamContext, ulword ulwCategoryType)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__ENTER_CATEGORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwParamContext); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__ENTER_CATEGORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCategoryType); 
        }
      pInst->vEnterCategory(ulwParamContext, ulwCategoryType);

    }
}

ulword HSA_AVDC__ulwGetBrowserType( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_TYPE  ) ); 
        }
      ret=pInst->ulwGetBrowserType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_AVDC__slwGetCurrentUSBPlayer( )
{
    slword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_USB_PLAYER  ) ); 
        }
      ret=pInst->slwGetCurrentUSBPlayer();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_USB_PLAYER | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC__ulwGetCurrentModeForTextDisplay( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MODE_FOR_TEXT_DISPLAY  ) ); 
        }
      ret=pInst->ulwGetCurrentModeForTextDisplay();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MODE_FOR_TEXT_DISPLAY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC__ulwGetCurrentModeForTextDisplay_MP( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MODE_FOR_TEXT_DISPLAY_MP  ) ); 
        }
      ret=pInst->ulwGetCurrentModeForTextDisplay_MP();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MODE_FOR_TEXT_DISPLAY_MP | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC__vEnterSelectedItem(ulword ulwEntryNr)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__ENTER_SELECTED_ITEM | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
        }
      pInst->vEnterSelectedItem(ulwEntryNr);

    }
}

void HSA_AVDC__vExitBrowser( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__EXIT_BROWSER  ) ); 
        }
      pInst->vExitBrowser();

    }
}

void HSA_AVDC__vEjectDisc( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__EJECT_DISC  ) ); 
        }
      pInst->vEjectDisc();

    }
}

tbool HSA_AVDC__blGetAUX2InputState( )
{
    tbool ret = false;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_AUX2_INPUT_STATE  ) ); 
        }
      ret=pInst->blGetAUX2InputState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_AUX2_INPUT_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC__ulwGetAUXInputLevel( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_AUX_INPUT_LEVEL  ) ); 
        }
      ret=pInst->ulwGetAUXInputLevel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_AUX_INPUT_LEVEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC__ulwGetBrowserItemCount( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_COUNT  ) ); 
        }
      ret=pInst->ulwGetBrowserItemCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC__vGetBrowserItemName(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetBrowserItemName(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_AVDC__vGetBrowserItemTrackNr(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_TRACK_NR | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetBrowserItemTrackNr(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_TRACK_NR | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_AVDC__ulwGetBrowserItemType(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetBrowserItemType(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC__vGetBrowserItemTypeString(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_TYPE_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetBrowserItemTypeString(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_TYPE_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_AVDC__ulwGetBrowserLoadingState( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_LOADING_STATE  ) ); 
        }
      ret=pInst->ulwGetBrowserLoadingState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_LOADING_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC__ulwGetCDCDiscState(ulword ulwEntryNr)
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CDC_DISC_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
        }
      ret=pInst->ulwGetCDCDiscState(ulwEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CDC_DISC_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC__ulwGetCDCNumberOfDiscs( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CDC_NUMBER_OF_DISCS  ) ); 
        }
      ret=pInst->ulwGetCDCNumberOfDiscs();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CDC_NUMBER_OF_DISCS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC__ulwGetCurrentFolderLevel( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_FOLDER_LEVEL  ) ); 
        }
      ret=pInst->ulwGetCurrentFolderLevel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_FOLDER_LEVEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_AVDC__slwGetCurrentSource( )
{
    slword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SOURCE  ) ); 
        }
      ret=pInst->slwGetCurrentSource();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SOURCE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC__ulwGetFollowModeItem( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_FOLLOW_MODE_ITEM  ) ); 
        }
      ret=pInst->ulwGetFollowModeItem();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_FOLLOW_MODE_ITEM | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC__ulwGetMDIInputLevel( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_INPUT_LEVEL  ) ); 
        }
      ret=pInst->ulwGetMDIInputLevel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_MDI_INPUT_LEVEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC__vGetPath(GUI_String *out_result)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_PATH  ) ); 
        }
      pInst->vGetPath(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_PATH | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_AVDC__ulwGetRequestInfoState( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_REQUEST_INFO_STATE  ) ); 
        }
      ret=pInst->ulwGetRequestInfoState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_REQUEST_INFO_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC__vGetSelectedItemInfo(GUI_String *out_result, ulword uwArrayIndex, ulword ulwListEntryNr)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_ITEM_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&uwArrayIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_ITEM_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetSelectedItemInfo(out_result, uwArrayIndex, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_ITEM_INFO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_AVDC__vGoToRootFolder( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GO_TO_ROOT_FOLDER  ) ); 
        }
      pInst->vGoToRootFolder();

    }
}

void HSA_AVDC__vGoToUpperLevel( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GO_TO_UPPER_LEVEL  ) ); 
        }
      pInst->vGoToUpperLevel();

    }
}

ulword HSA_AVDC__ulwIsInfoAvailable( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_INFO_AVAILABLE  ) ); 
        }
      ret=pInst->ulwIsInfoAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_INFO_AVAILABLE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC__blIsMDIAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_MDI_AVAILABLE  ) ); 
        }
      ret=pInst->blIsMDIAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_MDI_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC__blIsMDITrackListAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_MDI_TRACK_LIST_AVAILABLE  ) ); 
        }
      ret=pInst->blIsMDITrackListAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_MDI_TRACK_LIST_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC__ulwIsMediaAvailable( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_MEDIA_AVAILABLE  ) ); 
        }
      ret=pInst->ulwIsMediaAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_MEDIA_AVAILABLE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC__vLeaveSource( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__LEAVE_SOURCE  ) ); 
        }
      pInst->vLeaveSource();

    }
}

void HSA_AVDC__vLoadBrowser( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__LOAD_BROWSER  ) ); 
        }
      pInst->vLoadBrowser();

    }
}

void HSA_AVDC__vPlaySelectedItem(ulword ulwEntryNr)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__PLAY_SELECTED_ITEM | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
        }
      pInst->vPlaySelectedItem(ulwEntryNr);

    }
}

void HSA_AVDC__vPrepareSelectedListItemInfo(ulword ulwListEntryNr)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__PREPARE_SELECTED_LIST_ITEM_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vPrepareSelectedListItemInfo(ulwListEntryNr);

    }
}

void HSA_AVDC__vSetAUXInputLevel(ulword ulwLevel)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__SET_AUX_INPUT_LEVEL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLevel); 
        }
      pInst->vSetAUXInputLevel(ulwLevel);

    }
}

void HSA_AVDC__vSetMDIInputLevel(ulword ulwLevel)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__SET_MDI_INPUT_LEVEL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLevel); 
        }
      pInst->vSetMDIInputLevel(ulwLevel);

    }
}

void HSA_AVDC__vSetSource(ulword ulwSource)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__SET_SOURCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSource); 
        }
      pInst->vSetSource(ulwSource);

    }
}

void HSA_AVDC__vStopFollowMode( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__STOP_FOLLOW_MODE  ) ); 
        }
      pInst->vStopFollowMode();

    }
}

void HSA_AVDC__vToggleAUX2InputState( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_AUX2_INPUT_STATE  ) ); 
        }
      pInst->vToggleAUX2InputState();

    }
}

void HSA_AVDC__vToggleAvailableSources( )
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_AVAILABLE_SOURCES  ) ); 
        }
      pInst->vToggleAvailableSources();

    }
}

ulword HSA_AVDC__ulwGetCurrentRepeatMode( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_REPEAT_MODE  ) ); 
        }
      ret=pInst->ulwGetCurrentRepeatMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_REPEAT_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC__blIsIPODPlaystatusAvailable( )
{
    tbool ret = false;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_IPOD_PLAYSTATUS_AVAILABLE  ) ); 
        }
      ret=pInst->blIsIPODPlaystatusAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_IPOD_PLAYSTATUS_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_AVDC__blIsIPODIndexPlayable(ulword ulwListEntryNr)
{
    tbool ret = false;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_IPOD_INDEX_PLAYABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->blIsIPODIndexPlayable(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__IS_IPOD_INDEX_PLAYABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_AVDC__ulwGetCurrentMixMode( )
{
    ulword ret = 0;
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MIX_MODE  ) ); 
        }
      ret=pInst->ulwGetCurrentMixMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MIX_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_AVDC__vFolderSkip(ulword ulwSkipDirection)
{
    
    clHSA_AVDC_Base *pInst=clHSA_AVDC_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_AVDC), (tU16)(HSA_API_ENTRYPOINT__FOLDER_SKIP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSkipDirection); 
        }
      pInst->vFolderSkip(ulwSkipDirection);

    }
}

#ifdef __cplusplus
}
#endif

