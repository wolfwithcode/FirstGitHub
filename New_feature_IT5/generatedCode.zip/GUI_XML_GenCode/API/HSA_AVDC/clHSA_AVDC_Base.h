/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_AVDC_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_AVDC_Base_H
#define _clHSA_AVDC_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_AVDC_Base : public clHSA_Base
{
public:

    static clHSA_AVDC_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_AVDC_Base()        {}

    virtual void vQSInitQuickSearch(ulword ulwListPos);

    virtual void vGetQSCurrentCharacterGroup(GUI_String *out_result);

    virtual void vSetQSIncreaseCurrentCharacterGroup( );

    virtual void vSetQSDecreaseCurrentCharacterGroup( );

    virtual void vQSStartSearch( );

    virtual ulword ulwGetQSCurrentCharacterGroupIndex( );

    virtual tbool blGetQSOptionVisibility( );

    virtual ulword ulwGetAVDCListPosition( );

    virtual tbool blIsMixmodeComplete( );

    virtual tbool blIsUSBConnected( );

    virtual tbool blDisplayAllField( );

    virtual void vToggleSources_MFL_Order( );

    virtual ulword ulwGetCurrentAuxSource( );

    virtual void vToggleAvailableAuxSources( );

    virtual void vActivateDisc(ulword ulwEntryNr);

    virtual void vActivateNextDisc( );

    virtual void vCancelCheckSelectedItem( );

    virtual void vChangeBrowserScreen( );

    virtual void vEnterCategory(ulword ulwParamContext, ulword ulwCategoryType);

    virtual ulword ulwGetBrowserType( );

    virtual slword slwGetCurrentUSBPlayer( );

    virtual ulword ulwGetCurrentModeForTextDisplay( );

    virtual ulword ulwGetCurrentModeForTextDisplay_MP( );

    virtual void vEnterSelectedItem(ulword ulwEntryNr);

    virtual void vExitBrowser( );

    virtual void vEjectDisc( );

    virtual tbool blGetAUX2InputState( );

    virtual ulword ulwGetAUXInputLevel( );

    virtual ulword ulwGetBrowserItemCount( );

    virtual void vGetBrowserItemName(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetBrowserItemTrackNr(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetBrowserItemType(ulword ulwListEntryNr);

    virtual void vGetBrowserItemTypeString(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetBrowserLoadingState( );

    virtual ulword ulwGetCDCDiscState(ulword ulwEntryNr);

    virtual ulword ulwGetCDCNumberOfDiscs( );

    virtual ulword ulwGetCurrentFolderLevel( );

    virtual slword slwGetCurrentSource( );

    virtual ulword ulwGetFollowModeItem( );

    virtual ulword ulwGetMDIInputLevel( );

    virtual void vGetPath(GUI_String *out_result);

    virtual ulword ulwGetRequestInfoState( );

    virtual void vGetSelectedItemInfo(GUI_String *out_result, ulword uwArrayIndex, ulword ulwListEntryNr);

    virtual void vGoToRootFolder( );

    virtual void vGoToUpperLevel( );

    virtual ulword ulwIsInfoAvailable( );

    virtual tbool blIsMDIAvailable( );

    virtual tbool blIsMDITrackListAvailable( );

    virtual ulword ulwIsMediaAvailable( );

    virtual void vLeaveSource( );

    virtual void vLoadBrowser( );

    virtual void vPlaySelectedItem(ulword ulwEntryNr);

    virtual void vPrepareSelectedListItemInfo(ulword ulwListEntryNr);

    virtual void vSetAUXInputLevel(ulword ulwLevel);

    virtual void vSetMDIInputLevel(ulword ulwLevel);

    virtual void vSetSource(ulword ulwSource);

    virtual void vStopFollowMode( );

    virtual void vToggleAUX2InputState( );

    virtual void vToggleAvailableSources( );

    virtual ulword ulwGetCurrentRepeatMode( );

    virtual tbool blIsIPODPlaystatusAvailable( );

    virtual tbool blIsIPODIndexPlayable(ulword ulwListEntryNr);

    virtual ulword ulwGetCurrentMixMode( );

    virtual void vFolderSkip(ulword ulwSkipDirection);

protected:
    clHSA_AVDC_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_AVDC_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_AVDC_Base_H

