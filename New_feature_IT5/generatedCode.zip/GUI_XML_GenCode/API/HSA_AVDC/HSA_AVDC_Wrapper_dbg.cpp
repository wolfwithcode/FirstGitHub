/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_AVDC_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_AVDC_Wrapper_dbg.h"
#include "clHSA_AVDC_Base.h"
#include "HSA_AVDC_Trace.h"
#include "HSA_AVDC_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_AVDC_Wrapper_dbg::~clHSA_AVDC_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_AVDC_Wrapper_dbg::clHSA_AVDC_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_AVDC_Wrapper_dbg::clHSA_AVDC_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_AVDC_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_AVDC_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__QS_INIT_QUICK_SEARCH:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC__vQSInitQuickSearch(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_QS_CURRENT_CHARACTER_GROUP:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_AVDC__vGetQSCurrentCharacterGroup(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_QS_INCREASE_CURRENT_CHARACTER_GROUP:

            HSA_AVDC__vSetQSIncreaseCurrentCharacterGroup();
            break;

        case HSA_API_ENTRYPOINT__SET_QS_DECREASE_CURRENT_CHARACTER_GROUP:

            HSA_AVDC__vSetQSDecreaseCurrentCharacterGroup();
            break;

        case HSA_API_ENTRYPOINT__QS_START_SEARCH:

            HSA_AVDC__vQSStartSearch();
            break;

        case HSA_API_ENTRYPOINT__GET_QS_CURRENT_CHARACTER_GROUP_INDEX:

            HSA_AVDC__ulwGetQSCurrentCharacterGroupIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_QS_OPTION_VISIBILITY:

            HSA_AVDC__blGetQSOptionVisibility();
            break;

        case HSA_API_ENTRYPOINT__GET_AVDC_LIST_POSITION:

            HSA_AVDC__ulwGetAVDCListPosition();
            break;

        case HSA_API_ENTRYPOINT__IS_MIXMODE_COMPLETE:

            HSA_AVDC__blIsMixmodeComplete();
            break;

        case HSA_API_ENTRYPOINT__IS_USB_CONNECTED:

            HSA_AVDC__blIsUSBConnected();
            break;

        case HSA_API_ENTRYPOINT__DISPLAY_ALL_FIELD:

            HSA_AVDC__blDisplayAllField();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_SOURCES_MFL__ORDER:

            HSA_AVDC__vToggleSources_MFL_Order();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_AUX_SOURCE:

            HSA_AVDC__ulwGetCurrentAuxSource();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_AVAILABLE_AUX_SOURCES:

            HSA_AVDC__vToggleAvailableAuxSources();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_DISC:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC__vActivateDisc(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_NEXT_DISC:

            HSA_AVDC__vActivateNextDisc();
            break;

        case HSA_API_ENTRYPOINT__CANCEL_CHECK_SELECTED_ITEM:

            HSA_AVDC__vCancelCheckSelectedItem();
            break;

        case HSA_API_ENTRYPOINT__CHANGE_BROWSER_SCREEN:

            HSA_AVDC__vChangeBrowserScreen();
            break;

        case HSA_API_ENTRYPOINT__ENTER_CATEGORY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_AVDC__vEnterCategory(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_BROWSER_TYPE:

            HSA_AVDC__ulwGetBrowserType();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_USB_PLAYER:

            HSA_AVDC__slwGetCurrentUSBPlayer();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_MODE_FOR_TEXT_DISPLAY:

            HSA_AVDC__ulwGetCurrentModeForTextDisplay();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_MODE_FOR_TEXT_DISPLAY_MP:

            HSA_AVDC__ulwGetCurrentModeForTextDisplay_MP();
            break;

        case HSA_API_ENTRYPOINT__ENTER_SELECTED_ITEM:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC__vEnterSelectedItem(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__EXIT_BROWSER:

            HSA_AVDC__vExitBrowser();
            break;

        case HSA_API_ENTRYPOINT__EJECT_DISC:

            HSA_AVDC__vEjectDisc();
            break;

        case HSA_API_ENTRYPOINT__GET_AUX2_INPUT_STATE:

            HSA_AVDC__blGetAUX2InputState();
            break;

        case HSA_API_ENTRYPOINT__GET_AUX_INPUT_LEVEL:

            HSA_AVDC__ulwGetAUXInputLevel();
            break;

        case HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_COUNT:

            HSA_AVDC__ulwGetBrowserItemCount();
            break;

        case HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_AVDC__vGetBrowserItemName(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_TRACK_NR:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_AVDC__vGetBrowserItemTrackNr(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_TYPE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC__ulwGetBrowserItemType(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_BROWSER_ITEM_TYPE_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_AVDC__vGetBrowserItemTypeString(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_BROWSER_LOADING_STATE:

            HSA_AVDC__ulwGetBrowserLoadingState();
            break;

        case HSA_API_ENTRYPOINT__GET_CDC_DISC_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC__ulwGetCDCDiscState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CDC_NUMBER_OF_DISCS:

            HSA_AVDC__ulwGetCDCNumberOfDiscs();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_FOLDER_LEVEL:

            HSA_AVDC__ulwGetCurrentFolderLevel();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_SOURCE:

            HSA_AVDC__slwGetCurrentSource();
            break;

        case HSA_API_ENTRYPOINT__GET_FOLLOW_MODE_ITEM:

            HSA_AVDC__ulwGetFollowModeItem();
            break;

        case HSA_API_ENTRYPOINT__GET_MDI_INPUT_LEVEL:

            HSA_AVDC__ulwGetMDIInputLevel();
            break;

        case HSA_API_ENTRYPOINT__GET_PATH:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_AVDC__vGetPath(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_REQUEST_INFO_STATE:

            HSA_AVDC__ulwGetRequestInfoState();
            break;

        case HSA_API_ENTRYPOINT__GET_SELECTED_ITEM_INFO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2);
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_AVDC__vGetSelectedItemInfo(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GO_TO_ROOT_FOLDER:

            HSA_AVDC__vGoToRootFolder();
            break;

        case HSA_API_ENTRYPOINT__GO_TO_UPPER_LEVEL:

            HSA_AVDC__vGoToUpperLevel();
            break;

        case HSA_API_ENTRYPOINT__IS_INFO_AVAILABLE:

            HSA_AVDC__ulwIsInfoAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_MDI_AVAILABLE:

            HSA_AVDC__blIsMDIAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_MDI_TRACK_LIST_AVAILABLE:

            HSA_AVDC__blIsMDITrackListAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_MEDIA_AVAILABLE:

            HSA_AVDC__ulwIsMediaAvailable();
            break;

        case HSA_API_ENTRYPOINT__LEAVE_SOURCE:

            HSA_AVDC__vLeaveSource();
            break;

        case HSA_API_ENTRYPOINT__LOAD_BROWSER:

            HSA_AVDC__vLoadBrowser();
            break;

        case HSA_API_ENTRYPOINT__PLAY_SELECTED_ITEM:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC__vPlaySelectedItem(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_SELECTED_LIST_ITEM_INFO:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC__vPrepareSelectedListItemInfo(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_AUX_INPUT_LEVEL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC__vSetAUXInputLevel(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_MDI_INPUT_LEVEL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC__vSetMDIInputLevel(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_SOURCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC__vSetSource(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__STOP_FOLLOW_MODE:

            HSA_AVDC__vStopFollowMode();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_AUX2_INPUT_STATE:

            HSA_AVDC__vToggleAUX2InputState();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_AVAILABLE_SOURCES:

            HSA_AVDC__vToggleAvailableSources();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_REPEAT_MODE:

            HSA_AVDC__ulwGetCurrentRepeatMode();
            break;

        case HSA_API_ENTRYPOINT__IS_IPOD_PLAYSTATUS_AVAILABLE:

            HSA_AVDC__blIsIPODPlaystatusAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_IPOD_INDEX_PLAYABLE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC__blIsIPODIndexPlayable(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_MIX_MODE:

            HSA_AVDC__ulwGetCurrentMixMode();
            break;

        case HSA_API_ENTRYPOINT__FOLDER_SKIP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_AVDC__vFolderSkip(ulParam1);
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

