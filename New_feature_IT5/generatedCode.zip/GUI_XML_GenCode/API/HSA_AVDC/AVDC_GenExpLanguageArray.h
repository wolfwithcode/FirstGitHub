/*Exported Language Array from the model - AVDC*/
/*  This file has been generated on 05.12.2014 16:38 */
/*
 *  This file contains the definition of exported language content.
 *  The String lists with the translation that are to be exported
 *  from the model are listed here in the array structure
 *  
 *  Please note that:
 *    - Translations are provided in the following language order
 *    - English US
 *    - French CAN
 *    - Spanish Standard Latin
 *    - Dutch
 *    - German
 *    - Italian
 *    - Portuguese
 *    - Russian
 *    - Turkish
 *    - English UK
 *    - French
 *    - Spanish
 *    - Danish
 *    - Swedish
 *    - Finnish
 *    - Norwegian
 *    - Polish
 *    - Slovak
 *    - Czech
 *    - Hungarian
 *    - Greek
 *    - Brazilian
 *    - Arabic
 *    - Thai
 *    - Australian
 *
 *    This list is the same as used in the Model
 *
 *  The following macros are used:
 *
 *    CONTENT_LANGUAGE_COUNT(LanguageCount)
 *       Provides the count value to indicate the number of translations
 *    CONTENT_LANGUAGE_ARRAY(DeviceName) 
 *       Provides the start of the Array with Device name to which the 
 *       array belongs
 *    CONTENT_INDEX_START(Index Value)
 *       mark the start of Each string followed by the array of
 *       translations
 *    CONTENT_LANGUAGE(ContentID)
 *       provides the content ID for the translated string
 *    CONTENT_INDEX_END
 *       marks the end of Each string translation set
 *    CONTENT_END(value)
 *       End of the complete array
 *
 */


CONTENT_BEGIN()
#ifndef CONTENT_EXP_LANGUAGE_COUNT
   #define CONTENT_EXP_LANGUAGE_COUNT       25
#endif // #ifndef CONTENT_EXP_LANGUAGE_COUNT
CONTENT_LANGUAGE_ARRAY(AVDC)

#ifdef CONTENT_LANGUAGE
    //STRING_START(0)
    CONTENT_LANGUAGE(0x40004b84)                                      // 0x80000014: Playlists
    CONTENT_LANGUAGE(0x40004b8f)                                      // 0x80000014: Listes d'�coute
    CONTENT_LANGUAGE(0x40004b90)                                      // 0x80000014: Listas de reproducci�n
    CONTENT_LANGUAGE(0x40004b91)                                      // 0x80000014: Afspeellijsten
    CONTENT_LANGUAGE(0x40004b92)                                      // 0x80000014: Wiedergabelisten
    CONTENT_LANGUAGE(0x40004b93)                                      // 0x80000014: Playlist
    CONTENT_LANGUAGE(0x40004b94)                                      // 0x80000014: Listas de m�sicas
    CONTENT_LANGUAGE(0x40004b95)                                      // 0x80000014: ?????????
    CONTENT_LANGUAGE(0x40004b96)                                      // 0x80000014: �alma listeleri
    CONTENT_LANGUAGE(0x40004b84)                                      // 0x80000014: Playlists
    CONTENT_LANGUAGE(0x40004b97)                                      // 0x80000014: Listes de lecture
    CONTENT_LANGUAGE(0x40004b98)                                      // 0x80000014: Listas repr.
    CONTENT_LANGUAGE(0x40004b99)                                      // 0x80000014: Spillelister
    CONTENT_LANGUAGE(0x40004b9a)                                      // 0x80000014: Spellistor
    CONTENT_LANGUAGE(0x40004b9b)                                      // 0x80000014: Soittolistat
    CONTENT_LANGUAGE(0x40004b99)                                      // 0x80000014: Spillelister
    CONTENT_LANGUAGE(0x40004b9c)                                      // 0x80000014: Playlisty
    CONTENT_LANGUAGE(0x40004b9c)                                      // 0x80000014: Playlisty
    CONTENT_LANGUAGE(0x40004b9c)                                      // 0x80000014: Playlisty
    CONTENT_LANGUAGE(0x40004b9d)                                      // 0x80000014: Lej�tsz�si list�k
    CONTENT_LANGUAGE(0x40004b9e)                                      // 0x80000014: ?????? ????????????
    CONTENT_LANGUAGE(0x40004b9f)                                      // 0x80000014: Lista de m�sicas
    CONTENT_LANGUAGE(0x40004ba0)                                      // 0x80000014: ????? ???????
    CONTENT_LANGUAGE(0x40004ba1)                                      // 0x80000014: ???????????????
    CONTENT_LANGUAGE(0x40004ba2)                                      // 0x80000014: ?????????
    //STRING_END()
    //STRING_START(1)
    CONTENT_LANGUAGE(0x40004b85)                                      // 0x80000015: Artists
    CONTENT_LANGUAGE(0x40004ba3)                                      // 0x80000015: Artistes
    CONTENT_LANGUAGE(0x40004ba4)                                      // 0x80000015: Artistas
    CONTENT_LANGUAGE(0x40004ba5)                                      // 0x80000015: Artiesten
    CONTENT_LANGUAGE(0x40004ba6)                                      // 0x80000015: Interpreten
    CONTENT_LANGUAGE(0x40004ba7)                                      // 0x80000015: Interpreti
    CONTENT_LANGUAGE(0x40004ba4)                                      // 0x80000015: Artistas
    CONTENT_LANGUAGE(0x40004ba8)                                      // 0x80000015: ???????????
    CONTENT_LANGUAGE(0x40004ba9)                                      // 0x80000015: Sanat�?lar
    CONTENT_LANGUAGE(0x40004b85)                                      // 0x80000015: Artists
    CONTENT_LANGUAGE(0x40004ba3)                                      // 0x80000015: Artistes
    CONTENT_LANGUAGE(0x40004ba4)                                      // 0x80000015: Artistas
    CONTENT_LANGUAGE(0x40004baa)                                      // 0x80000015: Kunstnere
    CONTENT_LANGUAGE(0x40004bab)                                      // 0x80000015: Artister
    CONTENT_LANGUAGE(0x40004bac)                                      // 0x80000015: Esitt�j�t
    CONTENT_LANGUAGE(0x40004bab)                                      // 0x80000015: Artister
    CONTENT_LANGUAGE(0x40004bad)                                      // 0x80000015: Wykonawcy
    CONTENT_LANGUAGE(0x40004ba7)                                      // 0x80000015: Interpreti
    CONTENT_LANGUAGE(0x40004ba7)                                      // 0x80000015: Interpreti
    CONTENT_LANGUAGE(0x40004bae)                                      // 0x80000015: El?ad�k
    CONTENT_LANGUAGE(0x40004baf)                                      // 0x80000015: ??????????
    CONTENT_LANGUAGE(0x40004ba4)                                      // 0x80000015: Artistas
    CONTENT_LANGUAGE(0x40004bb0)                                      // 0x80000015: ????????
    CONTENT_LANGUAGE(0x40004bb1)                                      // 0x80000015: ??????
    CONTENT_LANGUAGE(0x40004bb2)                                      // 0x80000015: ?????????
    //STRING_END()
    //STRING_START(2)
    CONTENT_LANGUAGE(0x40004b86)                                      // 0x80000016: Albums
    CONTENT_LANGUAGE(0x40004b86)                                      // 0x80000016: Albums
    CONTENT_LANGUAGE(0x40004bb3)                                      // 0x80000016: �lbumes
    CONTENT_LANGUAGE(0x40004b86)                                      // 0x80000016: Albums
    CONTENT_LANGUAGE(0x40004bb4)                                      // 0x80000016: Alben
    CONTENT_LANGUAGE(0x40001d28)                                      // 0x80000016: Album
    CONTENT_LANGUAGE(0x40004bb5)                                      // 0x80000016: �lbuns
    CONTENT_LANGUAGE(0x40004bb6)                                      // 0x80000016: ???????
    CONTENT_LANGUAGE(0x40004bb7)                                      // 0x80000016: Alb�mler
    CONTENT_LANGUAGE(0x40004b86)                                      // 0x80000016: Albums
    CONTENT_LANGUAGE(0x40004b86)                                      // 0x80000016: Albums
    CONTENT_LANGUAGE(0x40004bb3)                                      // 0x80000016: �lbumes
    CONTENT_LANGUAGE(0x40001d28)                                      // 0x80000016: Album
    CONTENT_LANGUAGE(0x40001d28)                                      // 0x80000016: Album
    CONTENT_LANGUAGE(0x40004bb8)                                      // 0x80000016: Albumit
    CONTENT_LANGUAGE(0x40001d28)                                      // 0x80000016: Album
    CONTENT_LANGUAGE(0x40004bb9)                                      // 0x80000016: Albumy
    CONTENT_LANGUAGE(0x40004bb9)                                      // 0x80000016: Albumy
    CONTENT_LANGUAGE(0x40004bba)                                      // 0x80000016: Alba
    CONTENT_LANGUAGE(0x40004bbb)                                      // 0x80000016: Albumok
    CONTENT_LANGUAGE(0x40004bbc)                                      // 0x80000016: ???????
    CONTENT_LANGUAGE(0x40004bb5)                                      // 0x80000016: �lbuns
    CONTENT_LANGUAGE(0x40004bbd)                                      // 0x80000016: ?????????
    CONTENT_LANGUAGE(0x40004bbe)                                      // 0x80000016: ??????
    CONTENT_LANGUAGE(0x40004bbf)                                      // 0x80000016: ???????
    //STRING_END()
    //STRING_START(3)
    CONTENT_LANGUAGE(0x40004b87)                                      // 0x80000017: Songs
    CONTENT_LANGUAGE(0x40004bc0)                                      // 0x80000017: Chansons
    CONTENT_LANGUAGE(0x40004bc1)                                      // 0x80000017: Canciones
    CONTENT_LANGUAGE(0x40004bc2)                                      // 0x80000017: Liedjes
    CONTENT_LANGUAGE(0x40004bc3)                                      // 0x80000017: Titel
    CONTENT_LANGUAGE(0x40004bc4)                                      // 0x80000017: Brani
    CONTENT_LANGUAGE(0x40004bc5)                                      // 0x80000017: T�tulos
    CONTENT_LANGUAGE(0x40004bc6)                                      // 0x80000017: ?????
    CONTENT_LANGUAGE(0x40004bc7)                                      // 0x80000017: Par�alar
    CONTENT_LANGUAGE(0x40004b87)                                      // 0x80000017: Songs
    CONTENT_LANGUAGE(0x40004bc8)                                      // 0x80000017: Morceaux
    CONTENT_LANGUAGE(0x40004bc1)                                      // 0x80000017: Canciones
    CONTENT_LANGUAGE(0x40004bc9)                                      // 0x80000017: Sange
    CONTENT_LANGUAGE(0x40004bca)                                      // 0x80000017: L�tar
    CONTENT_LANGUAGE(0x40004bcb)                                      // 0x80000017: Kappaleet
    CONTENT_LANGUAGE(0x40004bcc)                                      // 0x80000017: Sanger
    CONTENT_LANGUAGE(0x40004bcd)                                      // 0x80000017: Utwory
    CONTENT_LANGUAGE(0x40004bce)                                      // 0x80000017: Skladby
    CONTENT_LANGUAGE(0x40004bce)                                      // 0x80000017: Skladby
    CONTENT_LANGUAGE(0x40004bcf)                                      // 0x80000017: Sz�mok
    CONTENT_LANGUAGE(0x40004bd0)                                      // 0x80000017: ??????
    CONTENT_LANGUAGE(0x40004bc5)                                      // 0x80000017: T�tulos
    CONTENT_LANGUAGE(0x40004bd1)                                      // 0x80000017: ???????
    CONTENT_LANGUAGE(0x40004bd2)                                      // 0x80000017: ????
    CONTENT_LANGUAGE(0x40004bd3)                                      // 0x80000017: ?????
    //STRING_END()
    //STRING_START(4)
    CONTENT_LANGUAGE(0x40004bd4)                                      // 0x80000018: Genres
    CONTENT_LANGUAGE(0x40004bd4)                                      // 0x80000018: Genres
    CONTENT_LANGUAGE(0x40004bd5)                                      // 0x80000018: G�neros
    CONTENT_LANGUAGE(0x40004bd4)                                      // 0x80000018: Genres
    CONTENT_LANGUAGE(0x40004bd6)                                      // 0x80000018: Musikrichtungen
    CONTENT_LANGUAGE(0x40004bd7)                                      // 0x80000018: Generi
    CONTENT_LANGUAGE(0x40004bd5)                                      // 0x80000018: G�neros
    CONTENT_LANGUAGE(0x40004bd8)                                      // 0x80000018: ?????
    CONTENT_LANGUAGE(0x40004bd9)                                      // 0x80000018: T�rler
    CONTENT_LANGUAGE(0x40004bd4)                                      // 0x80000018: Genres
    CONTENT_LANGUAGE(0x40004bd4)                                      // 0x80000018: Genres
    CONTENT_LANGUAGE(0x40004bd5)                                      // 0x80000018: G�neros
    CONTENT_LANGUAGE(0x40004bda)                                      // 0x80000018: Genrer
    CONTENT_LANGUAGE(0x40004bda)                                      // 0x80000018: Genrer
    CONTENT_LANGUAGE(0x40004bdb)                                      // 0x80000018: Musiikkilajit
    CONTENT_LANGUAGE(0x40004bdc)                                      // 0x80000018: Sjangere
    CONTENT_LANGUAGE(0x40004bdd)                                      // 0x80000018: Gatunki muzyki
    CONTENT_LANGUAGE(0x40004bde)                                      // 0x80000018: Hudobn� smery
    CONTENT_LANGUAGE(0x40004bdf)                                      // 0x80000018: Hudebn� ��nry
    CONTENT_LANGUAGE(0x40004be0)                                      // 0x80000018: M?fajok
    CONTENT_LANGUAGE(0x40004be1)                                      // 0x80000018: ???? ????????
    CONTENT_LANGUAGE(0x40004be2)                                      // 0x80000018: G�neros
    CONTENT_LANGUAGE(0x40004be3)                                      // 0x80000018: ????? ???????
    CONTENT_LANGUAGE(0x40004be4)                                      // 0x80000018: ??????
    CONTENT_LANGUAGE(0x40004be5)                                      // 0x80000018: ?????
    //STRING_END()
    //STRING_START(5)
    CONTENT_LANGUAGE(0x40004b89)                                      // 0x80000019: Composers
    CONTENT_LANGUAGE(0x40004be6)                                      // 0x80000019: Compositeurs
    CONTENT_LANGUAGE(0x40004be7)                                      // 0x80000019: Compositores
    CONTENT_LANGUAGE(0x40004be8)                                      // 0x80000019: Componisten
    CONTENT_LANGUAGE(0x40004be9)                                      // 0x80000019: Komponisten
    CONTENT_LANGUAGE(0x40004bea)                                      // 0x80000019: Compositori
    CONTENT_LANGUAGE(0x40004be7)                                      // 0x80000019: Compositores
    CONTENT_LANGUAGE(0x40004beb)                                      // 0x80000019: ???????????
    CONTENT_LANGUAGE(0x40004bec)                                      // 0x80000019: Besteciler
    CONTENT_LANGUAGE(0x40004b89)                                      // 0x80000019: Composers
    CONTENT_LANGUAGE(0x40004be6)                                      // 0x80000019: Compositeurs
    CONTENT_LANGUAGE(0x40004bed)                                      // 0x80000019: Autores
    CONTENT_LANGUAGE(0x40004bee)                                      // 0x80000019: Komponister
    CONTENT_LANGUAGE(0x40004bef)                                      // 0x80000019: Komposit�rer
    CONTENT_LANGUAGE(0x40004bf0)                                      // 0x80000019: S�velt�j�t
    CONTENT_LANGUAGE(0x40004bee)                                      // 0x80000019: Komponister
    CONTENT_LANGUAGE(0x40004bf1)                                      // 0x80000019: Kompozytorzy
    CONTENT_LANGUAGE(0x40004bf2)                                      // 0x80000019: Skladatelia
    CONTENT_LANGUAGE(0x40004bf3)                                      // 0x80000019: Skladatel�
    CONTENT_LANGUAGE(0x40004bf4)                                      // 0x80000019: Zeneszerz?k
    CONTENT_LANGUAGE(0x40004bf5)                                      // 0x80000019: ????????
    CONTENT_LANGUAGE(0x40004be7)                                      // 0x80000019: Compositores
    CONTENT_LANGUAGE(0x40004bf6)                                      // 0x80000019: ????????
    CONTENT_LANGUAGE(0x40004bf7)                                      // 0x80000019: ???????
    CONTENT_LANGUAGE(0x40004bf8)                                      // 0x80000019: ???????????
    //STRING_END()
    //STRING_START(6)
    CONTENT_LANGUAGE(0x40004b8a)                                      // 0x8000001a: Audiobooks
    CONTENT_LANGUAGE(0x40004bf9)                                      // 0x8000001a: Livres audio
    CONTENT_LANGUAGE(0x40004bfa)                                      // 0x8000001a: Audiolibros
    CONTENT_LANGUAGE(0x40004bfb)                                      // 0x8000001a: Audioboeken
    CONTENT_LANGUAGE(0x40004bfc)                                      // 0x8000001a: H�rb�cher
    CONTENT_LANGUAGE(0x40004bfd)                                      // 0x8000001a: Audiolibri
    CONTENT_LANGUAGE(0x40004bfe)                                      // 0x8000001a: Livros �udio
    CONTENT_LANGUAGE(0x40004bff)                                      // 0x8000001a: ??????????
    CONTENT_LANGUAGE(0x40004c00)                                      // 0x8000001a: Sesli kitaplar
    CONTENT_LANGUAGE(0x40004b8a)                                      // 0x8000001a: Audiobooks
    CONTENT_LANGUAGE(0x40004bf9)                                      // 0x8000001a: Livres audio
    CONTENT_LANGUAGE(0x40004bfa)                                      // 0x8000001a: Audiolibros
    CONTENT_LANGUAGE(0x40004c01)                                      // 0x8000001a: Lydb�ger
    CONTENT_LANGUAGE(0x40004c02)                                      // 0x8000001a: Ljudb�cker
    CONTENT_LANGUAGE(0x40004c03)                                      // 0x8000001a: ��nikirjat
    CONTENT_LANGUAGE(0x40004c04)                                      // 0x8000001a: Lydb�ker
    CONTENT_LANGUAGE(0x40004c05)                                      // 0x8000001a: Ksi??ka audio
    CONTENT_LANGUAGE(0x40004c06)                                      // 0x8000001a: Zvukov� knihy
    CONTENT_LANGUAGE(0x40004c07)                                      // 0x8000001a: Audio knihy
    CONTENT_LANGUAGE(0x40004c08)                                      // 0x8000001a: Hangosk�nyvek
    CONTENT_LANGUAGE(0x40004c09)                                      // 0x8000001a: ?????????
    CONTENT_LANGUAGE(0x40004c0a)                                      // 0x8000001a: Audiolivros
    CONTENT_LANGUAGE(0x40004c0b)                                      // 0x8000001a: ??? ??????
    CONTENT_LANGUAGE(0x40004c0c)                                      // 0x8000001a: ????????????
    CONTENT_LANGUAGE(0x40004c0d)                                      // 0x8000001a: ??????????
    //STRING_END()
    //STRING_START(7)
    CONTENT_LANGUAGE(0x40004b8b)                                      // 0x8000001b: Podcasts
    CONTENT_LANGUAGE(0x40004b8b)                                      // 0x8000001b: Podcasts
    CONTENT_LANGUAGE(0x40004b8b)                                      // 0x8000001b: Podcasts
    CONTENT_LANGUAGE(0x40004b8b)                                      // 0x8000001b: Podcasts
    CONTENT_LANGUAGE(0x40004b8b)                                      // 0x8000001b: Podcasts
    CONTENT_LANGUAGE(0x40001d32)                                      // 0x8000001b: Podcast
    CONTENT_LANGUAGE(0x40004b8b)                                      // 0x8000001b: Podcasts
    CONTENT_LANGUAGE(0x40004c0e)                                      // 0x8000001b: ????????
    CONTENT_LANGUAGE(0x40004b8b)                                      // 0x8000001b: Podcasts
    CONTENT_LANGUAGE(0x40004b8b)                                      // 0x8000001b: Podcasts
    CONTENT_LANGUAGE(0x40004b8b)                                      // 0x8000001b: Podcasts
    CONTENT_LANGUAGE(0x40004b8b)                                      // 0x8000001b: Podcasts
    CONTENT_LANGUAGE(0x40004b8b)                                      // 0x8000001b: Podcasts
    CONTENT_LANGUAGE(0x40004c0f)                                      // 0x8000001b: Podcaster
    CONTENT_LANGUAGE(0x40004c10)                                      // 0x8000001b: Podcastit
    CONTENT_LANGUAGE(0x40004c0f)                                      // 0x8000001b: Podcaster
    CONTENT_LANGUAGE(0x40004c11)                                      // 0x8000001b: Podkasty
    CONTENT_LANGUAGE(0x40004c12)                                      // 0x8000001b: Podcasty
    CONTENT_LANGUAGE(0x40004c12)                                      // 0x8000001b: Podcasty
    CONTENT_LANGUAGE(0x40004c13)                                      // 0x8000001b: Podcast-ek
    CONTENT_LANGUAGE(0x40001d32)                                      // 0x8000001b: Podcast
    CONTENT_LANGUAGE(0x40004b8b)                                      // 0x8000001b: Podcasts
    CONTENT_LANGUAGE(0x40004c14)                                      // 0x8000001b: ?????????
    CONTENT_LANGUAGE(0x40004c15)                                      // 0x8000001b: ????????
    CONTENT_LANGUAGE(0x40004c16)                                      // 0x8000001b: ????????
    //STRING_END()
    //STRING_START(8)
    CONTENT_LANGUAGE(0x40004b8c)                                      // 0x8000001c: All
    CONTENT_LANGUAGE(0x40004c17)                                      // 0x8000001c: Tous
    CONTENT_LANGUAGE(0x40004c18)                                      // 0x8000001c: Todas
    CONTENT_LANGUAGE(0x40004c19)                                      // 0x8000001c: Alles
    CONTENT_LANGUAGE(0x40004c1a)                                      // 0x8000001c: Alle
    CONTENT_LANGUAGE(0x40004c1b)                                      // 0x8000001c: Tutto
    CONTENT_LANGUAGE(0x40004c1c)                                      // 0x8000001c: Todos
    CONTENT_LANGUAGE(0x40004c1d)                                      // 0x8000001c: ???
    CONTENT_LANGUAGE(0x40004c1e)                                      // 0x8000001c: T�m
    CONTENT_LANGUAGE(0x40004b8c)                                      // 0x8000001c: All
    CONTENT_LANGUAGE(0x40004c17)                                      // 0x8000001c: Tous
    CONTENT_LANGUAGE(0x40004c1f)                                      // 0x8000001c: Todo
    CONTENT_LANGUAGE(0x40004c1a)                                      // 0x8000001c: Alle
    CONTENT_LANGUAGE(0x40004c20)                                      // 0x8000001c: Alla
    CONTENT_LANGUAGE(0x40004c21)                                      // 0x8000001c: Kaikki
    CONTENT_LANGUAGE(0x40004c1a)                                      // 0x8000001c: Alle
    CONTENT_LANGUAGE(0x40004c22)                                      // 0x8000001c: Wszystkie
    CONTENT_LANGUAGE(0x40004c23)                                      // 0x8000001c: V�etko
    CONTENT_LANGUAGE(0x40004c24)                                      // 0x8000001c: V�e
    CONTENT_LANGUAGE(0x40004c25)                                      // 0x8000001c: �sszes
    CONTENT_LANGUAGE(0x40004c26)                                      // 0x8000001c: ???
    CONTENT_LANGUAGE(0x40004c1c)                                      // 0x8000001c: Todos
    CONTENT_LANGUAGE(0x40004c27)                                      // 0x8000001c: ????
    CONTENT_LANGUAGE(0x40004c28)                                      // 0x8000001c: ???????
    CONTENT_LANGUAGE(0x40004c1d)                                      // 0x8000001c: ???
    //STRING_END()
    //STRING_START(9)
    CONTENT_LANGUAGE(0x40004b8d)                                      // 0x8000001d: Track
    CONTENT_LANGUAGE(0x40004c29)                                      // 0x8000001d: Piste
    CONTENT_LANGUAGE(0x40004c2a)                                      // 0x8000001d: Tema
    CONTENT_LANGUAGE(0x40004bc3)                                      // 0x8000001d: Titel
    CONTENT_LANGUAGE(0x40004bc3)                                      // 0x8000001d: Titel
    CONTENT_LANGUAGE(0x40004c2b)                                      // 0x8000001d: Traccia
    CONTENT_LANGUAGE(0x40004c2c)                                      // 0x8000001d: Faixa
    CONTENT_LANGUAGE(0x40004c2d)                                      // 0x8000001d: ?????
    CONTENT_LANGUAGE(0x40004c2e)                                      // 0x8000001d: Par�a
    CONTENT_LANGUAGE(0x40004b8d)                                      // 0x8000001d: Track
    CONTENT_LANGUAGE(0x40004c2f)                                      // 0x8000001d: Titre
    CONTENT_LANGUAGE(0x40004c30)                                      // 0x8000001d: Pista
    CONTENT_LANGUAGE(0x40004c31)                                      // 0x8000001d: Nummer
    CONTENT_LANGUAGE(0x40004c32)                                      // 0x8000001d: Sp�r
    CONTENT_LANGUAGE(0x40004c33)                                      // 0x8000001d: Raita
    CONTENT_LANGUAGE(0x40004c34)                                      // 0x8000001d: Spor
    CONTENT_LANGUAGE(0x40004c35)                                      // 0x8000001d: Utw�r
    CONTENT_LANGUAGE(0x40004c36)                                      // 0x8000001d: Titul
    CONTENT_LANGUAGE(0x40004c37)                                      // 0x8000001d: Skladba
    CONTENT_LANGUAGE(0x40004c38)                                      // 0x8000001d: S�v
    CONTENT_LANGUAGE(0x40004c39)                                      // 0x8000001d: ?????? ??????????
    CONTENT_LANGUAGE(0x40004c3a)                                      // 0x8000001d: T�tulo
    CONTENT_LANGUAGE(0x40004c3b)                                      // 0x8000001d: ???????
    CONTENT_LANGUAGE(0x40004c3c)                                      // 0x8000001d: ????
    CONTENT_LANGUAGE(0x40004c3d)                                      // 0x8000001d: ?????
    //STRING_END()
#endif // #ifdef CONTENT_LANGUAGE

CONTENT_END()
