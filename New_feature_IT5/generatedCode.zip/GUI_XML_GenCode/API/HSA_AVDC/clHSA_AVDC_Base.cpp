/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_AVDC_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_AVDC/clHSA_AVDC_Base.h"

clHSA_AVDC_Base* clHSA_AVDC_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_AVDC_Base.cpp.trc.h"
#endif


/**
 * Method: vQSInitQuickSearch
  * When Quick Search is started by the list position the API must evaluate what is the first character displayed in the Quick Search popup based on the current position in the list which is given as param1
  * NISSAN 1.5
 */
void clHSA_AVDC_Base::vQSInitQuickSearch(ulword ulwListPos)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListPos);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vQSInitQuickSearch not implemented"));
   
}

/**
 * Method: vGetQSCurrentCharacterGroup
  * This function provides the character which is shown in the Quick Search popup
  * NISSAN 1.5
 */
void clHSA_AVDC_Base::vGetQSCurrentCharacterGroup(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vGetQSCurrentCharacterGroup not implemented"));
   
}

/**
 * Method: vSetQSIncreaseCurrentCharacterGroup
  * Makes the API increasing the position in the character grouping list
  * NISSAN 1.5
 */
void clHSA_AVDC_Base::vSetQSIncreaseCurrentCharacterGroup( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vSetQSIncreaseCurrentCharacterGroup not implemented"));
   
}

/**
 * Method: vSetQSDecreaseCurrentCharacterGroup
  * Makes the API decreasing the position in the character grouping list
  * NISSAN 1.5
 */
void clHSA_AVDC_Base::vSetQSDecreaseCurrentCharacterGroup( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vSetQSDecreaseCurrentCharacterGroup not implemented"));
   
}

/**
 * Method: vQSStartSearch
  * This function makes the API calling the interface towards the middleware to start the quick search by using the currently selected letter. As the control of the current displayed character is in the hand of the API layer it must not be given as parameter.
  * NISSAN 1.5
 */
void clHSA_AVDC_Base::vQSStartSearch( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vQSStartSearch not implemented"));
   
}

/**
 * Method: ulwGetQSCurrentCharacterGroupIndex
  * GetQuicksearch character index group
  * NISSAN 1.5
 */
ulword clHSA_AVDC_Base::ulwGetQSCurrentCharacterGroupIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetQSCurrentCharacterGroupIndex not implemented"));
   return 0;
}

/**
 * Method: blGetQSOptionVisibility
  * The Quick Search button will be visible / invisible for some condition 0 - invisible , 1 - visible
  * NISSAN 1.5
 */
tbool clHSA_AVDC_Base::blGetQSOptionVisibility( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC::blGetQSOptionVisibility not implemented"));
   return 0;
}

/**
 * Method: ulwGetAVDCListPosition
  * Used for reposition the MP3/USB/IPOD list
  * NISSAN 1.5
 */
ulword clHSA_AVDC_Base::ulwGetAVDCListPosition( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetAVDCListPosition not implemented"));
   return 0;
}

/**
 * Method: blIsMixmodeComplete
  * Mix operation active in IPOD or not
  * NISSAN 1.5
 */
tbool clHSA_AVDC_Base::blIsMixmodeComplete( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC::blIsMixmodeComplete not implemented"));
   return 0;
}

/**
 * Method: blIsUSBConnected
  * Used to inform GUI if a USB is connected to target
  * NISSAN LCN2Kai
 */
tbool clHSA_AVDC_Base::blIsUSBConnected( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC::blIsUSBConnected not implemented"));
   return 0;
}

/**
 * Method: blDisplayAllField
  * Is used to display all option in lists of metadata browsing
  * NISSAN 2
 */
tbool clHSA_AVDC_Base::blDisplayAllField( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC::blDisplayAllField not implemented"));
   return 0;
}

/**
 * Method: vToggleSources_MFL_Order
  * Toggles sources (MFL_SOURCE)
  * NISSAN
 */
void clHSA_AVDC_Base::vToggleSources_MFL_Order( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vToggleSources_MFL_Order not implemented"));
   
}

/**
 * Method: ulwGetCurrentAuxSource
  * returns current aux source
  * NISSAN
 */
ulword clHSA_AVDC_Base::ulwGetCurrentAuxSource( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetCurrentAuxSource not implemented"));
   return 0;
}

/**
 * Method: vToggleAvailableAuxSources
  * Toggles the available aux sources (GUI HK-AUX)
  * NISSAN
 */
void clHSA_AVDC_Base::vToggleAvailableAuxSources( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vToggleAvailableAuxSources not implemented"));
   
}

/**
 * Method: vActivateDisc
  * Starts playing the selected disc
  * B
 */
void clHSA_AVDC_Base::vActivateDisc(ulword ulwEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vActivateDisc not implemented"));
   
}

/**
 * Method: vActivateNextDisc
  * This APICall is used to toggle the CDs from the CDChanger. 
  * B
 */
void clHSA_AVDC_Base::vActivateNextDisc( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vActivateNextDisc not implemented"));
   
}

/**
 * Method: vCancelCheckSelectedItem
  * This APICall is called in the screens MEDIA_PO_CHECK_AUDIO_FILES_DISPLAY and MEDIA_PO_CHECK_AUDIO_FILES_PLAY, on pressing the SK_Cancel.The function cancels the checking-process of the files.
  * B
 */
void clHSA_AVDC_Base::vCancelCheckSelectedItem( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vCancelCheckSelectedItem not implemented"));
   
}

/**
 * Method: vChangeBrowserScreen
  * Called during the browser-animation  in order to inform the HMI level that the old data are not needed anymore.
  * B
 */
void clHSA_AVDC_Base::vChangeBrowserScreen( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vChangeBrowserScreen not implemented"));
   
}

/**
 * Method: vEnterCategory
  * Will be called when user selects particualt category from Root category screen in IPOD
  * B
 */
void clHSA_AVDC_Base::vEnterCategory(ulword ulwParamContext, ulword ulwCategoryType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwParamContext);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCategoryType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vEnterCategory not implemented"));
   
}

/**
 * Method: ulwGetBrowserType
  * Called to detemine type of browsing
  * B
 */
ulword clHSA_AVDC_Base::ulwGetBrowserType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetBrowserType not implemented"));
   return 0;
}

/**
 * Method: slwGetCurrentUSBPlayer
  * Returns from which player USB is currently plaing from.
  * B
 */
slword clHSA_AVDC_Base::slwGetCurrentUSBPlayer( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_AVDC::slwGetCurrentUSBPlayer not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentModeForTextDisplay
  * Returns the active mode of the player functions ( scan, mix, repeat) to display text in Nissan LCN2kai.
  * B1
 */
ulword clHSA_AVDC_Base::ulwGetCurrentModeForTextDisplay( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetCurrentModeForTextDisplay not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentModeForTextDisplay_MP
  * Returns the active mode of the Mediaplayer functions ( scan, mix, repeat) to display text in Nissan LCN2kai. Associated with API GetCurrentMixMode and GetCurrentRepeatMode
  * B1
 */
ulword clHSA_AVDC_Base::ulwGetCurrentModeForTextDisplay_MP( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetCurrentModeForTextDisplay_MP not implemented"));
   return 0;
}

/**
 * Method: vEnterSelectedItem
  * Browser function. Opens a folder/ playlist or plays a file. Used on HK_ENTER pressed event.
  * B2
 */
void clHSA_AVDC_Base::vEnterSelectedItem(ulword ulwEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vEnterSelectedItem not implemented"));
   
}

/**
 * Method: vExitBrowser
  * Called when the Browser is closed.
  * B
 */
void clHSA_AVDC_Base::vExitBrowser( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vExitBrowser not implemented"));
   
}

/**
 * Method: vEjectDisc
  * Called when on SK_OK in the PopUp MEDIA_PO_CD_ERROR.
  * B
 */
void clHSA_AVDC_Base::vEjectDisc( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vEjectDisc not implemented"));
   
}

/**
 * Method: blGetAUX2InputState
  * Gets the AUX2Input state (Only for the Seat variant; used in Media setup)
  * B
 */
tbool clHSA_AVDC_Base::blGetAUX2InputState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC::blGetAUX2InputState not implemented"));
   return 0;
}

/**
 * Method: ulwGetAUXInputLevel
  * Gets the AUXInput level
  * B1
 */
ulword clHSA_AVDC_Base::ulwGetAUXInputLevel( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetAUXInputLevel not implemented"));
   return 0;
}

/**
 * Method: ulwGetBrowserItemCount
  * Returns the number of folders, playlists and files shown in the browser
  * B2
 */
ulword clHSA_AVDC_Base::ulwGetBrowserItemCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetBrowserItemCount not implemented"));
   return 0;
}

/**
 * Method: vGetBrowserItemName
  * Returns a string with  the title name of  the  browser item with the index given as parameter.
  * B2
 */
void clHSA_AVDC_Base::vGetBrowserItemName(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vGetBrowserItemName not implemented"));
   
}

/**
 * Method: vGetBrowserItemTrackNr
  * Returns the track number of  the  browser item with the index given as parameter.Used only for CDChanger, CD audio and MDI-when only the trackNr is available (title name and ID3 not available)
  * B2
 */
void clHSA_AVDC_Base::vGetBrowserItemTrackNr(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vGetBrowserItemTrackNr not implemented"));
   
}

/**
 * Method: ulwGetBrowserItemType
  * Returns a number that represents  the type of  the browser item with the index given as parameter. Used in the browser to show different button-images for files, folders and playlists.
  * B2
 */
ulword clHSA_AVDC_Base::ulwGetBrowserItemType(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetBrowserItemType not implemented"));
   return 0;
}

/**
 * Method: vGetBrowserItemTypeString
  * Returns a string that represents  the type of  the browser item with the index given as parameter. Used in the browser to show different button-images for files, folders and playlists.
  * B2
 */
void clHSA_AVDC_Base::vGetBrowserItemTypeString(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vGetBrowserItemTypeString not implemented"));
   
}

/**
 * Method: ulwGetBrowserLoadingState
  * returns 1 if the Browser data was loaded, 0 if the data is loading
  * B2
 */
ulword clHSA_AVDC_Base::ulwGetBrowserLoadingState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetBrowserLoadingState not implemented"));
   return 0;
}

/**
 * Method: ulwGetCDCDiscState
  * gets the state of the CD selected by the user in the CD-Changer hub (see diagram MEDIA_CDC_DESKTOP, view MEDIA_CDC_DESKTOP_HUB )
  * B
 */
ulword clHSA_AVDC_Base::ulwGetCDCDiscState(ulword ulwEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetCDCDiscState not implemented"));
   return 0;
}

/**
 * Method: ulwGetCDCNumberOfDiscs
  * Returns the number of CDs present in the CD changer
  * 
 */
ulword clHSA_AVDC_Base::ulwGetCDCNumberOfDiscs( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetCDCNumberOfDiscs not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentFolderLevel
  * Returns the level of the opened folder in the browser. The function returns 0 for the root level and an integer > 0 for the subfolders.
  * B2
 */
ulword clHSA_AVDC_Base::ulwGetCurrentFolderLevel( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetCurrentFolderLevel not implemented"));
   return 0;
}

/**
 * Method: slwGetCurrentSource
  * Returns the current media source, which is already playing or was selected to be started next.
  * B1
 */
slword clHSA_AVDC_Base::slwGetCurrentSource( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_AVDC::slwGetCurrentSource not implemented"));
   return 0;
}

/**
 * Method: ulwGetFollowModeItem
  * returns the activeItem
  * 
 */
ulword clHSA_AVDC_Base::ulwGetFollowModeItem( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetFollowModeItem not implemented"));
   return 0;
}

/**
 * Method: ulwGetMDIInputLevel
  * Gets the MDI Input level
  * B
 */
ulword clHSA_AVDC_Base::ulwGetMDIInputLevel( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetMDIInputLevel not implemented"));
   return 0;
}

/**
 * Method: vGetPath
  * Returns the folder path of the current browser level.  
  * B2
 */
void clHSA_AVDC_Base::vGetPath(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vGetPath not implemented"));
   
}

/**
 * Method: ulwGetRequestInfoState
  * Used in the media browser for the WaitSyncMediator.
  * B2
 */
ulword clHSA_AVDC_Base::ulwGetRequestInfoState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetRequestInfoState not implemented"));
   return 0;
}

/**
 * Method: vGetSelectedItemInfo
  * Returns information about the selected Item in the Browser.(ID3;path).
  * B2
 */
void clHSA_AVDC_Base::vGetSelectedItemInfo(GUI_String *out_result, ulword uwArrayIndex, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(uwArrayIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vGetSelectedItemInfo not implemented"));
   
}

/**
 * Method: vGoToRootFolder
  * Browser function - used on subfolder-levels  to open the root folder. (Called on SK_LEFT= Up longpress event)
  * B2
 */
void clHSA_AVDC_Base::vGoToRootFolder( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vGoToRootFolder not implemented"));
   
}

/**
 * Method: vGoToUpperLevel
  * Browser function - used on subfolder-levels to go back to the parent folder (Called on SK_LEFT= Up press event)
  * B2
 */
void clHSA_AVDC_Base::vGoToUpperLevel( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vGoToUpperLevel not implemented"));
   
}

/**
 * Method: ulwIsInfoAvailable
  * returns true, if Info available for the active track
  * B
 */
ulword clHSA_AVDC_Base::ulwIsInfoAvailable( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwIsInfoAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsMDIAvailable
  * returns true, if MDI box attached
  * B
 */
tbool clHSA_AVDC_Base::blIsMDIAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC::blIsMDIAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsMDITrackListAvailable
  * returns true, if a track list is available for the active MDI
  * B
 */
tbool clHSA_AVDC_Base::blIsMDITrackListAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC::blIsMDITrackListAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwIsMediaAvailable
  * returns 1, if at least one media source is available (can be played)
  * B1
 */
ulword clHSA_AVDC_Base::ulwIsMediaAvailable( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwIsMediaAvailable not implemented"));
   return 0;
}

/**
 * Method: vLeaveSource
  * Used in the PopUp screens MEDIA_PO_MDI_CONNECTION_INTERRUPTED_AUX and MEDIA_PO_MDI_CONNECTION_INTERRUPTED_MDI_LIST. The function is called on pressing the SK_Cancel and makes possible the automatic change to the last active source.
  * B
 */
void clHSA_AVDC_Base::vLeaveSource( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vLeaveSource not implemented"));
   
}

/**
 * Method: vLoadBrowser
  * triggered when the user opens the browser, in order to load the current listitems.
  * B2
 */
void clHSA_AVDC_Base::vLoadBrowser( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vLoadBrowser not implemented"));
   
}

/**
 * Method: vPlaySelectedItem
  * Starts playing the selected media item. Called in GUI on SK_Play press event.
  * B2
 */
void clHSA_AVDC_Base::vPlaySelectedItem(ulword ulwEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vPlaySelectedItem not implemented"));
   
}

/**
 * Method: vPrepareSelectedListItemInfo
  * Called in the mp3 browser when the user presses the HK_Info, in order to inform the application, that the mp3 infos have to be prepared for display.
  * B1
 */
void clHSA_AVDC_Base::vPrepareSelectedListItemInfo(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vPrepareSelectedListItemInfo not implemented"));
   
}

/**
 * Method: vSetAUXInputLevel
  * Sets the AUX input level (option in media-setup)
  * B1
 */
void clHSA_AVDC_Base::vSetAUXInputLevel(ulword ulwLevel)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLevel);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vSetAUXInputLevel not implemented"));
   
}

/**
 * Method: vSetMDIInputLevel
  * Sets the MDI input level (option in media-setup) - only if MDI available
  * B
 */
void clHSA_AVDC_Base::vSetMDIInputLevel(ulword ulwLevel)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLevel);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vSetMDIInputLevel not implemented"));
   
}

/**
 * Method: vSetSource
  * Activates and plays the selected source. (Must be adjusted for the Seat variant)
  * B1
 */
void clHSA_AVDC_Base::vSetSource(ulword ulwSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSource);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vSetSource not implemented"));
   
}

/**
 * Method: vStopFollowMode
  * Used in the browser to stop the follow mode when the user starts browsing, or when he activates a new track per touch or RE-Press
  * B
 */
void clHSA_AVDC_Base::vStopFollowMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vStopFollowMode not implemented"));
   
}

/**
 * Method: vToggleAUX2InputState
  * Toggles thestate of the AUX2 input (used in media setup)
  * B
 */
void clHSA_AVDC_Base::vToggleAUX2InputState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vToggleAUX2InputState not implemented"));
   
}

/**
 * Method: vToggleAvailableSources
  * Toggles the available media sources (GUI: HK_MEDIA in MEDIA_DESKTOP_HUB)
  * B1
 */
void clHSA_AVDC_Base::vToggleAvailableSources( )
{
   
   ETG_TRACE_USR4(("function void clHSA_AVDC::vToggleAvailableSources not implemented"));
   
}

/**
 * Method: ulwGetCurrentRepeatMode
  * returns current repeat mode (only IPOD)
  * PT1
 */
ulword clHSA_AVDC_Base::ulwGetCurrentRepeatMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetCurrentRepeatMode not implemented"));
   return 0;
}

/**
 * Method: blIsIPODPlaystatusAvailable
  * Indicates if the IPOD started playing. This interface will be used for disabling the browse button until IPOD starts playing
  * NISSAN LCN2
 */
tbool clHSA_AVDC_Base::blIsIPODPlaystatusAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_AVDC::blIsIPODPlaystatusAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsIPODIndexPlayable
  * Return true if selected item can be playable.
  * NISSAN LCN2
 */
tbool clHSA_AVDC_Base::blIsIPODIndexPlayable(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_AVDC::blIsIPODIndexPlayable not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentMixMode
  * returns current mix mode (only IPOD)
  * PT1
 */
ulword clHSA_AVDC_Base::ulwGetCurrentMixMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_AVDC::ulwGetCurrentMixMode not implemented"));
   return 0;
}

/**
 * Method: vFolderSkip
  * Will be called when user press HK left or right to play the next or previous folder song 
  * ITGH5SD
 */
void clHSA_AVDC_Base::vFolderSkip(ulword ulwSkipDirection)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSkipDirection);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_AVDC::vFolderSkip not implemented"));
   
}

