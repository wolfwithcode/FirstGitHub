/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_XMRadio_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_XMRadio_Base_H
#define _clHSA_XMRadio_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_XMRadio_Base : public clHSA_Base
{
public:

    static clHSA_XMRadio_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_XMRadio_Base()        {}

    virtual void vActivateSource( );

    virtual tbool blIsCategoryIconAvailable( );

    virtual tbool blIsChannelIconAvailable( );

    virtual tbool blIsArtistIconAvailable( );

    virtual tbool blIsTitleIconAvailable( );

    virtual ulword ulwGetCurrentChannelNumber( );

    virtual void vGetCurrentArtistName(GUI_String *out_result);

    virtual void vGetCurrentCategoryName(GUI_String *out_result);

    virtual void vGetCurrentChannelName(GUI_String *out_result);

    virtual void vGetCurrentSongName(GUI_String *out_result);

    virtual ulword ulwGetCurrentPresetBank( );

    virtual ulword ulwGetActiveXMChannelPresetNr( );

    virtual ulword ulwGetXMAdvisoryMessage( );

    virtual void vXMRadioSelectChannelUp(ulword ulwNoOfSteps);

    virtual void vXMRadioSelectChannelDown(ulword ulwNoOfSteps);

    virtual ulword ulwGetChannelListStatus( );

    virtual ulword ulwGetChannelListCount( );

    virtual ulword ulwGetChannelListActiveChannelIndex( );

    virtual void vGetChannelListElement(GUI_String *out_result, ulword ulwIndex, ulword ulwElementType);

    virtual void vSelectFromChannelList(ulword ulwIndex);

    virtual tbool blIsCategoryListAvailable( );

    virtual ulword ulwGetCategoryListStatus( );

    virtual ulword ulwGetCategoryListCount( );

    virtual ulword ulwGetCategoryListActiveCategoryIndex( );

    virtual void vGetCategoryName(GUI_String *out_result, ulword ulwIndex);

    virtual ulword ulwGetNumberOfChannelsForCategory(ulword ulwIndex);

    virtual ulword ulwGetChannelListToCatStatus(ulword ulwCategoryIndex);

    virtual slword slwGetCategoryListActiveChannelIndex( );

    virtual void vGetChannelElementFromCategory(GUI_String *out_result, ulword ulwCategoryIndex, ulword ulwChannelIndex, ulword ulwElementType);

    virtual void vSelectFromCategoryList(ulword ulwCategoryIndex, ulword ulwChannelIndex);

    virtual void vTogglePresetBank( );

    virtual void vRecallPreset(ulword ulwPresetNr);

    virtual void vStorePreset(ulword ulwPresetNr);

    virtual void vSeekPreset(ulword ulwDirection);

    virtual void vScrollChannelUp(ulword ulwNoOfSteps);

    virtual void vScrollChannelDown(ulword ulwNoOfSteps);

    virtual void vAbortChannelScroll( );

    virtual ulword ulwGetChannelScrollStatus( );

    virtual void vSeekCategoryUp(ulword ulwNoOfSteps);

    virtual void vSeekCategoryDown(ulword ulwNoOfSteps);

    virtual void vScrollCategoryUp(ulword ulwNoOfSteps);

    virtual void vScrollCategoryDown(ulword ulwNoOfSteps);

    virtual void vSeekCategoryChannelUp(ulword ulwNoOfSteps);

    virtual void vSeekCategoryChannelDown(ulword ulwNoOfSteps);

    virtual void vAbortCategorySearch( );

    virtual ulword ulwGetCategorySearchStatus( );

    virtual void vActivateXMDiag(ulword ulwAction);

    virtual ulword ulwGetSignalStrength( );

    virtual ulword ulwGetXMRadioSubscriptionStatus( );

    virtual ulword ulwGetXMNavtrafficSubscriptionStatus( );

    virtual void vGetLastMesgReceivedDetails(GUI_String *out_result);

    virtual void vGetXMRadioID(GUI_String *out_result);

    virtual void vGetXMServiceMonitorDetails(GUI_String *out_result, ulword ulwLineNo);

    virtual void vGetXMSDecVersion(GUI_String *out_result);

    virtual void vGetXMSTKVersion(GUI_String *out_result);

    virtual void vGetXMCBMStackVersion(GUI_String *out_result);

    virtual void vGetSWModVersion(GUI_String *out_result);

    virtual void vGetHWversion(GUI_String *out_result);

    virtual void vClearXMChipsetNVM( );

    virtual void vResetALLXMSetting( );

    virtual void vToggleCBMDebugMode( );

    virtual void vToggleExternalDiagMode( );

    virtual tbool blCBMDebugModeState( );

    virtual tbool blExternalDiagModeState( );

    virtual void vResetXMChnGr( );

    virtual void vGetCurrentChannelNumberInString(GUI_String *out_result);

    virtual slword slwGetChannelGraphicsPicElementID( );

    virtual void vGetSxmChannelArtImageId(GUI_String *out_result);

    virtual void vStartSXMWeatherRequest( );

    virtual void vSXMSetRequestModeType(ulword ulwRequestLocationType);

    virtual ulword ulwGetSXMRequestModeType( );

    virtual slword slwGetSXMWeatherRequestTempCurrent( );

    virtual void vGetSXMCurrentWeatherHumidity(GUI_String *out_result);

    virtual void vGetSXMWeatherRequestWinddirection(GUI_String *out_result);

    virtual void vGetSXMWeatherRequestWindspeed(GUI_String *out_result);

    virtual ulword ulwGetSXMCurrentWeatherCondition( );

    virtual ulword ulwGetSXMForecastWeatherCondition(ulword ulwListEntryNr);

    virtual ulword ulwGetSXMForecastWeather_count( );

    virtual slword slwGetSXMWeatherRequestTempMax(ulword ulwListEntryNr);

    virtual slword slwGetSXMWeatherRequestTempMin(ulword ulwListEntryNr);

    virtual ulword ulwGetSXMForecastWeatherDayOfWeek(ulword ulwListEntryNr);

    virtual ulword ulwGetSXMWeatherRequestRainPropabiltiy( );

    virtual ulword ulwGetSXMWeatherRequestPrecipitationType( );

    virtual void vGetLastSXMWeatherRequestCityName(GUI_String *out_result);

    virtual tbool blIsLastWeatherRequestOutdated( );

    virtual tbool blIsRepeatLastRequestPossible( );

    virtual ulword ulwGetXMWeatherAdvisoryMessage( );

    virtual ulword ulwGetSXMRequestType( );

    virtual void vSetSXMRequestType(ulword ulwulwReqType);

    virtual ulword ulwGetSXMRequestStatus( );

    virtual void vLocationModeChange( );

    virtual void vIsMapDataAvailable( );

    virtual tbool blIsWindSpeedAvailable( );

    virtual tbool blIsHumidityAvailable( );

    virtual tbool blIsPrecipitationAvailable( );

    virtual void vGetSXMWeatherStationName(GUI_String *out_result);

    virtual ulword ulwGetXMTravelLinkStatus( );

protected:
    clHSA_XMRadio_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_XMRadio_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_XMRadio_Base_H

