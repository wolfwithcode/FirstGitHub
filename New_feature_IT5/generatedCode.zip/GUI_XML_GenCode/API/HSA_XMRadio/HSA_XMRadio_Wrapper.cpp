/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_XMRadio_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_XMRadio_Wrapper.h"
#include "clHSA_XMRadio_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_XMRadio_Trace.h"
#include "hmi_trace.h"

void HSA_XMRadio__vActivateSource( )
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_SOURCE  ) ); 
        }
      pInst->vActivateSource();

    }
}

tbool HSA_XMRadio__blIsCategoryIconAvailable( )
{
    tbool ret = false;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_CATEGORY_ICON_AVAILABLE  ) ); 
        }
      ret=pInst->blIsCategoryIconAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_CATEGORY_ICON_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_XMRadio__blIsChannelIconAvailable( )
{
    tbool ret = false;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_CHANNEL_ICON_AVAILABLE  ) ); 
        }
      ret=pInst->blIsChannelIconAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_CHANNEL_ICON_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_XMRadio__blIsArtistIconAvailable( )
{
    tbool ret = false;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_ARTIST_ICON_AVAILABLE  ) ); 
        }
      ret=pInst->blIsArtistIconAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_ARTIST_ICON_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_XMRadio__blIsTitleIconAvailable( )
{
    tbool ret = false;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_TITLE_ICON_AVAILABLE  ) ); 
        }
      ret=pInst->blIsTitleIconAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_TITLE_ICON_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetCurrentChannelNumber( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NUMBER  ) ); 
        }
      ret=pInst->ulwGetCurrentChannelNumber();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NUMBER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vGetCurrentArtistName(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_ARTIST_NAME  ) ); 
        }
      pInst->vGetCurrentArtistName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_ARTIST_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vGetCurrentCategoryName(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CATEGORY_NAME  ) ); 
        }
      pInst->vGetCurrentCategoryName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CATEGORY_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vGetCurrentChannelName(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NAME  ) ); 
        }
      pInst->vGetCurrentChannelName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vGetCurrentSongName(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SONG_NAME  ) ); 
        }
      pInst->vGetCurrentSongName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SONG_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_XMRadio__ulwGetCurrentPresetBank( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_PRESET_BANK  ) ); 
        }
      ret=pInst->ulwGetCurrentPresetBank();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_PRESET_BANK | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetActiveXMChannelPresetNr( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_XM_CHANNEL_PRESET_NR  ) ); 
        }
      ret=pInst->ulwGetActiveXMChannelPresetNr();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_XM_CHANNEL_PRESET_NR | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetXMAdvisoryMessage( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_ADVISORY_MESSAGE  ) ); 
        }
      ret=pInst->ulwGetXMAdvisoryMessage();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_ADVISORY_MESSAGE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vXMRadioSelectChannelUp(ulword ulwNoOfSteps)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__XM_RADIO_SELECT_CHANNEL_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vXMRadioSelectChannelUp(ulwNoOfSteps);

    }
}

void HSA_XMRadio__vXMRadioSelectChannelDown(ulword ulwNoOfSteps)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__XM_RADIO_SELECT_CHANNEL_DOWN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vXMRadioSelectChannelDown(ulwNoOfSteps);

    }
}

ulword HSA_XMRadio__ulwGetChannelListStatus( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_STATUS  ) ); 
        }
      ret=pInst->ulwGetChannelListStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetChannelListCount( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetChannelListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetChannelListActiveChannelIndex( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_ACTIVE_CHANNEL_INDEX  ) ); 
        }
      ret=pInst->ulwGetChannelListActiveChannelIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_ACTIVE_CHANNEL_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vGetChannelListElement(GUI_String *out_result, ulword ulwIndex, ulword ulwElementType)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_ELEMENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_ELEMENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwElementType); 
        }
      pInst->vGetChannelListElement(out_result, ulwIndex, ulwElementType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_ELEMENT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vSelectFromChannelList(ulword ulwIndex)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SELECT_FROM_CHANNEL_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vSelectFromChannelList(ulwIndex);

    }
}

tbool HSA_XMRadio__blIsCategoryListAvailable( )
{
    tbool ret = false;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_CATEGORY_LIST_AVAILABLE  ) ); 
        }
      ret=pInst->blIsCategoryListAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_CATEGORY_LIST_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetCategoryListStatus( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_STATUS  ) ); 
        }
      ret=pInst->ulwGetCategoryListStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetCategoryListCount( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetCategoryListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetCategoryListActiveCategoryIndex( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_ACTIVE_CATEGORY_INDEX  ) ); 
        }
      ret=pInst->ulwGetCategoryListActiveCategoryIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_ACTIVE_CATEGORY_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vGetCategoryName(GUI_String *out_result, ulword ulwIndex)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vGetCategoryName(out_result, ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_XMRadio__ulwGetNumberOfChannelsForCategory(ulword ulwIndex)
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_NUMBER_OF_CHANNELS_FOR_CATEGORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      ret=pInst->ulwGetNumberOfChannelsForCategory(ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_NUMBER_OF_CHANNELS_FOR_CATEGORY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetChannelListToCatStatus(ulword ulwCategoryIndex)
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_TO_CAT_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCategoryIndex); 
        }
      ret=pInst->ulwGetChannelListToCatStatus(ulwCategoryIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_TO_CAT_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_XMRadio__slwGetCategoryListActiveChannelIndex( )
{
    slword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_ACTIVE_CHANNEL_INDEX  ) ); 
        }
      ret=pInst->slwGetCategoryListActiveChannelIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_ACTIVE_CHANNEL_INDEX | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vGetChannelElementFromCategory(GUI_String *out_result, ulword ulwCategoryIndex, ulword ulwChannelIndex, ulword ulwElementType)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_ELEMENT_FROM_CATEGORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCategoryIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_ELEMENT_FROM_CATEGORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwChannelIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_ELEMENT_FROM_CATEGORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwElementType); 
        }
      pInst->vGetChannelElementFromCategory(out_result, ulwCategoryIndex, ulwChannelIndex, ulwElementType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_ELEMENT_FROM_CATEGORY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vSelectFromCategoryList(ulword ulwCategoryIndex, ulword ulwChannelIndex)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SELECT_FROM_CATEGORY_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCategoryIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SELECT_FROM_CATEGORY_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwChannelIndex); 
        }
      pInst->vSelectFromCategoryList(ulwCategoryIndex, ulwChannelIndex);

    }
}

void HSA_XMRadio__vTogglePresetBank( )
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_PRESET_BANK  ) ); 
        }
      pInst->vTogglePresetBank();

    }
}

void HSA_XMRadio__vRecallPreset(ulword ulwPresetNr)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__RECALL_PRESET | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPresetNr); 
        }
      pInst->vRecallPreset(ulwPresetNr);

    }
}

void HSA_XMRadio__vStorePreset(ulword ulwPresetNr)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__STORE_PRESET | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPresetNr); 
        }
      pInst->vStorePreset(ulwPresetNr);

    }
}

void HSA_XMRadio__vSeekPreset(ulword ulwDirection)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_PRESET | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDirection); 
        }
      pInst->vSeekPreset(ulwDirection);

    }
}

void HSA_XMRadio__vScrollChannelUp(ulword ulwNoOfSteps)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SCROLL_CHANNEL_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vScrollChannelUp(ulwNoOfSteps);

    }
}

void HSA_XMRadio__vScrollChannelDown(ulword ulwNoOfSteps)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SCROLL_CHANNEL_DOWN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vScrollChannelDown(ulwNoOfSteps);

    }
}

void HSA_XMRadio__vAbortChannelScroll( )
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__ABORT_CHANNEL_SCROLL  ) ); 
        }
      pInst->vAbortChannelScroll();

    }
}

ulword HSA_XMRadio__ulwGetChannelScrollStatus( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_SCROLL_STATUS  ) ); 
        }
      ret=pInst->ulwGetChannelScrollStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_SCROLL_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vSeekCategoryUp(ulword ulwNoOfSteps)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_CATEGORY_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vSeekCategoryUp(ulwNoOfSteps);

    }
}

void HSA_XMRadio__vSeekCategoryDown(ulword ulwNoOfSteps)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_CATEGORY_DOWN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vSeekCategoryDown(ulwNoOfSteps);

    }
}

void HSA_XMRadio__vScrollCategoryUp(ulword ulwNoOfSteps)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SCROLL_CATEGORY_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vScrollCategoryUp(ulwNoOfSteps);

    }
}

void HSA_XMRadio__vScrollCategoryDown(ulword ulwNoOfSteps)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SCROLL_CATEGORY_DOWN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vScrollCategoryDown(ulwNoOfSteps);

    }
}

void HSA_XMRadio__vSeekCategoryChannelUp(ulword ulwNoOfSteps)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_CATEGORY_CHANNEL_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vSeekCategoryChannelUp(ulwNoOfSteps);

    }
}

void HSA_XMRadio__vSeekCategoryChannelDown(ulword ulwNoOfSteps)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_CATEGORY_CHANNEL_DOWN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vSeekCategoryChannelDown(ulwNoOfSteps);

    }
}

void HSA_XMRadio__vAbortCategorySearch( )
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__ABORT_CATEGORY_SEARCH  ) ); 
        }
      pInst->vAbortCategorySearch();

    }
}

ulword HSA_XMRadio__ulwGetCategorySearchStatus( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_SEARCH_STATUS  ) ); 
        }
      ret=pInst->ulwGetCategorySearchStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_SEARCH_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vActivateXMDiag(ulword ulwAction)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_XM_DIAG | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwAction); 
        }
      pInst->vActivateXMDiag(ulwAction);

    }
}

ulword HSA_XMRadio__ulwGetSignalStrength( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SIGNAL_STRENGTH  ) ); 
        }
      ret=pInst->ulwGetSignalStrength();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SIGNAL_STRENGTH | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetXMRadioSubscriptionStatus( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_RADIO_SUBSCRIPTION_STATUS  ) ); 
        }
      ret=pInst->ulwGetXMRadioSubscriptionStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_RADIO_SUBSCRIPTION_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetXMNavtrafficSubscriptionStatus( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_NAVTRAFFIC_SUBSCRIPTION_STATUS  ) ); 
        }
      ret=pInst->ulwGetXMNavtrafficSubscriptionStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_NAVTRAFFIC_SUBSCRIPTION_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vGetLastMesgReceivedDetails(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_MESG_RECEIVED_DETAILS  ) ); 
        }
      pInst->vGetLastMesgReceivedDetails(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_MESG_RECEIVED_DETAILS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vGetXMRadioID(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_RADIO_ID  ) ); 
        }
      pInst->vGetXMRadioID(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_RADIO_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vGetXMServiceMonitorDetails(GUI_String *out_result, ulword ulwLineNo)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_SERVICE_MONITOR_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLineNo); 
        }
      pInst->vGetXMServiceMonitorDetails(out_result, ulwLineNo);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_SERVICE_MONITOR_DETAILS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vGetXMSDecVersion(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XMS_DEC_VERSION  ) ); 
        }
      pInst->vGetXMSDecVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XMS_DEC_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vGetXMSTKVersion(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XMSTK_VERSION  ) ); 
        }
      pInst->vGetXMSTKVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XMSTK_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vGetXMCBMStackVersion(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XMCBM_STACK_VERSION  ) ); 
        }
      pInst->vGetXMCBMStackVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XMCBM_STACK_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vGetSWModVersion(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SW_MOD_VERSION  ) ); 
        }
      pInst->vGetSWModVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SW_MOD_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vGetHWversion(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_H_WVERSION  ) ); 
        }
      pInst->vGetHWversion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_H_WVERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vClearXMChipsetNVM( )
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__CLEAR_XM_CHIPSET_NVM  ) ); 
        }
      pInst->vClearXMChipsetNVM();

    }
}

void HSA_XMRadio__vResetALLXMSetting( )
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__RESET_ALLXM_SETTING  ) ); 
        }
      pInst->vResetALLXMSetting();

    }
}

void HSA_XMRadio__vToggleCBMDebugMode( )
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_CBM_DEBUG_MODE  ) ); 
        }
      pInst->vToggleCBMDebugMode();

    }
}

void HSA_XMRadio__vToggleExternalDiagMode( )
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_EXTERNAL_DIAG_MODE  ) ); 
        }
      pInst->vToggleExternalDiagMode();

    }
}

tbool HSA_XMRadio__blCBMDebugModeState( )
{
    tbool ret = false;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__CBM_DEBUG_MODE_STATE  ) ); 
        }
      ret=pInst->blCBMDebugModeState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__CBM_DEBUG_MODE_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_XMRadio__blExternalDiagModeState( )
{
    tbool ret = false;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__EXTERNAL_DIAG_MODE_STATE  ) ); 
        }
      ret=pInst->blExternalDiagModeState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__EXTERNAL_DIAG_MODE_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vResetXMChnGr( )
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__RESET_XM_CHN_GR  ) ); 
        }
      pInst->vResetXMChnGr();

    }
}

void HSA_XMRadio__vGetCurrentChannelNumberInString(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NUMBER_IN_STRING  ) ); 
        }
      pInst->vGetCurrentChannelNumberInString(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NUMBER_IN_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

slword HSA_XMRadio__slwGetChannelGraphicsPicElementID( )
{
    slword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_GRAPHICS_PIC_ELEMENT_ID  ) ); 
        }
      ret=pInst->slwGetChannelGraphicsPicElementID();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_GRAPHICS_PIC_ELEMENT_ID | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vGetSxmChannelArtImageId(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CHANNEL_ART_IMAGE_ID  ) ); 
        }
      pInst->vGetSxmChannelArtImageId(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CHANNEL_ART_IMAGE_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vStartSXMWeatherRequest( )
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__START_SXM_WEATHER_REQUEST  ) ); 
        }
      pInst->vStartSXMWeatherRequest();

    }
}

void HSA_XMRadio__vSXMSetRequestModeType(ulword ulwRequestLocationType)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SXM_SET_REQUEST_MODE_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRequestLocationType); 
        }
      pInst->vSXMSetRequestModeType(ulwRequestLocationType);

    }
}

ulword HSA_XMRadio__ulwGetSXMRequestModeType( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_REQUEST_MODE_TYPE  ) ); 
        }
      ret=pInst->ulwGetSXMRequestModeType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_REQUEST_MODE_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_XMRadio__slwGetSXMWeatherRequestTempCurrent( )
{
    slword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_TEMP_CURRENT  ) ); 
        }
      ret=pInst->slwGetSXMWeatherRequestTempCurrent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_TEMP_CURRENT | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vGetSXMCurrentWeatherHumidity(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_HUMIDITY  ) ); 
        }
      pInst->vGetSXMCurrentWeatherHumidity(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_HUMIDITY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vGetSXMWeatherRequestWinddirection(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_WINDDIRECTION  ) ); 
        }
      pInst->vGetSXMWeatherRequestWinddirection(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_WINDDIRECTION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_XMRadio__vGetSXMWeatherRequestWindspeed(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_WINDSPEED  ) ); 
        }
      pInst->vGetSXMWeatherRequestWindspeed(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_WINDSPEED | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_XMRadio__ulwGetSXMCurrentWeatherCondition( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_CONDITION  ) ); 
        }
      ret=pInst->ulwGetSXMCurrentWeatherCondition();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_CONDITION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetSXMForecastWeatherCondition(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_FORECAST_WEATHER_CONDITION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetSXMForecastWeatherCondition(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_FORECAST_WEATHER_CONDITION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetSXMForecastWeather_count( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_FORECAST_WEATHER_COUNT  ) ); 
        }
      ret=pInst->ulwGetSXMForecastWeather_count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_FORECAST_WEATHER_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_XMRadio__slwGetSXMWeatherRequestTempMax(ulword ulwListEntryNr)
{
    slword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_TEMP_MAX | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->slwGetSXMWeatherRequestTempMax(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_TEMP_MAX | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_XMRadio__slwGetSXMWeatherRequestTempMin(ulword ulwListEntryNr)
{
    slword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_TEMP_MIN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->slwGetSXMWeatherRequestTempMin(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_TEMP_MIN | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetSXMForecastWeatherDayOfWeek(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_FORECAST_WEATHER_DAY_OF_WEEK | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetSXMForecastWeatherDayOfWeek(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_FORECAST_WEATHER_DAY_OF_WEEK | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetSXMWeatherRequestRainPropabiltiy( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_RAIN_PROPABILTIY  ) ); 
        }
      ret=pInst->ulwGetSXMWeatherRequestRainPropabiltiy();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_RAIN_PROPABILTIY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetSXMWeatherRequestPrecipitationType( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_PRECIPITATION_TYPE  ) ); 
        }
      ret=pInst->ulwGetSXMWeatherRequestPrecipitationType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_PRECIPITATION_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vGetLastSXMWeatherRequestCityName(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_SXM_WEATHER_REQUEST_CITY_NAME  ) ); 
        }
      pInst->vGetLastSXMWeatherRequestCityName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_SXM_WEATHER_REQUEST_CITY_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_XMRadio__blIsLastWeatherRequestOutdated( )
{
    tbool ret = false;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_LAST_WEATHER_REQUEST_OUTDATED  ) ); 
        }
      ret=pInst->blIsLastWeatherRequestOutdated();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_LAST_WEATHER_REQUEST_OUTDATED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_XMRadio__blIsRepeatLastRequestPossible( )
{
    tbool ret = false;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_REPEAT_LAST_REQUEST_POSSIBLE  ) ); 
        }
      ret=pInst->blIsRepeatLastRequestPossible();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_REPEAT_LAST_REQUEST_POSSIBLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetXMWeatherAdvisoryMessage( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_WEATHER_ADVISORY_MESSAGE  ) ); 
        }
      ret=pInst->ulwGetXMWeatherAdvisoryMessage();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_WEATHER_ADVISORY_MESSAGE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_XMRadio__ulwGetSXMRequestType( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_REQUEST_TYPE  ) ); 
        }
      ret=pInst->ulwGetSXMRequestType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_REQUEST_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vSetSXMRequestType(ulword ulwulwReqType)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__SET_SXM_REQUEST_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwulwReqType); 
        }
      pInst->vSetSXMRequestType(ulwulwReqType);

    }
}

ulword HSA_XMRadio__ulwGetSXMRequestStatus( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_REQUEST_STATUS  ) ); 
        }
      ret=pInst->ulwGetSXMRequestStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_REQUEST_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vLocationModeChange( )
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__LOCATION_MODE_CHANGE  ) ); 
        }
      pInst->vLocationModeChange();

    }
}

void HSA_XMRadio__vIsMapDataAvailable( )
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_MAP_DATA_AVAILABLE  ) ); 
        }
      pInst->vIsMapDataAvailable();

    }
}

tbool HSA_XMRadio__blIsWindSpeedAvailable( )
{
    tbool ret = false;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_WIND_SPEED_AVAILABLE  ) ); 
        }
      ret=pInst->blIsWindSpeedAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_WIND_SPEED_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_XMRadio__blIsHumidityAvailable( )
{
    tbool ret = false;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_HUMIDITY_AVAILABLE  ) ); 
        }
      ret=pInst->blIsHumidityAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_HUMIDITY_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_XMRadio__blIsPrecipitationAvailable( )
{
    tbool ret = false;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_PRECIPITATION_AVAILABLE  ) ); 
        }
      ret=pInst->blIsPrecipitationAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__IS_PRECIPITATION_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_XMRadio__vGetSXMWeatherStationName(GUI_String *out_result)
{
    
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_STATION_NAME  ) ); 
        }
      pInst->vGetSXMWeatherStationName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_STATION_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_XMRadio__ulwGetXMTravelLinkStatus( )
{
    ulword ret = 0;
    clHSA_XMRadio_Base *pInst=clHSA_XMRadio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_TRAVEL_LINK_STATUS  ) ); 
        }
      ret=pInst->ulwGetXMTravelLinkStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_XMRADIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_TRAVEL_LINK_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

#ifdef __cplusplus
}
#endif

