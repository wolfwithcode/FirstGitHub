/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_XMRadio_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_XMRadio_Wrapper_H
#define _HSA_XMRadio_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: ActivateSource
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vActivateSource( void);

/**
 * Function: IsCategoryIconAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_XMRadio__blIsCategoryIconAvailable( void);

/**
 * Function: IsChannelIconAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_XMRadio__blIsChannelIconAvailable( void);

/**
 * Function: IsArtistIconAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_XMRadio__blIsArtistIconAvailable( void);

/**
 * Function: IsTitleIconAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_XMRadio__blIsTitleIconAvailable( void);

/**
 * Function: GetCurrentChannelNumber
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetCurrentChannelNumber( void);

/**
 * Function: GetCurrentArtistName
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetCurrentArtistName(GUI_String *out_result);

/**
 * Function: GetCurrentCategoryName
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetCurrentCategoryName(GUI_String *out_result);

/**
 * Function: GetCurrentChannelName
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetCurrentChannelName(GUI_String *out_result);

/**
 * Function: GetCurrentSongName
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetCurrentSongName(GUI_String *out_result);

/**
 * Function: GetCurrentPresetBank
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetCurrentPresetBank( void);

/**
 * Function: GetActiveXMChannelPresetNr
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetActiveXMChannelPresetNr( void);

/**
 * Function: GetXMAdvisoryMessage
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetXMAdvisoryMessage( void);

/**
 * Function: XMRadioSelectChannelUp
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vXMRadioSelectChannelUp(ulword ulwNoOfSteps);

/**
 * Function: XMRadioSelectChannelDown
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vXMRadioSelectChannelDown(ulword ulwNoOfSteps);

/**
 * Function: GetChannelListStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetChannelListStatus( void);

/**
 * Function: GetChannelListCount
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetChannelListCount( void);

/**
 * Function: GetChannelListActiveChannelIndex
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetChannelListActiveChannelIndex( void);

/**
 * Function: GetChannelListElement
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetChannelListElement(GUI_String *out_result, ulword ulwIndex, ulword ulwElementType);

/**
 * Function: SelectFromChannelList
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vSelectFromChannelList(ulword ulwIndex);

/**
 * Function: IsCategoryListAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_XMRadio__blIsCategoryListAvailable( void);

/**
 * Function: GetCategoryListStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetCategoryListStatus( void);

/**
 * Function: GetCategoryListCount
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetCategoryListCount( void);

/**
 * Function: GetCategoryListActiveCategoryIndex
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetCategoryListActiveCategoryIndex( void);

/**
 * Function: GetCategoryName
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetCategoryName(GUI_String *out_result, ulword ulwIndex);

/**
 * Function: GetNumberOfChannelsForCategory
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetNumberOfChannelsForCategory(ulword ulwIndex);

/**
 * Function: GetChannelListToCatStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetChannelListToCatStatus(ulword ulwCategoryIndex);

/**
 * Function: GetCategoryListActiveChannelIndex
 * NISSAN
 * NISSAN
 */
slword HSA_XMRadio__slwGetCategoryListActiveChannelIndex( void);

/**
 * Function: GetChannelElementFromCategory
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetChannelElementFromCategory(GUI_String *out_result, ulword ulwCategoryIndex, ulword ulwChannelIndex, ulword ulwElementType);

/**
 * Function: SelectFromCategoryList
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vSelectFromCategoryList(ulword ulwCategoryIndex, ulword ulwChannelIndex);

/**
 * Function: TogglePresetBank
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vTogglePresetBank( void);

/**
 * Function: RecallPreset
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vRecallPreset(ulword ulwPresetNr);

/**
 * Function: StorePreset
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vStorePreset(ulword ulwPresetNr);

/**
 * Function: SeekPreset
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vSeekPreset(ulword ulwDirection);

/**
 * Function: ScrollChannelUp
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vScrollChannelUp(ulword ulwNoOfSteps);

/**
 * Function: ScrollChannelDown
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vScrollChannelDown(ulword ulwNoOfSteps);

/**
 * Function: AbortChannelScroll
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vAbortChannelScroll( void);

/**
 * Function: GetChannelScrollStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetChannelScrollStatus( void);

/**
 * Function: SeekCategoryUp
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vSeekCategoryUp(ulword ulwNoOfSteps);

/**
 * Function: SeekCategoryDown
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vSeekCategoryDown(ulword ulwNoOfSteps);

/**
 * Function: ScrollCategoryUp
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vScrollCategoryUp(ulword ulwNoOfSteps);

/**
 * Function: ScrollCategoryDown
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vScrollCategoryDown(ulword ulwNoOfSteps);

/**
 * Function: SeekCategoryChannelUp
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vSeekCategoryChannelUp(ulword ulwNoOfSteps);

/**
 * Function: SeekCategoryChannelDown
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vSeekCategoryChannelDown(ulword ulwNoOfSteps);

/**
 * Function: AbortCategorySearch
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vAbortCategorySearch( void);

/**
 * Function: GetCategorySearchStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetCategorySearchStatus( void);

/**
 * Function: ActivateXMDiag
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vActivateXMDiag(ulword ulwAction);

/**
 * Function: GetSignalStrength
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetSignalStrength( void);

/**
 * Function: GetXMRadioSubscriptionStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetXMRadioSubscriptionStatus( void);

/**
 * Function: GetXMNavtrafficSubscriptionStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetXMNavtrafficSubscriptionStatus( void);

/**
 * Function: GetLastMesgReceivedDetails
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetLastMesgReceivedDetails(GUI_String *out_result);

/**
 * Function: GetXMRadioID
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetXMRadioID(GUI_String *out_result);

/**
 * Function: GetXMServiceMonitorDetails
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetXMServiceMonitorDetails(GUI_String *out_result, ulword ulwLineNo);

/**
 * Function: GetXMSDecVersion
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetXMSDecVersion(GUI_String *out_result);

/**
 * Function: GetXMSTKVersion
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetXMSTKVersion(GUI_String *out_result);

/**
 * Function: GetXMCBMStackVersion
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetXMCBMStackVersion(GUI_String *out_result);

/**
 * Function: GetSWModVersion
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetSWModVersion(GUI_String *out_result);

/**
 * Function: GetHWversion
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetHWversion(GUI_String *out_result);

/**
 * Function: ClearXMChipsetNVM
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vClearXMChipsetNVM( void);

/**
 * Function: ResetALLXMSetting
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vResetALLXMSetting( void);

/**
 * Function: ToggleCBMDebugMode
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vToggleCBMDebugMode( void);

/**
 * Function: ToggleExternalDiagMode
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vToggleExternalDiagMode( void);

/**
 * Function: CBMDebugModeState
 * NISSAN
 * NISSAN
 */
tbool HSA_XMRadio__blCBMDebugModeState( void);

/**
 * Function: ExternalDiagModeState
 * NISSAN
 * NISSAN
 */
tbool HSA_XMRadio__blExternalDiagModeState( void);

/**
 * Function: ResetXMChnGr
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vResetXMChnGr( void);

/**
 * Function: GetCurrentChannelNumberInString
 * NISSAN
 * NISSAN
 */
void HSA_XMRadio__vGetCurrentChannelNumberInString(GUI_String *out_result);

/**
 * Function: GetChannelGraphicsPicElementID
 * NISSAN
 * NISSAN
 */
slword HSA_XMRadio__slwGetChannelGraphicsPicElementID( void);

/**
 * Function: GetSxmChannelArtImageId
 * NISSANLCN2KAI
 * NISSAN
 */
void HSA_XMRadio__vGetSxmChannelArtImageId(GUI_String *out_result);

/**
 * Function: StartSXMWeatherRequest
 * NISSAN2.0
 * NISSAN
 */
void HSA_XMRadio__vStartSXMWeatherRequest( void);

/**
 * Function: SXMSetRequestModeType
 * NISSAN2.0
 * NISSAN
 */
void HSA_XMRadio__vSXMSetRequestModeType(ulword ulwRequestLocationType);

/**
 * Function: GetSXMRequestModeType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetSXMRequestModeType( void);

/**
 * Function: GetSXMWeatherRequestTempCurrent
 * NISSAN2.0
 * NISSAN
 */
slword HSA_XMRadio__slwGetSXMWeatherRequestTempCurrent( void);

/**
 * Function: GetSXMCurrentWeatherHumidity
 * NISSAN2.0
 * NISSAN
 */
void HSA_XMRadio__vGetSXMCurrentWeatherHumidity(GUI_String *out_result);

/**
 * Function: GetSXMWeatherRequestWinddirection
 * NISSAN2.0
 * NISSAN
 */
void HSA_XMRadio__vGetSXMWeatherRequestWinddirection(GUI_String *out_result);

/**
 * Function: GetSXMWeatherRequestWindspeed
 * NISSAN2.0
 * NISSAN
 */
void HSA_XMRadio__vGetSXMWeatherRequestWindspeed(GUI_String *out_result);

/**
 * Function: GetSXMCurrentWeatherCondition
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetSXMCurrentWeatherCondition( void);

/**
 * Function: GetSXMForecastWeatherCondition
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetSXMForecastWeatherCondition(ulword ulwListEntryNr);

/**
 * Function: GetSXMForecastWeather_count
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetSXMForecastWeather_count( void);

/**
 * Function: GetSXMWeatherRequestTempMax
 * NISSAN2.0
 * NISSAN
 */
slword HSA_XMRadio__slwGetSXMWeatherRequestTempMax(ulword ulwListEntryNr);

/**
 * Function: GetSXMWeatherRequestTempMin
 * NISSAN2.0
 * NISSAN
 */
slword HSA_XMRadio__slwGetSXMWeatherRequestTempMin(ulword ulwListEntryNr);

/**
 * Function: GetSXMForecastWeatherDayOfWeek
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetSXMForecastWeatherDayOfWeek(ulword ulwListEntryNr);

/**
 * Function: GetSXMWeatherRequestRainPropabiltiy
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetSXMWeatherRequestRainPropabiltiy( void);

/**
 * Function: GetSXMWeatherRequestPrecipitationType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetSXMWeatherRequestPrecipitationType( void);

/**
 * Function: GetLastSXMWeatherRequestCityName
 * NISSAN2.0
 * NISSAN
 */
void HSA_XMRadio__vGetLastSXMWeatherRequestCityName(GUI_String *out_result);

/**
 * Function: IsLastWeatherRequestOutdated
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_XMRadio__blIsLastWeatherRequestOutdated( void);

/**
 * Function: IsRepeatLastRequestPossible
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_XMRadio__blIsRepeatLastRequestPossible( void);

/**
 * Function: GetXMWeatherAdvisoryMessage
 * NISSAN
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetXMWeatherAdvisoryMessage( void);

/**
 * Function: GetSXMRequestType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetSXMRequestType( void);

/**
 * Function: SetSXMRequestType
 * NISSAN2.0
 * NISSAN
 */
void HSA_XMRadio__vSetSXMRequestType(ulword ulwulwReqType);

/**
 * Function: GetSXMRequestStatus
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetSXMRequestStatus( void);

/**
 * Function: LocationModeChange
 * NISSAN2.0
 * NISSAN
 */
void HSA_XMRadio__vLocationModeChange( void);

/**
 * Function: IsMapDataAvailable
 * NISSAN2.0
 * NISSAN
 */
void HSA_XMRadio__vIsMapDataAvailable( void);

/**
 * Function: IsWindSpeedAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_XMRadio__blIsWindSpeedAvailable( void);

/**
 * Function: IsHumidityAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_XMRadio__blIsHumidityAvailable( void);

/**
 * Function: IsPrecipitationAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_XMRadio__blIsPrecipitationAvailable( void);

/**
 * Function: GetSXMWeatherStationName
 * NISSAN2.0
 * NISSAN
 */
void HSA_XMRadio__vGetSXMWeatherStationName(GUI_String *out_result);

/**
 * Function: GetXMTravelLinkStatus
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_XMRadio__ulwGetXMTravelLinkStatus( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_XMRadio_H

