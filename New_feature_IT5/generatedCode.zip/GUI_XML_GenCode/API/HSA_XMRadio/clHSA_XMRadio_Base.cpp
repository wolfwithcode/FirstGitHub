/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_XMRadio_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_XMRadio/clHSA_XMRadio_Base.h"

clHSA_XMRadio_Base* clHSA_XMRadio_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_XMRadio_Base.cpp.trc.h"
#endif


/**
 * Method: vActivateSource
  *  Activates XM Radio source (source swith to XM ) 
  * NISSAN
 */
void clHSA_XMRadio_Base::vActivateSource( )
{
   
   ETG_TRACE_USR4(("function void clHSA_XMRadio::vActivateSource not implemented"));
   
}

/**
 * Method: blIsCategoryIconAvailable
  * Get the status of category icon display on HMI
  * NISSAN
 */
tbool clHSA_XMRadio_Base::blIsCategoryIconAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_XMRadio::blIsCategoryIconAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsChannelIconAvailable
  * Get the status of channel icon display on HMI
  * NISSAN
 */
tbool clHSA_XMRadio_Base::blIsChannelIconAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_XMRadio::blIsChannelIconAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsArtistIconAvailable
  * Get the status of artist icon display on HMI
  * NISSAN
 */
tbool clHSA_XMRadio_Base::blIsArtistIconAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_XMRadio::blIsArtistIconAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsTitleIconAvailable
  * Get the status of title icon display on HMI
  * NISSAN
 */
tbool clHSA_XMRadio_Base::blIsTitleIconAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_XMRadio::blIsTitleIconAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentChannelNumber
  * Get the Channel number of currently active XM audio Channel( varies from 0 ~ 255 )
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetCurrentChannelNumber( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetCurrentChannelNumber not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentArtistName
  * Get the artist name of currently active XM audio Channel
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetCurrentArtistName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetCurrentArtistName not implemented"));
   
}

/**
 * Method: vGetCurrentCategoryName
  * Get the name of the category of currently active XM audio Channel
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetCurrentCategoryName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetCurrentCategoryName not implemented"));
   
}

/**
 * Method: vGetCurrentChannelName
  * Get the channel name of currently active XM audio Channel
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetCurrentChannelName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetCurrentChannelName not implemented"));
   
}

/**
 * Method: vGetCurrentSongName
  * Get the song name of currently active XM audio Channel
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetCurrentSongName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetCurrentSongName not implemented"));
   
}

/**
 * Method: ulwGetCurrentPresetBank
  *  Returns the current active XM preset bank number
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetCurrentPresetBank( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetCurrentPresetBank not implemented"));
   return 0;
}

/**
 * Method: ulwGetActiveXMChannelPresetNr
  * Get the preset number from active preset bank on which the active XM Channel is saved(it is the auto compare value from tuner middleware). It returns -1  if station is not saved 
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetActiveXMChannelPresetNr( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetActiveXMChannelPresetNr not implemented"));
   return 0;
}

/**
 * Method: ulwGetXMAdvisoryMessage
  *  Returns the integer value corresponding to the current XM advisory message. Returns 0 if there is no advisory message
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetXMAdvisoryMessage( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetXMAdvisoryMessage not implemented"));
   return 0;
}

/**
 * Method: vXMRadioSelectChannelUp
  * Select next channel upwards to the given number of steps
  * NISSAN
 */
void clHSA_XMRadio_Base::vXMRadioSelectChannelUp(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vXMRadioSelectChannelUp not implemented"));
   
}

/**
 * Method: vXMRadioSelectChannelDown
  * Select next channel downwards to the given number of steps
  * NISSAN
 */
void clHSA_XMRadio_Base::vXMRadioSelectChannelDown(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vXMRadioSelectChannelDown not implemented"));
   
}

/**
 * Method: ulwGetChannelListStatus
  * Get the status of channel list at API side
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetChannelListStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetChannelListStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetChannelListCount
  * Get the number of elements in the current XM Channel list
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetChannelListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetChannelListCount not implemented"));
   return 0;
}

/**
 * Method: ulwGetChannelListActiveChannelIndex
  * Get the index of active XM channel in the current channel list that has to be highlighted
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetChannelListActiveChannelIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetChannelListActiveChannelIndex not implemented"));
   return 0;
}

/**
 * Method: vGetChannelListElement
  * Get an element of the channel list. One element of the channel list consists of channel number , channel name, associated preset number and preset bank number ( preset number = -1 means there is no preset entry for the channel).
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetChannelListElement(GUI_String *out_result, ulword ulwIndex, ulword ulwElementType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwElementType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetChannelListElement not implemented"));
   
}

/**
 * Method: vSelectFromChannelList
  * Select a channel from the channel list
  * NISSAN
 */
void clHSA_XMRadio_Base::vSelectFromChannelList(ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vSelectFromChannelList not implemented"));
   
}

/**
 * Method: blIsCategoryListAvailable
  * If there are zero elements in Category list then the soft key Category list will be grayed out (De-Activated). This API return the value to the Model to take a decision whether to Grey-out the Category list soft key or not.
  * NISSAN
 */
tbool clHSA_XMRadio_Base::blIsCategoryListAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_XMRadio::blIsCategoryListAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwGetCategoryListStatus
  * Get the status of category overview list at API side
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetCategoryListStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetCategoryListStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetCategoryListCount
  * Get the number of category elements in the current XM category list
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetCategoryListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetCategoryListCount not implemented"));
   return 0;
}

/**
 * Method: ulwGetCategoryListActiveCategoryIndex
  * Get the index of the currently playing channel's category information inorder to highlight the category list element
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetCategoryListActiveCategoryIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetCategoryListActiveCategoryIndex not implemented"));
   return 0;
}

/**
 * Method: vGetCategoryName
  * Get the category name of the requested index from the category list
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetCategoryName(GUI_String *out_result, ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetCategoryName not implemented"));
   
}

/**
 * Method: ulwGetNumberOfChannelsForCategory
  * Get the number of channel elements for a particular category
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetNumberOfChannelsForCategory(ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetNumberOfChannelsForCategory not implemented"));
   return 0;
}

/**
 * Method: ulwGetChannelListToCatStatus
  * Get the status of the channel list to a category at the API side
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetChannelListToCatStatus(ulword ulwCategoryIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCategoryIndex);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetChannelListToCatStatus not implemented"));
   return 0;
}

/**
 * Method: slwGetCategoryListActiveChannelIndex
  * Get the index of active XM channel in the channel list of user selected category
  * NISSAN
 */
slword clHSA_XMRadio_Base::slwGetCategoryListActiveChannelIndex( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_XMRadio::slwGetCategoryListActiveChannelIndex not implemented"));
   return 0;
}

/**
 * Method: vGetChannelElementFromCategory
  * Get a channel element of a catogory from the category list
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetChannelElementFromCategory(GUI_String *out_result, ulword ulwCategoryIndex, ulword ulwChannelIndex, ulword ulwElementType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCategoryIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwChannelIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwElementType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetChannelElementFromCategory not implemented"));
   
}

/**
 * Method: vSelectFromCategoryList
  * Select a channel from the channel list
  * NISSAN
 */
void clHSA_XMRadio_Base::vSelectFromCategoryList(ulword ulwCategoryIndex, ulword ulwChannelIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCategoryIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwChannelIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vSelectFromCategoryList not implemented"));
   
}

/**
 * Method: vTogglePresetBank
  *  Each call to this API toggles the preset bank between XM1 ~ XM2 ~ XM3 ~ XM1. 
  * NISSAN
 */
void clHSA_XMRadio_Base::vTogglePresetBank( )
{
   
   ETG_TRACE_USR4(("function void clHSA_XMRadio::vTogglePresetBank not implemented"));
   
}

/**
 * Method: vRecallPreset
  * Recall a preset channel from the current XM preset bank
  * NISSAN
 */
void clHSA_XMRadio_Base::vRecallPreset(ulword ulwPresetNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPresetNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vRecallPreset not implemented"));
   
}

/**
 * Method: vStorePreset
  * Store current playing channel to the current preset bank
  * NISSAN
 */
void clHSA_XMRadio_Base::vStorePreset(ulword ulwPresetNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPresetNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vStorePreset not implemented"));
   
}

/**
 * Method: vSeekPreset
  * Seek the preset position from current position and play the next preset channel.The seek is done for current preset bank
  * NISSAN
 */
void clHSA_XMRadio_Base::vSeekPreset(ulword ulwDirection)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDirection);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vSeekPreset not implemented"));
   
}

/**
 * Method: vScrollChannelUp
  * Scroll the channel in upward direction
  * NISSAN
 */
void clHSA_XMRadio_Base::vScrollChannelUp(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vScrollChannelUp not implemented"));
   
}

/**
 * Method: vScrollChannelDown
  * Scroll the channel in downward direction
  * NISSAN
 */
void clHSA_XMRadio_Base::vScrollChannelDown(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vScrollChannelDown not implemented"));
   
}

/**
 * Method: vAbortChannelScroll
  * This API is called when the user escapes from channel scroll operation by pressing logical back button
  * NISSAN
 */
void clHSA_XMRadio_Base::vAbortChannelScroll( )
{
   
   ETG_TRACE_USR4(("function void clHSA_XMRadio::vAbortChannelScroll not implemented"));
   
}

/**
 * Method: ulwGetChannelScrollStatus
  *  Get the current status of channel scrolling(inactive/active)
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetChannelScrollStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetChannelScrollStatus not implemented"));
   return 0;
}

/**
 * Method: vSeekCategoryUp
  * Seek category in upward direction. This API is used when the user triggers a logical CAT+.
  * NISSAN
 */
void clHSA_XMRadio_Base::vSeekCategoryUp(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vSeekCategoryUp not implemented"));
   
}

/**
 * Method: vSeekCategoryDown
  * Seek category in downward direction. This API is used when the user triggers a logical CAT-.
  * NISSAN
 */
void clHSA_XMRadio_Base::vSeekCategoryDown(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vSeekCategoryDown not implemented"));
   
}

/**
 * Method: vScrollCategoryUp
  * Scroll channel in upward direction across category. This API is used when the user is in CAT mode and triggers a logical rotary turn in right direction.
  * NISSAN
 */
void clHSA_XMRadio_Base::vScrollCategoryUp(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vScrollCategoryUp not implemented"));
   
}

/**
 * Method: vScrollCategoryDown
  * Scroll channel in upward direction across category. This API is used when the user is in CAT mode and triggers a logical rotary turn in left direction.
  * NISSAN
 */
void clHSA_XMRadio_Base::vScrollCategoryDown(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vScrollCategoryDown not implemented"));
   
}

/**
 * Method: vSeekCategoryChannelUp
  * Seek channel in upward direction across category.This API is called when the SWC next is triggered while user is in CAT mode.
  * NISSAN
 */
void clHSA_XMRadio_Base::vSeekCategoryChannelUp(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vSeekCategoryChannelUp not implemented"));
   
}

/**
 * Method: vSeekCategoryChannelDown
  * Seek channel in upward direction across category. This API is called when the SWC prev is triggered while user is in CAT mode.
  * NISSAN
 */
void clHSA_XMRadio_Base::vSeekCategoryChannelDown(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vSeekCategoryChannelDown not implemented"));
   
}

/**
 * Method: vAbortCategorySearch
  * This API is called when the user escapes from category search operation by pressing logical escape/back button
  * NISSAN
 */
void clHSA_XMRadio_Base::vAbortCategorySearch( )
{
   
   ETG_TRACE_USR4(("function void clHSA_XMRadio::vAbortCategorySearch not implemented"));
   
}

/**
 * Method: ulwGetCategorySearchStatus
  *  Get the current status of category search operation(inactive/active)
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetCategorySearchStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetCategorySearchStatus not implemented"));
   return 0;
}

/**
 * Method: vActivateXMDiag
  *  This API is called when user enter in to XM duag screen 
  * NISSAN
 */
void clHSA_XMRadio_Base::vActivateXMDiag(ulword ulwAction)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwAction);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vActivateXMDiag not implemented"));
   
}

/**
 * Method: ulwGetSignalStrength
  * Get the Signal State of XM
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetSignalStrength( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetSignalStrength not implemented"));
   return 0;
}

/**
 * Method: ulwGetXMRadioSubscriptionStatus
  * Get subscription Status of XM Radio
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetXMRadioSubscriptionStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetXMRadioSubscriptionStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetXMNavtrafficSubscriptionStatus
  * Get subscription Status of Nav traffic
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetXMNavtrafficSubscriptionStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetXMNavtrafficSubscriptionStatus not implemented"));
   return 0;
}

/**
 * Method: vGetLastMesgReceivedDetails
  * Get the the last message received details  
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetLastMesgReceivedDetails(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetLastMesgReceivedDetails not implemented"));
   
}

/**
 * Method: vGetXMRadioID
  * Get the XM Radio ID Or the HARWARE ID
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetXMRadioID(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetXMRadioID not implemented"));
   
}

/**
 * Method: vGetXMServiceMonitorDetails
  * Returns the string for each line display of XM Monitor screen 1 and 2
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetXMServiceMonitorDetails(GUI_String *out_result, ulword ulwLineNo)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLineNo);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetXMServiceMonitorDetails not implemented"));
   
}

/**
 * Method: vGetXMSDecVersion
  * Get the XM Radio SDEC/DSP version details
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetXMSDecVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetXMSDecVersion not implemented"));
   
}

/**
 * Method: vGetXMSTKVersion
  * Get the XM Radio stack  version details
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetXMSTKVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetXMSTKVersion not implemented"));
   
}

/**
 * Method: vGetXMCBMStackVersion
  * Get the XM Radio CBM  version details
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetXMCBMStackVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetXMCBMStackVersion not implemented"));
   
}

/**
 * Method: vGetSWModVersion
  * Get the XM Radio SW module version details
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetSWModVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetSWModVersion not implemented"));
   
}

/**
 * Method: vGetHWversion
  * Get the XM Radio HW version details
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetHWversion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetHWversion not implemented"));
   
}

/**
 * Method: vClearXMChipsetNVM
  *  To clear the user Non-Volatile Memory of XM chipset 
  * NISSAN
 */
void clHSA_XMRadio_Base::vClearXMChipsetNVM( )
{
   
   ETG_TRACE_USR4(("function void clHSA_XMRadio::vClearXMChipsetNVM not implemented"));
   
}

/**
 * Method: vResetALLXMSetting
  *  Reset to Factory Default 
  * NISSAN
 */
void clHSA_XMRadio_Base::vResetALLXMSetting( )
{
   
   ETG_TRACE_USR4(("function void clHSA_XMRadio::vResetALLXMSetting not implemented"));
   
}

/**
 * Method: vToggleCBMDebugMode
  *  Toggle (ON/OFF) between the CBM debug mode 
  * NISSAN
 */
void clHSA_XMRadio_Base::vToggleCBMDebugMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_XMRadio::vToggleCBMDebugMode not implemented"));
   
}

/**
 * Method: vToggleExternalDiagMode
  *  Toggle(ON/OFF) between External Diagnosis mode
  * NISSAN
 */
void clHSA_XMRadio_Base::vToggleExternalDiagMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_XMRadio::vToggleExternalDiagMode not implemented"));
   
}

/**
 * Method: blCBMDebugModeState
  * State Of the CBM Debug Mode
  * NISSAN
 */
tbool clHSA_XMRadio_Base::blCBMDebugModeState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_XMRadio::blCBMDebugModeState not implemented"));
   return 0;
}

/**
 * Method: blExternalDiagModeState
  * State Of the External diag Mode
  * NISSAN
 */
tbool clHSA_XMRadio_Base::blExternalDiagModeState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_XMRadio::blExternalDiagModeState not implemented"));
   return 0;
}

/**
 * Method: vResetXMChnGr
  *  Reset to Default Channelgraphics Database 
  * NISSAN
 */
void clHSA_XMRadio_Base::vResetXMChnGr( )
{
   
   ETG_TRACE_USR4(("function void clHSA_XMRadio::vResetXMChnGr not implemented"));
   
}

/**
 * Method: vGetCurrentChannelNumberInString
  * Get the Channel number of currently active XM audio Channel( varies from 0 ~ 255 )
  * NISSAN
 */
void clHSA_XMRadio_Base::vGetCurrentChannelNumberInString(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetCurrentChannelNumberInString not implemented"));
   
}

/**
 * Method: slwGetChannelGraphicsPicElementID
  * Returns the Picture ID for the Current Graphics data
  * NISSAN
 */
slword clHSA_XMRadio_Base::slwGetChannelGraphicsPicElementID( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_XMRadio::slwGetChannelGraphicsPicElementID not implemented"));
   return 0;
}

/**
 * Method: vGetSxmChannelArtImageId
  * Gets the file path of the channel art image
  * NISSANLCN2KAI
 */
void clHSA_XMRadio_Base::vGetSxmChannelArtImageId(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetSxmChannelArtImageId not implemented"));
   
}

/**
 * Method: vStartSXMWeatherRequest
  * initiates SXM weather
  * NISSAN2.0
 */
void clHSA_XMRadio_Base::vStartSXMWeatherRequest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_XMRadio::vStartSXMWeatherRequest not implemented"));
   
}

/**
 * Method: vSXMSetRequestModeType
  * to set location type requested
  * NISSAN2.0
 */
void clHSA_XMRadio_Base::vSXMSetRequestModeType(ulword ulwRequestLocationType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRequestLocationType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vSXMSetRequestModeType not implemented"));
   
}

/**
 * Method: ulwGetSXMRequestModeType
  * to get location type requested
  * NISSAN2.0
 */
ulword clHSA_XMRadio_Base::ulwGetSXMRequestModeType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetSXMRequestModeType not implemented"));
   return 0;
}

/**
 * Method: slwGetSXMWeatherRequestTempCurrent
  * Returns the current temperature of city for the specific date
  * NISSAN2.0
 */
slword clHSA_XMRadio_Base::slwGetSXMWeatherRequestTempCurrent( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_XMRadio::slwGetSXMWeatherRequestTempCurrent not implemented"));
   return 0;
}

/**
 * Method: vGetSXMCurrentWeatherHumidity
  * Returns the humidity of city for the specific date
  * NISSAN2.0
 */
void clHSA_XMRadio_Base::vGetSXMCurrentWeatherHumidity(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetSXMCurrentWeatherHumidity not implemented"));
   
}

/**
 * Method: vGetSXMWeatherRequestWinddirection
  * Returns the wind direction of city for the specific date
  * NISSAN2.0
 */
void clHSA_XMRadio_Base::vGetSXMWeatherRequestWinddirection(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetSXMWeatherRequestWinddirection not implemented"));
   
}

/**
 * Method: vGetSXMWeatherRequestWindspeed
  * Returns the wind speed of city for the specific date
  * NISSAN2.0
 */
void clHSA_XMRadio_Base::vGetSXMWeatherRequestWindspeed(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetSXMWeatherRequestWindspeed not implemented"));
   
}

/**
 * Method: ulwGetSXMCurrentWeatherCondition
  * Returns the weather condition of the city for the specific date
  * NISSAN2.0
 */
ulword clHSA_XMRadio_Base::ulwGetSXMCurrentWeatherCondition( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetSXMCurrentWeatherCondition not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMForecastWeatherCondition
  * Returns the weather condition of the city for the specific date
  * NISSAN2.0
 */
ulword clHSA_XMRadio_Base::ulwGetSXMForecastWeatherCondition(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetSXMForecastWeatherCondition not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMForecastWeather_count
  * Returns the number of Weather infos in the list of latest weather request
  * NISSAN2.0
 */
ulword clHSA_XMRadio_Base::ulwGetSXMForecastWeather_count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetSXMForecastWeather_count not implemented"));
   return 0;
}

/**
 * Method: slwGetSXMWeatherRequestTempMax
  * Returns the max temperature of city for the specific date
  * NISSAN2.0
 */
slword clHSA_XMRadio_Base::slwGetSXMWeatherRequestTempMax(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_XMRadio::slwGetSXMWeatherRequestTempMax not implemented"));
   return 0;
}

/**
 * Method: slwGetSXMWeatherRequestTempMin
  * Returns the minimum temperature of city for the specific date
  * NISSAN2.0
 */
slword clHSA_XMRadio_Base::slwGetSXMWeatherRequestTempMin(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_XMRadio::slwGetSXMWeatherRequestTempMin not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMForecastWeatherDayOfWeek
  * Returns the day of week for the specific date
  * NISSAN2.0
 */
ulword clHSA_XMRadio_Base::ulwGetSXMForecastWeatherDayOfWeek(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetSXMForecastWeatherDayOfWeek not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMWeatherRequestRainPropabiltiy
  * Returns the rain probability of city for the specific date
  * NISSAN2.0
 */
ulword clHSA_XMRadio_Base::ulwGetSXMWeatherRequestRainPropabiltiy( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetSXMWeatherRequestRainPropabiltiy not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMWeatherRequestPrecipitationType
  * Returns the precipitation of city for the specific date
  * NISSAN2.0
 */
ulword clHSA_XMRadio_Base::ulwGetSXMWeatherRequestPrecipitationType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetSXMWeatherRequestPrecipitationType not implemented"));
   return 0;
}

/**
 * Method: vGetLastSXMWeatherRequestCityName
  * Method to Read content from the list of Weather Info
  * NISSAN2.0
 */
void clHSA_XMRadio_Base::vGetLastSXMWeatherRequestCityName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetLastSXMWeatherRequestCityName not implemented"));
   
}

/**
 * Method: blIsLastWeatherRequestOutdated
  * Method to Get the Info if the available weather information is outdated
  * NISSAN2.0
 */
tbool clHSA_XMRadio_Base::blIsLastWeatherRequestOutdated( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_XMRadio::blIsLastWeatherRequestOutdated not implemented"));
   return 0;
}

/**
 * Method: blIsRepeatLastRequestPossible
  * Method to check the availability of last request
  * NISSAN2.0
 */
tbool clHSA_XMRadio_Base::blIsRepeatLastRequestPossible( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_XMRadio::blIsRepeatLastRequestPossible not implemented"));
   return 0;
}

/**
 * Method: ulwGetXMWeatherAdvisoryMessage
  *  Returns the integer value corresponding to the current XM weather advisory message. Returns 0 if there is no advisory message
  * NISSAN
 */
ulword clHSA_XMRadio_Base::ulwGetXMWeatherAdvisoryMessage( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetXMWeatherAdvisoryMessage not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMRequestType
  * Returns the current weather screen used
  * NISSAN2.0
 */
ulword clHSA_XMRadio_Base::ulwGetSXMRequestType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetSXMRequestType not implemented"));
   return 0;
}

/**
 * Method: vSetSXMRequestType
  * to set the current weather screen 
  * NISSAN2.0
 */
void clHSA_XMRadio_Base::vSetSXMRequestType(ulword ulwulwReqType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwulwReqType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vSetSXMRequestType not implemented"));
   
}

/**
 * Method: ulwGetSXMRequestStatus
  * Returns the current status of the navserver request
  * NISSAN2.0
 */
ulword clHSA_XMRadio_Base::ulwGetSXMRequestStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetSXMRequestStatus not implemented"));
   return 0;
}

/**
 * Method: vLocationModeChange
  * to show popup for RG active
  * NISSAN2.0
 */
void clHSA_XMRadio_Base::vLocationModeChange( )
{
   
   ETG_TRACE_USR4(("function void clHSA_XMRadio::vLocationModeChange not implemented"));
   
}

/**
 * Method: vIsMapDataAvailable
  * to check if sd card is available
  * NISSAN2.0
 */
void clHSA_XMRadio_Base::vIsMapDataAvailable( )
{
   
   ETG_TRACE_USR4(("function void clHSA_XMRadio::vIsMapDataAvailable not implemented"));
   
}

/**
 * Method: blIsWindSpeedAvailable
  * Get the status of wind speed display on HMI
  * NISSAN
 */
tbool clHSA_XMRadio_Base::blIsWindSpeedAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_XMRadio::blIsWindSpeedAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsHumidityAvailable
  * Get the status of Humidity display on HMI
  * NISSAN
 */
tbool clHSA_XMRadio_Base::blIsHumidityAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_XMRadio::blIsHumidityAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsPrecipitationAvailable
  * Get the status of Precipitation display on HMI
  * NISSAN
 */
tbool clHSA_XMRadio_Base::blIsPrecipitationAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_XMRadio::blIsPrecipitationAvailable not implemented"));
   return 0;
}

/**
 * Method: vGetSXMWeatherStationName
  * Method to Read content from the list of Weather Info
  * NISSAN2.0
 */
void clHSA_XMRadio_Base::vGetSXMWeatherStationName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_XMRadio::vGetSXMWeatherStationName not implemented"));
   
}

/**
 * Method: ulwGetXMTravelLinkStatus
  * Returns the current status of the travel link subscription
  * NISSAN2.0
 */
ulword clHSA_XMRadio_Base::ulwGetXMTravelLinkStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_XMRadio::ulwGetXMTravelLinkStatus not implemented"));
   return 0;
}

