/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_VehicleFunction_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_VehicleFunction_Base_H
#define _clHSA_VehicleFunction_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_VehicleFunction_Base : public clHSA_Base
{
public:

    static clHSA_VehicleFunction_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_VehicleFunction_Base()        {}

    virtual ulword ulwTpmsGetDisplayStyle( );

    virtual tbool blTpmsGetFRLowPressureStatus( );

    virtual tbool blTpmsGetFLLowPressureStatus( );

    virtual tbool blTpmsGetRRLowPressureStatus( );

    virtual tbool blTpmsGetRLLowPressureStatus( );

    virtual tbool blTpmsGetFRFlatTireStatus( );

    virtual tbool blTpmsGetFLFlatTireStatus( );

    virtual tbool blTpmsGetRRFlatTireStatus( );

    virtual tbool blTpmsGetRLFlatTireStatus( );

    virtual tbool blTpmsGetFRTransmitterStatus( );

    virtual tbool blTpmsGetFLTransmitterStatus( );

    virtual tbool blTpmsGetRRTransmitterStatus( );

    virtual tbool blTpmsGetRLTransmitterStatus( );

    virtual tbool blTpmsGetPressureSettingsScreenSupport( );

    virtual ulword ulwTpmsGetFRPressureData( );

    virtual ulword ulwTpmsGetFLPressureData( );

    virtual ulword ulwTpmsGetRRPressureData( );

    virtual ulword ulwTpmsGetRLPressureData( );

    virtual ulword ulwTpmsGetPressureSettingFront( );

    virtual ulword ulwTpmsGetPressureSettingRear( );

    virtual ulword ulwTpmsGetResetStatus( );

    virtual void vSetPressureSetting(tbool blTire, tbool blMode);

    virtual void vSendTpmsResetRequest( );

protected:
    clHSA_VehicleFunction_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_VehicleFunction_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_VehicleFunction_Base_H

