/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_VehicleFunction_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_VehicleFunction_Wrapper.h"
#include "clHSA_VehicleFunction_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_VehicleFunction_Trace.h"
#include "hmi_trace.h"

ulword HSA_VehicleFunction__ulwTpmsGetDisplayStyle( )
{
    ulword ret = 0;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_DISPLAY_STYLE  ) ); 
        }
      ret=pInst->ulwTpmsGetDisplayStyle();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_DISPLAY_STYLE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetFRLowPressureStatus( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FR_LOW_PRESSURE_STATUS  ) ); 
        }
      ret=pInst->blTpmsGetFRLowPressureStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FR_LOW_PRESSURE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetFLLowPressureStatus( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FL_LOW_PRESSURE_STATUS  ) ); 
        }
      ret=pInst->blTpmsGetFLLowPressureStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FL_LOW_PRESSURE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetRRLowPressureStatus( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RR_LOW_PRESSURE_STATUS  ) ); 
        }
      ret=pInst->blTpmsGetRRLowPressureStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RR_LOW_PRESSURE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetRLLowPressureStatus( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RL_LOW_PRESSURE_STATUS  ) ); 
        }
      ret=pInst->blTpmsGetRLLowPressureStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RL_LOW_PRESSURE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetFRFlatTireStatus( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FR_FLAT_TIRE_STATUS  ) ); 
        }
      ret=pInst->blTpmsGetFRFlatTireStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FR_FLAT_TIRE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetFLFlatTireStatus( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FL_FLAT_TIRE_STATUS  ) ); 
        }
      ret=pInst->blTpmsGetFLFlatTireStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FL_FLAT_TIRE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetRRFlatTireStatus( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RR_FLAT_TIRE_STATUS  ) ); 
        }
      ret=pInst->blTpmsGetRRFlatTireStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RR_FLAT_TIRE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetRLFlatTireStatus( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RL_FLAT_TIRE_STATUS  ) ); 
        }
      ret=pInst->blTpmsGetRLFlatTireStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RL_FLAT_TIRE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetFRTransmitterStatus( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FR_TRANSMITTER_STATUS  ) ); 
        }
      ret=pInst->blTpmsGetFRTransmitterStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FR_TRANSMITTER_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetFLTransmitterStatus( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FL_TRANSMITTER_STATUS  ) ); 
        }
      ret=pInst->blTpmsGetFLTransmitterStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FL_TRANSMITTER_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetRRTransmitterStatus( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RR_TRANSMITTER_STATUS  ) ); 
        }
      ret=pInst->blTpmsGetRRTransmitterStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RR_TRANSMITTER_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetRLTransmitterStatus( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RL_TRANSMITTER_STATUS  ) ); 
        }
      ret=pInst->blTpmsGetRLTransmitterStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RL_TRANSMITTER_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_VehicleFunction__blTpmsGetPressureSettingsScreenSupport( )
{
    tbool ret = false;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_PRESSURE_SETTINGS_SCREEN_SUPPORT  ) ); 
        }
      ret=pInst->blTpmsGetPressureSettingsScreenSupport();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_PRESSURE_SETTINGS_SCREEN_SUPPORT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_VehicleFunction__ulwTpmsGetFRPressureData( )
{
    ulword ret = 0;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FR_PRESSURE_DATA  ) ); 
        }
      ret=pInst->ulwTpmsGetFRPressureData();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FR_PRESSURE_DATA | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_VehicleFunction__ulwTpmsGetFLPressureData( )
{
    ulword ret = 0;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FL_PRESSURE_DATA  ) ); 
        }
      ret=pInst->ulwTpmsGetFLPressureData();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_FL_PRESSURE_DATA | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_VehicleFunction__ulwTpmsGetRRPressureData( )
{
    ulword ret = 0;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RR_PRESSURE_DATA  ) ); 
        }
      ret=pInst->ulwTpmsGetRRPressureData();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RR_PRESSURE_DATA | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_VehicleFunction__ulwTpmsGetRLPressureData( )
{
    ulword ret = 0;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RL_PRESSURE_DATA  ) ); 
        }
      ret=pInst->ulwTpmsGetRLPressureData();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RL_PRESSURE_DATA | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_VehicleFunction__ulwTpmsGetPressureSettingFront( )
{
    ulword ret = 0;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_PRESSURE_SETTING_FRONT  ) ); 
        }
      ret=pInst->ulwTpmsGetPressureSettingFront();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_PRESSURE_SETTING_FRONT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_VehicleFunction__ulwTpmsGetPressureSettingRear( )
{
    ulword ret = 0;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_PRESSURE_SETTING_REAR  ) ); 
        }
      ret=pInst->ulwTpmsGetPressureSettingRear();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_PRESSURE_SETTING_REAR | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_VehicleFunction__ulwTpmsGetResetStatus( )
{
    ulword ret = 0;
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RESET_STATUS  ) ); 
        }
      ret=pInst->ulwTpmsGetResetStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__TPMS_GET_RESET_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_VehicleFunction__vSetPressureSetting(tbool blTire, tbool blMode)
{
    
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__SET_PRESSURE_SETTING | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blTire); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__SET_PRESSURE_SETTING | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vSetPressureSetting(blTire, blMode);

    }
}

void HSA_VehicleFunction__vSendTpmsResetRequest( )
{
    
    clHSA_VehicleFunction_Base *pInst=clHSA_VehicleFunction_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_VEHICLEFUNCTION), (tU16)(HSA_API_ENTRYPOINT__SEND_TPMS_RESET_REQUEST  ) ); 
        }
      pInst->vSendTpmsResetRequest();

    }
}

#ifdef __cplusplus
}
#endif

