/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_VehicleFunction_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_VehicleFunction_Wrapper_H
#define _HSA_VehicleFunction_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: TpmsGetDisplayStyle
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_VehicleFunction__ulwTpmsGetDisplayStyle( void);

/**
 * Function: TpmsGetFRLowPressureStatus
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetFRLowPressureStatus( void);

/**
 * Function: TpmsGetFLLowPressureStatus
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetFLLowPressureStatus( void);

/**
 * Function: TpmsGetRRLowPressureStatus
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetRRLowPressureStatus( void);

/**
 * Function: TpmsGetRLLowPressureStatus
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetRLLowPressureStatus( void);

/**
 * Function: TpmsGetFRFlatTireStatus
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetFRFlatTireStatus( void);

/**
 * Function: TpmsGetFLFlatTireStatus
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetFLFlatTireStatus( void);

/**
 * Function: TpmsGetRRFlatTireStatus
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetRRFlatTireStatus( void);

/**
 * Function: TpmsGetRLFlatTireStatus
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetRLFlatTireStatus( void);

/**
 * Function: TpmsGetFRTransmitterStatus
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetFRTransmitterStatus( void);

/**
 * Function: TpmsGetFLTransmitterStatus
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetFLTransmitterStatus( void);

/**
 * Function: TpmsGetRRTransmitterStatus
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetRRTransmitterStatus( void);

/**
 * Function: TpmsGetRLTransmitterStatus
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetRLTransmitterStatus( void);

/**
 * Function: TpmsGetPressureSettingsScreenSupport
 * NISSAN ITG5SD
 * NISSAN
 */
tbool HSA_VehicleFunction__blTpmsGetPressureSettingsScreenSupport( void);

/**
 * Function: TpmsGetFRPressureData
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_VehicleFunction__ulwTpmsGetFRPressureData( void);

/**
 * Function: TpmsGetFLPressureData
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_VehicleFunction__ulwTpmsGetFLPressureData( void);

/**
 * Function: TpmsGetRRPressureData
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_VehicleFunction__ulwTpmsGetRRPressureData( void);

/**
 * Function: TpmsGetRLPressureData
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_VehicleFunction__ulwTpmsGetRLPressureData( void);

/**
 * Function: TpmsGetPressureSettingFront
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_VehicleFunction__ulwTpmsGetPressureSettingFront( void);

/**
 * Function: TpmsGetPressureSettingRear
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_VehicleFunction__ulwTpmsGetPressureSettingRear( void);

/**
 * Function: TpmsGetResetStatus
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_VehicleFunction__ulwTpmsGetResetStatus( void);

/**
 * Function: SetPressureSetting
 * NISSAN ITG5SD
 * NISSAN
 */
void HSA_VehicleFunction__vSetPressureSetting(tbool blTire, tbool blMode);

/**
 * Function: SendTpmsResetRequest
 * NISSAN ITG5SD
 * NISSAN
 */
void HSA_VehicleFunction__vSendTpmsResetRequest( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_VehicleFunction_H

