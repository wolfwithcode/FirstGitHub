/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_VehicleFunction_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_VehicleFunction_Wrapper_dbg.h"
#include "clHSA_VehicleFunction_Base.h"
#include "HSA_VehicleFunction_Trace.h"
#include "HSA_VehicleFunction_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_VehicleFunction_Wrapper_dbg::~clHSA_VehicleFunction_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_VehicleFunction_Wrapper_dbg::clHSA_VehicleFunction_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_VehicleFunction_Wrapper_dbg::clHSA_VehicleFunction_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_VehicleFunction_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_VehicleFunction_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__TPMS_GET_DISPLAY_STYLE:

            HSA_VehicleFunction__ulwTpmsGetDisplayStyle();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_FR_LOW_PRESSURE_STATUS:

            HSA_VehicleFunction__blTpmsGetFRLowPressureStatus();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_FL_LOW_PRESSURE_STATUS:

            HSA_VehicleFunction__blTpmsGetFLLowPressureStatus();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_RR_LOW_PRESSURE_STATUS:

            HSA_VehicleFunction__blTpmsGetRRLowPressureStatus();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_RL_LOW_PRESSURE_STATUS:

            HSA_VehicleFunction__blTpmsGetRLLowPressureStatus();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_FR_FLAT_TIRE_STATUS:

            HSA_VehicleFunction__blTpmsGetFRFlatTireStatus();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_FL_FLAT_TIRE_STATUS:

            HSA_VehicleFunction__blTpmsGetFLFlatTireStatus();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_RR_FLAT_TIRE_STATUS:

            HSA_VehicleFunction__blTpmsGetRRFlatTireStatus();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_RL_FLAT_TIRE_STATUS:

            HSA_VehicleFunction__blTpmsGetRLFlatTireStatus();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_FR_TRANSMITTER_STATUS:

            HSA_VehicleFunction__blTpmsGetFRTransmitterStatus();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_FL_TRANSMITTER_STATUS:

            HSA_VehicleFunction__blTpmsGetFLTransmitterStatus();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_RR_TRANSMITTER_STATUS:

            HSA_VehicleFunction__blTpmsGetRRTransmitterStatus();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_RL_TRANSMITTER_STATUS:

            HSA_VehicleFunction__blTpmsGetRLTransmitterStatus();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_PRESSURE_SETTINGS_SCREEN_SUPPORT:

            HSA_VehicleFunction__blTpmsGetPressureSettingsScreenSupport();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_FR_PRESSURE_DATA:

            HSA_VehicleFunction__ulwTpmsGetFRPressureData();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_FL_PRESSURE_DATA:

            HSA_VehicleFunction__ulwTpmsGetFLPressureData();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_RR_PRESSURE_DATA:

            HSA_VehicleFunction__ulwTpmsGetRRPressureData();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_RL_PRESSURE_DATA:

            HSA_VehicleFunction__ulwTpmsGetRLPressureData();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_PRESSURE_SETTING_FRONT:

            HSA_VehicleFunction__ulwTpmsGetPressureSettingFront();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_PRESSURE_SETTING_REAR:

            HSA_VehicleFunction__ulwTpmsGetPressureSettingRear();
            break;

        case HSA_API_ENTRYPOINT__TPMS_GET_RESET_STATUS:

            HSA_VehicleFunction__ulwTpmsGetResetStatus();
            break;

        case HSA_API_ENTRYPOINT__SET_PRESSURE_SETTING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam2); 

            HSA_VehicleFunction__vSetPressureSetting(usParam1, usParam2);
            break;

        case HSA_API_ENTRYPOINT__SEND_TPMS_RESET_REQUEST:

            HSA_VehicleFunction__vSendTpmsResetRequest();
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

