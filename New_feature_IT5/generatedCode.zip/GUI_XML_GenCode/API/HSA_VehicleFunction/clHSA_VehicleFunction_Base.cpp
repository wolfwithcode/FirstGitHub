/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_VehicleFunction_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_VehicleFunction/clHSA_VehicleFunction_Base.h"

clHSA_VehicleFunction_Base* clHSA_VehicleFunction_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_VehicleFunction_Base.cpp.trc.h"
#endif


/**
 * Method: ulwTpmsGetDisplayStyle
  * To show Low pressure message based on the Display style
  * NISSAN ITG5SD
 */
ulword clHSA_VehicleFunction_Base::ulwTpmsGetDisplayStyle( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_VehicleFunction::ulwTpmsGetDisplayStyle not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetFRLowPressureStatus
  * Returns whether the Front Right Tire is in Low Pressure state or not
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetFRLowPressureStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetFRLowPressureStatus not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetFLLowPressureStatus
  * Returns whether the Front Left Tire is in Low Pressure state or not
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetFLLowPressureStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetFLLowPressureStatus not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetRRLowPressureStatus
  * Returns whether the Rear Right Tire is in Low Pressure state or not
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetRRLowPressureStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetRRLowPressureStatus not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetRLLowPressureStatus
  * Returns whether the Rear Left Tire is in Low Pressure state or not
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetRLLowPressureStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetRLLowPressureStatus not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetFRFlatTireStatus
  * Returns whether the Front Right Tire is flat or not
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetFRFlatTireStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetFRFlatTireStatus not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetFLFlatTireStatus
  * Returns whether the Front Left Tire is flat or not
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetFLFlatTireStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetFLFlatTireStatus not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetRRFlatTireStatus
  * Returns whether the Rear Right Tire is flat or not
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetRRFlatTireStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetRRFlatTireStatus not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetRLFlatTireStatus
  * Returns whether the Rear Left Tire is flat or not
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetRLFlatTireStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetRLFlatTireStatus not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetFRTransmitterStatus
  * Returns whether the transmission status of Front Right Tire is normal or failure
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetFRTransmitterStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetFRTransmitterStatus not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetFLTransmitterStatus
  * Returns whether the transmission status of Front Left Tire is normal or failure
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetFLTransmitterStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetFLTransmitterStatus not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetRRTransmitterStatus
  * Returns whether the transmission status of Rear Right Tire is normal or failure
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetRRTransmitterStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetRRTransmitterStatus not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetRLTransmitterStatus
  * Returns whether the transmission status of Rear Left Tire is normal or failure
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetRLTransmitterStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetRLTransmitterStatus not implemented"));
   return 0;
}

/**
 * Method: blTpmsGetPressureSettingsScreenSupport
  * Returns whether the TPMS pressure settings is supported or not
  * NISSAN ITG5SD
 */
tbool clHSA_VehicleFunction_Base::blTpmsGetPressureSettingsScreenSupport( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_VehicleFunction::blTpmsGetPressureSettingsScreenSupport not implemented"));
   return 0;
}

/**
 * Method: ulwTpmsGetFRPressureData
  * To display the Pressure value of Front Right Tire
  * NISSAN ITG5SD
 */
ulword clHSA_VehicleFunction_Base::ulwTpmsGetFRPressureData( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_VehicleFunction::ulwTpmsGetFRPressureData not implemented"));
   return 0;
}

/**
 * Method: ulwTpmsGetFLPressureData
  * To display the Pressure value of Front Left Tire
  * NISSAN ITG5SD
 */
ulword clHSA_VehicleFunction_Base::ulwTpmsGetFLPressureData( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_VehicleFunction::ulwTpmsGetFLPressureData not implemented"));
   return 0;
}

/**
 * Method: ulwTpmsGetRRPressureData
  * To display the Pressure value of Rear Right Tire
  * NISSAN ITG5SD
 */
ulword clHSA_VehicleFunction_Base::ulwTpmsGetRRPressureData( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_VehicleFunction::ulwTpmsGetRRPressureData not implemented"));
   return 0;
}

/**
 * Method: ulwTpmsGetRLPressureData
  * To display the Pressure value of Rear Left Tire
  * NISSAN ITG5SD
 */
ulword clHSA_VehicleFunction_Base::ulwTpmsGetRLPressureData( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_VehicleFunction::ulwTpmsGetRLPressureData not implemented"));
   return 0;
}

/**
 * Method: ulwTpmsGetPressureSettingFront
  * To set the Pressure Setting for the Front Tires based on user action
  * NISSAN ITG5SD
 */
ulword clHSA_VehicleFunction_Base::ulwTpmsGetPressureSettingFront( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_VehicleFunction::ulwTpmsGetPressureSettingFront not implemented"));
   return 0;
}

/**
 * Method: ulwTpmsGetPressureSettingRear
  * To set the Pressure Setting for the Rear Tires based on user action
  * NISSAN ITG5SD
 */
ulword clHSA_VehicleFunction_Base::ulwTpmsGetPressureSettingRear( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_VehicleFunction::ulwTpmsGetPressureSettingRear not implemented"));
   return 0;
}

/**
 * Method: ulwTpmsGetResetStatus
  * Returns the reply from Tpms unit on Reset request from the user
  * NISSAN ITG5SD
 */
ulword clHSA_VehicleFunction_Base::ulwTpmsGetResetStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_VehicleFunction::ulwTpmsGetResetStatus not implemented"));
   return 0;
}

/**
 * Method: vSetPressureSetting
  * Sets the Pressure Setting for Front tires or Back tires based on user selection from the Pressure Setting screen
  * NISSAN ITG5SD
 */
void clHSA_VehicleFunction_Base::vSetPressureSetting(tbool blTire, tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blTire);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_VehicleFunction::vSetPressureSetting not implemented"));
   
}

/**
 * Method: vSendTpmsResetRequest
  * To reset the TPMS on user request
  * NISSAN ITG5SD
 */
void clHSA_VehicleFunction_Base::vSendTpmsResetRequest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_VehicleFunction::vSendTpmsResetRequest not implemented"));
   
}

