/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_SmartPhone_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_SmartPhone_Base_H
#define _clHSA_SmartPhone_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_SmartPhone_Base : public clHSA_Base
{
public:

    static clHSA_SmartPhone_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_SmartPhone_Base()        {}

    virtual void vHardKeyEvent(ulword ulwHardKeyEventType);

    virtual void vSwcKeyEvent(ulword ulwSWCEventType);

    virtual void vTouchPressed(slword slwXCoordinate, slword slwYCoordinate);

    virtual void vTouchReleased(slword slwXCoordinate, slword slwYCoordinate);

    virtual void vEncoderEvent(ulword ulwEncoderDirection, ulword ulwSteps);

    virtual void vScreenDraggedEvent(slword slwXCoordinate, slword slwYCoordinate, ulword ulwPenstate);

    virtual void vScreenDragReleasedEvent(slword slwXCoordinate, slword slwYCoordinate);

    virtual tbool blGetTbtStatusInCanvas( );

    virtual void vNaviRequestResult(ulword ulwResult, ulword ulwRequestType);

    virtual void vNavCanvasStatus(tbool blNavCanvasState);

    virtual void vSetScreenLockCounter( );

    virtual void vGetDialNumberResult( );

    virtual void vGetSendSmsResult( );

    virtual void vMyApps( );

    virtual ulword ulwAdvisoryMessge( );

    virtual void vGetDynamicImageID(GUI_String *out_result);

    virtual void vStartSpiBrowser(ulword ulwStartReason);

    virtual tbool blIsContinueSearchWithSpiApp( );

    virtual tbool blGetKeyConsupmtionStatusHKAUX( );

    virtual tbool blGetKeyConsupmtionStatusHKBACK( );

    virtual tbool blIsSpiServiceAvailable( );

    virtual tbool blIsSmartPhoneConnected( );

    virtual ulword ulwGetConnectedSmartPhoneCount( );

    virtual void vContinueSpiGoogleSearch(ulword ulwSearchLocationType, const GUI_String * SearchString);

    virtual tbool blGetBrowserLoadingStatus( );

    virtual ulword ulwGetCurrentSource( );

    virtual void vStopSpiFgSource( );

    virtual tbool blIsInternetRadioScreenActive( );

    virtual tbool blIsInternetRadioSubScreenActive( );

protected:
    clHSA_SmartPhone_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_SmartPhone_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_SmartPhone_Base_H

