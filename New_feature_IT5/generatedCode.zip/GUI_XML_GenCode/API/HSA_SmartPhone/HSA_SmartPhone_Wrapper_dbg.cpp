/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SmartPhone_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_SmartPhone_Wrapper_dbg.h"
#include "clHSA_SmartPhone_Base.h"
#include "HSA_SmartPhone_Trace.h"
#include "HSA_SmartPhone_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_SmartPhone_Wrapper_dbg::~clHSA_SmartPhone_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_SmartPhone_Wrapper_dbg::clHSA_SmartPhone_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_SmartPhone_Wrapper_dbg::clHSA_SmartPhone_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_SmartPhone_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_SmartPhone_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__HARD_KEY_EVENT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SmartPhone__vHardKeyEvent(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SWC_KEY_EVENT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SmartPhone__vSwcKeyEvent(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__TOUCH_PRESSED:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam2); 

            HSA_SmartPhone__vTouchPressed(slParam1, slParam2);
            break;

        case HSA_API_ENTRYPOINT__TOUCH_RELEASED:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam2); 

            HSA_SmartPhone__vTouchReleased(slParam1, slParam2);
            break;

        case HSA_API_ENTRYPOINT__ENCODER_EVENT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SmartPhone__vEncoderEvent(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SCREEN_DRAGGED_EVENT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SmartPhone__vScreenDraggedEvent(slParam1, slParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__SCREEN_DRAG_RELEASED_EVENT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam2); 

            HSA_SmartPhone__vScreenDragReleasedEvent(slParam1, slParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TBT_STATUS_IN_CANVAS:

            HSA_SmartPhone__blGetTbtStatusInCanvas();
            break;

        case HSA_API_ENTRYPOINT__NAVI_REQUEST_RESULT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SmartPhone__vNaviRequestResult(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__NAV_CANVAS_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_SmartPhone__vNavCanvasStatus(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_SCREEN_LOCK_COUNTER:

            HSA_SmartPhone__vSetScreenLockCounter();
            break;

        case HSA_API_ENTRYPOINT__GET_DIAL_NUMBER_RESULT:

            HSA_SmartPhone__vGetDialNumberResult();
            break;

        case HSA_API_ENTRYPOINT__GET_SEND_SMS_RESULT:

            HSA_SmartPhone__vGetSendSmsResult();
            break;

        case HSA_API_ENTRYPOINT__MY_APPS:

            HSA_SmartPhone__vMyApps();
            break;

        case HSA_API_ENTRYPOINT__ADVISORY_MESSGE:

            HSA_SmartPhone__ulwAdvisoryMessge();
            break;

        case HSA_API_ENTRYPOINT__GET_DYNAMIC_IMAGE_ID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SmartPhone__vGetDynamicImageID(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__START_SPI_BROWSER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SmartPhone__vStartSpiBrowser(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_CONTINUE_SEARCH_WITH_SPI_APP:

            HSA_SmartPhone__blIsContinueSearchWithSpiApp();
            break;

        case HSA_API_ENTRYPOINT__GET_KEY_CONSUPMTION_STATUS_HKAUX:

            HSA_SmartPhone__blGetKeyConsupmtionStatusHKAUX();
            break;

        case HSA_API_ENTRYPOINT__GET_KEY_CONSUPMTION_STATUS_HKBACK:

            HSA_SmartPhone__blGetKeyConsupmtionStatusHKBACK();
            break;

        case HSA_API_ENTRYPOINT__IS_SPI_SERVICE_AVAILABLE:

            HSA_SmartPhone__blIsSpiServiceAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_SMART_PHONE_CONNECTED:

            HSA_SmartPhone__blIsSmartPhoneConnected();
            break;

        case HSA_API_ENTRYPOINT__GET_CONNECTED_SMART_PHONE_COUNT:

            HSA_SmartPhone__ulwGetConnectedSmartPhoneCount();
            break;

        case HSA_API_ENTRYPOINT__CONTINUE_SPI_GOOGLE_SEARCH:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam2, aubBuffer2, sizeof(aubBuffer2)); 
            GUI_String_vSetCStr(&gsParam2, tmpBuffer);
            HSA_SmartPhone__vContinueSpiGoogleSearch(ulParam1, &gsParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_BROWSER_LOADING_STATUS:

            HSA_SmartPhone__blGetBrowserLoadingStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_SOURCE:

            HSA_SmartPhone__ulwGetCurrentSource();
            break;

        case HSA_API_ENTRYPOINT__STOP_SPI_FG_SOURCE:

            HSA_SmartPhone__vStopSpiFgSource();
            break;

        case HSA_API_ENTRYPOINT__IS_INTERNET_RADIO_SCREEN_ACTIVE:

            HSA_SmartPhone__blIsInternetRadioScreenActive();
            break;

        case HSA_API_ENTRYPOINT__IS_INTERNET_RADIO_SUB_SCREEN_ACTIVE:

            HSA_SmartPhone__blIsInternetRadioSubScreenActive();
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

