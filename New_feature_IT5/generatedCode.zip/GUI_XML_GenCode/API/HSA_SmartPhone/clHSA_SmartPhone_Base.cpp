/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_SmartPhone_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_SmartPhone/clHSA_SmartPhone_Base.h"

clHSA_SmartPhone_Base* clHSA_SmartPhone_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_SmartPhone_Base.cpp.trc.h"
#endif


/**
 * Method: vHardKeyEvent
  * This method is called whenever any hard-key is pressed and which is not consumed by Head Unit HMI
  * LCN2KAI
 */
void clHSA_SmartPhone_Base::vHardKeyEvent(ulword ulwHardKeyEventType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwHardKeyEventType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vHardKeyEvent not implemented"));
   
}

/**
 * Method: vSwcKeyEvent
  * This method is called whenever any steering wheel key is pressed and which is not consumed by Head Unit HMI
  * LCN2KAI
 */
void clHSA_SmartPhone_Base::vSwcKeyEvent(ulword ulwSWCEventType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSWCEventType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vSwcKeyEvent not implemented"));
   
}

/**
 * Method: vTouchPressed
  * This method is called whenever user touches anywhere in the active Smartphone HMI screen
  * LCN2Kai
 */
void clHSA_SmartPhone_Base::vTouchPressed(slword slwXCoordinate, slword slwYCoordinate)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwXCoordinate);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwYCoordinate);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vTouchPressed not implemented"));
   
}

/**
 * Method: vTouchReleased
  * This method is called whenever user releases touch anywhere in the active Smartphone HMI screen
  * LCN2Kai
 */
void clHSA_SmartPhone_Base::vTouchReleased(slword slwXCoordinate, slword slwYCoordinate)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwXCoordinate);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwYCoordinate);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vTouchReleased not implemented"));
   
}

/**
 * Method: vEncoderEvent
  * This method is called whenever user rotates the Encoder in the active Smartphone HMI screen
  * LCN2Kai
 */
void clHSA_SmartPhone_Base::vEncoderEvent(ulword ulwEncoderDirection, ulword ulwSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEncoderDirection);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vEncoderEvent not implemented"));
   
}

/**
 * Method: vScreenDraggedEvent
  * This method is called whenever user drags the screen. May be useful when there is Google map
  * LCN2Kai
 */
void clHSA_SmartPhone_Base::vScreenDraggedEvent(slword slwXCoordinate, slword slwYCoordinate, ulword ulwPenstate)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwXCoordinate);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwYCoordinate);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPenstate);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vScreenDraggedEvent not implemented"));
   
}

/**
 * Method: vScreenDragReleasedEvent
  * This method is called whenever user releases after dragging
  * LCN2Kai
 */
void clHSA_SmartPhone_Base::vScreenDragReleasedEvent(slword slwXCoordinate, slword slwYCoordinate)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwXCoordinate);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwYCoordinate);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vScreenDragReleasedEvent not implemented"));
   
}

/**
 * Method: blGetTbtStatusInCanvas
  * This API shall inform whether turn by turn symbol shall be shown in Smartphone canvas
  * 
 */
tbool clHSA_SmartPhone_Base::blGetTbtStatusInCanvas( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SmartPhone::blGetTbtStatusInCanvas not implemented"));
   return 0;
}

/**
 * Method: vNaviRequestResult
  * This API sends the result of the request made, such as set destination
  * 
 */
void clHSA_SmartPhone_Base::vNaviRequestResult(ulword ulwResult, ulword ulwRequestType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwResult);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRequestType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vNaviRequestResult not implemented"));
   
}

/**
 * Method: vNavCanvasStatus
  * This method Shall be sent whenever Navi canvas is active in HMI, During this time,if Internet Audio is active InternetRadio info like TrackName shall be displayed on Headline
  * LCN2Kai
 */
void clHSA_SmartPhone_Base::vNavCanvasStatus(tbool blNavCanvasState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blNavCanvasState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vNavCanvasStatus not implemented"));
   
}

/**
 * Method: vSetScreenLockCounter
  * This function shall provide the present screen lock count value to HUP
  * LCN2Kai
 */
void clHSA_SmartPhone_Base::vSetScreenLockCounter( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vSetScreenLockCounter not implemented"));
   
}

/**
 * Method: vGetDialNumberResult
  * This method shall be sent to inform about the dial status to ABQ whenever Dial number is triggered from the ABQ, This API will be called based on DPTELEPHONE__DIAL_NUMBER_RESULT the data update event
  * LCN2Kai
 */
void clHSA_SmartPhone_Base::vGetDialNumberResult( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vGetDialNumberResult not implemented"));
   
}

/**
 * Method: vGetSendSmsResult
  * This method shall be sent to inform about the send sms status to ABQ whenever send sms is triggered from the ABQ,This API will be called based on DPTELEPHONE__SMS_SENDING_STATUS the data update event
  * LCN2Kai
 */
void clHSA_SmartPhone_Base::vGetSendSmsResult( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vGetSendSmsResult not implemented"));
   
}

/**
 * Method: vMyApps
  * This method Shall be sent whenever user press the MyApps button
  * LCN2Kai
 */
void clHSA_SmartPhone_Base::vMyApps( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vMyApps not implemented"));
   
}

/**
 * Method: ulwAdvisoryMessge
  * This API shall be used to know about SmartPhone connection and Installed application status
  * LCN2Kai
 */
ulword clHSA_SmartPhone_Base::ulwAdvisoryMessge( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SmartPhone::ulwAdvisoryMessge not implemented"));
   return 0;
}

/**
 * Method: vGetDynamicImageID
  * Returns the image ID of the SPI internet source
  * B1
 */
void clHSA_SmartPhone_Base::vGetDynamicImageID(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vGetDynamicImageID not implemented"));
   
}

/**
 * Method: vStartSpiBrowser
  * This method is called whenever the browser is started by any user action
  * LCN2KAI
 */
void clHSA_SmartPhone_Base::vStartSpiBrowser(ulword ulwStartReason)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwStartReason);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vStartSpiBrowser not implemented"));
   
}

/**
 * Method: blIsContinueSearchWithSpiApp
  * This API shall inform to GUI whether continue search with SPI App is enabled or disabled
  * LCN2KAI
 */
tbool clHSA_SmartPhone_Base::blIsContinueSearchWithSpiApp( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SmartPhone::blIsContinueSearchWithSpiApp not implemented"));
   return 0;
}

/**
 * Method: blGetKeyConsupmtionStatusHKAUX
  * This API shall inform to GUI about HK_AUX key consumption status from Airbiquity HUP
  * LCN2KAI
 */
tbool clHSA_SmartPhone_Base::blGetKeyConsupmtionStatusHKAUX( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SmartPhone::blGetKeyConsupmtionStatusHKAUX not implemented"));
   return 0;
}

/**
 * Method: blGetKeyConsupmtionStatusHKBACK
  * This API shall inform to GUI about HK_BACK key consumption status from Airbiquity HUP
  * LCN2KAI
 */
tbool clHSA_SmartPhone_Base::blGetKeyConsupmtionStatusHKBACK( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SmartPhone::blGetKeyConsupmtionStatusHKBACK not implemented"));
   return 0;
}

/**
 * Method: blIsSpiServiceAvailable
  * This API shall inform to GUI whether SPI service is available or not.MyApps is greyed out if service is not available
  * LCN2KAI
 */
tbool clHSA_SmartPhone_Base::blIsSpiServiceAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SmartPhone::blIsSpiServiceAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsSmartPhoneConnected
  * This API shall inform to GUI whether smartphone is connected via SPP/IAP
  * LCN2KAI
 */
tbool clHSA_SmartPhone_Base::blIsSmartPhoneConnected( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SmartPhone::blIsSmartPhoneConnected not implemented"));
   return 0;
}

/**
 * Method: ulwGetConnectedSmartPhoneCount
  * This API shall inform to GUI about number of smartphone conected via SPP/IAP
  * LCN2KAI
 */
ulword clHSA_SmartPhone_Base::ulwGetConnectedSmartPhoneCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SmartPhone::ulwGetConnectedSmartPhoneCount not implemented"));
   return 0;
}

/**
 * Method: vContinueSpiGoogleSearch
  * This API shall inform to GUI to start the POI google search via SmartPhone Application for the given search string
  * LCN2KAI
 */
void clHSA_SmartPhone_Base::vContinueSpiGoogleSearch(ulword ulwSearchLocationType, const GUI_String * SearchString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSearchLocationType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( SearchString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vContinueSpiGoogleSearch not implemented"));
   
}

/**
 * Method: blGetBrowserLoadingStatus
  * This API shall inform to GUI about browser loading status
  * LCN2KAI
 */
tbool clHSA_SmartPhone_Base::blGetBrowserLoadingStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SmartPhone::blGetBrowserLoadingStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentSource
  * This API shall be used to know which SPI FG source(SPI_TTS/SPI_VR) is active
  * LCN2Kai
 */
ulword clHSA_SmartPhone_Base::ulwGetCurrentSource( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SmartPhone::ulwGetCurrentSource not implemented"));
   return 0;
}

/**
 * Method: vStopSpiFgSource
  * This method Shall be whenever current SPI FG source needs to switched off because of Screen transition
  * LCN2Kai
 */
void clHSA_SmartPhone_Base::vStopSpiFgSource( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SmartPhone::vStopSpiFgSource not implemented"));
   
}

/**
 * Method: blIsInternetRadioScreenActive
  * This API shall inform to GUI whether SPI Internet source is active and Browser is in Internet Radio Screen
  * LCN2KAI
 */
tbool clHSA_SmartPhone_Base::blIsInternetRadioScreenActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SmartPhone::blIsInternetRadioScreenActive not implemented"));
   return 0;
}

/**
 * Method: blIsInternetRadioSubScreenActive
  * This method Shall be called when SPI Internet Radio sub screen is visible in browser and SPI Internet Radio is active
  * LCN2KAI
 */
tbool clHSA_SmartPhone_Base::blIsInternetRadioSubScreenActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SmartPhone::blIsInternetRadioSubScreenActive not implemented"));
   return 0;
}

