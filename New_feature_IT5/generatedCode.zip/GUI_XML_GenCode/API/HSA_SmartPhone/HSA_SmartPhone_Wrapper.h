/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SmartPhone_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_SmartPhone_Wrapper_H
#define _HSA_SmartPhone_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: HardKeyEvent
 * LCN2KAI
 * NISSAN
 */
void HSA_SmartPhone__vHardKeyEvent(ulword ulwHardKeyEventType);

/**
 * Function: SwcKeyEvent
 * LCN2KAI
 * NISSAN
 */
void HSA_SmartPhone__vSwcKeyEvent(ulword ulwSWCEventType);

/**
 * Function: TouchPressed
 * LCN2Kai
 * NISSAN
 */
void HSA_SmartPhone__vTouchPressed(slword slwXCoordinate, slword slwYCoordinate);

/**
 * Function: TouchReleased
 * LCN2Kai
 * NISSAN
 */
void HSA_SmartPhone__vTouchReleased(slword slwXCoordinate, slword slwYCoordinate);

/**
 * Function: EncoderEvent
 * LCN2Kai
 * NISSAN
 */
void HSA_SmartPhone__vEncoderEvent(ulword ulwEncoderDirection, ulword ulwSteps);

/**
 * Function: ScreenDraggedEvent
 * LCN2Kai
 * NISSAN
 */
void HSA_SmartPhone__vScreenDraggedEvent(slword slwXCoordinate, slword slwYCoordinate, ulword ulwPenstate);

/**
 * Function: ScreenDragReleasedEvent
 * LCN2Kai
 * NISSAN
 */
void HSA_SmartPhone__vScreenDragReleasedEvent(slword slwXCoordinate, slword slwYCoordinate);

/**
 * Function: GetTbtStatusInCanvas
 * 
 * NISSAN
 */
tbool HSA_SmartPhone__blGetTbtStatusInCanvas( void);

/**
 * Function: NaviRequestResult
 * 
 * NISSAN
 */
void HSA_SmartPhone__vNaviRequestResult(ulword ulwResult, ulword ulwRequestType);

/**
 * Function: NavCanvasStatus
 * LCN2Kai
 * NISSAN
 */
void HSA_SmartPhone__vNavCanvasStatus(tbool blNavCanvasState);

/**
 * Function: SetScreenLockCounter
 * LCN2Kai
 * NISSAN
 */
void HSA_SmartPhone__vSetScreenLockCounter( void);

/**
 * Function: GetDialNumberResult
 * LCN2Kai
 * NISSAN
 */
void HSA_SmartPhone__vGetDialNumberResult( void);

/**
 * Function: GetSendSmsResult
 * LCN2Kai
 * NISSAN
 */
void HSA_SmartPhone__vGetSendSmsResult( void);

/**
 * Function: MyApps
 * LCN2Kai
 * NISSAN
 */
void HSA_SmartPhone__vMyApps( void);

/**
 * Function: AdvisoryMessge
 * LCN2Kai
 * NISSAN
 */
ulword HSA_SmartPhone__ulwAdvisoryMessge( void);

/**
 * Function: GetDynamicImageID
 * B1
 * NISSAN
 */
void HSA_SmartPhone__vGetDynamicImageID(GUI_String *out_result);

/**
 * Function: StartSpiBrowser
 * LCN2KAI
 * NISSAN
 */
void HSA_SmartPhone__vStartSpiBrowser(ulword ulwStartReason);

/**
 * Function: IsContinueSearchWithSpiApp
 * LCN2KAI
 * NISSAN
 */
tbool HSA_SmartPhone__blIsContinueSearchWithSpiApp( void);

/**
 * Function: GetKeyConsupmtionStatusHKAUX
 * LCN2KAI
 * NISSAN
 */
tbool HSA_SmartPhone__blGetKeyConsupmtionStatusHKAUX( void);

/**
 * Function: GetKeyConsupmtionStatusHKBACK
 * LCN2KAI
 * NISSAN
 */
tbool HSA_SmartPhone__blGetKeyConsupmtionStatusHKBACK( void);

/**
 * Function: IsSpiServiceAvailable
 * LCN2KAI
 * NISSAN
 */
tbool HSA_SmartPhone__blIsSpiServiceAvailable( void);

/**
 * Function: IsSmartPhoneConnected
 * LCN2KAI
 * NISSAN
 */
tbool HSA_SmartPhone__blIsSmartPhoneConnected( void);

/**
 * Function: GetConnectedSmartPhoneCount
 * LCN2KAI
 * NISSAN
 */
ulword HSA_SmartPhone__ulwGetConnectedSmartPhoneCount( void);

/**
 * Function: ContinueSpiGoogleSearch
 * LCN2KAI
 * NISSAN
 */
void HSA_SmartPhone__vContinueSpiGoogleSearch(ulword ulwSearchLocationType, const GUI_String * SearchString);

/**
 * Function: GetBrowserLoadingStatus
 * LCN2KAI
 * NISSAN
 */
tbool HSA_SmartPhone__blGetBrowserLoadingStatus( void);

/**
 * Function: GetCurrentSource
 * LCN2Kai
 * NISSAN
 */
ulword HSA_SmartPhone__ulwGetCurrentSource( void);

/**
 * Function: StopSpiFgSource
 * LCN2Kai
 * NISSAN
 */
void HSA_SmartPhone__vStopSpiFgSource( void);

/**
 * Function: IsInternetRadioScreenActive
 * LCN2KAI
 * NISSAN
 */
tbool HSA_SmartPhone__blIsInternetRadioScreenActive( void);

/**
 * Function: IsInternetRadioSubScreenActive
 * LCN2KAI
 * NISSAN
 */
tbool HSA_SmartPhone__blIsInternetRadioSubScreenActive( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_SmartPhone_H

