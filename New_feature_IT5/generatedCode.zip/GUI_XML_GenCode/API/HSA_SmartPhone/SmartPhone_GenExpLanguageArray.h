/*Exported Language Array from the model - SmartPhone*/
/*  This file has been generated on 05.12.2014 16:38 */
/*
 *  This file contains the definition of exported language content.
 *  The String lists with the translation that are to be exported
 *  from the model are listed here in the array structure
 *  
 *  Please note that:
 *    - Translations are provided in the following language order
 *    - English US
 *    - French CAN
 *    - Spanish Standard Latin
 *    - Dutch
 *    - German
 *    - Italian
 *    - Portuguese
 *    - Russian
 *    - Turkish
 *    - English UK
 *    - French
 *    - Spanish
 *    - Danish
 *    - Swedish
 *    - Finnish
 *    - Norwegian
 *    - Polish
 *    - Slovak
 *    - Czech
 *    - Hungarian
 *    - Greek
 *    - Brazilian
 *    - Arabic
 *    - Thai
 *    - Australian
 *
 *    This list is the same as used in the Model
 *
 *  The following macros are used:
 *
 *    CONTENT_LANGUAGE_COUNT(LanguageCount)
 *       Provides the count value to indicate the number of translations
 *    CONTENT_LANGUAGE_ARRAY(DeviceName) 
 *       Provides the start of the Array with Device name to which the 
 *       array belongs
 *    CONTENT_INDEX_START(Index Value)
 *       mark the start of Each string followed by the array of
 *       translations
 *    CONTENT_LANGUAGE(ContentID)
 *       provides the content ID for the translated string
 *    CONTENT_INDEX_END
 *       marks the end of Each string translation set
 *    CONTENT_END(value)
 *       End of the complete array
 *
 */


CONTENT_BEGIN()
#ifndef CONTENT_EXP_LANGUAGE_COUNT
   #define CONTENT_EXP_LANGUAGE_COUNT       25
#endif // #ifndef CONTENT_EXP_LANGUAGE_COUNT
CONTENT_LANGUAGE_ARRAY(SmartPhone)

#ifdef CONTENT_LANGUAGE
    //STRING_START(0)
    CONTENT_LANGUAGE(0x40004ccc)                                      // 0x80000043: (Save custom message here)
    CONTENT_LANGUAGE(0x40004ccd)                                      // 0x80000043: (Enregistrer le message personnalis� ici)
    CONTENT_LANGUAGE(0x40004cce)                                      // 0x80000043: (Guardar mensaje personalizado aqu�)
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000043: #No translation required
    //STRING_END()
    //STRING_START(1)
    CONTENT_LANGUAGE(0x40004ccf)                                      // 0x80000044: (Save custom message 2 here)
    CONTENT_LANGUAGE(0x40004cd0)                                      // 0x80000044: (Enregistrer le message personnalis� 2 ici)
    CONTENT_LANGUAGE(0x40004cd1)                                      // 0x80000044: (Guardar mensaje personalizado 2 aqu�)
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000044: #No translation required
    //STRING_END()
    //STRING_START(2)
    CONTENT_LANGUAGE(0x40004cd2)                                      // 0x80000045: (Save custom message 3 here)
    CONTENT_LANGUAGE(0x40004cd3)                                      // 0x80000045: (Enregistrer le message personnalis� 3 ici)
    CONTENT_LANGUAGE(0x40004cd4)                                      // 0x80000045: (Guardar mensaje personalizado 3 aqu�)
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000045: #No translation required
    //STRING_END()
    //STRING_START(3)
    CONTENT_LANGUAGE(0x40004cd5)                                      // 0x80000046: (Save custom message 4 here)
    CONTENT_LANGUAGE(0x40004cd6)                                      // 0x80000046: (Enregistrer le message personnalis� 4 ici)
    CONTENT_LANGUAGE(0x40004cd7)                                      // 0x80000046: (Guardar mensaje personalizado 4 aqu�)
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000046: #No translation required
    //STRING_END()
    //STRING_START(4)
    CONTENT_LANGUAGE(0x40004cd8)                                      // 0x80000047: Driving, can't text.
    CONTENT_LANGUAGE(0x40004cd9)                                      // 0x80000047: En train de conduire, ne peux pas texter.
    CONTENT_LANGUAGE(0x40004cda)                                      // 0x80000047: Estoy conduciendo, no puedo escribir.
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000047: #No translation required
    //STRING_END()
    //STRING_START(5)
    CONTENT_LANGUAGE(0x40004cdb)                                      // 0x80000048: Sent from
    CONTENT_LANGUAGE(0x40004cdc)                                      // 0x80000048: Envoy� de
    CONTENT_LANGUAGE(0x40004cdd)                                      // 0x80000048: Enviado por
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000048: #No translation required
    //STRING_END()
    //STRING_START(6)
    CONTENT_LANGUAGE(0x40004cde)                                      // 0x80000049: Yesterday
    CONTENT_LANGUAGE(0x40004cdf)                                      // 0x80000049: Hier
    CONTENT_LANGUAGE(0x40004ce0)                                      // 0x80000049: Ayer
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    //STRING_END()
    //STRING_START(7)
    CONTENT_LANGUAGE(0x40004ce1)                                      // 0x8000004a: Sunday
    CONTENT_LANGUAGE(0x40004ce2)                                      // 0x8000004a: Dimanche
    CONTENT_LANGUAGE(0x40004ce3)                                      // 0x8000004a: Domingo
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    //STRING_END()
    //STRING_START(8)
    CONTENT_LANGUAGE(0x40004ce4)                                      // 0x8000004b: Monday
    CONTENT_LANGUAGE(0x40004ce5)                                      // 0x8000004b: Lundi
    CONTENT_LANGUAGE(0x40004ce6)                                      // 0x8000004b: Lunes
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    //STRING_END()
    //STRING_START(9)
    CONTENT_LANGUAGE(0x40004ce7)                                      // 0x8000004c: Tuesday
    CONTENT_LANGUAGE(0x40004ce8)                                      // 0x8000004c: Mardi
    CONTENT_LANGUAGE(0x40004ce9)                                      // 0x8000004c: Martes
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    //STRING_END()
    //STRING_START(10)
    CONTENT_LANGUAGE(0x40004cea)                                      // 0x8000004d: Wednesday
    CONTENT_LANGUAGE(0x40004ceb)                                      // 0x8000004d: Mercredi
    CONTENT_LANGUAGE(0x40004cec)                                      // 0x8000004d: Mi�rcoles
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    //STRING_END()
    //STRING_START(11)
    CONTENT_LANGUAGE(0x40004ced)                                      // 0x8000004e: Thursday
    CONTENT_LANGUAGE(0x40004cee)                                      // 0x8000004e: Jeudi
    CONTENT_LANGUAGE(0x40004cef)                                      // 0x8000004e: Jueves
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    //STRING_END()
    //STRING_START(12)
    CONTENT_LANGUAGE(0x40004cf0)                                      // 0x8000004f: Friday
    CONTENT_LANGUAGE(0x40004cf1)                                      // 0x8000004f: Vendredi
    CONTENT_LANGUAGE(0x40004cf2)                                      // 0x8000004f: Viernes
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    //STRING_END()
    //STRING_START(13)
    CONTENT_LANGUAGE(0x40004cf3)                                      // 0x80000050: Saturday
    CONTENT_LANGUAGE(0x40004cf4)                                      // 0x80000050: Samedi
    CONTENT_LANGUAGE(0x40004cf5)                                      // 0x80000050: S�bado
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    //STRING_END()
    //STRING_START(14)
    CONTENT_LANGUAGE(0x40004cf6)                                      // 0x80000051: Msg 
    CONTENT_LANGUAGE(0x40004cf6)                                      // 0x80000051: Msg 
    CONTENT_LANGUAGE(0x40004cf7)                                      // 0x80000051: Mje 
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    //STRING_END()
    //STRING_START(15)
    CONTENT_LANGUAGE(0x40004cf8)                                      // 0x80000052:  of 
    CONTENT_LANGUAGE(0x40004cf9)                                      // 0x80000052:  de 
    CONTENT_LANGUAGE(0x40004cf9)                                      // 0x80000052:  de 
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    //STRING_END()
    //STRING_START(16)
    CONTENT_LANGUAGE(0x400007b8)                                      // 0x80000053: Private Number
    CONTENT_LANGUAGE(0x40004cfa)                                      // 0x80000053: Num�ro priv�
    CONTENT_LANGUAGE(0x40004cfb)                                      // 0x80000053: N�mero privado
    CONTENT_LANGUAGE(0x40004cfc)                                      // 0x80000053: Priv�nummer
    CONTENT_LANGUAGE(0x400007b8)                                      // 0x80000053: Private Number
    CONTENT_LANGUAGE(0x40004cfd)                                      // 0x80000053: Numero privato
    CONTENT_LANGUAGE(0x40004cfb)                                      // 0x80000053: N�mero privado
    CONTENT_LANGUAGE(0x40004cfe)                                      // 0x80000053: ?????? ?????
    CONTENT_LANGUAGE(0x40004cff)                                      // 0x80000053: �zel numara
    CONTENT_LANGUAGE(0x400007b8)                                      // 0x80000053: Private Number
    CONTENT_LANGUAGE(0x40004cfa)                                      // 0x80000053: Num�ro priv�
    CONTENT_LANGUAGE(0x40004cfb)                                      // 0x80000053: N�mero privado
    CONTENT_LANGUAGE(0x40004d00)                                      // 0x80000053: Privatnummer
    CONTENT_LANGUAGE(0x40004d01)                                      // 0x80000053: Privat nummer
    CONTENT_LANGUAGE(0x40004d02)                                      // 0x80000053: Yksityinen numero
    CONTENT_LANGUAGE(0x40004d01)                                      // 0x80000053: Privat nummer
    CONTENT_LANGUAGE(0x40004d03)                                      // 0x80000053: Numer zastrze?ony
    CONTENT_LANGUAGE(0x40004d04)                                      // 0x80000053: S�kromn� tel. ?�slo
    CONTENT_LANGUAGE(0x40004d05)                                      // 0x80000053: Soukrom� ?�slo
    CONTENT_LANGUAGE(0x40004d06)                                      // 0x80000053: Priv�t sz�m
    CONTENT_LANGUAGE(0x40004d07)                                      // 0x80000053: ?????????? ???????
    CONTENT_LANGUAGE(0x40004cfb)                                      // 0x80000053: N�mero privado
    CONTENT_LANGUAGE(0x40004d08)                                      // 0x80000053: ??? ???
    CONTENT_LANGUAGE(0x40004d09)                                      // 0x80000053: ??????????????
    CONTENT_LANGUAGE(0x40004d0a)                                      // 0x80000053: ????????? ?????
    //STRING_END()
#endif // #ifdef CONTENT_LANGUAGE

CONTENT_END()
