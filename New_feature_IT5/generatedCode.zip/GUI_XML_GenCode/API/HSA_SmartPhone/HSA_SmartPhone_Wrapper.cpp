/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SmartPhone_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_SmartPhone_Wrapper.h"
#include "clHSA_SmartPhone_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_SmartPhone_Trace.h"
#include "hmi_trace.h"

void HSA_SmartPhone__vHardKeyEvent(ulword ulwHardKeyEventType)
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__HARD_KEY_EVENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwHardKeyEventType); 
        }
      pInst->vHardKeyEvent(ulwHardKeyEventType);

    }
}

void HSA_SmartPhone__vSwcKeyEvent(ulword ulwSWCEventType)
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__SWC_KEY_EVENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSWCEventType); 
        }
      pInst->vSwcKeyEvent(ulwSWCEventType);

    }
}

void HSA_SmartPhone__vTouchPressed(slword slwXCoordinate, slword slwYCoordinate)
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__TOUCH_PRESSED | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwXCoordinate); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__TOUCH_PRESSED | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwYCoordinate); 
        }
      pInst->vTouchPressed(slwXCoordinate, slwYCoordinate);

    }
}

void HSA_SmartPhone__vTouchReleased(slword slwXCoordinate, slword slwYCoordinate)
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__TOUCH_RELEASED | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwXCoordinate); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__TOUCH_RELEASED | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwYCoordinate); 
        }
      pInst->vTouchReleased(slwXCoordinate, slwYCoordinate);

    }
}

void HSA_SmartPhone__vEncoderEvent(ulword ulwEncoderDirection, ulword ulwSteps)
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__ENCODER_EVENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEncoderDirection); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__ENCODER_EVENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSteps); 
        }
      pInst->vEncoderEvent(ulwEncoderDirection, ulwSteps);

    }
}

void HSA_SmartPhone__vScreenDraggedEvent(slword slwXCoordinate, slword slwYCoordinate, ulword ulwPenstate)
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__SCREEN_DRAGGED_EVENT | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwXCoordinate); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__SCREEN_DRAGGED_EVENT | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwYCoordinate); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__SCREEN_DRAGGED_EVENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPenstate); 
        }
      pInst->vScreenDraggedEvent(slwXCoordinate, slwYCoordinate, ulwPenstate);

    }
}

void HSA_SmartPhone__vScreenDragReleasedEvent(slword slwXCoordinate, slword slwYCoordinate)
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__SCREEN_DRAG_RELEASED_EVENT | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwXCoordinate); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__SCREEN_DRAG_RELEASED_EVENT | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwYCoordinate); 
        }
      pInst->vScreenDragReleasedEvent(slwXCoordinate, slwYCoordinate);

    }
}

tbool HSA_SmartPhone__blGetTbtStatusInCanvas( )
{
    tbool ret = false;
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_TBT_STATUS_IN_CANVAS  ) ); 
        }
      ret=pInst->blGetTbtStatusInCanvas();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_TBT_STATUS_IN_CANVAS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SmartPhone__vNaviRequestResult(ulword ulwResult, ulword ulwRequestType)
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__NAVI_REQUEST_RESULT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwResult); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__NAVI_REQUEST_RESULT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRequestType); 
        }
      pInst->vNaviRequestResult(ulwResult, ulwRequestType);

    }
}

void HSA_SmartPhone__vNavCanvasStatus(tbool blNavCanvasState)
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__NAV_CANVAS_STATUS | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blNavCanvasState); 
        }
      pInst->vNavCanvasStatus(blNavCanvasState);

    }
}

void HSA_SmartPhone__vSetScreenLockCounter( )
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__SET_SCREEN_LOCK_COUNTER  ) ); 
        }
      pInst->vSetScreenLockCounter();

    }
}

void HSA_SmartPhone__vGetDialNumberResult( )
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIAL_NUMBER_RESULT  ) ); 
        }
      pInst->vGetDialNumberResult();

    }
}

void HSA_SmartPhone__vGetSendSmsResult( )
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SEND_SMS_RESULT  ) ); 
        }
      pInst->vGetSendSmsResult();

    }
}

void HSA_SmartPhone__vMyApps( )
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__MY_APPS  ) ); 
        }
      pInst->vMyApps();

    }
}

ulword HSA_SmartPhone__ulwAdvisoryMessge( )
{
    ulword ret = 0;
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__ADVISORY_MESSGE  ) ); 
        }
      ret=pInst->ulwAdvisoryMessge();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__ADVISORY_MESSGE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SmartPhone__vGetDynamicImageID(GUI_String *out_result)
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DYNAMIC_IMAGE_ID  ) ); 
        }
      pInst->vGetDynamicImageID(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DYNAMIC_IMAGE_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SmartPhone__vStartSpiBrowser(ulword ulwStartReason)
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__START_SPI_BROWSER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwStartReason); 
        }
      pInst->vStartSpiBrowser(ulwStartReason);

    }
}

tbool HSA_SmartPhone__blIsContinueSearchWithSpiApp( )
{
    tbool ret = false;
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__IS_CONTINUE_SEARCH_WITH_SPI_APP  ) ); 
        }
      ret=pInst->blIsContinueSearchWithSpiApp();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__IS_CONTINUE_SEARCH_WITH_SPI_APP | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SmartPhone__blGetKeyConsupmtionStatusHKAUX( )
{
    tbool ret = false;
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_KEY_CONSUPMTION_STATUS_HKAUX  ) ); 
        }
      ret=pInst->blGetKeyConsupmtionStatusHKAUX();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_KEY_CONSUPMTION_STATUS_HKAUX | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SmartPhone__blGetKeyConsupmtionStatusHKBACK( )
{
    tbool ret = false;
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_KEY_CONSUPMTION_STATUS_HKBACK  ) ); 
        }
      ret=pInst->blGetKeyConsupmtionStatusHKBACK();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_KEY_CONSUPMTION_STATUS_HKBACK | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SmartPhone__blIsSpiServiceAvailable( )
{
    tbool ret = false;
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SPI_SERVICE_AVAILABLE  ) ); 
        }
      ret=pInst->blIsSpiServiceAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SPI_SERVICE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SmartPhone__blIsSmartPhoneConnected( )
{
    tbool ret = false;
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SMART_PHONE_CONNECTED  ) ); 
        }
      ret=pInst->blIsSmartPhoneConnected();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SMART_PHONE_CONNECTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SmartPhone__ulwGetConnectedSmartPhoneCount( )
{
    ulword ret = 0;
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_SMART_PHONE_COUNT  ) ); 
        }
      ret=pInst->ulwGetConnectedSmartPhoneCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_SMART_PHONE_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SmartPhone__vContinueSpiGoogleSearch(ulword ulwSearchLocationType, const GUI_String * SearchString)
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__CONTINUE_SPI_GOOGLE_SEARCH | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSearchLocationType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__CONTINUE_SPI_GOOGLE_SEARCH | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)SearchString->ulwLen_+1, SearchString->pubBuffer_);
         }
      pInst->vContinueSpiGoogleSearch(ulwSearchLocationType,  SearchString);

    }
}

tbool HSA_SmartPhone__blGetBrowserLoadingStatus( )
{
    tbool ret = false;
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_LOADING_STATUS  ) ); 
        }
      ret=pInst->blGetBrowserLoadingStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_BROWSER_LOADING_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SmartPhone__ulwGetCurrentSource( )
{
    ulword ret = 0;
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SOURCE  ) ); 
        }
      ret=pInst->ulwGetCurrentSource();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SOURCE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SmartPhone__vStopSpiFgSource( )
{
    
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__STOP_SPI_FG_SOURCE  ) ); 
        }
      pInst->vStopSpiFgSource();

    }
}

tbool HSA_SmartPhone__blIsInternetRadioScreenActive( )
{
    tbool ret = false;
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__IS_INTERNET_RADIO_SCREEN_ACTIVE  ) ); 
        }
      ret=pInst->blIsInternetRadioScreenActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__IS_INTERNET_RADIO_SCREEN_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SmartPhone__blIsInternetRadioSubScreenActive( )
{
    tbool ret = false;
    clHSA_SmartPhone_Base *pInst=clHSA_SmartPhone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__IS_INTERNET_RADIO_SUB_SCREEN_ACTIVE  ) ); 
        }
      ret=pInst->blIsInternetRadioSubScreenActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SMARTPHONE), (tU16)(HSA_API_ENTRYPOINT__IS_INTERNET_RADIO_SUB_SCREEN_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

#ifdef __cplusplus
}
#endif

