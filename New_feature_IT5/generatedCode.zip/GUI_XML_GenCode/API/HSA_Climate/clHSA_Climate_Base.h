/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_Climate_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_Climate_Base_H
#define _clHSA_Climate_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_Climate_Base : public clHSA_Base
{
public:

    static clHSA_Climate_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_Climate_Base()        {}

    virtual ulword ulwGetHVACPopupPatternType( );

    virtual void vGetRightTemperatureValue(GUI_String *out_result);

    virtual void vGetLeftTemperatureValue(GUI_String *out_result);

    virtual void vGetRearTemperatureValue(GUI_String *out_result);

    virtual void vGetOutsideTemperatureValue(GUI_String *out_result);

    virtual ulword ulwGetAirFlowTopRightVisiblity( );

    virtual ulword ulwGetAirFlowTopLeftVisiblity( );

    virtual ulword ulwGetAirFlowTopRearVisiblity( );

    virtual ulword ulwGetAirFlowRightIconValue( );

    virtual ulword ulwGetAirFlowLeftIconValue( );

    virtual ulword ulwGetAirFlowRearIconValue( );

    virtual ulword ulwGetHVACTemperatureUnit( );

    virtual ulword ulwGetHVACFrontFanSpeedValue( );

    virtual ulword ulwGetHVACRearFanSpeedValue( );

    virtual ulword ulwGetHVACAutoDefVisiblity( );

    virtual ulword ulwGetHVACDualVisiblity( );

    virtual ulword ulwGetHVACAutoVisiblity( );

    virtual ulword ulwGetPlasmaIconValue( );

    virtual ulword ulwGetHVACStatusAC( );

    virtual ulword ulwGetHVACStatusRecirculation( );

    virtual ulword ulwGetHVACStatusDefrost( );

    virtual ulword ulwGetHVACStatusForest( );

    virtual ulword ulwGetHVACStatusRearACStatusOff( );

    virtual ulword ulwGetHVACStatusOfOff( );

    virtual void vSetPopUpStatus(ulword ulwPopUpState);

protected:
    clHSA_Climate_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_Climate_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_Climate_Base_H

