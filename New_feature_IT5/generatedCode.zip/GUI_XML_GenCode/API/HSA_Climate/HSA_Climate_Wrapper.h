/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Climate_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_Climate_Wrapper_H
#define _HSA_Climate_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: GetHVACPopupPatternType
 * pattern are numbered according to the priority
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACPopupPatternType( void);

/**
 * Function: GetRightTemperatureValue
 * NISSAN ITG5SD
 * NISSAN
 */
void HSA_Climate__vGetRightTemperatureValue(GUI_String *out_result);

/**
 * Function: GetLeftTemperatureValue
 * NISSAN ITG5SD
 * NISSAN
 */
void HSA_Climate__vGetLeftTemperatureValue(GUI_String *out_result);

/**
 * Function: GetRearTemperatureValue
 * NISSAN ITG5SD
 * NISSAN
 */
void HSA_Climate__vGetRearTemperatureValue(GUI_String *out_result);

/**
 * Function: GetOutsideTemperatureValue
 * NISSAN ITG5SD
 * NISSAN
 */
void HSA_Climate__vGetOutsideTemperatureValue(GUI_String *out_result);

/**
 * Function: GetAirFlowTopRightVisiblity
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetAirFlowTopRightVisiblity( void);

/**
 * Function: GetAirFlowTopLeftVisiblity
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetAirFlowTopLeftVisiblity( void);

/**
 * Function: GetAirFlowTopRearVisiblity
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetAirFlowTopRearVisiblity( void);

/**
 * Function: GetAirFlowRightIconValue
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetAirFlowRightIconValue( void);

/**
 * Function: GetAirFlowLeftIconValue
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetAirFlowLeftIconValue( void);

/**
 * Function: GetAirFlowRearIconValue
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetAirFlowRearIconValue( void);

/**
 * Function: GetHVACTemperatureUnit
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACTemperatureUnit( void);

/**
 * Function: GetHVACFrontFanSpeedValue
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACFrontFanSpeedValue( void);

/**
 * Function: GetHVACRearFanSpeedValue
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACRearFanSpeedValue( void);

/**
 * Function: GetHVACAutoDefVisiblity
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACAutoDefVisiblity( void);

/**
 * Function: GetHVACDualVisiblity
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACDualVisiblity( void);

/**
 * Function: GetHVACAutoVisiblity
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACAutoVisiblity( void);

/**
 * Function: GetPlasmaIconValue
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetPlasmaIconValue( void);

/**
 * Function: GetHVACStatusAC
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACStatusAC( void);

/**
 * Function: GetHVACStatusRecirculation
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACStatusRecirculation( void);

/**
 * Function: GetHVACStatusDefrost
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACStatusDefrost( void);

/**
 * Function: GetHVACStatusForest
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACStatusForest( void);

/**
 * Function: GetHVACStatusRearACStatusOff
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACStatusRearACStatusOff( void);

/**
 * Function: GetHVACStatusOfOff
 * NISSAN ITG5SD
 * NISSAN
 */
ulword HSA_Climate__ulwGetHVACStatusOfOff( void);

/**
 * Function: SetPopUpStatus
 * NISSAN ITG5SD
 * NISSAN
 */
void HSA_Climate__vSetPopUpStatus(ulword ulwPopUpState);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_Climate_H

