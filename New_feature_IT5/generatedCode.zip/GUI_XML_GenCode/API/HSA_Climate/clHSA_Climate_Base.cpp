/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_Climate_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_Climate/clHSA_Climate_Base.h"

clHSA_Climate_Base* clHSA_Climate_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_Climate_Base.cpp.trc.h"
#endif


/**
 * Method: ulwGetHVACPopupPatternType
  * Returns the Pattern to be displayed
  * pattern are numbered according to the priority
 */
ulword clHSA_Climate_Base::ulwGetHVACPopupPatternType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACPopupPatternType not implemented"));
   return 0;
}

/**
 * Method: vGetRightTemperatureValue
  * This function returns the temperature value that shall be displayed on right side of the screen irrespective of RHD or LHD.
  * NISSAN ITG5SD
 */
void clHSA_Climate_Base::vGetRightTemperatureValue(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Climate::vGetRightTemperatureValue not implemented"));
   
}

/**
 * Method: vGetLeftTemperatureValue
  * This function returns the temperature value that shall be displayed on left side of the screen irrespective of RHD or LHD.
  * NISSAN ITG5SD
 */
void clHSA_Climate_Base::vGetLeftTemperatureValue(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Climate::vGetLeftTemperatureValue not implemented"));
   
}

/**
 * Method: vGetRearTemperatureValue
  * This function returns the rear temperature.
  * NISSAN ITG5SD
 */
void clHSA_Climate_Base::vGetRearTemperatureValue(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Climate::vGetRearTemperatureValue not implemented"));
   
}

/**
 * Method: vGetOutsideTemperatureValue
  * This function returns the temperature value that shall be displayed on diagnostics screen.
  * NISSAN ITG5SD
 */
void clHSA_Climate_Base::vGetOutsideTemperatureValue(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Climate::vGetOutsideTemperatureValue not implemented"));
   
}

/**
 * Method: ulwGetAirFlowTopRightVisiblity
  * This function returns the status of upper vent that shall be displayed on right side of the screen irrespective of RHD or LHD.
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetAirFlowTopRightVisiblity( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetAirFlowTopRightVisiblity not implemented"));
   return 0;
}

/**
 * Method: ulwGetAirFlowTopLeftVisiblity
  * This function returns the status of upper vent that shall be displayed on left side of the screen irrespective of RHD or LHD.
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetAirFlowTopLeftVisiblity( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetAirFlowTopLeftVisiblity not implemented"));
   return 0;
}

/**
 * Method: ulwGetAirFlowTopRearVisiblity
  * This function returns the rear upper vent status.
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetAirFlowTopRearVisiblity( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetAirFlowTopRearVisiblity not implemented"));
   return 0;
}

/**
 * Method: ulwGetAirFlowRightIconValue
  * Returns the Air Vent status of Driver
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetAirFlowRightIconValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetAirFlowRightIconValue not implemented"));
   return 0;
}

/**
 * Method: ulwGetAirFlowLeftIconValue
  * Returns the Air Vent status of Passenger
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetAirFlowLeftIconValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetAirFlowLeftIconValue not implemented"));
   return 0;
}

/**
 * Method: ulwGetAirFlowRearIconValue
  * Returns the Air Vent status of Rear
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetAirFlowRearIconValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetAirFlowRearIconValue not implemented"));
   return 0;
}

/**
 * Method: ulwGetHVACTemperatureUnit
  * Returns the Temperature unit
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetHVACTemperatureUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACTemperatureUnit not implemented"));
   return 0;
}

/**
 * Method: ulwGetHVACFrontFanSpeedValue
  * This function returns the Speed of front fan.
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetHVACFrontFanSpeedValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACFrontFanSpeedValue not implemented"));
   return 0;
}

/**
 * Method: ulwGetHVACRearFanSpeedValue
  * This function returns the Speed of Rear fan.
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetHVACRearFanSpeedValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACRearFanSpeedValue not implemented"));
   return 0;
}

/**
 * Method: ulwGetHVACAutoDefVisiblity
  * Returns the status of AUTO Defrost
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetHVACAutoDefVisiblity( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACAutoDefVisiblity not implemented"));
   return 0;
}

/**
 * Method: ulwGetHVACDualVisiblity
  * Returns the status of Dual
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetHVACDualVisiblity( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACDualVisiblity not implemented"));
   return 0;
}

/**
 * Method: ulwGetHVACAutoVisiblity
  * Returns the status of Automatic driver control
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetHVACAutoVisiblity( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACAutoVisiblity not implemented"));
   return 0;
}

/**
 * Method: ulwGetPlasmaIconValue
  * Returns the Plasma cluster status
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetPlasmaIconValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetPlasmaIconValue not implemented"));
   return 0;
}

/**
 * Method: ulwGetHVACStatusAC
  * Returns the AC Status
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetHVACStatusAC( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACStatusAC not implemented"));
   return 0;
}

/**
 * Method: ulwGetHVACStatusRecirculation
  * Returns the recirculation status
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetHVACStatusRecirculation( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACStatusRecirculation not implemented"));
   return 0;
}

/**
 * Method: ulwGetHVACStatusDefrost
  * Returns the Defrost status
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetHVACStatusDefrost( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACStatusDefrost not implemented"));
   return 0;
}

/**
 * Method: ulwGetHVACStatusForest
  * Returns the Forest Switch indicator status
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetHVACStatusForest( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACStatusForest not implemented"));
   return 0;
}

/**
 * Method: ulwGetHVACStatusRearACStatusOff
  * Returns the Rear AC off status
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetHVACStatusRearACStatusOff( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACStatusRearACStatusOff not implemented"));
   return 0;
}

/**
 * Method: ulwGetHVACStatusOfOff
  * Returns Status of off
  * NISSAN ITG5SD
 */
ulword clHSA_Climate_Base::ulwGetHVACStatusOfOff( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Climate::ulwGetHVACStatusOfOff not implemented"));
   return 0;
}

/**
 * Method: vSetPopUpStatus
  * Sets the Climate POP_UP state
  * NISSAN ITG5SD
 */
void clHSA_Climate_Base::vSetPopUpStatus(ulword ulwPopUpState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPopUpState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Climate::vSetPopUpStatus not implemented"));
   
}

