/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Climate_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_Climate_Wrapper.h"
#include "clHSA_Climate_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_Climate_Trace.h"
#include "hmi_trace.h"

ulword HSA_Climate__ulwGetHVACPopupPatternType( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_POPUP_PATTERN_TYPE  ) ); 
        }
      ret=pInst->ulwGetHVACPopupPatternType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_POPUP_PATTERN_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Climate__vGetRightTemperatureValue(GUI_String *out_result)
{
    
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_RIGHT_TEMPERATURE_VALUE  ) ); 
        }
      pInst->vGetRightTemperatureValue(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_RIGHT_TEMPERATURE_VALUE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Climate__vGetLeftTemperatureValue(GUI_String *out_result)
{
    
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_LEFT_TEMPERATURE_VALUE  ) ); 
        }
      pInst->vGetLeftTemperatureValue(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_LEFT_TEMPERATURE_VALUE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Climate__vGetRearTemperatureValue(GUI_String *out_result)
{
    
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_REAR_TEMPERATURE_VALUE  ) ); 
        }
      pInst->vGetRearTemperatureValue(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_REAR_TEMPERATURE_VALUE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Climate__vGetOutsideTemperatureValue(GUI_String *out_result)
{
    
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_OUTSIDE_TEMPERATURE_VALUE  ) ); 
        }
      pInst->vGetOutsideTemperatureValue(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_OUTSIDE_TEMPERATURE_VALUE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Climate__ulwGetAirFlowTopRightVisiblity( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_AIR_FLOW_TOP_RIGHT_VISIBLITY  ) ); 
        }
      ret=pInst->ulwGetAirFlowTopRightVisiblity();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_AIR_FLOW_TOP_RIGHT_VISIBLITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetAirFlowTopLeftVisiblity( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_AIR_FLOW_TOP_LEFT_VISIBLITY  ) ); 
        }
      ret=pInst->ulwGetAirFlowTopLeftVisiblity();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_AIR_FLOW_TOP_LEFT_VISIBLITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetAirFlowTopRearVisiblity( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_AIR_FLOW_TOP_REAR_VISIBLITY  ) ); 
        }
      ret=pInst->ulwGetAirFlowTopRearVisiblity();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_AIR_FLOW_TOP_REAR_VISIBLITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetAirFlowRightIconValue( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_AIR_FLOW_RIGHT_ICON_VALUE  ) ); 
        }
      ret=pInst->ulwGetAirFlowRightIconValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_AIR_FLOW_RIGHT_ICON_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetAirFlowLeftIconValue( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_AIR_FLOW_LEFT_ICON_VALUE  ) ); 
        }
      ret=pInst->ulwGetAirFlowLeftIconValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_AIR_FLOW_LEFT_ICON_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetAirFlowRearIconValue( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_AIR_FLOW_REAR_ICON_VALUE  ) ); 
        }
      ret=pInst->ulwGetAirFlowRearIconValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_AIR_FLOW_REAR_ICON_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetHVACTemperatureUnit( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_TEMPERATURE_UNIT  ) ); 
        }
      ret=pInst->ulwGetHVACTemperatureUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_TEMPERATURE_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetHVACFrontFanSpeedValue( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_FRONT_FAN_SPEED_VALUE  ) ); 
        }
      ret=pInst->ulwGetHVACFrontFanSpeedValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_FRONT_FAN_SPEED_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetHVACRearFanSpeedValue( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_REAR_FAN_SPEED_VALUE  ) ); 
        }
      ret=pInst->ulwGetHVACRearFanSpeedValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_REAR_FAN_SPEED_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetHVACAutoDefVisiblity( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_AUTO_DEF_VISIBLITY  ) ); 
        }
      ret=pInst->ulwGetHVACAutoDefVisiblity();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_AUTO_DEF_VISIBLITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetHVACDualVisiblity( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_DUAL_VISIBLITY  ) ); 
        }
      ret=pInst->ulwGetHVACDualVisiblity();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_DUAL_VISIBLITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetHVACAutoVisiblity( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_AUTO_VISIBLITY  ) ); 
        }
      ret=pInst->ulwGetHVACAutoVisiblity();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_AUTO_VISIBLITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetPlasmaIconValue( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_PLASMA_ICON_VALUE  ) ); 
        }
      ret=pInst->ulwGetPlasmaIconValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_PLASMA_ICON_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetHVACStatusAC( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_STATUS_AC  ) ); 
        }
      ret=pInst->ulwGetHVACStatusAC();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_STATUS_AC | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetHVACStatusRecirculation( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_STATUS_RECIRCULATION  ) ); 
        }
      ret=pInst->ulwGetHVACStatusRecirculation();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_STATUS_RECIRCULATION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetHVACStatusDefrost( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_STATUS_DEFROST  ) ); 
        }
      ret=pInst->ulwGetHVACStatusDefrost();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_STATUS_DEFROST | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetHVACStatusForest( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_STATUS_FOREST  ) ); 
        }
      ret=pInst->ulwGetHVACStatusForest();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_STATUS_FOREST | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetHVACStatusRearACStatusOff( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_STATUS_REAR_AC_STATUS_OFF  ) ); 
        }
      ret=pInst->ulwGetHVACStatusRearACStatusOff();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_STATUS_REAR_AC_STATUS_OFF | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Climate__ulwGetHVACStatusOfOff( )
{
    ulword ret = 0;
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_STATUS_OF_OFF  ) ); 
        }
      ret=pInst->ulwGetHVACStatusOfOff();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__GET_HVAC_STATUS_OF_OFF | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Climate__vSetPopUpStatus(ulword ulwPopUpState)
{
    
    clHSA_Climate_Base *pInst=clHSA_Climate_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_CLIMATE), (tU16)(HSA_API_ENTRYPOINT__SET_POP_UP_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPopUpState); 
        }
      pInst->vSetPopUpStatus(ulwPopUpState);

    }
}

#ifdef __cplusplus
}
#endif

