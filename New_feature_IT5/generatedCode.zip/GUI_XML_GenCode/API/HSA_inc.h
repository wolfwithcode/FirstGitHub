/*<<< auto-generated file. Do not edit. >>>
  *  FILE:        HSA_inc
  *  PROJECT:      CM-CR HMI Framework
  *  SW-COMPONENT: API2HSA Adapter > */

#ifndef _HSA_inc_H
#define _HSA_inc_H
#include	"API/HSA_AVDC/clHSA_AVDC_Base.h"
#include	"API/HSA_AVDC/HSA_Audio/clHSA_AVDC_Audio_Base.h"
#include	"API/HSA_GUI/clHSA_GUI_Base.h"
#include	"API/HSA_HMIFW_Test/clHSA_HMIFW_Test_Base.h"
#include	"API/HSA_Navigation/clHSA_Navigation_Base.h"
#include	"API/HSA_Navigation/HSA_Map/clHSA_Navigation_Map_Base.h"
#include	"API/HSA_Phone/clHSA_Phone_Base.h"
#include	"API/HSA_Radio/clHSA_Radio_Base.h"
#include	"API/HSA_Sound/clHSA_Sound_Base.h"
#include	"API/HSA_SpeechDialog/clHSA_SpeechDialog_Base.h"
#include	"API/HSA_System/clHSA_System_Base.h"
#include	"API/HSA_System/HSA_TestMode/clHSA_System_TestMode_Base.h"
#include	"API/HSA_System/HSA_Config/clHSA_System_Config_Base.h"
#include	"API/HSA_Telematic/clHSA_Telematic_Base.h"
#include	"API/HSA_Traffic/clHSA_Traffic_Base.h"
#include	"API/HSA_XMRadio/clHSA_XMRadio_Base.h"
#include	"API/HSA_SmartPhone/clHSA_SmartPhone_Base.h"
#include	"API/HSA_SXM/clHSA_SXM_Base.h"
#include	"API/HSA_SXM/HSA_Tabweather/clHSA_SXM_Tabweather_Base.h"
#include	"API/HSA_SXM/HSA_SPORTS/clHSA_SXM_SPORTS_Base.h"
#include	"API/HSA_SXM/HSA_STOCKS/clHSA_SXM_STOCKS_Base.h"
#include	"API/HSA_SXM/HSA_MOVIES/clHSA_SXM_MOVIES_Base.h"
#include	"API/HSA_SXM/HSA_FUEL/clHSA_SXM_FUEL_Base.h"
#include	"API/HSA_SXM/HSA_CHANNELART/clHSA_SXM_CHANNELART_Base.h"
#include	"API/HSA_SXM/HSA_SXM_TRAFFIC/clHSA_SXM_SXM_TRAFFIC_Base.h"
#include	"API/HSA_SXM/HSA_SXM_AUDIO/clHSA_SXM_SXM_AUDIO_Base.h"
#include	"API/HSA_TCU/clHSA_TCU_Base.h"
#include	"API/HSA_Climate/clHSA_Climate_Base.h"
#include	"API/HSA_VehicleFunction/clHSA_VehicleFunction_Base.h"

#endif //#ifndef _HSA_inc_H

