/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Sound_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_Sound_Wrapper.h"
#include "clHSA_Sound_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_Sound_Trace.h"
#include "hmi_trace.h"

tbool HSA_Sound__blNoActiveAudio( )
{
    tbool ret = false;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__NO_ACTIVE_AUDIO  ) ); 
        }
      ret=pInst->blNoActiveAudio();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__NO_ACTIVE_AUDIO | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Sound__vSetMuteState(tbool blMuteState, ulword ulwMuteType)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_MUTE_STATE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMuteState); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_MUTE_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMuteType); 
        }
      pInst->vSetMuteState(blMuteState, ulwMuteType);

    }
}

void HSA_Sound__vActivateAudioComponent(ulword ulwAudioComponent)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_AUDIO_COMPONENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwAudioComponent); 
        }
      pInst->vActivateAudioComponent(ulwAudioComponent);

    }
}

void HSA_Sound__vActivateAudioFeedback(ulword ulwSource)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_AUDIO_FEEDBACK | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSource); 
        }
      pInst->vActivateAudioFeedback(ulwSource);

    }
}

void HSA_Sound__vDecreaseToneSetting(ulword ulwTone)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__DECREASE_TONE_SETTING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTone); 
        }
      pInst->vDecreaseToneSetting(ulwTone);

    }
}

void HSA_Sound__vDecreaseVolume(ulword ulwSource)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__DECREASE_VOLUME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSource); 
        }
      pInst->vDecreaseVolume(ulwSource);

    }
}

ulword HSA_Sound__ulwGetActiveAudioComponent( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_AUDIO_COMPONENT  ) ); 
        }
      ret=pInst->ulwGetActiveAudioComponent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_AUDIO_COMPONENT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetCurrentAudioComponent( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_AUDIO_COMPONENT  ) ); 
        }
      ret=pInst->ulwGetCurrentAudioComponent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_AUDIO_COMPONENT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetCurrentRadioSource( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_RADIO_SOURCE  ) ); 
        }
      ret=pInst->ulwGetCurrentRadioSource();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_RADIO_SOURCE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetEQSettings( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_EQ_SETTINGS  ) ); 
        }
      ret=pInst->ulwGetEQSettings();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_EQ_SETTINGS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Sound__blGetLoudness( )
{
    tbool ret = false;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_LOUDNESS  ) ); 
        }
      ret=pInst->blGetLoudness();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_LOUDNESS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetNextPossibleSource( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_NEXT_POSSIBLE_SOURCE  ) ); 
        }
      ret=pInst->ulwGetNextPossibleSource();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_NEXT_POSSIBLE_SOURCE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetPDCVolumeSetting( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_PDC_VOLUME_SETTING  ) ); 
        }
      ret=pInst->ulwGetPDCVolumeSetting();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_PDC_VOLUME_SETTING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetSurround( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_SURROUND  ) ); 
        }
      ret=pInst->ulwGetSurround();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_SURROUND | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Sound__slwGetToneSetting(ulword ulwTone)
{
    slword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_TONE_SETTING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTone); 
        }
      ret=pInst->slwGetToneSetting(ulwTone);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_TONE_SETTING | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Sound__blGetAudioBoseSetting(ulword ulwSettingType)
{
    tbool ret = false;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_AUDIO_BOSE_SETTING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSettingType); 
        }
      ret=pInst->blGetAudioBoseSetting(ulwSettingType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_AUDIO_BOSE_SETTING | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Sound__blGetAudioBoseSettingAvailability(ulword ulwSettingType)
{
    tbool ret = false;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_AUDIO_BOSE_SETTING_AVAILABILITY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSettingType); 
        }
      ret=pInst->blGetAudioBoseSettingAvailability(ulwSettingType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_AUDIO_BOSE_SETTING_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Sound__vSetAudioBoseSetting(tbool blSettingState, ulword ulwSettingType)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_AUDIO_BOSE_SETTING | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blSettingState); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_AUDIO_BOSE_SETTING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSettingType); 
        }
      pInst->vSetAudioBoseSetting(blSettingState, ulwSettingType);

    }
}

slword HSA_Sound__slwGetVolume(ulword ulwSource)
{
    slword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_VOLUME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSource); 
        }
      ret=pInst->slwGetVolume(ulwSource);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_VOLUME | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_Sound__vIncreaseToneSetting(ulword ulwTone)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__INCREASE_TONE_SETTING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTone); 
        }
      pInst->vIncreaseToneSetting(ulwTone);

    }
}

void HSA_Sound__vIncreaseVolume(ulword ulwSource)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__INCREASE_VOLUME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSource); 
        }
      pInst->vIncreaseVolume(ulwSource);

    }
}

tbool HSA_Sound__blIsMuteActive( )
{
    tbool ret = false;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__IS_MUTE_ACTIVE  ) ); 
        }
      ret=pInst->blIsMuteActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__IS_MUTE_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Sound__vSetEQSettings(ulword ulwValue)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_EQ_SETTINGS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwValue); 
        }
      pInst->vSetEQSettings(ulwValue);

    }
}

void HSA_Sound__vSetLoudness(ulword ulwState)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_LOUDNESS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwState); 
        }
      pInst->vSetLoudness(ulwState);

    }
}

void HSA_Sound__vSetPinMute(tbool blMuteState)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_PIN_MUTE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMuteState); 
        }
      pInst->vSetPinMute(blMuteState);

    }
}

void HSA_Sound__vToggleMuteState( )
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_MUTE_STATE  ) ); 
        }
      pInst->vToggleMuteState();

    }
}

void HSA_Sound__vSetPDCVolumeSetting(ulword ulwValue)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_PDC_VOLUME_SETTING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwValue); 
        }
      pInst->vSetPDCVolumeSetting(ulwValue);

    }
}

void HSA_Sound__vSetVolume(ulword ulwSource, ulword ulwValue)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_VOLUME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSource); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_VOLUME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwValue); 
        }
      pInst->vSetVolume(ulwSource, ulwValue);

    }
}

void HSA_Sound__vSetToneSetting(ulword ulwTone, slword slwValue)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_TONE_SETTING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTone); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_TONE_SETTING | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwValue); 
        }
      pInst->vSetToneSetting(ulwTone, slwValue);

    }
}

void HSA_Sound__vSetSurround(ulword ulwValue)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_SURROUND | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwValue); 
        }
      pInst->vSetSurround(ulwValue);

    }
}

void HSA_Sound__vGetAmpSoftwareVersion(GUI_String *out_result)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_AMP_SOFTWARE_VERSION  ) ); 
        }
      pInst->vGetAmpSoftwareVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_AMP_SOFTWARE_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Sound__vGetAmpParameterVersion(GUI_String *out_result)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_AMP_PARAMETER_VERSION  ) ); 
        }
      pInst->vGetAmpParameterVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_AMP_PARAMETER_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Sound__vGetAmpHardwareVersion(GUI_String *out_result)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_AMP_HARDWARE_VERSION  ) ); 
        }
      pInst->vGetAmpHardwareVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_AMP_HARDWARE_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Sound__vGetANCSWVersion(GUI_String *out_result)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ANCSW_VERSION  ) ); 
        }
      pInst->vGetANCSWVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ANCSW_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Sound__vGetASCSWVersion(GUI_String *out_result)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ASCSW_VERSION  ) ); 
        }
      pInst->vGetASCSWVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ASCSW_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Sound__vSetANCASCActiveTest(tbool blRequest)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_ANCASC_ACTIVE_TEST | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blRequest); 
        }
      pInst->vSetANCASCActiveTest(blRequest);

    }
}

tbool HSA_Sound__blGetANCASCActiveTest( )
{
    tbool ret = false;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ANCASC_ACTIVE_TEST  ) ); 
        }
      ret=pInst->blGetANCASCActiveTest();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ANCASC_ACTIVE_TEST | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Sound__vSetANCASCSetting(ulword ulwANCSetting, ulword ulwASCSetting)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_ANCASC_SETTING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwANCSetting); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_ANCASC_SETTING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwASCSetting); 
        }
      pInst->vSetANCASCSetting(ulwANCSetting, ulwASCSetting);

    }
}

ulword HSA_Sound__ulwGetANCSetting( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ANC_SETTING  ) ); 
        }
      ret=pInst->ulwGetANCSetting();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ANC_SETTING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetASCSetting( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ASC_SETTING  ) ); 
        }
      ret=pInst->ulwGetASCSetting();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ASC_SETTING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Sound__blGetExternalAmplifierConnectionState( )
{
    tbool ret = false;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_EXTERNAL_AMPLIFIER_CONNECTION_STATE  ) ); 
        }
      ret=pInst->blGetExternalAmplifierConnectionState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_EXTERNAL_AMPLIFIER_CONNECTION_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetSpeakerValue1( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE1  ) ); 
        }
      ret=pInst->ulwGetSpeakerValue1();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE1 | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetSpeakerValue2( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE2  ) ); 
        }
      ret=pInst->ulwGetSpeakerValue2();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE2 | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetSpeakerValue3( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE3  ) ); 
        }
      ret=pInst->ulwGetSpeakerValue3();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE3 | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetSpeakerValue4( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE4  ) ); 
        }
      ret=pInst->ulwGetSpeakerValue4();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE4 | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetSpeakerValue5( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE5  ) ); 
        }
      ret=pInst->ulwGetSpeakerValue5();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE5 | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetANCASCDiagResult( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ANCASC_DIAG_RESULT  ) ); 
        }
      ret=pInst->ulwGetANCASCDiagResult();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ANCASC_DIAG_RESULT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetMicConnectionResult(ulword ulwMicType)
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_MIC_CONNECTION_RESULT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMicType); 
        }
      ret=pInst->ulwGetMicConnectionResult(ulwMicType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_MIC_CONNECTION_RESULT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetTachoResult( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_TACHO_RESULT  ) ); 
        }
      ret=pInst->ulwGetTachoResult();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_TACHO_RESULT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Sound__ulwGetDoorOpenSignal( )
{
    ulword ret = 0;
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_DOOR_OPEN_SIGNAL  ) ); 
        }
      ret=pInst->ulwGetDoorOpenSignal();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_DOOR_OPEN_SIGNAL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Sound__vGetANCASCConfigInfo(GUI_String *out_result)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ANCASC_CONFIG_INFO  ) ); 
        }
      pInst->vGetANCASCConfigInfo(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__GET_ANCASC_CONFIG_INFO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Sound__vSetBoseSpeakerTest(tbool blRequest)
{
    
    clHSA_Sound_Base *pInst=clHSA_Sound_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SOUND), (tU16)(HSA_API_ENTRYPOINT__SET_BOSE_SPEAKER_TEST | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blRequest); 
        }
      pInst->vSetBoseSpeakerTest(blRequest);

    }
}

#ifdef __cplusplus
}
#endif

