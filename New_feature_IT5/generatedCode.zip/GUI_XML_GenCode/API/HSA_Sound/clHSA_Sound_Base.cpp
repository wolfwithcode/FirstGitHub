/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_Sound_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_Sound/clHSA_Sound_Base.h"

clHSA_Sound_Base* clHSA_Sound_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_Sound_Base.cpp.trc.h"
#endif


/**
 * Method: blNoActiveAudio
  * Returns the over all mute status. Compared to IsMuteActive this includes not only Entertainment sources but also temporary nav announcments, phone,...
  * NISSAN
 */
tbool clHSA_Sound_Base::blNoActiveAudio( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Sound::blNoActiveAudio not implemented"));
   return 0;
}

/**
 * Method: vSetMuteState
  * sets the mute status
  * NISSAN
 */
void clHSA_Sound_Base::vSetMuteState(tbool blMuteState, ulword ulwMuteType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMuteState);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMuteType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vSetMuteState not implemented"));
   
}

/**
 * Method: vActivateAudioComponent
  * Sets the active audio component.
  * B1
 */
void clHSA_Sound_Base::vActivateAudioComponent(ulword ulwAudioComponent)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwAudioComponent);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vActivateAudioComponent not implemented"));
   
}

/**
 * Method: vActivateAudioFeedback
  * 
  * 
 */
void clHSA_Sound_Base::vActivateAudioFeedback(ulword ulwSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSource);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vActivateAudioFeedback not implemented"));
   
}

/**
 * Method: vDecreaseToneSetting
  * Decreases the selected tone setting.
  * B2
 */
void clHSA_Sound_Base::vDecreaseToneSetting(ulword ulwTone)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTone);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vDecreaseToneSetting not implemented"));
   
}

/**
 * Method: vDecreaseVolume
  * Decreases the selected volume setting.
  * B1
 */
void clHSA_Sound_Base::vDecreaseVolume(ulword ulwSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSource);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vDecreaseVolume not implemented"));
   
}

/**
 * Method: ulwGetActiveAudioComponent
  * Returns the active audio component. The component the user is listening to in this moment (foreground source).
  * B1
 */
ulword clHSA_Sound_Base::ulwGetActiveAudioComponent( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetActiveAudioComponent not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentAudioComponent
  * Returns the current audio component. The permanent entertainment component (radio or media) the user has selected. 
  * B1
 */
ulword clHSA_Sound_Base::ulwGetCurrentAudioComponent( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetCurrentAudioComponent not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentRadioSource
  * Returns the current radio source. 
  * ITG5SD
 */
ulword clHSA_Sound_Base::ulwGetCurrentRadioSource( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetCurrentRadioSource not implemented"));
   return 0;
}

/**
 * Method: ulwGetEQSettings
  * returns current Equilizer-Settings (presets)
  * B2
 */
ulword clHSA_Sound_Base::ulwGetEQSettings( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetEQSettings not implemented"));
   return 0;
}

/**
 * Method: blGetLoudness
  * gets the current loudnesstate (testmode)
  * B2
 */
tbool clHSA_Sound_Base::blGetLoudness( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Sound::blGetLoudness not implemented"));
   return 0;
}

/**
 * Method: ulwGetNextPossibleSource
  * returns the next possible audio-source.
  * B2
 */
ulword clHSA_Sound_Base::ulwGetNextPossibleSource( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetNextPossibleSource not implemented"));
   return 0;
}

/**
 * Method: ulwGetPDCVolumeSetting
  * Returns the current value for the PDC volume
  * B
 */
ulword clHSA_Sound_Base::ulwGetPDCVolumeSetting( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetPDCVolumeSetting not implemented"));
   return 0;
}

/**
 * Method: ulwGetSurround
  * returns current Surround-Settings (presets)
  * B2
 */
ulword clHSA_Sound_Base::ulwGetSurround( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetSurround not implemented"));
   return 0;
}

/**
 * Method: slwGetToneSetting
  * Returns the current value of the selected tone setting
  * B2
 */
slword clHSA_Sound_Base::slwGetToneSetting(ulword ulwTone)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTone);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Sound::slwGetToneSetting not implemented"));
   return 0;
}

/**
 * Method: blGetAudioBoseSetting
  * Returns the current value of the selected bose setting
  * ITG5SD
 */
tbool clHSA_Sound_Base::blGetAudioBoseSetting(ulword ulwSettingType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSettingType);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Sound::blGetAudioBoseSetting not implemented"));
   return 0;
}

/**
 * Method: blGetAudioBoseSettingAvailability
  * Returns the bose amplifier availability state
  * ITG5SD
 */
tbool clHSA_Sound_Base::blGetAudioBoseSettingAvailability(ulword ulwSettingType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSettingType);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Sound::blGetAudioBoseSettingAvailability not implemented"));
   return 0;
}

/**
 * Method: vSetAudioBoseSetting
  * sets the audio bose setting
  * NISSAN
 */
void clHSA_Sound_Base::vSetAudioBoseSetting(tbool blSettingState, ulword ulwSettingType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blSettingState);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSettingType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vSetAudioBoseSetting not implemented"));
   
}

/**
 * Method: slwGetVolume
  * Returns the current volume of the selected volume.
  * B2
 */
slword clHSA_Sound_Base::slwGetVolume(ulword ulwSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSource);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Sound::slwGetVolume not implemented"));
   return 0;
}

/**
 * Method: vIncreaseToneSetting
  * Increases the selected tone setting
  * B2
 */
void clHSA_Sound_Base::vIncreaseToneSetting(ulword ulwTone)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTone);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vIncreaseToneSetting not implemented"));
   
}

/**
 * Method: vIncreaseVolume
  * Increases the selected volume setting
  * B1
 */
void clHSA_Sound_Base::vIncreaseVolume(ulword ulwSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSource);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vIncreaseVolume not implemented"));
   
}

/**
 * Method: blIsMuteActive
  * Returns the mute status
  * B1
 */
tbool clHSA_Sound_Base::blIsMuteActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Sound::blIsMuteActive not implemented"));
   return 0;
}

/**
 * Method: vSetEQSettings
  * Sets Equalizer-Settings (for Skoda variant)
  * B2
 */
void clHSA_Sound_Base::vSetEQSettings(ulword ulwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vSetEQSettings not implemented"));
   
}

/**
 * Method: vSetLoudness
  * sets the loudness state (Testmode)
  * B2
 */
void clHSA_Sound_Base::vSetLoudness(ulword ulwState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vSetLoudness not implemented"));
   
}

/**
 * Method: vSetPinMute
  * Activates or deactivates the mute status. 
  * B2
 */
void clHSA_Sound_Base::vSetPinMute(tbool blMuteState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMuteState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vSetPinMute not implemented"));
   
}

/**
 * Method: vToggleMuteState
  * Activates or deactivates the mute status. Used to set the mute state when the event MFL_Mute is sent to the HMI.
  * B2
 */
void clHSA_Sound_Base::vToggleMuteState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Sound::vToggleMuteState not implemented"));
   
}

/**
 * Method: vSetPDCVolumeSetting
  * Sets the PDC volume to the specific value
  * B2
 */
void clHSA_Sound_Base::vSetPDCVolumeSetting(ulword ulwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vSetPDCVolumeSetting not implemented"));
   
}

/**
 * Method: vSetVolume
  * Sets the volume of the selected audio source to the specific value
  * B2
 */
void clHSA_Sound_Base::vSetVolume(ulword ulwSource, ulword ulwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSource);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vSetVolume not implemented"));
   
}

/**
 * Method: vSetToneSetting
  * Sets the selected tone setting to the specific value
  * B2
 */
void clHSA_Sound_Base::vSetToneSetting(ulword ulwTone, slword slwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTone);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vSetToneSetting not implemented"));
   
}

/**
 * Method: vSetSurround
  * Sets Surround-Setting (for Skoda variant)
  * B2
 */
void clHSA_Sound_Base::vSetSurround(ulword ulwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vSetSurround not implemented"));
   
}

/**
 * Method: vGetAmpSoftwareVersion
  * This function returns the amplifier software version.
  * ITG5SD
 */
void clHSA_Sound_Base::vGetAmpSoftwareVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vGetAmpSoftwareVersion not implemented"));
   
}

/**
 * Method: vGetAmpParameterVersion
  * This function returns the amplifier parameter version.
  * ITG5SD
 */
void clHSA_Sound_Base::vGetAmpParameterVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vGetAmpParameterVersion not implemented"));
   
}

/**
 * Method: vGetAmpHardwareVersion
  * This function returns the amplifier hardware version.
  * ITG5SD
 */
void clHSA_Sound_Base::vGetAmpHardwareVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vGetAmpHardwareVersion not implemented"));
   
}

/**
 * Method: vGetANCSWVersion
  * This function returns the amplifier hardware version.
  * ITG5SD
 */
void clHSA_Sound_Base::vGetANCSWVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vGetANCSWVersion not implemented"));
   
}

/**
 * Method: vGetASCSWVersion
  * This function returns the amplifier hardware version.
  * ITG5SD
 */
void clHSA_Sound_Base::vGetASCSWVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vGetASCSWVersion not implemented"));
   
}

/**
 * Method: vSetANCASCActiveTest
  * Start and stop the ANC ASC Active Test
  * ITG5SD
 */
void clHSA_Sound_Base::vSetANCASCActiveTest(tbool blRequest)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blRequest);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vSetANCASCActiveTest not implemented"));
   
}

/**
 * Method: blGetANCASCActiveTest
  * Status of ANC ASC Active Test
  * ITG5SD
 */
tbool clHSA_Sound_Base::blGetANCASCActiveTest( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Sound::blGetANCASCActiveTest not implemented"));
   return 0;
}

/**
 * Method: vSetANCASCSetting
  * Set ANC and ASC setting active or inactive
  * ITG5SD
 */
void clHSA_Sound_Base::vSetANCASCSetting(ulword ulwANCSetting, ulword ulwASCSetting)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwANCSetting);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwASCSetting);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vSetANCASCSetting not implemented"));
   
}

/**
 * Method: ulwGetANCSetting
  * Status of ANC Setting
  * ITG5SD
 */
ulword clHSA_Sound_Base::ulwGetANCSetting( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetANCSetting not implemented"));
   return 0;
}

/**
 * Method: ulwGetASCSetting
  * Status of ASC Setting
  * ITG5SD
 */
ulword clHSA_Sound_Base::ulwGetASCSetting( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetASCSetting not implemented"));
   return 0;
}

/**
 * Method: blGetExternalAmplifierConnectionState
  * Status of Bose amplifier connection state
  * ITG5SD
 */
tbool clHSA_Sound_Base::blGetExternalAmplifierConnectionState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Sound::blGetExternalAmplifierConnectionState not implemented"));
   return 0;
}

/**
 * Method: ulwGetSpeakerValue1
  * Status of General speaker Test
  * ITG5SD
 */
ulword clHSA_Sound_Base::ulwGetSpeakerValue1( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetSpeakerValue1 not implemented"));
   return 0;
}

/**
 * Method: ulwGetSpeakerValue2
  * Status of General speaker Test
  * ITG5SD
 */
ulword clHSA_Sound_Base::ulwGetSpeakerValue2( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetSpeakerValue2 not implemented"));
   return 0;
}

/**
 * Method: ulwGetSpeakerValue3
  * Status of General speaker Test
  * ITG5SD
 */
ulword clHSA_Sound_Base::ulwGetSpeakerValue3( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetSpeakerValue3 not implemented"));
   return 0;
}

/**
 * Method: ulwGetSpeakerValue4
  * Status of General speaker Test
  * ITG5SD
 */
ulword clHSA_Sound_Base::ulwGetSpeakerValue4( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetSpeakerValue4 not implemented"));
   return 0;
}

/**
 * Method: ulwGetSpeakerValue5
  * Status of General speaker Test
  * ITG5SD
 */
ulword clHSA_Sound_Base::ulwGetSpeakerValue5( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetSpeakerValue5 not implemented"));
   return 0;
}

/**
 * Method: ulwGetANCASCDiagResult
  * Status of ANC ASC Result Summary
  * ITG5SD
 */
ulword clHSA_Sound_Base::ulwGetANCASCDiagResult( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetANCASCDiagResult not implemented"));
   return 0;
}

/**
 * Method: ulwGetMicConnectionResult
  * Status of Mic connection Result
  * ITG5SD
 */
ulword clHSA_Sound_Base::ulwGetMicConnectionResult(ulword ulwMicType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMicType);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetMicConnectionResult not implemented"));
   return 0;
}

/**
 * Method: ulwGetTachoResult
  * Status of Engine pulse
  * ITG5SD
 */
ulword clHSA_Sound_Base::ulwGetTachoResult( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetTachoResult not implemented"));
   return 0;
}

/**
 * Method: ulwGetDoorOpenSignal
  * Status of Door Open Close
  * ITG5SD
 */
ulword clHSA_Sound_Base::ulwGetDoorOpenSignal( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Sound::ulwGetDoorOpenSignal not implemented"));
   return 0;
}

/**
 * Method: vGetANCASCConfigInfo
  * Returns the ANC ASC configuration info.
  * ITG5SD
 */
void clHSA_Sound_Base::vGetANCASCConfigInfo(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vGetANCASCConfigInfo not implemented"));
   
}

/**
 * Method: vSetBoseSpeakerTest
  * start/stop the speaker test
  * ITG5SD
 */
void clHSA_Sound_Base::vSetBoseSpeakerTest(tbool blRequest)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blRequest);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Sound::vSetBoseSpeakerTest not implemented"));
   
}

