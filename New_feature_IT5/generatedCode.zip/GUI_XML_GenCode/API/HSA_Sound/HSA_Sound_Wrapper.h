/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Sound_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_Sound_Wrapper_H
#define _HSA_Sound_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: NoActiveAudio
 * NISSAN
 * NISSAN
 */
tbool HSA_Sound__blNoActiveAudio( void);

/**
 * Function: SetMuteState
 * NISSAN
 * NISSAN
 */
void HSA_Sound__vSetMuteState(tbool blMuteState, ulword ulwMuteType);

/**
 * Function: ActivateAudioComponent
 * B1
 * NISSAN
 */
void HSA_Sound__vActivateAudioComponent(ulword ulwAudioComponent);

/**
 * Function: ActivateAudioFeedback
 * 
 * NISSAN
 */
void HSA_Sound__vActivateAudioFeedback(ulword ulwSource);

/**
 * Function: DecreaseToneSetting
 * B2
 * NISSAN
 */
void HSA_Sound__vDecreaseToneSetting(ulword ulwTone);

/**
 * Function: DecreaseVolume
 * B1
 * NISSAN
 */
void HSA_Sound__vDecreaseVolume(ulword ulwSource);

/**
 * Function: GetActiveAudioComponent
 * B1
 * NISSAN
 */
ulword HSA_Sound__ulwGetActiveAudioComponent( void);

/**
 * Function: GetCurrentAudioComponent
 * B1
 * NISSAN
 */
ulword HSA_Sound__ulwGetCurrentAudioComponent( void);

/**
 * Function: GetCurrentRadioSource
 * ITG5SD
 * NISSAN
 */
ulword HSA_Sound__ulwGetCurrentRadioSource( void);

/**
 * Function: GetEQSettings
 * B2
 * NISSAN
 */
ulword HSA_Sound__ulwGetEQSettings( void);

/**
 * Function: GetLoudness
 * B2
 * NISSAN
 */
tbool HSA_Sound__blGetLoudness( void);

/**
 * Function: GetNextPossibleSource
 * B2
 * NISSAN
 */
ulword HSA_Sound__ulwGetNextPossibleSource( void);

/**
 * Function: GetPDCVolumeSetting
 * B
 * NISSAN
 */
ulword HSA_Sound__ulwGetPDCVolumeSetting( void);

/**
 * Function: GetSurround
 * B2
 * NISSAN
 */
ulword HSA_Sound__ulwGetSurround( void);

/**
 * Function: GetToneSetting
 * B2
 * NISSAN
 */
slword HSA_Sound__slwGetToneSetting(ulword ulwTone);

/**
 * Function: GetAudioBoseSetting
 * ITG5SD
 * NISSAN
 */
tbool HSA_Sound__blGetAudioBoseSetting(ulword ulwSettingType);

/**
 * Function: GetAudioBoseSettingAvailability
 * ITG5SD
 * NISSAN
 */
tbool HSA_Sound__blGetAudioBoseSettingAvailability(ulword ulwSettingType);

/**
 * Function: SetAudioBoseSetting
 * NISSAN
 * NISSAN
 */
void HSA_Sound__vSetAudioBoseSetting(tbool blSettingState, ulword ulwSettingType);

/**
 * Function: GetVolume
 * B2
 * NISSAN
 */
slword HSA_Sound__slwGetVolume(ulword ulwSource);

/**
 * Function: IncreaseToneSetting
 * B2
 * NISSAN
 */
void HSA_Sound__vIncreaseToneSetting(ulword ulwTone);

/**
 * Function: IncreaseVolume
 * B1
 * NISSAN
 */
void HSA_Sound__vIncreaseVolume(ulword ulwSource);

/**
 * Function: IsMuteActive
 * B1
 * NISSAN
 */
tbool HSA_Sound__blIsMuteActive( void);

/**
 * Function: SetEQSettings
 * B2
 * NISSAN
 */
void HSA_Sound__vSetEQSettings(ulword ulwValue);

/**
 * Function: SetLoudness
 * B2
 * NISSAN
 */
void HSA_Sound__vSetLoudness(ulword ulwState);

/**
 * Function: SetPinMute
 * B2
 * NISSAN
 */
void HSA_Sound__vSetPinMute(tbool blMuteState);

/**
 * Function: ToggleMuteState
 * B2
 * NISSAN
 */
void HSA_Sound__vToggleMuteState( void);

/**
 * Function: SetPDCVolumeSetting
 * B2
 * NISSAN
 */
void HSA_Sound__vSetPDCVolumeSetting(ulword ulwValue);

/**
 * Function: SetVolume
 * B2
 * NISSAN
 */
void HSA_Sound__vSetVolume(ulword ulwSource, ulword ulwValue);

/**
 * Function: SetToneSetting
 * B2
 * NISSAN
 */
void HSA_Sound__vSetToneSetting(ulword ulwTone, slword slwValue);

/**
 * Function: SetSurround
 * B2
 * NISSAN
 */
void HSA_Sound__vSetSurround(ulword ulwValue);

/**
 * Function: GetAmpSoftwareVersion
 * ITG5SD
 * NISSAN
 */
void HSA_Sound__vGetAmpSoftwareVersion(GUI_String *out_result);

/**
 * Function: GetAmpParameterVersion
 * ITG5SD
 * NISSAN
 */
void HSA_Sound__vGetAmpParameterVersion(GUI_String *out_result);

/**
 * Function: GetAmpHardwareVersion
 * ITG5SD
 * NISSAN
 */
void HSA_Sound__vGetAmpHardwareVersion(GUI_String *out_result);

/**
 * Function: GetANCSWVersion
 * ITG5SD
 * NISSAN
 */
void HSA_Sound__vGetANCSWVersion(GUI_String *out_result);

/**
 * Function: GetASCSWVersion
 * ITG5SD
 * NISSAN
 */
void HSA_Sound__vGetASCSWVersion(GUI_String *out_result);

/**
 * Function: SetANCASCActiveTest
 * ITG5SD
 * NISSAN
 */
void HSA_Sound__vSetANCASCActiveTest(tbool blRequest);

/**
 * Function: GetANCASCActiveTest
 * ITG5SD
 * NISSAN
 */
tbool HSA_Sound__blGetANCASCActiveTest( void);

/**
 * Function: SetANCASCSetting
 * ITG5SD
 * NISSAN
 */
void HSA_Sound__vSetANCASCSetting(ulword ulwANCSetting, ulword ulwASCSetting);

/**
 * Function: GetANCSetting
 * ITG5SD
 * NISSAN
 */
ulword HSA_Sound__ulwGetANCSetting( void);

/**
 * Function: GetASCSetting
 * ITG5SD
 * NISSAN
 */
ulword HSA_Sound__ulwGetASCSetting( void);

/**
 * Function: GetExternalAmplifierConnectionState
 * ITG5SD
 * NISSAN
 */
tbool HSA_Sound__blGetExternalAmplifierConnectionState( void);

/**
 * Function: GetSpeakerValue1
 * ITG5SD
 * NISSAN
 */
ulword HSA_Sound__ulwGetSpeakerValue1( void);

/**
 * Function: GetSpeakerValue2
 * ITG5SD
 * NISSAN
 */
ulword HSA_Sound__ulwGetSpeakerValue2( void);

/**
 * Function: GetSpeakerValue3
 * ITG5SD
 * NISSAN
 */
ulword HSA_Sound__ulwGetSpeakerValue3( void);

/**
 * Function: GetSpeakerValue4
 * ITG5SD
 * NISSAN
 */
ulword HSA_Sound__ulwGetSpeakerValue4( void);

/**
 * Function: GetSpeakerValue5
 * ITG5SD
 * NISSAN
 */
ulword HSA_Sound__ulwGetSpeakerValue5( void);

/**
 * Function: GetANCASCDiagResult
 * ITG5SD
 * NISSAN
 */
ulword HSA_Sound__ulwGetANCASCDiagResult( void);

/**
 * Function: GetMicConnectionResult
 * ITG5SD
 * NISSAN
 */
ulword HSA_Sound__ulwGetMicConnectionResult(ulword ulwMicType);

/**
 * Function: GetTachoResult
 * ITG5SD
 * NISSAN
 */
ulword HSA_Sound__ulwGetTachoResult( void);

/**
 * Function: GetDoorOpenSignal
 * ITG5SD
 * NISSAN
 */
ulword HSA_Sound__ulwGetDoorOpenSignal( void);

/**
 * Function: GetANCASCConfigInfo
 * ITG5SD
 * NISSAN
 */
void HSA_Sound__vGetANCASCConfigInfo(GUI_String *out_result);

/**
 * Function: SetBoseSpeakerTest
 * ITG5SD
 * NISSAN
 */
void HSA_Sound__vSetBoseSpeakerTest(tbool blRequest);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_Sound_H

