/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_Sound_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_Sound_Base_H
#define _clHSA_Sound_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_Sound_Base : public clHSA_Base
{
public:

    static clHSA_Sound_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_Sound_Base()        {}

    virtual tbool blNoActiveAudio( );

    virtual void vSetMuteState(tbool blMuteState, ulword ulwMuteType);

    virtual void vActivateAudioComponent(ulword ulwAudioComponent);

    virtual void vActivateAudioFeedback(ulword ulwSource);

    virtual void vDecreaseToneSetting(ulword ulwTone);

    virtual void vDecreaseVolume(ulword ulwSource);

    virtual ulword ulwGetActiveAudioComponent( );

    virtual ulword ulwGetCurrentAudioComponent( );

    virtual ulword ulwGetCurrentRadioSource( );

    virtual ulword ulwGetEQSettings( );

    virtual tbool blGetLoudness( );

    virtual ulword ulwGetNextPossibleSource( );

    virtual ulword ulwGetPDCVolumeSetting( );

    virtual ulword ulwGetSurround( );

    virtual slword slwGetToneSetting(ulword ulwTone);

    virtual tbool blGetAudioBoseSetting(ulword ulwSettingType);

    virtual tbool blGetAudioBoseSettingAvailability(ulword ulwSettingType);

    virtual void vSetAudioBoseSetting(tbool blSettingState, ulword ulwSettingType);

    virtual slword slwGetVolume(ulword ulwSource);

    virtual void vIncreaseToneSetting(ulword ulwTone);

    virtual void vIncreaseVolume(ulword ulwSource);

    virtual tbool blIsMuteActive( );

    virtual void vSetEQSettings(ulword ulwValue);

    virtual void vSetLoudness(ulword ulwState);

    virtual void vSetPinMute(tbool blMuteState);

    virtual void vToggleMuteState( );

    virtual void vSetPDCVolumeSetting(ulword ulwValue);

    virtual void vSetVolume(ulword ulwSource, ulword ulwValue);

    virtual void vSetToneSetting(ulword ulwTone, slword slwValue);

    virtual void vSetSurround(ulword ulwValue);

    virtual void vGetAmpSoftwareVersion(GUI_String *out_result);

    virtual void vGetAmpParameterVersion(GUI_String *out_result);

    virtual void vGetAmpHardwareVersion(GUI_String *out_result);

    virtual void vGetANCSWVersion(GUI_String *out_result);

    virtual void vGetASCSWVersion(GUI_String *out_result);

    virtual void vSetANCASCActiveTest(tbool blRequest);

    virtual tbool blGetANCASCActiveTest( );

    virtual void vSetANCASCSetting(ulword ulwANCSetting, ulword ulwASCSetting);

    virtual ulword ulwGetANCSetting( );

    virtual ulword ulwGetASCSetting( );

    virtual tbool blGetExternalAmplifierConnectionState( );

    virtual ulword ulwGetSpeakerValue1( );

    virtual ulword ulwGetSpeakerValue2( );

    virtual ulword ulwGetSpeakerValue3( );

    virtual ulword ulwGetSpeakerValue4( );

    virtual ulword ulwGetSpeakerValue5( );

    virtual ulword ulwGetANCASCDiagResult( );

    virtual ulword ulwGetMicConnectionResult(ulword ulwMicType);

    virtual ulword ulwGetTachoResult( );

    virtual ulword ulwGetDoorOpenSignal( );

    virtual void vGetANCASCConfigInfo(GUI_String *out_result);

    virtual void vSetBoseSpeakerTest(tbool blRequest);

protected:
    clHSA_Sound_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_Sound_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_Sound_Base_H

