/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Sound_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_Sound_Wrapper_dbg.h"
#include "clHSA_Sound_Base.h"
#include "HSA_Sound_Trace.h"
#include "HSA_Sound_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_Sound_Wrapper_dbg::~clHSA_Sound_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_Sound_Wrapper_dbg::clHSA_Sound_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_Sound_Wrapper_dbg::clHSA_Sound_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_Sound_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_Sound_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__NO_ACTIVE_AUDIO:

            HSA_Sound__blNoActiveAudio();
            break;

        case HSA_API_ENTRYPOINT__SET_MUTE_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Sound__vSetMuteState(usParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_AUDIO_COMPONENT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__vActivateAudioComponent(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_AUDIO_FEEDBACK:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__vActivateAudioFeedback(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DECREASE_TONE_SETTING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__vDecreaseToneSetting(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DECREASE_VOLUME:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__vDecreaseVolume(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_AUDIO_COMPONENT:

            HSA_Sound__ulwGetActiveAudioComponent();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_AUDIO_COMPONENT:

            HSA_Sound__ulwGetCurrentAudioComponent();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_RADIO_SOURCE:

            HSA_Sound__ulwGetCurrentRadioSource();
            break;

        case HSA_API_ENTRYPOINT__GET_EQ_SETTINGS:

            HSA_Sound__ulwGetEQSettings();
            break;

        case HSA_API_ENTRYPOINT__GET_LOUDNESS:

            HSA_Sound__blGetLoudness();
            break;

        case HSA_API_ENTRYPOINT__GET_NEXT_POSSIBLE_SOURCE:

            HSA_Sound__ulwGetNextPossibleSource();
            break;

        case HSA_API_ENTRYPOINT__GET_PDC_VOLUME_SETTING:

            HSA_Sound__ulwGetPDCVolumeSetting();
            break;

        case HSA_API_ENTRYPOINT__GET_SURROUND:

            HSA_Sound__ulwGetSurround();
            break;

        case HSA_API_ENTRYPOINT__GET_TONE_SETTING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__slwGetToneSetting(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_AUDIO_BOSE_SETTING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__blGetAudioBoseSetting(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_AUDIO_BOSE_SETTING_AVAILABILITY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__blGetAudioBoseSettingAvailability(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_AUDIO_BOSE_SETTING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Sound__vSetAudioBoseSetting(usParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_VOLUME:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__slwGetVolume(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__INCREASE_TONE_SETTING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__vIncreaseToneSetting(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__INCREASE_VOLUME:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__vIncreaseVolume(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_MUTE_ACTIVE:

            HSA_Sound__blIsMuteActive();
            break;

        case HSA_API_ENTRYPOINT__SET_EQ_SETTINGS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__vSetEQSettings(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_LOUDNESS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__vSetLoudness(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_PIN_MUTE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Sound__vSetPinMute(usParam1);
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_MUTE_STATE:

            HSA_Sound__vToggleMuteState();
            break;

        case HSA_API_ENTRYPOINT__SET_PDC_VOLUME_SETTING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__vSetPDCVolumeSetting(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_VOLUME:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Sound__vSetVolume(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_TONE_SETTING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam2); 

            HSA_Sound__vSetToneSetting(ulParam1, slParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_SURROUND:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__vSetSurround(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_AMP_SOFTWARE_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Sound__vGetAmpSoftwareVersion(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_AMP_PARAMETER_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Sound__vGetAmpParameterVersion(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_AMP_HARDWARE_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Sound__vGetAmpHardwareVersion(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ANCSW_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Sound__vGetANCSWVersion(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ASCSW_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Sound__vGetASCSWVersion(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_ANCASC_ACTIVE_TEST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Sound__vSetANCASCActiveTest(usParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ANCASC_ACTIVE_TEST:

            HSA_Sound__blGetANCASCActiveTest();
            break;

        case HSA_API_ENTRYPOINT__SET_ANCASC_SETTING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Sound__vSetANCASCSetting(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_ANC_SETTING:

            HSA_Sound__ulwGetANCSetting();
            break;

        case HSA_API_ENTRYPOINT__GET_ASC_SETTING:

            HSA_Sound__ulwGetASCSetting();
            break;

        case HSA_API_ENTRYPOINT__GET_EXTERNAL_AMPLIFIER_CONNECTION_STATE:

            HSA_Sound__blGetExternalAmplifierConnectionState();
            break;

        case HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE1:

            HSA_Sound__ulwGetSpeakerValue1();
            break;

        case HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE2:

            HSA_Sound__ulwGetSpeakerValue2();
            break;

        case HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE3:

            HSA_Sound__ulwGetSpeakerValue3();
            break;

        case HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE4:

            HSA_Sound__ulwGetSpeakerValue4();
            break;

        case HSA_API_ENTRYPOINT__GET_SPEAKER_VALUE5:

            HSA_Sound__ulwGetSpeakerValue5();
            break;

        case HSA_API_ENTRYPOINT__GET_ANCASC_DIAG_RESULT:

            HSA_Sound__ulwGetANCASCDiagResult();
            break;

        case HSA_API_ENTRYPOINT__GET_MIC_CONNECTION_RESULT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Sound__ulwGetMicConnectionResult(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TACHO_RESULT:

            HSA_Sound__ulwGetTachoResult();
            break;

        case HSA_API_ENTRYPOINT__GET_DOOR_OPEN_SIGNAL:

            HSA_Sound__ulwGetDoorOpenSignal();
            break;

        case HSA_API_ENTRYPOINT__GET_ANCASC_CONFIG_INFO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Sound__vGetANCASCConfigInfo(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_BOSE_SPEAKER_TEST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Sound__vSetBoseSpeakerTest(usParam1);
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

