/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_SXM_FUEL_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_SXM/HSA_FUEL/clHSA_SXM_FUEL_Base.h"

clHSA_SXM_FUEL_Base* clHSA_SXM_FUEL_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_SXM_FUEL_Base.cpp.trc.h"
#endif


/**
 * Method: blWaitSyncForFuel
  * Whether to wait for information or not.
  * NISSAN2.0
 */
tbool clHSA_SXM_FUEL_Base::blWaitSyncForFuel( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_FUEL::blWaitSyncForFuel not implemented"));
   return 0;
}

/**
 * Method: ulwGetFuelType
  * Returns the Fuel Type name.
  * NISSAN2.0
 */
ulword clHSA_SXM_FUEL_Base::ulwGetFuelType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_FUEL::ulwGetFuelType not implemented"));
   return 0;
}

/**
 * Method: vSetFuelType
  * Set the Fuel Type.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vSetFuelType( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vSetFuelType not implemented"));
   
}

/**
 * Method: vRequestToGetBrandType
  * Request to get List of Brand Type.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vRequestToGetBrandType( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vRequestToGetBrandType not implemented"));
   
}

/**
 * Method: ulwGetBrandTypeCount
  * Returns the number of Fuel Brands in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_FUEL_Base::ulwGetBrandTypeCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_FUEL::ulwGetBrandTypeCount not implemented"));
   return 0;
}

/**
 * Method: vGetBrandType
  * Returns Brand type.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vGetBrandType(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vGetBrandType not implemented"));
   
}

/**
 * Method: vSetBrandType
  * Sets the Brand Name selected by user.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vSetBrandType(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vSetBrandType not implemented"));
   
}

/**
 * Method: vGetSelectedBrandType
  * Returns Brand type.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vGetSelectedBrandType(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vGetSelectedBrandType not implemented"));
   
}

/**
 * Method: vSetFuelStationLocation
  * Sets the location as Nearby, Near Destination or Favorites for Fuel Station.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vSetFuelStationLocation(ulword ulwLocType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLocType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vSetFuelStationLocation not implemented"));
   
}

/**
 * Method: vRequestToGetFuelStationList
  * Request to get the Fuel Stations list.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vRequestToGetFuelStationList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vRequestToGetFuelStationList not implemented"));
   
}

/**
 * Method: ulwGetFuelStationLocation
  * to get requested location type. 
  * NISSAN2.0
 */
ulword clHSA_SXM_FUEL_Base::ulwGetFuelStationLocation( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_FUEL::ulwGetFuelStationLocation not implemented"));
   return 0;
}

/**
 * Method: vSetFuelSortType
  * To set the Sorting Type for Nearby or Near Destination Fuel Station
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vSetFuelSortType(ulword ulwSortType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSortType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vSetFuelSortType not implemented"));
   
}

/**
 * Method: ulwGetFuelSortType
  * to get requested sort type. 
  * NISSAN2.0
 */
ulword clHSA_SXM_FUEL_Base::ulwGetFuelSortType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_FUEL::ulwGetFuelSortType not implemented"));
   return 0;
}

/**
 * Method: ulwGetFuelStationDistanceUnit
  *  Returns the integer value corresponding to the user selected distance metric
  * NISSAN2.0
 */
ulword clHSA_SXM_FUEL_Base::ulwGetFuelStationDistanceUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_FUEL::ulwGetFuelStationDistanceUnit not implemented"));
   return 0;
}

/**
 * Method: ulwGetFuelStationCount
  * Returns the number of entries in list of Fuel information.
  * NISSAN2.0
 */
ulword clHSA_SXM_FUEL_Base::ulwGetFuelStationCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_FUEL::ulwGetFuelStationCount not implemented"));
   return 0;
}

/**
 * Method: vGetFuelStationList
  * gets information of the fuel brand, price, age of the fuel, distance and direction.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vGetFuelStationList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vGetFuelStationList not implemented"));
   
}

/**
 * Method: vRequestDetailsForSelectedFuelStation
  * Request to get information of the fuel like Fuel Price, Address of the Fuel Station and its phone number, Amenitites.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vRequestDetailsForSelectedFuelStation(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vRequestDetailsForSelectedFuelStation not implemented"));
   
}

/**
 * Method: vGetDetailsForSelectedFuelStation
  * Gives extended information for the selected fuel station like Fuel Price, Address of the Fuel Station and its phone number, Amenitites.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vGetDetailsForSelectedFuelStation(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vGetDetailsForSelectedFuelStation not implemented"));
   
}

/**
 * Method: vGetSelectedBrandName
  * Gives brand Name for selected entry in Fuel info list.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vGetSelectedBrandName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vGetSelectedBrandName not implemented"));
   
}

/**
 * Method: ulwGetFavoriteCountForFuel
  * Returns the Number of Fuel Stations in the Favorites list.
  * NISSAN2.0
 */
ulword clHSA_SXM_FUEL_Base::ulwGetFavoriteCountForFuel( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_FUEL::ulwGetFavoriteCountForFuel not implemented"));
   return 0;
}

/**
 * Method: vGetFavoriteFuelStationList
  * Request to get the Favorite Fuel Station list with information like BrandName, Direction, Distance, Distance unit, Price, Age of fuel.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vGetFavoriteFuelStationList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vGetFavoriteFuelStationList not implemented"));
   
}

/**
 * Method: vGetDetailsForSelectedFavoriteFuelStation
  * Gives extended information for the selected fuel station like Fuel Price, Address of the Fuel Station and its phone number, Amenitites.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vGetDetailsForSelectedFavoriteFuelStation(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vGetDetailsForSelectedFavoriteFuelStation not implemented"));
   
}

/**
 * Method: blIsFavoriteFuelStation
  * To check whether the station is present in Favorite list or not.
  * NISSAN2.0
 */
tbool clHSA_SXM_FUEL_Base::blIsFavoriteFuelStation( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_FUEL::blIsFavoriteFuelStation not implemented"));
   return 0;
}

/**
 * Method: blIsFavoriteListFull
  * To check whether the Favorite Fuel Station list is full or not.
  * NISSAN2.0
 */
tbool clHSA_SXM_FUEL_Base::blIsFavoriteListFull( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_FUEL::blIsFavoriteListFull not implemented"));
   return 0;
}

/**
 * Method: vSaveFuelStationToFavoriteList
  * Save the selected Fuel Station to the Favorites.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vSaveFuelStationToFavoriteList(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vSaveFuelStationToFavoriteList not implemented"));
   
}

/**
 * Method: vRemoveFuelStationFromFavoriteList
  * Remove the selected Fuel Station from the Favorites.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vRemoveFuelStationFromFavoriteList(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vRemoveFuelStationFromFavoriteList not implemented"));
   
}

/**
 * Method: vRequestToGetFavFuelStationList
  * Request to get the favorite Fuel Stations list when user wants to replace an entry .
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vRequestToGetFavFuelStationList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vRequestToGetFavFuelStationList not implemented"));
   
}

/**
 * Method: vReplaceFuelStationInFavoriteList
  * Replace the selected Fuel Station entry from the Favorite list with the new one.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vReplaceFuelStationInFavoriteList(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vReplaceFuelStationInFavoriteList not implemented"));
   
}

/**
 * Method: blIsFavoriteAvailable
  * To check whether the Favorite Theater list is empty or not.
  * NISSAN2.0
 */
tbool clHSA_SXM_FUEL_Base::blIsFavoriteAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_FUEL::blIsFavoriteAvailable not implemented"));
   return 0;
}

/**
 * Method: vRequestToGetFuelType
  * Request to get List of Fuel Type.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vRequestToGetFuelType( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vRequestToGetFuelType not implemented"));
   
}

/**
 * Method: ulwGetFuelTypeCount
  * Returns the number of Fuel Types in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_FUEL_Base::ulwGetFuelTypeCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_FUEL::ulwGetFuelTypeCount not implemented"));
   return 0;
}

/**
 * Method: vGetFuelName
  * Returns Fuel type name.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vGetFuelName(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vGetFuelName not implemented"));
   
}

/**
 * Method: vSetFuelName
  * Sets the Fuel type Name selected by user.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vSetFuelName(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vSetFuelName not implemented"));
   
}

/**
 * Method: vGetSelectedFuelName
  * Returns selected Fuel type name.
  * NISSAN2.0
 */
void clHSA_SXM_FUEL_Base::vGetSelectedFuelName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_FUEL::vGetSelectedFuelName not implemented"));
   
}

/**
 * Method: ulwGetActiveBrandType
  * Returns the active Fuel Brands in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_FUEL_Base::ulwGetActiveBrandType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_FUEL::ulwGetActiveBrandType not implemented"));
   return 0;
}

/**
 * Method: ulwGetActiveFuelType
  * Returns the active Fuel Type in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_FUEL_Base::ulwGetActiveFuelType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_FUEL::ulwGetActiveFuelType not implemented"));
   return 0;
}

/**
 * Method: ulwGetFuelDataAvailability
  * Tells whether the data is available or not
  * NISSAN2.0
 */
ulword clHSA_SXM_FUEL_Base::ulwGetFuelDataAvailability( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_FUEL::ulwGetFuelDataAvailability not implemented"));
   return 0;
}

/**
 * Method: ulwGetFuelFilterAvailability
  * Tells whether the fuel filters are available or not
  * NISSAN2.0
 */
ulword clHSA_SXM_FUEL_Base::ulwGetFuelFilterAvailability( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_FUEL::ulwGetFuelFilterAvailability not implemented"));
   return 0;
}

