/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_SXM_FUEL_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_SXM_FUEL_Base_H
#define _clHSA_SXM_FUEL_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_SXM_FUEL_Base : public clHSA_Base
{
public:

    static clHSA_SXM_FUEL_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_SXM_FUEL_Base()        {}

    virtual tbool blWaitSyncForFuel( );

    virtual ulword ulwGetFuelType( );

    virtual void vSetFuelType( );

    virtual void vRequestToGetBrandType( );

    virtual ulword ulwGetBrandTypeCount( );

    virtual void vGetBrandType(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vSetBrandType(ulword ulwListEntryNr);

    virtual void vGetSelectedBrandType(GUI_String *out_result);

    virtual void vSetFuelStationLocation(ulword ulwLocType);

    virtual void vRequestToGetFuelStationList( );

    virtual ulword ulwGetFuelStationLocation( );

    virtual void vSetFuelSortType(ulword ulwSortType);

    virtual ulword ulwGetFuelSortType( );

    virtual ulword ulwGetFuelStationDistanceUnit( );

    virtual ulword ulwGetFuelStationCount( );

    virtual void vGetFuelStationList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vRequestDetailsForSelectedFuelStation(ulword ulwListEntryNr);

    virtual void vGetDetailsForSelectedFuelStation(GUI_String *out_result);

    virtual void vGetSelectedBrandName(GUI_String *out_result);

    virtual ulword ulwGetFavoriteCountForFuel( );

    virtual void vGetFavoriteFuelStationList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vGetDetailsForSelectedFavoriteFuelStation(GUI_String *out_result);

    virtual tbool blIsFavoriteFuelStation( );

    virtual tbool blIsFavoriteListFull( );

    virtual void vSaveFuelStationToFavoriteList(ulword ulwListEntryNr);

    virtual void vRemoveFuelStationFromFavoriteList(ulword ulwListEntryNr);

    virtual void vRequestToGetFavFuelStationList( );

    virtual void vReplaceFuelStationInFavoriteList(ulword ulwListEntryNr);

    virtual tbool blIsFavoriteAvailable( );

    virtual void vRequestToGetFuelType( );

    virtual ulword ulwGetFuelTypeCount( );

    virtual void vGetFuelName(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vSetFuelName(ulword ulwListEntryNr);

    virtual void vGetSelectedFuelName(GUI_String *out_result);

    virtual ulword ulwGetActiveBrandType( );

    virtual ulword ulwGetActiveFuelType( );

    virtual ulword ulwGetFuelDataAvailability( );

    virtual ulword ulwGetFuelFilterAvailability( );

protected:
    clHSA_SXM_FUEL_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_SXM_FUEL_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_SXM_FUEL_Base_H

