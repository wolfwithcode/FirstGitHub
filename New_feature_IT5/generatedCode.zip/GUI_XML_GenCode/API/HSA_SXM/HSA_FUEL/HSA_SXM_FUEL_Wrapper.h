/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_FUEL_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_SXM_FUEL_Wrapper_H
#define _HSA_SXM_FUEL_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: WaitSyncForFuel
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_FUEL__blWaitSyncForFuel( void);

/**
 * Function: GetFuelType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_FUEL__ulwGetFuelType( void);

/**
 * Function: SetFuelType
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vSetFuelType( void);

/**
 * Function: RequestToGetBrandType
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vRequestToGetBrandType( void);

/**
 * Function: GetBrandTypeCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_FUEL__ulwGetBrandTypeCount( void);

/**
 * Function: GetBrandType
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vGetBrandType(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: SetBrandType
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vSetBrandType(ulword ulwListEntryNr);

/**
 * Function: GetSelectedBrandType
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vGetSelectedBrandType(GUI_String *out_result);

/**
 * Function: SetFuelStationLocation
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vSetFuelStationLocation(ulword ulwLocType);

/**
 * Function: RequestToGetFuelStationList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vRequestToGetFuelStationList( void);

/**
 * Function: GetFuelStationLocation
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_FUEL__ulwGetFuelStationLocation( void);

/**
 * Function: SetFuelSortType
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vSetFuelSortType(ulword ulwSortType);

/**
 * Function: GetFuelSortType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_FUEL__ulwGetFuelSortType( void);

/**
 * Function: GetFuelStationDistanceUnit
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_FUEL__ulwGetFuelStationDistanceUnit( void);

/**
 * Function: GetFuelStationCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_FUEL__ulwGetFuelStationCount( void);

/**
 * Function: GetFuelStationList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vGetFuelStationList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: RequestDetailsForSelectedFuelStation
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vRequestDetailsForSelectedFuelStation(ulword ulwListEntryNr);

/**
 * Function: GetDetailsForSelectedFuelStation
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vGetDetailsForSelectedFuelStation(GUI_String *out_result);

/**
 * Function: GetSelectedBrandName
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vGetSelectedBrandName(GUI_String *out_result);

/**
 * Function: GetFavoriteCountForFuel
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_FUEL__ulwGetFavoriteCountForFuel( void);

/**
 * Function: GetFavoriteFuelStationList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vGetFavoriteFuelStationList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: GetDetailsForSelectedFavoriteFuelStation
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vGetDetailsForSelectedFavoriteFuelStation(GUI_String *out_result);

/**
 * Function: IsFavoriteFuelStation
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_FUEL__blIsFavoriteFuelStation( void);

/**
 * Function: IsFavoriteListFull
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_FUEL__blIsFavoriteListFull( void);

/**
 * Function: SaveFuelStationToFavoriteList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vSaveFuelStationToFavoriteList(ulword ulwListEntryNr);

/**
 * Function: RemoveFuelStationFromFavoriteList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vRemoveFuelStationFromFavoriteList(ulword ulwListEntryNr);

/**
 * Function: RequestToGetFavFuelStationList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vRequestToGetFavFuelStationList( void);

/**
 * Function: ReplaceFuelStationInFavoriteList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vReplaceFuelStationInFavoriteList(ulword ulwListEntryNr);

/**
 * Function: IsFavoriteAvailable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_FUEL__blIsFavoriteAvailable( void);

/**
 * Function: RequestToGetFuelType
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vRequestToGetFuelType( void);

/**
 * Function: GetFuelTypeCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_FUEL__ulwGetFuelTypeCount( void);

/**
 * Function: GetFuelName
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vGetFuelName(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: SetFuelName
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vSetFuelName(ulword ulwListEntryNr);

/**
 * Function: GetSelectedFuelName
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_FUEL__vGetSelectedFuelName(GUI_String *out_result);

/**
 * Function: GetActiveBrandType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_FUEL__ulwGetActiveBrandType( void);

/**
 * Function: GetActiveFuelType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_FUEL__ulwGetActiveFuelType( void);

/**
 * Function: GetFuelDataAvailability
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_FUEL__ulwGetFuelDataAvailability( void);

/**
 * Function: GetFuelFilterAvailability
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_FUEL__ulwGetFuelFilterAvailability( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_SXM_FUEL_H

