/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_FUEL_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_SXM_FUEL_Wrapper_dbg.h"
#include "clHSA_SXM_FUEL_Base.h"
#include "HSA_SXM_FUEL_Trace.h"
#include "HSA_SXM_FUEL_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_SXM_FUEL_Wrapper_dbg::~clHSA_SXM_FUEL_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_SXM_FUEL_Wrapper_dbg::clHSA_SXM_FUEL_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_SXM_FUEL_Wrapper_dbg::clHSA_SXM_FUEL_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_SXM_FUEL_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_SXM_FUEL_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_FUEL:

            HSA_SXM_FUEL__blWaitSyncForFuel();
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_TYPE:

            HSA_SXM_FUEL__ulwGetFuelType();
            break;

        case HSA_API_ENTRYPOINT__SET_FUEL_TYPE:

            HSA_SXM_FUEL__vSetFuelType();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_BRAND_TYPE:

            HSA_SXM_FUEL__vRequestToGetBrandType();
            break;

        case HSA_API_ENTRYPOINT__GET_BRAND_TYPE_COUNT:

            HSA_SXM_FUEL__ulwGetBrandTypeCount();
            break;

        case HSA_API_ENTRYPOINT__GET_BRAND_TYPE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_FUEL__vGetBrandType(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_BRAND_TYPE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_FUEL__vSetBrandType(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SELECTED_BRAND_TYPE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_FUEL__vGetSelectedBrandType(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_FUEL_STATION_LOCATION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_FUEL__vSetFuelStationLocation(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_FUEL_STATION_LIST:

            HSA_SXM_FUEL__vRequestToGetFuelStationList();
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_STATION_LOCATION:

            HSA_SXM_FUEL__ulwGetFuelStationLocation();
            break;

        case HSA_API_ENTRYPOINT__SET_FUEL_SORT_TYPE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_FUEL__vSetFuelSortType(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_SORT_TYPE:

            HSA_SXM_FUEL__ulwGetFuelSortType();
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_STATION_DISTANCE_UNIT:

            HSA_SXM_FUEL__ulwGetFuelStationDistanceUnit();
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_STATION_COUNT:

            HSA_SXM_FUEL__ulwGetFuelStationCount();
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_STATION_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_FUEL__vGetFuelStationList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_DETAILS_FOR_SELECTED_FUEL_STATION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_FUEL__vRequestDetailsForSelectedFuelStation(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DETAILS_FOR_SELECTED_FUEL_STATION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_FUEL__vGetDetailsForSelectedFuelStation(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SELECTED_BRAND_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_FUEL__vGetSelectedBrandName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_FAVORITE_COUNT_FOR_FUEL:

            HSA_SXM_FUEL__ulwGetFavoriteCountForFuel();
            break;

        case HSA_API_ENTRYPOINT__GET_FAVORITE_FUEL_STATION_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_FUEL__vGetFavoriteFuelStationList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_DETAILS_FOR_SELECTED_FAVORITE_FUEL_STATION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_FUEL__vGetDetailsForSelectedFavoriteFuelStation(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_FAVORITE_FUEL_STATION:

            HSA_SXM_FUEL__blIsFavoriteFuelStation();
            break;

        case HSA_API_ENTRYPOINT__IS_FAVORITE_LIST_FULL:

            HSA_SXM_FUEL__blIsFavoriteListFull();
            break;

        case HSA_API_ENTRYPOINT__SAVE_FUEL_STATION_TO_FAVORITE_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_FUEL__vSaveFuelStationToFavoriteList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__REMOVE_FUEL_STATION_FROM_FAVORITE_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_FUEL__vRemoveFuelStationFromFavoriteList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_FAV_FUEL_STATION_LIST:

            HSA_SXM_FUEL__vRequestToGetFavFuelStationList();
            break;

        case HSA_API_ENTRYPOINT__REPLACE_FUEL_STATION_IN_FAVORITE_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_FUEL__vReplaceFuelStationInFavoriteList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_FAVORITE_AVAILABLE:

            HSA_SXM_FUEL__blIsFavoriteAvailable();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_FUEL_TYPE:

            HSA_SXM_FUEL__vRequestToGetFuelType();
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_TYPE_COUNT:

            HSA_SXM_FUEL__ulwGetFuelTypeCount();
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_FUEL__vGetFuelName(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_FUEL_NAME:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_FUEL__vSetFuelName(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SELECTED_FUEL_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_FUEL__vGetSelectedFuelName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_BRAND_TYPE:

            HSA_SXM_FUEL__ulwGetActiveBrandType();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_FUEL_TYPE:

            HSA_SXM_FUEL__ulwGetActiveFuelType();
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_DATA_AVAILABILITY:

            HSA_SXM_FUEL__ulwGetFuelDataAvailability();
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_FILTER_AVAILABILITY:

            HSA_SXM_FUEL__ulwGetFuelFilterAvailability();
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

