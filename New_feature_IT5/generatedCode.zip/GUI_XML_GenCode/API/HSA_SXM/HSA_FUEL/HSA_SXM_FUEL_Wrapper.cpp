/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_FUEL_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_SXM_FUEL_Wrapper.h"
#include "clHSA_SXM_FUEL_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_SXM_FUEL_Trace.h"
#include "hmi_trace.h"

tbool HSA_SXM_FUEL__blWaitSyncForFuel( )
{
    tbool ret = false;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_FUEL  ) ); 
        }
      ret=pInst->blWaitSyncForFuel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_FUEL | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_FUEL__ulwGetFuelType( )
{
    ulword ret = 0;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_TYPE  ) ); 
        }
      ret=pInst->ulwGetFuelType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_FUEL__vSetFuelType( )
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__SET_FUEL_TYPE  ) ); 
        }
      pInst->vSetFuelType();

    }
}

void HSA_SXM_FUEL__vRequestToGetBrandType( )
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_BRAND_TYPE  ) ); 
        }
      pInst->vRequestToGetBrandType();

    }
}

ulword HSA_SXM_FUEL__ulwGetBrandTypeCount( )
{
    ulword ret = 0;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_BRAND_TYPE_COUNT  ) ); 
        }
      ret=pInst->ulwGetBrandTypeCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_BRAND_TYPE_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_FUEL__vGetBrandType(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_BRAND_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetBrandType(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_BRAND_TYPE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_FUEL__vSetBrandType(ulword ulwListEntryNr)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__SET_BRAND_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetBrandType(ulwListEntryNr);

    }
}

void HSA_SXM_FUEL__vGetSelectedBrandType(GUI_String *out_result)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_BRAND_TYPE  ) ); 
        }
      pInst->vGetSelectedBrandType(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_BRAND_TYPE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_FUEL__vSetFuelStationLocation(ulword ulwLocType)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__SET_FUEL_STATION_LOCATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLocType); 
        }
      pInst->vSetFuelStationLocation(ulwLocType);

    }
}

void HSA_SXM_FUEL__vRequestToGetFuelStationList( )
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_FUEL_STATION_LIST  ) ); 
        }
      pInst->vRequestToGetFuelStationList();

    }
}

ulword HSA_SXM_FUEL__ulwGetFuelStationLocation( )
{
    ulword ret = 0;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_STATION_LOCATION  ) ); 
        }
      ret=pInst->ulwGetFuelStationLocation();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_STATION_LOCATION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_FUEL__vSetFuelSortType(ulword ulwSortType)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__SET_FUEL_SORT_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSortType); 
        }
      pInst->vSetFuelSortType(ulwSortType);

    }
}

ulword HSA_SXM_FUEL__ulwGetFuelSortType( )
{
    ulword ret = 0;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_SORT_TYPE  ) ); 
        }
      ret=pInst->ulwGetFuelSortType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_SORT_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_FUEL__ulwGetFuelStationDistanceUnit( )
{
    ulword ret = 0;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_STATION_DISTANCE_UNIT  ) ); 
        }
      ret=pInst->ulwGetFuelStationDistanceUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_STATION_DISTANCE_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_FUEL__ulwGetFuelStationCount( )
{
    ulword ret = 0;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_STATION_COUNT  ) ); 
        }
      ret=pInst->ulwGetFuelStationCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_STATION_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_FUEL__vGetFuelStationList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_STATION_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_STATION_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetFuelStationList(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_STATION_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_FUEL__vRequestDetailsForSelectedFuelStation(ulword ulwListEntryNr)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__REQUEST_DETAILS_FOR_SELECTED_FUEL_STATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRequestDetailsForSelectedFuelStation(ulwListEntryNr);

    }
}

void HSA_SXM_FUEL__vGetDetailsForSelectedFuelStation(GUI_String *out_result)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_DETAILS_FOR_SELECTED_FUEL_STATION  ) ); 
        }
      pInst->vGetDetailsForSelectedFuelStation(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_DETAILS_FOR_SELECTED_FUEL_STATION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_FUEL__vGetSelectedBrandName(GUI_String *out_result)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_BRAND_NAME  ) ); 
        }
      pInst->vGetSelectedBrandName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_BRAND_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_FUEL__ulwGetFavoriteCountForFuel( )
{
    ulword ret = 0;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_COUNT_FOR_FUEL  ) ); 
        }
      ret=pInst->ulwGetFavoriteCountForFuel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_COUNT_FOR_FUEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_FUEL__vGetFavoriteFuelStationList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_FUEL_STATION_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_FUEL_STATION_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetFavoriteFuelStationList(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_FUEL_STATION_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_FUEL__vGetDetailsForSelectedFavoriteFuelStation(GUI_String *out_result)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_DETAILS_FOR_SELECTED_FAVORITE_FUEL_STATION  ) ); 
        }
      pInst->vGetDetailsForSelectedFavoriteFuelStation(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_DETAILS_FOR_SELECTED_FAVORITE_FUEL_STATION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_SXM_FUEL__blIsFavoriteFuelStation( )
{
    tbool ret = false;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__IS_FAVORITE_FUEL_STATION  ) ); 
        }
      ret=pInst->blIsFavoriteFuelStation();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__IS_FAVORITE_FUEL_STATION | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_FUEL__blIsFavoriteListFull( )
{
    tbool ret = false;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__IS_FAVORITE_LIST_FULL  ) ); 
        }
      ret=pInst->blIsFavoriteListFull();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__IS_FAVORITE_LIST_FULL | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_FUEL__vSaveFuelStationToFavoriteList(ulword ulwListEntryNr)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__SAVE_FUEL_STATION_TO_FAVORITE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSaveFuelStationToFavoriteList(ulwListEntryNr);

    }
}

void HSA_SXM_FUEL__vRemoveFuelStationFromFavoriteList(ulword ulwListEntryNr)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__REMOVE_FUEL_STATION_FROM_FAVORITE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRemoveFuelStationFromFavoriteList(ulwListEntryNr);

    }
}

void HSA_SXM_FUEL__vRequestToGetFavFuelStationList( )
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_FAV_FUEL_STATION_LIST  ) ); 
        }
      pInst->vRequestToGetFavFuelStationList();

    }
}

void HSA_SXM_FUEL__vReplaceFuelStationInFavoriteList(ulword ulwListEntryNr)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__REPLACE_FUEL_STATION_IN_FAVORITE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vReplaceFuelStationInFavoriteList(ulwListEntryNr);

    }
}

tbool HSA_SXM_FUEL__blIsFavoriteAvailable( )
{
    tbool ret = false;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__IS_FAVORITE_AVAILABLE  ) ); 
        }
      ret=pInst->blIsFavoriteAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__IS_FAVORITE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_FUEL__vRequestToGetFuelType( )
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_FUEL_TYPE  ) ); 
        }
      pInst->vRequestToGetFuelType();

    }
}

ulword HSA_SXM_FUEL__ulwGetFuelTypeCount( )
{
    ulword ret = 0;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_TYPE_COUNT  ) ); 
        }
      ret=pInst->ulwGetFuelTypeCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_TYPE_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_FUEL__vGetFuelName(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetFuelName(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_FUEL__vSetFuelName(ulword ulwListEntryNr)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__SET_FUEL_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetFuelName(ulwListEntryNr);

    }
}

void HSA_SXM_FUEL__vGetSelectedFuelName(GUI_String *out_result)
{
    
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_FUEL_NAME  ) ); 
        }
      pInst->vGetSelectedFuelName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTED_FUEL_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_FUEL__ulwGetActiveBrandType( )
{
    ulword ret = 0;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_BRAND_TYPE  ) ); 
        }
      ret=pInst->ulwGetActiveBrandType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_BRAND_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_FUEL__ulwGetActiveFuelType( )
{
    ulword ret = 0;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_FUEL_TYPE  ) ); 
        }
      ret=pInst->ulwGetActiveFuelType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_FUEL_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_FUEL__ulwGetFuelDataAvailability( )
{
    ulword ret = 0;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_DATA_AVAILABILITY  ) ); 
        }
      ret=pInst->ulwGetFuelDataAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_DATA_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_FUEL__ulwGetFuelFilterAvailability( )
{
    ulword ret = 0;
    clHSA_SXM_FUEL_Base *pInst=clHSA_SXM_FUEL_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_FILTER_AVAILABILITY  ) ); 
        }
      ret=pInst->ulwGetFuelFilterAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_FUEL), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_FILTER_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

#ifdef __cplusplus
}
#endif

