/*Exported Language Array from the model - SXM*/
/*  This file has been generated on 05.12.2014 16:38 */
/*
 *  This file contains the definition of exported language content.
 *  The String lists with the translation that are to be exported
 *  from the model are listed here in the array structure
 *  
 *  Please note that:
 *    - Translations are provided in the following language order
 *    - English US
 *    - French CAN
 *    - Spanish Standard Latin
 *    - Dutch
 *    - German
 *    - Italian
 *    - Portuguese
 *    - Russian
 *    - Turkish
 *    - English UK
 *    - French
 *    - Spanish
 *    - Danish
 *    - Swedish
 *    - Finnish
 *    - Norwegian
 *    - Polish
 *    - Slovak
 *    - Czech
 *    - Hungarian
 *    - Greek
 *    - Brazilian
 *    - Arabic
 *    - Thai
 *    - Australian
 *
 *    This list is the same as used in the Model
 *
 *  The following macros are used:
 *
 *    CONTENT_LANGUAGE_COUNT(LanguageCount)
 *       Provides the count value to indicate the number of translations
 *    CONTENT_LANGUAGE_ARRAY(DeviceName) 
 *       Provides the start of the Array with Device name to which the 
 *       array belongs
 *    CONTENT_INDEX_START(Index Value)
 *       mark the start of Each string followed by the array of
 *       translations
 *    CONTENT_LANGUAGE(ContentID)
 *       provides the content ID for the translated string
 *    CONTENT_INDEX_END
 *       marks the end of Each string translation set
 *    CONTENT_END(value)
 *       End of the complete array
 *
 */


CONTENT_BEGIN()
#ifndef CONTENT_EXP_LANGUAGE_COUNT
   #define CONTENT_EXP_LANGUAGE_COUNT       25
#endif // #ifndef CONTENT_EXP_LANGUAGE_COUNT
CONTENT_LANGUAGE_ARRAY(SXM)

#ifdef CONTENT_LANGUAGE
    //STRING_START(0)
    CONTENT_LANGUAGE(0x40004d27)                                      // 0x80000066: Rating
    CONTENT_LANGUAGE(0x40004d56)                                      // 0x80000066: Classification
    CONTENT_LANGUAGE(0x40004d57)                                      // 0x80000066: Clasificaci�n
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000066: #No translation required
    //STRING_END()
    //STRING_START(1)
    CONTENT_LANGUAGE(0x40004d28)                                      // 0x80000067: Length
    CONTENT_LANGUAGE(0x40004d58)                                      // 0x80000067: Dur�e
    CONTENT_LANGUAGE(0x40004d59)                                      // 0x80000067: Largo
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000067: #No translation required
    //STRING_END()
    //STRING_START(2)
    CONTENT_LANGUAGE(0x40004d29)                                      // 0x80000068: Times
    CONTENT_LANGUAGE(0x40004d5a)                                      // 0x80000068: Hrs.
    CONTENT_LANGUAGE(0x40004d5b)                                      // 0x80000068: Horar.
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000068: #No translation required
    //STRING_END()
    //STRING_START(3)
    CONTENT_LANGUAGE(0x40004d2a)                                      // 0x80000069: Actors
    CONTENT_LANGUAGE(0x40004d5c)                                      // 0x80000069: Acteurs
    CONTENT_LANGUAGE(0x40004d5d)                                      // 0x80000069: Actores
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000069: #No translation required
    //STRING_END()
    //STRING_START(4)
    CONTENT_LANGUAGE(0x40004d2b)                                      // 0x8000006a: Synopsis
    CONTENT_LANGUAGE(0x40004d2b)                                      // 0x8000006a: Synopsis
    CONTENT_LANGUAGE(0x40004d5e)                                      // 0x8000006a: Sin�psis
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006a: #No translation required
    //STRING_END()
    //STRING_START(5)
    CONTENT_LANGUAGE(0x40004d2c)                                      // 0x8000006b: Call Theater for Show Times
    CONTENT_LANGUAGE(0x40004d5f)                                      // 0x8000006b: Appel. cin�ma pr conn. l'horaire du film
    CONTENT_LANGUAGE(0x40004d60)                                      // 0x8000006b: Llamar cine para horario de funciones
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006b: #No translation required
    //STRING_END()
    //STRING_START(6)
    CONTENT_LANGUAGE(0x40004d1d)                                      // 0x8000006c: Today
    CONTENT_LANGUAGE(0x40004d61)                                      // 0x8000006c: Aujour.
    CONTENT_LANGUAGE(0x40004d1f)                                      // 0x8000006c: Hoy
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006c: #No translation required
    //STRING_END()
    //STRING_START(7)
    CONTENT_LANGUAGE(0x40004d2d)                                      // 0x8000006d: 1 day
    CONTENT_LANGUAGE(0x40004d20)                                      // 0x8000006d: 1 jour
    CONTENT_LANGUAGE(0x40004d21)                                      // 0x8000006d: 1 d�a
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006d: #No translation required
    //STRING_END()
    //STRING_START(8)
    CONTENT_LANGUAGE(0x40004d22)                                      // 0x80000056: 2 days
    CONTENT_LANGUAGE(0x40004d23)                                      // 0x80000056: 2 jours
    CONTENT_LANGUAGE(0x40004d24)                                      // 0x80000056: 2 d�as
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    //STRING_END()
    //STRING_START(9)
    CONTENT_LANGUAGE(0x40004d10)                                      // 0x80000057: 3+days
    CONTENT_LANGUAGE(0x40004d25)                                      // 0x80000057: 3+jours
    CONTENT_LANGUAGE(0x40004d26)                                      // 0x80000057: 3+d�as
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    //STRING_END()
    //STRING_START(10)
    CONTENT_LANGUAGE(0x40002cea)                                      // 0x8000006e: None
    CONTENT_LANGUAGE(0x40004d62)                                      // 0x8000006e: Aucun
    CONTENT_LANGUAGE(0x40004d63)                                      // 0x8000006e: Ninguno
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006e: #No translation required
    //STRING_END()
    //STRING_START(11)
    CONTENT_LANGUAGE(0x40004d2e)                                      // 0x8000006f: Out of Fuel
    CONTENT_LANGUAGE(0x40004d64)                                      // 0x8000006f: Manque d'essence
    CONTENT_LANGUAGE(0x40004d65)                                      // 0x8000006f: No hay gasolina
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000006f: #No translation required
    //STRING_END()
    //STRING_START(12)
    CONTENT_LANGUAGE(0x40004d2f)                                      // 0x80000070: Last Updated
    CONTENT_LANGUAGE(0x40004d66)                                      // 0x80000070: Derni�re mise � jour
    CONTENT_LANGUAGE(0x40004d67)                                      // 0x80000070: �ltima actualizaci�n
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000070: #No translation required
    //STRING_END()
    //STRING_START(13)
    CONTENT_LANGUAGE(0x40004d30)                                      // 0x80000071: Amenities
    CONTENT_LANGUAGE(0x40004d68)                                      // 0x80000071: Am�nagements
    CONTENT_LANGUAGE(0x40004d69)                                      // 0x80000071: Instalaciones p�blicas
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000071: #No translation required
    //STRING_END()
    //STRING_START(14)
    CONTENT_LANGUAGE(0x40004d31)                                      // 0x80000072: Open 24 Hours
    CONTENT_LANGUAGE(0x40004d6a)                                      // 0x80000072: Ouvert 24 h
    CONTENT_LANGUAGE(0x40004d6b)                                      // 0x80000072: Abierto 24 horas
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000072: #No translation required
    //STRING_END()
    //STRING_START(15)
    CONTENT_LANGUAGE(0x40004d32)                                      // 0x80000073: Emergency Road Service
    CONTENT_LANGUAGE(0x40004d6c)                                      // 0x80000073: Service routier d'urgence
    CONTENT_LANGUAGE(0x40004d6d)                                      // 0x80000073: Servicio de emergencia de calles
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000073: #No translation required
    //STRING_END()
    //STRING_START(16)
    CONTENT_LANGUAGE(0x40004d33)                                      // 0x80000074: Full Service
    CONTENT_LANGUAGE(0x40004d6e)                                      // 0x80000074: Service complet
    CONTENT_LANGUAGE(0x40004d6f)                                      // 0x80000074: Servicios completos
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000074: #No translation required
    //STRING_END()
    //STRING_START(17)
    CONTENT_LANGUAGE(0x40004d34)                                      // 0x80000075: Oil Change Service 
    CONTENT_LANGUAGE(0x40004d70)                                      // 0x80000075: Service de changement d'huile
    CONTENT_LANGUAGE(0x40004d71)                                      // 0x80000075: Servicio de cambio de aceite
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000075: #No translation required
    //STRING_END()
    //STRING_START(18)
    CONTENT_LANGUAGE(0x40004d35)                                      // 0x80000076: Interstate Access (less than .5 miles)
    CONTENT_LANGUAGE(0x40004d72)                                      // 0x80000076: Dist. Stat.-serv. de l'autor. (- de .5 milles)
    CONTENT_LANGUAGE(0x40004d73)                                      // 0x80000076: Acceso interestatal (menos de .5 millas)
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000076: #No translation required
    //STRING_END()
    //STRING_START(19)
    CONTENT_LANGUAGE(0x40004d36)                                      // 0x80000077: Interstate Access (over .5 miles)
    CONTENT_LANGUAGE(0x40004d74)                                      // 0x80000077: Dist. Stat.-serv. de l'autor. (+ de .5 milles)
    CONTENT_LANGUAGE(0x40004d75)                                      // 0x80000077: Acceso interestatal (m�s de .5 millas)
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000077: #No translation required
    //STRING_END()
    //STRING_START(20)
    CONTENT_LANGUAGE(0x40004d37)                                      // 0x80000078: Cash Discount
    CONTENT_LANGUAGE(0x40004d76)                                      // 0x80000078: Remise sur achats pay�s comptant
    CONTENT_LANGUAGE(0x40004d77)                                      // 0x80000078: Descuento por pago en efectivo
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000078: #No translation required
    //STRING_END()
    //STRING_START(21)
    CONTENT_LANGUAGE(0x40004d38)                                      // 0x80000079: Convenience Store
    CONTENT_LANGUAGE(0x40004d78)                                      // 0x80000079: D�panneur
    CONTENT_LANGUAGE(0x40004d79)                                      // 0x80000079: Tienda
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000079: #No translation required
    //STRING_END()
    //STRING_START(22)
    CONTENT_LANGUAGE(0x40004d39)                                      // 0x8000007a: Supermarket
    CONTENT_LANGUAGE(0x40004d7a)                                      // 0x8000007a: Supermarch�
    CONTENT_LANGUAGE(0x40004d7b)                                      // 0x8000007a: Supermercado
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007a: #No translation required
    //STRING_END()
    //STRING_START(23)
    CONTENT_LANGUAGE(0x40004d3a)                                      // 0x8000007b: Snacks/Fast Food
    CONTENT_LANGUAGE(0x40004d7c)                                      // 0x8000007b: Collations/Cuisine rapide
    CONTENT_LANGUAGE(0x40004d7d)                                      // 0x8000007b: Snacks/Comida r�pida
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007b: #No translation required
    //STRING_END()
    //STRING_START(24)
    CONTENT_LANGUAGE(0x40001017)                                      // 0x8000007c: Restaurant
    CONTENT_LANGUAGE(0x40001017)                                      // 0x8000007c: Restaurant
    CONTENT_LANGUAGE(0x40004d7e)                                      // 0x8000007c: Restaurante
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007c: #No translation required
    //STRING_END()
    //STRING_START(25)
    CONTENT_LANGUAGE(0x40004d3b)                                      // 0x8000007d: Truck Stop
    CONTENT_LANGUAGE(0x40004d7f)                                      // 0x8000007d: Restoroute
    CONTENT_LANGUAGE(0x40004d80)                                      // 0x8000007d: Parada para camiones
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007d: #No translation required
    //STRING_END()
    //STRING_START(26)
    CONTENT_LANGUAGE(0x40004d3c)                                      // 0x8000007e: Truck Stop with Hotel
    CONTENT_LANGUAGE(0x40004d81)                                      // 0x8000007e: Restoroute avec h�tel
    CONTENT_LANGUAGE(0x40004d82)                                      // 0x8000007e: Parada para camiones con hotel
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007e: #No translation required
    //STRING_END()
    //STRING_START(27)
    CONTENT_LANGUAGE(0x40004d3d)                                      // 0x8000007f: Affiliated Service Cards Accepted
    CONTENT_LANGUAGE(0x40004d83)                                      // 0x8000007f: Cartes service de r�seaux affili�s accept.
    CONTENT_LANGUAGE(0x40004d84)                                      // 0x8000007f: Se aceptan tarjetas del servicio afiliado
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000007f: #No translation required
    //STRING_END()
    //STRING_START(28)
    CONTENT_LANGUAGE(0x40004d3e)                                      // 0x80000080: All Service Cards Accepted
    CONTENT_LANGUAGE(0x40004d85)                                      // 0x80000080: Toutes les cartes de service accept�es
    CONTENT_LANGUAGE(0x40004d86)                                      // 0x80000080: Se aceptan todas las tarjetas del servicio
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000080: #No translation required
    //STRING_END()
    //STRING_START(29)
    CONTENT_LANGUAGE(0x40004d3f)                                      // 0x80000081: Credit/Debit Accepted
    CONTENT_LANGUAGE(0x40004d87)                                      // 0x80000081: Cartes de cr�dit/d�bit accept�es
    CONTENT_LANGUAGE(0x40004d88)                                      // 0x80000081: Se acepta cr�dito/d�bito
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000081: #No translation required
    //STRING_END()
    //STRING_START(30)
    CONTENT_LANGUAGE(0x40004d40)                                      // 0x80000082: Public Access
    CONTENT_LANGUAGE(0x40004d89)                                      // 0x80000082: Acc�s au public
    CONTENT_LANGUAGE(0x40004d8a)                                      // 0x80000082: Acceso p�blico
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000082: #No translation required
    //STRING_END()
    //STRING_START(31)
    CONTENT_LANGUAGE(0x40004d41)                                      // 0x80000083: Patrons Only
    CONTENT_LANGUAGE(0x40004d8b)                                      // 0x80000083: Clients seulement
    CONTENT_LANGUAGE(0x40004d8c)                                      // 0x80000083: Acceso restringido
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000083: #No translation required
    //STRING_END()
    //STRING_START(32)
    CONTENT_LANGUAGE(0x40004d42)                                      // 0x80000084: Cash Accepted
    CONTENT_LANGUAGE(0x40004d8d)                                      // 0x80000084: Argent comptant accept�
    CONTENT_LANGUAGE(0x40004d8e)                                      // 0x80000084: Se acepta efectivo
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000084: #No translation required
    //STRING_END()
    //STRING_START(33)
    CONTENT_LANGUAGE(0x40004d43)                                      // 0x80000085: Reservations
    CONTENT_LANGUAGE(0x40004d8f)                                      // 0x80000085: R�servations
    CONTENT_LANGUAGE(0x40004d90)                                      // 0x80000085: Reservas
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000085: #No translation required
    //STRING_END()
    //STRING_START(34)
    CONTENT_LANGUAGE(0x4000017b)                                      // 0x80000026: AM
    CONTENT_LANGUAGE(0x4000017b)                                      // 0x80000026: AM
    CONTENT_LANGUAGE(0x4000017b)                                      // 0x80000026: AM
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000026: #No translation required
    //STRING_END()
    //STRING_START(35)
    CONTENT_LANGUAGE(0x4000089f)                                      // 0x80000027: PM
    CONTENT_LANGUAGE(0x4000089f)                                      // 0x80000027: PM
    CONTENT_LANGUAGE(0x4000089f)                                      // 0x80000027: PM
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000027: #No translation required
    //STRING_END()
    //STRING_START(36)
    CONTENT_LANGUAGE(0x40002087)                                      // 0x80000086: Loading
    CONTENT_LANGUAGE(0x40004d91)                                      // 0x80000086: Chargement
    CONTENT_LANGUAGE(0x40004d92)                                      // 0x80000086: Cargando
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000086: #No translation required
    //STRING_END()
    //STRING_START(37)
    CONTENT_LANGUAGE(0x40002ceb)                                      // 0x80000087: Unknown
    CONTENT_LANGUAGE(0x40004d93)                                      // 0x80000087: Inconnu
    CONTENT_LANGUAGE(0x40004d94)                                      // 0x80000087: Desconoc.
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000087: #No translation required
    //STRING_END()
    //STRING_START(38)
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x80000058: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x80000058: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x80000058: km
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    //STRING_END()
    //STRING_START(39)
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x80000088: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x80000088: m
    CONTENT_LANGUAGE(0x4000083b)                                      // 0x80000088: m
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000088: #No translation required
    //STRING_END()
    //STRING_START(40)
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x80000059: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x80000059: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x80000059: mi
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    //STRING_END()
    //STRING_START(41)
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000089: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000089: yds
    CONTENT_LANGUAGE(0x4000083d)                                      // 0x80000089: yds
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000089: #No translation required
    //STRING_END()
    //STRING_START(42)
    CONTENT_LANGUAGE(0x4000083e)                                      // 0x8000008a: ft
    CONTENT_LANGUAGE(0x40004d95)                                      // 0x8000008a: pi
    CONTENT_LANGUAGE(0x40004d96)                                      // 0x8000008a: pies
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008a: #No translation required
    //STRING_END()
    //STRING_START(43)
    CONTENT_LANGUAGE(0x40004d44)                                      // 0x8000008b: Fuel Price Info Loading...
    CONTENT_LANGUAGE(0x40004d97)                                      // 0x8000008b: Chargement Info prix du carburant en cours�
    CONTENT_LANGUAGE(0x40004d98)                                      // 0x8000008b: Cargando info precio gasolina
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008b: #No translation required
    //STRING_END()
    //STRING_START(44)
    CONTENT_LANGUAGE(0x40004d45)                                      // 0x8000008c: No Price Information
    CONTENT_LANGUAGE(0x40004d99)                                      // 0x8000008c: Pas d'info prix
    CONTENT_LANGUAGE(0x40004d9a)                                      // 0x8000008c: No existe informaci�n sobre precio
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008c: #No translation required
    //STRING_END()
    //STRING_START(45)
    CONTENT_LANGUAGE(0x40004d46)                                      // 0x8000008d: All Brands
    CONTENT_LANGUAGE(0x40004d9b)                                      // 0x8000008d: Toutes marques
    CONTENT_LANGUAGE(0x40004d9c)                                      // 0x8000008d: Todas las marcas
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000008d: #No translation required
    //STRING_END()
    //STRING_START(46)
    CONTENT_LANGUAGE(0x40004d47)                                      // 0x8000008e: Preset SXM
    CONTENT_LANGUAGE(0x40004d9d)                                      // 0x8000008e: Pr�s�lection SXM
    CONTENT_LANGUAGE(0x40004d9e)                                      // 0x8000008e: Preajustes SXM
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    CONTENT_LANGUAGE(0x40004d9f)                                      // 0x8000008e: Preset
    //STRING_END()
    //STRING_START(47)
    CONTENT_LANGUAGE(0x40004d48)                                      // 0x8000008f: Today's Game
    CONTENT_LANGUAGE(0x40004da0)                                      // 0x8000008f: Match du jour
    CONTENT_LANGUAGE(0x40004da1)                                      // 0x8000008f: Partido de hoy
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000008f: 
    //STRING_END()
    //STRING_START(48)
    CONTENT_LANGUAGE(0x40004d49)                                      // 0x80000090: Recent Game
    CONTENT_LANGUAGE(0x40004da2)                                      // 0x80000090: Match r�cent
    CONTENT_LANGUAGE(0x40004da3)                                      // 0x80000090: Partido reciente
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000090: 
    //STRING_END()
    //STRING_START(49)
    CONTENT_LANGUAGE(0x40004d4a)                                      // 0x80000091: Future Game
    CONTENT_LANGUAGE(0x40004da4)                                      // 0x80000091: Match � venir
    CONTENT_LANGUAGE(0x40004da5)                                      // 0x80000091: Futuro partido
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000091: 
    //STRING_END()
    //STRING_START(50)
    CONTENT_LANGUAGE(0x40004d4b)                                      // 0x80000092: Away
    CONTENT_LANGUAGE(0x40004da6)                                      // 0x80000092: � l'ext�r.
    CONTENT_LANGUAGE(0x40004da7)                                      // 0x80000092: Fuera
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000092: 
    //STRING_END()
    //STRING_START(51)
    CONTENT_LANGUAGE(0x40004d4c)                                      // 0x80000093: Home
    CONTENT_LANGUAGE(0x40004da8)                                      // 0x80000093: � domic.
    CONTENT_LANGUAGE(0x40004da9)                                      // 0x80000093: Casa
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000093: 
    //STRING_END()
    //STRING_START(52)
    CONTENT_LANGUAGE(0x40004d4d)                                      // 0x80000094: Course
    CONTENT_LANGUAGE(0x40004d4d)                                      // 0x80000094: Course
    CONTENT_LANGUAGE(0x40004daa)                                      // 0x80000094: Recorrido
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000094: 
    //STRING_END()
    //STRING_START(53)
    CONTENT_LANGUAGE(0x40004d4e)                                      // 0x80000095: Purse
    CONTENT_LANGUAGE(0x40004dab)                                      // 0x80000095: Prix
    CONTENT_LANGUAGE(0x40004dac)                                      // 0x80000095: Premio
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000095: 
    //STRING_END()
    //STRING_START(54)
    CONTENT_LANGUAGE(0x40004d4f)                                      // 0x80000096: Yardage
    CONTENT_LANGUAGE(0x40004d4f)                                      // 0x80000096: Yardage
    CONTENT_LANGUAGE(0x40004dad)                                      // 0x80000096: Yardaje
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000096: 
    //STRING_END()
    //STRING_START(55)
    CONTENT_LANGUAGE(0x40004d50)                                      // 0x80000097: Winner
    CONTENT_LANGUAGE(0x40004dae)                                      // 0x80000097: Gagnant
    CONTENT_LANGUAGE(0x40004daf)                                      // 0x80000097: Ganador
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000097: 
    //STRING_END()
    //STRING_START(56)
    CONTENT_LANGUAGE(0x40004b8d)                                      // 0x80000098: Track
    CONTENT_LANGUAGE(0x40004c29)                                      // 0x80000098: Piste
    CONTENT_LANGUAGE(0x40004db0)                                      // 0x80000098: Circuito
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000098: 
    //STRING_END()
    //STRING_START(57)
    CONTENT_LANGUAGE(0x40004d51)                                      // 0x80000099: Laps
    CONTENT_LANGUAGE(0x40004db1)                                      // 0x80000099: Tours
    CONTENT_LANGUAGE(0x40004db2)                                      // 0x80000099: Vueltas
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x80000099: 
    //STRING_END()
    //STRING_START(58)
    CONTENT_LANGUAGE(0x40004d52)                                      // 0x8000009a: Lap
    CONTENT_LANGUAGE(0x40004db3)                                      // 0x8000009a: Tour
    CONTENT_LANGUAGE(0x40004db4)                                      // 0x8000009a: Vuelta
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009a: 
    //STRING_END()
    //STRING_START(59)
    CONTENT_LANGUAGE(0x40002f27)                                      // 0x8000009b: Leader
    CONTENT_LANGUAGE(0x40002f27)                                      // 0x8000009b: Leader
    CONTENT_LANGUAGE(0x40004db5)                                      // 0x8000009b: 1� pos.
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009b: 
    //STRING_END()
    //STRING_START(60)
    CONTENT_LANGUAGE(0x40004d53)                                      // 0x8000009c: Car
    CONTENT_LANGUAGE(0x40004db6)                                      // 0x8000009c: Voiture
    CONTENT_LANGUAGE(0x40004db7)                                      // 0x8000009c: Coche
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    CONTENT_LANGUAGE(0x4000013c)                                      // 0x8000009c: 
    //STRING_END()
    //STRING_START(61)
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    CONTENT_LANGUAGE(0x40004d54)                                      // 0x8000009d: Favorite
    //STRING_END()
    //STRING_START(62)
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004db8)                                      // 0x8000009e: F�tbol americano
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000009e: Football
    //STRING_END()
    //STRING_START(63)
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004db9)                                      // 0x8000009f: Baloncesto
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000009f: Basketball
    //STRING_END()
    //STRING_START(64)
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004dba)                                      // 0x800000a0: B�isbol
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x800000a0: Baseball
    //STRING_END()
    //STRING_START(65)
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004dbb)                                      // 0x800000a1: F�tbol
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x800000a1: Soccer
    //STRING_END()
    //STRING_START(66)
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004dbc)                                      // 0x800000a2: Hockey sur glace
    CONTENT_LANGUAGE(0x40004dbd)                                      // 0x800000a2: Hockey sobre hielo
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x800000a2: Ice Hockey
    //STRING_END()
    //STRING_START(67)
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004dbe)                                      // 0x800000a3: Sports motoris�s
    CONTENT_LANGUAGE(0x40004dbf)                                      // 0x800000a3: Deporte del motor
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x800000a3: Motor Sports
    //STRING_END()
    //STRING_START(68)
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    //STRING_END()
#endif // #ifdef CONTENT_LANGUAGE

CONTENT_END()
