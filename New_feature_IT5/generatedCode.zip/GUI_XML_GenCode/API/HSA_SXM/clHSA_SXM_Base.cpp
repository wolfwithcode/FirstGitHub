/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_SXM_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_SXM/clHSA_SXM_Base.h"

clHSA_SXM_Base* clHSA_SXM_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_SXM_Base.cpp.trc.h"
#endif


/**
 * Method: vReleaseSXMDataServiceList
  * API to initiate the release of the Freezed List for all SXM Data Services
  * NISSAN
 */
void clHSA_SXM_Base::vReleaseSXMDataServiceList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM::vReleaseSXMDataServiceList not implemented"));
   
}

/**
 * Method: vUpdateSXMDataServiveInfo
  * API to initiate the update of the changed status received from MIDW
  * NISSAN
 */
void clHSA_SXM_Base::vUpdateSXMDataServiveInfo(ulword ulwScreenNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwScreenNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM::vUpdateSXMDataServiveInfo not implemented"));
   
}

/**
 * Method: blGetSXMDataServiveListStatus
  * API to know whether the list is freezed or not.
  * NISSAN
 */
tbool clHSA_SXM_Base::blGetSXMDataServiveListStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM::blGetSXMDataServiveListStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMDataServiceCCAState
  * API to know status of the CCA service for each data service.
  * NISSAN
 */
ulword clHSA_SXM_Base::ulwGetSXMDataServiceCCAState(ulword ulwServiceType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwServiceType);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_SXM::ulwGetSXMDataServiceCCAState not implemented"));
   return 0;
}

