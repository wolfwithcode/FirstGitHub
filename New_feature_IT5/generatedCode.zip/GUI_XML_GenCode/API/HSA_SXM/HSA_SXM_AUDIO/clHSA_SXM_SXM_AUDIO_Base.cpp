/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_SXM_SXM_AUDIO_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_SXM/HSA_SXM_AUDIO/clHSA_SXM_SXM_AUDIO_Base.h"

clHSA_SXM_SXM_AUDIO_Base* clHSA_SXM_SXM_AUDIO_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_SXM_SXM_AUDIO_Base.cpp.trc.h"
#endif


/**
 * Method: vActivateSource
  *  Activates XM Radio source (source swith to XM ) 
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vActivateSource( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vActivateSource not implemented"));
   
}

/**
 * Method: blIsCategoryIconAvailable
  * Get the status of category icon display on HMI
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blIsCategoryIconAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blIsCategoryIconAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsChannelIconAvailable
  * Get the status of channel icon display on HMI
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blIsChannelIconAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blIsChannelIconAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsArtistIconAvailable
  * Get the status of artist icon display on HMI
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blIsArtistIconAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blIsArtistIconAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsTitleIconAvailable
  * Get the status of title icon display on HMI
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blIsTitleIconAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blIsTitleIconAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentChannelNumber
  * Get the Channel number of currently active XM audio Channel( varies from 0 ~ 255 )
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetCurrentChannelNumber( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetCurrentChannelNumber not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentArtistName
  * Get the artist name of currently active XM audio Channel
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vGetCurrentArtistName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vGetCurrentArtistName not implemented"));
   
}

/**
 * Method: vGetCurrentCategoryName
  * Get the name of the category of currently active XM audio Channel
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vGetCurrentCategoryName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vGetCurrentCategoryName not implemented"));
   
}

/**
 * Method: vGetCurrentChannelName
  * Get the channel name of currently active XM audio Channel
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vGetCurrentChannelName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vGetCurrentChannelName not implemented"));
   
}

/**
 * Method: vGetCurrentSongName
  * Get the song name of currently active XM audio Channel
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vGetCurrentSongName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vGetCurrentSongName not implemented"));
   
}

/**
 * Method: ulwGetCurrentPresetBank
  *  Returns the current active XM preset bank number
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetCurrentPresetBank( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetCurrentPresetBank not implemented"));
   return 0;
}

/**
 * Method: ulwGetActiveXMChannelPresetNr
  * Get the preset number from active preset bank on which the active XM Channel is saved(it is the auto compare value from tuner middleware). It returns -1  if station is not saved 
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetActiveXMChannelPresetNr( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetActiveXMChannelPresetNr not implemented"));
   return 0;
}

/**
 * Method: ulwGetXMAdvisoryMessage
  *  Returns the integer value corresponding to the current XM advisory message. Returns 0 if there is no advisory message
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetXMAdvisoryMessage( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetXMAdvisoryMessage not implemented"));
   return 0;
}

/**
 * Method: vXMRadioSelectChannelUp
  * Select next channel upwards to the given number of steps
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vXMRadioSelectChannelUp(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vXMRadioSelectChannelUp not implemented"));
   
}

/**
 * Method: vXMRadioSelectChannelDown
  * Select next channel downwards to the given number of steps
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vXMRadioSelectChannelDown(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vXMRadioSelectChannelDown not implemented"));
   
}

/**
 * Method: blWaitSyncForSelectChannel
  * Whether to wait for information or not.
  * NISSAN2.0
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blWaitSyncForSelectChannel( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blWaitSyncForSelectChannel not implemented"));
   return 0;
}

/**
 * Method: blGetSXMModuleInitState
  * Whether the SXM module is initialized or not.
  * NISSAN2.0
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blGetSXMModuleInitState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blGetSXMModuleInitState not implemented"));
   return 0;
}

/**
 * Method: ulwGetChannelListStatus
  * Get the status of channel list at API side
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetChannelListStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetChannelListStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetChannelListCount
  * Get the number of elements in the current XM Channel list
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetChannelListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetChannelListCount not implemented"));
   return 0;
}

/**
 * Method: ulwGetChannelListActiveChannelIndex
  * Get the index of active XM channel in the current channel list that has to be highlighted
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetChannelListActiveChannelIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetChannelListActiveChannelIndex not implemented"));
   return 0;
}

/**
 * Method: vGetChannelListElement
  * Get an element of the channel list. One element of the channel list consists of channel number , channel name, associated preset number and preset bank number ( preset number = -1 means there is no preset entry for the channel).
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vGetChannelListElement(GUI_String *out_result, ulword ulwIndex, ulword ulwElementType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwElementType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vGetChannelListElement not implemented"));
   
}

/**
 * Method: vSelectFromChannelList
  * Select a channel from the channel list
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vSelectFromChannelList(ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vSelectFromChannelList not implemented"));
   
}

/**
 * Method: blIsCategoryListAvailable
  * If there are zero elements in Category list then the soft key Category list will be grayed out (De-Activated). This API return the value to the Model to take a decision whether to Grey-out the Category list soft key or not.
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blIsCategoryListAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blIsCategoryListAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwGetCategoryListStatus
  * Get the status of category overview list at API side
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetCategoryListStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetCategoryListStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetCategoryListCount
  * Get the number of category elements in the current XM category list
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetCategoryListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetCategoryListCount not implemented"));
   return 0;
}

/**
 * Method: ulwGetCategoryListActiveCategoryIndex
  * Get the index of the currently playing channel's category information inorder to highlight the category list element
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetCategoryListActiveCategoryIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetCategoryListActiveCategoryIndex not implemented"));
   return 0;
}

/**
 * Method: vGetCategoryName
  * Get the category name of the requested index from the category list
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vGetCategoryName(GUI_String *out_result, ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vGetCategoryName not implemented"));
   
}

/**
 * Method: ulwGetNumberOfChannelsForCategory
  * Get the number of channel elements for a particular category
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetNumberOfChannelsForCategory(ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetNumberOfChannelsForCategory not implemented"));
   return 0;
}

/**
 * Method: ulwGetChannelListToCatStatus
  * Get the status of the channel list to a category at the API side
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetChannelListToCatStatus(ulword ulwCategoryIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCategoryIndex);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetChannelListToCatStatus not implemented"));
   return 0;
}

/**
 * Method: slwGetCategoryListActiveChannelIndex
  * Get the index of active XM channel in the channel list of user selected category
  * NISSAN
 */
slword clHSA_SXM_SXM_AUDIO_Base::slwGetCategoryListActiveChannelIndex( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_SXM_SXM_AUDIO::slwGetCategoryListActiveChannelIndex not implemented"));
   return 0;
}

/**
 * Method: vGetChannelElementFromCategory
  * Get a channel element of a catogory from the category list
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vGetChannelElementFromCategory(GUI_String *out_result, ulword ulwCategoryIndex, ulword ulwChannelIndex, ulword ulwElementType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCategoryIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwChannelIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwElementType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vGetChannelElementFromCategory not implemented"));
   
}

/**
 * Method: vSelectFromCategoryList
  * Select a channel from the category channel list
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vSelectFromCategoryList(ulword ulwCategoryIndex, ulword ulwChannelIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCategoryIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwChannelIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vSelectFromCategoryList not implemented"));
   
}

/**
 * Method: vTogglePresetBank
  *  Each call to this API toggles the preset bank between XM1 ~ XM2 ~ XM3 ~ XM1. 
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vTogglePresetBank( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vTogglePresetBank not implemented"));
   
}

/**
 * Method: vRecallPreset
  * Recall a preset channel from the current XM preset bank
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vRecallPreset(ulword ulwPresetNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPresetNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vRecallPreset not implemented"));
   
}

/**
 * Method: vStorePreset
  * Store current playing channel to the current preset bank
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vStorePreset(ulword ulwPresetNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPresetNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vStorePreset not implemented"));
   
}

/**
 * Method: vSeekPreset
  * Seek the preset position from current position and play the next preset channel.The seek is done for current preset bank
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vSeekPreset(ulword ulwDirection)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDirection);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vSeekPreset not implemented"));
   
}

/**
 * Method: vScrollChannelUp
  * Scroll the channel in upward direction
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vScrollChannelUp(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vScrollChannelUp not implemented"));
   
}

/**
 * Method: vScrollChannelDown
  * Scroll the channel in downward direction
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vScrollChannelDown(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vScrollChannelDown not implemented"));
   
}

/**
 * Method: vAbortChannelScroll
  * This API is called when the user escapes from channel scroll operation by pressing logical back button
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vAbortChannelScroll( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vAbortChannelScroll not implemented"));
   
}

/**
 * Method: ulwGetChannelScrollStatus
  *  Get the current status of channel scrolling(inactive/active)
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetChannelScrollStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetChannelScrollStatus not implemented"));
   return 0;
}

/**
 * Method: vIsCatModeActive
  * This API is used to check if the CAT mode is active.
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vIsCatModeActive(tbool blCatModeActive)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blCatModeActive);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vIsCatModeActive not implemented"));
   
}

/**
 * Method: vSeekCategoryUp
  * Seek category in upward direction. This API is used when the user triggers a logical CAT+.
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vSeekCategoryUp(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vSeekCategoryUp not implemented"));
   
}

/**
 * Method: vSeekCategoryDown
  * Seek category in downward direction. This API is used when the user triggers a logical CAT-.
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vSeekCategoryDown(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vSeekCategoryDown not implemented"));
   
}

/**
 * Method: vScrollCategoryUp
  * Scroll channel in upward direction across category. This API is used when the user is in CAT mode and triggers a logical rotary turn in right direction.
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vScrollCategoryUp(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vScrollCategoryUp not implemented"));
   
}

/**
 * Method: vScrollCategoryDown
  * Scroll channel in upward direction across category. This API is used when the user is in CAT mode and triggers a logical rotary turn in left direction.
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vScrollCategoryDown(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vScrollCategoryDown not implemented"));
   
}

/**
 * Method: vSeekCategoryChannelUp
  * Seek channel in upward direction across category.This API is called when the SWC next is triggered while user is in CAT mode.
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vSeekCategoryChannelUp(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vSeekCategoryChannelUp not implemented"));
   
}

/**
 * Method: vSeekCategoryChannelDown
  * Seek channel in upward direction across category. This API is called when the SWC prev is triggered while user is in CAT mode.
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vSeekCategoryChannelDown(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vSeekCategoryChannelDown not implemented"));
   
}

/**
 * Method: vAbortCategorySearch
  * This API is called when the user escapes from category search operation by pressing logical escape/back button
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vAbortCategorySearch( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vAbortCategorySearch not implemented"));
   
}

/**
 * Method: ulwGetCategorySearchStatus
  *  Get the current status of category search operation(inactive/active)
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetCategorySearchStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetCategorySearchStatus not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentChannelNumberInString
  * Get the Channel number of currently active XM audio Channel( varies from 0 ~ 255 )
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vGetCurrentChannelNumberInString(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vGetCurrentChannelNumberInString not implemented"));
   
}

/**
 * Method: vLoadList
  * API to be called on entering the list screen
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vLoadList(ulword ulwListType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vLoadList not implemented"));
   
}

/**
 * Method: vLoadCatChanList
  * API to be called on entering the list screen
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vLoadCatChanList(ulword ulwCatChanListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCatChanListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vLoadCatChanList not implemented"));
   
}

/**
 * Method: ulwGetSXMDataServiceStatus
  *  Returns the integer value corresponding to the SXM Data Service Status
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetSXMDataServiceStatus(ulword ulwDataService)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDataService);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetSXMDataServiceStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetXMMode
  * Get Mode of XM Screen - API to be used when to check in which mode XM main screen should be activated
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetXMMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetXMMode not implemented"));
   return 0;
}

/**
 * Method: vSetXMMode
  * API to be called to set/activate LIVE/REPLAY Mode
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vSetXMMode(ulword ulwXMMOde)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwXMMOde);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vSetXMMode not implemented"));
   
}

/**
 * Method: blGetSeekBackSKStatus
  * Get Status SEEK BACK Soft Key display Status
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blGetSeekBackSKStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blGetSeekBackSKStatus not implemented"));
   return 0;
}

/**
 * Method: blGetSeekForwardSKStatus
  * Get Status SEEK FORWARD Soft Key display Status
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blGetSeekForwardSKStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blGetSeekForwardSKStatus not implemented"));
   return 0;
}

/**
 * Method: blGetPlayPauseSKStatus
  * Get Status PLAY/PAUSE Soft Key display Status
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blGetPlayPauseSKStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blGetPlayPauseSKStatus not implemented"));
   return 0;
}

/**
 * Method: blGetReplaySKStatus
  * Get REPLAY Soft Key display Status
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blGetReplaySKStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blGetReplaySKStatus not implemented"));
   return 0;
}

/**
 * Method: blGetExitSKStatus
  * Get Status of EXIT Soft Key display Status
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blGetExitSKStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blGetExitSKStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetReplayMode
  * Get Mode of Replay MOde for Text Display - API shall be called when a event triggered that Replay Text has changed
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetReplayMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetReplayMode not implemented"));
   return 0;
}

/**
 * Method: vGetTimeToLiveInMin
  * Get Time to live data in Minutes
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vGetTimeToLiveInMin(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vGetTimeToLiveInMin not implemented"));
   
}

/**
 * Method: vGetTimeToLiveInSec
  * Get Time to live data in Seconds
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vGetTimeToLiveInSec(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vGetTimeToLiveInSec not implemented"));
   
}

/**
 * Method: blGetPresetSFStatus
  * API to be called to display SF icon on each preset when XM Main screen activates
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blGetPresetSFStatus(ulword ulwPresetIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPresetIndex);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blGetPresetSFStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetPlaybackState
  * Get Current playback state.
  * NISSAN
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetPlaybackState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetPlaybackState not implemented"));
   return 0;
}

/**
 * Method: vSetInstantReplayControl
  * API to be called to set/activate Instant Replay Controls(defined below) action
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vSetInstantReplayControl(ulword ulwIRControls)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIRControls);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vSetInstantReplayControl not implemented"));
   
}

/**
 * Method: blGetTuneStartStatus
  * Get Status of Tune Start
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blGetTuneStartStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blGetTuneStartStatus not implemented"));
   return 0;
}

/**
 * Method: blWaitSyncForReplaySetup
  * Whether to wait for information or not.
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blWaitSyncForReplaySetup( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blWaitSyncForReplaySetup not implemented"));
   return 0;
}

/**
 * Method: vRequestToGetSFList
  * Request to Get Smart Favorite List
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vRequestToGetSFList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vRequestToGetSFList not implemented"));
   
}

/**
 * Method: vGetSFList
  * Get information of Smart Favorites
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vGetSFList(GUI_String *out_result, ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vGetSFList not implemented"));
   
}

/**
 * Method: blGetAddPresetSKStatus
  * TO Enable/Disable Add Preset button on Smart Favorite List
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blGetAddPresetSKStatus(ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blGetAddPresetSKStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetSFCount
  * Returns the number of Presets in Smart Favorite List
  * NISSAN2.0
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetSFCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetSFCount not implemented"));
   return 0;
}

/**
 * Method: ulwGetPRESETSFCount
  * Returns the number of Presets 
  * NISSAN2.0
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetPRESETSFCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetPRESETSFCount not implemented"));
   return 0;
}

/**
 * Method: ulwGetNonSFCount
  * Returns the number of Presets Not in Smart Favorite List
  * NISSAN2.0
 */
ulword clHSA_SXM_SXM_AUDIO_Base::ulwGetNonSFCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_AUDIO::ulwGetNonSFCount not implemented"));
   return 0;
}

/**
 * Method: blGetAudioBeepPlayStatus
  * TO Play Audio Beep when SEEK or SKIP of FWD and BACK Buttons not possible on user action
  * NISSAN
 */
tbool clHSA_SXM_SXM_AUDIO_Base::blGetAudioBeepPlayStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SXM_AUDIO::blGetAudioBeepPlayStatus not implemented"));
   return 0;
}

/**
 * Method: vRequestToGetNonSFList
  * Request to Get Non Smart Favorite List
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vRequestToGetNonSFList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vRequestToGetNonSFList not implemented"));
   
}

/**
 * Method: vGetNonSFList
  * Get information of Non Smart Favorites
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vGetNonSFList(GUI_String *out_result, ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vGetNonSFList not implemented"));
   
}

/**
 * Method: vSetSFOperation
  * API to be called to perform Add/Remove operation on SF list
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vSetSFOperation(ulword ulwSFOpeartion, ulword ulwPresetIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSFOpeartion);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPresetIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vSetSFOperation not implemented"));
   
}

/**
 * Method: vSetTuneStartStatus
  * API to be called to Enable/Disable tune start functionality
  * NISSAN
 */
void clHSA_SXM_SXM_AUDIO_Base::vSetTuneStartStatus(tbool blIRControls)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blIRControls);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SXM_AUDIO::vSetTuneStartStatus not implemented"));
   
}

