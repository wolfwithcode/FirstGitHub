/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_SXM_SXM_AUDIO_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_SXM_SXM_AUDIO_Base_H
#define _clHSA_SXM_SXM_AUDIO_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_SXM_SXM_AUDIO_Base : public clHSA_Base
{
public:

    static clHSA_SXM_SXM_AUDIO_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_SXM_SXM_AUDIO_Base()        {}

    virtual void vActivateSource( );

    virtual tbool blIsCategoryIconAvailable( );

    virtual tbool blIsChannelIconAvailable( );

    virtual tbool blIsArtistIconAvailable( );

    virtual tbool blIsTitleIconAvailable( );

    virtual ulword ulwGetCurrentChannelNumber( );

    virtual void vGetCurrentArtistName(GUI_String *out_result);

    virtual void vGetCurrentCategoryName(GUI_String *out_result);

    virtual void vGetCurrentChannelName(GUI_String *out_result);

    virtual void vGetCurrentSongName(GUI_String *out_result);

    virtual ulword ulwGetCurrentPresetBank( );

    virtual ulword ulwGetActiveXMChannelPresetNr( );

    virtual ulword ulwGetXMAdvisoryMessage( );

    virtual void vXMRadioSelectChannelUp(ulword ulwNoOfSteps);

    virtual void vXMRadioSelectChannelDown(ulword ulwNoOfSteps);

    virtual tbool blWaitSyncForSelectChannel( );

    virtual tbool blGetSXMModuleInitState( );

    virtual ulword ulwGetChannelListStatus( );

    virtual ulword ulwGetChannelListCount( );

    virtual ulword ulwGetChannelListActiveChannelIndex( );

    virtual void vGetChannelListElement(GUI_String *out_result, ulword ulwIndex, ulword ulwElementType);

    virtual void vSelectFromChannelList(ulword ulwIndex);

    virtual tbool blIsCategoryListAvailable( );

    virtual ulword ulwGetCategoryListStatus( );

    virtual ulword ulwGetCategoryListCount( );

    virtual ulword ulwGetCategoryListActiveCategoryIndex( );

    virtual void vGetCategoryName(GUI_String *out_result, ulword ulwIndex);

    virtual ulword ulwGetNumberOfChannelsForCategory(ulword ulwIndex);

    virtual ulword ulwGetChannelListToCatStatus(ulword ulwCategoryIndex);

    virtual slword slwGetCategoryListActiveChannelIndex( );

    virtual void vGetChannelElementFromCategory(GUI_String *out_result, ulword ulwCategoryIndex, ulword ulwChannelIndex, ulword ulwElementType);

    virtual void vSelectFromCategoryList(ulword ulwCategoryIndex, ulword ulwChannelIndex);

    virtual void vTogglePresetBank( );

    virtual void vRecallPreset(ulword ulwPresetNr);

    virtual void vStorePreset(ulword ulwPresetNr);

    virtual void vSeekPreset(ulword ulwDirection);

    virtual void vScrollChannelUp(ulword ulwNoOfSteps);

    virtual void vScrollChannelDown(ulword ulwNoOfSteps);

    virtual void vAbortChannelScroll( );

    virtual ulword ulwGetChannelScrollStatus( );

    virtual void vIsCatModeActive(tbool blCatModeActive);

    virtual void vSeekCategoryUp(ulword ulwNoOfSteps);

    virtual void vSeekCategoryDown(ulword ulwNoOfSteps);

    virtual void vScrollCategoryUp(ulword ulwNoOfSteps);

    virtual void vScrollCategoryDown(ulword ulwNoOfSteps);

    virtual void vSeekCategoryChannelUp(ulword ulwNoOfSteps);

    virtual void vSeekCategoryChannelDown(ulword ulwNoOfSteps);

    virtual void vAbortCategorySearch( );

    virtual ulword ulwGetCategorySearchStatus( );

    virtual void vGetCurrentChannelNumberInString(GUI_String *out_result);

    virtual void vLoadList(ulword ulwListType);

    virtual void vLoadCatChanList(ulword ulwCatChanListIndex);

    virtual ulword ulwGetSXMDataServiceStatus(ulword ulwDataService);

    virtual ulword ulwGetXMMode( );

    virtual void vSetXMMode(ulword ulwXMMOde);

    virtual tbool blGetSeekBackSKStatus( );

    virtual tbool blGetSeekForwardSKStatus( );

    virtual tbool blGetPlayPauseSKStatus( );

    virtual tbool blGetReplaySKStatus( );

    virtual tbool blGetExitSKStatus( );

    virtual ulword ulwGetReplayMode( );

    virtual void vGetTimeToLiveInMin(GUI_String *out_result);

    virtual void vGetTimeToLiveInSec(GUI_String *out_result);

    virtual tbool blGetPresetSFStatus(ulword ulwPresetIndex);

    virtual ulword ulwGetPlaybackState( );

    virtual void vSetInstantReplayControl(ulword ulwIRControls);

    virtual tbool blGetTuneStartStatus( );

    virtual tbool blWaitSyncForReplaySetup( );

    virtual void vRequestToGetSFList( );

    virtual void vGetSFList(GUI_String *out_result, ulword ulwIndex);

    virtual tbool blGetAddPresetSKStatus(ulword ulwIndex);

    virtual ulword ulwGetSFCount( );

    virtual ulword ulwGetPRESETSFCount( );

    virtual ulword ulwGetNonSFCount( );

    virtual tbool blGetAudioBeepPlayStatus( );

    virtual void vRequestToGetNonSFList( );

    virtual void vGetNonSFList(GUI_String *out_result, ulword ulwIndex);

    virtual void vSetSFOperation(ulword ulwSFOpeartion, ulword ulwPresetIndex);

    virtual void vSetTuneStartStatus(tbool blIRControls);

protected:
    clHSA_SXM_SXM_AUDIO_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_SXM_SXM_AUDIO_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_SXM_SXM_AUDIO_Base_H

