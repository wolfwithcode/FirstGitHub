/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_SXM_AUDIO_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_SXM_SXM_AUDIO_Wrapper_H
#define _HSA_SXM_SXM_AUDIO_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: ActivateSource
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vActivateSource( void);

/**
 * Function: IsCategoryIconAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blIsCategoryIconAvailable( void);

/**
 * Function: IsChannelIconAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blIsChannelIconAvailable( void);

/**
 * Function: IsArtistIconAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blIsArtistIconAvailable( void);

/**
 * Function: IsTitleIconAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blIsTitleIconAvailable( void);

/**
 * Function: GetCurrentChannelNumber
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetCurrentChannelNumber( void);

/**
 * Function: GetCurrentArtistName
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vGetCurrentArtistName(GUI_String *out_result);

/**
 * Function: GetCurrentCategoryName
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vGetCurrentCategoryName(GUI_String *out_result);

/**
 * Function: GetCurrentChannelName
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vGetCurrentChannelName(GUI_String *out_result);

/**
 * Function: GetCurrentSongName
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vGetCurrentSongName(GUI_String *out_result);

/**
 * Function: GetCurrentPresetBank
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetCurrentPresetBank( void);

/**
 * Function: GetActiveXMChannelPresetNr
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetActiveXMChannelPresetNr( void);

/**
 * Function: GetXMAdvisoryMessage
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetXMAdvisoryMessage( void);

/**
 * Function: XMRadioSelectChannelUp
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vXMRadioSelectChannelUp(ulword ulwNoOfSteps);

/**
 * Function: XMRadioSelectChannelDown
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vXMRadioSelectChannelDown(ulword ulwNoOfSteps);

/**
 * Function: WaitSyncForSelectChannel
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blWaitSyncForSelectChannel( void);

/**
 * Function: GetSXMModuleInitState
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blGetSXMModuleInitState( void);

/**
 * Function: GetChannelListStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetChannelListStatus( void);

/**
 * Function: GetChannelListCount
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetChannelListCount( void);

/**
 * Function: GetChannelListActiveChannelIndex
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetChannelListActiveChannelIndex( void);

/**
 * Function: GetChannelListElement
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vGetChannelListElement(GUI_String *out_result, ulword ulwIndex, ulword ulwElementType);

/**
 * Function: SelectFromChannelList
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vSelectFromChannelList(ulword ulwIndex);

/**
 * Function: IsCategoryListAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blIsCategoryListAvailable( void);

/**
 * Function: GetCategoryListStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetCategoryListStatus( void);

/**
 * Function: GetCategoryListCount
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetCategoryListCount( void);

/**
 * Function: GetCategoryListActiveCategoryIndex
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetCategoryListActiveCategoryIndex( void);

/**
 * Function: GetCategoryName
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vGetCategoryName(GUI_String *out_result, ulword ulwIndex);

/**
 * Function: GetNumberOfChannelsForCategory
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetNumberOfChannelsForCategory(ulword ulwIndex);

/**
 * Function: GetChannelListToCatStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetChannelListToCatStatus(ulword ulwCategoryIndex);

/**
 * Function: GetCategoryListActiveChannelIndex
 * NISSAN
 * NISSAN
 */
slword HSA_SXM_SXM_AUDIO__slwGetCategoryListActiveChannelIndex( void);

/**
 * Function: GetChannelElementFromCategory
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vGetChannelElementFromCategory(GUI_String *out_result, ulword ulwCategoryIndex, ulword ulwChannelIndex, ulword ulwElementType);

/**
 * Function: SelectFromCategoryList
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vSelectFromCategoryList(ulword ulwCategoryIndex, ulword ulwChannelIndex);

/**
 * Function: TogglePresetBank
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vTogglePresetBank( void);

/**
 * Function: RecallPreset
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vRecallPreset(ulword ulwPresetNr);

/**
 * Function: StorePreset
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vStorePreset(ulword ulwPresetNr);

/**
 * Function: SeekPreset
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vSeekPreset(ulword ulwDirection);

/**
 * Function: ScrollChannelUp
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vScrollChannelUp(ulword ulwNoOfSteps);

/**
 * Function: ScrollChannelDown
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vScrollChannelDown(ulword ulwNoOfSteps);

/**
 * Function: AbortChannelScroll
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vAbortChannelScroll( void);

/**
 * Function: GetChannelScrollStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetChannelScrollStatus( void);

/**
 * Function: IsCatModeActive
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vIsCatModeActive(tbool blCatModeActive);

/**
 * Function: SeekCategoryUp
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vSeekCategoryUp(ulword ulwNoOfSteps);

/**
 * Function: SeekCategoryDown
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vSeekCategoryDown(ulword ulwNoOfSteps);

/**
 * Function: ScrollCategoryUp
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vScrollCategoryUp(ulword ulwNoOfSteps);

/**
 * Function: ScrollCategoryDown
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vScrollCategoryDown(ulword ulwNoOfSteps);

/**
 * Function: SeekCategoryChannelUp
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vSeekCategoryChannelUp(ulword ulwNoOfSteps);

/**
 * Function: SeekCategoryChannelDown
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vSeekCategoryChannelDown(ulword ulwNoOfSteps);

/**
 * Function: AbortCategorySearch
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vAbortCategorySearch( void);

/**
 * Function: GetCategorySearchStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetCategorySearchStatus( void);

/**
 * Function: GetCurrentChannelNumberInString
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vGetCurrentChannelNumberInString(GUI_String *out_result);

/**
 * Function: LoadList
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vLoadList(ulword ulwListType);

/**
 * Function: LoadCatChanList
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vLoadCatChanList(ulword ulwCatChanListIndex);

/**
 * Function: GetSXMDataServiceStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetSXMDataServiceStatus(ulword ulwDataService);

/**
 * Function: GetXMMode
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetXMMode( void);

/**
 * Function: SetXMMode
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vSetXMMode(ulword ulwXMMOde);

/**
 * Function: GetSeekBackSKStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blGetSeekBackSKStatus( void);

/**
 * Function: GetSeekForwardSKStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blGetSeekForwardSKStatus( void);

/**
 * Function: GetPlayPauseSKStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blGetPlayPauseSKStatus( void);

/**
 * Function: GetReplaySKStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blGetReplaySKStatus( void);

/**
 * Function: GetExitSKStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blGetExitSKStatus( void);

/**
 * Function: GetReplayMode
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetReplayMode( void);

/**
 * Function: GetTimeToLiveInMin
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vGetTimeToLiveInMin(GUI_String *out_result);

/**
 * Function: GetTimeToLiveInSec
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vGetTimeToLiveInSec(GUI_String *out_result);

/**
 * Function: GetPresetSFStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blGetPresetSFStatus(ulword ulwPresetIndex);

/**
 * Function: GetPlaybackState
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetPlaybackState( void);

/**
 * Function: SetInstantReplayControl
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vSetInstantReplayControl(ulword ulwIRControls);

/**
 * Function: GetTuneStartStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blGetTuneStartStatus( void);

/**
 * Function: WaitSyncForReplaySetup
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blWaitSyncForReplaySetup( void);

/**
 * Function: RequestToGetSFList
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vRequestToGetSFList( void);

/**
 * Function: GetSFList
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vGetSFList(GUI_String *out_result, ulword ulwIndex);

/**
 * Function: GetAddPresetSKStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blGetAddPresetSKStatus(ulword ulwIndex);

/**
 * Function: GetSFCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetSFCount( void);

/**
 * Function: GetPRESETSFCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetPRESETSFCount( void);

/**
 * Function: GetNonSFCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SXM_AUDIO__ulwGetNonSFCount( void);

/**
 * Function: GetAudioBeepPlayStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_SXM_SXM_AUDIO__blGetAudioBeepPlayStatus( void);

/**
 * Function: RequestToGetNonSFList
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vRequestToGetNonSFList( void);

/**
 * Function: GetNonSFList
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vGetNonSFList(GUI_String *out_result, ulword ulwIndex);

/**
 * Function: SetSFOperation
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vSetSFOperation(ulword ulwSFOpeartion, ulword ulwPresetIndex);

/**
 * Function: SetTuneStartStatus
 * NISSAN
 * NISSAN
 */
void HSA_SXM_SXM_AUDIO__vSetTuneStartStatus(tbool blIRControls);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_SXM_SXM_AUDIO_H

