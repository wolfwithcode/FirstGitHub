/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_SXM_AUDIO_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_SXM_SXM_AUDIO_Wrapper_dbg.h"
#include "clHSA_SXM_SXM_AUDIO_Base.h"
#include "HSA_SXM_SXM_AUDIO_Trace.h"
#include "HSA_SXM_SXM_AUDIO_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_SXM_SXM_AUDIO_Wrapper_dbg::~clHSA_SXM_SXM_AUDIO_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_SXM_SXM_AUDIO_Wrapper_dbg::clHSA_SXM_SXM_AUDIO_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_SXM_SXM_AUDIO_Wrapper_dbg::clHSA_SXM_SXM_AUDIO_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_SXM_SXM_AUDIO_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_SXM_SXM_AUDIO_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__ACTIVATE_SOURCE:

            HSA_SXM_SXM_AUDIO__vActivateSource();
            break;

        case HSA_API_ENTRYPOINT__IS_CATEGORY_ICON_AVAILABLE:

            HSA_SXM_SXM_AUDIO__blIsCategoryIconAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_CHANNEL_ICON_AVAILABLE:

            HSA_SXM_SXM_AUDIO__blIsChannelIconAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_ARTIST_ICON_AVAILABLE:

            HSA_SXM_SXM_AUDIO__blIsArtistIconAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_TITLE_ICON_AVAILABLE:

            HSA_SXM_SXM_AUDIO__blIsTitleIconAvailable();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NUMBER:

            HSA_SXM_SXM_AUDIO__ulwGetCurrentChannelNumber();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_ARTIST_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SXM_AUDIO__vGetCurrentArtistName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_CATEGORY_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SXM_AUDIO__vGetCurrentCategoryName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SXM_AUDIO__vGetCurrentChannelName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_SONG_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SXM_AUDIO__vGetCurrentSongName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_PRESET_BANK:

            HSA_SXM_SXM_AUDIO__ulwGetCurrentPresetBank();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_XM_CHANNEL_PRESET_NR:

            HSA_SXM_SXM_AUDIO__ulwGetActiveXMChannelPresetNr();
            break;

        case HSA_API_ENTRYPOINT__GET_XM_ADVISORY_MESSAGE:

            HSA_SXM_SXM_AUDIO__ulwGetXMAdvisoryMessage();
            break;

        case HSA_API_ENTRYPOINT__XM_RADIO_SELECT_CHANNEL_UP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vXMRadioSelectChannelUp(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__XM_RADIO_SELECT_CHANNEL_DOWN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vXMRadioSelectChannelDown(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_SELECT_CHANNEL:

            HSA_SXM_SXM_AUDIO__blWaitSyncForSelectChannel();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_MODULE_INIT_STATE:

            HSA_SXM_SXM_AUDIO__blGetSXMModuleInitState();
            break;

        case HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_STATUS:

            HSA_SXM_SXM_AUDIO__ulwGetChannelListStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_COUNT:

            HSA_SXM_SXM_AUDIO__ulwGetChannelListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_ACTIVE_CHANNEL_INDEX:

            HSA_SXM_SXM_AUDIO__ulwGetChannelListActiveChannelIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_ELEMENT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_SXM_AUDIO__vGetChannelListElement(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__SELECT_FROM_CHANNEL_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vSelectFromChannelList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_CATEGORY_LIST_AVAILABLE:

            HSA_SXM_SXM_AUDIO__blIsCategoryListAvailable();
            break;

        case HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_STATUS:

            HSA_SXM_SXM_AUDIO__ulwGetCategoryListStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_COUNT:

            HSA_SXM_SXM_AUDIO__ulwGetCategoryListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_ACTIVE_CATEGORY_INDEX:

            HSA_SXM_SXM_AUDIO__ulwGetCategoryListActiveCategoryIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_CATEGORY_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SXM_AUDIO__vGetCategoryName(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_NUMBER_OF_CHANNELS_FOR_CATEGORY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__ulwGetNumberOfChannelsForCategory(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_TO_CAT_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__ulwGetChannelListToCatStatus(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_ACTIVE_CHANNEL_INDEX:

            HSA_SXM_SXM_AUDIO__slwGetCategoryListActiveChannelIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_CHANNEL_ELEMENT_FROM_CATEGORY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam4); 

            HSA_SXM_SXM_AUDIO__vGetChannelElementFromCategory(&gsParam1, ulParam2, ulParam3, ulParam4);
            break;

        case HSA_API_ENTRYPOINT__SELECT_FROM_CATEGORY_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SXM_AUDIO__vSelectFromCategoryList(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_PRESET_BANK:

            HSA_SXM_SXM_AUDIO__vTogglePresetBank();
            break;

        case HSA_API_ENTRYPOINT__RECALL_PRESET:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vRecallPreset(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__STORE_PRESET:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vStorePreset(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SEEK_PRESET:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vSeekPreset(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SCROLL_CHANNEL_UP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vScrollChannelUp(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SCROLL_CHANNEL_DOWN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vScrollChannelDown(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ABORT_CHANNEL_SCROLL:

            HSA_SXM_SXM_AUDIO__vAbortChannelScroll();
            break;

        case HSA_API_ENTRYPOINT__GET_CHANNEL_SCROLL_STATUS:

            HSA_SXM_SXM_AUDIO__ulwGetChannelScrollStatus();
            break;

        case HSA_API_ENTRYPOINT__IS_CAT_MODE_ACTIVE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_SXM_SXM_AUDIO__vIsCatModeActive(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SEEK_CATEGORY_UP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vSeekCategoryUp(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SEEK_CATEGORY_DOWN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vSeekCategoryDown(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SCROLL_CATEGORY_UP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vScrollCategoryUp(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SCROLL_CATEGORY_DOWN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vScrollCategoryDown(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SEEK_CATEGORY_CHANNEL_UP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vSeekCategoryChannelUp(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SEEK_CATEGORY_CHANNEL_DOWN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vSeekCategoryChannelDown(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ABORT_CATEGORY_SEARCH:

            HSA_SXM_SXM_AUDIO__vAbortCategorySearch();
            break;

        case HSA_API_ENTRYPOINT__GET_CATEGORY_SEARCH_STATUS:

            HSA_SXM_SXM_AUDIO__ulwGetCategorySearchStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NUMBER_IN_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SXM_AUDIO__vGetCurrentChannelNumberInString(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__LOAD_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vLoadList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__LOAD_CAT_CHAN_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vLoadCatChanList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_DATA_SERVICE_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__ulwGetSXMDataServiceStatus(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_XM_MODE:

            HSA_SXM_SXM_AUDIO__ulwGetXMMode();
            break;

        case HSA_API_ENTRYPOINT__SET_XM_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vSetXMMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SEEK_BACK_SK_STATUS:

            HSA_SXM_SXM_AUDIO__blGetSeekBackSKStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_SEEK_FORWARD_SK_STATUS:

            HSA_SXM_SXM_AUDIO__blGetSeekForwardSKStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_PLAY_PAUSE_SK_STATUS:

            HSA_SXM_SXM_AUDIO__blGetPlayPauseSKStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_REPLAY_SK_STATUS:

            HSA_SXM_SXM_AUDIO__blGetReplaySKStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_EXIT_SK_STATUS:

            HSA_SXM_SXM_AUDIO__blGetExitSKStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_REPLAY_MODE:

            HSA_SXM_SXM_AUDIO__ulwGetReplayMode();
            break;

        case HSA_API_ENTRYPOINT__GET_TIME_TO_LIVE_IN_MIN:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SXM_AUDIO__vGetTimeToLiveInMin(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TIME_TO_LIVE_IN_SEC:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SXM_AUDIO__vGetTimeToLiveInSec(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_PRESET_SF_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__blGetPresetSFStatus(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_PLAYBACK_STATE:

            HSA_SXM_SXM_AUDIO__ulwGetPlaybackState();
            break;

        case HSA_API_ENTRYPOINT__SET_INSTANT_REPLAY_CONTROL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__vSetInstantReplayControl(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNE_START_STATUS:

            HSA_SXM_SXM_AUDIO__blGetTuneStartStatus();
            break;

        case HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_REPLAY_SETUP:

            HSA_SXM_SXM_AUDIO__blWaitSyncForReplaySetup();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_SF_LIST:

            HSA_SXM_SXM_AUDIO__vRequestToGetSFList();
            break;

        case HSA_API_ENTRYPOINT__GET_SF_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SXM_AUDIO__vGetSFList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_ADD_PRESET_SK_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SXM_AUDIO__blGetAddPresetSKStatus(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SF_COUNT:

            HSA_SXM_SXM_AUDIO__ulwGetSFCount();
            break;

        case HSA_API_ENTRYPOINT__GET_PRESETSF_COUNT:

            HSA_SXM_SXM_AUDIO__ulwGetPRESETSFCount();
            break;

        case HSA_API_ENTRYPOINT__GET_NON_SF_COUNT:

            HSA_SXM_SXM_AUDIO__ulwGetNonSFCount();
            break;

        case HSA_API_ENTRYPOINT__GET_AUDIO_BEEP_PLAY_STATUS:

            HSA_SXM_SXM_AUDIO__blGetAudioBeepPlayStatus();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_NON_SF_LIST:

            HSA_SXM_SXM_AUDIO__vRequestToGetNonSFList();
            break;

        case HSA_API_ENTRYPOINT__GET_NON_SF_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SXM_AUDIO__vGetNonSFList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_SF_OPERATION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SXM_AUDIO__vSetSFOperation(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_TUNE_START_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_SXM_SXM_AUDIO__vSetTuneStartStatus(usParam1);
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

