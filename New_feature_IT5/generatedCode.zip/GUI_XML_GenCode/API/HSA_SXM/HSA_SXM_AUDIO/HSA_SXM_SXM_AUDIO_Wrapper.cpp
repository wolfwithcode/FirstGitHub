/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_SXM_AUDIO_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_SXM_SXM_AUDIO_Wrapper.h"
#include "clHSA_SXM_SXM_AUDIO_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_SXM_SXM_AUDIO_Trace.h"
#include "hmi_trace.h"

void HSA_SXM_SXM_AUDIO__vActivateSource( )
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_SOURCE  ) ); 
        }
      pInst->vActivateSource();

    }
}

tbool HSA_SXM_SXM_AUDIO__blIsCategoryIconAvailable( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CATEGORY_ICON_AVAILABLE  ) ); 
        }
      ret=pInst->blIsCategoryIconAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CATEGORY_ICON_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_SXM_AUDIO__blIsChannelIconAvailable( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CHANNEL_ICON_AVAILABLE  ) ); 
        }
      ret=pInst->blIsChannelIconAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CHANNEL_ICON_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_SXM_AUDIO__blIsArtistIconAvailable( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_ARTIST_ICON_AVAILABLE  ) ); 
        }
      ret=pInst->blIsArtistIconAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_ARTIST_ICON_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_SXM_AUDIO__blIsTitleIconAvailable( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_TITLE_ICON_AVAILABLE  ) ); 
        }
      ret=pInst->blIsTitleIconAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_TITLE_ICON_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetCurrentChannelNumber( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NUMBER  ) ); 
        }
      ret=pInst->ulwGetCurrentChannelNumber();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NUMBER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SXM_AUDIO__vGetCurrentArtistName(GUI_String *out_result)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_ARTIST_NAME  ) ); 
        }
      pInst->vGetCurrentArtistName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_ARTIST_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SXM_AUDIO__vGetCurrentCategoryName(GUI_String *out_result)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CATEGORY_NAME  ) ); 
        }
      pInst->vGetCurrentCategoryName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CATEGORY_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SXM_AUDIO__vGetCurrentChannelName(GUI_String *out_result)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NAME  ) ); 
        }
      pInst->vGetCurrentChannelName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SXM_AUDIO__vGetCurrentSongName(GUI_String *out_result)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SONG_NAME  ) ); 
        }
      pInst->vGetCurrentSongName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SONG_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetCurrentPresetBank( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_PRESET_BANK  ) ); 
        }
      ret=pInst->ulwGetCurrentPresetBank();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_PRESET_BANK | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetActiveXMChannelPresetNr( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_XM_CHANNEL_PRESET_NR  ) ); 
        }
      ret=pInst->ulwGetActiveXMChannelPresetNr();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_XM_CHANNEL_PRESET_NR | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetXMAdvisoryMessage( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_ADVISORY_MESSAGE  ) ); 
        }
      ret=pInst->ulwGetXMAdvisoryMessage();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_ADVISORY_MESSAGE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SXM_AUDIO__vXMRadioSelectChannelUp(ulword ulwNoOfSteps)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__XM_RADIO_SELECT_CHANNEL_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vXMRadioSelectChannelUp(ulwNoOfSteps);

    }
}

void HSA_SXM_SXM_AUDIO__vXMRadioSelectChannelDown(ulword ulwNoOfSteps)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__XM_RADIO_SELECT_CHANNEL_DOWN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vXMRadioSelectChannelDown(ulwNoOfSteps);

    }
}

tbool HSA_SXM_SXM_AUDIO__blWaitSyncForSelectChannel( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_SELECT_CHANNEL  ) ); 
        }
      ret=pInst->blWaitSyncForSelectChannel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_SELECT_CHANNEL | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_SXM_AUDIO__blGetSXMModuleInitState( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_MODULE_INIT_STATE  ) ); 
        }
      ret=pInst->blGetSXMModuleInitState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_MODULE_INIT_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetChannelListStatus( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_STATUS  ) ); 
        }
      ret=pInst->ulwGetChannelListStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetChannelListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetChannelListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetChannelListActiveChannelIndex( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_ACTIVE_CHANNEL_INDEX  ) ); 
        }
      ret=pInst->ulwGetChannelListActiveChannelIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_ACTIVE_CHANNEL_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SXM_AUDIO__vGetChannelListElement(GUI_String *out_result, ulword ulwIndex, ulword ulwElementType)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_ELEMENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_ELEMENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwElementType); 
        }
      pInst->vGetChannelListElement(out_result, ulwIndex, ulwElementType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_ELEMENT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SXM_AUDIO__vSelectFromChannelList(ulword ulwIndex)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SELECT_FROM_CHANNEL_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vSelectFromChannelList(ulwIndex);

    }
}

tbool HSA_SXM_SXM_AUDIO__blIsCategoryListAvailable( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CATEGORY_LIST_AVAILABLE  ) ); 
        }
      ret=pInst->blIsCategoryListAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CATEGORY_LIST_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetCategoryListStatus( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_STATUS  ) ); 
        }
      ret=pInst->ulwGetCategoryListStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetCategoryListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetCategoryListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetCategoryListActiveCategoryIndex( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_ACTIVE_CATEGORY_INDEX  ) ); 
        }
      ret=pInst->ulwGetCategoryListActiveCategoryIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_ACTIVE_CATEGORY_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SXM_AUDIO__vGetCategoryName(GUI_String *out_result, ulword ulwIndex)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vGetCategoryName(out_result, ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetNumberOfChannelsForCategory(ulword ulwIndex)
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_NUMBER_OF_CHANNELS_FOR_CATEGORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      ret=pInst->ulwGetNumberOfChannelsForCategory(ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_NUMBER_OF_CHANNELS_FOR_CATEGORY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetChannelListToCatStatus(ulword ulwCategoryIndex)
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_TO_CAT_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCategoryIndex); 
        }
      ret=pInst->ulwGetChannelListToCatStatus(ulwCategoryIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_LIST_TO_CAT_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_SXM_SXM_AUDIO__slwGetCategoryListActiveChannelIndex( )
{
    slword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_ACTIVE_CHANNEL_INDEX  ) ); 
        }
      ret=pInst->slwGetCategoryListActiveChannelIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_LIST_ACTIVE_CHANNEL_INDEX | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SXM_AUDIO__vGetChannelElementFromCategory(GUI_String *out_result, ulword ulwCategoryIndex, ulword ulwChannelIndex, ulword ulwElementType)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_ELEMENT_FROM_CATEGORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCategoryIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_ELEMENT_FROM_CATEGORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwChannelIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_ELEMENT_FROM_CATEGORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwElementType); 
        }
      pInst->vGetChannelElementFromCategory(out_result, ulwCategoryIndex, ulwChannelIndex, ulwElementType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_ELEMENT_FROM_CATEGORY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SXM_AUDIO__vSelectFromCategoryList(ulword ulwCategoryIndex, ulword ulwChannelIndex)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SELECT_FROM_CATEGORY_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCategoryIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SELECT_FROM_CATEGORY_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwChannelIndex); 
        }
      pInst->vSelectFromCategoryList(ulwCategoryIndex, ulwChannelIndex);

    }
}

void HSA_SXM_SXM_AUDIO__vTogglePresetBank( )
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_PRESET_BANK  ) ); 
        }
      pInst->vTogglePresetBank();

    }
}

void HSA_SXM_SXM_AUDIO__vRecallPreset(ulword ulwPresetNr)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__RECALL_PRESET | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPresetNr); 
        }
      pInst->vRecallPreset(ulwPresetNr);

    }
}

void HSA_SXM_SXM_AUDIO__vStorePreset(ulword ulwPresetNr)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__STORE_PRESET | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPresetNr); 
        }
      pInst->vStorePreset(ulwPresetNr);

    }
}

void HSA_SXM_SXM_AUDIO__vSeekPreset(ulword ulwDirection)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_PRESET | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDirection); 
        }
      pInst->vSeekPreset(ulwDirection);

    }
}

void HSA_SXM_SXM_AUDIO__vScrollChannelUp(ulword ulwNoOfSteps)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SCROLL_CHANNEL_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vScrollChannelUp(ulwNoOfSteps);

    }
}

void HSA_SXM_SXM_AUDIO__vScrollChannelDown(ulword ulwNoOfSteps)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SCROLL_CHANNEL_DOWN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vScrollChannelDown(ulwNoOfSteps);

    }
}

void HSA_SXM_SXM_AUDIO__vAbortChannelScroll( )
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__ABORT_CHANNEL_SCROLL  ) ); 
        }
      pInst->vAbortChannelScroll();

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetChannelScrollStatus( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_SCROLL_STATUS  ) ); 
        }
      ret=pInst->ulwGetChannelScrollStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_SCROLL_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SXM_AUDIO__vIsCatModeActive(tbool blCatModeActive)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__IS_CAT_MODE_ACTIVE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blCatModeActive); 
        }
      pInst->vIsCatModeActive(blCatModeActive);

    }
}

void HSA_SXM_SXM_AUDIO__vSeekCategoryUp(ulword ulwNoOfSteps)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_CATEGORY_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vSeekCategoryUp(ulwNoOfSteps);

    }
}

void HSA_SXM_SXM_AUDIO__vSeekCategoryDown(ulword ulwNoOfSteps)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_CATEGORY_DOWN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vSeekCategoryDown(ulwNoOfSteps);

    }
}

void HSA_SXM_SXM_AUDIO__vScrollCategoryUp(ulword ulwNoOfSteps)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SCROLL_CATEGORY_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vScrollCategoryUp(ulwNoOfSteps);

    }
}

void HSA_SXM_SXM_AUDIO__vScrollCategoryDown(ulword ulwNoOfSteps)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SCROLL_CATEGORY_DOWN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vScrollCategoryDown(ulwNoOfSteps);

    }
}

void HSA_SXM_SXM_AUDIO__vSeekCategoryChannelUp(ulword ulwNoOfSteps)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_CATEGORY_CHANNEL_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vSeekCategoryChannelUp(ulwNoOfSteps);

    }
}

void HSA_SXM_SXM_AUDIO__vSeekCategoryChannelDown(ulword ulwNoOfSteps)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_CATEGORY_CHANNEL_DOWN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vSeekCategoryChannelDown(ulwNoOfSteps);

    }
}

void HSA_SXM_SXM_AUDIO__vAbortCategorySearch( )
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__ABORT_CATEGORY_SEARCH  ) ); 
        }
      pInst->vAbortCategorySearch();

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetCategorySearchStatus( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_SEARCH_STATUS  ) ); 
        }
      ret=pInst->ulwGetCategorySearchStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CATEGORY_SEARCH_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SXM_AUDIO__vGetCurrentChannelNumberInString(GUI_String *out_result)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NUMBER_IN_STRING  ) ); 
        }
      pInst->vGetCurrentChannelNumberInString(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_CHANNEL_NUMBER_IN_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SXM_AUDIO__vLoadList(ulword ulwListType)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__LOAD_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListType); 
        }
      pInst->vLoadList(ulwListType);

    }
}

void HSA_SXM_SXM_AUDIO__vLoadCatChanList(ulword ulwCatChanListIndex)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__LOAD_CAT_CHAN_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCatChanListIndex); 
        }
      pInst->vLoadCatChanList(ulwCatChanListIndex);

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetSXMDataServiceStatus(ulword ulwDataService)
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_DATA_SERVICE_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDataService); 
        }
      ret=pInst->ulwGetSXMDataServiceStatus(ulwDataService);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_DATA_SERVICE_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetXMMode( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_MODE  ) ); 
        }
      ret=pInst->ulwGetXMMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_XM_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SXM_AUDIO__vSetXMMode(ulword ulwXMMOde)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SET_XM_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwXMMOde); 
        }
      pInst->vSetXMMode(ulwXMMOde);

    }
}

tbool HSA_SXM_SXM_AUDIO__blGetSeekBackSKStatus( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_SEEK_BACK_SK_STATUS  ) ); 
        }
      ret=pInst->blGetSeekBackSKStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_SEEK_BACK_SK_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_SXM_AUDIO__blGetSeekForwardSKStatus( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_SEEK_FORWARD_SK_STATUS  ) ); 
        }
      ret=pInst->blGetSeekForwardSKStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_SEEK_FORWARD_SK_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_SXM_AUDIO__blGetPlayPauseSKStatus( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PLAY_PAUSE_SK_STATUS  ) ); 
        }
      ret=pInst->blGetPlayPauseSKStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PLAY_PAUSE_SK_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_SXM_AUDIO__blGetReplaySKStatus( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_REPLAY_SK_STATUS  ) ); 
        }
      ret=pInst->blGetReplaySKStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_REPLAY_SK_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_SXM_AUDIO__blGetExitSKStatus( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_EXIT_SK_STATUS  ) ); 
        }
      ret=pInst->blGetExitSKStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_EXIT_SK_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetReplayMode( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_REPLAY_MODE  ) ); 
        }
      ret=pInst->ulwGetReplayMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_REPLAY_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SXM_AUDIO__vGetTimeToLiveInMin(GUI_String *out_result)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_TO_LIVE_IN_MIN  ) ); 
        }
      pInst->vGetTimeToLiveInMin(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_TO_LIVE_IN_MIN | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SXM_AUDIO__vGetTimeToLiveInSec(GUI_String *out_result)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_TO_LIVE_IN_SEC  ) ); 
        }
      pInst->vGetTimeToLiveInSec(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_TO_LIVE_IN_SEC | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_SXM_SXM_AUDIO__blGetPresetSFStatus(ulword ulwPresetIndex)
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_SF_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPresetIndex); 
        }
      ret=pInst->blGetPresetSFStatus(ulwPresetIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_SF_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetPlaybackState( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PLAYBACK_STATE  ) ); 
        }
      ret=pInst->ulwGetPlaybackState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PLAYBACK_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SXM_AUDIO__vSetInstantReplayControl(ulword ulwIRControls)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SET_INSTANT_REPLAY_CONTROL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIRControls); 
        }
      pInst->vSetInstantReplayControl(ulwIRControls);

    }
}

tbool HSA_SXM_SXM_AUDIO__blGetTuneStartStatus( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_TUNE_START_STATUS  ) ); 
        }
      ret=pInst->blGetTuneStartStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_TUNE_START_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_SXM_AUDIO__blWaitSyncForReplaySetup( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_REPLAY_SETUP  ) ); 
        }
      ret=pInst->blWaitSyncForReplaySetup();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_REPLAY_SETUP | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SXM_AUDIO__vRequestToGetSFList( )
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_SF_LIST  ) ); 
        }
      pInst->vRequestToGetSFList();

    }
}

void HSA_SXM_SXM_AUDIO__vGetSFList(GUI_String *out_result, ulword ulwIndex)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_SF_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vGetSFList(out_result, ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_SF_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_SXM_SXM_AUDIO__blGetAddPresetSKStatus(ulword ulwIndex)
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ADD_PRESET_SK_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      ret=pInst->blGetAddPresetSKStatus(ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_ADD_PRESET_SK_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetSFCount( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_SF_COUNT  ) ); 
        }
      ret=pInst->ulwGetSFCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_SF_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetPRESETSFCount( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESETSF_COUNT  ) ); 
        }
      ret=pInst->ulwGetPRESETSFCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESETSF_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SXM_AUDIO__ulwGetNonSFCount( )
{
    ulword ret = 0;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_NON_SF_COUNT  ) ); 
        }
      ret=pInst->ulwGetNonSFCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_NON_SF_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_SXM_AUDIO__blGetAudioBeepPlayStatus( )
{
    tbool ret = false;
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_AUDIO_BEEP_PLAY_STATUS  ) ); 
        }
      ret=pInst->blGetAudioBeepPlayStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_AUDIO_BEEP_PLAY_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SXM_AUDIO__vRequestToGetNonSFList( )
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_NON_SF_LIST  ) ); 
        }
      pInst->vRequestToGetNonSFList();

    }
}

void HSA_SXM_SXM_AUDIO__vGetNonSFList(GUI_String *out_result, ulword ulwIndex)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_NON_SF_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vGetNonSFList(out_result, ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__GET_NON_SF_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SXM_AUDIO__vSetSFOperation(ulword ulwSFOpeartion, ulword ulwPresetIndex)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SET_SF_OPERATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSFOpeartion); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SET_SF_OPERATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPresetIndex); 
        }
      pInst->vSetSFOperation(ulwSFOpeartion, ulwPresetIndex);

    }
}

void HSA_SXM_SXM_AUDIO__vSetTuneStartStatus(tbool blIRControls)
{
    
    clHSA_SXM_SXM_AUDIO_Base *pInst=clHSA_SXM_SXM_AUDIO_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SXM_AUDIO), (tU16)(HSA_API_ENTRYPOINT__SET_TUNE_START_STATUS | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blIRControls); 
        }
      pInst->vSetTuneStartStatus(blIRControls);

    }
}

#ifdef __cplusplus
}
#endif

