/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_SXM_TRAFFIC_Trace.h
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
#ifndef _HSA_SXM_SXM_TRAFFIC_TRACE_H
#define _HSA_SXM_SXM_TRAFFIC_TRACE_H
 

/**** Trace defines for HSA_SXM_SXM_TRAFFIC ****/

#define HSA_API_ENTRYPOINT__GET_SUBSCRIPTION_STATUS 0x1

#endif  //#ifndef _HSA_SXM_SXM_TRAFFIC_TRACE_H

