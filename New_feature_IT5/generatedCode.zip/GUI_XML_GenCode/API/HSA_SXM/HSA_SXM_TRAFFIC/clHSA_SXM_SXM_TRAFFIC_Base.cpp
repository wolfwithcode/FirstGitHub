/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_SXM_SXM_TRAFFIC_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_SXM/HSA_SXM_TRAFFIC/clHSA_SXM_SXM_TRAFFIC_Base.h"

clHSA_SXM_SXM_TRAFFIC_Base* clHSA_SXM_SXM_TRAFFIC_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_SXM_SXM_TRAFFIC_Base.cpp.trc.h"
#endif


/**
 * Method: ulwGetSubscriptionStatus
  * Returns the status of traffic service
  * NISSAN2.0
 */
ulword clHSA_SXM_SXM_TRAFFIC_Base::ulwGetSubscriptionStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SXM_TRAFFIC::ulwGetSubscriptionStatus not implemented"));
   return 0;
}

