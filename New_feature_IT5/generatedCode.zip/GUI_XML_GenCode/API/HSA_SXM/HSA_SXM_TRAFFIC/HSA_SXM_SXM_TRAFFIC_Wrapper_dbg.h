/*<<< auto-generated file. Do not edit. >>>*/

/*
 *  FILE:         HSA_SXM_SXM_TRAFFIC_Wrapper_dbg.h
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_SXM_SXM_TRAFFIC_Wrapper_DBG_H
#define _HSA_SXM_SXM_TRAFFIC_Wrapper_DBG_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "clDebug.h"
#include "clITrace.h"


class clHSA_SXM_SXM_TRAFFIC_Wrapper_dbg : public clDebug
{
public:
   
   //Destructor
   virtual ~clHSA_SXM_SXM_TRAFFIC_Wrapper_dbg(); 
   
   /*default constructor*/
   clHSA_SXM_SXM_TRAFFIC_Wrapper_dbg();
   clHSA_SXM_SXM_TRAFFIC_Wrapper_dbg(void* v); 

   virtual tBool bExecDbgInput ( tU8 **pu8Stream);

   /** FW interfaces for init and general behaviour e.g. powertates */
   // init get trace pointer
   virtual tBool bConfigure( clITrace* poTrace );
   
protected:
   clITrace* m_poTrace;
};
#endif

