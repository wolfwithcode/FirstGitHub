/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_SPORTS_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_SXM_SPORTS_Wrapper_dbg.h"
#include "clHSA_SXM_SPORTS_Base.h"
#include "HSA_SXM_SPORTS_Trace.h"
#include "HSA_SXM_SPORTS_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_SXM_SPORTS_Wrapper_dbg::~clHSA_SXM_SPORTS_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_SXM_SPORTS_Wrapper_dbg::clHSA_SXM_SPORTS_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_SXM_SPORTS_Wrapper_dbg::clHSA_SXM_SPORTS_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_SXM_SPORTS_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_SXM_SPORTS_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_SPORTS:

            HSA_SXM_SPORTS__blWaitSyncForSports();
            break;

        case HSA_API_ENTRYPOINT__GET_SPORTS_SERVICE_STATE:

            HSA_SXM_SPORTS__blGetSportsServiceState();
            break;

        case HSA_API_ENTRYPOINT__GET_SPORTS_DATA_AVAILABILITY:

            HSA_SXM_SPORTS__ulwGetSportsDataAvailability();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_SPORTS_LIST:

            HSA_SXM_SPORTS__vRequestToGetSportsList();
            break;

        case HSA_API_ENTRYPOINT__GET_SPORTS_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetSportsListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_SPORTS_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SPORTS__vGetSportsList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_FAVORITE_SPORTS_LIST:

            HSA_SXM_SPORTS__vRequestToGetFavoriteSportsList();
            break;

        case HSA_API_ENTRYPOINT__GET_FAVORITE_SPORTS_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetFavoriteSportsListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_FAVORITE_SPORTS_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_SPORTS__vGetFavoriteSportsList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_TEAM_GAME_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SPORTS__vRequestToGetTeamGameList(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TEAM_GAME_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetTeamGameListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_TEAM_GAME_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_SPORTS__vGetTeamGameList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_LISTEN_BUTTON_VISIBILITY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__blGetListenButtonVisibility(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SEND_SELECTED_LIST_ENTRY_NR:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vSendSelectedListEntryNr(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_LEAGUE_SEASON_STATUS:

            HSA_SXM_SPORTS__ulwGetActiveLeagueSeasonStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_TEAM_GAME_DETAILS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SPORTS__vGetTeamGameDetails(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_VISIBILITY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__ulwGetVisibility(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TEAM_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SPORTS__vGetTeamName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_FAVORITE_CONTROL:

            HSA_SXM_SPORTS__vSetFavoriteControl();
            break;

        case HSA_API_ENTRYPOINT__REPLACE_TEAM_IN_FAVORITE_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vReplaceTeamInFavoriteList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_LISTEN:

            HSA_SXM_SPORTS__vRequestToListen();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_LISTEN_FRM_LIST_ENTRY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vRequestToListenFrmListEntry(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CHANNEL_COUNT:

            HSA_SXM_SPORTS__ulwGetChannelCount();
            break;

        case HSA_API_ENTRYPOINT__GET_CHANNEL_NAME:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__ulwGetChannelName(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CHANNEL_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SPORTS__vGetChannelNumber(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__LISTEN_SPORTS_CHANNEL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vListenSportsChannel(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_ROOT_AFFILIATE_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vRequestToGetRootAffiliateList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ROOT_AFFILIATE_SPORT_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SPORTS__vGetRootAffiliateSportName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ROOT_AFFILIATE_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetRootAffiliateListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_ROOT_AFFILIATE_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SPORTS__vGetRootAffiliateList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_AFFILIATE_DETAILS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vRequestToGetAffiliateDetails(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_AFFILIATE_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SPORTS__vGetCurrentAffiliateName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_AFFILIATE_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetAffiliateListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_AFFILIATE_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SPORTS__vGetAffiliateList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_AFFILIATE_LIST_VISIBILITY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__blGetAffiliateListVisibility(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_SPORT_INFO:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vRequestToGetSportInfo(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SCREEN_TYPE:

            HSA_SXM_SPORTS__ulwGetScreenType();
            break;

        case HSA_API_ENTRYPOINT__GET_AFFILIATE_SCREEN_TYPE:

            HSA_SXM_SPORTS__ulwGetAffiliateScreenType();
            break;

        case HSA_API_ENTRYPOINT__GET_PARRENT_AFFILIATE_LISTIDX:

            HSA_SXM_SPORTS__ulwGetParrentAffiliateListidx();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_CHILD_AFFILIATE_DETAILS:

            HSA_SXM_SPORTS__vRequestToGetChildAffiliateDetails();
            break;

        case HSA_API_ENTRYPOINT__GET_NEWS_DETAILS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SPORTS__vGetNewsDetails(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ALL_TEAMS_COUNT:

            HSA_SXM_SPORTS__ulwGetAllTeamsCount();
            break;

        case HSA_API_ENTRYPOINT__GET_ALL_TEAMS_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SPORTS__vGetAllTeamsList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TOP_TEAMS_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetTopTeamsListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_TOP_TEAMS_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SPORTS__vGetTopTeamsList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SCHEDULE_GAME_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetScheduleGameListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_SCHEDULE_GAME_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_SPORTS__vGetScheduleGameList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_SCHEDULE_GAME_DETAILS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SPORTS__vGetScheduleGameDetails(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_SCHEDULE_GAME_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vRequestToGetScheduleGameList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_EVENT_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetEventListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_EVENT_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_SPORTS__vGetEventList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_EVENT_DETAIL:

            HSA_SXM_SPORTS__vRequestToGetEventDetail();
            break;

        case HSA_API_ENTRYPOINT__GET_EVENT_DETAILS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SPORTS__vGetEventDetails(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_EVENT_LEADERLIST:

            HSA_SXM_SPORTS__vRequestToGetEventLeaderlist();
            break;

        case HSA_API_ENTRYPOINT__GET_EVENT_LEADERLIST_COUNT:

            HSA_SXM_SPORTS__ulwGetEventLeaderlistCount();
            break;

        case HSA_API_ENTRYPOINT__GET_EVENT_LEADERLIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_SPORTS__vGetEventLeaderlist(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_ROOT_AFFILIATE_LIST_FOR_SDS:

            HSA_SXM_SPORTS__vRequestToGetRootAffiliateListForSDS();
            break;

        case HSA_API_ENTRYPOINT__AVAILABILITY_SPORTS_FOR_SDS:

            HSA_SXM_SPORTS__blAvailabilitySportsForSDS();
            break;

        case HSA_API_ENTRYPOINT__SEND_FOCUSED_LIST_ENTRY_NUMBER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vSendFocusedListEntryNumber(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_FOCUSED_LIST_ENTRY_NUMBER:

            HSA_SXM_SPORTS__ulwGetFocusedListEntryNumber();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_CLASS_TYPE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SPORTS__vRequestToGetClassType(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_CLASS_TYPE:

            HSA_SXM_SPORTS__ulwGetClassType();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_FAV_GAME_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vRequestToGetFavGameList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_FAV_GAME_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetFavGameListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_FAV_GAME_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_SPORTS__vGetFavGameList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_GAME_DETAILS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SPORTS__vGetGameDetails(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_RANK_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetRankListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_RANKED_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_SPORTS__vGetRankedList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_GAME_DETAILS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vRequestToGetGameDetails(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_GOLF_GAME_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetGolfGameListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_GOLF_GAME_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_SPORTS__vGetGolfGameList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_GOLF_DETAILS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vRequestToGetGolfDetails(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_GOLF_DETAILS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SPORTS__vGetGolfDetails(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_GOLF_INFO:

            HSA_SXM_SPORTS__vRequestToGetGolfInfo();
            break;

        case HSA_API_ENTRYPOINT__GET_GOLF_INFO_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetGolfInfoListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_GOLF_INFO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_SPORTS__vGetGolfInfo(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_GAME_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetMotorSportGameListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_GAME_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_SPORTS__vGetMotorSportGameList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_MOTOR_SPORT_DETAILS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_SPORTS__vRequestToGetMotorSportDetails(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_DETAILS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_SPORTS__vGetMotorSportDetails(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_MOTOR_SPORT_INFO:

            HSA_SXM_SPORTS__vRequestToGetMotorSportInfo();
            break;

        case HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_INFO_LIST_COUNT:

            HSA_SXM_SPORTS__ulwGetMotorSportInfoListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_INFO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SXM_SPORTS__vGetMotorSportInfo(&gsParam1, ulParam2, ulParam3);
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

