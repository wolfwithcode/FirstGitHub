/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_SXM_SPORTS_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_SXM/HSA_SPORTS/clHSA_SXM_SPORTS_Base.h"

clHSA_SXM_SPORTS_Base* clHSA_SXM_SPORTS_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_SXM_SPORTS_Base.cpp.trc.h"
#endif


/**
 * Method: blWaitSyncForSports
  * Whether to wait for information or not.
  * NISSAN2.0
 */
tbool clHSA_SXM_SPORTS_Base::blWaitSyncForSports( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SPORTS::blWaitSyncForSports not implemented"));
   return 0;
}

/**
 * Method: blGetSportsServiceState
  * Return the service state and insert popup if needed
  * NISSAN2.0
 */
tbool clHSA_SXM_SPORTS_Base::blGetSportsServiceState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SPORTS::blGetSportsServiceState not implemented"));
   return 0;
}

/**
 * Method: ulwGetSportsDataAvailability
  * Tells whether the data is available or not
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetSportsDataAvailability( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetSportsDataAvailability not implemented"));
   return 0;
}

/**
 * Method: vRequestToGetSportsList
  * Request to Get list of the sports
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetSportsList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetSportsList not implemented"));
   
}

/**
 * Method: ulwGetSportsListCount
  * Returns the number of sports in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetSportsListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetSportsListCount not implemented"));
   return 0;
}

/**
 * Method: vGetSportsList
  * Get list of the sports
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetSportsList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetSportsList not implemented"));
   
}

/**
 * Method: vRequestToGetFavoriteSportsList
  * Request to Get list of the Favorite sports
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetFavoriteSportsList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetFavoriteSportsList not implemented"));
   
}

/**
 * Method: ulwGetFavoriteSportsListCount
  * Returns the number of  Favoritesports in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetFavoriteSportsListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetFavoriteSportsListCount not implemented"));
   return 0;
}

/**
 * Method: vGetFavoriteSportsList
  * Get list of the Favoritesports
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetFavoriteSportsList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetFavoriteSportsList not implemented"));
   
}

/**
 * Method: vRequestToGetTeamGameList
  * Request to get game list of the  selected favorite sport
  * NISSAN2.0
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetTeamGameList(ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetTeamGameList not implemented"));
   
}

/**
 * Method: ulwGetTeamGameListCount
  * Returns the number of  games in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetTeamGameListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetTeamGameListCount not implemented"));
   return 0;
}

/**
 * Method: vGetTeamGameList
  * Get list of the games
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetTeamGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetTeamGameList not implemented"));
   
}

/**
 * Method: blGetListenButtonVisibility
  * Returns visibility Listen button in game list for each entry.
  * NISSAN2.0
 */
tbool clHSA_SXM_SPORTS_Base::blGetListenButtonVisibility(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_SXM_SPORTS::blGetListenButtonVisibility not implemented"));
   return 0;
}

/**
 * Method: vSendSelectedListEntryNr
  * Selected ListEntryNr is sent to HMI
  * NISSAN2.0
 */
void clHSA_SXM_SPORTS_Base::vSendSelectedListEntryNr(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vSendSelectedListEntryNr not implemented"));
   
}

/**
 * Method: ulwGetActiveLeagueSeasonStatus
  * Returns the status of the league
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetActiveLeagueSeasonStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetActiveLeagueSeasonStatus not implemented"));
   return 0;
}

/**
 * Method: vGetTeamGameDetails
  * Returns details about the game based on Team Selected
  * NISSAN2.0
 */
void clHSA_SXM_SPORTS_Base::vGetTeamGameDetails(GUI_String *out_result, ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetTeamGameDetails not implemented"));
   
}

/**
 * Method: ulwGetVisibility
  * Returns the enable or disable or visibility of button listen/current/recent/future/S_R/Leader
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetVisibility(ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetVisibility not implemented"));
   return 0;
}

/**
 * Method: vGetTeamName
  * Returns name of team used for header.
  * NISSAN2.0
 */
void clHSA_SXM_SPORTS_Base::vGetTeamName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetTeamName not implemented"));
   
}

/**
 * Method: vSetFavoriteControl
  * Request to Save or remove the game in favorite list
  * NISSAN2.0
 */
void clHSA_SXM_SPORTS_Base::vSetFavoriteControl( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vSetFavoriteControl not implemented"));
   
}

/**
 * Method: vReplaceTeamInFavoriteList
  * Selected team ListEntryNr is sent to HMI
  * NISSAN2.0
 */
void clHSA_SXM_SPORTS_Base::vReplaceTeamInFavoriteList(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vReplaceTeamInFavoriteList not implemented"));
   
}

/**
 * Method: vRequestToListen
  * Request to listen the current sports
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToListen( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToListen not implemented"));
   
}

/**
 * Method: vRequestToListenFrmListEntry
  * Request to listen the current sports with List Entry
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToListenFrmListEntry(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToListenFrmListEntry not implemented"));
   
}

/**
 * Method: ulwGetChannelCount
  * Returns the number of channels .
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetChannelCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetChannelCount not implemented"));
   return 0;
}

/**
 * Method: ulwGetChannelName
  * Get the channel Type
  * B
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetChannelName(ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetChannelName not implemented"));
   return 0;
}

/**
 * Method: vGetChannelNumber
  * Get the channel number
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetChannelNumber(GUI_String *out_result, ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetChannelNumber not implemented"));
   
}

/**
 * Method: vListenSportsChannel
  * Request to listen to selected channel number
  * B
 */
void clHSA_SXM_SPORTS_Base::vListenSportsChannel(ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vListenSportsChannel not implemented"));
   
}

/**
 * Method: vRequestToGetRootAffiliateList
  * Request to Get list of the Root Affiliates
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetRootAffiliateList(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetRootAffiliateList not implemented"));
   
}

/**
 * Method: vGetRootAffiliateSportName
  * Get name of the sport for which Root Affiliate list has to be shown
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetRootAffiliateSportName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetRootAffiliateSportName not implemented"));
   
}

/**
 * Method: ulwGetRootAffiliateListCount
  * Returns the number of  RootAffiliate in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetRootAffiliateListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetRootAffiliateListCount not implemented"));
   return 0;
}

/**
 * Method: vGetRootAffiliateList
  * Get list of the RootAffiliate
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetRootAffiliateList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetRootAffiliateList not implemented"));
   
}

/**
 * Method: vRequestToGetAffiliateDetails
  * Request to Get list of the Root Affiliates
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetAffiliateDetails(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetAffiliateDetails not implemented"));
   
}

/**
 * Method: vGetCurrentAffiliateName
  * Get name of the Root Affiliate for which Affiliate details has to be shown
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetCurrentAffiliateName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetCurrentAffiliateName not implemented"));
   
}

/**
 * Method: ulwGetAffiliateListCount
  * Returns the number of Affiliate Details List in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetAffiliateListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetAffiliateListCount not implemented"));
   return 0;
}

/**
 * Method: vGetAffiliateList
  * Get list of the RootAffiliate
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetAffiliateList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetAffiliateList not implemented"));
   
}

/**
 * Method: blGetAffiliateListVisibility
  * Returns Visibility Status of affiliate list element.
  * B
 */
tbool clHSA_SXM_SPORTS_Base::blGetAffiliateListVisibility(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_SXM_SPORTS::blGetAffiliateListVisibility not implemented"));
   return 0;
}

/**
 * Method: vRequestToGetSportInfo
  * Request to Get list of the Root Affiliates
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetSportInfo(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetSportInfo not implemented"));
   
}

/**
 * Method: ulwGetScreenType
  * Returns the type of screen for Affiliate Details.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetScreenType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetScreenType not implemented"));
   return 0;
}

/**
 * Method: ulwGetAffiliateScreenType
  * Returns 0 for root affiliate screen and 1 for child affiliate screen type .
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetAffiliateScreenType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetAffiliateScreenType not implemented"));
   return 0;
}

/**
 * Method: ulwGetParrentAffiliateListidx
  * Returns Parrent affiliates Listidx.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetParrentAffiliateListidx( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetParrentAffiliateListidx not implemented"));
   return 0;
}

/**
 * Method: vRequestToGetChildAffiliateDetails
  * Request to Get list of the child  Affiliates details on the press of back
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetChildAffiliateDetails( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetChildAffiliateDetails not implemented"));
   
}

/**
 * Method: vGetNewsDetails
  * Get the news details  of the current Affiliate
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetNewsDetails(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetNewsDetails not implemented"));
   
}

/**
 * Method: ulwGetAllTeamsCount
  * Returns the number of  all teams in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetAllTeamsCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetAllTeamsCount not implemented"));
   return 0;
}

/**
 * Method: vGetAllTeamsList
  * Get list of the all teams
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetAllTeamsList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetAllTeamsList not implemented"));
   
}

/**
 * Method: ulwGetTopTeamsListCount
  * Returns the number of  ranked list count.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetTopTeamsListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetTopTeamsListCount not implemented"));
   return 0;
}

/**
 * Method: vGetTopTeamsList
  * Get list of the RootAffiliate
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetTopTeamsList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetTopTeamsList not implemented"));
   
}

/**
 * Method: ulwGetScheduleGameListCount
  * Returns the number of  rows in Recent/Future/Today details.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetScheduleGameListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetScheduleGameListCount not implemented"));
   return 0;
}

/**
 * Method: vGetScheduleGameList
  * Get list of the all teams
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetScheduleGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetScheduleGameList not implemented"));
   
}

/**
 * Method: vGetScheduleGameDetails
  * Returns details about the game.
  * NISSAN2.0
 */
void clHSA_SXM_SPORTS_Base::vGetScheduleGameDetails(GUI_String *out_result, ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetScheduleGameDetails not implemented"));
   
}

/**
 * Method: vRequestToGetScheduleGameList
  * Request to get Schedule game list of the selected league
  * NISSAN2.0
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetScheduleGameList(ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetScheduleGameList not implemented"));
   
}

/**
 * Method: ulwGetEventListCount
  * Returns the number of golf Tourney's in a affiliate.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetEventListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetEventListCount not implemented"));
   return 0;
}

/**
 * Method: vGetEventList
  * Get list of the golf Tourney's in a affiliate
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetEventList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetEventList not implemented"));
   
}

/**
 * Method: vRequestToGetEventDetail
  * Request to get Event list of the selected league
  * NISSAN2.0
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetEventDetail( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetEventDetail not implemented"));
   
}

/**
 * Method: vGetEventDetails
  * Get Tourney Details of Non Team Sports
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetEventDetails(GUI_String *out_result, ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetEventDetails not implemented"));
   
}

/**
 * Method: vRequestToGetEventLeaderlist
  * Request to Get list of the participants Rank in a Tourney
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetEventLeaderlist( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetEventLeaderlist not implemented"));
   
}

/**
 * Method: ulwGetEventLeaderlistCount
  * Returns the number of participants in a Tourney.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetEventLeaderlistCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetEventLeaderlistCount not implemented"));
   return 0;
}

/**
 * Method: vGetEventLeaderlist
  * Get participants Rank info of selected Tourney
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetEventLeaderlist(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetEventLeaderlist not implemented"));
   
}

/**
 * Method: vRequestToGetRootAffiliateListForSDS
  * Request to Get list of the root affilaite sports
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetRootAffiliateListForSDS( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetRootAffiliateListForSDS not implemented"));
   
}

/**
 * Method: blAvailabilitySportsForSDS
  * Whether to call the root affilaite or Not.
  * NISSAN2.0
 */
tbool clHSA_SXM_SPORTS_Base::blAvailabilitySportsForSDS( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_SPORTS::blAvailabilitySportsForSDS not implemented"));
   return 0;
}

/**
 * Method: vSendFocusedListEntryNumber
  * Api call to Store current focused index
  * B
 */
void clHSA_SXM_SPORTS_Base::vSendFocusedListEntryNumber(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vSendFocusedListEntryNumber not implemented"));
   
}

/**
 * Method: ulwGetFocusedListEntryNumber
  * Get current active game index
  * B
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetFocusedListEntryNumber( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetFocusedListEntryNumber not implemented"));
   return 0;
}

/**
 * Method: vRequestToGetClassType
  * Request to Get details about Favorite sport
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetClassType(ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetClassType not implemented"));
   
}

/**
 * Method: ulwGetClassType
  * Returns the type of class current/recent/future/no_data.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetClassType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetClassType not implemented"));
   return 0;
}

/**
 * Method: vRequestToGetFavGameList
  * Request to get game list of the  selected favorite sport
  * NISSAN2.0
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetFavGameList(ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetFavGameList not implemented"));
   
}

/**
 * Method: ulwGetFavGameListCount
  * Returns the number of  games in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetFavGameListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetFavGameListCount not implemented"));
   return 0;
}

/**
 * Method: vGetFavGameList
  * Get list of the games
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetFavGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetFavGameList not implemented"));
   
}

/**
 * Method: vGetGameDetails
  * Returns details about the game.
  * NISSAN2.0
 */
void clHSA_SXM_SPORTS_Base::vGetGameDetails(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetGameDetails not implemented"));
   
}

/**
 * Method: ulwGetRankListCount
  * Returns the number of  ranked list count.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetRankListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetRankListCount not implemented"));
   return 0;
}

/**
 * Method: vGetRankedList
  * Get list of the RootAffiliate
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetRankedList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetRankedList not implemented"));
   
}

/**
 * Method: vRequestToGetGameDetails
  * Get list of the RootAffiliate
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetGameDetails(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetGameDetails not implemented"));
   
}

/**
 * Method: ulwGetGolfGameListCount
  * Returns the number of golf Tourney's in a affiliate.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetGolfGameListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetGolfGameListCount not implemented"));
   return 0;
}

/**
 * Method: vGetGolfGameList
  * Get list of the golf Tourney's in a affiliate
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetGolfGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetGolfGameList not implemented"));
   
}

/**
 * Method: vRequestToGetGolfDetails
  * Request to get golf Tourney Details
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetGolfDetails(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetGolfDetails not implemented"));
   
}

/**
 * Method: vGetGolfDetails
  * Get Tourney Details of Non Team Sports
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetGolfDetails(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetGolfDetails not implemented"));
   
}

/**
 * Method: vRequestToGetGolfInfo
  * Request to Get list of the participants Rank in a Tourney
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetGolfInfo( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetGolfInfo not implemented"));
   
}

/**
 * Method: ulwGetGolfInfoListCount
  * Returns the number of participants in a Tourney.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetGolfInfoListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetGolfInfoListCount not implemented"));
   return 0;
}

/**
 * Method: vGetGolfInfo
  * Get participants Rank info of selected Tourney
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetGolfInfo(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetGolfInfo not implemented"));
   
}

/**
 * Method: ulwGetMotorSportGameListCount
  * Returns the number of  Motorsport events in a affiliate.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetMotorSportGameListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetMotorSportGameListCount not implemented"));
   return 0;
}

/**
 * Method: vGetMotorSportGameList
  * Get list of the Motorsport events in a affiliate
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetMotorSportGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetMotorSportGameList not implemented"));
   
}

/**
 * Method: vRequestToGetMotorSportDetails
  * Request to get Race Details
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetMotorSportDetails(ulword ulwrowIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwrowIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetMotorSportDetails not implemented"));
   
}

/**
 * Method: vGetMotorSportDetails
  * Get Details of the Selected Race
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetMotorSportDetails(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetMotorSportDetails not implemented"));
   
}

/**
 * Method: vRequestToGetMotorSportInfo
  * Request to Get list of the participants in a Race
  * B
 */
void clHSA_SXM_SPORTS_Base::vRequestToGetMotorSportInfo( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vRequestToGetMotorSportInfo not implemented"));
   
}

/**
 * Method: ulwGetMotorSportInfoListCount
  * Returns the number of participants in Selected Race.
  * NISSAN2.0
 */
ulword clHSA_SXM_SPORTS_Base::ulwGetMotorSportInfoListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_SPORTS::ulwGetMotorSportInfoListCount not implemented"));
   return 0;
}

/**
 * Method: vGetMotorSportInfo
  * Get participants info in Selected Race
  * B
 */
void clHSA_SXM_SPORTS_Base::vGetMotorSportInfo(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_SPORTS::vGetMotorSportInfo not implemented"));
   
}

