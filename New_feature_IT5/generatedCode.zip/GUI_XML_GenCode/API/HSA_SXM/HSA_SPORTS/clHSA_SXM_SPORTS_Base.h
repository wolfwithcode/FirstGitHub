/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_SXM_SPORTS_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_SXM_SPORTS_Base_H
#define _clHSA_SXM_SPORTS_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_SXM_SPORTS_Base : public clHSA_Base
{
public:

    static clHSA_SXM_SPORTS_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_SXM_SPORTS_Base()        {}

    virtual tbool blWaitSyncForSports( );

    virtual tbool blGetSportsServiceState( );

    virtual ulword ulwGetSportsDataAvailability( );

    virtual void vRequestToGetSportsList( );

    virtual ulword ulwGetSportsListCount( );

    virtual void vGetSportsList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vRequestToGetFavoriteSportsList( );

    virtual ulword ulwGetFavoriteSportsListCount( );

    virtual void vGetFavoriteSportsList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vRequestToGetTeamGameList(ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual ulword ulwGetTeamGameListCount( );

    virtual void vGetTeamGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual tbool blGetListenButtonVisibility(ulword ulwListEntryNr);

    virtual void vSendSelectedListEntryNr(ulword ulwListEntryNr);

    virtual ulword ulwGetActiveLeagueSeasonStatus( );

    virtual void vGetTeamGameDetails(GUI_String *out_result, ulword ulwInfo_Type);

    virtual ulword ulwGetVisibility(ulword ulwInfo_Type);

    virtual void vGetTeamName(GUI_String *out_result);

    virtual void vSetFavoriteControl( );

    virtual void vReplaceTeamInFavoriteList(ulword ulwListEntryNr);

    virtual void vRequestToListen( );

    virtual void vRequestToListenFrmListEntry(ulword ulwListEntryNr);

    virtual ulword ulwGetChannelCount( );

    virtual ulword ulwGetChannelName(ulword ulwInfo_Type);

    virtual void vGetChannelNumber(GUI_String *out_result, ulword ulwInfo_Type);

    virtual void vListenSportsChannel(ulword ulwInfo_Type);

    virtual void vRequestToGetRootAffiliateList(ulword ulwListEntryNr);

    virtual void vGetRootAffiliateSportName(GUI_String *out_result);

    virtual ulword ulwGetRootAffiliateListCount( );

    virtual void vGetRootAffiliateList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vRequestToGetAffiliateDetails(ulword ulwListEntryNr);

    virtual void vGetCurrentAffiliateName(GUI_String *out_result);

    virtual ulword ulwGetAffiliateListCount( );

    virtual void vGetAffiliateList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual tbool blGetAffiliateListVisibility(ulword ulwListEntryNr);

    virtual void vRequestToGetSportInfo(ulword ulwListEntryNr);

    virtual ulword ulwGetScreenType( );

    virtual ulword ulwGetAffiliateScreenType( );

    virtual ulword ulwGetParrentAffiliateListidx( );

    virtual void vRequestToGetChildAffiliateDetails( );

    virtual void vGetNewsDetails(GUI_String *out_result);

    virtual ulword ulwGetAllTeamsCount( );

    virtual void vGetAllTeamsList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetTopTeamsListCount( );

    virtual void vGetTopTeamsList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetScheduleGameListCount( );

    virtual void vGetScheduleGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vGetScheduleGameDetails(GUI_String *out_result, ulword ulwInfo_Type);

    virtual void vRequestToGetScheduleGameList(ulword ulwInfo_Type);

    virtual ulword ulwGetEventListCount( );

    virtual void vGetEventList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vRequestToGetEventDetail( );

    virtual void vGetEventDetails(GUI_String *out_result, ulword ulwInfo_Type);

    virtual void vRequestToGetEventLeaderlist( );

    virtual ulword ulwGetEventLeaderlistCount( );

    virtual void vGetEventLeaderlist(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vRequestToGetRootAffiliateListForSDS( );

    virtual tbool blAvailabilitySportsForSDS( );

    virtual void vSendFocusedListEntryNumber(ulword ulwListEntryNr);

    virtual ulword ulwGetFocusedListEntryNumber( );

    virtual void vRequestToGetClassType(ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual ulword ulwGetClassType( );

    virtual void vRequestToGetFavGameList(ulword ulwInfo_Type);

    virtual ulword ulwGetFavGameListCount( );

    virtual void vGetFavGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vGetGameDetails(GUI_String *out_result);

    virtual ulword ulwGetRankListCount( );

    virtual void vGetRankedList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vRequestToGetGameDetails(ulword ulwListEntryNr);

    virtual ulword ulwGetGolfGameListCount( );

    virtual void vGetGolfGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vRequestToGetGolfDetails(ulword ulwListEntryNr);

    virtual void vGetGolfDetails(GUI_String *out_result);

    virtual void vRequestToGetGolfInfo( );

    virtual ulword ulwGetGolfInfoListCount( );

    virtual void vGetGolfInfo(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual ulword ulwGetMotorSportGameListCount( );

    virtual void vGetMotorSportGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vRequestToGetMotorSportDetails(ulword ulwrowIndex);

    virtual void vGetMotorSportDetails(GUI_String *out_result);

    virtual void vRequestToGetMotorSportInfo( );

    virtual ulword ulwGetMotorSportInfoListCount( );

    virtual void vGetMotorSportInfo(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

protected:
    clHSA_SXM_SPORTS_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_SXM_SPORTS_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_SXM_SPORTS_Base_H

