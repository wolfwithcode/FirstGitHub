/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_SPORTS_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_SXM_SPORTS_Wrapper.h"
#include "clHSA_SXM_SPORTS_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_SXM_SPORTS_Trace.h"
#include "hmi_trace.h"

tbool HSA_SXM_SPORTS__blWaitSyncForSports( )
{
    tbool ret = false;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_SPORTS  ) ); 
        }
      ret=pInst->blWaitSyncForSports();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_SPORTS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_SPORTS__blGetSportsServiceState( )
{
    tbool ret = false;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SPORTS_SERVICE_STATE  ) ); 
        }
      ret=pInst->blGetSportsServiceState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SPORTS_SERVICE_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SPORTS__ulwGetSportsDataAvailability( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SPORTS_DATA_AVAILABILITY  ) ); 
        }
      ret=pInst->ulwGetSportsDataAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SPORTS_DATA_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vRequestToGetSportsList( )
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_SPORTS_LIST  ) ); 
        }
      pInst->vRequestToGetSportsList();

    }
}

ulword HSA_SXM_SPORTS__ulwGetSportsListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SPORTS_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetSportsListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SPORTS_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetSportsList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SPORTS_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetSportsList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SPORTS_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vRequestToGetFavoriteSportsList( )
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_FAVORITE_SPORTS_LIST  ) ); 
        }
      pInst->vRequestToGetFavoriteSportsList();

    }
}

ulword HSA_SXM_SPORTS__ulwGetFavoriteSportsListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_SPORTS_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetFavoriteSportsListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_SPORTS_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetFavoriteSportsList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_SPORTS_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_SPORTS_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetFavoriteSportsList(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_SPORTS_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vRequestToGetTeamGameList(ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_TEAM_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_TEAM_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRequestToGetTeamGameList(ulwInfo_Type, ulwListEntryNr);

    }
}

ulword HSA_SXM_SPORTS__ulwGetTeamGameListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TEAM_GAME_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetTeamGameListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TEAM_GAME_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetTeamGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TEAM_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TEAM_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetTeamGameList(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TEAM_GAME_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_SXM_SPORTS__blGetListenButtonVisibility(ulword ulwListEntryNr)
{
    tbool ret = false;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_LISTEN_BUTTON_VISIBILITY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->blGetListenButtonVisibility(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_LISTEN_BUTTON_VISIBILITY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vSendSelectedListEntryNr(ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__SEND_SELECTED_LIST_ENTRY_NR | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSendSelectedListEntryNr(ulwListEntryNr);

    }
}

ulword HSA_SXM_SPORTS__ulwGetActiveLeagueSeasonStatus( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_LEAGUE_SEASON_STATUS  ) ); 
        }
      ret=pInst->ulwGetActiveLeagueSeasonStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_LEAGUE_SEASON_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetTeamGameDetails(GUI_String *out_result, ulword ulwInfo_Type)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TEAM_GAME_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vGetTeamGameDetails(out_result, ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TEAM_GAME_DETAILS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_SPORTS__ulwGetVisibility(ulword ulwInfo_Type)
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_VISIBILITY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      ret=pInst->ulwGetVisibility(ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_VISIBILITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetTeamName(GUI_String *out_result)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TEAM_NAME  ) ); 
        }
      pInst->vGetTeamName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TEAM_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vSetFavoriteControl( )
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__SET_FAVORITE_CONTROL  ) ); 
        }
      pInst->vSetFavoriteControl();

    }
}

void HSA_SXM_SPORTS__vReplaceTeamInFavoriteList(ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REPLACE_TEAM_IN_FAVORITE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vReplaceTeamInFavoriteList(ulwListEntryNr);

    }
}

void HSA_SXM_SPORTS__vRequestToListen( )
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_LISTEN  ) ); 
        }
      pInst->vRequestToListen();

    }
}

void HSA_SXM_SPORTS__vRequestToListenFrmListEntry(ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_LISTEN_FRM_LIST_ENTRY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRequestToListenFrmListEntry(ulwListEntryNr);

    }
}

ulword HSA_SXM_SPORTS__ulwGetChannelCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_COUNT  ) ); 
        }
      ret=pInst->ulwGetChannelCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SPORTS__ulwGetChannelName(ulword ulwInfo_Type)
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      ret=pInst->ulwGetChannelName(ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_NAME | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetChannelNumber(GUI_String *out_result, ulword ulwInfo_Type)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vGetChannelNumber(out_result, ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_CHANNEL_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vListenSportsChannel(ulword ulwInfo_Type)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__LISTEN_SPORTS_CHANNEL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vListenSportsChannel(ulwInfo_Type);

    }
}

void HSA_SXM_SPORTS__vRequestToGetRootAffiliateList(ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_ROOT_AFFILIATE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRequestToGetRootAffiliateList(ulwListEntryNr);

    }
}

void HSA_SXM_SPORTS__vGetRootAffiliateSportName(GUI_String *out_result)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_ROOT_AFFILIATE_SPORT_NAME  ) ); 
        }
      pInst->vGetRootAffiliateSportName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_ROOT_AFFILIATE_SPORT_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_SPORTS__ulwGetRootAffiliateListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_ROOT_AFFILIATE_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetRootAffiliateListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_ROOT_AFFILIATE_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetRootAffiliateList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_ROOT_AFFILIATE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetRootAffiliateList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_ROOT_AFFILIATE_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vRequestToGetAffiliateDetails(ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_AFFILIATE_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRequestToGetAffiliateDetails(ulwListEntryNr);

    }
}

void HSA_SXM_SPORTS__vGetCurrentAffiliateName(GUI_String *out_result)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_AFFILIATE_NAME  ) ); 
        }
      pInst->vGetCurrentAffiliateName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_AFFILIATE_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_SPORTS__ulwGetAffiliateListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_AFFILIATE_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetAffiliateListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_AFFILIATE_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetAffiliateList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_AFFILIATE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetAffiliateList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_AFFILIATE_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_SXM_SPORTS__blGetAffiliateListVisibility(ulword ulwListEntryNr)
{
    tbool ret = false;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_AFFILIATE_LIST_VISIBILITY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->blGetAffiliateListVisibility(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_AFFILIATE_LIST_VISIBILITY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vRequestToGetSportInfo(ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_SPORT_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRequestToGetSportInfo(ulwListEntryNr);

    }
}

ulword HSA_SXM_SPORTS__ulwGetScreenType( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SCREEN_TYPE  ) ); 
        }
      ret=pInst->ulwGetScreenType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SCREEN_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SPORTS__ulwGetAffiliateScreenType( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_AFFILIATE_SCREEN_TYPE  ) ); 
        }
      ret=pInst->ulwGetAffiliateScreenType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_AFFILIATE_SCREEN_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_SPORTS__ulwGetParrentAffiliateListidx( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_PARRENT_AFFILIATE_LISTIDX  ) ); 
        }
      ret=pInst->ulwGetParrentAffiliateListidx();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_PARRENT_AFFILIATE_LISTIDX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vRequestToGetChildAffiliateDetails( )
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_CHILD_AFFILIATE_DETAILS  ) ); 
        }
      pInst->vRequestToGetChildAffiliateDetails();

    }
}

void HSA_SXM_SPORTS__vGetNewsDetails(GUI_String *out_result)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_NEWS_DETAILS  ) ); 
        }
      pInst->vGetNewsDetails(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_NEWS_DETAILS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_SPORTS__ulwGetAllTeamsCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_ALL_TEAMS_COUNT  ) ); 
        }
      ret=pInst->ulwGetAllTeamsCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_ALL_TEAMS_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetAllTeamsList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_ALL_TEAMS_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetAllTeamsList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_ALL_TEAMS_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_SPORTS__ulwGetTopTeamsListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TOP_TEAMS_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetTopTeamsListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TOP_TEAMS_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetTopTeamsList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TOP_TEAMS_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetTopTeamsList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_TOP_TEAMS_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_SPORTS__ulwGetScheduleGameListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SCHEDULE_GAME_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetScheduleGameListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SCHEDULE_GAME_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetScheduleGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SCHEDULE_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SCHEDULE_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetScheduleGameList(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SCHEDULE_GAME_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vGetScheduleGameDetails(GUI_String *out_result, ulword ulwInfo_Type)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SCHEDULE_GAME_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vGetScheduleGameDetails(out_result, ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_SCHEDULE_GAME_DETAILS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vRequestToGetScheduleGameList(ulword ulwInfo_Type)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_SCHEDULE_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vRequestToGetScheduleGameList(ulwInfo_Type);

    }
}

ulword HSA_SXM_SPORTS__ulwGetEventListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_EVENT_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetEventListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_EVENT_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetEventList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_EVENT_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_EVENT_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetEventList(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_EVENT_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vRequestToGetEventDetail( )
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_EVENT_DETAIL  ) ); 
        }
      pInst->vRequestToGetEventDetail();

    }
}

void HSA_SXM_SPORTS__vGetEventDetails(GUI_String *out_result, ulword ulwInfo_Type)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_EVENT_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vGetEventDetails(out_result, ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_EVENT_DETAILS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vRequestToGetEventLeaderlist( )
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_EVENT_LEADERLIST  ) ); 
        }
      pInst->vRequestToGetEventLeaderlist();

    }
}

ulword HSA_SXM_SPORTS__ulwGetEventLeaderlistCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_EVENT_LEADERLIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetEventLeaderlistCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_EVENT_LEADERLIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetEventLeaderlist(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_EVENT_LEADERLIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_EVENT_LEADERLIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetEventLeaderlist(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_EVENT_LEADERLIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vRequestToGetRootAffiliateListForSDS( )
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_ROOT_AFFILIATE_LIST_FOR_SDS  ) ); 
        }
      pInst->vRequestToGetRootAffiliateListForSDS();

    }
}

tbool HSA_SXM_SPORTS__blAvailabilitySportsForSDS( )
{
    tbool ret = false;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__AVAILABILITY_SPORTS_FOR_SDS  ) ); 
        }
      ret=pInst->blAvailabilitySportsForSDS();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__AVAILABILITY_SPORTS_FOR_SDS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vSendFocusedListEntryNumber(ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__SEND_FOCUSED_LIST_ENTRY_NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSendFocusedListEntryNumber(ulwListEntryNr);

    }
}

ulword HSA_SXM_SPORTS__ulwGetFocusedListEntryNumber( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_FOCUSED_LIST_ENTRY_NUMBER  ) ); 
        }
      ret=pInst->ulwGetFocusedListEntryNumber();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_FOCUSED_LIST_ENTRY_NUMBER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vRequestToGetClassType(ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_CLASS_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_CLASS_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRequestToGetClassType(ulwInfo_Type, ulwListEntryNr);

    }
}

ulword HSA_SXM_SPORTS__ulwGetClassType( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_CLASS_TYPE  ) ); 
        }
      ret=pInst->ulwGetClassType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_CLASS_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vRequestToGetFavGameList(ulword ulwInfo_Type)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_FAV_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vRequestToGetFavGameList(ulwInfo_Type);

    }
}

ulword HSA_SXM_SPORTS__ulwGetFavGameListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_FAV_GAME_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetFavGameListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_FAV_GAME_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetFavGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_FAV_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_FAV_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetFavGameList(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_FAV_GAME_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vGetGameDetails(GUI_String *out_result)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GAME_DETAILS  ) ); 
        }
      pInst->vGetGameDetails(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GAME_DETAILS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_SPORTS__ulwGetRankListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_RANK_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetRankListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_RANK_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetRankedList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_RANKED_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetRankedList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_RANKED_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vRequestToGetGameDetails(ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_GAME_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRequestToGetGameDetails(ulwListEntryNr);

    }
}

ulword HSA_SXM_SPORTS__ulwGetGolfGameListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GOLF_GAME_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetGolfGameListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GOLF_GAME_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetGolfGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GOLF_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GOLF_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetGolfGameList(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GOLF_GAME_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vRequestToGetGolfDetails(ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_GOLF_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vRequestToGetGolfDetails(ulwListEntryNr);

    }
}

void HSA_SXM_SPORTS__vGetGolfDetails(GUI_String *out_result)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GOLF_DETAILS  ) ); 
        }
      pInst->vGetGolfDetails(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GOLF_DETAILS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vRequestToGetGolfInfo( )
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_GOLF_INFO  ) ); 
        }
      pInst->vRequestToGetGolfInfo();

    }
}

ulword HSA_SXM_SPORTS__ulwGetGolfInfoListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GOLF_INFO_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetGolfInfoListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GOLF_INFO_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetGolfInfo(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GOLF_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GOLF_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetGolfInfo(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_GOLF_INFO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_SPORTS__ulwGetMotorSportGameListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_GAME_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetMotorSportGameListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_GAME_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetMotorSportGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_GAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetMotorSportGameList(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_GAME_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vRequestToGetMotorSportDetails(ulword ulwrowIndex)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_MOTOR_SPORT_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwrowIndex); 
        }
      pInst->vRequestToGetMotorSportDetails(ulwrowIndex);

    }
}

void HSA_SXM_SPORTS__vGetMotorSportDetails(GUI_String *out_result)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_DETAILS  ) ); 
        }
      pInst->vGetMotorSportDetails(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_DETAILS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_SPORTS__vRequestToGetMotorSportInfo( )
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_MOTOR_SPORT_INFO  ) ); 
        }
      pInst->vRequestToGetMotorSportInfo();

    }
}

ulword HSA_SXM_SPORTS__ulwGetMotorSportInfoListCount( )
{
    ulword ret = 0;
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_INFO_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetMotorSportInfoListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_INFO_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_SPORTS__vGetMotorSportInfo(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_SPORTS_Base *pInst=clHSA_SXM_SPORTS_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetMotorSportInfo(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_SPORTS), (tU16)(HSA_API_ENTRYPOINT__GET_MOTOR_SPORT_INFO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

#ifdef __cplusplus
}
#endif

