/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_SPORTS_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_SXM_SPORTS_Wrapper_H
#define _HSA_SXM_SPORTS_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: WaitSyncForSports
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_SPORTS__blWaitSyncForSports( void);

/**
 * Function: GetSportsServiceState
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_SPORTS__blGetSportsServiceState( void);

/**
 * Function: GetSportsDataAvailability
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetSportsDataAvailability( void);

/**
 * Function: RequestToGetSportsList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetSportsList( void);

/**
 * Function: GetSportsListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetSportsListCount( void);

/**
 * Function: GetSportsList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetSportsList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: RequestToGetFavoriteSportsList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetFavoriteSportsList( void);

/**
 * Function: GetFavoriteSportsListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetFavoriteSportsListCount( void);

/**
 * Function: GetFavoriteSportsList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetFavoriteSportsList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: RequestToGetTeamGameList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetTeamGameList(ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: GetTeamGameListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetTeamGameListCount( void);

/**
 * Function: GetTeamGameList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetTeamGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: GetListenButtonVisibility
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_SPORTS__blGetListenButtonVisibility(ulword ulwListEntryNr);

/**
 * Function: SendSelectedListEntryNr
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_SPORTS__vSendSelectedListEntryNr(ulword ulwListEntryNr);

/**
 * Function: GetActiveLeagueSeasonStatus
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetActiveLeagueSeasonStatus( void);

/**
 * Function: GetTeamGameDetails
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetTeamGameDetails(GUI_String *out_result, ulword ulwInfo_Type);

/**
 * Function: GetVisibility
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetVisibility(ulword ulwInfo_Type);

/**
 * Function: GetTeamName
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetTeamName(GUI_String *out_result);

/**
 * Function: SetFavoriteControl
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_SPORTS__vSetFavoriteControl( void);

/**
 * Function: ReplaceTeamInFavoriteList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_SPORTS__vReplaceTeamInFavoriteList(ulword ulwListEntryNr);

/**
 * Function: RequestToListen
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToListen( void);

/**
 * Function: RequestToListenFrmListEntry
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToListenFrmListEntry(ulword ulwListEntryNr);

/**
 * Function: GetChannelCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetChannelCount( void);

/**
 * Function: GetChannelName
 * B
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetChannelName(ulword ulwInfo_Type);

/**
 * Function: GetChannelNumber
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetChannelNumber(GUI_String *out_result, ulword ulwInfo_Type);

/**
 * Function: ListenSportsChannel
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vListenSportsChannel(ulword ulwInfo_Type);

/**
 * Function: RequestToGetRootAffiliateList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetRootAffiliateList(ulword ulwListEntryNr);

/**
 * Function: GetRootAffiliateSportName
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetRootAffiliateSportName(GUI_String *out_result);

/**
 * Function: GetRootAffiliateListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetRootAffiliateListCount( void);

/**
 * Function: GetRootAffiliateList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetRootAffiliateList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: RequestToGetAffiliateDetails
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetAffiliateDetails(ulword ulwListEntryNr);

/**
 * Function: GetCurrentAffiliateName
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetCurrentAffiliateName(GUI_String *out_result);

/**
 * Function: GetAffiliateListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetAffiliateListCount( void);

/**
 * Function: GetAffiliateList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetAffiliateList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetAffiliateListVisibility
 * B
 * NISSAN
 */
tbool HSA_SXM_SPORTS__blGetAffiliateListVisibility(ulword ulwListEntryNr);

/**
 * Function: RequestToGetSportInfo
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetSportInfo(ulword ulwListEntryNr);

/**
 * Function: GetScreenType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetScreenType( void);

/**
 * Function: GetAffiliateScreenType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetAffiliateScreenType( void);

/**
 * Function: GetParrentAffiliateListidx
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetParrentAffiliateListidx( void);

/**
 * Function: RequestToGetChildAffiliateDetails
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetChildAffiliateDetails( void);

/**
 * Function: GetNewsDetails
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetNewsDetails(GUI_String *out_result);

/**
 * Function: GetAllTeamsCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetAllTeamsCount( void);

/**
 * Function: GetAllTeamsList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetAllTeamsList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetTopTeamsListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetTopTeamsListCount( void);

/**
 * Function: GetTopTeamsList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetTopTeamsList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetScheduleGameListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetScheduleGameListCount( void);

/**
 * Function: GetScheduleGameList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetScheduleGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: GetScheduleGameDetails
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetScheduleGameDetails(GUI_String *out_result, ulword ulwInfo_Type);

/**
 * Function: RequestToGetScheduleGameList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetScheduleGameList(ulword ulwInfo_Type);

/**
 * Function: GetEventListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetEventListCount( void);

/**
 * Function: GetEventList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetEventList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: RequestToGetEventDetail
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetEventDetail( void);

/**
 * Function: GetEventDetails
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetEventDetails(GUI_String *out_result, ulword ulwInfo_Type);

/**
 * Function: RequestToGetEventLeaderlist
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetEventLeaderlist( void);

/**
 * Function: GetEventLeaderlistCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetEventLeaderlistCount( void);

/**
 * Function: GetEventLeaderlist
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetEventLeaderlist(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: RequestToGetRootAffiliateListForSDS
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetRootAffiliateListForSDS( void);

/**
 * Function: AvailabilitySportsForSDS
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_SPORTS__blAvailabilitySportsForSDS( void);

/**
 * Function: SendFocusedListEntryNumber
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vSendFocusedListEntryNumber(ulword ulwListEntryNr);

/**
 * Function: GetFocusedListEntryNumber
 * B
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetFocusedListEntryNumber( void);

/**
 * Function: RequestToGetClassType
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetClassType(ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: GetClassType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetClassType( void);

/**
 * Function: RequestToGetFavGameList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetFavGameList(ulword ulwInfo_Type);

/**
 * Function: GetFavGameListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetFavGameListCount( void);

/**
 * Function: GetFavGameList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetFavGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: GetGameDetails
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetGameDetails(GUI_String *out_result);

/**
 * Function: GetRankListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetRankListCount( void);

/**
 * Function: GetRankedList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetRankedList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: RequestToGetGameDetails
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetGameDetails(ulword ulwListEntryNr);

/**
 * Function: GetGolfGameListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetGolfGameListCount( void);

/**
 * Function: GetGolfGameList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetGolfGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: RequestToGetGolfDetails
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetGolfDetails(ulword ulwListEntryNr);

/**
 * Function: GetGolfDetails
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetGolfDetails(GUI_String *out_result);

/**
 * Function: RequestToGetGolfInfo
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetGolfInfo( void);

/**
 * Function: GetGolfInfoListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetGolfInfoListCount( void);

/**
 * Function: GetGolfInfo
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetGolfInfo(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: GetMotorSportGameListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetMotorSportGameListCount( void);

/**
 * Function: GetMotorSportGameList
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetMotorSportGameList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: RequestToGetMotorSportDetails
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetMotorSportDetails(ulword ulwrowIndex);

/**
 * Function: GetMotorSportDetails
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetMotorSportDetails(GUI_String *out_result);

/**
 * Function: RequestToGetMotorSportInfo
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vRequestToGetMotorSportInfo( void);

/**
 * Function: GetMotorSportInfoListCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_SPORTS__ulwGetMotorSportInfoListCount( void);

/**
 * Function: GetMotorSportInfo
 * B
 * NISSAN
 */
void HSA_SXM_SPORTS__vGetMotorSportInfo(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_SXM_SPORTS_H

