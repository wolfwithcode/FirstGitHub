/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_Trace.h
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
#ifndef _HSA_SXM_TRACE_H
#define _HSA_SXM_TRACE_H
 

/**** Trace defines for HSA_SXM ****/

#define HSA_API_ENTRYPOINT__RELEASE_SXM_DATA_SERVICE_LIST 0x1

#define HSA_API_ENTRYPOINT__UPDATE_SXM_DATA_SERVIVE_INFO 0x2

#define HSA_API_ENTRYPOINT__GET_SXM_DATA_SERVIVE_LIST_STATUS 0x3

#define HSA_API_ENTRYPOINT__GET_SXM_DATA_SERVICE_CCA_STATE 0x4

#endif  //#ifndef _HSA_SXM_TRACE_H

