/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_SXM_STOCKS_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_SXM_STOCKS_Base_H
#define _clHSA_SXM_STOCKS_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_SXM_STOCKS_Base : public clHSA_Base
{
public:

    static clHSA_SXM_STOCKS_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_SXM_STOCKS_Base()        {}

    virtual void vStartSXMStocksRequest( );

    virtual tbool blBlIsStocksConfigured( );

    virtual void vGetDataProviderInfo(GUI_String *out_result);

    virtual ulword ulwGetSXMStocksAdvisoryMessage( );

    virtual tbool blWaitSyncForStocks( );

    virtual tbool blIsStocksAvailable( );

    virtual tbool blGetDataProviderInfoDisplayState( );

    virtual tbool blIsStocksIntialized( );

    virtual void vRequestToGetFavStocksList( );

    virtual ulword ulwGetCountForFavStocks( );

    virtual void vGetFavStocksList(GUI_String *out_result);

    virtual void vGetListToRemoveStocksFromFavList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vSetSelectedStocksNameforRemove(ulword ulwListEntryNr);

    virtual void vGetSelectedStocksName(GUI_String *out_result);

    virtual void vRemoveStocksFromFavList( );

    virtual void vRequestToEnableSpeller( );

    virtual void vSpellerCharacterInput(const GUI_String * InputString);

    virtual void vSpellerMatchGetFirst(GUI_String *out_result);

    virtual void vRequestToGetStocksListForMatchedString( );

    virtual ulword ulwGetCountOfStocksListForMatchedString( );

    virtual void vGetStocksListForMatchedString(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vAddToFavStocksList(ulword ulwListEntryNr);

    virtual void vSpellerMatchGetPossibleLetters(GUI_String *out_result);

    virtual ulword ulwSpellerGetCursorPos( );

    virtual tbool blSpellerInvertGetLetterFunction( );

    virtual ulword ulwGetStocksAddStatus( );

protected:
    clHSA_SXM_STOCKS_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_SXM_STOCKS_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_SXM_STOCKS_Base_H

