/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_STOCKS_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_SXM_STOCKS_Wrapper_dbg.h"
#include "clHSA_SXM_STOCKS_Base.h"
#include "HSA_SXM_STOCKS_Trace.h"
#include "HSA_SXM_STOCKS_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_SXM_STOCKS_Wrapper_dbg::~clHSA_SXM_STOCKS_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_SXM_STOCKS_Wrapper_dbg::clHSA_SXM_STOCKS_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_SXM_STOCKS_Wrapper_dbg::clHSA_SXM_STOCKS_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_SXM_STOCKS_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_SXM_STOCKS_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__START_SXM_STOCKS_REQUEST:

            HSA_SXM_STOCKS__vStartSXMStocksRequest();
            break;

        case HSA_API_ENTRYPOINT__BL_IS_STOCKS_CONFIGURED:

            HSA_SXM_STOCKS__blBlIsStocksConfigured();
            break;

        case HSA_API_ENTRYPOINT__GET_DATA_PROVIDER_INFO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_STOCKS__vGetDataProviderInfo(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_STOCKS_ADVISORY_MESSAGE:

            HSA_SXM_STOCKS__ulwGetSXMStocksAdvisoryMessage();
            break;

        case HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_STOCKS:

            HSA_SXM_STOCKS__blWaitSyncForStocks();
            break;

        case HSA_API_ENTRYPOINT__IS_STOCKS_AVAILABLE:

            HSA_SXM_STOCKS__blIsStocksAvailable();
            break;

        case HSA_API_ENTRYPOINT__GET_DATA_PROVIDER_INFO_DISPLAY_STATE:

            HSA_SXM_STOCKS__blGetDataProviderInfoDisplayState();
            break;

        case HSA_API_ENTRYPOINT__IS_STOCKS_INTIALIZED:

            HSA_SXM_STOCKS__blIsStocksIntialized();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_FAV_STOCKS_LIST:

            HSA_SXM_STOCKS__vRequestToGetFavStocksList();
            break;

        case HSA_API_ENTRYPOINT__GET_COUNT_FOR_FAV_STOCKS:

            HSA_SXM_STOCKS__ulwGetCountForFavStocks();
            break;

        case HSA_API_ENTRYPOINT__GET_FAV_STOCKS_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_STOCKS__vGetFavStocksList(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LIST_TO_REMOVE_STOCKS_FROM_FAV_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_STOCKS__vGetListToRemoveStocksFromFavList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_SELECTED_STOCKS_NAMEFOR_REMOVE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_STOCKS__vSetSelectedStocksNameforRemove(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SELECTED_STOCKS_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_STOCKS__vGetSelectedStocksName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__REMOVE_STOCKS_FROM_FAV_LIST:

            HSA_SXM_STOCKS__vRemoveStocksFromFavList();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_ENABLE_SPELLER:

            HSA_SXM_STOCKS__vRequestToEnableSpeller();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_CHARACTER_INPUT:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_SXM_STOCKS__vSpellerCharacterInput(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_FIRST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_STOCKS__vSpellerMatchGetFirst(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_GET_STOCKS_LIST_FOR_MATCHED_STRING:

            HSA_SXM_STOCKS__vRequestToGetStocksListForMatchedString();
            break;

        case HSA_API_ENTRYPOINT__GET_COUNT_OF_STOCKS_LIST_FOR_MATCHED_STRING:

            HSA_SXM_STOCKS__ulwGetCountOfStocksListForMatchedString();
            break;

        case HSA_API_ENTRYPOINT__GET_STOCKS_LIST_FOR_MATCHED_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_STOCKS__vGetStocksListForMatchedString(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__ADD_TO_FAV_STOCKS_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_STOCKS__vAddToFavStocksList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_POSSIBLE_LETTERS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_STOCKS__vSpellerMatchGetPossibleLetters(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS:

            HSA_SXM_STOCKS__ulwSpellerGetCursorPos();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION:

            HSA_SXM_STOCKS__blSpellerInvertGetLetterFunction();
            break;

        case HSA_API_ENTRYPOINT__GET_STOCKS_ADD_STATUS:

            HSA_SXM_STOCKS__ulwGetStocksAddStatus();
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

