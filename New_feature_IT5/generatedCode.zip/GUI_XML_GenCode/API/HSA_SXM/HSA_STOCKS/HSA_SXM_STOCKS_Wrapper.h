/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_STOCKS_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_SXM_STOCKS_Wrapper_H
#define _HSA_SXM_STOCKS_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: StartSXMStocksRequest
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vStartSXMStocksRequest( void);

/**
 * Function: BlIsStocksConfigured
 * NISSAN_KAI
 * NISSAN
 */
tbool HSA_SXM_STOCKS__blBlIsStocksConfigured( void);

/**
 * Function: GetDataProviderInfo
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vGetDataProviderInfo(GUI_String *out_result);

/**
 * Function: GetSXMStocksAdvisoryMessage
 * NISSAN_KAI
 * NISSAN
 */
ulword HSA_SXM_STOCKS__ulwGetSXMStocksAdvisoryMessage( void);

/**
 * Function: WaitSyncForStocks
 * NISSAN_KAI
 * NISSAN
 */
tbool HSA_SXM_STOCKS__blWaitSyncForStocks( void);

/**
 * Function: IsStocksAvailable
 * NISSAN_KAI
 * NISSAN
 */
tbool HSA_SXM_STOCKS__blIsStocksAvailable( void);

/**
 * Function: GetDataProviderInfoDisplayState
 * NISSAN_KAI
 * NISSAN
 */
tbool HSA_SXM_STOCKS__blGetDataProviderInfoDisplayState( void);

/**
 * Function: IsStocksIntialized
 * NISSAN_KAI
 * NISSAN
 */
tbool HSA_SXM_STOCKS__blIsStocksIntialized( void);

/**
 * Function: RequestToGetFavStocksList
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vRequestToGetFavStocksList( void);

/**
 * Function: GetCountForFavStocks
 * NISSAN_KAI
 * NISSAN
 */
ulword HSA_SXM_STOCKS__ulwGetCountForFavStocks( void);

/**
 * Function: GetFavStocksList
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vGetFavStocksList(GUI_String *out_result);

/**
 * Function: GetListToRemoveStocksFromFavList
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vGetListToRemoveStocksFromFavList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: SetSelectedStocksNameforRemove
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vSetSelectedStocksNameforRemove(ulword ulwListEntryNr);

/**
 * Function: GetSelectedStocksName
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vGetSelectedStocksName(GUI_String *out_result);

/**
 * Function: RemoveStocksFromFavList
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vRemoveStocksFromFavList( void);

/**
 * Function: RequestToEnableSpeller
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vRequestToEnableSpeller( void);

/**
 * Function: SpellerCharacterInput
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vSpellerCharacterInput(const GUI_String * InputString);

/**
 * Function: SpellerMatchGetFirst
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vSpellerMatchGetFirst(GUI_String *out_result);

/**
 * Function: RequestToGetStocksListForMatchedString
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vRequestToGetStocksListForMatchedString( void);

/**
 * Function: GetCountOfStocksListForMatchedString
 * NISSAN_KAI
 * NISSAN
 */
ulword HSA_SXM_STOCKS__ulwGetCountOfStocksListForMatchedString( void);

/**
 * Function: GetStocksListForMatchedString
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vGetStocksListForMatchedString(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: AddToFavStocksList
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vAddToFavStocksList(ulword ulwListEntryNr);

/**
 * Function: SpellerMatchGetPossibleLetters
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_STOCKS__vSpellerMatchGetPossibleLetters(GUI_String *out_result);

/**
 * Function: SpellerGetCursorPos
 * NISSAN_KAI
 * NISSAN
 */
ulword HSA_SXM_STOCKS__ulwSpellerGetCursorPos( void);

/**
 * Function: SpellerInvertGetLetterFunction
 * B
 * NISSAN
 */
tbool HSA_SXM_STOCKS__blSpellerInvertGetLetterFunction( void);

/**
 * Function: GetStocksAddStatus
 * NISSAN_KAI
 * NISSAN
 */
ulword HSA_SXM_STOCKS__ulwGetStocksAddStatus( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_SXM_STOCKS_H

