/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_SXM_STOCKS_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_SXM/HSA_STOCKS/clHSA_SXM_STOCKS_Base.h"

clHSA_SXM_STOCKS_Base* clHSA_SXM_STOCKS_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_SXM_STOCKS_Base.cpp.trc.h"
#endif


/**
 * Method: vStartSXMStocksRequest
  * API to be called on entering SXM Stocks service.
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vStartSXMStocksRequest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vStartSXMStocksRequest not implemented"));
   
}

/**
 * Method: blBlIsStocksConfigured
  * To check wether Stocks is configured or not.
  * NISSAN_KAI
 */
tbool clHSA_SXM_STOCKS_Base::blBlIsStocksConfigured( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_STOCKS::blBlIsStocksConfigured not implemented"));
   return 0;
}

/**
 * Method: vGetDataProviderInfo
  * API to be called for displaying Data Provider Information.
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vGetDataProviderInfo(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vGetDataProviderInfo not implemented"));
   
}

/**
 * Method: ulwGetSXMStocksAdvisoryMessage
  * Returns the integer value corresponding to the current SXM advisory message.
  * NISSAN_KAI
 */
ulword clHSA_SXM_STOCKS_Base::ulwGetSXMStocksAdvisoryMessage( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_STOCKS::ulwGetSXMStocksAdvisoryMessage not implemented"));
   return 0;
}

/**
 * Method: blWaitSyncForStocks
  * Whether to wait for information or not.
  * NISSAN_KAI
 */
tbool clHSA_SXM_STOCKS_Base::blWaitSyncForStocks( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_STOCKS::blWaitSyncForStocks not implemented"));
   return 0;
}

/**
 * Method: blIsStocksAvailable
  * Whether the favorite stocks list is available or not.
  * NISSAN_KAI
 */
tbool clHSA_SXM_STOCKS_Base::blIsStocksAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_STOCKS::blIsStocksAvailable not implemented"));
   return 0;
}

/**
 * Method: blGetDataProviderInfoDisplayState
  * Data Provider Info needs to be displayed info or not
  * NISSAN_KAI
 */
tbool clHSA_SXM_STOCKS_Base::blGetDataProviderInfoDisplayState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_STOCKS::blGetDataProviderInfoDisplayState not implemented"));
   return 0;
}

/**
 * Method: blIsStocksIntialized
  * Whether Intializing pop up needed or not.
  * NISSAN_KAI
 */
tbool clHSA_SXM_STOCKS_Base::blIsStocksIntialized( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_STOCKS::blIsStocksIntialized not implemented"));
   return 0;
}

/**
 * Method: vRequestToGetFavStocksList
  * Request to get the favorite stocks list  .
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vRequestToGetFavStocksList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vRequestToGetFavStocksList not implemented"));
   
}

/**
 * Method: ulwGetCountForFavStocks
  * Returns the Number of Stocks in the Favorites list.
  * NISSAN_KAI
 */
ulword clHSA_SXM_STOCKS_Base::ulwGetCountForFavStocks( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_STOCKS::ulwGetCountForFavStocks not implemented"));
   return 0;
}

/**
 * Method: vGetFavStocksList
  * Request to get the Favorite Stocks list with information like stocks Name ,Price ,Change in value ,Change in percentage.
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vGetFavStocksList(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vGetFavStocksList not implemented"));
   
}

/**
 * Method: vGetListToRemoveStocksFromFavList
  * Shows the  Stocks list from the Favorites in order to remove.
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vGetListToRemoveStocksFromFavList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vGetListToRemoveStocksFromFavList not implemented"));
   
}

/**
 * Method: vSetSelectedStocksNameforRemove
  * Select the stocks symbol to be removed.
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vSetSelectedStocksNameforRemove(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vSetSelectedStocksNameforRemove not implemented"));
   
}

/**
 * Method: vGetSelectedStocksName
  * Return the selected Stock name from the Favorites.
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vGetSelectedStocksName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vGetSelectedStocksName not implemented"));
   
}

/**
 * Method: vRemoveStocksFromFavList
  * Remove the selected Stock from the Favorites.
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vRemoveStocksFromFavList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vRemoveStocksFromFavList not implemented"));
   
}

/**
 * Method: vRequestToEnableSpeller
  * Request to enable stocks speller  .
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vRequestToEnableSpeller( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vRequestToEnableSpeller not implemented"));
   
}

/**
 * Method: vSpellerCharacterInput
  * enter one character of  (speller input function)
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vSpellerCharacterInput(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vSpellerCharacterInput not implemented"));
   
}

/**
 * Method: vSpellerMatchGetFirst
  * API for filling the entry field with the characters input by the user
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vSpellerMatchGetFirst(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vSpellerMatchGetFirst not implemented"));
   
}

/**
 * Method: vRequestToGetStocksListForMatchedString
  * Request to get the Stocks list starting with the user typed string.
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vRequestToGetStocksListForMatchedString( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vRequestToGetStocksListForMatchedString not implemented"));
   
}

/**
 * Method: ulwGetCountOfStocksListForMatchedString
  * Returns the Number of Stocks from the stock list for matched string.
  * NISSAN_KAI
 */
ulword clHSA_SXM_STOCKS_Base::ulwGetCountOfStocksListForMatchedString( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_STOCKS::ulwGetCountOfStocksListForMatchedString not implemented"));
   return 0;
}

/**
 * Method: vGetStocksListForMatchedString
  * Shows the  Stocks from the stock list for matched string.
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vGetStocksListForMatchedString(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vGetStocksListForMatchedString not implemented"));
   
}

/**
 * Method: vAddToFavStocksList
  * Add the selected Stock from the stock list for matched string.
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vAddToFavStocksList(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vAddToFavStocksList not implemented"));
   
}

/**
 * Method: vSpellerMatchGetPossibleLetters
  * Shows the  string list that contains all letters which are possible to get the next valid match-result.
  * NISSAN_KAI
 */
void clHSA_SXM_STOCKS_Base::vSpellerMatchGetPossibleLetters(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_STOCKS::vSpellerMatchGetPossibleLetters not implemented"));
   
}

/**
 * Method: ulwSpellerGetCursorPos
  * Shows the  cursor position
  * NISSAN_KAI
 */
ulword clHSA_SXM_STOCKS_Base::ulwSpellerGetCursorPos( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_STOCKS::ulwSpellerGetCursorPos not implemented"));
   return 0;
}

/**
 * Method: blSpellerInvertGetLetterFunction
  * Inverts the logic of the SpellerGetLetterFunction. Has to be set by the application, for example in a freetext-speller, in order to disable some buttons and, at the same time, to enable the cursor-buttons and alt/sub/nr. 
  * B
 */
tbool clHSA_SXM_STOCKS_Base::blSpellerInvertGetLetterFunction( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_STOCKS::blSpellerInvertGetLetterFunction not implemented"));
   return 0;
}

/**
 * Method: ulwGetStocksAddStatus
  * Returns status wehther the stock is added,duplicate or not added .
  * NISSAN_KAI
 */
ulword clHSA_SXM_STOCKS_Base::ulwGetStocksAddStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_STOCKS::ulwGetStocksAddStatus not implemented"));
   return 0;
}

