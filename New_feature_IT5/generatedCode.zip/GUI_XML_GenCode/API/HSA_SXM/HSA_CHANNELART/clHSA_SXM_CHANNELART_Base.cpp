/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_SXM_CHANNELART_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_SXM/HSA_CHANNELART/clHSA_SXM_CHANNELART_Base.h"

clHSA_SXM_CHANNELART_Base* clHSA_SXM_CHANNELART_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_SXM_CHANNELART_Base.cpp.trc.h"
#endif


/**
 * Method: vGetSxmChannelArtImageId
  * Gets the file path of the channel art image
  * NISSANLCN2KAI
 */
void clHSA_SXM_CHANNELART_Base::vGetSxmChannelArtImageId(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_CHANNELART::vGetSxmChannelArtImageId not implemented"));
   
}

/**
 * Method: blGetSxmChannelArtImageVisibility
  * visibility status of the channel art image
  * NISSANLCN2KAI
 */
tbool clHSA_SXM_CHANNELART_Base::blGetSxmChannelArtImageVisibility( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_CHANNELART::blGetSxmChannelArtImageVisibility not implemented"));
   return 0;
}

