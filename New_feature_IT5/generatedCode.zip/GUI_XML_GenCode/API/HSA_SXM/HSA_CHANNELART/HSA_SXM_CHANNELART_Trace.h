/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_CHANNELART_Trace.h
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
#ifndef _HSA_SXM_CHANNELART_TRACE_H
#define _HSA_SXM_CHANNELART_TRACE_H
 

/**** Trace defines for HSA_SXM_CHANNELART ****/

#define HSA_API_ENTRYPOINT__GET_SXM_CHANNEL_ART_IMAGE_ID 0x1

#define HSA_API_ENTRYPOINT__GET_SXM_CHANNEL_ART_IMAGE_VISIBILITY 0x2

#endif  //#ifndef _HSA_SXM_CHANNELART_TRACE_H

