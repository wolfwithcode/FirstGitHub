/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_SXM_CHANNELART_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_SXM_CHANNELART_Base_H
#define _clHSA_SXM_CHANNELART_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_SXM_CHANNELART_Base : public clHSA_Base
{
public:

    static clHSA_SXM_CHANNELART_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_SXM_CHANNELART_Base()        {}

    virtual void vGetSxmChannelArtImageId(GUI_String *out_result);

    virtual tbool blGetSxmChannelArtImageVisibility( );

protected:
    clHSA_SXM_CHANNELART_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_SXM_CHANNELART_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_SXM_CHANNELART_Base_H

