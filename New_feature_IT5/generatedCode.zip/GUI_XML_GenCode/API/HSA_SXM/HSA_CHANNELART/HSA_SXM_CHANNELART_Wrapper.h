/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_CHANNELART_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_SXM_CHANNELART_Wrapper_H
#define _HSA_SXM_CHANNELART_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: GetSxmChannelArtImageId
 * NISSANLCN2KAI
 * NISSAN
 */
void HSA_SXM_CHANNELART__vGetSxmChannelArtImageId(GUI_String *out_result);

/**
 * Function: GetSxmChannelArtImageVisibility
 * NISSANLCN2KAI
 * NISSAN
 */
tbool HSA_SXM_CHANNELART__blGetSxmChannelArtImageVisibility( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_SXM_CHANNELART_H

