/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_SXM_MOVIES_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_SXM/HSA_MOVIES/clHSA_SXM_MOVIES_Base.h"

clHSA_SXM_MOVIES_Base* clHSA_SXM_MOVIES_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_SXM_MOVIES_Base.cpp.trc.h"
#endif


/**
 * Method: vStartSXMMovieRequest
  * API to be called on entering the Movies service
  * B
 */
void clHSA_SXM_MOVIES_Base::vStartSXMMovieRequest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vStartSXMMovieRequest not implemented"));
   
}

/**
 * Method: ulwGetSXMMoviesAdvisoryMessage
  *  Returns the integer value corresponding to the current SXM advisory. Returns 0 if there is no advisory message
  * NISSAN
 */
ulword clHSA_SXM_MOVIES_Base::ulwGetSXMMoviesAdvisoryMessage( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_MOVIES::ulwGetSXMMoviesAdvisoryMessage not implemented"));
   return 0;
}

/**
 * Method: blWaitSyncForTheaterAndMovies
  * Whether to wait for information or not.
  * NISSAN2.0
 */
tbool clHSA_SXM_MOVIES_Base::blWaitSyncForTheaterAndMovies( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_MOVIES::blWaitSyncForTheaterAndMovies not implemented"));
   return 0;
}

/**
 * Method: vRequestToGetTheaterList
  * Request to Get information of the Movie Theaters like Theater name, City name, distance and Direction.
  * B
 */
void clHSA_SXM_MOVIES_Base::vRequestToGetTheaterList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vRequestToGetTheaterList not implemented"));
   
}

/**
 * Method: ulwGetTheaterCount
  * Returns the number of Theaters in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_MOVIES_Base::ulwGetTheaterCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_MOVIES::ulwGetTheaterCount not implemented"));
   return 0;
}

/**
 * Method: vGetTheaterList
  * Get information of the Movie Theaters like Theater name, City name, distance and Direction.
  * B
 */
void clHSA_SXM_MOVIES_Base::vGetTheaterList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vGetTheaterList not implemented"));
   
}

/**
 * Method: vRequestToGetDetailsForSelectedTheater
  * Request to get the details of the selected theater in the Theater list.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vRequestToGetDetailsForSelectedTheater(ulword ulwListEntryNr, ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vRequestToGetDetailsForSelectedTheater not implemented"));
   
}

/**
 * Method: ulwGetTheaterListDistanceUnit
  * Returns the Distance unit to theater list items
  * NISSAN2.0
 */
ulword clHSA_SXM_MOVIES_Base::ulwGetTheaterListDistanceUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_MOVIES::ulwGetTheaterListDistanceUnit not implemented"));
   return 0;
}

/**
 * Method: vGetDetailsForSelectedTheater
  * Returns the full address of selected Theater in the list.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vGetDetailsForSelectedTheater(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vGetDetailsForSelectedTheater not implemented"));
   
}

/**
 * Method: blIsFavoriteTheater
  * To check whether the selected theater is present in Favorite list or not.
  * NISSAN2.0
 */
tbool clHSA_SXM_MOVIES_Base::blIsFavoriteTheater( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_MOVIES::blIsFavoriteTheater not implemented"));
   return 0;
}

/**
 * Method: vRequestToGetMoviesListForSelectedTheater
  * Request to get the list of Movies playing in a theater.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vRequestToGetMoviesListForSelectedTheater( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vRequestToGetMoviesListForSelectedTheater not implemented"));
   
}

/**
 * Method: ulwGetMoviesCount
  * Returns the number of Movies in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_MOVIES_Base::ulwGetMoviesCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_MOVIES::ulwGetMoviesCount not implemented"));
   return 0;
}

/**
 * Method: ulwGetMoviesDataAvailability
  * Tells whether the data is available or not
  * NISSAN2.0
 */
ulword clHSA_SXM_MOVIES_Base::ulwGetMoviesDataAvailability( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_MOVIES::ulwGetMoviesDataAvailability not implemented"));
   return 0;
}

/**
 * Method: vGetMoviesDetailsForSelectedTheater
  * Returns the selected movie details of selected Theater in the list.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vGetMoviesDetailsForSelectedTheater(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vGetMoviesDetailsForSelectedTheater not implemented"));
   
}

/**
 * Method: vGetTheaterName
  * Returns the name of the selected Theater in the list.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vGetTheaterName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vGetTheaterName not implemented"));
   
}

/**
 * Method: vRemoveTheaterFromFavoriteList
  * Remove the selected Theater entry from the Favorite list.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vRemoveTheaterFromFavoriteList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vRemoveTheaterFromFavoriteList not implemented"));
   
}

/**
 * Method: blIsFavoriteListFull
  * To check whether the Favorite Theater list is full or not.
  * NISSAN2.0
 */
tbool clHSA_SXM_MOVIES_Base::blIsFavoriteListFull( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_MOVIES::blIsFavoriteListFull not implemented"));
   return 0;
}

/**
 * Method: blIsFavoriteAvailable
  * To check whether the Favorite Theater list is empty or not.
  * NISSAN2.0
 */
tbool clHSA_SXM_MOVIES_Base::blIsFavoriteAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_MOVIES::blIsFavoriteAvailable not implemented"));
   return 0;
}

/**
 * Method: vSaveTheaterToFavoriteList
  * Save the selected Theater to the Favorites.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vSaveTheaterToFavoriteList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vSaveTheaterToFavoriteList not implemented"));
   
}

/**
 * Method: ulwGetFavoriteCountForTheater
  * Returns the number of Favorite Theaters in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_MOVIES_Base::ulwGetFavoriteCountForTheater( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_MOVIES::ulwGetFavoriteCountForTheater not implemented"));
   return 0;
}

/**
 * Method: vGetFavoriteTheaterList
  * Get list of the favorite Movie Theaters.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vGetFavoriteTheaterList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vGetFavoriteTheaterList not implemented"));
   
}

/**
 * Method: vReplaceTheaterInFavoriteList
  * Replace the selected Theater entry from the Favorite list.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vReplaceTheaterInFavoriteList(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vReplaceTheaterInFavoriteList not implemented"));
   
}

/**
 * Method: vRequestToGetFavoriteTheaterList
  * Request to Get the favourite theater list.
  * B
 */
void clHSA_SXM_MOVIES_Base::vRequestToGetFavoriteTheaterList(ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vRequestToGetFavoriteTheaterList not implemented"));
   
}

/**
 * Method: vRequestToGetMoviesList
  * Request to Get information of the Movies.
  * B
 */
void clHSA_SXM_MOVIES_Base::vRequestToGetMoviesList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vRequestToGetMoviesList not implemented"));
   
}

/**
 * Method: vGetMoviesList
  * Get name of the Movie and its rating 
  * B
 */
void clHSA_SXM_MOVIES_Base::vGetMoviesList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vGetMoviesList not implemented"));
   
}

/**
 * Method: vRequestToGetMoviesDetails
  * Returns the info of selected Movie in the list.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vRequestToGetMoviesDetails(ulword ulwListEntryNr, ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vRequestToGetMoviesDetails not implemented"));
   
}

/**
 * Method: vGetMoviesDetails
  * Returns the info of selected Movie in the list.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vGetMoviesDetails(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vGetMoviesDetails not implemented"));
   
}

/**
 * Method: vRequestToGetTheaterListForSelectedMovie
  * Request to Get the list of theaters for a selected Movie.
  * B
 */
void clHSA_SXM_MOVIES_Base::vRequestToGetTheaterListForSelectedMovie( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vRequestToGetTheaterListForSelectedMovie not implemented"));
   
}

/**
 * Method: vRequestToGetShowTimes
  * Request to Get the list of show times of a Movie.
  * B
 */
void clHSA_SXM_MOVIES_Base::vRequestToGetShowTimes( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vRequestToGetShowTimes not implemented"));
   
}

/**
 * Method: vGetShowTimes
  * Get information of the Movie Theaters like Theater name, City name, distance and Direction.
  * B
 */
void clHSA_SXM_MOVIES_Base::vGetShowTimes(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vGetShowTimes not implemented"));
   
}

/**
 * Method: vSpellerMatchGetFirst
  * API for filling the entry field with the characters input by the user
  * NISSAN_KAI
 */
void clHSA_SXM_MOVIES_Base::vSpellerMatchGetFirst(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vSpellerMatchGetFirst not implemented"));
   
}

/**
 * Method: vSpellerCharacterInput
  * enter one character of  (speller input function)
  * B
 */
void clHSA_SXM_MOVIES_Base::vSpellerCharacterInput(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vSpellerCharacterInput not implemented"));
   
}

/**
 * Method: blSpellerInvertGetLetterFunction
  * Inverts the logic of the SpellerGetLetterFunction. Has to be set by the application, for example in a freetext-speller, in order to disable some buttons and, at the same time, to enable the cursor-buttons and alt/sub/nr. 
  * B
 */
tbool clHSA_SXM_MOVIES_Base::blSpellerInvertGetLetterFunction( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_MOVIES::blSpellerInvertGetLetterFunction not implemented"));
   return 0;
}

/**
 * Method: ulwSpellerGetCursorPos
  * Shows the  cursor position
  * NISSAN_KAI
 */
ulword clHSA_SXM_MOVIES_Base::ulwSpellerGetCursorPos( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_MOVIES::ulwSpellerGetCursorPos not implemented"));
   return 0;
}

/**
 * Method: vSpellerMatchGetPossibleLetters
  * Shows the  string list that contains all letters which are possible to get the next valid match-result.
  * NISSAN_KAI
 */
void clHSA_SXM_MOVIES_Base::vSpellerMatchGetPossibleLetters(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vSpellerMatchGetPossibleLetters not implemented"));
   
}

/**
 * Method: vRequestToGetTheaterListForMatchedString
  * Request to get the Theater list starting with the user typed string.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vRequestToGetTheaterListForMatchedString( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vRequestToGetTheaterListForMatchedString not implemented"));
   
}

/**
 * Method: vRequestToGetMoviesListForMatchedString
  * Request to get the Movies list starting with the user typed string.
  * NISSAN2.0
 */
void clHSA_SXM_MOVIES_Base::vRequestToGetMoviesListForMatchedString( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vRequestToGetMoviesListForMatchedString not implemented"));
   
}

/**
 * Method: ulwGetCountOfTheaterListForMatchedString
  * Returns the Number of Theater from the theater list for matched string.
  * NISSAN2.0
 */
ulword clHSA_SXM_MOVIES_Base::ulwGetCountOfTheaterListForMatchedString( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_MOVIES::ulwGetCountOfTheaterListForMatchedString not implemented"));
   return 0;
}

/**
 * Method: ulwGetCountOfMoviesListForMatchedString
  * Returns the Number of Theater from the theater list for matched string.
  * NISSAN2.0
 */
ulword clHSA_SXM_MOVIES_Base::ulwGetCountOfMoviesListForMatchedString( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_MOVIES::ulwGetCountOfMoviesListForMatchedString not implemented"));
   return 0;
}

/**
 * Method: vGetTheaterListForMatchedString
  * Get information of the Movie Theaters like Theater name, City name, distance and Direction.
  * B
 */
void clHSA_SXM_MOVIES_Base::vGetTheaterListForMatchedString(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vGetTheaterListForMatchedString not implemented"));
   
}

/**
 * Method: vGetMoviesListForMatchedString
  * Get name of the Movie and its rating 
  * B
 */
void clHSA_SXM_MOVIES_Base::vGetMoviesListForMatchedString(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vGetMoviesListForMatchedString not implemented"));
   
}

/**
 * Method: vSpellerInitInput
  * Initialize a speller-item of the selected type
  * B
 */
void clHSA_SXM_MOVIES_Base::vSpellerInitInput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_MOVIES::vSpellerInitInput not implemented"));
   
}

