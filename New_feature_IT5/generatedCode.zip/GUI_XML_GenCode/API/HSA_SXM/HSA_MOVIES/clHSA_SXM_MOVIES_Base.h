/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_SXM_MOVIES_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_SXM_MOVIES_Base_H
#define _clHSA_SXM_MOVIES_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_SXM_MOVIES_Base : public clHSA_Base
{
public:

    static clHSA_SXM_MOVIES_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_SXM_MOVIES_Base()        {}

    virtual void vStartSXMMovieRequest( );

    virtual ulword ulwGetSXMMoviesAdvisoryMessage( );

    virtual tbool blWaitSyncForTheaterAndMovies( );

    virtual void vRequestToGetTheaterList( );

    virtual ulword ulwGetTheaterCount( );

    virtual void vGetTheaterList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vRequestToGetDetailsForSelectedTheater(ulword ulwListEntryNr, ulword ulwInfo_Type);

    virtual ulword ulwGetTheaterListDistanceUnit( );

    virtual void vGetDetailsForSelectedTheater(GUI_String *out_result);

    virtual tbool blIsFavoriteTheater( );

    virtual void vRequestToGetMoviesListForSelectedTheater( );

    virtual ulword ulwGetMoviesCount( );

    virtual ulword ulwGetMoviesDataAvailability( );

    virtual void vGetMoviesDetailsForSelectedTheater(GUI_String *out_result);

    virtual void vGetTheaterName(GUI_String *out_result);

    virtual void vRemoveTheaterFromFavoriteList( );

    virtual tbool blIsFavoriteListFull( );

    virtual tbool blIsFavoriteAvailable( );

    virtual void vSaveTheaterToFavoriteList( );

    virtual ulword ulwGetFavoriteCountForTheater( );

    virtual void vGetFavoriteTheaterList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vReplaceTheaterInFavoriteList(ulword ulwListEntryNr);

    virtual void vRequestToGetFavoriteTheaterList(ulword ulwInfo_Type);

    virtual void vRequestToGetMoviesList( );

    virtual void vGetMoviesList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vRequestToGetMoviesDetails(ulword ulwListEntryNr, ulword ulwInfo_Type);

    virtual void vGetMoviesDetails(GUI_String *out_result);

    virtual void vRequestToGetTheaterListForSelectedMovie( );

    virtual void vRequestToGetShowTimes( );

    virtual void vGetShowTimes(GUI_String *out_result);

    virtual void vSpellerMatchGetFirst(GUI_String *out_result);

    virtual void vSpellerCharacterInput(const GUI_String * InputString);

    virtual tbool blSpellerInvertGetLetterFunction( );

    virtual ulword ulwSpellerGetCursorPos( );

    virtual void vSpellerMatchGetPossibleLetters(GUI_String *out_result);

    virtual void vRequestToGetTheaterListForMatchedString( );

    virtual void vRequestToGetMoviesListForMatchedString( );

    virtual ulword ulwGetCountOfTheaterListForMatchedString( );

    virtual ulword ulwGetCountOfMoviesListForMatchedString( );

    virtual void vGetTheaterListForMatchedString(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vGetMoviesListForMatchedString(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

    virtual void vSpellerInitInput( );

protected:
    clHSA_SXM_MOVIES_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_SXM_MOVIES_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_SXM_MOVIES_Base_H

