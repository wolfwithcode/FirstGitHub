/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_MOVIES_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_SXM_MOVIES_Wrapper.h"
#include "clHSA_SXM_MOVIES_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_SXM_MOVIES_Trace.h"
#include "hmi_trace.h"

void HSA_SXM_MOVIES__vStartSXMMovieRequest( )
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__START_SXM_MOVIE_REQUEST  ) ); 
        }
      pInst->vStartSXMMovieRequest();

    }
}

ulword HSA_SXM_MOVIES__ulwGetSXMMoviesAdvisoryMessage( )
{
    ulword ret = 0;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_MOVIES_ADVISORY_MESSAGE  ) ); 
        }
      ret=pInst->ulwGetSXMMoviesAdvisoryMessage();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_MOVIES_ADVISORY_MESSAGE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_MOVIES__blWaitSyncForTheaterAndMovies( )
{
    tbool ret = false;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_THEATER_AND_MOVIES  ) ); 
        }
      ret=pInst->blWaitSyncForTheaterAndMovies();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_THEATER_AND_MOVIES | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_MOVIES__vRequestToGetTheaterList( )
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_THEATER_LIST  ) ); 
        }
      pInst->vRequestToGetTheaterList();

    }
}

ulword HSA_SXM_MOVIES__ulwGetTheaterCount( )
{
    ulword ret = 0;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_THEATER_COUNT  ) ); 
        }
      ret=pInst->ulwGetTheaterCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_THEATER_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_MOVIES__vGetTheaterList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_THEATER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_THEATER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetTheaterList(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_THEATER_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_MOVIES__vRequestToGetDetailsForSelectedTheater(ulword ulwListEntryNr, ulword ulwInfo_Type)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_DETAILS_FOR_SELECTED_THEATER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_DETAILS_FOR_SELECTED_THEATER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vRequestToGetDetailsForSelectedTheater(ulwListEntryNr, ulwInfo_Type);

    }
}

ulword HSA_SXM_MOVIES__ulwGetTheaterListDistanceUnit( )
{
    ulword ret = 0;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_THEATER_LIST_DISTANCE_UNIT  ) ); 
        }
      ret=pInst->ulwGetTheaterListDistanceUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_THEATER_LIST_DISTANCE_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_MOVIES__vGetDetailsForSelectedTheater(GUI_String *out_result)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_DETAILS_FOR_SELECTED_THEATER  ) ); 
        }
      pInst->vGetDetailsForSelectedTheater(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_DETAILS_FOR_SELECTED_THEATER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_SXM_MOVIES__blIsFavoriteTheater( )
{
    tbool ret = false;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__IS_FAVORITE_THEATER  ) ); 
        }
      ret=pInst->blIsFavoriteTheater();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__IS_FAVORITE_THEATER | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_MOVIES__vRequestToGetMoviesListForSelectedTheater( )
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_MOVIES_LIST_FOR_SELECTED_THEATER  ) ); 
        }
      pInst->vRequestToGetMoviesListForSelectedTheater();

    }
}

ulword HSA_SXM_MOVIES__ulwGetMoviesCount( )
{
    ulword ret = 0;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_COUNT  ) ); 
        }
      ret=pInst->ulwGetMoviesCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_MOVIES__ulwGetMoviesDataAvailability( )
{
    ulword ret = 0;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_DATA_AVAILABILITY  ) ); 
        }
      ret=pInst->ulwGetMoviesDataAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_DATA_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_MOVIES__vGetMoviesDetailsForSelectedTheater(GUI_String *out_result)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_DETAILS_FOR_SELECTED_THEATER  ) ); 
        }
      pInst->vGetMoviesDetailsForSelectedTheater(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_DETAILS_FOR_SELECTED_THEATER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_MOVIES__vGetTheaterName(GUI_String *out_result)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_THEATER_NAME  ) ); 
        }
      pInst->vGetTheaterName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_THEATER_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_MOVIES__vRemoveTheaterFromFavoriteList( )
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REMOVE_THEATER_FROM_FAVORITE_LIST  ) ); 
        }
      pInst->vRemoveTheaterFromFavoriteList();

    }
}

tbool HSA_SXM_MOVIES__blIsFavoriteListFull( )
{
    tbool ret = false;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__IS_FAVORITE_LIST_FULL  ) ); 
        }
      ret=pInst->blIsFavoriteListFull();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__IS_FAVORITE_LIST_FULL | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_MOVIES__blIsFavoriteAvailable( )
{
    tbool ret = false;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__IS_FAVORITE_AVAILABLE  ) ); 
        }
      ret=pInst->blIsFavoriteAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__IS_FAVORITE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_MOVIES__vSaveTheaterToFavoriteList( )
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__SAVE_THEATER_TO_FAVORITE_LIST  ) ); 
        }
      pInst->vSaveTheaterToFavoriteList();

    }
}

ulword HSA_SXM_MOVIES__ulwGetFavoriteCountForTheater( )
{
    ulword ret = 0;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_COUNT_FOR_THEATER  ) ); 
        }
      ret=pInst->ulwGetFavoriteCountForTheater();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_COUNT_FOR_THEATER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_MOVIES__vGetFavoriteTheaterList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_THEATER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_THEATER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetFavoriteTheaterList(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_THEATER_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_MOVIES__vReplaceTheaterInFavoriteList(ulword ulwListEntryNr)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REPLACE_THEATER_IN_FAVORITE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vReplaceTheaterInFavoriteList(ulwListEntryNr);

    }
}

void HSA_SXM_MOVIES__vRequestToGetFavoriteTheaterList(ulword ulwInfo_Type)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_FAVORITE_THEATER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vRequestToGetFavoriteTheaterList(ulwInfo_Type);

    }
}

void HSA_SXM_MOVIES__vRequestToGetMoviesList( )
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_MOVIES_LIST  ) ); 
        }
      pInst->vRequestToGetMoviesList();

    }
}

void HSA_SXM_MOVIES__vGetMoviesList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetMoviesList(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_MOVIES__vRequestToGetMoviesDetails(ulword ulwListEntryNr, ulword ulwInfo_Type)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_MOVIES_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_MOVIES_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vRequestToGetMoviesDetails(ulwListEntryNr, ulwInfo_Type);

    }
}

void HSA_SXM_MOVIES__vGetMoviesDetails(GUI_String *out_result)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_DETAILS  ) ); 
        }
      pInst->vGetMoviesDetails(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_DETAILS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_MOVIES__vRequestToGetTheaterListForSelectedMovie( )
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_THEATER_LIST_FOR_SELECTED_MOVIE  ) ); 
        }
      pInst->vRequestToGetTheaterListForSelectedMovie();

    }
}

void HSA_SXM_MOVIES__vRequestToGetShowTimes( )
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_SHOW_TIMES  ) ); 
        }
      pInst->vRequestToGetShowTimes();

    }
}

void HSA_SXM_MOVIES__vGetShowTimes(GUI_String *out_result)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_SHOW_TIMES  ) ); 
        }
      pInst->vGetShowTimes(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_SHOW_TIMES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_MOVIES__vSpellerMatchGetFirst(GUI_String *out_result)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_FIRST  ) ); 
        }
      pInst->vSpellerMatchGetFirst(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_FIRST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_MOVIES__vSpellerCharacterInput(const GUI_String * InputString)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__SPELLER_CHARACTER_INPUT | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSpellerCharacterInput( InputString);

    }
}

tbool HSA_SXM_MOVIES__blSpellerInvertGetLetterFunction( )
{
    tbool ret = false;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION  ) ); 
        }
      ret=pInst->blSpellerInvertGetLetterFunction();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_MOVIES__ulwSpellerGetCursorPos( )
{
    ulword ret = 0;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS  ) ); 
        }
      ret=pInst->ulwSpellerGetCursorPos();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_MOVIES__vSpellerMatchGetPossibleLetters(GUI_String *out_result)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_POSSIBLE_LETTERS  ) ); 
        }
      pInst->vSpellerMatchGetPossibleLetters(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_POSSIBLE_LETTERS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_MOVIES__vRequestToGetTheaterListForMatchedString( )
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_THEATER_LIST_FOR_MATCHED_STRING  ) ); 
        }
      pInst->vRequestToGetTheaterListForMatchedString();

    }
}

void HSA_SXM_MOVIES__vRequestToGetMoviesListForMatchedString( )
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_GET_MOVIES_LIST_FOR_MATCHED_STRING  ) ); 
        }
      pInst->vRequestToGetMoviesListForMatchedString();

    }
}

ulword HSA_SXM_MOVIES__ulwGetCountOfTheaterListForMatchedString( )
{
    ulword ret = 0;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_COUNT_OF_THEATER_LIST_FOR_MATCHED_STRING  ) ); 
        }
      ret=pInst->ulwGetCountOfTheaterListForMatchedString();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_COUNT_OF_THEATER_LIST_FOR_MATCHED_STRING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_MOVIES__ulwGetCountOfMoviesListForMatchedString( )
{
    ulword ret = 0;
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_COUNT_OF_MOVIES_LIST_FOR_MATCHED_STRING  ) ); 
        }
      ret=pInst->ulwGetCountOfMoviesListForMatchedString();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_COUNT_OF_MOVIES_LIST_FOR_MATCHED_STRING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_MOVIES__vGetTheaterListForMatchedString(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_THEATER_LIST_FOR_MATCHED_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_THEATER_LIST_FOR_MATCHED_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetTheaterListForMatchedString(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_THEATER_LIST_FOR_MATCHED_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_MOVIES__vGetMoviesListForMatchedString(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr)
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_LIST_FOR_MATCHED_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_LIST_FOR_MATCHED_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetMoviesListForMatchedString(out_result, ulwInfo_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__GET_MOVIES_LIST_FOR_MATCHED_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_MOVIES__vSpellerInitInput( )
{
    
    clHSA_SXM_MOVIES_Base *pInst=clHSA_SXM_MOVIES_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_MOVIES), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INIT_INPUT  ) ); 
        }
      pInst->vSpellerInitInput();

    }
}

#ifdef __cplusplus
}
#endif

