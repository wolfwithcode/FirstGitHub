/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_MOVIES_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_SXM_MOVIES_Wrapper_H
#define _HSA_SXM_MOVIES_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: StartSXMMovieRequest
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vStartSXMMovieRequest( void);

/**
 * Function: GetSXMMoviesAdvisoryMessage
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_MOVIES__ulwGetSXMMoviesAdvisoryMessage( void);

/**
 * Function: WaitSyncForTheaterAndMovies
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_MOVIES__blWaitSyncForTheaterAndMovies( void);

/**
 * Function: RequestToGetTheaterList
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vRequestToGetTheaterList( void);

/**
 * Function: GetTheaterCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_MOVIES__ulwGetTheaterCount( void);

/**
 * Function: GetTheaterList
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vGetTheaterList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: RequestToGetDetailsForSelectedTheater
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vRequestToGetDetailsForSelectedTheater(ulword ulwListEntryNr, ulword ulwInfo_Type);

/**
 * Function: GetTheaterListDistanceUnit
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_MOVIES__ulwGetTheaterListDistanceUnit( void);

/**
 * Function: GetDetailsForSelectedTheater
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vGetDetailsForSelectedTheater(GUI_String *out_result);

/**
 * Function: IsFavoriteTheater
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_MOVIES__blIsFavoriteTheater( void);

/**
 * Function: RequestToGetMoviesListForSelectedTheater
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vRequestToGetMoviesListForSelectedTheater( void);

/**
 * Function: GetMoviesCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_MOVIES__ulwGetMoviesCount( void);

/**
 * Function: GetMoviesDataAvailability
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_MOVIES__ulwGetMoviesDataAvailability( void);

/**
 * Function: GetMoviesDetailsForSelectedTheater
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vGetMoviesDetailsForSelectedTheater(GUI_String *out_result);

/**
 * Function: GetTheaterName
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vGetTheaterName(GUI_String *out_result);

/**
 * Function: RemoveTheaterFromFavoriteList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vRemoveTheaterFromFavoriteList( void);

/**
 * Function: IsFavoriteListFull
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_MOVIES__blIsFavoriteListFull( void);

/**
 * Function: IsFavoriteAvailable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_MOVIES__blIsFavoriteAvailable( void);

/**
 * Function: SaveTheaterToFavoriteList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vSaveTheaterToFavoriteList( void);

/**
 * Function: GetFavoriteCountForTheater
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_MOVIES__ulwGetFavoriteCountForTheater( void);

/**
 * Function: GetFavoriteTheaterList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vGetFavoriteTheaterList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: ReplaceTheaterInFavoriteList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vReplaceTheaterInFavoriteList(ulword ulwListEntryNr);

/**
 * Function: RequestToGetFavoriteTheaterList
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vRequestToGetFavoriteTheaterList(ulword ulwInfo_Type);

/**
 * Function: RequestToGetMoviesList
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vRequestToGetMoviesList( void);

/**
 * Function: GetMoviesList
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vGetMoviesList(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: RequestToGetMoviesDetails
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vRequestToGetMoviesDetails(ulword ulwListEntryNr, ulword ulwInfo_Type);

/**
 * Function: GetMoviesDetails
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vGetMoviesDetails(GUI_String *out_result);

/**
 * Function: RequestToGetTheaterListForSelectedMovie
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vRequestToGetTheaterListForSelectedMovie( void);

/**
 * Function: RequestToGetShowTimes
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vRequestToGetShowTimes( void);

/**
 * Function: GetShowTimes
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vGetShowTimes(GUI_String *out_result);

/**
 * Function: SpellerMatchGetFirst
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_MOVIES__vSpellerMatchGetFirst(GUI_String *out_result);

/**
 * Function: SpellerCharacterInput
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vSpellerCharacterInput(const GUI_String * InputString);

/**
 * Function: SpellerInvertGetLetterFunction
 * B
 * NISSAN
 */
tbool HSA_SXM_MOVIES__blSpellerInvertGetLetterFunction( void);

/**
 * Function: SpellerGetCursorPos
 * NISSAN_KAI
 * NISSAN
 */
ulword HSA_SXM_MOVIES__ulwSpellerGetCursorPos( void);

/**
 * Function: SpellerMatchGetPossibleLetters
 * NISSAN_KAI
 * NISSAN
 */
void HSA_SXM_MOVIES__vSpellerMatchGetPossibleLetters(GUI_String *out_result);

/**
 * Function: RequestToGetTheaterListForMatchedString
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vRequestToGetTheaterListForMatchedString( void);

/**
 * Function: RequestToGetMoviesListForMatchedString
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_MOVIES__vRequestToGetMoviesListForMatchedString( void);

/**
 * Function: GetCountOfTheaterListForMatchedString
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_MOVIES__ulwGetCountOfTheaterListForMatchedString( void);

/**
 * Function: GetCountOfMoviesListForMatchedString
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_MOVIES__ulwGetCountOfMoviesListForMatchedString( void);

/**
 * Function: GetTheaterListForMatchedString
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vGetTheaterListForMatchedString(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: GetMoviesListForMatchedString
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vGetMoviesListForMatchedString(GUI_String *out_result, ulword ulwInfo_Type, ulword ulwListEntryNr);

/**
 * Function: SpellerInitInput
 * B
 * NISSAN
 */
void HSA_SXM_MOVIES__vSpellerInitInput( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_SXM_MOVIES_H

