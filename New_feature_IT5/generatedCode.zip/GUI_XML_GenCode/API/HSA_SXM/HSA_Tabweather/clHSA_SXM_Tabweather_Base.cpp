/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_SXM_Tabweather_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_SXM/HSA_Tabweather/clHSA_SXM_Tabweather_Base.h"

clHSA_SXM_Tabweather_Base* clHSA_SXM_Tabweather_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_SXM_Tabweather_Base.cpp.trc.h"
#endif


/**
 * Method: vStartSXMWeatherRequest
  * To start the weather service
  * B
 */
void clHSA_SXM_Tabweather_Base::vStartSXMWeatherRequest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vStartSXMWeatherRequest not implemented"));
   
}

/**
 * Method: vSetSXMModeType
  * to set location type requested
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vSetSXMModeType(ulword ulwRequestLocationType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRequestLocationType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vSetSXMModeType not implemented"));
   
}

/**
 * Method: ulwGetSXMModeType
  * to get location type requested
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMModeType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMModeType not implemented"));
   return 0;
}

/**
 * Method: blWaitSyncForWeather
  * To get whether to wait for information or not.
  * NISSAN2.0
 */
tbool clHSA_SXM_Tabweather_Base::blWaitSyncForWeather( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SXM_Tabweather::blWaitSyncForWeather not implemented"));
   return 0;
}

/**
 * Method: vGetSXMWeatherCityName
  * Method to Read content from the list of Weather Info
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMWeatherCityName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMWeatherCityName not implemented"));
   
}

/**
 * Method: vGetSXMRequestWeatherStationName
  * Method to Read content from the list of Weather Info
  * Taken from LCN2
 */
void clHSA_SXM_Tabweather_Base::vGetSXMRequestWeatherStationName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMRequestWeatherStationName not implemented"));
   
}

/**
 * Method: ulwGetSXMCurrentWeatherCondition
  * Returns the current weather condition of the city.
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMCurrentWeatherCondition( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMCurrentWeatherCondition not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMThreeHourWeatherCondition
  * Returns the current weather condition of the city.
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMThreeHourWeatherCondition( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMThreeHourWeatherCondition not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMSixHourWeatherCondition
  * Returns the current weather condition of the city.
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMSixHourWeatherCondition( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMSixHourWeatherCondition not implemented"));
   return 0;
}

/**
 * Method: slwGetSXMCurrentWeatherTemp
  * Returns the current temperature of city for the specific date
  * NISSAN2.0
 */
slword clHSA_SXM_Tabweather_Base::slwGetSXMCurrentWeatherTemp( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_SXM_Tabweather::slwGetSXMCurrentWeatherTemp not implemented"));
   return 0;
}

/**
 * Method: slwGetSXMThreeHourWeatherTemp
  * Returns the current temperature of city for the specific date
  * NISSAN2.0
 */
slword clHSA_SXM_Tabweather_Base::slwGetSXMThreeHourWeatherTemp( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_SXM_Tabweather::slwGetSXMThreeHourWeatherTemp not implemented"));
   return 0;
}

/**
 * Method: slwGetSXMSixHourWeatherTemp
  * Returns the current temperature of city for the specific date
  * NISSAN2.0
 */
slword clHSA_SXM_Tabweather_Base::slwGetSXMSixHourWeatherTemp( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_SXM_Tabweather::slwGetSXMSixHourWeatherTemp not implemented"));
   return 0;
}

/**
 * Method: vGetSXMCurrentWeatherHumidity
  * Returns the humidity of city for the specific date
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMCurrentWeatherHumidity(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMCurrentWeatherHumidity not implemented"));
   
}

/**
 * Method: vGetSXMCurrentWeatherWindspeed
  * Returns the wind speed of city for the specific date
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMCurrentWeatherWindspeed(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMCurrentWeatherWindspeed not implemented"));
   
}

/**
 * Method: vGetSXMThreeHourWeatherWindspeed
  * Returns the wind speed of city for the specific date
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMThreeHourWeatherWindspeed(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMThreeHourWeatherWindspeed not implemented"));
   
}

/**
 * Method: vGetSXMSixHourWeatherWindspeed
  * Returns the wind speed of city for the specific date
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMSixHourWeatherWindspeed(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMSixHourWeatherWindspeed not implemented"));
   
}

/**
 * Method: ulwGetSXMCurrentWeatherWinddirection
  * Returns the wind direction of city for the specific date
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMCurrentWeatherWinddirection( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMCurrentWeatherWinddirection not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMThreeHourWeatherWinddirection
  * Returns the wind direction of city for the specific date
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMThreeHourWeatherWinddirection( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMThreeHourWeatherWinddirection not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMSixHourWeatherWinddirection
  * Returns the wind direction of city for the specific date
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMSixHourWeatherWinddirection( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMSixHourWeatherWinddirection not implemented"));
   return 0;
}

/**
 * Method: vGetSXMCurrentWeatherPrecipitationChance
  * Returns the precipitation chance of city for the specific date
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMCurrentWeatherPrecipitationChance(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMCurrentWeatherPrecipitationChance not implemented"));
   
}

/**
 * Method: vGetSXMThreeHourWeatherPrecipitationChance
  * Returns the precipitation chance of city for the specific date
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMThreeHourWeatherPrecipitationChance(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMThreeHourWeatherPrecipitationChance not implemented"));
   
}

/**
 * Method: vGetSXMSixHourWeatherPrecipitationChance
  * Returns the precipitation chance of city for the specific date
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMSixHourWeatherPrecipitationChance(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMSixHourWeatherPrecipitationChance not implemented"));
   
}

/**
 * Method: vGetSXMCurrentWeatherPrecipitationAmount
  * Returns the precipitation amount of city for the specific date
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMCurrentWeatherPrecipitationAmount(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMCurrentWeatherPrecipitationAmount not implemented"));
   
}

/**
 * Method: ulwGetSXMCurrentWeatherPollenLevel
  * Returns the pollen level of city for the specific date
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMCurrentWeatherPollenLevel( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMCurrentWeatherPollenLevel not implemented"));
   return 0;
}

/**
 * Method: vGetSXMCurrentWeatherUvIndex
  * Returns the UV Index of city for the specific date
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMCurrentWeatherUvIndex(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMCurrentWeatherUvIndex not implemented"));
   
}

/**
 * Method: ulwGetSXMCurrentWeatherAirQuality
  * Returns the Air Quality of city for the specific date
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMCurrentWeatherAirQuality( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMCurrentWeatherAirQuality not implemented"));
   return 0;
}

/**
 * Method: vGetSXMWeatherThreeHourForecastTime
  * Returns the Forecast time
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMWeatherThreeHourForecastTime(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMWeatherThreeHourForecastTime not implemented"));
   
}

/**
 * Method: vGetSXMWeatherSixHourForecastTime
  * Returns the Forecast time
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMWeatherSixHourForecastTime(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMWeatherSixHourForecastTime not implemented"));
   
}

/**
 * Method: ulwGetSXMForecastWeatherDayOfWeek
  * Returns the day of week for the specific date
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMForecastWeatherDayOfWeek(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMForecastWeatherDayOfWeek not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMForecastWeatherCondition
  * Returns the weather condition of the city for the specific date
  * Obsolete in LCN2
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMForecastWeatherCondition(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMForecastWeatherCondition not implemented"));
   return 0;
}

/**
 * Method: slwGetSXMWeatherRequestTempMax
  * Returns the max temperature of city for the specific date
  * Obsolete in LCN2
 */
slword clHSA_SXM_Tabweather_Base::slwGetSXMWeatherRequestTempMax(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_SXM_Tabweather::slwGetSXMWeatherRequestTempMax not implemented"));
   return 0;
}

/**
 * Method: slwGetSXMWeatherRequestTempMin
  * Returns the minimum temperature of city for the specific date
  * Obsolete in LCN2
 */
slword clHSA_SXM_Tabweather_Base::slwGetSXMWeatherRequestTempMin(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_SXM_Tabweather::slwGetSXMWeatherRequestTempMin not implemented"));
   return 0;
}

/**
 * Method: vGetFavoritesList
  * List of Favorite Weather Station
  * B
 */
void clHSA_SXM_Tabweather_Base::vGetFavoritesList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetFavoritesList not implemented"));
   
}

/**
 * Method: vGetDeleteFavoritesList
  * List of Favorite Weather Station 
  * B
 */
void clHSA_SXM_Tabweather_Base::vGetDeleteFavoritesList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetDeleteFavoritesList not implemented"));
   
}

/**
 * Method: ulwGetFavoriteCount
  * Returns the number of Favorites in the list.
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetFavoriteCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetFavoriteCount not implemented"));
   return 0;
}

/**
 * Method: vSaveToFavouriteWeatherList
  * .
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vSaveToFavouriteWeatherList(ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vSaveToFavouriteWeatherList not implemented"));
   
}

/**
 * Method: vRemoveFromFavouriteWeatherList
  * .
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vRemoveFromFavouriteWeatherList(ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vRemoveFromFavouriteWeatherList not implemented"));
   
}

/**
 * Method: vSelectFromFavouriteWeatherList
  * .
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vSelectFromFavouriteWeatherList(ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vSelectFromFavouriteWeatherList not implemented"));
   
}

/**
 * Method: blIsWeatherDataAvailable
  * To know weather data is available or not 
  * B
 */
tbool clHSA_SXM_Tabweather_Base::blIsWeatherDataAvailable(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_SXM_Tabweather::blIsWeatherDataAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsSXMHourDataAvailable
  * To know weather data is available or not 
  * B
 */
tbool clHSA_SXM_Tabweather_Base::blIsSXMHourDataAvailable(ulword ulwHour_Type, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwHour_Type);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_SXM_Tabweather::blIsSXMHourDataAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwIsAddFavSuccess
  * Get the status of add favorite
  * NISSAN
 */
ulword clHSA_SXM_Tabweather_Base::ulwIsAddFavSuccess( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwIsAddFavSuccess not implemented"));
   return 0;
}

/**
 * Method: vGetSXMWeatherFavoriteName
  * Method to Read content from the list of Weather Info
  * NISSAN2.0
 */
void clHSA_SXM_Tabweather_Base::vGetSXMWeatherFavoriteName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SXM_Tabweather::vGetSXMWeatherFavoriteName not implemented"));
   
}

/**
 * Method: ulwGetSXMWindSpeedUnit
  * Returns unit for wind speed
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMWindSpeedUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMWindSpeedUnit not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMPrecipitationUnit
  * Returns unit for precipitation amount
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMPrecipitationUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMPrecipitationUnit not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMWeatherDataAvailability
  * Get the availability of the data
  * NISSAN
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMWeatherDataAvailability(ulword ulwEventType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEventType);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMWeatherDataAvailability not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMCurrentUVRisk
  * Returns UV risk
  * NISSAN2.0
 */
ulword clHSA_SXM_Tabweather_Base::ulwGetSXMCurrentUVRisk( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SXM_Tabweather::ulwGetSXMCurrentUVRisk not implemented"));
   return 0;
}

