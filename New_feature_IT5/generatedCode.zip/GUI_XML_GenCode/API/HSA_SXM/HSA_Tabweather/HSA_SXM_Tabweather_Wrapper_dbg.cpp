/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_Tabweather_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_SXM_Tabweather_Wrapper_dbg.h"
#include "clHSA_SXM_Tabweather_Base.h"
#include "HSA_SXM_Tabweather_Trace.h"
#include "HSA_SXM_Tabweather_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_SXM_Tabweather_Wrapper_dbg::~clHSA_SXM_Tabweather_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_SXM_Tabweather_Wrapper_dbg::clHSA_SXM_Tabweather_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_SXM_Tabweather_Wrapper_dbg::clHSA_SXM_Tabweather_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_SXM_Tabweather_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_SXM_Tabweather_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__START_SXM_WEATHER_REQUEST:

            HSA_SXM_Tabweather__vStartSXMWeatherRequest();
            break;

        case HSA_API_ENTRYPOINT__SET_SXM_MODE_TYPE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_Tabweather__vSetSXMModeType(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_MODE_TYPE:

            HSA_SXM_Tabweather__ulwGetSXMModeType();
            break;

        case HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_WEATHER:

            HSA_SXM_Tabweather__blWaitSyncForWeather();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_WEATHER_CITY_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMWeatherCityName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_REQUEST_WEATHER_STATION_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMRequestWeatherStationName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_CONDITION:

            HSA_SXM_Tabweather__ulwGetSXMCurrentWeatherCondition();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_CONDITION:

            HSA_SXM_Tabweather__ulwGetSXMThreeHourWeatherCondition();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_CONDITION:

            HSA_SXM_Tabweather__ulwGetSXMSixHourWeatherCondition();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_TEMP:

            HSA_SXM_Tabweather__slwGetSXMCurrentWeatherTemp();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_TEMP:

            HSA_SXM_Tabweather__slwGetSXMThreeHourWeatherTemp();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_TEMP:

            HSA_SXM_Tabweather__slwGetSXMSixHourWeatherTemp();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_HUMIDITY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMCurrentWeatherHumidity(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_WINDSPEED:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMCurrentWeatherWindspeed(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_WINDSPEED:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMThreeHourWeatherWindspeed(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_WINDSPEED:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMSixHourWeatherWindspeed(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_WINDDIRECTION:

            HSA_SXM_Tabweather__ulwGetSXMCurrentWeatherWinddirection();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_WINDDIRECTION:

            HSA_SXM_Tabweather__ulwGetSXMThreeHourWeatherWinddirection();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_WINDDIRECTION:

            HSA_SXM_Tabweather__ulwGetSXMSixHourWeatherWinddirection();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_PRECIPITATION_CHANCE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMCurrentWeatherPrecipitationChance(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_PRECIPITATION_CHANCE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMThreeHourWeatherPrecipitationChance(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_PRECIPITATION_CHANCE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMSixHourWeatherPrecipitationChance(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_PRECIPITATION_AMOUNT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMCurrentWeatherPrecipitationAmount(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_POLLEN_LEVEL:

            HSA_SXM_Tabweather__ulwGetSXMCurrentWeatherPollenLevel();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_UV_INDEX:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMCurrentWeatherUvIndex(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_AIR_QUALITY:

            HSA_SXM_Tabweather__ulwGetSXMCurrentWeatherAirQuality();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_WEATHER_THREE_HOUR_FORECAST_TIME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMWeatherThreeHourForecastTime(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_WEATHER_SIX_HOUR_FORECAST_TIME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMWeatherSixHourForecastTime(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_FORECAST_WEATHER_DAY_OF_WEEK:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_Tabweather__ulwGetSXMForecastWeatherDayOfWeek(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_FORECAST_WEATHER_CONDITION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_Tabweather__ulwGetSXMForecastWeatherCondition(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_TEMP_MAX:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_Tabweather__slwGetSXMWeatherRequestTempMax(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_TEMP_MIN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_Tabweather__slwGetSXMWeatherRequestTempMin(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_FAVORITES_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_Tabweather__vGetFavoritesList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DELETE_FAVORITES_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_Tabweather__vGetDeleteFavoritesList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_FAVORITE_COUNT:

            HSA_SXM_Tabweather__ulwGetFavoriteCount();
            break;

        case HSA_API_ENTRYPOINT__SAVE_TO_FAVOURITE_WEATHER_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_Tabweather__vSaveToFavouriteWeatherList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__REMOVE_FROM_FAVOURITE_WEATHER_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_Tabweather__vRemoveFromFavouriteWeatherList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SELECT_FROM_FAVOURITE_WEATHER_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_Tabweather__vSelectFromFavouriteWeatherList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_WEATHER_DATA_AVAILABLE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_Tabweather__blIsWeatherDataAvailable(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_SXM_HOUR_DATA_AVAILABLE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SXM_Tabweather__blIsSXMHourDataAvailable(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__IS_ADD_FAV_SUCCESS:

            HSA_SXM_Tabweather__ulwIsAddFavSuccess();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_WEATHER_FAVORITE_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SXM_Tabweather__vGetSXMWeatherFavoriteName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_WIND_SPEED_UNIT:

            HSA_SXM_Tabweather__ulwGetSXMWindSpeedUnit();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_PRECIPITATION_UNIT:

            HSA_SXM_Tabweather__ulwGetSXMPrecipitationUnit();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_WEATHER_DATA_AVAILABILITY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SXM_Tabweather__ulwGetSXMWeatherDataAvailability(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_CURRENT_UV_RISK:

            HSA_SXM_Tabweather__ulwGetSXMCurrentUVRisk();
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

