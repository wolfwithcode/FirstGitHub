/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_Tabweather_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_SXM_Tabweather_Wrapper.h"
#include "clHSA_SXM_Tabweather_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_SXM_Tabweather_Trace.h"
#include "hmi_trace.h"

void HSA_SXM_Tabweather__vStartSXMWeatherRequest( )
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__START_SXM_WEATHER_REQUEST  ) ); 
        }
      pInst->vStartSXMWeatherRequest();

    }
}

void HSA_SXM_Tabweather__vSetSXMModeType(ulword ulwRequestLocationType)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__SET_SXM_MODE_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRequestLocationType); 
        }
      pInst->vSetSXMModeType(ulwRequestLocationType);

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMModeType( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_MODE_TYPE  ) ); 
        }
      ret=pInst->ulwGetSXMModeType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_MODE_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_Tabweather__blWaitSyncForWeather( )
{
    tbool ret = false;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_WEATHER  ) ); 
        }
      ret=pInst->blWaitSyncForWeather();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNC_FOR_WEATHER | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_Tabweather__vGetSXMWeatherCityName(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_CITY_NAME  ) ); 
        }
      pInst->vGetSXMWeatherCityName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_CITY_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_Tabweather__vGetSXMRequestWeatherStationName(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_REQUEST_WEATHER_STATION_NAME  ) ); 
        }
      pInst->vGetSXMRequestWeatherStationName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_REQUEST_WEATHER_STATION_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMCurrentWeatherCondition( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_CONDITION  ) ); 
        }
      ret=pInst->ulwGetSXMCurrentWeatherCondition();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_CONDITION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMThreeHourWeatherCondition( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_CONDITION  ) ); 
        }
      ret=pInst->ulwGetSXMThreeHourWeatherCondition();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_CONDITION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMSixHourWeatherCondition( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_CONDITION  ) ); 
        }
      ret=pInst->ulwGetSXMSixHourWeatherCondition();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_CONDITION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_SXM_Tabweather__slwGetSXMCurrentWeatherTemp( )
{
    slword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_TEMP  ) ); 
        }
      ret=pInst->slwGetSXMCurrentWeatherTemp();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_TEMP | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_SXM_Tabweather__slwGetSXMThreeHourWeatherTemp( )
{
    slword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_TEMP  ) ); 
        }
      ret=pInst->slwGetSXMThreeHourWeatherTemp();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_TEMP | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_SXM_Tabweather__slwGetSXMSixHourWeatherTemp( )
{
    slword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_TEMP  ) ); 
        }
      ret=pInst->slwGetSXMSixHourWeatherTemp();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_TEMP | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_Tabweather__vGetSXMCurrentWeatherHumidity(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_HUMIDITY  ) ); 
        }
      pInst->vGetSXMCurrentWeatherHumidity(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_HUMIDITY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_Tabweather__vGetSXMCurrentWeatherWindspeed(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_WINDSPEED  ) ); 
        }
      pInst->vGetSXMCurrentWeatherWindspeed(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_WINDSPEED | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_Tabweather__vGetSXMThreeHourWeatherWindspeed(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_WINDSPEED  ) ); 
        }
      pInst->vGetSXMThreeHourWeatherWindspeed(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_WINDSPEED | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_Tabweather__vGetSXMSixHourWeatherWindspeed(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_WINDSPEED  ) ); 
        }
      pInst->vGetSXMSixHourWeatherWindspeed(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_WINDSPEED | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMCurrentWeatherWinddirection( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_WINDDIRECTION  ) ); 
        }
      ret=pInst->ulwGetSXMCurrentWeatherWinddirection();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_WINDDIRECTION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMThreeHourWeatherWinddirection( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_WINDDIRECTION  ) ); 
        }
      ret=pInst->ulwGetSXMThreeHourWeatherWinddirection();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_WINDDIRECTION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMSixHourWeatherWinddirection( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_WINDDIRECTION  ) ); 
        }
      ret=pInst->ulwGetSXMSixHourWeatherWinddirection();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_WINDDIRECTION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_Tabweather__vGetSXMCurrentWeatherPrecipitationChance(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_PRECIPITATION_CHANCE  ) ); 
        }
      pInst->vGetSXMCurrentWeatherPrecipitationChance(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_PRECIPITATION_CHANCE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_Tabweather__vGetSXMThreeHourWeatherPrecipitationChance(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_PRECIPITATION_CHANCE  ) ); 
        }
      pInst->vGetSXMThreeHourWeatherPrecipitationChance(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_THREE_HOUR_WEATHER_PRECIPITATION_CHANCE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_Tabweather__vGetSXMSixHourWeatherPrecipitationChance(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_PRECIPITATION_CHANCE  ) ); 
        }
      pInst->vGetSXMSixHourWeatherPrecipitationChance(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SIX_HOUR_WEATHER_PRECIPITATION_CHANCE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_Tabweather__vGetSXMCurrentWeatherPrecipitationAmount(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_PRECIPITATION_AMOUNT  ) ); 
        }
      pInst->vGetSXMCurrentWeatherPrecipitationAmount(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_PRECIPITATION_AMOUNT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMCurrentWeatherPollenLevel( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_POLLEN_LEVEL  ) ); 
        }
      ret=pInst->ulwGetSXMCurrentWeatherPollenLevel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_POLLEN_LEVEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_Tabweather__vGetSXMCurrentWeatherUvIndex(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_UV_INDEX  ) ); 
        }
      pInst->vGetSXMCurrentWeatherUvIndex(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_UV_INDEX | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMCurrentWeatherAirQuality( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_AIR_QUALITY  ) ); 
        }
      ret=pInst->ulwGetSXMCurrentWeatherAirQuality();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_WEATHER_AIR_QUALITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_Tabweather__vGetSXMWeatherThreeHourForecastTime(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_THREE_HOUR_FORECAST_TIME  ) ); 
        }
      pInst->vGetSXMWeatherThreeHourForecastTime(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_THREE_HOUR_FORECAST_TIME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_Tabweather__vGetSXMWeatherSixHourForecastTime(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_SIX_HOUR_FORECAST_TIME  ) ); 
        }
      pInst->vGetSXMWeatherSixHourForecastTime(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_SIX_HOUR_FORECAST_TIME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMForecastWeatherDayOfWeek(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_FORECAST_WEATHER_DAY_OF_WEEK | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetSXMForecastWeatherDayOfWeek(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_FORECAST_WEATHER_DAY_OF_WEEK | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMForecastWeatherCondition(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_FORECAST_WEATHER_CONDITION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetSXMForecastWeatherCondition(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_FORECAST_WEATHER_CONDITION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_SXM_Tabweather__slwGetSXMWeatherRequestTempMax(ulword ulwListEntryNr)
{
    slword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_TEMP_MAX | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->slwGetSXMWeatherRequestTempMax(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_TEMP_MAX | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_SXM_Tabweather__slwGetSXMWeatherRequestTempMin(ulword ulwListEntryNr)
{
    slword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_TEMP_MIN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->slwGetSXMWeatherRequestTempMin(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_REQUEST_TEMP_MIN | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_Tabweather__vGetFavoritesList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITES_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetFavoritesList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITES_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SXM_Tabweather__vGetDeleteFavoritesList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_DELETE_FAVORITES_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDeleteFavoritesList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_DELETE_FAVORITES_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_Tabweather__ulwGetFavoriteCount( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_COUNT  ) ); 
        }
      ret=pInst->ulwGetFavoriteCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_FAVORITE_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_Tabweather__vSaveToFavouriteWeatherList(ulword ulwListindex)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__SAVE_TO_FAVOURITE_WEATHER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vSaveToFavouriteWeatherList(ulwListindex);

    }
}

void HSA_SXM_Tabweather__vRemoveFromFavouriteWeatherList(ulword ulwListindex)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__REMOVE_FROM_FAVOURITE_WEATHER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vRemoveFromFavouriteWeatherList(ulwListindex);

    }
}

void HSA_SXM_Tabweather__vSelectFromFavouriteWeatherList(ulword ulwListindex)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__SELECT_FROM_FAVOURITE_WEATHER_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vSelectFromFavouriteWeatherList(ulwListindex);

    }
}

tbool HSA_SXM_Tabweather__blIsWeatherDataAvailable(ulword ulwListEntryNr)
{
    tbool ret = false;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__IS_WEATHER_DATA_AVAILABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->blIsWeatherDataAvailable(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__IS_WEATHER_DATA_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_SXM_Tabweather__blIsSXMHourDataAvailable(ulword ulwHour_Type, ulword ulwListEntryNr)
{
    tbool ret = false;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__IS_SXM_HOUR_DATA_AVAILABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwHour_Type); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__IS_SXM_HOUR_DATA_AVAILABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->blIsSXMHourDataAvailable(ulwHour_Type, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__IS_SXM_HOUR_DATA_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_Tabweather__ulwIsAddFavSuccess( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__IS_ADD_FAV_SUCCESS  ) ); 
        }
      ret=pInst->ulwIsAddFavSuccess();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__IS_ADD_FAV_SUCCESS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SXM_Tabweather__vGetSXMWeatherFavoriteName(GUI_String *out_result)
{
    
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_FAVORITE_NAME  ) ); 
        }
      pInst->vGetSXMWeatherFavoriteName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_FAVORITE_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMWindSpeedUnit( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WIND_SPEED_UNIT  ) ); 
        }
      ret=pInst->ulwGetSXMWindSpeedUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WIND_SPEED_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMPrecipitationUnit( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_PRECIPITATION_UNIT  ) ); 
        }
      ret=pInst->ulwGetSXMPrecipitationUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_PRECIPITATION_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMWeatherDataAvailability(ulword ulwEventType)
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_DATA_AVAILABILITY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEventType); 
        }
      ret=pInst->ulwGetSXMWeatherDataAvailability(ulwEventType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_WEATHER_DATA_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SXM_Tabweather__ulwGetSXMCurrentUVRisk( )
{
    ulword ret = 0;
    clHSA_SXM_Tabweather_Base *pInst=clHSA_SXM_Tabweather_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_UV_RISK  ) ); 
        }
      ret=pInst->ulwGetSXMCurrentUVRisk();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SXM_TABWEATHER), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_CURRENT_UV_RISK | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

#ifdef __cplusplus
}
#endif

