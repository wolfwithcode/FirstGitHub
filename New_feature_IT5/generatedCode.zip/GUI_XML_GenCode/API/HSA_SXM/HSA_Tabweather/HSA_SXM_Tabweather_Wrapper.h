/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SXM_Tabweather_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_SXM_Tabweather_Wrapper_H
#define _HSA_SXM_Tabweather_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: StartSXMWeatherRequest
 * B
 * NISSAN
 */
void HSA_SXM_Tabweather__vStartSXMWeatherRequest( void);

/**
 * Function: SetSXMModeType
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vSetSXMModeType(ulword ulwRequestLocationType);

/**
 * Function: GetSXMModeType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMModeType( void);

/**
 * Function: WaitSyncForWeather
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SXM_Tabweather__blWaitSyncForWeather( void);

/**
 * Function: GetSXMWeatherCityName
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMWeatherCityName(GUI_String *out_result);

/**
 * Function: GetSXMRequestWeatherStationName
 * Taken from LCN2
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMRequestWeatherStationName(GUI_String *out_result);

/**
 * Function: GetSXMCurrentWeatherCondition
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMCurrentWeatherCondition( void);

/**
 * Function: GetSXMThreeHourWeatherCondition
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMThreeHourWeatherCondition( void);

/**
 * Function: GetSXMSixHourWeatherCondition
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMSixHourWeatherCondition( void);

/**
 * Function: GetSXMCurrentWeatherTemp
 * NISSAN2.0
 * NISSAN
 */
slword HSA_SXM_Tabweather__slwGetSXMCurrentWeatherTemp( void);

/**
 * Function: GetSXMThreeHourWeatherTemp
 * NISSAN2.0
 * NISSAN
 */
slword HSA_SXM_Tabweather__slwGetSXMThreeHourWeatherTemp( void);

/**
 * Function: GetSXMSixHourWeatherTemp
 * NISSAN2.0
 * NISSAN
 */
slword HSA_SXM_Tabweather__slwGetSXMSixHourWeatherTemp( void);

/**
 * Function: GetSXMCurrentWeatherHumidity
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMCurrentWeatherHumidity(GUI_String *out_result);

/**
 * Function: GetSXMCurrentWeatherWindspeed
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMCurrentWeatherWindspeed(GUI_String *out_result);

/**
 * Function: GetSXMThreeHourWeatherWindspeed
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMThreeHourWeatherWindspeed(GUI_String *out_result);

/**
 * Function: GetSXMSixHourWeatherWindspeed
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMSixHourWeatherWindspeed(GUI_String *out_result);

/**
 * Function: GetSXMCurrentWeatherWinddirection
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMCurrentWeatherWinddirection( void);

/**
 * Function: GetSXMThreeHourWeatherWinddirection
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMThreeHourWeatherWinddirection( void);

/**
 * Function: GetSXMSixHourWeatherWinddirection
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMSixHourWeatherWinddirection( void);

/**
 * Function: GetSXMCurrentWeatherPrecipitationChance
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMCurrentWeatherPrecipitationChance(GUI_String *out_result);

/**
 * Function: GetSXMThreeHourWeatherPrecipitationChance
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMThreeHourWeatherPrecipitationChance(GUI_String *out_result);

/**
 * Function: GetSXMSixHourWeatherPrecipitationChance
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMSixHourWeatherPrecipitationChance(GUI_String *out_result);

/**
 * Function: GetSXMCurrentWeatherPrecipitationAmount
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMCurrentWeatherPrecipitationAmount(GUI_String *out_result);

/**
 * Function: GetSXMCurrentWeatherPollenLevel
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMCurrentWeatherPollenLevel( void);

/**
 * Function: GetSXMCurrentWeatherUvIndex
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMCurrentWeatherUvIndex(GUI_String *out_result);

/**
 * Function: GetSXMCurrentWeatherAirQuality
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMCurrentWeatherAirQuality( void);

/**
 * Function: GetSXMWeatherThreeHourForecastTime
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMWeatherThreeHourForecastTime(GUI_String *out_result);

/**
 * Function: GetSXMWeatherSixHourForecastTime
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMWeatherSixHourForecastTime(GUI_String *out_result);

/**
 * Function: GetSXMForecastWeatherDayOfWeek
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMForecastWeatherDayOfWeek(ulword ulwListEntryNr);

/**
 * Function: GetSXMForecastWeatherCondition
 * Obsolete in LCN2
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMForecastWeatherCondition(ulword ulwListEntryNr);

/**
 * Function: GetSXMWeatherRequestTempMax
 * Obsolete in LCN2
 * NISSAN
 */
slword HSA_SXM_Tabweather__slwGetSXMWeatherRequestTempMax(ulword ulwListEntryNr);

/**
 * Function: GetSXMWeatherRequestTempMin
 * Obsolete in LCN2
 * NISSAN
 */
slword HSA_SXM_Tabweather__slwGetSXMWeatherRequestTempMin(ulword ulwListEntryNr);

/**
 * Function: GetFavoritesList
 * B
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetFavoritesList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetDeleteFavoritesList
 * B
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetDeleteFavoritesList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetFavoriteCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetFavoriteCount( void);

/**
 * Function: SaveToFavouriteWeatherList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vSaveToFavouriteWeatherList(ulword ulwListindex);

/**
 * Function: RemoveFromFavouriteWeatherList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vRemoveFromFavouriteWeatherList(ulword ulwListindex);

/**
 * Function: SelectFromFavouriteWeatherList
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vSelectFromFavouriteWeatherList(ulword ulwListindex);

/**
 * Function: IsWeatherDataAvailable
 * B
 * NISSAN
 */
tbool HSA_SXM_Tabweather__blIsWeatherDataAvailable(ulword ulwListEntryNr);

/**
 * Function: IsSXMHourDataAvailable
 * B
 * NISSAN
 */
tbool HSA_SXM_Tabweather__blIsSXMHourDataAvailable(ulword ulwHour_Type, ulword ulwListEntryNr);

/**
 * Function: IsAddFavSuccess
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwIsAddFavSuccess( void);

/**
 * Function: GetSXMWeatherFavoriteName
 * NISSAN2.0
 * NISSAN
 */
void HSA_SXM_Tabweather__vGetSXMWeatherFavoriteName(GUI_String *out_result);

/**
 * Function: GetSXMWindSpeedUnit
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMWindSpeedUnit( void);

/**
 * Function: GetSXMPrecipitationUnit
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMPrecipitationUnit( void);

/**
 * Function: GetSXMWeatherDataAvailability
 * NISSAN
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMWeatherDataAvailability(ulword ulwEventType);

/**
 * Function: GetSXMCurrentUVRisk
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_SXM_Tabweather__ulwGetSXMCurrentUVRisk( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_SXM_Tabweather_H

