/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_SXM_Tabweather_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_SXM_Tabweather_Base_H
#define _clHSA_SXM_Tabweather_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_SXM_Tabweather_Base : public clHSA_Base
{
public:

    static clHSA_SXM_Tabweather_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_SXM_Tabweather_Base()        {}

    virtual void vStartSXMWeatherRequest( );

    virtual void vSetSXMModeType(ulword ulwRequestLocationType);

    virtual ulword ulwGetSXMModeType( );

    virtual tbool blWaitSyncForWeather( );

    virtual void vGetSXMWeatherCityName(GUI_String *out_result);

    virtual void vGetSXMRequestWeatherStationName(GUI_String *out_result);

    virtual ulword ulwGetSXMCurrentWeatherCondition( );

    virtual ulword ulwGetSXMThreeHourWeatherCondition( );

    virtual ulword ulwGetSXMSixHourWeatherCondition( );

    virtual slword slwGetSXMCurrentWeatherTemp( );

    virtual slword slwGetSXMThreeHourWeatherTemp( );

    virtual slword slwGetSXMSixHourWeatherTemp( );

    virtual void vGetSXMCurrentWeatherHumidity(GUI_String *out_result);

    virtual void vGetSXMCurrentWeatherWindspeed(GUI_String *out_result);

    virtual void vGetSXMThreeHourWeatherWindspeed(GUI_String *out_result);

    virtual void vGetSXMSixHourWeatherWindspeed(GUI_String *out_result);

    virtual ulword ulwGetSXMCurrentWeatherWinddirection( );

    virtual ulword ulwGetSXMThreeHourWeatherWinddirection( );

    virtual ulword ulwGetSXMSixHourWeatherWinddirection( );

    virtual void vGetSXMCurrentWeatherPrecipitationChance(GUI_String *out_result);

    virtual void vGetSXMThreeHourWeatherPrecipitationChance(GUI_String *out_result);

    virtual void vGetSXMSixHourWeatherPrecipitationChance(GUI_String *out_result);

    virtual void vGetSXMCurrentWeatherPrecipitationAmount(GUI_String *out_result);

    virtual ulword ulwGetSXMCurrentWeatherPollenLevel( );

    virtual void vGetSXMCurrentWeatherUvIndex(GUI_String *out_result);

    virtual ulword ulwGetSXMCurrentWeatherAirQuality( );

    virtual void vGetSXMWeatherThreeHourForecastTime(GUI_String *out_result);

    virtual void vGetSXMWeatherSixHourForecastTime(GUI_String *out_result);

    virtual ulword ulwGetSXMForecastWeatherDayOfWeek(ulword ulwListEntryNr);

    virtual ulword ulwGetSXMForecastWeatherCondition(ulword ulwListEntryNr);

    virtual slword slwGetSXMWeatherRequestTempMax(ulword ulwListEntryNr);

    virtual slword slwGetSXMWeatherRequestTempMin(ulword ulwListEntryNr);

    virtual void vGetFavoritesList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetDeleteFavoritesList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetFavoriteCount( );

    virtual void vSaveToFavouriteWeatherList(ulword ulwListindex);

    virtual void vRemoveFromFavouriteWeatherList(ulword ulwListindex);

    virtual void vSelectFromFavouriteWeatherList(ulword ulwListindex);

    virtual tbool blIsWeatherDataAvailable(ulword ulwListEntryNr);

    virtual tbool blIsSXMHourDataAvailable(ulword ulwHour_Type, ulword ulwListEntryNr);

    virtual ulword ulwIsAddFavSuccess( );

    virtual void vGetSXMWeatherFavoriteName(GUI_String *out_result);

    virtual ulword ulwGetSXMWindSpeedUnit( );

    virtual ulword ulwGetSXMPrecipitationUnit( );

    virtual ulword ulwGetSXMWeatherDataAvailability(ulword ulwEventType);

    virtual ulword ulwGetSXMCurrentUVRisk( );

protected:
    clHSA_SXM_Tabweather_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_SXM_Tabweather_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_SXM_Tabweather_Base_H

