/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_Traffic_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_Traffic/clHSA_Traffic_Base.h"

clHSA_Traffic_Base* clHSA_Traffic_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_Traffic_Base.cpp.trc.h"
#endif


/**
 * Method: vTMCToggleAcousticWarningsOutput
  * Toggles the acoustic output of Traffic warning messages to on/off based on user settings
  * NISSAN 2.0
 */
void clHSA_Traffic_Base::vTMCToggleAcousticWarningsOutput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCToggleAcousticWarningsOutput not implemented"));
   
}

/**
 * Method: blTMCGetAcousticWarningsOutput
  * Returns the user setting for acoustic output of Traffic warning messages
  * NISSAN 2.0
 */
tbool clHSA_Traffic_Base::blTMCGetAcousticWarningsOutput( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Traffic::blTMCGetAcousticWarningsOutput not implemented"));
   return 0;
}

/**
 * Method: vTMCToggleShowIncident
  * toggles the show incident option to on/off based on user setting
  * NISSAN NAR
 */
void clHSA_Traffic_Base::vTMCToggleShowIncident( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCToggleShowIncident not implemented"));
   
}

/**
 * Method: blTMCGetShowIncident
  * Returns the Show incident option either on/off
  * NISSAN NAR
 */
tbool clHSA_Traffic_Base::blTMCGetShowIncident( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Traffic::blTMCGetShowIncident not implemented"));
   return 0;
}

/**
 * Method: ulwTMCCheckServiceAvailable
  * Gets the state whether service is available or not
  * NISSAN NAR
 */
ulword clHSA_Traffic_Base::ulwTMCCheckServiceAvailable( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Traffic::ulwTMCCheckServiceAvailable not implemented"));
   return 0;
}

/**
 * Method: vTMCToggleTrafficFlow
  * toggles the traffic flow option to on/off based on user setting
  * NISSAN NAR
 */
void clHSA_Traffic_Base::vTMCToggleTrafficFlow( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCToggleTrafficFlow not implemented"));
   
}

/**
 * Method: blTMCGetTrafficFlow
  * Returns the traffic flow option either on/off
  * NISSAN NAR
 */
tbool clHSA_Traffic_Base::blTMCGetTrafficFlow( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Traffic::blTMCGetTrafficFlow not implemented"));
   return 0;
}

/**
 * Method: vRequestOnRouteMessages
  * limits to get the TMC messages only on route 
  * NISSAN
 */
void clHSA_Traffic_Base::vRequestOnRouteMessages( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vRequestOnRouteMessages not implemented"));
   
}

/**
 * Method: vTMCActivateMessage
  * selects a message in the list to get information using TMCGetCurrentMessageInfo
  * B2
 */
void clHSA_Traffic_Base::vTMCActivateMessage(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCActivateMessage not implemented"));
   
}

/**
 * Method: vTMCActivateNextMessage
  * selects the next message in TMC-list, does nothing if currently the last was selected
  * B2
 */
void clHSA_Traffic_Base::vTMCActivateNextMessage( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCActivateNextMessage not implemented"));
   
}

/**
 * Method: vTMCActivatePrevMessage
  * selects the previous message in TMC-list, does nothing if currently the first was selected
  * B2
 */
void clHSA_Traffic_Base::vTMCActivatePrevMessage( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCActivatePrevMessage not implemented"));
   
}

/**
 * Method: ulwTMCGetCurrentItemIndex
  * get the current item index of TMC Overview List
  * B2
 */
ulword clHSA_Traffic_Base::ulwTMCGetCurrentItemIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Traffic::ulwTMCGetCurrentItemIndex not implemented"));
   return 0;
}

/**
 * Method: vTMCGetCurrentMessageInfo
  * Resolves information about the by TMCActivateMessage activated TMC-message
  * B2
 */
void clHSA_Traffic_Base::vTMCGetCurrentMessageInfo(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCGetCurrentMessageInfo not implemented"));
   
}

/**
 * Method: vTMCGetCurrentMessageInfoSourceTime
  * Returns information about the source time for the  TMCActivateMessage activated TMC-message
  * B2
 */
void clHSA_Traffic_Base::vTMCGetCurrentMessageInfoSourceTime(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCGetCurrentMessageInfoSourceTime not implemented"));
   
}

/**
 * Method: vTMCGetCurrentMessageInfoSourceDate
  * Returns information about the source date for the  TMCActivateMessage activated TMC-message
  * B
 */
void clHSA_Traffic_Base::vTMCGetCurrentMessageInfoSourceDate(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCGetCurrentMessageInfoSourceDate not implemented"));
   
}

/**
 * Method: vTMCGetCurrentMessageInfoSourceStation
  * Returns information about the source station for the  TMCActivateMessage activated TMC-message
  * B2
 */
void clHSA_Traffic_Base::vTMCGetCurrentMessageInfoSourceStation(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCGetCurrentMessageInfoSourceStation not implemented"));
   
}

/**
 * Method: vTMCGetMessageList
  * Get the TMC message list
  * B2
 */
void clHSA_Traffic_Base::vTMCGetMessageList(GUI_String *out_result, ulword ulwLine, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLine);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCGetMessageList not implemented"));
   
}

/**
 * Method: ulwTMCGetCurrentMessageIconLabelIndex
  * Get the TMC message list icon as an index to the png image to be displayed.
  * B2
 */
ulword clHSA_Traffic_Base::ulwTMCGetCurrentMessageIconLabelIndex(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Traffic::ulwTMCGetCurrentMessageIconLabelIndex not implemented"));
   return 0;
}

/**
 * Method: ulwTMCGetTrafficListHeading
  * Get the heading  or direction of the selected trafficmessage
  * nissan
 */
ulword clHSA_Traffic_Base::ulwTMCGetTrafficListHeading(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Traffic::ulwTMCGetTrafficListHeading not implemented"));
   return 0;
}

/**
 * Method: vTMCGetTrafficDistance
  * Get the air or onroute distances for the  traffic messages
  * nissan
 */
void clHSA_Traffic_Base::vTMCGetTrafficDistance(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCGetTrafficDistance not implemented"));
   
}

/**
 * Method: ulwTrafficDistanceGetListUnit
  * Returns the Distance unit to traffic  list 
  * nissan
 */
ulword clHSA_Traffic_Base::ulwTrafficDistanceGetListUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Traffic::ulwTrafficDistanceGetListUnit not implemented"));
   return 0;
}

/**
 * Method: ulwTMCGetMessageCount
  * gets the number of items in the TMC-List
  * B2
 */
ulword clHSA_Traffic_Base::ulwTMCGetMessageCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Traffic::ulwTMCGetMessageCount not implemented"));
   return 0;
}

/**
 * Method: vTMCGetMessageCountasString
  * gets the number of items in the TMC-List
  * B2
 */
void clHSA_Traffic_Base::vTMCGetMessageCountasString(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCGetMessageCountasString not implemented"));
   
}

/**
 * Method: vTMCGetXUrgentMessage
  * gets the information about the current X-Urgent message
  * B
 */
void clHSA_Traffic_Base::vTMCGetXUrgentMessage(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCGetXUrgentMessage not implemented"));
   
}

/**
 * Method: blTMCIsFirstMessage
  * Returns wheather the current TMC-Message is the FIRST message
  * B2
 */
tbool clHSA_Traffic_Base::blTMCIsFirstMessage( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Traffic::blTMCIsFirstMessage not implemented"));
   return 0;
}

/**
 * Method: blTMCIsLastMessage
  * Returns wheather the current TMC-Message is the LAST message
  * B2
 */
tbool clHSA_Traffic_Base::blTMCIsLastMessage( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Traffic::blTMCIsLastMessage not implemented"));
   return 0;
}

/**
 * Method: blTMCIsCongestionDefined
  * Returns wheather a congestion is already defined
  * B2
 */
tbool clHSA_Traffic_Base::blTMCIsCongestionDefined( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Traffic::blTMCIsCongestionDefined not implemented"));
   return 0;
}

/**
 * Method: blTMCIsMSGAvailableForSegment
  * Returns wheather tmc messages are available for the current segment in route maneuver list
  * B
 */
tbool clHSA_Traffic_Base::blTMCIsMSGAvailableForSegment( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Traffic::blTMCIsMSGAvailableForSegment not implemented"));
   return 0;
}

/**
 * Method: vTMCActivateMessageForSegment
  * activates the tmc msg, which are available for the current segment in route maneuver list
  * B
 */
void clHSA_Traffic_Base::vTMCActivateMessageForSegment( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCActivateMessageForSegment not implemented"));
   
}

/**
 * Method: vTMCDeleteCongestion
  * Deletes the current activated congestion
  * B2
 */
void clHSA_Traffic_Base::vTMCDeleteCongestion( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCDeleteCongestion not implemented"));
   
}

/**
 * Method: ulwTMCListUpdateOperating
  * Gets the state, whether Listupdate mechanism is currently operating.
  * B
 */
ulword clHSA_Traffic_Base::ulwTMCListUpdateOperating( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Traffic::ulwTMCListUpdateOperating not implemented"));
   return 0;
}

/**
 * Method: ulwTMCListUpdateAvailable
  * Gets the state, whether Listupdate is available or not
  * B
 */
ulword clHSA_Traffic_Base::ulwTMCListUpdateAvailable( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Traffic::ulwTMCListUpdateAvailable not implemented"));
   return 0;
}

/**
 * Method: vTMCUpdateList
  * triggers the state of the TMC-List to busy
  * B2
 */
void clHSA_Traffic_Base::vTMCUpdateList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCUpdateList not implemented"));
   
}

/**
 * Method: vTMCEndUpdateList
  * stops updating the traffic list
  * B2
 */
void clHSA_Traffic_Base::vTMCEndUpdateList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCEndUpdateList not implemented"));
   
}

/**
 * Method: vTMCSetTimerValues
  * sets the timeout values for the systemevent TRAFFIC_TMC_UPDATE_MESSAGELIST and TRAFFIC_TMC_NO_USER_ACTIONS
  * B2
 */
void clHSA_Traffic_Base::vTMCSetTimerValues(ulword ulwTimer, ulword ulwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTimer);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCSetTimerValues not implemented"));
   
}

/**
 * Method: vTMCResetTimerValues
  * Resets the timeout values to default for the systemevent TRAFFIC_TMC_UPDATE_MESSAGELIST and TRAFFIC_TMC_NO_USER_ACTIONS
  * B2
 */
void clHSA_Traffic_Base::vTMCResetTimerValues(ulword ulwTimer)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTimer);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCResetTimerValues not implemented"));
   
}

/**
 * Method: vTMCRequestBlockDistances
  * request the block distances for defining the congestion ahead
  * B
 */
void clHSA_Traffic_Base::vTMCRequestBlockDistances( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCRequestBlockDistances not implemented"));
   
}

/**
 * Method: vTMCEndRequestBlockDistances
  * finalise the request for block distances in order to defining the congestion ahead
  * B
 */
void clHSA_Traffic_Base::vTMCEndRequestBlockDistances( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCEndRequestBlockDistances not implemented"));
   
}

/**
 * Method: slwConvertToDynamicIndex_TrafficList
  * used for the highly dynamic list
  * B
 */
slword clHSA_Traffic_Base::slwConvertToDynamicIndex_TrafficList(ulword ulwUniqueId)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwUniqueId);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Traffic::slwConvertToDynamicIndex_TrafficList not implemented"));
   return 0;
}

/**
 * Method: slwConvertToUniqueId_TrafficList
  * used for the highly dynamic list
  * B
 */
slword clHSA_Traffic_Base::slwConvertToUniqueId_TrafficList(ulword ulwDynamicIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDynamicIndex);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Traffic::slwConvertToUniqueId_TrafficList not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentTMCStationName
  * Gets the name of the current TMC Station. Information should be used from the background tuner.
  * B
 */
void clHSA_Traffic_Base::vGetCurrentTMCStationName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Traffic::vGetCurrentTMCStationName not implemented"));
   
}

/**
 * Method: vTMCUpdateNow
  * triggers the TMC msg list udate operating  process
  * B
 */
void clHSA_Traffic_Base::vTMCUpdateNow( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCUpdateNow not implemented"));
   
}

/**
 * Method: vTMCXUrgentMsgClosed
  * Gives indication, that the X-Urgent msg is closed by user. Information is necessary to determine whether system event TRAFFIC_TMC_X_URGENT_MSG_OCCURRED should be triggered again if there are additional X-Urgent msg avialable. 
  * B
 */
void clHSA_Traffic_Base::vTMCXUrgentMsgClosed( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vTMCXUrgentMsgClosed not implemented"));
   
}

/**
 * Method: ulwGetOnRouteMessageCount
  * Gets the total number of messages on route 
  * NISSAN
 */
ulword clHSA_Traffic_Base::ulwGetOnRouteMessageCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Traffic::ulwGetOnRouteMessageCount not implemented"));
   return 0;
}

/**
 * Method: blIsBlockAlreadyActive
  * Returns whether block is already active in Traffic list
  * NISSAN
 */
tbool clHSA_Traffic_Base::blIsBlockAlreadyActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Traffic::blIsBlockAlreadyActive not implemented"));
   return 0;
}

/**
 * Method: blIsMessageBlocked
  * Returns whether a particular message is already blocked (index use from TMCActivateMessage)
  * NISSAN
 */
tbool clHSA_Traffic_Base::blIsMessageBlocked( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Traffic::blIsMessageBlocked not implemented"));
   return 0;
}

/**
 * Method: blTMCIsAreaMessage
  * Returns whether a particular message is Area message or Not
  * NISSAN
 */
tbool clHSA_Traffic_Base::blTMCIsAreaMessage(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Traffic::blTMCIsAreaMessage not implemented"));
   return 0;
}

/**
 * Method: ulwTMCMsgBlockStatus
  * returns whether list entry is blocked or not "down".
  * B
 */
ulword clHSA_Traffic_Base::ulwTMCMsgBlockStatus(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Traffic::ulwTMCMsgBlockStatus not implemented"));
   return 0;
}

/**
 * Method: vBlockMessage
  * Marks selected item for blocking (index use from TMCActivateMessage)
  * NISSAN
 */
void clHSA_Traffic_Base::vBlockMessage( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vBlockMessage not implemented"));
   
}

/**
 * Method: vUnBlockMessage
  * Marks selected item for unblocking (index use from TMCActivateMessage)
  * NISSAN
 */
void clHSA_Traffic_Base::vUnBlockMessage( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vUnBlockMessage not implemented"));
   
}

/**
 * Method: vExitOnRouteEventsList
  * Indicates that context is out of Traffic on route list
  * NISSAN
 */
void clHSA_Traffic_Base::vExitOnRouteEventsList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vExitOnRouteEventsList not implemented"));
   
}

/**
 * Method: vConfirmBlock
  * To Block the marked messages in traffic list
  * NISSAN
 */
void clHSA_Traffic_Base::vConfirmBlock( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vConfirmBlock not implemented"));
   
}

/**
 * Method: vRemoveBlock
  * To Remove the already defined block in traffic list
  * NISSAN
 */
void clHSA_Traffic_Base::vRemoveBlock( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Traffic::vRemoveBlock not implemented"));
   
}

/**
 * Method: blTMCIsOnRouteMessageUpdateAvailable
  * Returns whether on-route list has to be udpated or not
  * NISSANLCN2KAI
 */
tbool clHSA_Traffic_Base::blTMCIsOnRouteMessageUpdateAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Traffic::blTMCIsOnRouteMessageUpdateAvailable not implemented"));
   return 0;
}

