/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Traffic_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_Traffic_Wrapper_H
#define _HSA_Traffic_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: TMCToggleAcousticWarningsOutput
 * NISSAN 2.0
 * NISSAN
 */
void HSA_Traffic__vTMCToggleAcousticWarningsOutput( void);

/**
 * Function: TMCGetAcousticWarningsOutput
 * NISSAN 2.0
 * NISSAN
 */
tbool HSA_Traffic__blTMCGetAcousticWarningsOutput( void);

/**
 * Function: TMCToggleShowIncident
 * NISSAN NAR
 * NISSAN
 */
void HSA_Traffic__vTMCToggleShowIncident( void);

/**
 * Function: TMCGetShowIncident
 * NISSAN NAR
 * NISSAN
 */
tbool HSA_Traffic__blTMCGetShowIncident( void);

/**
 * Function: TMCCheckServiceAvailable
 * NISSAN NAR
 * NISSAN
 */
ulword HSA_Traffic__ulwTMCCheckServiceAvailable( void);

/**
 * Function: TMCToggleTrafficFlow
 * NISSAN NAR
 * NISSAN
 */
void HSA_Traffic__vTMCToggleTrafficFlow( void);

/**
 * Function: TMCGetTrafficFlow
 * NISSAN NAR
 * NISSAN
 */
tbool HSA_Traffic__blTMCGetTrafficFlow( void);

/**
 * Function: RequestOnRouteMessages
 * NISSAN
 * NISSAN
 */
void HSA_Traffic__vRequestOnRouteMessages( void);

/**
 * Function: TMCActivateMessage
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCActivateMessage(ulword ulwListEntryNr);

/**
 * Function: TMCActivateNextMessage
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCActivateNextMessage( void);

/**
 * Function: TMCActivatePrevMessage
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCActivatePrevMessage( void);

/**
 * Function: TMCGetCurrentItemIndex
 * B2
 * NISSAN
 */
ulword HSA_Traffic__ulwTMCGetCurrentItemIndex( void);

/**
 * Function: TMCGetCurrentMessageInfo
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCGetCurrentMessageInfo(GUI_String *out_result);

/**
 * Function: TMCGetCurrentMessageInfoSourceTime
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCGetCurrentMessageInfoSourceTime(GUI_String *out_result);

/**
 * Function: TMCGetCurrentMessageInfoSourceDate
 * B
 * NISSAN
 */
void HSA_Traffic__vTMCGetCurrentMessageInfoSourceDate(GUI_String *out_result);

/**
 * Function: TMCGetCurrentMessageInfoSourceStation
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCGetCurrentMessageInfoSourceStation(GUI_String *out_result);

/**
 * Function: TMCGetMessageList
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCGetMessageList(GUI_String *out_result, ulword ulwLine, ulword ulwListEntryNr);

/**
 * Function: TMCGetCurrentMessageIconLabelIndex
 * B2
 * NISSAN
 */
ulword HSA_Traffic__ulwTMCGetCurrentMessageIconLabelIndex(ulword ulwListEntryNr);

/**
 * Function: TMCGetTrafficListHeading
 * nissan
 * NISSAN
 */
ulword HSA_Traffic__ulwTMCGetTrafficListHeading(ulword ulwListEntryNr);

/**
 * Function: TMCGetTrafficDistance
 * nissan
 * NISSAN
 */
void HSA_Traffic__vTMCGetTrafficDistance(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: TrafficDistanceGetListUnit
 * nissan
 * NISSAN
 */
ulword HSA_Traffic__ulwTrafficDistanceGetListUnit( void);

/**
 * Function: TMCGetMessageCount
 * B2
 * NISSAN
 */
ulword HSA_Traffic__ulwTMCGetMessageCount( void);

/**
 * Function: TMCGetMessageCountasString
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCGetMessageCountasString(GUI_String *out_result);

/**
 * Function: TMCGetXUrgentMessage
 * B
 * NISSAN
 */
void HSA_Traffic__vTMCGetXUrgentMessage(GUI_String *out_result);

/**
 * Function: TMCIsFirstMessage
 * B2
 * NISSAN
 */
tbool HSA_Traffic__blTMCIsFirstMessage( void);

/**
 * Function: TMCIsLastMessage
 * B2
 * NISSAN
 */
tbool HSA_Traffic__blTMCIsLastMessage( void);

/**
 * Function: TMCIsCongestionDefined
 * B2
 * NISSAN
 */
tbool HSA_Traffic__blTMCIsCongestionDefined( void);

/**
 * Function: TMCIsMSGAvailableForSegment
 * B
 * NISSAN
 */
tbool HSA_Traffic__blTMCIsMSGAvailableForSegment( void);

/**
 * Function: TMCActivateMessageForSegment
 * B
 * NISSAN
 */
void HSA_Traffic__vTMCActivateMessageForSegment( void);

/**
 * Function: TMCDeleteCongestion
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCDeleteCongestion( void);

/**
 * Function: TMCListUpdateOperating
 * B
 * NISSAN
 */
ulword HSA_Traffic__ulwTMCListUpdateOperating( void);

/**
 * Function: TMCListUpdateAvailable
 * B
 * NISSAN
 */
ulword HSA_Traffic__ulwTMCListUpdateAvailable( void);

/**
 * Function: TMCUpdateList
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCUpdateList( void);

/**
 * Function: TMCEndUpdateList
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCEndUpdateList( void);

/**
 * Function: TMCSetTimerValues
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCSetTimerValues(ulword ulwTimer, ulword ulwValue);

/**
 * Function: TMCResetTimerValues
 * B2
 * NISSAN
 */
void HSA_Traffic__vTMCResetTimerValues(ulword ulwTimer);

/**
 * Function: TMCRequestBlockDistances
 * B
 * NISSAN
 */
void HSA_Traffic__vTMCRequestBlockDistances( void);

/**
 * Function: TMCEndRequestBlockDistances
 * B
 * NISSAN
 */
void HSA_Traffic__vTMCEndRequestBlockDistances( void);

/**
 * Function: ConvertToDynamicIndex_TrafficList
 * B
 * NISSAN
 */
slword HSA_Traffic__slwConvertToDynamicIndex_TrafficList(ulword ulwUniqueId);

/**
 * Function: ConvertToUniqueId_TrafficList
 * B
 * NISSAN
 */
slword HSA_Traffic__slwConvertToUniqueId_TrafficList(ulword ulwDynamicIndex);

/**
 * Function: GetCurrentTMCStationName
 * B
 * NISSAN
 */
void HSA_Traffic__vGetCurrentTMCStationName(GUI_String *out_result);

/**
 * Function: TMCUpdateNow
 * B
 * NISSAN
 */
void HSA_Traffic__vTMCUpdateNow( void);

/**
 * Function: TMCXUrgentMsgClosed
 * B
 * NISSAN
 */
void HSA_Traffic__vTMCXUrgentMsgClosed( void);

/**
 * Function: GetOnRouteMessageCount
 * NISSAN
 * NISSAN
 */
ulword HSA_Traffic__ulwGetOnRouteMessageCount( void);

/**
 * Function: IsBlockAlreadyActive
 * NISSAN
 * NISSAN
 */
tbool HSA_Traffic__blIsBlockAlreadyActive( void);

/**
 * Function: IsMessageBlocked
 * NISSAN
 * NISSAN
 */
tbool HSA_Traffic__blIsMessageBlocked( void);

/**
 * Function: TMCIsAreaMessage
 * NISSAN
 * NISSAN
 */
tbool HSA_Traffic__blTMCIsAreaMessage(ulword ulwListEntryNr);

/**
 * Function: TMCMsgBlockStatus
 * B
 * NISSAN
 */
ulword HSA_Traffic__ulwTMCMsgBlockStatus(ulword ulwListEntryNr);

/**
 * Function: BlockMessage
 * NISSAN
 * NISSAN
 */
void HSA_Traffic__vBlockMessage( void);

/**
 * Function: UnBlockMessage
 * NISSAN
 * NISSAN
 */
void HSA_Traffic__vUnBlockMessage( void);

/**
 * Function: ExitOnRouteEventsList
 * NISSAN
 * NISSAN
 */
void HSA_Traffic__vExitOnRouteEventsList( void);

/**
 * Function: ConfirmBlock
 * NISSAN
 * NISSAN
 */
void HSA_Traffic__vConfirmBlock( void);

/**
 * Function: RemoveBlock
 * NISSAN
 * NISSAN
 */
void HSA_Traffic__vRemoveBlock( void);

/**
 * Function: TMCIsOnRouteMessageUpdateAvailable
 * NISSANLCN2KAI
 * NISSAN
 */
tbool HSA_Traffic__blTMCIsOnRouteMessageUpdateAvailable( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_Traffic_H

