/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_Traffic_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_Traffic_Base_H
#define _clHSA_Traffic_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_Traffic_Base : public clHSA_Base
{
public:

    static clHSA_Traffic_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_Traffic_Base()        {}

    virtual void vTMCToggleAcousticWarningsOutput( );

    virtual tbool blTMCGetAcousticWarningsOutput( );

    virtual void vTMCToggleShowIncident( );

    virtual tbool blTMCGetShowIncident( );

    virtual ulword ulwTMCCheckServiceAvailable( );

    virtual void vTMCToggleTrafficFlow( );

    virtual tbool blTMCGetTrafficFlow( );

    virtual void vRequestOnRouteMessages( );

    virtual void vTMCActivateMessage(ulword ulwListEntryNr);

    virtual void vTMCActivateNextMessage( );

    virtual void vTMCActivatePrevMessage( );

    virtual ulword ulwTMCGetCurrentItemIndex( );

    virtual void vTMCGetCurrentMessageInfo(GUI_String *out_result);

    virtual void vTMCGetCurrentMessageInfoSourceTime(GUI_String *out_result);

    virtual void vTMCGetCurrentMessageInfoSourceDate(GUI_String *out_result);

    virtual void vTMCGetCurrentMessageInfoSourceStation(GUI_String *out_result);

    virtual void vTMCGetMessageList(GUI_String *out_result, ulword ulwLine, ulword ulwListEntryNr);

    virtual ulword ulwTMCGetCurrentMessageIconLabelIndex(ulword ulwListEntryNr);

    virtual ulword ulwTMCGetTrafficListHeading(ulword ulwListEntryNr);

    virtual void vTMCGetTrafficDistance(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwTrafficDistanceGetListUnit( );

    virtual ulword ulwTMCGetMessageCount( );

    virtual void vTMCGetMessageCountasString(GUI_String *out_result);

    virtual void vTMCGetXUrgentMessage(GUI_String *out_result);

    virtual tbool blTMCIsFirstMessage( );

    virtual tbool blTMCIsLastMessage( );

    virtual tbool blTMCIsCongestionDefined( );

    virtual tbool blTMCIsMSGAvailableForSegment( );

    virtual void vTMCActivateMessageForSegment( );

    virtual void vTMCDeleteCongestion( );

    virtual ulword ulwTMCListUpdateOperating( );

    virtual ulword ulwTMCListUpdateAvailable( );

    virtual void vTMCUpdateList( );

    virtual void vTMCEndUpdateList( );

    virtual void vTMCSetTimerValues(ulword ulwTimer, ulword ulwValue);

    virtual void vTMCResetTimerValues(ulword ulwTimer);

    virtual void vTMCRequestBlockDistances( );

    virtual void vTMCEndRequestBlockDistances( );

    virtual slword slwConvertToDynamicIndex_TrafficList(ulword ulwUniqueId);

    virtual slword slwConvertToUniqueId_TrafficList(ulword ulwDynamicIndex);

    virtual void vGetCurrentTMCStationName(GUI_String *out_result);

    virtual void vTMCUpdateNow( );

    virtual void vTMCXUrgentMsgClosed( );

    virtual ulword ulwGetOnRouteMessageCount( );

    virtual tbool blIsBlockAlreadyActive( );

    virtual tbool blIsMessageBlocked( );

    virtual tbool blTMCIsAreaMessage(ulword ulwListEntryNr);

    virtual ulword ulwTMCMsgBlockStatus(ulword ulwListEntryNr);

    virtual void vBlockMessage( );

    virtual void vUnBlockMessage( );

    virtual void vExitOnRouteEventsList( );

    virtual void vConfirmBlock( );

    virtual void vRemoveBlock( );

    virtual tbool blTMCIsOnRouteMessageUpdateAvailable( );

protected:
    clHSA_Traffic_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_Traffic_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_Traffic_Base_H

