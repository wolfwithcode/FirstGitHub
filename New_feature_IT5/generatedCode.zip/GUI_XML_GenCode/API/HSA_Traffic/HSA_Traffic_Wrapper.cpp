/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Traffic_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_Traffic_Wrapper.h"
#include "clHSA_Traffic_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_Traffic_Trace.h"
#include "hmi_trace.h"

void HSA_Traffic__vTMCToggleAcousticWarningsOutput( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_TOGGLE_ACOUSTIC_WARNINGS_OUTPUT  ) ); 
        }
      pInst->vTMCToggleAcousticWarningsOutput();

    }
}

tbool HSA_Traffic__blTMCGetAcousticWarningsOutput( )
{
    tbool ret = false;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_ACOUSTIC_WARNINGS_OUTPUT  ) ); 
        }
      ret=pInst->blTMCGetAcousticWarningsOutput();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_ACOUSTIC_WARNINGS_OUTPUT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Traffic__vTMCToggleShowIncident( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_TOGGLE_SHOW_INCIDENT  ) ); 
        }
      pInst->vTMCToggleShowIncident();

    }
}

tbool HSA_Traffic__blTMCGetShowIncident( )
{
    tbool ret = false;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_SHOW_INCIDENT  ) ); 
        }
      ret=pInst->blTMCGetShowIncident();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_SHOW_INCIDENT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Traffic__ulwTMCCheckServiceAvailable( )
{
    ulword ret = 0;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_CHECK_SERVICE_AVAILABLE  ) ); 
        }
      ret=pInst->ulwTMCCheckServiceAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_CHECK_SERVICE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Traffic__vTMCToggleTrafficFlow( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_TOGGLE_TRAFFIC_FLOW  ) ); 
        }
      pInst->vTMCToggleTrafficFlow();

    }
}

tbool HSA_Traffic__blTMCGetTrafficFlow( )
{
    tbool ret = false;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_TRAFFIC_FLOW  ) ); 
        }
      ret=pInst->blTMCGetTrafficFlow();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_TRAFFIC_FLOW | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Traffic__vRequestOnRouteMessages( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__REQUEST_ON_ROUTE_MESSAGES  ) ); 
        }
      pInst->vRequestOnRouteMessages();

    }
}

void HSA_Traffic__vTMCActivateMessage(ulword ulwListEntryNr)
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_ACTIVATE_MESSAGE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vTMCActivateMessage(ulwListEntryNr);

    }
}

void HSA_Traffic__vTMCActivateNextMessage( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_ACTIVATE_NEXT_MESSAGE  ) ); 
        }
      pInst->vTMCActivateNextMessage();

    }
}

void HSA_Traffic__vTMCActivatePrevMessage( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_ACTIVATE_PREV_MESSAGE  ) ); 
        }
      pInst->vTMCActivatePrevMessage();

    }
}

ulword HSA_Traffic__ulwTMCGetCurrentItemIndex( )
{
    ulword ret = 0;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_CURRENT_ITEM_INDEX  ) ); 
        }
      ret=pInst->ulwTMCGetCurrentItemIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_CURRENT_ITEM_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Traffic__vTMCGetCurrentMessageInfo(GUI_String *out_result)
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_CURRENT_MESSAGE_INFO  ) ); 
        }
      pInst->vTMCGetCurrentMessageInfo(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_CURRENT_MESSAGE_INFO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Traffic__vTMCGetCurrentMessageInfoSourceTime(GUI_String *out_result)
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_CURRENT_MESSAGE_INFO_SOURCE_TIME  ) ); 
        }
      pInst->vTMCGetCurrentMessageInfoSourceTime(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_CURRENT_MESSAGE_INFO_SOURCE_TIME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Traffic__vTMCGetCurrentMessageInfoSourceDate(GUI_String *out_result)
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_CURRENT_MESSAGE_INFO_SOURCE_DATE  ) ); 
        }
      pInst->vTMCGetCurrentMessageInfoSourceDate(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_CURRENT_MESSAGE_INFO_SOURCE_DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Traffic__vTMCGetCurrentMessageInfoSourceStation(GUI_String *out_result)
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_CURRENT_MESSAGE_INFO_SOURCE_STATION  ) ); 
        }
      pInst->vTMCGetCurrentMessageInfoSourceStation(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_CURRENT_MESSAGE_INFO_SOURCE_STATION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Traffic__vTMCGetMessageList(GUI_String *out_result, ulword ulwLine, ulword ulwListEntryNr)
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_MESSAGE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLine); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_MESSAGE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vTMCGetMessageList(out_result, ulwLine, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_MESSAGE_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Traffic__ulwTMCGetCurrentMessageIconLabelIndex(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_CURRENT_MESSAGE_ICON_LABEL_INDEX | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwTMCGetCurrentMessageIconLabelIndex(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_CURRENT_MESSAGE_ICON_LABEL_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Traffic__ulwTMCGetTrafficListHeading(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_TRAFFIC_LIST_HEADING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwTMCGetTrafficListHeading(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_TRAFFIC_LIST_HEADING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Traffic__vTMCGetTrafficDistance(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_TRAFFIC_DISTANCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vTMCGetTrafficDistance(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_TRAFFIC_DISTANCE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Traffic__ulwTrafficDistanceGetListUnit( )
{
    ulword ret = 0;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TRAFFIC_DISTANCE_GET_LIST_UNIT  ) ); 
        }
      ret=pInst->ulwTrafficDistanceGetListUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TRAFFIC_DISTANCE_GET_LIST_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Traffic__ulwTMCGetMessageCount( )
{
    ulword ret = 0;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_MESSAGE_COUNT  ) ); 
        }
      ret=pInst->ulwTMCGetMessageCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_MESSAGE_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Traffic__vTMCGetMessageCountasString(GUI_String *out_result)
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_MESSAGE_COUNTAS_STRING  ) ); 
        }
      pInst->vTMCGetMessageCountasString(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_MESSAGE_COUNTAS_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Traffic__vTMCGetXUrgentMessage(GUI_String *out_result)
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_X_URGENT_MESSAGE  ) ); 
        }
      pInst->vTMCGetXUrgentMessage(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_GET_X_URGENT_MESSAGE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Traffic__blTMCIsFirstMessage( )
{
    tbool ret = false;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_IS_FIRST_MESSAGE  ) ); 
        }
      ret=pInst->blTMCIsFirstMessage();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_IS_FIRST_MESSAGE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Traffic__blTMCIsLastMessage( )
{
    tbool ret = false;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_IS_LAST_MESSAGE  ) ); 
        }
      ret=pInst->blTMCIsLastMessage();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_IS_LAST_MESSAGE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Traffic__blTMCIsCongestionDefined( )
{
    tbool ret = false;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_IS_CONGESTION_DEFINED  ) ); 
        }
      ret=pInst->blTMCIsCongestionDefined();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_IS_CONGESTION_DEFINED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Traffic__blTMCIsMSGAvailableForSegment( )
{
    tbool ret = false;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_IS_MSG_AVAILABLE_FOR_SEGMENT  ) ); 
        }
      ret=pInst->blTMCIsMSGAvailableForSegment();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_IS_MSG_AVAILABLE_FOR_SEGMENT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Traffic__vTMCActivateMessageForSegment( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_ACTIVATE_MESSAGE_FOR_SEGMENT  ) ); 
        }
      pInst->vTMCActivateMessageForSegment();

    }
}

void HSA_Traffic__vTMCDeleteCongestion( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_DELETE_CONGESTION  ) ); 
        }
      pInst->vTMCDeleteCongestion();

    }
}

ulword HSA_Traffic__ulwTMCListUpdateOperating( )
{
    ulword ret = 0;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_LIST_UPDATE_OPERATING  ) ); 
        }
      ret=pInst->ulwTMCListUpdateOperating();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_LIST_UPDATE_OPERATING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Traffic__ulwTMCListUpdateAvailable( )
{
    ulword ret = 0;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_LIST_UPDATE_AVAILABLE  ) ); 
        }
      ret=pInst->ulwTMCListUpdateAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_LIST_UPDATE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Traffic__vTMCUpdateList( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_UPDATE_LIST  ) ); 
        }
      pInst->vTMCUpdateList();

    }
}

void HSA_Traffic__vTMCEndUpdateList( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_END_UPDATE_LIST  ) ); 
        }
      pInst->vTMCEndUpdateList();

    }
}

void HSA_Traffic__vTMCSetTimerValues(ulword ulwTimer, ulword ulwValue)
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_SET_TIMER_VALUES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTimer); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_SET_TIMER_VALUES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwValue); 
        }
      pInst->vTMCSetTimerValues(ulwTimer, ulwValue);

    }
}

void HSA_Traffic__vTMCResetTimerValues(ulword ulwTimer)
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_RESET_TIMER_VALUES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTimer); 
        }
      pInst->vTMCResetTimerValues(ulwTimer);

    }
}

void HSA_Traffic__vTMCRequestBlockDistances( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_REQUEST_BLOCK_DISTANCES  ) ); 
        }
      pInst->vTMCRequestBlockDistances();

    }
}

void HSA_Traffic__vTMCEndRequestBlockDistances( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_END_REQUEST_BLOCK_DISTANCES  ) ); 
        }
      pInst->vTMCEndRequestBlockDistances();

    }
}

slword HSA_Traffic__slwConvertToDynamicIndex_TrafficList(ulword ulwUniqueId)
{
    slword ret = 0;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_DYNAMIC_INDEX__TRAFFIC_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwUniqueId); 
        }
      ret=pInst->slwConvertToDynamicIndex_TrafficList(ulwUniqueId);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_DYNAMIC_INDEX__TRAFFIC_LIST | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Traffic__slwConvertToUniqueId_TrafficList(ulword ulwDynamicIndex)
{
    slword ret = 0;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_UNIQUE_ID__TRAFFIC_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDynamicIndex); 
        }
      ret=pInst->slwConvertToUniqueId_TrafficList(ulwDynamicIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_UNIQUE_ID__TRAFFIC_LIST | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_Traffic__vGetCurrentTMCStationName(GUI_String *out_result)
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TMC_STATION_NAME  ) ); 
        }
      pInst->vGetCurrentTMCStationName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TMC_STATION_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Traffic__vTMCUpdateNow( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_UPDATE_NOW  ) ); 
        }
      pInst->vTMCUpdateNow();

    }
}

void HSA_Traffic__vTMCXUrgentMsgClosed( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMCX_URGENT_MSG_CLOSED  ) ); 
        }
      pInst->vTMCXUrgentMsgClosed();

    }
}

ulword HSA_Traffic__ulwGetOnRouteMessageCount( )
{
    ulword ret = 0;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__GET_ON_ROUTE_MESSAGE_COUNT  ) ); 
        }
      ret=pInst->ulwGetOnRouteMessageCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__GET_ON_ROUTE_MESSAGE_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Traffic__blIsBlockAlreadyActive( )
{
    tbool ret = false;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__IS_BLOCK_ALREADY_ACTIVE  ) ); 
        }
      ret=pInst->blIsBlockAlreadyActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__IS_BLOCK_ALREADY_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Traffic__blIsMessageBlocked( )
{
    tbool ret = false;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__IS_MESSAGE_BLOCKED  ) ); 
        }
      ret=pInst->blIsMessageBlocked();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__IS_MESSAGE_BLOCKED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Traffic__blTMCIsAreaMessage(ulword ulwListEntryNr)
{
    tbool ret = false;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_IS_AREA_MESSAGE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->blTMCIsAreaMessage(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_IS_AREA_MESSAGE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Traffic__ulwTMCMsgBlockStatus(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_MSG_BLOCK_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwTMCMsgBlockStatus(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_MSG_BLOCK_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Traffic__vBlockMessage( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__BLOCK_MESSAGE  ) ); 
        }
      pInst->vBlockMessage();

    }
}

void HSA_Traffic__vUnBlockMessage( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__UN_BLOCK_MESSAGE  ) ); 
        }
      pInst->vUnBlockMessage();

    }
}

void HSA_Traffic__vExitOnRouteEventsList( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__EXIT_ON_ROUTE_EVENTS_LIST  ) ); 
        }
      pInst->vExitOnRouteEventsList();

    }
}

void HSA_Traffic__vConfirmBlock( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__CONFIRM_BLOCK  ) ); 
        }
      pInst->vConfirmBlock();

    }
}

void HSA_Traffic__vRemoveBlock( )
{
    
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__REMOVE_BLOCK  ) ); 
        }
      pInst->vRemoveBlock();

    }
}

tbool HSA_Traffic__blTMCIsOnRouteMessageUpdateAvailable( )
{
    tbool ret = false;
    clHSA_Traffic_Base *pInst=clHSA_Traffic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_IS_ON_ROUTE_MESSAGE_UPDATE_AVAILABLE  ) ); 
        }
      ret=pInst->blTMCIsOnRouteMessageUpdateAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TRAFFIC), (tU16)(HSA_API_ENTRYPOINT__TMC_IS_ON_ROUTE_MESSAGE_UPDATE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

#ifdef __cplusplus
}
#endif

