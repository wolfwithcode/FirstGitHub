/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Telematic_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_Telematic_Wrapper_dbg.h"
#include "clHSA_Telematic_Base.h"
#include "HSA_Telematic_Trace.h"
#include "HSA_Telematic_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_Telematic_Wrapper_dbg::~clHSA_Telematic_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_Telematic_Wrapper_dbg::clHSA_Telematic_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_Telematic_Wrapper_dbg::clHSA_Telematic_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_Telematic_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_Telematic_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__GET_CONNECTION_STATUS:

            HSA_Telematic__ulwGetConnectionStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_REQUEST_STATUS:

            HSA_Telematic__ulwGetRequestStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_REQUEST_TYPE:

            HSA_Telematic__ulwGetRequestType();
            break;

        case HSA_API_ENTRYPOINT__GET_REGISTRATION_STATUS:

            HSA_Telematic__ulwGetRegistrationStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_SET_REGISTRATION_USER_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetSetRegistrationUserName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SET_REGISTRATION_PASSWORD:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetSetRegistrationPassword(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SET_REGISTRATION_COUNTRY:

            HSA_Telematic__ulwGetSetRegistrationCountry();
            break;

        case HSA_API_ENTRYPOINT__GET_REGISTRATION_USER_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetRegistrationUserName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_REGISTRATION_PASSWORD:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetRegistrationPassword(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_REGISTRATION_COUNTRY:

            HSA_Telematic__ulwGetRegistrationCountry();
            break;

        case HSA_API_ENTRYPOINT__GET_REGISTRATION_DEVICE_ID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetRegistrationDeviceId(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_REGISTRATION_USER_NAME:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Telematic__vSetRegistrationUserName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_REGISTRATION_PASSWORD:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Telematic__vSetRegistrationPassword(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_REGISTRATION_COUNTRY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__vSetRegistrationCountry(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_COUNTRY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__ulwGetCountry(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_COUNTRY_LIST__COUNT:

            HSA_Telematic__ulwGetCountryList_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_CONFIRM_DIAL_IN:

            HSA_Telematic__ulwGetConfirmDialIn();
            break;

        case HSA_API_ENTRYPOINT__SET_CONFIRM_DIAL_ONCE_FLAG:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Telematic__vSetConfirmDialOnceFlag(usParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_CONFIRM_DIAL_ONCE_FLAG_SET:

            HSA_Telematic__blIsConfirmDialOnceFlagSet();
            break;

        case HSA_API_ENTRYPOINT__GET_DOWNLOAD_POI_CNT:

            HSA_Telematic__ulwGetDownloadPOICnt();
            break;

        case HSA_API_ENTRYPOINT__SET_CONFIRM_DIAL_IN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__vSetConfirmDialIn(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__REGISTER_FOR_INFO_SERVICES:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Telematic__vRegisterForInfoServices(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_NEW_HU_FLAG:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Telematic__vSetNewHUFlag(usParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_MAIL_ADRESS_VALID:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Telematic__blIsMailAdressValid(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_REGISTRATION_DATA_VALID:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Telematic__blIsRegistrationDataValid(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_SPELLER_DISABLED:

            HSA_Telematic__blIsSpellerDisabled();
            break;

        case HSA_API_ENTRYPOINT__GET_SET_REGISTRATION_E_MAIL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetSetRegistrationEMail(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_REGISTRATION_E_MAIL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetRegistrationEMail(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_REGISTRATION_E_MAIL:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Telematic__vSetRegistrationEMail(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__INCREASE_SETUP_CNT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__vIncreaseSetupCnt(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DECREASE_SETUP_CNT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__vDecreaseSetupCnt(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SETUP_RADIUS:

            HSA_Telematic__ulwGetSetupRadius();
            break;

        case HSA_API_ENTRYPOINT__GET_SETUP_DOWNLOAD_POI_COUNT:

            HSA_Telematic__ulwGetSetupDownloadPoiCount();
            break;

        case HSA_API_ENTRYPOINT__SET_REQUEST_LOCATION_TYPE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__vSetRequestLocationType(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__UPDATE_NAVI_BLOB_INFO_RELATED_DP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vUpdateNaviBlobInfoRelatedDP(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TELEMATIC_DIRECTION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Telematic__vGetTelematicDirection(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_TELEMATIC_DISTANCE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Telematic__vGetTelematicDistance(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__SET_DETAIL_INDEX:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__vSetDetailIndex(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TELEMATIC_DETAIL_TEXT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vGetTelematicDetailText(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TELEMATIC_POI_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vGetTelematicPOINumber(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__IS_POI_DIAL_NUMBER_AVAILABLE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__blIsPOIDialNumberAvailable(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__START_TELEMATIC_REQUEST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__vStartTelematicRequest(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ABORT_TELEMATIC_REQUEST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__vAbortTelematicRequest(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_COUNT:

            HSA_Telematic__ulwGetLastStoredPOIs_count();
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_LATITUDE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__slwGetLastStoredPOIsLatitude(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_LONGITUDE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__slwGetLastStoredPOIsLongitude(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vGetLastStoredPOIsName(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_ADDRESS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vGetLastStoredPOIsAddress(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__UPDATE_DISTANCE_DIRECTION:

            HSA_Telematic__vUpdateDistanceDirection();
            break;

        case HSA_API_ENTRYPOINT__SET_FLIGHT_NUMBER:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Telematic__vSetFlightNumber(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_FLIGHT_REQUEST_ENABLED:

            HSA_Telematic__blIsFlightRequestEnabled();
            break;

        case HSA_API_ENTRYPOINT__FLIGHT_INFO_RESULT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Telematic__vFlightInfoResult(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__FLIGHT_INFORMATION_RESULT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vFlightInformationResult(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_FLIGHT_DIRECTION:

            HSA_Telematic__vToggleFlightDirection();
            break;

        case HSA_API_ENTRYPOINT__GET_FLIGHT_DIRECTION:

            HSA_Telematic__ulwGetFlightDirection();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_FLIGHT_DAY:

            HSA_Telematic__vToggleFlightDay();
            break;

        case HSA_API_ENTRYPOINT__GET_FLIGHT_DAY:

            HSA_Telematic__ulwGetFlightDay();
            break;

        case HSA_API_ENTRYPOINT__IS_FLIGHT_NUMBER_VALID:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Telematic__blIsFlightNumberValid(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_FLIGHT_STATUS_COUNT:

            HSA_Telematic__ulwGetLastFlightStatus_count();
            break;

        case HSA_API_ENTRYPOINT__GET_FLIGHT_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetFlightNumber(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_DATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetCurrentWeatherDate(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_TEMP:

            HSA_Telematic__slwGetCurrentWeatherTemp();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_TEMP_WIND_CHILL:

            HSA_Telematic__ulwGetCurrentWeatherTempWindChill();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_HUMIDITY:

            HSA_Telematic__ulwGetCurrentWeatherHumidity();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_WINDDIRECTION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetCurrentWeatherWinddirection(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_WINDSPEED:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetCurrentWeatherWindspeed(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_CONDITION:

            HSA_Telematic__ulwGetCurrentWeatherCondition();
            break;

        case HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_CONDITION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__ulwGetForecastWeatherCondition(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_COUNT:

            HSA_Telematic__ulwGetForecastWeather_count();
            break;

        case HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_DATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vGetForecastWeatherDate(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_TEMP_MAX:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__slwGetForecastWeatherTempMax(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_DAY_OF_WEEK:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__ulwGetForecastWeatherDayOfWeek(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_TEMP_MIN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__slwGetForecastWeatherTempMin(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_WEATHER_INFO_LONGITUDE:

            HSA_Telematic__slwGetWeatherInfoLongitude();
            break;

        case HSA_API_ENTRYPOINT__GET_WEATHER_INFO_LATITUDE:

            HSA_Telematic__slwGetWeatherInfoLatitude();
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_WEATHER_REQUEST_TEMP_MAX_WIND_CHILL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__ulwGetLastWeatherRequestTempMaxWindChill(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_WEATHER_REQUEST_TEMP_MIN_WIND_CHILL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__ulwGetLastWeatherRequestTempMinWindChill(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_WEATHER_REQUEST_RAIN_PROPABILTIY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__ulwGetLastWeatherRequestRainPropabiltiy(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_WEATHER_REQUEST_CITY_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetLastWeatherRequestCityName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_REQUEST_LOCATION_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetLastRequestLocationName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_LAST_WEATHER_REQUEST_OUTDATED:

            HSA_Telematic__blIsLastWeatherRequestOutdated();
            break;

        case HSA_API_ENTRYPOINT__IS_REPEAT_LAST_REQUEST_POSSIBLE:

            HSA_Telematic__blIsRepeatLastRequestPossible();
            break;

        case HSA_API_ENTRYPOINT__IS_WEATHER_DATA_AVAILABLE:

            HSA_Telematic__blIsWeatherDataAvailable();
            break;

        case HSA_API_ENTRYPOINT__GET_POI_SEARCH_LONGITUDE:

            HSA_Telematic__slwGetPOISearchLongitude();
            break;

        case HSA_API_ENTRYPOINT__GET_POI_SEARCH_LATITUDE:

            HSA_Telematic__slwGetPOISearchLatitude();
            break;

        case HSA_API_ENTRYPOINT__GET_ENTERED_SEARCH_ITEM:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetEnteredSearchItem(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_ENTERED_SEARCH_ITEM:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Telematic__vSetEnteredSearchItem(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_COUNT:

            HSA_Telematic__ulwGetLastPoiSearch_count();
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_LONGITUDE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__slwGetLastPoiSearchLongitude(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_LATITUDE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__slwGetLastPoiSearchLatitude(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vGetLastPoiSearchName(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_ADDRESS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vGetLastPoiSearchAddress(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_PRICES_LONGITUDE:

            HSA_Telematic__slwGetFuelPricesLongitude();
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_PRICES_LATITUDE:

            HSA_Telematic__slwGetFuelPricesLatitude();
            break;

        case HSA_API_ENTRYPOINT__SET_FUEL_PRICES_LONGITUDE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam1); 

            HSA_Telematic__vSetFuelPricesLongitude(slParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_FUEL_PRICES_LATITUDE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam1); 

            HSA_Telematic__vSetFuelPricesLatitude(slParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_COUNT:

            HSA_Telematic__ulwGetLastFuelPrices_count();
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_LATITUDE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__slwGetLastFuelPricesLatitude(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_LONGITUDE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__slwGetLastFuelPricesLongitude(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vGetLastFuelPricesName(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_ADDRESS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vGetLastFuelPricesAddress(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_PHONE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vGetLastFuelPricesPhone(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_PRICE_NEW:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vGetLastFuelPricesPriceNew(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_PRICE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__ulwGetLastFuelPricesPrice(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_DISTANCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__ulwGetLastFuelPricesDistance(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_LAST_FUEL_PRICES_OUTDATED:

            HSA_Telematic__blIsLastFuelPricesOutdated();
            break;

        case HSA_API_ENTRYPOINT__CLEAR_LAST_FUEL_INFO:

            HSA_Telematic__vClearLastFuelInfo();
            break;

        case HSA_API_ENTRYPOINT__GET_FUEL_TYPE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetFuelType(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_FUEL_TYPE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__vSetFuelType(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_REQUEST_FUEL_TYPE:

            HSA_Telematic__ulwGetRequestFuelType();
            break;

        case HSA_API_ENTRYPOINT__GET_REQUEST_LOCATION_TYPE:

            HSA_Telematic__ulwGetRequestLocationType();
            break;

        case HSA_API_ENTRYPOINT__GET_TEMPERATURE_UNIT:

            HSA_Telematic__ulwGetTemperatureUnit();
            break;

        case HSA_API_ENTRYPOINT__SET_TEMPERATURE_UNIT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__vSetTemperatureUnit(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__PREPARE_SPELLER_ENTRY_FIELD:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Telematic__vPrepareSpellerEntryField(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_MAX_CHAR_COUNT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam1); 

            HSA_Telematic__vSpellerSetMaxCharCount(slParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_INPUT_OCCURRED:

            HSA_Telematic__blSpellerInputOccurred();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_DISCARD_INPUT:

            HSA_Telematic__vSpellerDiscardInput();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_CHARACTER:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Telematic__vSpellerSetCharacter(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SPELLER_ENTRY_FIELD:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vGetSpellerEntryField(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_HIGHLIGHTED_TEXT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vSpellerGetHighlightedText(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SPELLER_MATCH_INDEX:

            HSA_Telematic__ulwGetSpellerMatchIndex();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION:

            HSA_Telematic__blSpellerInvertGetLetterFunction();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_LETTER_FUNCTION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Telematic__vSpellerGetLetterFunction(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SPELLER_MATCH_FOUND_RESULT:

            HSA_Telematic__ulwGetSpellerMatchFoundResult();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS:

            HSA_Telematic__ulwSpellerGetCursorPos();
            break;

        case HSA_API_ENTRYPOINT__ABORT_SEND_TO_CAR_DOWNLOAD:

            HSA_Telematic__vAbortSendToCarDownload();
            break;

        case HSA_API_ENTRYPOINT__ABORT_GAS_PRICES_REQUEST:

            HSA_Telematic__vAbortGasPricesRequest();
            break;

        case HSA_API_ENTRYPOINT__GET_SERVICE_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Telematic__blGetServiceStatus(ulParam1);
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

