/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_Telematic_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_Telematic_Base_H
#define _clHSA_Telematic_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_Telematic_Base : public clHSA_Base
{
public:

    static clHSA_Telematic_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_Telematic_Base()        {}

    virtual ulword ulwGetConnectionStatus( );

    virtual ulword ulwGetRequestStatus( );

    virtual ulword ulwGetRequestType( );

    virtual ulword ulwGetRegistrationStatus( );

    virtual void vGetSetRegistrationUserName(GUI_String *out_result);

    virtual void vGetSetRegistrationPassword(GUI_String *out_result);

    virtual ulword ulwGetSetRegistrationCountry( );

    virtual void vGetRegistrationUserName(GUI_String *out_result);

    virtual void vGetRegistrationPassword(GUI_String *out_result);

    virtual ulword ulwGetRegistrationCountry( );

    virtual void vGetRegistrationDeviceId(GUI_String *out_result);

    virtual void vSetRegistrationUserName(const GUI_String * InputString);

    virtual void vSetRegistrationPassword(const GUI_String * InputString);

    virtual void vSetRegistrationCountry(ulword ulwCountryindex);

    virtual ulword ulwGetCountry(ulword ulwListEntryNr);

    virtual ulword ulwGetCountryList_Count( );

    virtual ulword ulwGetConfirmDialIn( );

    virtual void vSetConfirmDialOnceFlag(tbool blFlag);

    virtual tbool blIsConfirmDialOnceFlagSet( );

    virtual ulword ulwGetDownloadPOICnt( );

    virtual void vSetConfirmDialIn(ulword ulwDialOption);

    virtual void vRegisterForInfoServices(tbool blRegister);

    virtual void vSetNewHUFlag(tbool blFlag);

    virtual tbool blIsMailAdressValid(const GUI_String * InputString);

    virtual tbool blIsRegistrationDataValid(const GUI_String * InputString);

    virtual tbool blIsSpellerDisabled( );

    virtual void vGetSetRegistrationEMail(GUI_String *out_result);

    virtual void vGetRegistrationEMail(GUI_String *out_result);

    virtual void vSetRegistrationEMail(const GUI_String * InputString);

    virtual void vIncreaseSetupCnt(ulword ulwSetupType);

    virtual void vDecreaseSetupCnt(ulword ulwSetupType);

    virtual ulword ulwGetSetupRadius( );

    virtual ulword ulwGetSetupDownloadPoiCount( );

    virtual void vSetRequestLocationType(ulword ulwRequestLocationType);

    virtual void vUpdateNaviBlobInfoRelatedDP(ulword ulwPoiType, ulword ulwListindex);

    virtual void vGetTelematicDirection(GUI_String *out_result, ulword ulwPoiType, ulword ulwListindex);

    virtual void vGetTelematicDistance(GUI_String *out_result, ulword ulwRequestType, ulword ulwListindex);

    virtual void vSetDetailIndex(ulword ulwListIndex);

    virtual void vGetTelematicDetailText(GUI_String *out_result, ulword ulwRequestType);

    virtual void vGetTelematicPOINumber(GUI_String *out_result, ulword ulwPoiType);

    virtual tbool blIsPOIDialNumberAvailable(ulword ulwPoiType);

    virtual void vStartTelematicRequest(ulword ulwRequestType);

    virtual void vAbortTelematicRequest(ulword ulwRequestType);

    virtual ulword ulwGetLastStoredPOIs_count( );

    virtual slword slwGetLastStoredPOIsLatitude(ulword ulwListindex);

    virtual slword slwGetLastStoredPOIsLongitude(ulword ulwListindex);

    virtual void vGetLastStoredPOIsName(GUI_String *out_result, ulword ulwListindex);

    virtual void vGetLastStoredPOIsAddress(GUI_String *out_result, ulword ulwListindex);

    virtual void vUpdateDistanceDirection( );

    virtual void vSetFlightNumber(const GUI_String * InputString);

    virtual tbool blIsFlightRequestEnabled( );

    virtual void vFlightInfoResult(GUI_String *out_result, ulword ulwInformationType, ulword ulwListindex);

    virtual void vFlightInformationResult(GUI_String *out_result);

    virtual void vToggleFlightDirection( );

    virtual ulword ulwGetFlightDirection( );

    virtual void vToggleFlightDay( );

    virtual ulword ulwGetFlightDay( );

    virtual tbool blIsFlightNumberValid(const GUI_String * InputString);

    virtual ulword ulwGetLastFlightStatus_count( );

    virtual void vGetFlightNumber(GUI_String *out_result);

    virtual void vGetCurrentWeatherDate(GUI_String *out_result);

    virtual slword slwGetCurrentWeatherTemp( );

    virtual ulword ulwGetCurrentWeatherTempWindChill( );

    virtual ulword ulwGetCurrentWeatherHumidity( );

    virtual void vGetCurrentWeatherWinddirection(GUI_String *out_result);

    virtual void vGetCurrentWeatherWindspeed(GUI_String *out_result);

    virtual ulword ulwGetCurrentWeatherCondition( );

    virtual ulword ulwGetForecastWeatherCondition(ulword ulwListEntryNr);

    virtual ulword ulwGetForecastWeather_count( );

    virtual void vGetForecastWeatherDate(GUI_String *out_result, ulword ulwListindex);

    virtual slword slwGetForecastWeatherTempMax(ulword ulwListEntryNr);

    virtual ulword ulwGetForecastWeatherDayOfWeek(ulword ulwListEntryNr);

    virtual slword slwGetForecastWeatherTempMin(ulword ulwListEntryNr);

    virtual slword slwGetWeatherInfoLongitude( );

    virtual slword slwGetWeatherInfoLatitude( );

    virtual ulword ulwGetLastWeatherRequestTempMaxWindChill(ulword ulwListEntryNr);

    virtual ulword ulwGetLastWeatherRequestTempMinWindChill(ulword ulwListEntryNr);

    virtual ulword ulwGetLastWeatherRequestRainPropabiltiy(ulword ulwListEntryNr);

    virtual void vGetLastWeatherRequestCityName(GUI_String *out_result);

    virtual void vGetLastRequestLocationName(GUI_String *out_result);

    virtual tbool blIsLastWeatherRequestOutdated( );

    virtual tbool blIsRepeatLastRequestPossible( );

    virtual tbool blIsWeatherDataAvailable( );

    virtual slword slwGetPOISearchLongitude( );

    virtual slword slwGetPOISearchLatitude( );

    virtual void vGetEnteredSearchItem(GUI_String *out_result);

    virtual void vSetEnteredSearchItem(const GUI_String * InputString);

    virtual ulword ulwGetLastPoiSearch_count( );

    virtual slword slwGetLastPoiSearchLongitude(ulword ulwListindex);

    virtual slword slwGetLastPoiSearchLatitude(ulword ulwListindex);

    virtual void vGetLastPoiSearchName(GUI_String *out_result, ulword ulwListindex);

    virtual void vGetLastPoiSearchAddress(GUI_String *out_result, ulword ulwListindex);

    virtual slword slwGetFuelPricesLongitude( );

    virtual slword slwGetFuelPricesLatitude( );

    virtual void vSetFuelPricesLongitude(slword slwLongitude);

    virtual void vSetFuelPricesLatitude(slword slwLatitude);

    virtual ulword ulwGetLastFuelPrices_count( );

    virtual slword slwGetLastFuelPricesLatitude(ulword ulwListindex);

    virtual slword slwGetLastFuelPricesLongitude(ulword ulwListindex);

    virtual void vGetLastFuelPricesName(GUI_String *out_result, ulword ulwListindex);

    virtual void vGetLastFuelPricesAddress(GUI_String *out_result, ulword ulwListindex);

    virtual void vGetLastFuelPricesPhone(GUI_String *out_result, ulword ulwListindex);

    virtual void vGetLastFuelPricesPriceNew(GUI_String *out_result, ulword ulwListindex);

    virtual ulword ulwGetLastFuelPricesPrice(ulword ulwListindex);

    virtual ulword ulwGetLastFuelPricesDistance(ulword ulwListindex);

    virtual tbool blIsLastFuelPricesOutdated( );

    virtual void vClearLastFuelInfo( );

    virtual void vGetFuelType(GUI_String *out_result);

    virtual void vSetFuelType(ulword ulwFuelType);

    virtual ulword ulwGetRequestFuelType( );

    virtual ulword ulwGetRequestLocationType( );

    virtual ulword ulwGetTemperatureUnit( );

    virtual void vSetTemperatureUnit(ulword ulwTemperatureUnit);

    virtual void vPrepareSpellerEntryField(const GUI_String * EntryFieldValue, ulword ulwSpeller);

    virtual void vSpellerSetMaxCharCount(slword slwCount);

    virtual tbool blSpellerInputOccurred( );

    virtual void vSpellerDiscardInput( );

    virtual void vSpellerSetCharacter(const GUI_String * InputString);

    virtual void vGetSpellerEntryField(GUI_String *out_result);

    virtual void vSpellerGetHighlightedText(GUI_String *out_result);

    virtual ulword ulwGetSpellerMatchIndex( );

    virtual tbool blSpellerInvertGetLetterFunction( );

    virtual void vSpellerGetLetterFunction(GUI_String *out_result);

    virtual ulword ulwGetSpellerMatchFoundResult( );

    virtual ulword ulwSpellerGetCursorPos( );

    virtual void vAbortSendToCarDownload( );

    virtual void vAbortGasPricesRequest( );

    virtual tbool blGetServiceStatus(ulword ulwServiceType);

protected:
    clHSA_Telematic_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_Telematic_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_Telematic_Base_H

