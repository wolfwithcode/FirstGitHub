/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_Telematic_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_Telematic/clHSA_Telematic_Base.h"

clHSA_Telematic_Base* clHSA_Telematic_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_Telematic_Base.cpp.trc.h"
#endif


/**
 * Method: ulwGetConnectionStatus
  * Returns the current status of the data connection.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetConnectionStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetConnectionStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetRequestStatus
  * Returns the current status of the data connection.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetRequestStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetRequestStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetRequestType
  * Returns the request type.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetRequestType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetRequestType not implemented"));
   return 0;
}

/**
 * Method: ulwGetRegistrationStatus
  * Returns the current status of registration of the current user.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetRegistrationStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetRegistrationStatus not implemented"));
   return 0;
}

/**
 * Method: vGetSetRegistrationUserName
  * Get the String which is used during user input and when the interface SetRegisterForTelematic is called.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetSetRegistrationUserName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetSetRegistrationUserName not implemented"));
   
}

/**
 * Method: vGetSetRegistrationPassword
  * Get the String which is used during user input and when the interface SetRegisterForTelematic is called.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetSetRegistrationPassword(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetSetRegistrationPassword not implemented"));
   
}

/**
 * Method: ulwGetSetRegistrationCountry
  * Get the String which is used during user input and when the interface SetRegisterForTelematic is called.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetSetRegistrationCountry( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetSetRegistrationCountry not implemented"));
   return 0;
}

/**
 * Method: vGetRegistrationUserName
  * Method to get the User Name currently used for registration and delivered by Mware.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetRegistrationUserName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetRegistrationUserName not implemented"));
   
}

/**
 * Method: vGetRegistrationPassword
  * Method to get the Password currently used for registration and delivered by Mware.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetRegistrationPassword(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetRegistrationPassword not implemented"));
   
}

/**
 * Method: ulwGetRegistrationCountry
  * Method to get the Country currently used for registration and delivered by Mware.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetRegistrationCountry( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetRegistrationCountry not implemented"));
   return 0;
}

/**
 * Method: vGetRegistrationDeviceId
  * Method to Read the Device ID used for registration.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetRegistrationDeviceId(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetRegistrationDeviceId not implemented"));
   
}

/**
 * Method: vSetRegistrationUserName
  * Method to Read the string entered in speller 1.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSetRegistrationUserName(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetRegistrationUserName not implemented"));
   
}

/**
 * Method: vSetRegistrationPassword
  * Method to Read the string entered in speller 1.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSetRegistrationPassword(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetRegistrationPassword not implemented"));
   
}

/**
 * Method: vSetRegistrationCountry
  * Method to Read the string entered in speller 1.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSetRegistrationCountry(ulword ulwCountryindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCountryindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetRegistrationCountry not implemented"));
   
}

/**
 * Method: ulwGetCountry
  * Method to get the registration country.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetCountry(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetCountry not implemented"));
   return 0;
}

/**
 * Method: ulwGetCountryList_Count
  * Returns the number of elements of the country configuration list.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetCountryList_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetCountryList_Count not implemented"));
   return 0;
}

/**
 * Method: ulwGetConfirmDialIn
  * returns the current DialIn option for Connecting to the Telematic Service Provider
  * B1
 */
ulword clHSA_Telematic_Base::ulwGetConfirmDialIn( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetConfirmDialIn not implemented"));
   return 0;
}

/**
 * Method: vSetConfirmDialOnceFlag
  * Sets the flag to indicate the confirm dial option is once
  * B1
 */
void clHSA_Telematic_Base::vSetConfirmDialOnceFlag(tbool blFlag)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blFlag);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetConfirmDialOnceFlag not implemented"));
   
}

/**
 * Method: blIsConfirmDialOnceFlagSet
  * Method to check wether confirm dial in option is set
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blIsConfirmDialOnceFlagSet( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blIsConfirmDialOnceFlagSet not implemented"));
   return 0;
}

/**
 * Method: ulwGetDownloadPOICnt
  * Returns the POI's count to be downlaoded.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetDownloadPOICnt( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetDownloadPOICnt not implemented"));
   return 0;
}

/**
 * Method: vSetConfirmDialIn
  * sets the DialIn option for Connecting to the Telematic Service Provider
  * B1
 */
void clHSA_Telematic_Base::vSetConfirmDialIn(ulword ulwDialOption)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDialOption);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetConfirmDialIn not implemented"));
   
}

/**
 * Method: vRegisterForInfoServices
  * Method to start the registration for the Info(Telematic)Services.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vRegisterForInfoServices(tbool blRegister)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blRegister);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vRegisterForInfoServices not implemented"));
   
}

/**
 * Method: vSetNewHUFlag
  * Sets the flag to indicate the reset of new head unit
  * B1
 */
void clHSA_Telematic_Base::vSetNewHUFlag(tbool blFlag)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blFlag);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetNewHUFlag not implemented"));
   
}

/**
 * Method: blIsMailAdressValid
  * Method to validate Email Address
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blIsMailAdressValid(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blIsMailAdressValid not implemented"));
   return 0;
}

/**
 * Method: blIsRegistrationDataValid
  * Method to validate PIN/Password
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blIsRegistrationDataValid(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blIsRegistrationDataValid not implemented"));
   return 0;
}

/**
 * Method: blIsSpellerDisabled
  * Method to check the availability of the weather data
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blIsSpellerDisabled( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blIsSpellerDisabled not implemented"));
   return 0;
}

/**
 * Method: vGetSetRegistrationEMail
  * Get the String which is used during user input and when the interface SetRegisterForTelematic is called.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetSetRegistrationEMail(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetSetRegistrationEMail not implemented"));
   
}

/**
 * Method: vGetRegistrationEMail
  * Method to get the Email adress currently used for registration and delivered by Mware.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetRegistrationEMail(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetRegistrationEMail not implemented"));
   
}

/**
 * Method: vSetRegistrationEMail
  * Method to Read the string entered in speller 1.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSetRegistrationEMail(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetRegistrationEMail not implemented"));
   
}

/**
 * Method: vIncreaseSetupCnt
  * Increments the number of POI's / Radius count to be downlaoded /Searched via GOOGLE POI by value 1, default value = 6 and maxm value = 30
  * 
 */
void clHSA_Telematic_Base::vIncreaseSetupCnt(ulword ulwSetupType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSetupType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vIncreaseSetupCnt not implemented"));
   
}

/**
 * Method: vDecreaseSetupCnt
  * Decrements the number of POI's / Radius count to be downlaoded /Searched via GOOGLE POI by value 1, default value = 6 and min value = 1
  * 
 */
void clHSA_Telematic_Base::vDecreaseSetupCnt(ulword ulwSetupType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSetupType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vDecreaseSetupCnt not implemented"));
   
}

/**
 * Method: ulwGetSetupRadius
  * Method to get the radius size
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetSetupRadius( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetSetupRadius not implemented"));
   return 0;
}

/**
 * Method: ulwGetSetupDownloadPoiCount
  * Method to get the download poi count
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetSetupDownloadPoiCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetSetupDownloadPoiCount not implemented"));
   return 0;
}

/**
 * Method: vSetRequestLocationType
  * sets the request location type for requesting the Telematic services
  * B1
 */
void clHSA_Telematic_Base::vSetRequestLocationType(ulword ulwRequestLocationType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRequestLocationType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetRequestLocationType not implemented"));
   
}

/**
 * Method: vUpdateNaviBlobInfoRelatedDP
  * API will update navi datapool ex: lat, lon, name, phone, details which are required by navigation to make the file descriptor.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vUpdateNaviBlobInfoRelatedDP(ulword ulwPoiType, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPoiType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vUpdateNaviBlobInfoRelatedDP not implemented"));
   
}

/**
 * Method: vGetTelematicDirection
  * API will update navi datapool ex: lat, lon, name, phone, details which are required by navigation to make the file descriptor.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetTelematicDirection(GUI_String *out_result, ulword ulwPoiType, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPoiType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetTelematicDirection not implemented"));
   
}

/**
 * Method: vGetTelematicDistance
  * Method to Read content from the list of GOOGLEPOIs/StoredPOI's/GAS_PRICES
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetTelematicDistance(GUI_String *out_result, ulword ulwRequestType, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRequestType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetTelematicDistance not implemented"));
   
}

/**
 * Method: vSetDetailIndex
  * API will set the selected index from the list for which detailed info is required
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSetDetailIndex(ulword ulwListIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetDetailIndex not implemented"));
   
}

/**
 * Method: vGetTelematicDetailText
  * API will concatinate the telematic info details for the selected index ex: lat, lon, name, phone, details .
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetTelematicDetailText(GUI_String *out_result, ulword ulwRequestType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRequestType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetTelematicDetailText not implemented"));
   
}

/**
 * Method: vGetTelematicPOINumber
  * Phone number
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetTelematicPOINumber(GUI_String *out_result, ulword ulwPoiType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPoiType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetTelematicPOINumber not implemented"));
   
}

/**
 * Method: blIsPOIDialNumberAvailable
  * Phone number available or not
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blIsPOIDialNumberAvailable(ulword ulwPoiType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPoiType);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blIsPOIDialNumberAvailable not implemented"));
   return 0;
}

/**
 * Method: vStartTelematicRequest
  * Starts request for Telematic services
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vStartTelematicRequest(ulword ulwRequestType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRequestType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vStartTelematicRequest not implemented"));
   
}

/**
 * Method: vAbortTelematicRequest
  * Aborts request for Telematic services
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vAbortTelematicRequest(ulword ulwRequestType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRequestType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vAbortTelematicRequest not implemented"));
   
}

/**
 * Method: ulwGetLastStoredPOIs_count
  * Returns the number of POIs in the list of downladed POIs
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetLastStoredPOIs_count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetLastStoredPOIs_count not implemented"));
   return 0;
}

/**
 * Method: slwGetLastStoredPOIsLatitude
  * Method to Read content from the list of stored POIs
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetLastStoredPOIsLatitude(ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetLastStoredPOIsLatitude not implemented"));
   return 0;
}

/**
 * Method: slwGetLastStoredPOIsLongitude
  * Method to Read content from the list of stored POIs
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetLastStoredPOIsLongitude(ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetLastStoredPOIsLongitude not implemented"));
   return 0;
}

/**
 * Method: vGetLastStoredPOIsName
  * Method to Read content from the list of stored POIs
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetLastStoredPOIsName(GUI_String *out_result, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetLastStoredPOIsName not implemented"));
   
}

/**
 * Method: vGetLastStoredPOIsAddress
  * Method to Read content from the list of stored POIs
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetLastStoredPOIsAddress(GUI_String *out_result, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetLastStoredPOIsAddress not implemented"));
   
}

/**
 * Method: vUpdateDistanceDirection
  * Method to Update Distance and Direction for stored POIs wrt current position
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vUpdateDistanceDirection( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Telematic::vUpdateDistanceDirection not implemented"));
   
}

/**
 * Method: vSetFlightNumber
  * Method to Read the string entered in speller 1.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSetFlightNumber(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetFlightNumber not implemented"));
   
}

/**
 * Method: blIsFlightRequestEnabled
  * Method to check wether flight number is set
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blIsFlightRequestEnabled( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blIsFlightRequestEnabled not implemented"));
   return 0;
}

/**
 * Method: vFlightInfoResult
  * Method to Return the result of Flight Status
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vFlightInfoResult(GUI_String *out_result, ulword ulwInformationType, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInformationType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vFlightInfoResult not implemented"));
   
}

/**
 * Method: vFlightInformationResult
  * Method to Return the result of Flight Status
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vFlightInformationResult(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vFlightInformationResult not implemented"));
   
}

/**
 * Method: vToggleFlightDirection
  * Method to toggle the flight direction
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vToggleFlightDirection( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Telematic::vToggleFlightDirection not implemented"));
   
}

/**
 * Method: ulwGetFlightDirection
  * Method to get the flight direction
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetFlightDirection( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetFlightDirection not implemented"));
   return 0;
}

/**
 * Method: vToggleFlightDay
  * Method to toggle the flight day
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vToggleFlightDay( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Telematic::vToggleFlightDay not implemented"));
   
}

/**
 * Method: ulwGetFlightDay
  * Method to get the flight day
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetFlightDay( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetFlightDay not implemented"));
   return 0;
}

/**
 * Method: blIsFlightNumberValid
  * Method to validate Flight Number
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blIsFlightNumberValid(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blIsFlightNumberValid not implemented"));
   return 0;
}

/**
 * Method: ulwGetLastFlightStatus_count
  * Returns the number of Flight Info present in the list
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetLastFlightStatus_count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetLastFlightStatus_count not implemented"));
   return 0;
}

/**
 * Method: vGetFlightNumber
  * Method to get the Flight number
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetFlightNumber(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetFlightNumber not implemented"));
   
}

/**
 * Method: vGetCurrentWeatherDate
  * Method to Read content from the list of stored POIs
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetCurrentWeatherDate(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetCurrentWeatherDate not implemented"));
   
}

/**
 * Method: slwGetCurrentWeatherTemp
  * Returns the current temperature of city for the specific date
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetCurrentWeatherTemp( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetCurrentWeatherTemp not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentWeatherTempWindChill
  * Returns the current wind chill of city for the specific date
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetCurrentWeatherTempWindChill( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetCurrentWeatherTempWindChill not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentWeatherHumidity
  * Returns the humidity of city for the specific date
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetCurrentWeatherHumidity( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetCurrentWeatherHumidity not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentWeatherWinddirection
  * Returns the wind direction of city for the specific date
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetCurrentWeatherWinddirection(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetCurrentWeatherWinddirection not implemented"));
   
}

/**
 * Method: vGetCurrentWeatherWindspeed
  * Returns the wind speed of city for the specific date
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetCurrentWeatherWindspeed(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetCurrentWeatherWindspeed not implemented"));
   
}

/**
 * Method: ulwGetCurrentWeatherCondition
  * Returns the weather condition of the city for the specific date
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetCurrentWeatherCondition( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetCurrentWeatherCondition not implemented"));
   return 0;
}

/**
 * Method: ulwGetForecastWeatherCondition
  * Returns the weather condition of the city for the specific date
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetForecastWeatherCondition(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetForecastWeatherCondition not implemented"));
   return 0;
}

/**
 * Method: ulwGetForecastWeather_count
  * Returns the number of Weather infos in the list of latest weather request
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetForecastWeather_count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetForecastWeather_count not implemented"));
   return 0;
}

/**
 * Method: vGetForecastWeatherDate
  * Method to Read content from the list of stored POIs
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetForecastWeatherDate(GUI_String *out_result, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetForecastWeatherDate not implemented"));
   
}

/**
 * Method: slwGetForecastWeatherTempMax
  * Returns the max temperature of city for the specific date
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetForecastWeatherTempMax(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetForecastWeatherTempMax not implemented"));
   return 0;
}

/**
 * Method: ulwGetForecastWeatherDayOfWeek
  * Returns the day of the week
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetForecastWeatherDayOfWeek(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetForecastWeatherDayOfWeek not implemented"));
   return 0;
}

/**
 * Method: slwGetForecastWeatherTempMin
  * Returns the minimum temperature of city for the specific date
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetForecastWeatherTempMin(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetForecastWeatherTempMin not implemented"));
   return 0;
}

/**
 * Method: slwGetWeatherInfoLongitude
  * Method to Get the Position coordinate for which weather forecast will be requested
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetWeatherInfoLongitude( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetWeatherInfoLongitude not implemented"));
   return 0;
}

/**
 * Method: slwGetWeatherInfoLatitude
  * Method to Get the Position coordinate for which weather forecast will be requested
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetWeatherInfoLatitude( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetWeatherInfoLatitude not implemented"));
   return 0;
}

/**
 * Method: ulwGetLastWeatherRequestTempMaxWindChill
  * Returns the max wind chill of city for the specific date
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetLastWeatherRequestTempMaxWindChill(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetLastWeatherRequestTempMaxWindChill not implemented"));
   return 0;
}

/**
 * Method: ulwGetLastWeatherRequestTempMinWindChill
  * Returns the min wind chill of city for the specific date
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetLastWeatherRequestTempMinWindChill(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetLastWeatherRequestTempMinWindChill not implemented"));
   return 0;
}

/**
 * Method: ulwGetLastWeatherRequestRainPropabiltiy
  * Returns the rain probability of city for the specific date
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetLastWeatherRequestRainPropabiltiy(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetLastWeatherRequestRainPropabiltiy not implemented"));
   return 0;
}

/**
 * Method: vGetLastWeatherRequestCityName
  * Method to Read content from the list of Weather Info
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetLastWeatherRequestCityName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetLastWeatherRequestCityName not implemented"));
   
}

/**
 * Method: vGetLastRequestLocationName
  * Method to Read the last requested destination name
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetLastRequestLocationName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetLastRequestLocationName not implemented"));
   
}

/**
 * Method: blIsLastWeatherRequestOutdated
  * Method to Get the Info if the available weather information is outdated
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blIsLastWeatherRequestOutdated( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blIsLastWeatherRequestOutdated not implemented"));
   return 0;
}

/**
 * Method: blIsRepeatLastRequestPossible
  * Method to check the availability of last request
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blIsRepeatLastRequestPossible( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blIsRepeatLastRequestPossible not implemented"));
   return 0;
}

/**
 * Method: blIsWeatherDataAvailable
  * Method to check the availability of the weather data
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blIsWeatherDataAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blIsWeatherDataAvailable not implemented"));
   return 0;
}

/**
 * Method: slwGetPOISearchLongitude
  * Method to Get the Position coordinate for which POI Search will be requested
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetPOISearchLongitude( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetPOISearchLongitude not implemented"));
   return 0;
}

/**
 * Method: slwGetPOISearchLatitude
  * Method to Get the Position coordinate for which POI Search will be requested
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetPOISearchLatitude( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetPOISearchLatitude not implemented"));
   return 0;
}

/**
 * Method: vGetEnteredSearchItem
  * Method to Read the Search string entered in speller 1.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetEnteredSearchItem(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetEnteredSearchItem not implemented"));
   
}

/**
 * Method: vSetEnteredSearchItem
  * Method to Read the Search string entered in speller 1.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSetEnteredSearchItem(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetEnteredSearchItem not implemented"));
   
}

/**
 * Method: ulwGetLastPoiSearch_count
  * Returns the number of Search results in the list of latest weather request
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetLastPoiSearch_count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetLastPoiSearch_count not implemented"));
   return 0;
}

/**
 * Method: slwGetLastPoiSearchLongitude
  * Method to Read position content from the result list of found POIs.
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetLastPoiSearchLongitude(ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetLastPoiSearchLongitude not implemented"));
   return 0;
}

/**
 * Method: slwGetLastPoiSearchLatitude
  * Method to Read position content from the result list of found POIs.
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetLastPoiSearchLatitude(ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetLastPoiSearchLatitude not implemented"));
   return 0;
}

/**
 * Method: vGetLastPoiSearchName
  * Method to Read content from the list of found POIs.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetLastPoiSearchName(GUI_String *out_result, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetLastPoiSearchName not implemented"));
   
}

/**
 * Method: vGetLastPoiSearchAddress
  * Method to Read content from the list of found POIs.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetLastPoiSearchAddress(GUI_String *out_result, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetLastPoiSearchAddress not implemented"));
   
}

/**
 * Method: slwGetFuelPricesLongitude
  * Method to Get the Position coordinate for which POI Search will be requested
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetFuelPricesLongitude( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetFuelPricesLongitude not implemented"));
   return 0;
}

/**
 * Method: slwGetFuelPricesLatitude
  * Method to Get the Position coordinate for which POI Search will be requested
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetFuelPricesLatitude( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetFuelPricesLatitude not implemented"));
   return 0;
}

/**
 * Method: vSetFuelPricesLongitude
  * Method to Get the Position coordinate for which POI Search will be requested
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSetFuelPricesLongitude(slword slwLongitude)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwLongitude);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetFuelPricesLongitude not implemented"));
   
}

/**
 * Method: vSetFuelPricesLatitude
  * Method to Get the Position coordinate for which POI Search will be requested
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSetFuelPricesLatitude(slword slwLatitude)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwLatitude);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetFuelPricesLatitude not implemented"));
   
}

/**
 * Method: ulwGetLastFuelPrices_count
  * Returns the number of Search results in the list of latest gas prices request.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetLastFuelPrices_count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetLastFuelPrices_count not implemented"));
   return 0;
}

/**
 * Method: slwGetLastFuelPricesLatitude
  * Method to Read position content from the result list of gas prices.
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetLastFuelPricesLatitude(ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetLastFuelPricesLatitude not implemented"));
   return 0;
}

/**
 * Method: slwGetLastFuelPricesLongitude
  * Method to Read position content from the result list of gas prices.
  * NISSAN2.0
 */
slword clHSA_Telematic_Base::slwGetLastFuelPricesLongitude(ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Telematic::slwGetLastFuelPricesLongitude not implemented"));
   return 0;
}

/**
 * Method: vGetLastFuelPricesName
  * Method to Read content from the list of gas prices.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetLastFuelPricesName(GUI_String *out_result, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetLastFuelPricesName not implemented"));
   
}

/**
 * Method: vGetLastFuelPricesAddress
  * Method to Read content from the list gas prices.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetLastFuelPricesAddress(GUI_String *out_result, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetLastFuelPricesAddress not implemented"));
   
}

/**
 * Method: vGetLastFuelPricesPhone
  * Method to Read content from the list of gas prices.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetLastFuelPricesPhone(GUI_String *out_result, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetLastFuelPricesPhone not implemented"));
   
}

/**
 * Method: vGetLastFuelPricesPriceNew
  * Method to Read content from the list of gas prices.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetLastFuelPricesPriceNew(GUI_String *out_result, ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetLastFuelPricesPriceNew not implemented"));
   
}

/**
 * Method: ulwGetLastFuelPricesPrice
  * Method to Read content from the list of gas prices.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetLastFuelPricesPrice(ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetLastFuelPricesPrice not implemented"));
   return 0;
}

/**
 * Method: ulwGetLastFuelPricesDistance
  * Method to Read content from the list of gas prices.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetLastFuelPricesDistance(ulword ulwListindex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListindex);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetLastFuelPricesDistance not implemented"));
   return 0;
}

/**
 * Method: blIsLastFuelPricesOutdated
  * Method to Get the Info if the available gas price information is outdated
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blIsLastFuelPricesOutdated( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blIsLastFuelPricesOutdated not implemented"));
   return 0;
}

/**
 * Method: vClearLastFuelInfo
  * Method to clear the previous fuel info
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vClearLastFuelInfo( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Telematic::vClearLastFuelInfo not implemented"));
   
}

/**
 * Method: vGetFuelType
  * Method to Get the Fuel Type.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetFuelType(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetFuelType not implemented"));
   
}

/**
 * Method: vSetFuelType
  * Method to Set the Fuel Type.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSetFuelType(ulword ulwFuelType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwFuelType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetFuelType not implemented"));
   
}

/**
 * Method: ulwGetRequestFuelType
  * Returns the type of fuel
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetRequestFuelType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetRequestFuelType not implemented"));
   return 0;
}

/**
 * Method: ulwGetRequestLocationType
  * Method to Get the Request Location Type.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetRequestLocationType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetRequestLocationType not implemented"));
   return 0;
}

/**
 * Method: ulwGetTemperatureUnit
  * Method to Get the Temperature unit
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetTemperatureUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetTemperatureUnit not implemented"));
   return 0;
}

/**
 * Method: vSetTemperatureUnit
  * Method to Set the Temperature unit
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSetTemperatureUnit(ulword ulwTemperatureUnit)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTemperatureUnit);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSetTemperatureUnit not implemented"));
   
}

/**
 * Method: vPrepareSpellerEntryField
  * Used to give an initial value to the input field of the speller, and to indicate the active speller.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vPrepareSpellerEntryField(const GUI_String * EntryFieldValue, ulword ulwSpeller)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( EntryFieldValue);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSpeller);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vPrepareSpellerEntryField not implemented"));
   
}

/**
 * Method: vSpellerSetMaxCharCount
  * Used to set the max number of characters which can be entered in the SpellerEntryField. The application has to know this value, in order to prevent entering characters after the maximum of allowed characters was reached. 
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSpellerSetMaxCharCount(slword slwCount)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwCount);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSpellerSetMaxCharCount not implemented"));
   
}

/**
 * Method: blSpellerInputOccurred
  * Used to set the max number of characters which can be entered in the SpellerEntryField. The application has to know this value, in order to prevent entering characters after the maximum of allowed characters was reached. 
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blSpellerInputOccurred( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blSpellerInputOccurred not implemented"));
   return 0;
}

/**
 * Method: vSpellerDiscardInput
  * discards the resultset of the speller input
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSpellerDiscardInput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Telematic::vSpellerDiscardInput not implemented"));
   
}

/**
 * Method: vSpellerSetCharacter
  * Used in the speller to send the character chosen in the widget to the application. Special unicodes which will be sent: F817 (cursor left), F818 (cursor right), F81C (DTMF). This APICall will also be used for deleting characters, by sending the unicode 0008. 
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSpellerSetCharacter(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSpellerSetCharacter not implemented"));
   
}

/**
 * Method: vGetSpellerEntryField
  * returns the string which will be shown in the input textfield of the speller
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vGetSpellerEntryField(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vGetSpellerEntryField not implemented"));
   
}

/**
 * Method: vSpellerGetHighlightedText
  * The initial text set by the APICall GetSpellerEntryField, wil be taken as proposal and will be sent to the entry field. This proposal can be displayed inverted by using the property "matchText". If only one character is entered, this proposal will be discarded and this function returns an empty string. If the cursor is moved,  this method also returns an empty string.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSpellerGetHighlightedText(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSpellerGetHighlightedText not implemented"));
   
}

/**
 * Method: ulwGetSpellerMatchIndex
  * Returns the position of the corresponding entry if matching string found in corresponding entry list.
  * NISSAN2.0(If any list of city will be there )
 */
ulword clHSA_Telematic_Base::ulwGetSpellerMatchIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetSpellerMatchIndex not implemented"));
   return 0;
}

/**
 * Method: blSpellerInvertGetLetterFunction
  * Inverts the logic of the SpellerGetLetterFunction. Has to be set by the application, for example in a freetext-speller, in order to disable some buttons and, at the same time, to enable the cursor-buttons and alt/sub/nr. 
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blSpellerInvertGetLetterFunction( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blSpellerInvertGetLetterFunction not implemented"));
   return 0;
}

/**
 * Method: vSpellerGetLetterFunction
  * Returns the characters which should be displayed enabled in the speller.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vSpellerGetLetterFunction(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Telematic::vSpellerGetLetterFunction not implemented"));
   
}

/**
 * Method: ulwGetSpellerMatchFoundResult
  * Returns the status of the speller string searched into the corresponding entry list.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwGetSpellerMatchFoundResult( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwGetSpellerMatchFoundResult not implemented"));
   return 0;
}

/**
 * Method: ulwSpellerGetCursorPos
  * Returns the position of the cursor. The application has to manage the position of the cursor by using the special unicodes F817 and F818. The cursor is independent from the length of the text. "Left" would position the cursor between the last and the last but one  character. "Right" will position the cursor after the last character.
  * NISSAN2.0
 */
ulword clHSA_Telematic_Base::ulwSpellerGetCursorPos( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Telematic::ulwSpellerGetCursorPos not implemented"));
   return 0;
}

/**
 * Method: vAbortSendToCarDownload
  * Method to abort the STC download request.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vAbortSendToCarDownload( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Telematic::vAbortSendToCarDownload not implemented"));
   
}

/**
 * Method: vAbortGasPricesRequest
  * Method to abort the gas prices listing request.
  * NISSAN2.0
 */
void clHSA_Telematic_Base::vAbortGasPricesRequest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Telematic::vAbortGasPricesRequest not implemented"));
   
}

/**
 * Method: blGetServiceStatus
  * Method to Get the Service status
  * NISSAN2.0
 */
tbool clHSA_Telematic_Base::blGetServiceStatus(ulword ulwServiceType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwServiceType);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Telematic::blGetServiceStatus not implemented"));
   return 0;
}

