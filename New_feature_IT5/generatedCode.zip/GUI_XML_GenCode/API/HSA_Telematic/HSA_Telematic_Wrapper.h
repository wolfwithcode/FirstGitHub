/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Telematic_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_Telematic_Wrapper_H
#define _HSA_Telematic_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: GetConnectionStatus
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetConnectionStatus( void);

/**
 * Function: GetRequestStatus
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetRequestStatus( void);

/**
 * Function: GetRequestType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetRequestType( void);

/**
 * Function: GetRegistrationStatus
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetRegistrationStatus( void);

/**
 * Function: GetSetRegistrationUserName
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetSetRegistrationUserName(GUI_String *out_result);

/**
 * Function: GetSetRegistrationPassword
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetSetRegistrationPassword(GUI_String *out_result);

/**
 * Function: GetSetRegistrationCountry
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetSetRegistrationCountry( void);

/**
 * Function: GetRegistrationUserName
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetRegistrationUserName(GUI_String *out_result);

/**
 * Function: GetRegistrationPassword
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetRegistrationPassword(GUI_String *out_result);

/**
 * Function: GetRegistrationCountry
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetRegistrationCountry( void);

/**
 * Function: GetRegistrationDeviceId
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetRegistrationDeviceId(GUI_String *out_result);

/**
 * Function: SetRegistrationUserName
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSetRegistrationUserName(const GUI_String * InputString);

/**
 * Function: SetRegistrationPassword
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSetRegistrationPassword(const GUI_String * InputString);

/**
 * Function: SetRegistrationCountry
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSetRegistrationCountry(ulword ulwCountryindex);

/**
 * Function: GetCountry
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetCountry(ulword ulwListEntryNr);

/**
 * Function: GetCountryList_Count
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetCountryList_Count( void);

/**
 * Function: GetConfirmDialIn
 * B1
 * NISSAN
 */
ulword HSA_Telematic__ulwGetConfirmDialIn( void);

/**
 * Function: SetConfirmDialOnceFlag
 * B1
 * NISSAN
 */
void HSA_Telematic__vSetConfirmDialOnceFlag(tbool blFlag);

/**
 * Function: IsConfirmDialOnceFlagSet
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blIsConfirmDialOnceFlagSet( void);

/**
 * Function: GetDownloadPOICnt
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetDownloadPOICnt( void);

/**
 * Function: SetConfirmDialIn
 * B1
 * NISSAN
 */
void HSA_Telematic__vSetConfirmDialIn(ulword ulwDialOption);

/**
 * Function: RegisterForInfoServices
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vRegisterForInfoServices(tbool blRegister);

/**
 * Function: SetNewHUFlag
 * B1
 * NISSAN
 */
void HSA_Telematic__vSetNewHUFlag(tbool blFlag);

/**
 * Function: IsMailAdressValid
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blIsMailAdressValid(const GUI_String * InputString);

/**
 * Function: IsRegistrationDataValid
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blIsRegistrationDataValid(const GUI_String * InputString);

/**
 * Function: IsSpellerDisabled
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blIsSpellerDisabled( void);

/**
 * Function: GetSetRegistrationEMail
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetSetRegistrationEMail(GUI_String *out_result);

/**
 * Function: GetRegistrationEMail
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetRegistrationEMail(GUI_String *out_result);

/**
 * Function: SetRegistrationEMail
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSetRegistrationEMail(const GUI_String * InputString);

/**
 * Function: IncreaseSetupCnt
 * 
 * NISSAN
 */
void HSA_Telematic__vIncreaseSetupCnt(ulword ulwSetupType);

/**
 * Function: DecreaseSetupCnt
 * 
 * NISSAN
 */
void HSA_Telematic__vDecreaseSetupCnt(ulword ulwSetupType);

/**
 * Function: GetSetupRadius
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetSetupRadius( void);

/**
 * Function: GetSetupDownloadPoiCount
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetSetupDownloadPoiCount( void);

/**
 * Function: SetRequestLocationType
 * B1
 * NISSAN
 */
void HSA_Telematic__vSetRequestLocationType(ulword ulwRequestLocationType);

/**
 * Function: UpdateNaviBlobInfoRelatedDP
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vUpdateNaviBlobInfoRelatedDP(ulword ulwPoiType, ulword ulwListindex);

/**
 * Function: GetTelematicDirection
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetTelematicDirection(GUI_String *out_result, ulword ulwPoiType, ulword ulwListindex);

/**
 * Function: GetTelematicDistance
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetTelematicDistance(GUI_String *out_result, ulword ulwRequestType, ulword ulwListindex);

/**
 * Function: SetDetailIndex
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSetDetailIndex(ulword ulwListIndex);

/**
 * Function: GetTelematicDetailText
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetTelematicDetailText(GUI_String *out_result, ulword ulwRequestType);

/**
 * Function: GetTelematicPOINumber
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetTelematicPOINumber(GUI_String *out_result, ulword ulwPoiType);

/**
 * Function: IsPOIDialNumberAvailable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blIsPOIDialNumberAvailable(ulword ulwPoiType);

/**
 * Function: StartTelematicRequest
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vStartTelematicRequest(ulword ulwRequestType);

/**
 * Function: AbortTelematicRequest
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vAbortTelematicRequest(ulword ulwRequestType);

/**
 * Function: GetLastStoredPOIs_count
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetLastStoredPOIs_count( void);

/**
 * Function: GetLastStoredPOIsLatitude
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetLastStoredPOIsLatitude(ulword ulwListindex);

/**
 * Function: GetLastStoredPOIsLongitude
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetLastStoredPOIsLongitude(ulword ulwListindex);

/**
 * Function: GetLastStoredPOIsName
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetLastStoredPOIsName(GUI_String *out_result, ulword ulwListindex);

/**
 * Function: GetLastStoredPOIsAddress
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetLastStoredPOIsAddress(GUI_String *out_result, ulword ulwListindex);

/**
 * Function: UpdateDistanceDirection
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vUpdateDistanceDirection( void);

/**
 * Function: SetFlightNumber
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSetFlightNumber(const GUI_String * InputString);

/**
 * Function: IsFlightRequestEnabled
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blIsFlightRequestEnabled( void);

/**
 * Function: FlightInfoResult
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vFlightInfoResult(GUI_String *out_result, ulword ulwInformationType, ulword ulwListindex);

/**
 * Function: FlightInformationResult
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vFlightInformationResult(GUI_String *out_result);

/**
 * Function: ToggleFlightDirection
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vToggleFlightDirection( void);

/**
 * Function: GetFlightDirection
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetFlightDirection( void);

/**
 * Function: ToggleFlightDay
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vToggleFlightDay( void);

/**
 * Function: GetFlightDay
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetFlightDay( void);

/**
 * Function: IsFlightNumberValid
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blIsFlightNumberValid(const GUI_String * InputString);

/**
 * Function: GetLastFlightStatus_count
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetLastFlightStatus_count( void);

/**
 * Function: GetFlightNumber
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetFlightNumber(GUI_String *out_result);

/**
 * Function: GetCurrentWeatherDate
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetCurrentWeatherDate(GUI_String *out_result);

/**
 * Function: GetCurrentWeatherTemp
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetCurrentWeatherTemp( void);

/**
 * Function: GetCurrentWeatherTempWindChill
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetCurrentWeatherTempWindChill( void);

/**
 * Function: GetCurrentWeatherHumidity
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetCurrentWeatherHumidity( void);

/**
 * Function: GetCurrentWeatherWinddirection
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetCurrentWeatherWinddirection(GUI_String *out_result);

/**
 * Function: GetCurrentWeatherWindspeed
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetCurrentWeatherWindspeed(GUI_String *out_result);

/**
 * Function: GetCurrentWeatherCondition
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetCurrentWeatherCondition( void);

/**
 * Function: GetForecastWeatherCondition
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetForecastWeatherCondition(ulword ulwListEntryNr);

/**
 * Function: GetForecastWeather_count
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetForecastWeather_count( void);

/**
 * Function: GetForecastWeatherDate
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetForecastWeatherDate(GUI_String *out_result, ulword ulwListindex);

/**
 * Function: GetForecastWeatherTempMax
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetForecastWeatherTempMax(ulword ulwListEntryNr);

/**
 * Function: GetForecastWeatherDayOfWeek
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetForecastWeatherDayOfWeek(ulword ulwListEntryNr);

/**
 * Function: GetForecastWeatherTempMin
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetForecastWeatherTempMin(ulword ulwListEntryNr);

/**
 * Function: GetWeatherInfoLongitude
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetWeatherInfoLongitude( void);

/**
 * Function: GetWeatherInfoLatitude
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetWeatherInfoLatitude( void);

/**
 * Function: GetLastWeatherRequestTempMaxWindChill
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetLastWeatherRequestTempMaxWindChill(ulword ulwListEntryNr);

/**
 * Function: GetLastWeatherRequestTempMinWindChill
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetLastWeatherRequestTempMinWindChill(ulword ulwListEntryNr);

/**
 * Function: GetLastWeatherRequestRainPropabiltiy
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetLastWeatherRequestRainPropabiltiy(ulword ulwListEntryNr);

/**
 * Function: GetLastWeatherRequestCityName
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetLastWeatherRequestCityName(GUI_String *out_result);

/**
 * Function: GetLastRequestLocationName
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetLastRequestLocationName(GUI_String *out_result);

/**
 * Function: IsLastWeatherRequestOutdated
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blIsLastWeatherRequestOutdated( void);

/**
 * Function: IsRepeatLastRequestPossible
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blIsRepeatLastRequestPossible( void);

/**
 * Function: IsWeatherDataAvailable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blIsWeatherDataAvailable( void);

/**
 * Function: GetPOISearchLongitude
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetPOISearchLongitude( void);

/**
 * Function: GetPOISearchLatitude
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetPOISearchLatitude( void);

/**
 * Function: GetEnteredSearchItem
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetEnteredSearchItem(GUI_String *out_result);

/**
 * Function: SetEnteredSearchItem
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSetEnteredSearchItem(const GUI_String * InputString);

/**
 * Function: GetLastPoiSearch_count
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetLastPoiSearch_count( void);

/**
 * Function: GetLastPoiSearchLongitude
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetLastPoiSearchLongitude(ulword ulwListindex);

/**
 * Function: GetLastPoiSearchLatitude
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetLastPoiSearchLatitude(ulword ulwListindex);

/**
 * Function: GetLastPoiSearchName
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetLastPoiSearchName(GUI_String *out_result, ulword ulwListindex);

/**
 * Function: GetLastPoiSearchAddress
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetLastPoiSearchAddress(GUI_String *out_result, ulword ulwListindex);

/**
 * Function: GetFuelPricesLongitude
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetFuelPricesLongitude( void);

/**
 * Function: GetFuelPricesLatitude
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetFuelPricesLatitude( void);

/**
 * Function: SetFuelPricesLongitude
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSetFuelPricesLongitude(slword slwLongitude);

/**
 * Function: SetFuelPricesLatitude
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSetFuelPricesLatitude(slword slwLatitude);

/**
 * Function: GetLastFuelPrices_count
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetLastFuelPrices_count( void);

/**
 * Function: GetLastFuelPricesLatitude
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetLastFuelPricesLatitude(ulword ulwListindex);

/**
 * Function: GetLastFuelPricesLongitude
 * NISSAN2.0
 * NISSAN
 */
slword HSA_Telematic__slwGetLastFuelPricesLongitude(ulword ulwListindex);

/**
 * Function: GetLastFuelPricesName
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetLastFuelPricesName(GUI_String *out_result, ulword ulwListindex);

/**
 * Function: GetLastFuelPricesAddress
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetLastFuelPricesAddress(GUI_String *out_result, ulword ulwListindex);

/**
 * Function: GetLastFuelPricesPhone
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetLastFuelPricesPhone(GUI_String *out_result, ulword ulwListindex);

/**
 * Function: GetLastFuelPricesPriceNew
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetLastFuelPricesPriceNew(GUI_String *out_result, ulword ulwListindex);

/**
 * Function: GetLastFuelPricesPrice
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetLastFuelPricesPrice(ulword ulwListindex);

/**
 * Function: GetLastFuelPricesDistance
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetLastFuelPricesDistance(ulword ulwListindex);

/**
 * Function: IsLastFuelPricesOutdated
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blIsLastFuelPricesOutdated( void);

/**
 * Function: ClearLastFuelInfo
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vClearLastFuelInfo( void);

/**
 * Function: GetFuelType
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetFuelType(GUI_String *out_result);

/**
 * Function: SetFuelType
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSetFuelType(ulword ulwFuelType);

/**
 * Function: GetRequestFuelType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetRequestFuelType( void);

/**
 * Function: GetRequestLocationType
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetRequestLocationType( void);

/**
 * Function: GetTemperatureUnit
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetTemperatureUnit( void);

/**
 * Function: SetTemperatureUnit
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSetTemperatureUnit(ulword ulwTemperatureUnit);

/**
 * Function: PrepareSpellerEntryField
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vPrepareSpellerEntryField(const GUI_String * EntryFieldValue, ulword ulwSpeller);

/**
 * Function: SpellerSetMaxCharCount
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSpellerSetMaxCharCount(slword slwCount);

/**
 * Function: SpellerInputOccurred
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blSpellerInputOccurred( void);

/**
 * Function: SpellerDiscardInput
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSpellerDiscardInput( void);

/**
 * Function: SpellerSetCharacter
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSpellerSetCharacter(const GUI_String * InputString);

/**
 * Function: GetSpellerEntryField
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vGetSpellerEntryField(GUI_String *out_result);

/**
 * Function: SpellerGetHighlightedText
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSpellerGetHighlightedText(GUI_String *out_result);

/**
 * Function: GetSpellerMatchIndex
 * NISSAN2.0(If any list of city will be there )
 * NISSAN
 */
ulword HSA_Telematic__ulwGetSpellerMatchIndex( void);

/**
 * Function: SpellerInvertGetLetterFunction
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blSpellerInvertGetLetterFunction( void);

/**
 * Function: SpellerGetLetterFunction
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vSpellerGetLetterFunction(GUI_String *out_result);

/**
 * Function: GetSpellerMatchFoundResult
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwGetSpellerMatchFoundResult( void);

/**
 * Function: SpellerGetCursorPos
 * NISSAN2.0
 * NISSAN
 */
ulword HSA_Telematic__ulwSpellerGetCursorPos( void);

/**
 * Function: AbortSendToCarDownload
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vAbortSendToCarDownload( void);

/**
 * Function: AbortGasPricesRequest
 * NISSAN2.0
 * NISSAN
 */
void HSA_Telematic__vAbortGasPricesRequest( void);

/**
 * Function: GetServiceStatus
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_Telematic__blGetServiceStatus(ulword ulwServiceType);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_Telematic_H

