/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Telematic_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_Telematic_Wrapper.h"
#include "clHSA_Telematic_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_Telematic_Trace.h"
#include "hmi_trace.h"

ulword HSA_Telematic__ulwGetConnectionStatus( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTION_STATUS  ) ); 
        }
      ret=pInst->ulwGetConnectionStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTION_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetRequestStatus( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REQUEST_STATUS  ) ); 
        }
      ret=pInst->ulwGetRequestStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REQUEST_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetRequestType( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REQUEST_TYPE  ) ); 
        }
      ret=pInst->ulwGetRequestType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REQUEST_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetRegistrationStatus( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REGISTRATION_STATUS  ) ); 
        }
      ret=pInst->ulwGetRegistrationStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REGISTRATION_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vGetSetRegistrationUserName(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SET_REGISTRATION_USER_NAME  ) ); 
        }
      pInst->vGetSetRegistrationUserName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SET_REGISTRATION_USER_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetSetRegistrationPassword(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SET_REGISTRATION_PASSWORD  ) ); 
        }
      pInst->vGetSetRegistrationPassword(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SET_REGISTRATION_PASSWORD | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Telematic__ulwGetSetRegistrationCountry( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SET_REGISTRATION_COUNTRY  ) ); 
        }
      ret=pInst->ulwGetSetRegistrationCountry();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SET_REGISTRATION_COUNTRY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vGetRegistrationUserName(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REGISTRATION_USER_NAME  ) ); 
        }
      pInst->vGetRegistrationUserName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REGISTRATION_USER_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetRegistrationPassword(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REGISTRATION_PASSWORD  ) ); 
        }
      pInst->vGetRegistrationPassword(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REGISTRATION_PASSWORD | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Telematic__ulwGetRegistrationCountry( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REGISTRATION_COUNTRY  ) ); 
        }
      ret=pInst->ulwGetRegistrationCountry();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REGISTRATION_COUNTRY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vGetRegistrationDeviceId(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REGISTRATION_DEVICE_ID  ) ); 
        }
      pInst->vGetRegistrationDeviceId(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REGISTRATION_DEVICE_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vSetRegistrationUserName(const GUI_String * InputString)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_REGISTRATION_USER_NAME | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSetRegistrationUserName( InputString);

    }
}

void HSA_Telematic__vSetRegistrationPassword(const GUI_String * InputString)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_REGISTRATION_PASSWORD | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSetRegistrationPassword( InputString);

    }
}

void HSA_Telematic__vSetRegistrationCountry(ulword ulwCountryindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_REGISTRATION_COUNTRY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCountryindex); 
        }
      pInst->vSetRegistrationCountry(ulwCountryindex);

    }
}

ulword HSA_Telematic__ulwGetCountry(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_COUNTRY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetCountry(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_COUNTRY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetCountryList_Count( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_COUNTRY_LIST__COUNT  ) ); 
        }
      ret=pInst->ulwGetCountryList_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_COUNTRY_LIST__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetConfirmDialIn( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CONFIRM_DIAL_IN  ) ); 
        }
      ret=pInst->ulwGetConfirmDialIn();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CONFIRM_DIAL_IN | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vSetConfirmDialOnceFlag(tbool blFlag)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_CONFIRM_DIAL_ONCE_FLAG | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blFlag); 
        }
      pInst->vSetConfirmDialOnceFlag(blFlag);

    }
}

tbool HSA_Telematic__blIsConfirmDialOnceFlagSet( )
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_CONFIRM_DIAL_ONCE_FLAG_SET  ) ); 
        }
      ret=pInst->blIsConfirmDialOnceFlagSet();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_CONFIRM_DIAL_ONCE_FLAG_SET | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetDownloadPOICnt( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_DOWNLOAD_POI_CNT  ) ); 
        }
      ret=pInst->ulwGetDownloadPOICnt();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_DOWNLOAD_POI_CNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vSetConfirmDialIn(ulword ulwDialOption)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_CONFIRM_DIAL_IN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDialOption); 
        }
      pInst->vSetConfirmDialIn(ulwDialOption);

    }
}

void HSA_Telematic__vRegisterForInfoServices(tbool blRegister)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__REGISTER_FOR_INFO_SERVICES | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blRegister); 
        }
      pInst->vRegisterForInfoServices(blRegister);

    }
}

void HSA_Telematic__vSetNewHUFlag(tbool blFlag)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_NEW_HU_FLAG | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blFlag); 
        }
      pInst->vSetNewHUFlag(blFlag);

    }
}

tbool HSA_Telematic__blIsMailAdressValid(const GUI_String * InputString)
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_MAIL_ADRESS_VALID | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      ret=pInst->blIsMailAdressValid( InputString);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_MAIL_ADRESS_VALID | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Telematic__blIsRegistrationDataValid(const GUI_String * InputString)
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_REGISTRATION_DATA_VALID | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      ret=pInst->blIsRegistrationDataValid( InputString);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_REGISTRATION_DATA_VALID | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Telematic__blIsSpellerDisabled( )
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_SPELLER_DISABLED  ) ); 
        }
      ret=pInst->blIsSpellerDisabled();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_SPELLER_DISABLED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vGetSetRegistrationEMail(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SET_REGISTRATION_E_MAIL  ) ); 
        }
      pInst->vGetSetRegistrationEMail(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SET_REGISTRATION_E_MAIL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetRegistrationEMail(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REGISTRATION_E_MAIL  ) ); 
        }
      pInst->vGetRegistrationEMail(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REGISTRATION_E_MAIL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vSetRegistrationEMail(const GUI_String * InputString)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_REGISTRATION_E_MAIL | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSetRegistrationEMail( InputString);

    }
}

void HSA_Telematic__vIncreaseSetupCnt(ulword ulwSetupType)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__INCREASE_SETUP_CNT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSetupType); 
        }
      pInst->vIncreaseSetupCnt(ulwSetupType);

    }
}

void HSA_Telematic__vDecreaseSetupCnt(ulword ulwSetupType)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__DECREASE_SETUP_CNT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSetupType); 
        }
      pInst->vDecreaseSetupCnt(ulwSetupType);

    }
}

ulword HSA_Telematic__ulwGetSetupRadius( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SETUP_RADIUS  ) ); 
        }
      ret=pInst->ulwGetSetupRadius();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SETUP_RADIUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetSetupDownloadPoiCount( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SETUP_DOWNLOAD_POI_COUNT  ) ); 
        }
      ret=pInst->ulwGetSetupDownloadPoiCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SETUP_DOWNLOAD_POI_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vSetRequestLocationType(ulword ulwRequestLocationType)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_REQUEST_LOCATION_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRequestLocationType); 
        }
      pInst->vSetRequestLocationType(ulwRequestLocationType);

    }
}

void HSA_Telematic__vUpdateNaviBlobInfoRelatedDP(ulword ulwPoiType, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__UPDATE_NAVI_BLOB_INFO_RELATED_DP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPoiType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__UPDATE_NAVI_BLOB_INFO_RELATED_DP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vUpdateNaviBlobInfoRelatedDP(ulwPoiType, ulwListindex);

    }
}

void HSA_Telematic__vGetTelematicDirection(GUI_String *out_result, ulword ulwPoiType, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_TELEMATIC_DIRECTION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPoiType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_TELEMATIC_DIRECTION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vGetTelematicDirection(out_result, ulwPoiType, ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_TELEMATIC_DIRECTION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetTelematicDistance(GUI_String *out_result, ulword ulwRequestType, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_TELEMATIC_DISTANCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRequestType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_TELEMATIC_DISTANCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vGetTelematicDistance(out_result, ulwRequestType, ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_TELEMATIC_DISTANCE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vSetDetailIndex(ulword ulwListIndex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_DETAIL_INDEX | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListIndex); 
        }
      pInst->vSetDetailIndex(ulwListIndex);

    }
}

void HSA_Telematic__vGetTelematicDetailText(GUI_String *out_result, ulword ulwRequestType)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_TELEMATIC_DETAIL_TEXT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRequestType); 
        }
      pInst->vGetTelematicDetailText(out_result, ulwRequestType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_TELEMATIC_DETAIL_TEXT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetTelematicPOINumber(GUI_String *out_result, ulword ulwPoiType)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_TELEMATIC_POI_NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPoiType); 
        }
      pInst->vGetTelematicPOINumber(out_result, ulwPoiType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_TELEMATIC_POI_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Telematic__blIsPOIDialNumberAvailable(ulword ulwPoiType)
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_POI_DIAL_NUMBER_AVAILABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPoiType); 
        }
      ret=pInst->blIsPOIDialNumberAvailable(ulwPoiType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_POI_DIAL_NUMBER_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vStartTelematicRequest(ulword ulwRequestType)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__START_TELEMATIC_REQUEST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRequestType); 
        }
      pInst->vStartTelematicRequest(ulwRequestType);

    }
}

void HSA_Telematic__vAbortTelematicRequest(ulword ulwRequestType)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__ABORT_TELEMATIC_REQUEST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRequestType); 
        }
      pInst->vAbortTelematicRequest(ulwRequestType);

    }
}

ulword HSA_Telematic__ulwGetLastStoredPOIs_count( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_COUNT  ) ); 
        }
      ret=pInst->ulwGetLastStoredPOIs_count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Telematic__slwGetLastStoredPOIsLatitude(ulword ulwListindex)
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_LATITUDE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      ret=pInst->slwGetLastStoredPOIsLatitude(ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_LATITUDE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Telematic__slwGetLastStoredPOIsLongitude(ulword ulwListindex)
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_LONGITUDE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      ret=pInst->slwGetLastStoredPOIsLongitude(ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_LONGITUDE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vGetLastStoredPOIsName(GUI_String *out_result, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vGetLastStoredPOIsName(out_result, ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetLastStoredPOIsAddress(GUI_String *out_result, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_ADDRESS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vGetLastStoredPOIsAddress(out_result, ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_STORED_PO_IS_ADDRESS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vUpdateDistanceDirection( )
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__UPDATE_DISTANCE_DIRECTION  ) ); 
        }
      pInst->vUpdateDistanceDirection();

    }
}

void HSA_Telematic__vSetFlightNumber(const GUI_String * InputString)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_FLIGHT_NUMBER | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSetFlightNumber( InputString);

    }
}

tbool HSA_Telematic__blIsFlightRequestEnabled( )
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_FLIGHT_REQUEST_ENABLED  ) ); 
        }
      ret=pInst->blIsFlightRequestEnabled();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_FLIGHT_REQUEST_ENABLED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vFlightInfoResult(GUI_String *out_result, ulword ulwInformationType, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__FLIGHT_INFO_RESULT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInformationType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__FLIGHT_INFO_RESULT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vFlightInfoResult(out_result, ulwInformationType, ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__FLIGHT_INFO_RESULT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vFlightInformationResult(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__FLIGHT_INFORMATION_RESULT  ) ); 
        }
      pInst->vFlightInformationResult(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__FLIGHT_INFORMATION_RESULT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vToggleFlightDirection( )
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_FLIGHT_DIRECTION  ) ); 
        }
      pInst->vToggleFlightDirection();

    }
}

ulword HSA_Telematic__ulwGetFlightDirection( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FLIGHT_DIRECTION  ) ); 
        }
      ret=pInst->ulwGetFlightDirection();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FLIGHT_DIRECTION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vToggleFlightDay( )
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_FLIGHT_DAY  ) ); 
        }
      pInst->vToggleFlightDay();

    }
}

ulword HSA_Telematic__ulwGetFlightDay( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FLIGHT_DAY  ) ); 
        }
      ret=pInst->ulwGetFlightDay();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FLIGHT_DAY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Telematic__blIsFlightNumberValid(const GUI_String * InputString)
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_FLIGHT_NUMBER_VALID | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      ret=pInst->blIsFlightNumberValid( InputString);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_FLIGHT_NUMBER_VALID | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetLastFlightStatus_count( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FLIGHT_STATUS_COUNT  ) ); 
        }
      ret=pInst->ulwGetLastFlightStatus_count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FLIGHT_STATUS_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vGetFlightNumber(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FLIGHT_NUMBER  ) ); 
        }
      pInst->vGetFlightNumber(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FLIGHT_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetCurrentWeatherDate(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_DATE  ) ); 
        }
      pInst->vGetCurrentWeatherDate(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

slword HSA_Telematic__slwGetCurrentWeatherTemp( )
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_TEMP  ) ); 
        }
      ret=pInst->slwGetCurrentWeatherTemp();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_TEMP | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetCurrentWeatherTempWindChill( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_TEMP_WIND_CHILL  ) ); 
        }
      ret=pInst->ulwGetCurrentWeatherTempWindChill();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_TEMP_WIND_CHILL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetCurrentWeatherHumidity( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_HUMIDITY  ) ); 
        }
      ret=pInst->ulwGetCurrentWeatherHumidity();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_HUMIDITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vGetCurrentWeatherWinddirection(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_WINDDIRECTION  ) ); 
        }
      pInst->vGetCurrentWeatherWinddirection(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_WINDDIRECTION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetCurrentWeatherWindspeed(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_WINDSPEED  ) ); 
        }
      pInst->vGetCurrentWeatherWindspeed(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_WINDSPEED | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Telematic__ulwGetCurrentWeatherCondition( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_CONDITION  ) ); 
        }
      ret=pInst->ulwGetCurrentWeatherCondition();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_WEATHER_CONDITION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetForecastWeatherCondition(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_CONDITION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetForecastWeatherCondition(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_CONDITION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetForecastWeather_count( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_COUNT  ) ); 
        }
      ret=pInst->ulwGetForecastWeather_count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vGetForecastWeatherDate(GUI_String *out_result, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_DATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vGetForecastWeatherDate(out_result, ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

slword HSA_Telematic__slwGetForecastWeatherTempMax(ulword ulwListEntryNr)
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_TEMP_MAX | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->slwGetForecastWeatherTempMax(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_TEMP_MAX | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetForecastWeatherDayOfWeek(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_DAY_OF_WEEK | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetForecastWeatherDayOfWeek(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_DAY_OF_WEEK | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Telematic__slwGetForecastWeatherTempMin(ulword ulwListEntryNr)
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_TEMP_MIN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->slwGetForecastWeatherTempMin(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FORECAST_WEATHER_TEMP_MIN | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Telematic__slwGetWeatherInfoLongitude( )
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_WEATHER_INFO_LONGITUDE  ) ); 
        }
      ret=pInst->slwGetWeatherInfoLongitude();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_WEATHER_INFO_LONGITUDE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Telematic__slwGetWeatherInfoLatitude( )
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_WEATHER_INFO_LATITUDE  ) ); 
        }
      ret=pInst->slwGetWeatherInfoLatitude();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_WEATHER_INFO_LATITUDE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetLastWeatherRequestTempMaxWindChill(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_WEATHER_REQUEST_TEMP_MAX_WIND_CHILL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetLastWeatherRequestTempMaxWindChill(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_WEATHER_REQUEST_TEMP_MAX_WIND_CHILL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetLastWeatherRequestTempMinWindChill(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_WEATHER_REQUEST_TEMP_MIN_WIND_CHILL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetLastWeatherRequestTempMinWindChill(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_WEATHER_REQUEST_TEMP_MIN_WIND_CHILL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetLastWeatherRequestRainPropabiltiy(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_WEATHER_REQUEST_RAIN_PROPABILTIY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetLastWeatherRequestRainPropabiltiy(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_WEATHER_REQUEST_RAIN_PROPABILTIY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vGetLastWeatherRequestCityName(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_WEATHER_REQUEST_CITY_NAME  ) ); 
        }
      pInst->vGetLastWeatherRequestCityName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_WEATHER_REQUEST_CITY_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetLastRequestLocationName(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_REQUEST_LOCATION_NAME  ) ); 
        }
      pInst->vGetLastRequestLocationName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_REQUEST_LOCATION_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Telematic__blIsLastWeatherRequestOutdated( )
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_LAST_WEATHER_REQUEST_OUTDATED  ) ); 
        }
      ret=pInst->blIsLastWeatherRequestOutdated();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_LAST_WEATHER_REQUEST_OUTDATED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Telematic__blIsRepeatLastRequestPossible( )
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_REPEAT_LAST_REQUEST_POSSIBLE  ) ); 
        }
      ret=pInst->blIsRepeatLastRequestPossible();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_REPEAT_LAST_REQUEST_POSSIBLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Telematic__blIsWeatherDataAvailable( )
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_WEATHER_DATA_AVAILABLE  ) ); 
        }
      ret=pInst->blIsWeatherDataAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_WEATHER_DATA_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

slword HSA_Telematic__slwGetPOISearchLongitude( )
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_POI_SEARCH_LONGITUDE  ) ); 
        }
      ret=pInst->slwGetPOISearchLongitude();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_POI_SEARCH_LONGITUDE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Telematic__slwGetPOISearchLatitude( )
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_POI_SEARCH_LATITUDE  ) ); 
        }
      ret=pInst->slwGetPOISearchLatitude();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_POI_SEARCH_LATITUDE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vGetEnteredSearchItem(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_ENTERED_SEARCH_ITEM  ) ); 
        }
      pInst->vGetEnteredSearchItem(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_ENTERED_SEARCH_ITEM | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vSetEnteredSearchItem(const GUI_String * InputString)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_ENTERED_SEARCH_ITEM | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSetEnteredSearchItem( InputString);

    }
}

ulword HSA_Telematic__ulwGetLastPoiSearch_count( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_COUNT  ) ); 
        }
      ret=pInst->ulwGetLastPoiSearch_count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Telematic__slwGetLastPoiSearchLongitude(ulword ulwListindex)
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_LONGITUDE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      ret=pInst->slwGetLastPoiSearchLongitude(ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_LONGITUDE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Telematic__slwGetLastPoiSearchLatitude(ulword ulwListindex)
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_LATITUDE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      ret=pInst->slwGetLastPoiSearchLatitude(ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_LATITUDE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vGetLastPoiSearchName(GUI_String *out_result, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vGetLastPoiSearchName(out_result, ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetLastPoiSearchAddress(GUI_String *out_result, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_ADDRESS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vGetLastPoiSearchAddress(out_result, ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_POI_SEARCH_ADDRESS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

slword HSA_Telematic__slwGetFuelPricesLongitude( )
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_PRICES_LONGITUDE  ) ); 
        }
      ret=pInst->slwGetFuelPricesLongitude();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_PRICES_LONGITUDE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Telematic__slwGetFuelPricesLatitude( )
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_PRICES_LATITUDE  ) ); 
        }
      ret=pInst->slwGetFuelPricesLatitude();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_PRICES_LATITUDE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vSetFuelPricesLongitude(slword slwLongitude)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_FUEL_PRICES_LONGITUDE | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwLongitude); 
        }
      pInst->vSetFuelPricesLongitude(slwLongitude);

    }
}

void HSA_Telematic__vSetFuelPricesLatitude(slword slwLatitude)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_FUEL_PRICES_LATITUDE | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwLatitude); 
        }
      pInst->vSetFuelPricesLatitude(slwLatitude);

    }
}

ulword HSA_Telematic__ulwGetLastFuelPrices_count( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_COUNT  ) ); 
        }
      ret=pInst->ulwGetLastFuelPrices_count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Telematic__slwGetLastFuelPricesLatitude(ulword ulwListindex)
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_LATITUDE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      ret=pInst->slwGetLastFuelPricesLatitude(ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_LATITUDE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Telematic__slwGetLastFuelPricesLongitude(ulword ulwListindex)
{
    slword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_LONGITUDE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      ret=pInst->slwGetLastFuelPricesLongitude(ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_LONGITUDE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vGetLastFuelPricesName(GUI_String *out_result, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vGetLastFuelPricesName(out_result, ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetLastFuelPricesAddress(GUI_String *out_result, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_ADDRESS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vGetLastFuelPricesAddress(out_result, ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_ADDRESS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetLastFuelPricesPhone(GUI_String *out_result, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_PHONE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vGetLastFuelPricesPhone(out_result, ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_PHONE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vGetLastFuelPricesPriceNew(GUI_String *out_result, ulword ulwListindex)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_PRICE_NEW | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      pInst->vGetLastFuelPricesPriceNew(out_result, ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_PRICE_NEW | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Telematic__ulwGetLastFuelPricesPrice(ulword ulwListindex)
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_PRICE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      ret=pInst->ulwGetLastFuelPricesPrice(ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_PRICE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetLastFuelPricesDistance(ulword ulwListindex)
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_DISTANCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListindex); 
        }
      ret=pInst->ulwGetLastFuelPricesDistance(ulwListindex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_FUEL_PRICES_DISTANCE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Telematic__blIsLastFuelPricesOutdated( )
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_LAST_FUEL_PRICES_OUTDATED  ) ); 
        }
      ret=pInst->blIsLastFuelPricesOutdated();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__IS_LAST_FUEL_PRICES_OUTDATED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vClearLastFuelInfo( )
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__CLEAR_LAST_FUEL_INFO  ) ); 
        }
      pInst->vClearLastFuelInfo();

    }
}

void HSA_Telematic__vGetFuelType(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_TYPE  ) ); 
        }
      pInst->vGetFuelType(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_FUEL_TYPE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vSetFuelType(ulword ulwFuelType)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_FUEL_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwFuelType); 
        }
      pInst->vSetFuelType(ulwFuelType);

    }
}

ulword HSA_Telematic__ulwGetRequestFuelType( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REQUEST_FUEL_TYPE  ) ); 
        }
      ret=pInst->ulwGetRequestFuelType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REQUEST_FUEL_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetRequestLocationType( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REQUEST_LOCATION_TYPE  ) ); 
        }
      ret=pInst->ulwGetRequestLocationType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_REQUEST_LOCATION_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwGetTemperatureUnit( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_TEMPERATURE_UNIT  ) ); 
        }
      ret=pInst->ulwGetTemperatureUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_TEMPERATURE_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vSetTemperatureUnit(ulword ulwTemperatureUnit)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SET_TEMPERATURE_UNIT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTemperatureUnit); 
        }
      pInst->vSetTemperatureUnit(ulwTemperatureUnit);

    }
}

void HSA_Telematic__vPrepareSpellerEntryField(const GUI_String * EntryFieldValue, ulword ulwSpeller)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__PREPARE_SPELLER_ENTRY_FIELD | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)EntryFieldValue->ulwLen_+1, EntryFieldValue->pubBuffer_);
             poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__PREPARE_SPELLER_ENTRY_FIELD | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSpeller); 
        }
      pInst->vPrepareSpellerEntryField( EntryFieldValue, ulwSpeller);

    }
}

void HSA_Telematic__vSpellerSetMaxCharCount(slword slwCount)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_MAX_CHAR_COUNT | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwCount); 
        }
      pInst->vSpellerSetMaxCharCount(slwCount);

    }
}

tbool HSA_Telematic__blSpellerInputOccurred( )
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INPUT_OCCURRED  ) ); 
        }
      ret=pInst->blSpellerInputOccurred();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INPUT_OCCURRED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vSpellerDiscardInput( )
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_DISCARD_INPUT  ) ); 
        }
      pInst->vSpellerDiscardInput();

    }
}

void HSA_Telematic__vSpellerSetCharacter(const GUI_String * InputString)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_CHARACTER | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSpellerSetCharacter( InputString);

    }
}

void HSA_Telematic__vGetSpellerEntryField(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_ENTRY_FIELD  ) ); 
        }
      pInst->vGetSpellerEntryField(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_ENTRY_FIELD | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Telematic__vSpellerGetHighlightedText(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_HIGHLIGHTED_TEXT  ) ); 
        }
      pInst->vSpellerGetHighlightedText(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_HIGHLIGHTED_TEXT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Telematic__ulwGetSpellerMatchIndex( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_MATCH_INDEX  ) ); 
        }
      ret=pInst->ulwGetSpellerMatchIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_MATCH_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Telematic__blSpellerInvertGetLetterFunction( )
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION  ) ); 
        }
      ret=pInst->blSpellerInvertGetLetterFunction();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vSpellerGetLetterFunction(GUI_String *out_result)
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_LETTER_FUNCTION  ) ); 
        }
      pInst->vSpellerGetLetterFunction(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_LETTER_FUNCTION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Telematic__ulwGetSpellerMatchFoundResult( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_MATCH_FOUND_RESULT  ) ); 
        }
      ret=pInst->ulwGetSpellerMatchFoundResult();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_MATCH_FOUND_RESULT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Telematic__ulwSpellerGetCursorPos( )
{
    ulword ret = 0;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS  ) ); 
        }
      ret=pInst->ulwSpellerGetCursorPos();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Telematic__vAbortSendToCarDownload( )
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__ABORT_SEND_TO_CAR_DOWNLOAD  ) ); 
        }
      pInst->vAbortSendToCarDownload();

    }
}

void HSA_Telematic__vAbortGasPricesRequest( )
{
    
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__ABORT_GAS_PRICES_REQUEST  ) ); 
        }
      pInst->vAbortGasPricesRequest();

    }
}

tbool HSA_Telematic__blGetServiceStatus(ulword ulwServiceType)
{
    tbool ret = false;
    clHSA_Telematic_Base *pInst=clHSA_Telematic_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SERVICE_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwServiceType); 
        }
      ret=pInst->blGetServiceStatus(ulwServiceType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_TELEMATIC), (tU16)(HSA_API_ENTRYPOINT__GET_SERVICE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

#ifdef __cplusplus
}
#endif

