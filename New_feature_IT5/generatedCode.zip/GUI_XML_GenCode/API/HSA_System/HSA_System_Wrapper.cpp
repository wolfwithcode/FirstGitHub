/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_System_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_System_Wrapper.h"
#include "clHSA_System_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_System_Trace.h"
#include "hmi_trace.h"

void HSA_System__vStartTouchScreenCalibration( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__START_TOUCH_SCREEN_CALIBRATION  ) ); 
        }
      pInst->vStartTouchScreenCalibration();

    }
}

void HSA_System__vAbortTouchScreenCalibration( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__ABORT_TOUCH_SCREEN_CALIBRATION  ) ); 
        }
      pInst->vAbortTouchScreenCalibration();

    }
}

ulword HSA_System__ulwGetCalibrationPageNumber( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CALIBRATION_PAGE_NUMBER  ) ); 
        }
      ret=pInst->ulwGetCalibrationPageNumber();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CALIBRATION_PAGE_NUMBER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vNewCalibrationPageDrawn( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__NEW_CALIBRATION_PAGE_DRAWN  ) ); 
        }
      pInst->vNewCalibrationPageDrawn();

    }
}

tbool HSA_System__blAutoModeEnableDisable( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__AUTO_MODE_ENABLE_DISABLE  ) ); 
        }
      ret=pInst->blAutoModeEnableDisable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__AUTO_MODE_ENABLE_DISABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetCalibrationStatus( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CALIBRATION_STATUS  ) ); 
        }
      ret=pInst->ulwGetCalibrationStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CALIBRATION_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetKDSData(GUI_String *out_result, ulword ulwKDSEntry)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_KDS_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwKDSEntry); 
        }
      pInst->vGetKDSData(out_result, ulwKDSEntry);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_KDS_DATA | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vCheckClockScreenMode( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_CLOCK_SCREEN_MODE  ) ); 
        }
      pInst->vCheckClockScreenMode();

    }
}

void HSA_System__vSetClockScreenMode(tbool blMode)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_CLOCK_SCREEN_MODE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vSetClockScreenMode(blMode);

    }
}

void HSA_System__vSetClockScreenTimer(tbool blAction)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_CLOCK_SCREEN_TIMER | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blAction); 
        }
      pInst->vSetClockScreenTimer(blAction);

    }
}

void HSA_System__vSetApplicationPalette(ulword ulwPalette)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_APPLICATION_PALETTE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPalette); 
        }
      pInst->vSetApplicationPalette(ulwPalette);

    }
}

void HSA_System__vResetTransitionCounter( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__RESET_TRANSITION_COUNTER  ) ); 
        }
      pInst->vResetTransitionCounter();

    }
}

void HSA_System__vIncrementTransitionCounter( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__INCREMENT_TRANSITION_COUNTER  ) ); 
        }
      pInst->vIncrementTransitionCounter();

    }
}

void HSA_System__vDecrementTransitionCounter( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__DECREMENT_TRANSITION_COUNTER  ) ); 
        }
      pInst->vDecrementTransitionCounter();

    }
}

void HSA_System__vGetVersion( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_VERSION  ) ); 
        }
      pInst->vGetVersion();

    }
}

tbool HSA_System__blIsOverSpeedActive( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_OVER_SPEED_ACTIVE  ) ); 
        }
      ret=pInst->blIsOverSpeedActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_OVER_SPEED_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetEcoDrivingDataSymbolType( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_DRIVING_DATA_SYMBOL_TYPE  ) ); 
        }
      ret=pInst->ulwGetEcoDrivingDataSymbolType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_DRIVING_DATA_SYMBOL_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetEcoDrivingScore( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_DRIVING_SCORE  ) ); 
        }
      ret=pInst->ulwGetEcoDrivingScore();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_DRIVING_SCORE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetEcoPullingAwayScore( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_PULLING_AWAY_SCORE  ) ); 
        }
      ret=pInst->ulwGetEcoPullingAwayScore();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_PULLING_AWAY_SCORE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetEcoCruiseScore( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_CRUISE_SCORE  ) ); 
        }
      ret=pInst->ulwGetEcoCruiseScore();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_CRUISE_SCORE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetEcoDecelerationScore( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_DECELERATION_SCORE  ) ); 
        }
      ret=pInst->ulwGetEcoDecelerationScore();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_DECELERATION_SCORE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetEcoDDrivingHistoryValues(ulword ulwListEntryNumber)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_D_DRIVING_HISTORY_VALUES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      ret=pInst->ulwGetEcoDDrivingHistoryValues(ulwListEntryNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_D_DRIVING_HISTORY_VALUES | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetEcoDDrivingHistoryDateString(GUI_String *out_result, ulword ulwListEntryNumber)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_D_DRIVING_HISTORY_DATE_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      pInst->vGetEcoDDrivingHistoryDateString(out_result, ulwListEntryNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_D_DRIVING_HISTORY_DATE_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetEcoDDrivingHistoryDateMonth(ulword ulwListEntryNumber)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_D_DRIVING_HISTORY_DATE_MONTH | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      ret=pInst->ulwGetEcoDDrivingHistoryDateMonth(ulwListEntryNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_D_DRIVING_HISTORY_DATE_MONTH | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetEcoDDrivingHistoryDateDay(ulword ulwListEntryNumber)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_D_DRIVING_HISTORY_DATE_DAY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      ret=pInst->ulwGetEcoDDrivingHistoryDateDay(ulwListEntryNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ECO_D_DRIVING_HISTORY_DATE_DAY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vResetEcoDrivingHistory( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__RESET_ECO_DRIVING_HISTORY  ) ); 
        }
      pInst->vResetEcoDrivingHistory();

    }
}

ulword HSA_System__ulwXMLVersionCheckStatus( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__XML_VERSION_CHECK_STATUS  ) ); 
        }
      ret=pInst->ulwXMLVersionCheckStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__XML_VERSION_CHECK_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetXMLVersionString(GUI_String *out_result, ulword ulwDevice)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_XML_VERSION_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDevice); 
        }
      pInst->vGetXMLVersionString(out_result, ulwDevice);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_XML_VERSION_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vSetMeterAudioWarning(ulword ulwWarningState, const GUI_String * WarningText)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_METER_AUDIO_WARNING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwWarningState); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_METER_AUDIO_WARNING | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)WarningText->ulwLen_+1, WarningText->pubBuffer_);
         }
      pInst->vSetMeterAudioWarning(ulwWarningState,  WarningText);

    }
}

void HSA_System__vSetMeterSMSPopup(ulword ulwSMSState, ulword ulwListEntryNr)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_METER_SMS_POPUP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSMSState); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_METER_SMS_POPUP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetMeterSMSPopup(ulwSMSState, ulwListEntryNr);

    }
}

void HSA_System__vSetSMSMessageTextPopupState(tbool blStatus)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_SMS_MESSAGE_TEXT_POPUP_STATE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blStatus); 
        }
      pInst->vSetSMSMessageTextPopupState(blStatus);

    }
}

tbool HSA_System__blIsMeterConnected( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_METER_CONNECTED  ) ); 
        }
      ret=pInst->blIsMeterConnected();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_METER_CONNECTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSetXMLVersionDisclaimerAcceptance(tbool blStatus)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_XML_VERSION_DISCLAIMER_ACCEPTANCE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blStatus); 
        }
      pInst->vSetXMLVersionDisclaimerAcceptance(blStatus);

    }
}

tbool HSA_System__blGetXMLVersionDisclaimerAcceptance( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_XML_VERSION_DISCLAIMER_ACCEPTANCE  ) ); 
        }
      ret=pInst->blGetXMLVersionDisclaimerAcceptance();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_XML_VERSION_DISCLAIMER_ACCEPTANCE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetSrvSystemSelfTest(ulword ulwSystemSelfTest)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SRV_SYSTEM_SELF_TEST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSystemSelfTest); 
        }
      ret=pInst->ulwGetSrvSystemSelfTest(ulwSystemSelfTest);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SRV_SYSTEM_SELF_TEST | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetSrvSDCardWriteProtectionStatus( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SRV_SD_CARD_WRITE_PROTECTION_STATUS  ) ); 
        }
      ret=pInst->ulwGetSrvSDCardWriteProtectionStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SRV_SD_CARD_WRITE_PROTECTION_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetImmobilizerLockState( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_IMMOBILIZER_LOCK_STATE  ) ); 
        }
      ret=pInst->ulwGetImmobilizerLockState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_IMMOBILIZER_LOCK_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSetImmobilizerLockStateToUnLock( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_IMMOBILIZER_LOCK_STATE_TO_UN_LOCK  ) ); 
        }
      pInst->vSetImmobilizerLockStateToUnLock();

    }
}

ulword HSA_System__ulwGetSrvSystemConfig(ulword ulwSystemConfig)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SRV_SYSTEM_CONFIG | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSystemConfig); 
        }
      ret=pInst->ulwGetSrvSystemConfig(ulwSystemConfig);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SRV_SYSTEM_CONFIG | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetXMTunerFirmwareVersion(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_XM_TUNER_FIRMWARE_VERSION  ) ); 
        }
      pInst->vGetXMTunerFirmwareVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_XM_TUNER_FIRMWARE_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetBTHF_BoxVersion(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_BTHF__BOX_VERSION  ) ); 
        }
      pInst->vGetBTHF_BoxVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_BTHF__BOX_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetDisplayMode( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DISPLAY_MODE  ) ); 
        }
      ret=pInst->ulwGetDisplayMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DISPLAY_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetDisplayTestScreen( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DISPLAY_TEST_SCREEN  ) ); 
        }
      ret=pInst->ulwGetDisplayTestScreen();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DISPLAY_TEST_SCREEN | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blGetNavDisclaimerConfirmed( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_NAV_DISCLAIMER_CONFIRMED  ) ); 
        }
      ret=pInst->blGetNavDisclaimerConfirmed();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_NAV_DISCLAIMER_CONFIRMED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSetNavDisclaimerConfirmed( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_NAV_DISCLAIMER_CONFIRMED  ) ); 
        }
      pInst->vSetNavDisclaimerConfirmed();

    }
}

void HSA_System__vDisableDestinationInputWhileDriving( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__DISABLE_DESTINATION_INPUT_WHILE_DRIVING  ) ); 
        }
      pInst->vDisableDestinationInputWhileDriving();

    }
}

tbool HSA_System__blGetDestinationInputWhileDriving( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_INPUT_WHILE_DRIVING  ) ); 
        }
      ret=pInst->blGetDestinationInputWhileDriving();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DESTINATION_INPUT_WHILE_DRIVING | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSetBeepMode(ulword ulwListEntryNr)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_BEEP_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetBeepMode(ulwListEntryNr);

    }
}

ulword HSA_System__ulwGetBeepMode( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_BEEP_MODE  ) ); 
        }
      ret=pInst->ulwGetBeepMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_BEEP_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vToggleDisplayMode( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_DISPLAY_MODE  ) ); 
        }
      pInst->vToggleDisplayMode();

    }
}

void HSA_System__vLanguageIconSelected( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__LANGUAGE_ICON_SELECTED  ) ); 
        }
      pInst->vLanguageIconSelected();

    }
}

void HSA_System__vGetSystemSerialNo(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_SERIAL_NO  ) ); 
        }
      pInst->vGetSystemSerialNo(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_SERIAL_NO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetSystemDeviceNo(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_DEVICE_NO  ) ); 
        }
      pInst->vGetSystemDeviceNo(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_DEVICE_NO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetSystemProductionDate(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_PRODUCTION_DATE  ) ); 
        }
      pInst->vGetSystemProductionDate(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_PRODUCTION_DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vPerformSpeakerTest(ulword ulwFrequency)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__PERFORM_SPEAKER_TEST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwFrequency); 
        }
      pInst->vPerformSpeakerTest(ulwFrequency);

    }
}

void HSA_System__vSetEncoderDirection(ulword ulwEncoderDirn)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_ENCODER_DIRECTION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEncoderDirn); 
        }
      pInst->vSetEncoderDirection(ulwEncoderDirn);

    }
}

tbool HSA_System__blGetEncoderDirection( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ENCODER_DIRECTION  ) ); 
        }
      ret=pInst->blGetEncoderDirection();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ENCODER_DIRECTION | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetCurrentSelfTestProgressValue( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SELF_TEST_PROGRESS_VALUE  ) ); 
        }
      ret=pInst->ulwGetCurrentSelfTestProgressValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SELF_TEST_PROGRESS_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSetRVCFlag(tbool blValue)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_RVC_FLAG | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blValue); 
        }
      pInst->vSetRVCFlag(blValue);

    }
}

ulword HSA_System__ulwGetCameraDisplaySettingsPopupState( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CAMERA_DISPLAY_SETTINGS_POPUP_STATE  ) ); 
        }
      ret=pInst->ulwGetCameraDisplaySettingsPopupState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CAMERA_DISPLAY_SETTINGS_POPUP_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSwitchToCameraScreen(tbool blbSwitchStatus, ulword ulwCameraSettingParam)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SWITCH_TO_CAMERA_SCREEN | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blbSwitchStatus); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SWITCH_TO_CAMERA_SCREEN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCameraSettingParam); 
        }
      pInst->vSwitchToCameraScreen(blbSwitchStatus, ulwCameraSettingParam);

    }
}

void HSA_System__vToggleGuideLineState( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_GUIDE_LINE_STATE  ) ); 
        }
      pInst->vToggleGuideLineState();

    }
}

ulword HSA_System__ulwGetRVCGuideLineStatus( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_RVC_GUIDE_LINE_STATUS  ) ); 
        }
      ret=pInst->ulwGetRVCGuideLineStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_RVC_GUIDE_LINE_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vInformCameraHKPress(tbool blCameraHKPressType)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__INFORM_CAMERA_HK_PRESS | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blCameraHKPressType); 
        }
      pInst->vInformCameraHKPress(blCameraHKPressType);

    }
}

ulword HSA_System__ulwGetCameraSystemConfigured( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CAMERA_SYSTEM_CONFIGURED  ) ); 
        }
      ret=pInst->ulwGetCameraSystemConfigured();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CAMERA_SYSTEM_CONFIGURED | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetCameraRequestState( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CAMERA_REQUEST_STATE  ) ); 
        }
      ret=pInst->ulwGetCameraRequestState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CAMERA_REQUEST_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsCameraReqTimeOutRequired( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_CAMERA_REQ_TIME_OUT_REQUIRED  ) ); 
        }
      ret=pInst->blIsCameraReqTimeOutRequired();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_CAMERA_REQ_TIME_OUT_REQUIRED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsCameraRequestActive( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_CAMERA_REQUEST_ACTIVE  ) ); 
        }
      ret=pInst->blIsCameraRequestActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_CAMERA_REQUEST_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsVideoSignalAvailable( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_VIDEO_SIGNAL_AVAILABLE  ) ); 
        }
      ret=pInst->blIsVideoSignalAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_VIDEO_SIGNAL_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsAVMRequestActive( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_AVM_REQUEST_ACTIVE  ) ); 
        }
      ret=pInst->blIsAVMRequestActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_AVM_REQUEST_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsAffordableITSAvailable( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_AFFORDABLE_ITS_AVAILABLE  ) ); 
        }
      ret=pInst->blIsAffordableITSAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_AFFORDABLE_ITS_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSwitchOffCamera( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SWITCH_OFF_CAMERA  ) ); 
        }
      pInst->vSwitchOffCamera();

    }
}

ulword HSA_System__ulwGetCameraConfigStatus(ulword ulwConfigParam)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CAMERA_CONFIG_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwConfigParam); 
        }
      ret=pInst->ulwGetCameraConfigStatus(ulwConfigParam);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CAMERA_CONFIG_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vToggleCameraConfigStatus(ulword ulwConfigParam)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_CAMERA_CONFIG_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwConfigParam); 
        }
      pInst->vToggleCameraConfigStatus(ulwConfigParam);

    }
}

ulword HSA_System__ulwGetVideoDimming(ulword ulwDimmingParam)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_VIDEO_DIMMING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDimmingParam); 
        }
      ret=pInst->ulwGetVideoDimming(ulwDimmingParam);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_VIDEO_DIMMING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vInformAVMOnPurposeSwitch( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__INFORM_AVM_ON_PURPOSE_SWITCH  ) ); 
        }
      pInst->vInformAVMOnPurposeSwitch();

    }
}

void HSA_System__vSetVideoDimming(ulword ulwDimmingParam, tbool blMode)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_VIDEO_DIMMING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDimmingParam); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_VIDEO_DIMMING | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vSetVideoDimming(ulwDimmingParam, blMode);

    }
}

void HSA_System__vIPA_SendButtonPress(ulword ulwButtonIdentifier, ulword ulwButtonState)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__SEND_BUTTON_PRESS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwButtonIdentifier); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__SEND_BUTTON_PRESS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwButtonState); 
        }
      pInst->vIPA_SendButtonPress(ulwButtonIdentifier, ulwButtonState);

    }
}

void HSA_System__vIPA_SetHMIStatus(tbool blHmiStatus)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__SET_HMI_STATUS | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blHmiStatus); 
        }
      pInst->vIPA_SetHMIStatus(blHmiStatus);

    }
}

ulword HSA_System__ulwIPA_GetAvailablityStatus( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_AVAILABLITY_STATUS  ) ); 
        }
      ret=pInst->ulwIPA_GetAvailablityStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_AVAILABLITY_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwIPA_GetConfiguredRegion( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_CONFIGURED_REGION  ) ); 
        }
      ret=pInst->ulwIPA_GetConfiguredRegion();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_CONFIGURED_REGION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwIPA_GetMessageRequested( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_MESSAGE_REQUESTED  ) ); 
        }
      ret=pInst->ulwIPA_GetMessageRequested();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_MESSAGE_REQUESTED | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwIPA_GetPatternRequested( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_PATTERN_REQUESTED  ) ); 
        }
      ret=pInst->ulwIPA_GetPatternRequested();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_PATTERN_REQUESTED | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwIPA_GetPopupRequested( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_POPUP_REQUESTED  ) ); 
        }
      ret=pInst->ulwIPA_GetPopupRequested();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_POPUP_REQUESTED | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwIPA_GetOperationStatus( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_OPERATION_STATUS  ) ); 
        }
      ret=pInst->ulwIPA_GetOperationStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_OPERATION_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwIPA_GetMode( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_MODE  ) ); 
        }
      ret=pInst->ulwIPA_GetMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwIPA_GetCarDirection_Indicator_Status( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_CAR_DIRECTION__INDICATOR__STATUS  ) ); 
        }
      ret=pInst->ulwIPA_GetCarDirection_Indicator_Status();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_CAR_DIRECTION__INDICATOR__STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwIPA_GetButtonVisibilityStatus(ulword ulwButtonIdentifier)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_BUTTON_VISIBILITY_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwButtonIdentifier); 
        }
      ret=pInst->ulwIPA_GetButtonVisibilityStatus(ulwButtonIdentifier);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IPA__GET_BUTTON_VISIBILITY_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blSONAR_GetVisualizationStatus( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_VISUALIZATION_STATUS  ) ); 
        }
      ret=pInst->blSONAR_GetVisualizationStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_VISUALIZATION_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwSONAR_GetCarShapeModel( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_CAR_SHAPE_MODEL  ) ); 
        }
      ret=pInst->ulwSONAR_GetCarShapeModel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_CAR_SHAPE_MODEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwSONAR_GetAvailabilityStatus( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_AVAILABILITY_STATUS  ) ); 
        }
      ret=pInst->ulwSONAR_GetAvailabilityStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_AVAILABILITY_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blSONAR_GetSonarSwitchAvailability( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_SONAR_SWITCH_AVAILABILITY  ) ); 
        }
      ret=pInst->blSONAR_GetSonarSwitchAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_SONAR_SWITCH_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blSONAR_GetErrorStatus( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_ERROR_STATUS  ) ); 
        }
      ret=pInst->blSONAR_GetErrorStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_ERROR_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwSONAR_GetFrontSensorAvailability( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_FRONT_SENSOR_AVAILABILITY  ) ); 
        }
      ret=pInst->ulwSONAR_GetFrontSensorAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_FRONT_SENSOR_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwSONAR_GetRearSensorAvailability( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_REAR_SENSOR_AVAILABILITY  ) ); 
        }
      ret=pInst->ulwSONAR_GetRearSensorAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_REAR_SENSOR_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwSONAR_GetFrontSensorDistanceLevels( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_FRONT_SENSOR_DISTANCE_LEVELS  ) ); 
        }
      ret=pInst->ulwSONAR_GetFrontSensorDistanceLevels();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_FRONT_SENSOR_DISTANCE_LEVELS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwSONAR_GetRearSensorDistanceLevels( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_REAR_SENSOR_DISTANCE_LEVELS  ) ); 
        }
      ret=pInst->ulwSONAR_GetRearSensorDistanceLevels();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_REAR_SENSOR_DISTANCE_LEVELS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blSONAR_GetSystemStatus( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_SYSTEM_STATUS  ) ); 
        }
      ret=pInst->blSONAR_GetSystemStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_SYSTEM_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blSONAR_GetFrontSensorsOnlyStatus( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_FRONT_SENSORS_ONLY_STATUS  ) ); 
        }
      ret=pInst->blSONAR_GetFrontSensorsOnlyStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_FRONT_SENSORS_ONLY_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blSONAR_GetAutomaticDisplayStatus( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_AUTOMATIC_DISPLAY_STATUS  ) ); 
        }
      ret=pInst->blSONAR_GetAutomaticDisplayStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_AUTOMATIC_DISPLAY_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwSONAR_GetSensitivityLevel( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_SENSITIVITY_LEVEL  ) ); 
        }
      ret=pInst->ulwSONAR_GetSensitivityLevel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_SENSITIVITY_LEVEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwSONAR_GetVolumeLevel( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_VOLUME_LEVEL  ) ); 
        }
      ret=pInst->ulwSONAR_GetVolumeLevel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_VOLUME_LEVEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vToggleSonarCancelSwitchStatus( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_SONAR_CANCEL_SWITCH_STATUS  ) ); 
        }
      pInst->vToggleSonarCancelSwitchStatus();

    }
}

void HSA_System__vToggleSonarSystemOption( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_SONAR_SYSTEM_OPTION  ) ); 
        }
      pInst->vToggleSonarSystemOption();

    }
}

void HSA_System__vToggleFrontSensorsOnlyOption( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_FRONT_SENSORS_ONLY_OPTION  ) ); 
        }
      pInst->vToggleFrontSensorsOnlyOption();

    }
}

void HSA_System__vToggleAutomaticDisplayOption( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_AUTOMATIC_DISPLAY_OPTION  ) ); 
        }
      pInst->vToggleAutomaticDisplayOption();

    }
}

void HSA_System__vSetSonarSensitivityLevel( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_SONAR_SENSITIVITY_LEVEL  ) ); 
        }
      pInst->vSetSonarSensitivityLevel();

    }
}

void HSA_System__vSetSonarVolumeLevel( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_SONAR_VOLUME_LEVEL  ) ); 
        }
      pInst->vSetSonarVolumeLevel();

    }
}

ulword HSA_System__ulwSONAR_GetSonarMenu( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_SONAR_MENU  ) ); 
        }
      ret=pInst->ulwSONAR_GetSonarMenu();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SONAR__GET_SONAR_MENU | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetSystemConfig(GUI_String *out_result, ulword ulwSystemConfig)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_CONFIG | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSystemConfig); 
        }
      pInst->vGetSystemConfig(out_result, ulwSystemConfig);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_CONFIG | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetSystemHistory(GUI_String *out_result, ulword ulwSystemHistory)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_HISTORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSystemHistory); 
        }
      pInst->vGetSystemHistory(out_result, ulwSystemHistory);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_HISTORY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetSystemSelfTest(GUI_String *out_result, ulword ulwSystemSelfTest)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_SELF_TEST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSystemSelfTest); 
        }
      pInst->vGetSystemSelfTest(out_result, ulwSystemSelfTest);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_SELF_TEST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vStartSelfTest( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__START_SELF_TEST  ) ); 
        }
      pInst->vStartSelfTest();

    }
}

void HSA_System__vGetUSBSlotMedium(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_USB_SLOT_MEDIUM  ) ); 
        }
      pInst->vGetUSBSlotMedium(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_USB_SLOT_MEDIUM | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetViaGPSTimeStatus( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_VIA_GPS_TIME_STATUS  ) ); 
        }
      ret=pInst->ulwGetViaGPSTimeStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_VIA_GPS_TIME_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vToggleViaGPSTimeStatus( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_VIA_GPS_TIME_STATUS  ) ); 
        }
      pInst->vToggleViaGPSTimeStatus();

    }
}

tbool HSA_System__blGetSummerTimeStatus( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SUMMER_TIME_STATUS  ) ); 
        }
      ret=pInst->blGetSummerTimeStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SUMMER_TIME_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vToggleSummerTimeStatus( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_SUMMER_TIME_STATUS  ) ); 
        }
      pInst->vToggleSummerTimeStatus();

    }
}

void HSA_System__vGetCurrentTZ(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TZ  ) ); 
        }
      pInst->vGetCurrentTZ(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TZ | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetCurrentTZIndex( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TZ_INDEX  ) ); 
        }
      ret=pInst->ulwGetCurrentTZIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TZ_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetTZListCount( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TZ_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetTZListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TZ_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetTZListElement(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TZ_LIST_ELEMENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetTZListElement(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TZ_LIST_ELEMENT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vSetTZ(ulword ulwListEntryNr)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_TZ | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetTZ(ulwListEntryNr);

    }
}

void HSA_System__vIncreaseTimeHour( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__INCREASE_TIME_HOUR  ) ); 
        }
      pInst->vIncreaseTimeHour();

    }
}

void HSA_System__vDateHandling(ulword ulwType, tbool blOperation)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__DATE_HANDLING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__DATE_HANDLING | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blOperation); 
        }
      pInst->vDateHandling(ulwType, blOperation);

    }
}

void HSA_System__vToggleDateFormat( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_DATE_FORMAT  ) ); 
        }
      pInst->vToggleDateFormat();

    }
}

ulword HSA_System__ulwGetDateFormat( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DATE_FORMAT  ) ); 
        }
      ret=pInst->ulwGetDateFormat();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DATE_FORMAT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vDecreaseTimeHour( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__DECREASE_TIME_HOUR  ) ); 
        }
      pInst->vDecreaseTimeHour();

    }
}

ulword HSA_System__ulwGetTimeHour( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_HOUR  ) ); 
        }
      ret=pInst->ulwGetTimeHour();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_HOUR | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vIncreaseTimeMinute( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__INCREASE_TIME_MINUTE  ) ); 
        }
      pInst->vIncreaseTimeMinute();

    }
}

void HSA_System__vIncreaseDateDay( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__INCREASE_DATE_DAY  ) ); 
        }
      pInst->vIncreaseDateDay();

    }
}

void HSA_System__vIncreaseDateMonth( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__INCREASE_DATE_MONTH  ) ); 
        }
      pInst->vIncreaseDateMonth();

    }
}

void HSA_System__vIncreaseDateYear( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__INCREASE_DATE_YEAR  ) ); 
        }
      pInst->vIncreaseDateYear();

    }
}

void HSA_System__vDecreaseTimeMinute( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__DECREASE_TIME_MINUTE  ) ); 
        }
      pInst->vDecreaseTimeMinute();

    }
}

void HSA_System__vDecreaseDateDay( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__DECREASE_DATE_DAY  ) ); 
        }
      pInst->vDecreaseDateDay();

    }
}

void HSA_System__vDecreaseDateMonth( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__DECREASE_DATE_MONTH  ) ); 
        }
      pInst->vDecreaseDateMonth();

    }
}

void HSA_System__vDecreaseDateYear( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__DECREASE_DATE_YEAR  ) ); 
        }
      pInst->vDecreaseDateYear();

    }
}

ulword HSA_System__ulwGetTimeMinute( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_MINUTE  ) ); 
        }
      ret=pInst->ulwGetTimeMinute();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_MINUTE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vActivateFirstMediaData(ulword ulwSource)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_FIRST_MEDIA_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSource); 
        }
      pInst->vActivateFirstMediaData(ulwSource);

    }
}

tbool HSA_System__blAreRearSpeakersAssembled( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__ARE_REAR_SPEAKERS_ASSEMBLED  ) ); 
        }
      ret=pInst->blAreRearSpeakersAssembled();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__ARE_REAR_SPEAKERS_ASSEMBLED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vCancelSoftwareDownload( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CANCEL_SOFTWARE_DOWNLOAD  ) ); 
        }
      pInst->vCancelSoftwareDownload();

    }
}

tbool HSA_System__blCheckAssemblyUnlock( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_ASSEMBLY_UNLOCK  ) ); 
        }
      ret=pInst->blCheckAssemblyUnlock();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_ASSEMBLY_UNLOCK | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwCheckCode( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_CODE  ) ); 
        }
      ret=pInst->ulwCheckCode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_CODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwCheckSDCode( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_SD_CODE  ) ); 
        }
      ret=pInst->ulwCheckSDCode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_SD_CODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwCheckComfortCoding( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_COMFORT_CODING  ) ); 
        }
      ret=pInst->ulwCheckComfortCoding();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_COMFORT_CODING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwCheckSDPaired( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_SD_PAIRED  ) ); 
        }
      ret=pInst->ulwCheckSDPaired();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_SD_PAIRED | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwCheckSDPINRequirement( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_SDPIN_REQUIREMENT  ) ); 
        }
      ret=pInst->ulwCheckSDPINRequirement();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_SDPIN_REQUIREMENT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vCheckSpellerDisclaimer( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CHECK_SPELLER_DISCLAIMER  ) ); 
        }
      pInst->vCheckSpellerDisclaimer();

    }
}

void HSA_System__vCodeInput(const GUI_String * InputString)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CODE_INPUT | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vCodeInput( InputString);

    }
}

void HSA_System__vSDCodeInput(const GUI_String * InputString)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SD_CODE_INPUT | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSDCodeInput( InputString);

    }
}

tbool HSA_System__blSetupGetPresetMenu( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_PRESET_MENU  ) ); 
        }
      ret=pInst->blSetupGetPresetMenu();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SETUP_GET_PRESET_MENU | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSetupSetPresetMenu(tbool blMode)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SETUP_SET_PRESET_MENU | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vSetupSetPresetMenu(blMode);

    }
}

ulword HSA_System__ulwGetSizeofDisplay( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SIZEOF_DISPLAY  ) ); 
        }
      ret=pInst->ulwGetSizeofDisplay();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SIZEOF_DISPLAY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vCreateBeep( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CREATE_BEEP  ) ); 
        }
      pInst->vCreateBeep();

    }
}

void HSA_System__vCreateBeepX(ulword ulwBeepType)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__CREATE_BEEP_X | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBeepType); 
        }
      pInst->vCreateBeepX(ulwBeepType);

    }
}

void HSA_System__vEjectCD( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__EJECT_CD  ) ); 
        }
      pInst->vEjectCD();

    }
}

ulword HSA_System__ulwGetAcousticTouchscreenFeedback( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ACOUSTIC_TOUCHSCREEN_FEEDBACK  ) ); 
        }
      ret=pInst->ulwGetAcousticTouchscreenFeedback();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_ACOUSTIC_TOUCHSCREEN_FEEDBACK | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetBluetoothSWProgress( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_BLUETOOTH_SW_PROGRESS  ) ); 
        }
      ret=pInst->ulwGetBluetoothSWProgress();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_BLUETOOTH_SW_PROGRESS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetClimateAirflowBody(ulword ulwSeat)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_AIRFLOW_BODY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSeat); 
        }
      ret=pInst->ulwGetClimateAirflowBody(ulwSeat);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_AIRFLOW_BODY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetClimateAirflowFootwell(ulword ulwSeat)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_AIRFLOW_FOOTWELL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSeat); 
        }
      ret=pInst->ulwGetClimateAirflowFootwell(ulwSeat);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_AIRFLOW_FOOTWELL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetClimateAirflowRange( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_AIRFLOW_RANGE  ) ); 
        }
      ret=pInst->ulwGetClimateAirflowRange();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_AIRFLOW_RANGE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetClimateAirflowUp(ulword ulwSeat)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_AIRFLOW_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSeat); 
        }
      ret=pInst->ulwGetClimateAirflowUp(ulwSeat);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_AIRFLOW_UP | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetClimateContext( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_CONTEXT  ) ); 
        }
      ret=pInst->ulwGetClimateContext();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_CONTEXT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetClimateCurrentStatusIcon( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_CURRENT_STATUS_ICON  ) ); 
        }
      ret=pInst->ulwGetClimateCurrentStatusIcon();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_CURRENT_STATUS_ICON | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetClimatePopupDuration( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_POPUP_DURATION  ) ); 
        }
      ret=pInst->ulwGetClimatePopupDuration();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_POPUP_DURATION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetClimateRearState( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_REAR_STATE  ) ); 
        }
      ret=pInst->ulwGetClimateRearState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_REAR_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetClimateSeatheat(ulword ulwSeat)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_SEATHEAT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSeat); 
        }
      ret=pInst->ulwGetClimateSeatheat(ulwSeat);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_SEATHEAT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetClimateStatusIcons(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_STATUS_ICONS  ) ); 
        }
      pInst->vGetClimateStatusIcons(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CLIMATE_STATUS_ICONS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetCodeInput(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CODE_INPUT  ) ); 
        }
      pInst->vGetCodeInput(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CODE_INPUT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetSDCodeInput(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CODE_INPUT  ) ); 
        }
      pInst->vGetSDCodeInput(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CODE_INPUT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetCurrentDistanceUnit( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DISTANCE_UNIT  ) ); 
        }
      ret=pInst->ulwGetCurrentDistanceUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DISTANCE_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetCurrentMenuLanguage( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MENU_LANGUAGE  ) ); 
        }
      ret=pInst->ulwGetCurrentMenuLanguage();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MENU_LANGUAGE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetCurrentTemperatureUnit(GUI_String *out_result, ulword ulwSeat)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TEMPERATURE_UNIT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSeat); 
        }
      pInst->vGetCurrentTemperatureUnit(out_result, ulwSeat);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TEMPERATURE_UNIT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetDABSWProgress( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DABSW_PROGRESS  ) ); 
        }
      ret=pInst->ulwGetDABSWProgress();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DABSW_PROGRESS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetDate(ulword ulwYearOrMonthOrDay)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwYearOrMonthOrDay); 
        }
      ret=pInst->ulwGetDate(ulwYearOrMonthOrDay);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetDateMode( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DATE_MODE  ) ); 
        }
      ret=pInst->ulwGetDateMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DATE_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetDesiredTemperatureAsString(GUI_String *out_result, ulword ulwSeat)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DESIRED_TEMPERATURE_AS_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSeat); 
        }
      pInst->vGetDesiredTemperatureAsString(out_result, ulwSeat);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DESIRED_TEMPERATURE_AS_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

slword HSA_System__slwGetDisplayBrightness( )
{
    slword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DISPLAY_BRIGHTNESS  ) ); 
        }
      ret=pInst->slwGetDisplayBrightness();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DISPLAY_BRIGHTNESS | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetFGSSWProgress( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_FGSSW_PROGRESS  ) ); 
        }
      ret=pInst->ulwGetFGSSWProgress();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_FGSSW_PROGRESS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetLanguageCode(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_LANGUAGE_CODE  ) ); 
        }
      pInst->vGetLanguageCode(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_LANGUAGE_CODE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetLastClamp15OffTime( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_CLAMP15_OFF_TIME  ) ); 
        }
      ret=pInst->ulwGetLastClamp15OffTime();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_CLAMP15_OFF_TIME | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetLastMainContext( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_MAIN_CONTEXT  ) ); 
        }
      ret=pInst->ulwGetLastMainContext();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_MAIN_CONTEXT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetNavSWProgress( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_NAV_SW_PROGRESS  ) ); 
        }
      ret=pInst->ulwGetNavSWProgress();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_NAV_SW_PROGRESS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetOPSCarType(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_OPS_CAR_TYPE  ) ); 
        }
      pInst->vGetOPSCarType(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_OPS_CAR_TYPE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetOPSFrontDistance(ulword ulwSector)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_OPS_FRONT_DISTANCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSector); 
        }
      ret=pInst->ulwGetOPSFrontDistance(ulwSector);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_OPS_FRONT_DISTANCE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetOPSNumberOfSectors( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_OPS_NUMBER_OF_SECTORS  ) ); 
        }
      ret=pInst->ulwGetOPSNumberOfSectors();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_OPS_NUMBER_OF_SECTORS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetOPSRearDistance(ulword ulwSector)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_OPS_REAR_DISTANCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSector); 
        }
      ret=pInst->ulwGetOPSRearDistance(ulwSector);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_OPS_REAR_DISTANCE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blGetOPSRearSensorsOnly( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_OPS_REAR_SENSORS_ONLY  ) ); 
        }
      ret=pInst->blGetOPSRearSensorsOnly();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_OPS_REAR_SENSORS_ONLY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetRemainingAttempts(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_REMAINING_ATTEMPTS  ) ); 
        }
      pInst->vGetRemainingAttempts(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_REMAINING_ATTEMPTS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetSDRemainingAttempts(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_REMAINING_ATTEMPTS  ) ); 
        }
      pInst->vGetSDRemainingAttempts(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_REMAINING_ATTEMPTS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetRemainingUnlocks(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_REMAINING_UNLOCKS  ) ); 
        }
      pInst->vGetRemainingUnlocks(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_REMAINING_UNLOCKS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetRVCDark( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_RVC_DARK  ) ); 
        }
      ret=pInst->ulwGetRVCDark();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_RVC_DARK | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetRVCMode( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_RVC_MODE  ) ); 
        }
      ret=pInst->ulwGetRVCMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_RVC_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetRVCType( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_RVC_TYPE  ) ); 
        }
      ret=pInst->ulwGetRVCType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_RVC_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetSDCardMemoryFree(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CARD_MEMORY_FREE  ) ); 
        }
      pInst->vGetSDCardMemoryFree(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CARD_MEMORY_FREE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetSDCardMemoryTotal(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CARD_MEMORY_TOTAL  ) ); 
        }
      pInst->vGetSDCardMemoryTotal(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CARD_MEMORY_TOTAL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetSDCardMemoryUsedByNAV(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CARD_MEMORY_USED_BY_NAV  ) ); 
        }
      pInst->vGetSDCardMemoryUsedByNAV(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CARD_MEMORY_USED_BY_NAV | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetSDChkdskProgress( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CHKDSK_PROGRESS  ) ); 
        }
      ret=pInst->ulwGetSDChkdskProgress();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CHKDSK_PROGRESS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetSDFormatProgress( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_FORMAT_PROGRESS  ) ); 
        }
      ret=pInst->ulwGetSDFormatProgress();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_FORMAT_PROGRESS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetSkinDayNight( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SKIN_DAY_NIGHT  ) ); 
        }
      ret=pInst->ulwGetSkinDayNight();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SKIN_DAY_NIGHT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetSoftwareDownloadErrorCode(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SOFTWARE_DOWNLOAD_ERROR_CODE  ) ); 
        }
      pInst->vGetSoftwareDownloadErrorCode(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SOFTWARE_DOWNLOAD_ERROR_CODE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetSoftwareVersionFromCD(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SOFTWARE_VERSION_FROM_CD  ) ); 
        }
      pInst->vGetSoftwareVersionFromCD(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SOFTWARE_VERSION_FROM_CD | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System__vGetSoftwareVersionInstalled(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SOFTWARE_VERSION_INSTALLED  ) ); 
        }
      pInst->vGetSoftwareVersionInstalled(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SOFTWARE_VERSION_INSTALLED | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetSpellerLayout( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_LAYOUT  ) ); 
        }
      ret=pInst->ulwGetSpellerLayout();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_LAYOUT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetSWUpdateProgress( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SW_UPDATE_PROGRESS  ) ); 
        }
      ret=pInst->ulwGetSWUpdateProgress();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SW_UPDATE_PROGRESS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetSystemCodeCountdownTime( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_CODE_COUNTDOWN_TIME  ) ); 
        }
      ret=pInst->ulwGetSystemCodeCountdownTime();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_CODE_COUNTDOWN_TIME | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetSystemCodeCountdownTimeAsString(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_CODE_COUNTDOWN_TIME_AS_STRING  ) ); 
        }
      pInst->vGetSystemCodeCountdownTimeAsString(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_CODE_COUNTDOWN_TIME_AS_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetSDCodeCountdownTime( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CODE_COUNTDOWN_TIME  ) ); 
        }
      ret=pInst->ulwGetSDCodeCountdownTime();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CODE_COUNTDOWN_TIME | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetSDCodeCountdownTimeAsString(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CODE_COUNTDOWN_TIME_AS_STRING  ) ); 
        }
      pInst->vGetSDCodeCountdownTimeAsString(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SD_CODE_COUNTDOWN_TIME_AS_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetSystemOnOffState( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_ON_OFF_STATE  ) ); 
        }
      ret=pInst->ulwGetSystemOnOffState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_ON_OFF_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetSystemSWProgress( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_SW_PROGRESS  ) ); 
        }
      ret=pInst->ulwGetSystemSWProgress();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_SW_PROGRESS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetSystemVendor( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_VENDOR  ) ); 
        }
      ret=pInst->ulwGetSystemVendor();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_VENDOR | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetWeekdayOfToday( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_WEEKDAY_OF_TODAY  ) ); 
        }
      ret=pInst->ulwGetWeekdayOfToday();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_WEEKDAY_OF_TODAY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetWeekdayOfTomorrow( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_WEEKDAY_OF_TOMORROW  ) ); 
        }
      ret=pInst->ulwGetWeekdayOfTomorrow();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_WEEKDAY_OF_TOMORROW | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetTime(ulword ulwHourOrMinute)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TIME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwHourOrMinute); 
        }
      ret=pInst->ulwGetTime(ulwHourOrMinute);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TIME | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetTimeFormat( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_FORMAT  ) ); 
        }
      ret=pInst->ulwGetTimeFormat();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_FORMAT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetTimeFormatted(GUI_String *out_result)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_FORMATTED  ) ); 
        }
      pInst->vGetTimeFormatted(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_FORMATTED | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_System__blIsAPSPresent( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_APS_PRESENT  ) ); 
        }
      ret=pInst->blIsAPSPresent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_APS_PRESENT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsClimateSetupAvailable( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_CLIMATE_SETUP_AVAILABLE  ) ); 
        }
      ret=pInst->blIsClimateSetupAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_CLIMATE_SETUP_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsClimateStatusLineFunctionOn( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_CLIMATE_STATUS_LINE_FUNCTION_ON  ) ); 
        }
      ret=pInst->blIsClimateStatusLineFunctionOn();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_CLIMATE_STATUS_LINE_FUNCTION_ON | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsClimateTempChanged(ulword ulwSeat)
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_CLIMATE_TEMP_CHANGED | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSeat); 
        }
      ret=pInst->blIsClimateTempChanged(ulwSeat);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_CLIMATE_TEMP_CHANGED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsClimateTempInRange(ulword ulwSeat)
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_CLIMATE_TEMP_IN_RANGE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSeat); 
        }
      ret=pInst->blIsClimateTempInRange(ulwSeat);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_CLIMATE_TEMP_IN_RANGE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsDateFormatMasterPresent( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_DATE_FORMAT_MASTER_PRESENT  ) ); 
        }
      ret=pInst->blIsDateFormatMasterPresent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_DATE_FORMAT_MASTER_PRESENT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsDateMasterPresent( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_DATE_MASTER_PRESENT  ) ); 
        }
      ret=pInst->blIsDateMasterPresent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_DATE_MASTER_PRESENT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

slword HSA_System__slwIsDateValid( )
{
    slword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_DATE_VALID  ) ); 
        }
      ret=pInst->slwIsDateValid();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_DATE_VALID | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsOPSPresent( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_OPS_PRESENT  ) ); 
        }
      ret=pInst->blIsOPSPresent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_OPS_PRESENT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsOPSTrailerRecognized( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_OPS_TRAILER_RECOGNIZED  ) ); 
        }
      ret=pInst->blIsOPSTrailerRecognized();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_OPS_TRAILER_RECOGNIZED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsRearGearActive( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_REAR_GEAR_ACTIVE  ) ); 
        }
      ret=pInst->blIsRearGearActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_REAR_GEAR_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsRVCRequestActive( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_RVC_REQUEST_ACTIVE  ) ); 
        }
      ret=pInst->blIsRVCRequestActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_RVC_REQUEST_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwIsSDCardAvailable( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_SD_CARD_AVAILABLE  ) ); 
        }
      ret=pInst->ulwIsSDCardAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_SD_CARD_AVAILABLE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsSDCardInUse( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_SD_CARD_IN_USE  ) ); 
        }
      ret=pInst->blIsSDCardInUse();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_SD_CARD_IN_USE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsSkodaExternalAmpAvailable( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_SKODA_EXTERNAL_AMP_AVAILABLE  ) ); 
        }
      ret=pInst->blIsSkodaExternalAmpAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_SKODA_EXTERNAL_AMP_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsSWDownloadPossible( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_SW_DOWNLOAD_POSSIBLE  ) ); 
        }
      ret=pInst->blIsSWDownloadPossible();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_SW_DOWNLOAD_POSSIBLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsTimeFormatMasterPresent( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_TIME_FORMAT_MASTER_PRESENT  ) ); 
        }
      ret=pInst->blIsTimeFormatMasterPresent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_TIME_FORMAT_MASTER_PRESENT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blIsTimeMasterPresent( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_TIME_MASTER_PRESENT  ) ); 
        }
      ret=pInst->blIsTimeMasterPresent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_TIME_MASTER_PRESENT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

slword HSA_System__slwIsTimeValid( )
{
    slword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_TIME_VALID  ) ); 
        }
      ret=pInst->slwIsTimeValid();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_TIME_VALID | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vLockDDSEventFocus( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__LOCK_DDS_EVENT_FOCUS  ) ); 
        }
      pInst->vLockDDSEventFocus();

    }
}

void HSA_System__vLockDDSVolumeFocus( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__LOCK_DDS_VOLUME_FOCUS  ) ); 
        }
      pInst->vLockDDSVolumeFocus();

    }
}

void HSA_System__vRestartSystem( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__RESTART_SYSTEM  ) ); 
        }
      pInst->vRestartSystem();

    }
}

void HSA_System__vRestoreDDSSpeedup( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__RESTORE_DDS_SPEEDUP  ) ); 
        }
      pInst->vRestoreDDSSpeedup();

    }
}

void HSA_System__vRestoreDDSVolumeSpeedup( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__RESTORE_DDS_VOLUME_SPEEDUP  ) ); 
        }
      pInst->vRestoreDDSVolumeSpeedup();

    }
}

void HSA_System__vSaveDate( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SAVE_DATE  ) ); 
        }
      pInst->vSaveDate();

    }
}

void HSA_System__vSaveTime( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SAVE_TIME  ) ); 
        }
      pInst->vSaveTime();

    }
}

void HSA_System__vDURSnooze( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__DUR_SNOOZE  ) ); 
        }
      pInst->vDURSnooze();

    }
}

void HSA_System__vDURDismiss( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__DUR_DISMISS  ) ); 
        }
      pInst->vDURDismiss();

    }
}

void HSA_System__vSetAcousticTouchscreenFeedback(ulword ulwListEntryNr)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_ACOUSTIC_TOUCHSCREEN_FEEDBACK | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetAcousticTouchscreenFeedback(ulwListEntryNr);

    }
}

void HSA_System__vSetClimatePopupDuration(ulword ulwMode)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_CLIMATE_POPUP_DURATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vSetClimatePopupDuration(ulwMode);

    }
}

void HSA_System__vSetDateDay(ulword ulwDay)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DATE_DAY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDay); 
        }
      pInst->vSetDateDay(ulwDay);

    }
}

void HSA_System__vSetDateMode(ulword ulwMode)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DATE_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vSetDateMode(ulwMode);

    }
}

void HSA_System__vSetDateMonth(ulword ulwMonth)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DATE_MONTH | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMonth); 
        }
      pInst->vSetDateMonth(ulwMonth);

    }
}

void HSA_System__vSetDateYear(ulword ulwYear)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DATE_YEAR | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwYear); 
        }
      pInst->vSetDateYear(ulwYear);

    }
}

void HSA_System__vSetDDSEventFocus(ulword ulwWindow)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DDS_EVENT_FOCUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwWindow); 
        }
      pInst->vSetDDSEventFocus(ulwWindow);

    }
}

void HSA_System__vSetDDSSpeedup(ulword ulwtime, ulword ulwthreshold, ulword ulwmultiplier)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DDS_SPEEDUP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwtime); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DDS_SPEEDUP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwthreshold); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DDS_SPEEDUP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwmultiplier); 
        }
      pInst->vSetDDSSpeedup(ulwtime, ulwthreshold, ulwmultiplier);

    }
}

void HSA_System__vSetDDSVolumeFocus(ulword ulwWindow)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DDS_VOLUME_FOCUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwWindow); 
        }
      pInst->vSetDDSVolumeFocus(ulwWindow);

    }
}

void HSA_System__vSetDDSVolumeSpeedup(ulword ulwtime, ulword ulwthreshold, ulword ulwmultiplier)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DDS_VOLUME_SPEEDUP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwtime); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DDS_VOLUME_SPEEDUP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwthreshold); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DDS_VOLUME_SPEEDUP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwmultiplier); 
        }
      pInst->vSetDDSVolumeSpeedup(ulwtime, ulwthreshold, ulwmultiplier);

    }
}

void HSA_System__vSetDisplayBrightness(tbool blMode)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DISPLAY_BRIGHTNESS | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vSetDisplayBrightness(blMode);

    }
}

void HSA_System__vSetDistanceUnit(ulword ulwMode)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_DISTANCE_UNIT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vSetDistanceUnit(ulwMode);

    }
}

void HSA_System__vSetFactorySettings( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_FACTORY_SETTINGS  ) ); 
        }
      pInst->vSetFactorySettings();

    }
}

void HSA_System__vSetLastMainContext(ulword ulwListEntryNr)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_LAST_MAIN_CONTEXT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetLastMainContext(ulwListEntryNr);

    }
}

void HSA_System__vSetMenuLanguage(ulword ulwListEntryNr)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_MENU_LANGUAGE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetMenuLanguage(ulwListEntryNr);

    }
}

void HSA_System__vSetRVCMode(ulword ulwRVCMode)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_RVC_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRVCMode); 
        }
      pInst->vSetRVCMode(ulwRVCMode);

    }
}

void HSA_System__vSetSkinDayNight(ulword ulwMode)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_SKIN_DAY_NIGHT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vSetSkinDayNight(ulwMode);

    }
}

tbool HSA_System__blGetDimstate( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DIMSTATE  ) ); 
        }
      ret=pInst->blGetDimstate();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DIMSTATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSetSpellerLayout(ulword ulwLayout)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_SPELLER_LAYOUT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLayout); 
        }
      pInst->vSetSpellerLayout(ulwLayout);

    }
}

void HSA_System__vSetTimeFormat(ulword ulwFormat)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_TIME_FORMAT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwFormat); 
        }
      pInst->vSetTimeFormat(ulwFormat);

    }
}

void HSA_System__vSetTimeHour(ulword ulwHour)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_TIME_HOUR | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwHour); 
        }
      pInst->vSetTimeHour(ulwHour);

    }
}

void HSA_System__vSetTimeMinute(ulword ulwMinute)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_TIME_MINUTE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMinute); 
        }
      pInst->vSetTimeMinute(ulwMinute);

    }
}

void HSA_System__vSetTimeMode(ulword ulwMode)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_TIME_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vSetTimeMode(ulwMode);

    }
}

ulword HSA_System__ulwGetTimeMode( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_MODE  ) ); 
        }
      ret=pInst->ulwGetTimeMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSetUserConfirmedSpellerDisclaimer( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_USER_CONFIRMED_SPELLER_DISCLAIMER  ) ); 
        }
      pInst->vSetUserConfirmedSpellerDisclaimer();

    }
}

tbool HSA_System__blSpellerInvertGetLetterFunction( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION  ) ); 
        }
      ret=pInst->blSpellerInvertGetLetterFunction();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSpellerSetMaxCharCount(ulword ulwCount)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_MAX_CHAR_COUNT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCount); 
        }
      pInst->vSpellerSetMaxCharCount(ulwCount);

    }
}

void HSA_System__vStartChkdsk( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__START_CHKDSK  ) ); 
        }
      pInst->vStartChkdsk();

    }
}

void HSA_System__vStartFormatting( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__START_FORMATTING  ) ); 
        }
      pInst->vStartFormatting();

    }
}

void HSA_System__vStartSoftwareDownload( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__START_SOFTWARE_DOWNLOAD  ) ); 
        }
      pInst->vStartSoftwareDownload();

    }
}

void HSA_System__vInsertMediaForDownload( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__INSERT_MEDIA_FOR_DOWNLOAD  ) ); 
        }
      pInst->vInsertMediaForDownload();

    }
}

void HSA_System__vUnLockDDSEventFocus( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__UN_LOCK_DDS_EVENT_FOCUS  ) ); 
        }
      pInst->vUnLockDDSEventFocus();

    }
}

void HSA_System__vUnLockDDSVolumeFocus( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__UN_LOCK_DDS_VOLUME_FOCUS  ) ); 
        }
      pInst->vUnLockDDSVolumeFocus();

    }
}

void HSA_System__vUnmountSD( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__UNMOUNT_SD  ) ); 
        }
      pInst->vUnmountSD();

    }
}

tbool HSA_System__blIsForcedDownloadPossible( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_FORCED_DOWNLOAD_POSSIBLE  ) ); 
        }
      ret=pInst->blIsForcedDownloadPossible();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_FORCED_DOWNLOAD_POSSIBLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetEABlockingMode(ulword ulwApplication)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_EA_BLOCKING_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwApplication); 
        }
      ret=pInst->ulwGetEABlockingMode(ulwApplication);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_EA_BLOCKING_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetNissanRegionType( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_NISSAN_REGION_TYPE  ) ); 
        }
      ret=pInst->ulwGetNissanRegionType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_NISSAN_REGION_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetUnitOfTemperature( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_UNIT_OF_TEMPERATURE  ) ); 
        }
      ret=pInst->ulwGetUnitOfTemperature();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_UNIT_OF_TEMPERATURE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSetUnitOfTemperature(ulword ulwTemperatureUnit)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_UNIT_OF_TEMPERATURE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTemperatureUnit); 
        }
      pInst->vSetUnitOfTemperature(ulwTemperatureUnit);

    }
}

void HSA_System__vGetDocumentText(GUI_String *out_result, const GUI_String * DocPath)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DOCUMENT_TEXT | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)DocPath->ulwLen_+1, DocPath->pubBuffer_);
         }
      pInst->vGetDocumentText(out_result,  DocPath);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DOCUMENT_TEXT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetDocumentSize(const GUI_String * DocPath)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DOCUMENT_SIZE | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)DocPath->ulwLen_+1, DocPath->pubBuffer_);
         }
      ret=pInst->ulwGetDocumentSize( DocPath);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_DOCUMENT_SIZE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetHEVDriveType( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_DRIVE_TYPE  ) ); 
        }
      ret=pInst->ulwGetHEVDriveType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_DRIVE_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetHEVBodyShape( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_BODY_SHAPE  ) ); 
        }
      ret=pInst->ulwGetHEVBodyShape();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_BODY_SHAPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetHEVEnergyFlow_StartIndex( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_ENERGY_FLOW__START_INDEX  ) ); 
        }
      ret=pInst->ulwGetHEVEnergyFlow_StartIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_ENERGY_FLOW__START_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetHEVEnergyFlow_EndIndex( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_ENERGY_FLOW__END_INDEX  ) ); 
        }
      ret=pInst->ulwGetHEVEnergyFlow_EndIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_ENERGY_FLOW__END_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blGetHEVEngineOperationState( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_ENGINE_OPERATION_STATE  ) ); 
        }
      ret=pInst->blGetHEVEngineOperationState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_ENGINE_OPERATION_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System__blGetHEVBatteryOperationState( )
{
    tbool ret = false;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_BATTERY_OPERATION_STATE  ) ); 
        }
      ret=pInst->blGetHEVBatteryOperationState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_BATTERY_OPERATION_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetHEVBatteryChargeDischargeState( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_BATTERY_CHARGE_DISCHARGE_STATE  ) ); 
        }
      ret=pInst->ulwGetHEVBatteryChargeDischargeState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_BATTERY_CHARGE_DISCHARGE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetHEVBatteryChargeLevel( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_BATTERY_CHARGE_LEVEL  ) ); 
        }
      ret=pInst->ulwGetHEVBatteryChargeLevel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_BATTERY_CHARGE_LEVEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetHEVTireRotationDirection( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_TIRE_ROTATION_DIRECTION  ) ); 
        }
      ret=pInst->ulwGetHEVTireRotationDirection();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_TIRE_ROTATION_DIRECTION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetHEVAverageFuelEconomyHistory(ulword ulwListEntryNumber)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_AVERAGE_FUEL_ECONOMY_HISTORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      ret=pInst->ulwGetHEVAverageFuelEconomyHistory(ulwListEntryNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_AVERAGE_FUEL_ECONOMY_HISTORY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetHEVRegenerationAmountIconHistory(ulword ulwListEntryNumber)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_REGENERATION_AMOUNT_ICON_HISTORY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      ret=pInst->ulwGetHEVRegenerationAmountIconHistory(ulwListEntryNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_REGENERATION_AMOUNT_ICON_HISTORY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetHEVDrivingHistoryTimeStamp(ulword ulwListEntryNumber)
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_DRIVING_HISTORY_TIME_STAMP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      ret=pInst->ulwGetHEVDrivingHistoryTimeStamp(ulwListEntryNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_DRIVING_HISTORY_TIME_STAMP | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vGetHEVDDrivingHistoryDateString(GUI_String *out_result, ulword ulwListEntryNumber)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEVD_DRIVING_HISTORY_DATE_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      pInst->vGetHEVDDrivingHistoryDateString(out_result, ulwListEntryNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEVD_DRIVING_HISTORY_DATE_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System__ulwGetHEVFuelEconomyUnit( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_FUEL_ECONOMY_UNIT  ) ); 
        }
      ret=pInst->ulwGetHEVFuelEconomyUnit();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_FUEL_ECONOMY_UNIT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vSetHEVShiftDirection(ulword ulwShift_direction)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__SET_HEV_SHIFT_DIRECTION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwShift_direction); 
        }
      pInst->vSetHEVShiftDirection(ulwShift_direction);

    }
}

ulword HSA_System__ulwGetHEVScrollKeyGrayingState( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_SCROLL_KEY_GRAYING_STATE  ) ); 
        }
      ret=pInst->ulwGetHEVScrollKeyGrayingState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_SCROLL_KEY_GRAYING_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System__ulwGetHEVHistoryMaxValue( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_HISTORY_MAX_VALUE  ) ); 
        }
      ret=pInst->ulwGetHEVHistoryMaxValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_HISTORY_MAX_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vLoadHEVHistory( )
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__LOAD_HEV_HISTORY  ) ); 
        }
      pInst->vLoadHEVHistory();

    }
}

ulword HSA_System__ulwGetHEVHistoryLoadingState( )
{
    ulword ret = 0;
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_HISTORY_LOADING_STATE  ) ); 
        }
      ret=pInst->ulwGetHEVHistoryLoadingState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__GET_HEV_HISTORY_LOADING_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System__vIsTimeFormatScreenActive(tbool blScreenstate)
{
    
    clHSA_System_Base *pInst=clHSA_System_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM), (tU16)(HSA_API_ENTRYPOINT__IS_TIME_FORMAT_SCREEN_ACTIVE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blScreenstate); 
        }
      pInst->vIsTimeFormatScreenActive(blScreenstate);

    }
}

#ifdef __cplusplus
}
#endif

