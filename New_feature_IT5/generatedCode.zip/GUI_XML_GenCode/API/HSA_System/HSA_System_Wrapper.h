/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_System_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_System_Wrapper_H
#define _HSA_System_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: StartTouchScreenCalibration
 * B1
 * NISSAN
 */
void HSA_System__vStartTouchScreenCalibration( void);

/**
 * Function: AbortTouchScreenCalibration
 * B
 * NISSAN
 */
void HSA_System__vAbortTouchScreenCalibration( void);

/**
 * Function: GetCalibrationPageNumber
 * NISSAN LCN2 Sample
 * NISSAN
 */
ulword HSA_System__ulwGetCalibrationPageNumber( void);

/**
 * Function: NewCalibrationPageDrawn
 * NISSAN LCN2 Sample
 * NISSAN
 */
void HSA_System__vNewCalibrationPageDrawn( void);

/**
 * Function: AutoModeEnableDisable
 * C
 * NISSAN
 */
tbool HSA_System__blAutoModeEnableDisable( void);

/**
 * Function: GetCalibrationStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetCalibrationStatus( void);

/**
 * Function: GetKDSData
 * NISSAN
 * NISSAN
 */
void HSA_System__vGetKDSData(GUI_String *out_result, ulword ulwKDSEntry);

/**
 * Function: CheckClockScreenMode
 * NISSAN LCN2 Sample
 * NISSAN
 */
void HSA_System__vCheckClockScreenMode( void);

/**
 * Function: SetClockScreenMode
 * 
 * NISSAN
 */
void HSA_System__vSetClockScreenMode(tbool blMode);

/**
 * Function: SetClockScreenTimer
 * NISSAN LCN2 Sample
 * NISSAN
 */
void HSA_System__vSetClockScreenTimer(tbool blAction);

/**
 * Function: SetApplicationPalette
 * 
 * NISSAN
 */
void HSA_System__vSetApplicationPalette(ulword ulwPalette);

/**
 * Function: ResetTransitionCounter
 * NISSAN LCN2 Sample
 * NISSAN
 */
void HSA_System__vResetTransitionCounter( void);

/**
 * Function: IncrementTransitionCounter
 * NISSAN LCN2 Sample
 * NISSAN
 */
void HSA_System__vIncrementTransitionCounter( void);

/**
 * Function: DecrementTransitionCounter
 * NISSAN LCN2 Sample
 * NISSAN
 */
void HSA_System__vDecrementTransitionCounter( void);

/**
 * Function: GetVersion
 * NISSAN LCN2 Sample
 * NISSAN
 */
void HSA_System__vGetVersion( void);

/**
 * Function: IsOverSpeedActive
 * NISSAN LCN2 Sample
 * NISSAN
 */
tbool HSA_System__blIsOverSpeedActive( void);

/**
 * Function: GetEcoDrivingDataSymbolType
 * NISSAN LCN2 Sample
 * NISSAN
 */
ulword HSA_System__ulwGetEcoDrivingDataSymbolType( void);

/**
 * Function: GetEcoDrivingScore
 * NISSAN LCN2  Sample
 * NISSAN
 */
ulword HSA_System__ulwGetEcoDrivingScore( void);

/**
 * Function: GetEcoPullingAwayScore
 * NISSAN LCN2 Sample
 * NISSAN
 */
ulword HSA_System__ulwGetEcoPullingAwayScore( void);

/**
 * Function: GetEcoCruiseScore
 * NISSAN LCN2 Sample
 * NISSAN
 */
ulword HSA_System__ulwGetEcoCruiseScore( void);

/**
 * Function: GetEcoDecelerationScore
 * NISSAN LCN2 Sample
 * NISSAN
 */
ulword HSA_System__ulwGetEcoDecelerationScore( void);

/**
 * Function: GetEcoDDrivingHistoryValues
 * NISSAN LCN2 Sample
 * NISSAN
 */
ulword HSA_System__ulwGetEcoDDrivingHistoryValues(ulword ulwListEntryNumber);

/**
 * Function: GetEcoDDrivingHistoryDateString
 * NISSAN LCN2 Sample
 * NISSAN
 */
void HSA_System__vGetEcoDDrivingHistoryDateString(GUI_String *out_result, ulword ulwListEntryNumber);

/**
 * Function: GetEcoDDrivingHistoryDateMonth
 * NISSAN LCN2 Sample
 * NISSAN
 */
ulword HSA_System__ulwGetEcoDDrivingHistoryDateMonth(ulword ulwListEntryNumber);

/**
 * Function: GetEcoDDrivingHistoryDateDay
 * NISSAN LCN2 Sample
 * NISSAN
 */
ulword HSA_System__ulwGetEcoDDrivingHistoryDateDay(ulword ulwListEntryNumber);

/**
 * Function: ResetEcoDrivingHistory
 * NISSAN LCN2 Sample
 * NISSAN
 */
void HSA_System__vResetEcoDrivingHistory( void);

/**
 * Function: XMLVersionCheckStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwXMLVersionCheckStatus( void);

/**
 * Function: GetXMLVersionString
 * 
 * NISSAN
 */
void HSA_System__vGetXMLVersionString(GUI_String *out_result, ulword ulwDevice);

/**
 * Function: SetMeterAudioWarning
 * 
 * NISSAN
 */
void HSA_System__vSetMeterAudioWarning(ulword ulwWarningState, const GUI_String * WarningText);

/**
 * Function: SetMeterSMSPopup
 * 
 * NISSAN
 */
void HSA_System__vSetMeterSMSPopup(ulword ulwSMSState, ulword ulwListEntryNr);

/**
 * Function: SetSMSMessageTextPopupState
 * 
 * NISSAN
 */
void HSA_System__vSetSMSMessageTextPopupState(tbool blStatus);

/**
 * Function: IsMeterConnected
 * 
 * NISSAN
 */
tbool HSA_System__blIsMeterConnected( void);

/**
 * Function: SetXMLVersionDisclaimerAcceptance
 * 
 * NISSAN
 */
void HSA_System__vSetXMLVersionDisclaimerAcceptance(tbool blStatus);

/**
 * Function: GetXMLVersionDisclaimerAcceptance
 * 
 * NISSAN
 */
tbool HSA_System__blGetXMLVersionDisclaimerAcceptance( void);

/**
 * Function: GetSrvSystemSelfTest
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetSrvSystemSelfTest(ulword ulwSystemSelfTest);

/**
 * Function: GetSrvSDCardWriteProtectionStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetSrvSDCardWriteProtectionStatus( void);

/**
 * Function: GetImmobilizerLockState
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetImmobilizerLockState( void);

/**
 * Function: SetImmobilizerLockStateToUnLock
 * NISSAN
 * NISSAN
 */
void HSA_System__vSetImmobilizerLockStateToUnLock( void);

/**
 * Function: GetSrvSystemConfig
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetSrvSystemConfig(ulword ulwSystemConfig);

/**
 * Function: GetXMTunerFirmwareVersion
 * NISSAN NAR
 * NISSAN
 */
void HSA_System__vGetXMTunerFirmwareVersion(GUI_String *out_result);

/**
 * Function: GetBTHF_BoxVersion
 * NISSAN NAR
 * NISSAN
 */
void HSA_System__vGetBTHF_BoxVersion(GUI_String *out_result);

/**
 * Function: GetDisplayMode
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetDisplayMode( void);

/**
 * Function: GetDisplayTestScreen
 * B1
 * NISSAN
 */
ulword HSA_System__ulwGetDisplayTestScreen( void);

/**
 * Function: GetNavDisclaimerConfirmed
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blGetNavDisclaimerConfirmed( void);

/**
 * Function: SetNavDisclaimerConfirmed
 * NISSAN
 * NISSAN
 */
void HSA_System__vSetNavDisclaimerConfirmed( void);

/**
 * Function: DisableDestinationInputWhileDriving
 * NISSAN
 * NISSAN
 */
void HSA_System__vDisableDestinationInputWhileDriving( void);

/**
 * Function: GetDestinationInputWhileDriving
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blGetDestinationInputWhileDriving( void);

/**
 * Function: SetBeepMode
 * NISSAN
 * NISSAN
 */
void HSA_System__vSetBeepMode(ulword ulwListEntryNr);

/**
 * Function: GetBeepMode
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetBeepMode( void);

/**
 * Function: ToggleDisplayMode
 * NISSAN
 * NISSAN
 */
void HSA_System__vToggleDisplayMode( void);

/**
 * Function: LanguageIconSelected
 * NISSAN
 * NISSAN
 */
void HSA_System__vLanguageIconSelected( void);

/**
 * Function: GetSystemSerialNo
 * NISSAN
 * NISSAN
 */
void HSA_System__vGetSystemSerialNo(GUI_String *out_result);

/**
 * Function: GetSystemDeviceNo
 * NISSAN
 * NISSAN
 */
void HSA_System__vGetSystemDeviceNo(GUI_String *out_result);

/**
 * Function: GetSystemProductionDate
 * NISSAN
 * NISSAN
 */
void HSA_System__vGetSystemProductionDate(GUI_String *out_result);

/**
 * Function: PerformSpeakerTest
 * NISSAN
 * NISSAN
 */
void HSA_System__vPerformSpeakerTest(ulword ulwFrequency);

/**
 * Function: SetEncoderDirection
 * NISSAN
 * NISSAN
 */
void HSA_System__vSetEncoderDirection(ulword ulwEncoderDirn);

/**
 * Function: GetEncoderDirection
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blGetEncoderDirection( void);

/**
 * Function: GetCurrentSelfTestProgressValue
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetCurrentSelfTestProgressValue( void);

/**
 * Function: SetRVCFlag
 * 
 * NISSAN
 */
void HSA_System__vSetRVCFlag(tbool blValue);

/**
 * Function: GetCameraDisplaySettingsPopupState
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetCameraDisplaySettingsPopupState( void);

/**
 * Function: SwitchToCameraScreen
 * 
 * NISSAN
 */
void HSA_System__vSwitchToCameraScreen(tbool blbSwitchStatus, ulword ulwCameraSettingParam);

/**
 * Function: ToggleGuideLineState
 * 
 * NISSAN
 */
void HSA_System__vToggleGuideLineState( void);

/**
 * Function: GetRVCGuideLineStatus
 * 
 * NISSAN
 */
ulword HSA_System__ulwGetRVCGuideLineStatus( void);

/**
 * Function: InformCameraHKPress
 * 
 * NISSAN
 */
void HSA_System__vInformCameraHKPress(tbool blCameraHKPressType);

/**
 * Function: GetCameraSystemConfigured
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetCameraSystemConfigured( void);

/**
 * Function: GetCameraRequestState
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetCameraRequestState( void);

/**
 * Function: IsCameraReqTimeOutRequired
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blIsCameraReqTimeOutRequired( void);

/**
 * Function: IsCameraRequestActive
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blIsCameraRequestActive( void);

/**
 * Function: IsVideoSignalAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blIsVideoSignalAvailable( void);

/**
 * Function: IsAVMRequestActive
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blIsAVMRequestActive( void);

/**
 * Function: IsAffordableITSAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blIsAffordableITSAvailable( void);

/**
 * Function: SwitchOffCamera
 * NISSAN
 * NISSAN
 */
void HSA_System__vSwitchOffCamera( void);

/**
 * Function: GetCameraConfigStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetCameraConfigStatus(ulword ulwConfigParam);

/**
 * Function: ToggleCameraConfigStatus
 * NISSAN
 * NISSAN
 */
void HSA_System__vToggleCameraConfigStatus(ulword ulwConfigParam);

/**
 * Function: GetVideoDimming
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetVideoDimming(ulword ulwDimmingParam);

/**
 * Function: InformAVMOnPurposeSwitch
 * NISSAN
 * NISSAN
 */
void HSA_System__vInformAVMOnPurposeSwitch( void);

/**
 * Function: SetVideoDimming
 * NISSAN
 * NISSAN
 */
void HSA_System__vSetVideoDimming(ulword ulwDimmingParam, tbool blMode);

/**
 * Function: IPA_SendButtonPress
 * NISSAN
 * NISSAN
 */
void HSA_System__vIPA_SendButtonPress(ulword ulwButtonIdentifier, ulword ulwButtonState);

/**
 * Function: IPA_SetHMIStatus
 * NISSAN
 * NISSAN
 */
void HSA_System__vIPA_SetHMIStatus(tbool blHmiStatus);

/**
 * Function: IPA_GetAvailablityStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwIPA_GetAvailablityStatus( void);

/**
 * Function: IPA_GetConfiguredRegion
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwIPA_GetConfiguredRegion( void);

/**
 * Function: IPA_GetMessageRequested
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwIPA_GetMessageRequested( void);

/**
 * Function: IPA_GetPatternRequested
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwIPA_GetPatternRequested( void);

/**
 * Function: IPA_GetPopupRequested
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwIPA_GetPopupRequested( void);

/**
 * Function: IPA_GetOperationStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwIPA_GetOperationStatus( void);

/**
 * Function: IPA_GetMode
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwIPA_GetMode( void);

/**
 * Function: IPA_GetCarDirection_Indicator_Status
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwIPA_GetCarDirection_Indicator_Status( void);

/**
 * Function: IPA_GetButtonVisibilityStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwIPA_GetButtonVisibilityStatus(ulword ulwButtonIdentifier);

/**
 * Function: SONAR_GetVisualizationStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blSONAR_GetVisualizationStatus( void);

/**
 * Function: SONAR_GetCarShapeModel
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwSONAR_GetCarShapeModel( void);

/**
 * Function: SONAR_GetAvailabilityStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwSONAR_GetAvailabilityStatus( void);

/**
 * Function: SONAR_GetSonarSwitchAvailability
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blSONAR_GetSonarSwitchAvailability( void);

/**
 * Function: SONAR_GetErrorStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blSONAR_GetErrorStatus( void);

/**
 * Function: SONAR_GetFrontSensorAvailability
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwSONAR_GetFrontSensorAvailability( void);

/**
 * Function: SONAR_GetRearSensorAvailability
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwSONAR_GetRearSensorAvailability( void);

/**
 * Function: SONAR_GetFrontSensorDistanceLevels
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwSONAR_GetFrontSensorDistanceLevels( void);

/**
 * Function: SONAR_GetRearSensorDistanceLevels
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwSONAR_GetRearSensorDistanceLevels( void);

/**
 * Function: SONAR_GetSystemStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blSONAR_GetSystemStatus( void);

/**
 * Function: SONAR_GetFrontSensorsOnlyStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blSONAR_GetFrontSensorsOnlyStatus( void);

/**
 * Function: SONAR_GetAutomaticDisplayStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blSONAR_GetAutomaticDisplayStatus( void);

/**
 * Function: SONAR_GetSensitivityLevel
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwSONAR_GetSensitivityLevel( void);

/**
 * Function: SONAR_GetVolumeLevel
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwSONAR_GetVolumeLevel( void);

/**
 * Function: ToggleSonarCancelSwitchStatus
 * 
 * NISSAN
 */
void HSA_System__vToggleSonarCancelSwitchStatus( void);

/**
 * Function: ToggleSonarSystemOption
 * 
 * NISSAN
 */
void HSA_System__vToggleSonarSystemOption( void);

/**
 * Function: ToggleFrontSensorsOnlyOption
 * 
 * NISSAN
 */
void HSA_System__vToggleFrontSensorsOnlyOption( void);

/**
 * Function: ToggleAutomaticDisplayOption
 * 
 * NISSAN
 */
void HSA_System__vToggleAutomaticDisplayOption( void);

/**
 * Function: SetSonarSensitivityLevel
 * 
 * NISSAN
 */
void HSA_System__vSetSonarSensitivityLevel( void);

/**
 * Function: SetSonarVolumeLevel
 * 
 * NISSAN
 */
void HSA_System__vSetSonarVolumeLevel( void);

/**
 * Function: SONAR_GetSonarMenu
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwSONAR_GetSonarMenu( void);

/**
 * Function: GetSystemConfig
 * NISSAN
 * NISSAN
 */
void HSA_System__vGetSystemConfig(GUI_String *out_result, ulword ulwSystemConfig);

/**
 * Function: GetSystemHistory
 * NISSAN
 * NISSAN
 */
void HSA_System__vGetSystemHistory(GUI_String *out_result, ulword ulwSystemHistory);

/**
 * Function: GetSystemSelfTest
 * NISSAN
 * NISSAN
 */
void HSA_System__vGetSystemSelfTest(GUI_String *out_result, ulword ulwSystemSelfTest);

/**
 * Function: StartSelfTest
 * NISSAN
 * NISSAN
 */
void HSA_System__vStartSelfTest( void);

/**
 * Function: GetUSBSlotMedium
 * NISSAN
 * NISSAN
 */
void HSA_System__vGetUSBSlotMedium(GUI_String *out_result);

/**
 * Function: GetViaGPSTimeStatus
 * 
 * NISSAN
 */
ulword HSA_System__ulwGetViaGPSTimeStatus( void);

/**
 * Function: ToggleViaGPSTimeStatus
 * 
 * NISSAN
 */
void HSA_System__vToggleViaGPSTimeStatus( void);

/**
 * Function: GetSummerTimeStatus
 * 
 * NISSAN
 */
tbool HSA_System__blGetSummerTimeStatus( void);

/**
 * Function: ToggleSummerTimeStatus
 * 
 * NISSAN
 */
void HSA_System__vToggleSummerTimeStatus( void);

/**
 * Function: GetCurrentTZ
 * 
 * NISSAN
 */
void HSA_System__vGetCurrentTZ(GUI_String *out_result);

/**
 * Function: GetCurrentTZIndex
 * 
 * NISSAN
 */
ulword HSA_System__ulwGetCurrentTZIndex( void);

/**
 * Function: GetTZListCount
 * 
 * NISSAN
 */
ulword HSA_System__ulwGetTZListCount( void);

/**
 * Function: GetTZListElement
 * 
 * NISSAN
 */
void HSA_System__vGetTZListElement(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: SetTZ
 * 
 * NISSAN
 */
void HSA_System__vSetTZ(ulword ulwListEntryNr);

/**
 * Function: IncreaseTimeHour
 * 
 * NISSAN
 */
void HSA_System__vIncreaseTimeHour( void);

/**
 * Function: DateHandling
 * 
 * NISSAN
 */
void HSA_System__vDateHandling(ulword ulwType, tbool blOperation);

/**
 * Function: ToggleDateFormat
 * NISSAN 2.0
 * NISSAN
 */
void HSA_System__vToggleDateFormat( void);

/**
 * Function: GetDateFormat
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetDateFormat( void);

/**
 * Function: DecreaseTimeHour
 * 
 * NISSAN
 */
void HSA_System__vDecreaseTimeHour( void);

/**
 * Function: GetTimeHour
 * 
 * NISSAN
 */
ulword HSA_System__ulwGetTimeHour( void);

/**
 * Function: IncreaseTimeMinute
 * 
 * NISSAN
 */
void HSA_System__vIncreaseTimeMinute( void);

/**
 * Function: IncreaseDateDay
 * 
 * NISSAN
 */
void HSA_System__vIncreaseDateDay( void);

/**
 * Function: IncreaseDateMonth
 * 
 * NISSAN
 */
void HSA_System__vIncreaseDateMonth( void);

/**
 * Function: IncreaseDateYear
 * 
 * NISSAN
 */
void HSA_System__vIncreaseDateYear( void);

/**
 * Function: DecreaseTimeMinute
 * 
 * NISSAN
 */
void HSA_System__vDecreaseTimeMinute( void);

/**
 * Function: DecreaseDateDay
 * 
 * NISSAN
 */
void HSA_System__vDecreaseDateDay( void);

/**
 * Function: DecreaseDateMonth
 * 
 * NISSAN
 */
void HSA_System__vDecreaseDateMonth( void);

/**
 * Function: DecreaseDateYear
 * 
 * NISSAN
 */
void HSA_System__vDecreaseDateYear( void);

/**
 * Function: GetTimeMinute
 * 
 * NISSAN
 */
ulword HSA_System__ulwGetTimeMinute( void);

/**
 * Function: ActivateFirstMediaData
 * B2
 * NISSAN
 */
void HSA_System__vActivateFirstMediaData(ulword ulwSource);

/**
 * Function: AreRearSpeakersAssembled
 * B2
 * NISSAN
 */
tbool HSA_System__blAreRearSpeakersAssembled( void);

/**
 * Function: CancelSoftwareDownload
 * B
 * NISSAN
 */
void HSA_System__vCancelSoftwareDownload( void);

/**
 * Function: CheckAssemblyUnlock
 * B2
 * NISSAN
 */
tbool HSA_System__blCheckAssemblyUnlock( void);

/**
 * Function: CheckCode
 * B2
 * NISSAN
 */
ulword HSA_System__ulwCheckCode( void);

/**
 * Function: CheckSDCode
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwCheckSDCode( void);

/**
 * Function: CheckComfortCoding
 * B2
 * NISSAN
 */
ulword HSA_System__ulwCheckComfortCoding( void);

/**
 * Function: CheckSDPaired
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwCheckSDPaired( void);

/**
 * Function: CheckSDPINRequirement
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwCheckSDPINRequirement( void);

/**
 * Function: CheckSpellerDisclaimer
 * B2
 * NISSAN
 */
void HSA_System__vCheckSpellerDisclaimer( void);

/**
 * Function: CodeInput
 * B2
 * NISSAN
 */
void HSA_System__vCodeInput(const GUI_String * InputString);

/**
 * Function: SDCodeInput
 * NISSAN
 * NISSAN
 */
void HSA_System__vSDCodeInput(const GUI_String * InputString);

/**
 * Function: SetupGetPresetMenu
 * NISSAN 2.0
 * NISSAN
 */
tbool HSA_System__blSetupGetPresetMenu( void);

/**
 * Function: SetupSetPresetMenu
 * NISSAN 2.0
 * NISSAN
 */
void HSA_System__vSetupSetPresetMenu(tbool blMode);

/**
 * Function: GetSizeofDisplay
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetSizeofDisplay( void);

/**
 * Function: CreateBeep
 * B1
 * NISSAN
 */
void HSA_System__vCreateBeep( void);

/**
 * Function: CreateBeepX
 * B1
 * NISSAN
 */
void HSA_System__vCreateBeepX(ulword ulwBeepType);

/**
 * Function: EjectCD
 * B
 * NISSAN
 */
void HSA_System__vEjectCD( void);

/**
 * Function: GetAcousticTouchscreenFeedback
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetAcousticTouchscreenFeedback( void);

/**
 * Function: GetBluetoothSWProgress
 * B1
 * NISSAN
 */
ulword HSA_System__ulwGetBluetoothSWProgress( void);

/**
 * Function: GetClimateAirflowBody
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetClimateAirflowBody(ulword ulwSeat);

/**
 * Function: GetClimateAirflowFootwell
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetClimateAirflowFootwell(ulword ulwSeat);

/**
 * Function: GetClimateAirflowRange
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetClimateAirflowRange( void);

/**
 * Function: GetClimateAirflowUp
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetClimateAirflowUp(ulword ulwSeat);

/**
 * Function: GetClimateContext
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetClimateContext( void);

/**
 * Function: GetClimateCurrentStatusIcon
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetClimateCurrentStatusIcon( void);

/**
 * Function: GetClimatePopupDuration
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetClimatePopupDuration( void);

/**
 * Function: GetClimateRearState
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetClimateRearState( void);

/**
 * Function: GetClimateSeatheat
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetClimateSeatheat(ulword ulwSeat);

/**
 * Function: GetClimateStatusIcons
 * B2
 * NISSAN
 */
void HSA_System__vGetClimateStatusIcons(GUI_String *out_result);

/**
 * Function: GetCodeInput
 * B2
 * NISSAN
 */
void HSA_System__vGetCodeInput(GUI_String *out_result);

/**
 * Function: GetSDCodeInput
 * NISSAN
 * NISSAN
 */
void HSA_System__vGetSDCodeInput(GUI_String *out_result);

/**
 * Function: GetCurrentDistanceUnit
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetCurrentDistanceUnit( void);

/**
 * Function: GetCurrentMenuLanguage
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetCurrentMenuLanguage( void);

/**
 * Function: GetCurrentTemperatureUnit
 * B2
 * NISSAN
 */
void HSA_System__vGetCurrentTemperatureUnit(GUI_String *out_result, ulword ulwSeat);

/**
 * Function: GetDABSWProgress
 * B1
 * NISSAN
 */
ulword HSA_System__ulwGetDABSWProgress( void);

/**
 * Function: GetDate
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetDate(ulword ulwYearOrMonthOrDay);

/**
 * Function: GetDateMode
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetDateMode( void);

/**
 * Function: GetDesiredTemperatureAsString
 * B2
 * NISSAN
 */
void HSA_System__vGetDesiredTemperatureAsString(GUI_String *out_result, ulword ulwSeat);

/**
 * Function: GetDisplayBrightness
 * B1
 * NISSAN
 */
slword HSA_System__slwGetDisplayBrightness( void);

/**
 * Function: GetFGSSWProgress
 * B1
 * NISSAN
 */
ulword HSA_System__ulwGetFGSSWProgress( void);

/**
 * Function: GetLanguageCode
 * B
 * NISSAN
 */
void HSA_System__vGetLanguageCode(GUI_String *out_result);

/**
 * Function: GetLastClamp15OffTime
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetLastClamp15OffTime( void);

/**
 * Function: GetLastMainContext
 * B1
 * NISSAN
 */
ulword HSA_System__ulwGetLastMainContext( void);

/**
 * Function: GetNavSWProgress
 * B1
 * NISSAN
 */
ulword HSA_System__ulwGetNavSWProgress( void);

/**
 * Function: GetOPSCarType
 * B
 * NISSAN
 */
void HSA_System__vGetOPSCarType(GUI_String *out_result);

/**
 * Function: GetOPSFrontDistance
 * B
 * NISSAN
 */
ulword HSA_System__ulwGetOPSFrontDistance(ulword ulwSector);

/**
 * Function: GetOPSNumberOfSectors
 * B
 * NISSAN
 */
ulword HSA_System__ulwGetOPSNumberOfSectors( void);

/**
 * Function: GetOPSRearDistance
 * B
 * NISSAN
 */
ulword HSA_System__ulwGetOPSRearDistance(ulword ulwSector);

/**
 * Function: GetOPSRearSensorsOnly
 * B
 * NISSAN
 */
tbool HSA_System__blGetOPSRearSensorsOnly( void);

/**
 * Function: GetRemainingAttempts
 * B2
 * NISSAN
 */
void HSA_System__vGetRemainingAttempts(GUI_String *out_result);

/**
 * Function: GetSDRemainingAttempts
 * NISSAN
 * NISSAN
 */
void HSA_System__vGetSDRemainingAttempts(GUI_String *out_result);

/**
 * Function: GetRemainingUnlocks
 * B2
 * NISSAN
 */
void HSA_System__vGetRemainingUnlocks(GUI_String *out_result);

/**
 * Function: GetRVCDark
 * B
 * NISSAN
 */
ulword HSA_System__ulwGetRVCDark( void);

/**
 * Function: GetRVCMode
 * B
 * NISSAN
 */
ulword HSA_System__ulwGetRVCMode( void);

/**
 * Function: GetRVCType
 * 
 * NISSAN
 */
ulword HSA_System__ulwGetRVCType( void);

/**
 * Function: GetSDCardMemoryFree
 * B2
 * NISSAN
 */
void HSA_System__vGetSDCardMemoryFree(GUI_String *out_result);

/**
 * Function: GetSDCardMemoryTotal
 * B2
 * NISSAN
 */
void HSA_System__vGetSDCardMemoryTotal(GUI_String *out_result);

/**
 * Function: GetSDCardMemoryUsedByNAV
 * B2
 * NISSAN
 */
void HSA_System__vGetSDCardMemoryUsedByNAV(GUI_String *out_result);

/**
 * Function: GetSDChkdskProgress
 * B
 * NISSAN
 */
ulword HSA_System__ulwGetSDChkdskProgress( void);

/**
 * Function: GetSDFormatProgress
 * B
 * NISSAN
 */
ulword HSA_System__ulwGetSDFormatProgress( void);

/**
 * Function: GetSkinDayNight
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetSkinDayNight( void);

/**
 * Function: GetSoftwareDownloadErrorCode
 * B1
 * NISSAN
 */
void HSA_System__vGetSoftwareDownloadErrorCode(GUI_String *out_result);

/**
 * Function: GetSoftwareVersionFromCD
 * B1
 * NISSAN
 */
void HSA_System__vGetSoftwareVersionFromCD(GUI_String *out_result);

/**
 * Function: GetSoftwareVersionInstalled
 * B1
 * NISSAN
 */
void HSA_System__vGetSoftwareVersionInstalled(GUI_String *out_result);

/**
 * Function: GetSpellerLayout
 * B
 * NISSAN
 */
ulword HSA_System__ulwGetSpellerLayout( void);

/**
 * Function: GetSWUpdateProgress
 * B1
 * NISSAN
 */
ulword HSA_System__ulwGetSWUpdateProgress( void);

/**
 * Function: GetSystemCodeCountdownTime
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetSystemCodeCountdownTime( void);

/**
 * Function: GetSystemCodeCountdownTimeAsString
 * B2
 * NISSAN
 */
void HSA_System__vGetSystemCodeCountdownTimeAsString(GUI_String *out_result);

/**
 * Function: GetSDCodeCountdownTime
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetSDCodeCountdownTime( void);

/**
 * Function: GetSDCodeCountdownTimeAsString
 * NISSAN
 * NISSAN
 */
void HSA_System__vGetSDCodeCountdownTimeAsString(GUI_String *out_result);

/**
 * Function: GetSystemOnOffState
 * B
 * NISSAN
 */
ulword HSA_System__ulwGetSystemOnOffState( void);

/**
 * Function: GetSystemSWProgress
 * B1
 * NISSAN
 */
ulword HSA_System__ulwGetSystemSWProgress( void);

/**
 * Function: GetSystemVendor
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetSystemVendor( void);

/**
 * Function: GetWeekdayOfToday
 * NISSAN LCN2
 * NISSAN
 */
ulword HSA_System__ulwGetWeekdayOfToday( void);

/**
 * Function: GetWeekdayOfTomorrow
 * NISSAN LCN2
 * NISSAN
 */
ulword HSA_System__ulwGetWeekdayOfTomorrow( void);

/**
 * Function: GetTime
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetTime(ulword ulwHourOrMinute);

/**
 * Function: GetTimeFormat
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetTimeFormat( void);

/**
 * Function: GetTimeFormatted
 * B2
 * NISSAN
 */
void HSA_System__vGetTimeFormatted(GUI_String *out_result);

/**
 * Function: IsAPSPresent
 * B
 * NISSAN
 */
tbool HSA_System__blIsAPSPresent( void);

/**
 * Function: IsClimateSetupAvailable
 * B2
 * NISSAN
 */
tbool HSA_System__blIsClimateSetupAvailable( void);

/**
 * Function: IsClimateStatusLineFunctionOn
 * B2
 * NISSAN
 */
tbool HSA_System__blIsClimateStatusLineFunctionOn( void);

/**
 * Function: IsClimateTempChanged
 * B2
 * NISSAN
 */
tbool HSA_System__blIsClimateTempChanged(ulword ulwSeat);

/**
 * Function: IsClimateTempInRange
 * B2
 * NISSAN
 */
tbool HSA_System__blIsClimateTempInRange(ulword ulwSeat);

/**
 * Function: IsDateFormatMasterPresent
 * B2
 * NISSAN
 */
tbool HSA_System__blIsDateFormatMasterPresent( void);

/**
 * Function: IsDateMasterPresent
 * B2
 * NISSAN
 */
tbool HSA_System__blIsDateMasterPresent( void);

/**
 * Function: IsDateValid
 * B2
 * NISSAN
 */
slword HSA_System__slwIsDateValid( void);

/**
 * Function: IsOPSPresent
 * B
 * NISSAN
 */
tbool HSA_System__blIsOPSPresent( void);

/**
 * Function: IsOPSTrailerRecognized
 * B
 * NISSAN
 */
tbool HSA_System__blIsOPSTrailerRecognized( void);

/**
 * Function: IsRearGearActive
 * B2
 * NISSAN
 */
tbool HSA_System__blIsRearGearActive( void);

/**
 * Function: IsRVCRequestActive
 * B2
 * NISSAN
 */
tbool HSA_System__blIsRVCRequestActive( void);

/**
 * Function: IsSDCardAvailable
 * B2
 * NISSAN
 */
ulword HSA_System__ulwIsSDCardAvailable( void);

/**
 * Function: IsSDCardInUse
 * B2
 * NISSAN
 */
tbool HSA_System__blIsSDCardInUse( void);

/**
 * Function: IsSkodaExternalAmpAvailable
 * B2
 * NISSAN
 */
tbool HSA_System__blIsSkodaExternalAmpAvailable( void);

/**
 * Function: IsSWDownloadPossible
 * B1
 * NISSAN
 */
tbool HSA_System__blIsSWDownloadPossible( void);

/**
 * Function: IsTimeFormatMasterPresent
 * B2
 * NISSAN
 */
tbool HSA_System__blIsTimeFormatMasterPresent( void);

/**
 * Function: IsTimeMasterPresent
 * B2
 * NISSAN
 */
tbool HSA_System__blIsTimeMasterPresent( void);

/**
 * Function: IsTimeValid
 * B2
 * NISSAN
 */
slword HSA_System__slwIsTimeValid( void);

/**
 * Function: LockDDSEventFocus
 * B1
 * NISSAN
 */
void HSA_System__vLockDDSEventFocus( void);

/**
 * Function: LockDDSVolumeFocus
 * B1
 * NISSAN
 */
void HSA_System__vLockDDSVolumeFocus( void);

/**
 * Function: RestartSystem
 * B1
 * NISSAN
 */
void HSA_System__vRestartSystem( void);

/**
 * Function: RestoreDDSSpeedup
 * B
 * NISSAN
 */
void HSA_System__vRestoreDDSSpeedup( void);

/**
 * Function: RestoreDDSVolumeSpeedup
 * B
 * NISSAN
 */
void HSA_System__vRestoreDDSVolumeSpeedup( void);

/**
 * Function: SaveDate
 * B2
 * NISSAN
 */
void HSA_System__vSaveDate( void);

/**
 * Function: SaveTime
 * B2
 * NISSAN
 */
void HSA_System__vSaveTime( void);

/**
 * Function: DURSnooze
 * B?
 * NISSAN
 */
void HSA_System__vDURSnooze( void);

/**
 * Function: DURDismiss
 * B?
 * NISSAN
 */
void HSA_System__vDURDismiss( void);

/**
 * Function: SetAcousticTouchscreenFeedback
 * B2
 * NISSAN
 */
void HSA_System__vSetAcousticTouchscreenFeedback(ulword ulwListEntryNr);

/**
 * Function: SetClimatePopupDuration
 * B2
 * NISSAN
 */
void HSA_System__vSetClimatePopupDuration(ulword ulwMode);

/**
 * Function: SetDateDay
 * B2
 * NISSAN
 */
void HSA_System__vSetDateDay(ulword ulwDay);

/**
 * Function: SetDateMode
 * B2
 * NISSAN
 */
void HSA_System__vSetDateMode(ulword ulwMode);

/**
 * Function: SetDateMonth
 * B2
 * NISSAN
 */
void HSA_System__vSetDateMonth(ulword ulwMonth);

/**
 * Function: SetDateYear
 * B2
 * NISSAN
 */
void HSA_System__vSetDateYear(ulword ulwYear);

/**
 * Function: SetDDSEventFocus
 * B1
 * NISSAN
 */
void HSA_System__vSetDDSEventFocus(ulword ulwWindow);

/**
 * Function: SetDDSSpeedup
 * B
 * NISSAN
 */
void HSA_System__vSetDDSSpeedup(ulword ulwtime, ulword ulwthreshold, ulword ulwmultiplier);

/**
 * Function: SetDDSVolumeFocus
 * B1
 * NISSAN
 */
void HSA_System__vSetDDSVolumeFocus(ulword ulwWindow);

/**
 * Function: SetDDSVolumeSpeedup
 * B
 * NISSAN
 */
void HSA_System__vSetDDSVolumeSpeedup(ulword ulwtime, ulword ulwthreshold, ulword ulwmultiplier);

/**
 * Function: SetDisplayBrightness
 * B1
 * NISSAN
 */
void HSA_System__vSetDisplayBrightness(tbool blMode);

/**
 * Function: SetDistanceUnit
 * B2
 * NISSAN
 */
void HSA_System__vSetDistanceUnit(ulword ulwMode);

/**
 * Function: SetFactorySettings
 * B2
 * NISSAN
 */
void HSA_System__vSetFactorySettings( void);

/**
 * Function: SetLastMainContext
 * B1
 * NISSAN
 */
void HSA_System__vSetLastMainContext(ulword ulwListEntryNr);

/**
 * Function: SetMenuLanguage
 * B2
 * NISSAN
 */
void HSA_System__vSetMenuLanguage(ulword ulwListEntryNr);

/**
 * Function: SetRVCMode
 * B
 * NISSAN
 */
void HSA_System__vSetRVCMode(ulword ulwRVCMode);

/**
 * Function: SetSkinDayNight
 * B2
 * NISSAN
 */
void HSA_System__vSetSkinDayNight(ulword ulwMode);

/**
 * Function: GetDimstate
 * B
 * NISSAN
 */
tbool HSA_System__blGetDimstate( void);

/**
 * Function: SetSpellerLayout
 * B
 * NISSAN
 */
void HSA_System__vSetSpellerLayout(ulword ulwLayout);

/**
 * Function: SetTimeFormat
 * B2
 * NISSAN
 */
void HSA_System__vSetTimeFormat(ulword ulwFormat);

/**
 * Function: SetTimeHour
 * B2
 * NISSAN
 */
void HSA_System__vSetTimeHour(ulword ulwHour);

/**
 * Function: SetTimeMinute
 * B2
 * NISSAN
 */
void HSA_System__vSetTimeMinute(ulword ulwMinute);

/**
 * Function: SetTimeMode
 * B2
 * NISSAN
 */
void HSA_System__vSetTimeMode(ulword ulwMode);

/**
 * Function: GetTimeMode
 * B2
 * NISSAN
 */
ulword HSA_System__ulwGetTimeMode( void);

/**
 * Function: SetUserConfirmedSpellerDisclaimer
 * B2
 * NISSAN
 */
void HSA_System__vSetUserConfirmedSpellerDisclaimer( void);

/**
 * Function: SpellerInvertGetLetterFunction
 * B
 * NISSAN
 */
tbool HSA_System__blSpellerInvertGetLetterFunction( void);

/**
 * Function: SpellerSetMaxCharCount
 * B
 * NISSAN
 */
void HSA_System__vSpellerSetMaxCharCount(ulword ulwCount);

/**
 * Function: StartChkdsk
 * B
 * NISSAN
 */
void HSA_System__vStartChkdsk( void);

/**
 * Function: StartFormatting
 * B
 * NISSAN
 */
void HSA_System__vStartFormatting( void);

/**
 * Function: StartSoftwareDownload
 * B1
 * NISSAN
 */
void HSA_System__vStartSoftwareDownload( void);

/**
 * Function: InsertMediaForDownload
 * 
 * NISSAN
 */
void HSA_System__vInsertMediaForDownload( void);

/**
 * Function: UnLockDDSEventFocus
 * B1
 * NISSAN
 */
void HSA_System__vUnLockDDSEventFocus( void);

/**
 * Function: UnLockDDSVolumeFocus
 * B1
 * NISSAN
 */
void HSA_System__vUnLockDDSVolumeFocus( void);

/**
 * Function: UnmountSD
 * B
 * NISSAN
 */
void HSA_System__vUnmountSD( void);

/**
 * Function: IsForcedDownloadPossible
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blIsForcedDownloadPossible( void);

/**
 * Function: GetEABlockingMode
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetEABlockingMode(ulword ulwApplication);

/**
 * Function: GetNissanRegionType
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetNissanRegionType( void);

/**
 * Function: GetUnitOfTemperature
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetUnitOfTemperature( void);

/**
 * Function: SetUnitOfTemperature
 * 
 * NISSAN
 */
void HSA_System__vSetUnitOfTemperature(ulword ulwTemperatureUnit);

/**
 * Function: GetDocumentText
 * NISSAN
 * NISSAN
 */
void HSA_System__vGetDocumentText(GUI_String *out_result, const GUI_String * DocPath);

/**
 * Function: GetDocumentSize
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetDocumentSize(const GUI_String * DocPath);

/**
 * Function: GetHEVDriveType
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetHEVDriveType( void);

/**
 * Function: GetHEVBodyShape
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetHEVBodyShape( void);

/**
 * Function: GetHEVEnergyFlow_StartIndex
 * 
 * NISSAN
 */
ulword HSA_System__ulwGetHEVEnergyFlow_StartIndex( void);

/**
 * Function: GetHEVEnergyFlow_EndIndex
 * 
 * NISSAN
 */
ulword HSA_System__ulwGetHEVEnergyFlow_EndIndex( void);

/**
 * Function: GetHEVEngineOperationState
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blGetHEVEngineOperationState( void);

/**
 * Function: GetHEVBatteryOperationState
 * NISSAN
 * NISSAN
 */
tbool HSA_System__blGetHEVBatteryOperationState( void);

/**
 * Function: GetHEVBatteryChargeDischargeState
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetHEVBatteryChargeDischargeState( void);

/**
 * Function: GetHEVBatteryChargeLevel
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetHEVBatteryChargeLevel( void);

/**
 * Function: GetHEVTireRotationDirection
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetHEVTireRotationDirection( void);

/**
 * Function: GetHEVAverageFuelEconomyHistory
 * NISSAN LCN2 Sample
 * NISSAN
 */
ulword HSA_System__ulwGetHEVAverageFuelEconomyHistory(ulword ulwListEntryNumber);

/**
 * Function: GetHEVRegenerationAmountIconHistory
 * NISSAN LCN2 Sample
 * NISSAN
 */
ulword HSA_System__ulwGetHEVRegenerationAmountIconHistory(ulword ulwListEntryNumber);

/**
 * Function: GetHEVDrivingHistoryTimeStamp
 * NISSAN LCN2 Sample
 * NISSAN
 */
ulword HSA_System__ulwGetHEVDrivingHistoryTimeStamp(ulword ulwListEntryNumber);

/**
 * Function: GetHEVDDrivingHistoryDateString
 * NISSAN LCN2 Sample
 * NISSAN
 */
void HSA_System__vGetHEVDDrivingHistoryDateString(GUI_String *out_result, ulword ulwListEntryNumber);

/**
 * Function: GetHEVFuelEconomyUnit
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetHEVFuelEconomyUnit( void);

/**
 * Function: SetHEVShiftDirection
 * NISSAN2.0
 * NISSAN
 */
void HSA_System__vSetHEVShiftDirection(ulword ulwShift_direction);

/**
 * Function: GetHEVScrollKeyGrayingState
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetHEVScrollKeyGrayingState( void);

/**
 * Function: GetHEVHistoryMaxValue
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetHEVHistoryMaxValue( void);

/**
 * Function: LoadHEVHistory
 * B
 * NISSAN
 */
void HSA_System__vLoadHEVHistory( void);

/**
 * Function: GetHEVHistoryLoadingState
 * NISSAN
 * NISSAN
 */
ulword HSA_System__ulwGetHEVHistoryLoadingState( void);

/**
 * Function: IsTimeFormatScreenActive
 * B2
 * NISSAN
 */
void HSA_System__vIsTimeFormatScreenActive(tbool blScreenstate);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_System_H

