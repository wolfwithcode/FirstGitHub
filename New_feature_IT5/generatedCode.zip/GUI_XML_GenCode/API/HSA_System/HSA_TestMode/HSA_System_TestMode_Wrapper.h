/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_System_TestMode_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_System_TestMode_Wrapper_H
#define _HSA_System_TestMode_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: GetTMDataAvailability
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTMDataAvailability( void);

/**
 * Function: SetDABTestmode
 * 
 * NISSAN
 */
void HSA_System_TestMode__vSetDABTestmode(tbool blActive);

/**
 * Function: SetNewScreenDataID
 * 
 * NISSAN
 */
void HSA_System_TestMode__vSetNewScreenDataID(ulword ulwScreen_ID);

/**
 * Function: DisplayTestStatus
 * 
 * NISSAN
 */
void HSA_System_TestMode__vDisplayTestStatus(tbool blDisplayTestSuccess);

/**
 * Function: CheckSystemVoltage
 * 
 * NISSAN
 */
void HSA_System_TestMode__vCheckSystemVoltage(tbool blAction);

/**
 * Function: GetDABChannelNumber
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABChannelNumber(GUI_String *out_result);

/**
 * Function: GetDABEnsembleLabel
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABEnsembleLabel(GUI_String *out_result);

/**
 * Function: GetDABEnsembleID
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABEnsembleID(GUI_String *out_result, ulword ulwDABTuner);

/**
 * Function: GetDABServiceID
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABServiceID(GUI_String *out_result);

/**
 * Function: GetDABFrequencyTable
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABFrequencyTable(GUI_String *out_result);

/**
 * Function: GetDABEnsembleFrequency
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABEnsembleFrequency(ulword ulwDABTuner);

/**
 * Function: GetDABServiceLabel
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABServiceLabel(GUI_String *out_result);

/**
 * Function: GetDABMSCBER
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABMSCBER( void);

/**
 * Function: GetDABFICBER
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABFICBER(ulword ulwDABTuner);

/**
 * Function: GetDAB_RS_FEC
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDAB_RS_FEC( void);

/**
 * Function: GetDAB_BG_Mode
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDAB_BG_Mode(GUI_String *out_result);

/**
 * Function: GetDABTMC
 *  Returns the No of DAB TMC Messages
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABTMC( void);

/**
 * Function: GetDAB_TPEG
 * Returns the No of DAB TMC Messages
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDAB_TPEG( void);

/**
 * Function: StartTPEGRequest
 * B
 * NISSAN
 */
void HSA_System_TestMode__vStartTPEGRequest( void);

/**
 * Function: GetDAB_TPEGNew
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDAB_TPEGNew(GUI_String *out_result, ulword ulwInfo_Type);

/**
 * Function: Get_TEC
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGet_TEC(GUI_String *out_result, ulword ulwInfo_Type);

/**
 * Function: Get_TMC
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGet_TMC(GUI_String *out_result, ulword ulwInfo_Type);

/**
 * Function: GetURIData
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetURIData(GUI_String *out_result, ulword ulwInfo_Type);

/**
 * Function: GetTotalACIDperFrame
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTotalACIDperFrame(ulword ulwInfo_Type);

/**
 * Function: RequestToURIList
 * 
 * NISSAN
 */
void HSA_System_TestMode__vRequestToURIList( void);

/**
 * Function: GetURIListCount
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetURIListCount( void);

/**
 * Function: GetURIList
 * Returns the info of URI List
 * NISSAN
 */
void HSA_System_TestMode__vGetURIList(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwInfo_Type);

/**
 * Function: RequestToStreamList
 * 
 * NISSAN
 */
void HSA_System_TestMode__vRequestToStreamList( void);

/**
 * Function: GetStreamListCount
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetStreamListCount( void);

/**
 * Function: GetStreamList
 * B
 * NISSAN
 */
void HSA_System_TestMode__vGetStreamList(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwInfo_Type);

/**
 * Function: GetDAB_TSU_Status
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blGetDAB_TSU_Status( void);

/**
 * Function: GetDABSwitchingStatus
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blGetDABSwitchingStatus( void);

/**
 * Function: GetDABNumEnsembles_DB
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABNumEnsembles_DB( void);

/**
 * Function: GetDABNum_TMC_Services
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABNum_TMC_Services( void);

/**
 * Function: GetDABNum_TPEG_Services
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABNum_TPEG_Services( void);

/**
 * Function: GetDABExpertIDValue
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABExpertIDValue(GUI_String *out_result, ulword ulwID);

/**
 * Function: GetDABExpertIDInfo
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABExpertIDInfo(GUI_String *out_result, ulword ulwID, ulword ulwID_Value, tbool blType);

/**
 * Function: GetCurrentDABActivity
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetCurrentDABActivity( void);

/**
 * Function: GetDABFieldStrength
 * 
 * NISSAN
 */
slword HSA_System_TestMode__slwGetDABFieldStrength( void);

/**
 * Function: GetDABSignalQuality
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABSignalQuality( void);

/**
 * Function: GetDABAudioQuality
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABAudioQuality( void);

/**
 * Function: GetDABSync
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blGetDABSync(ulword ulwDABTuner);

/**
 * Function: SpellerInitforID
 * 
 * NISSAN
 */
void HSA_System_TestMode__vSpellerInitforID(ulword ulwID);

/**
 * Function: SpellerSetNameInput
 * 
 * NISSAN
 */
void HSA_System_TestMode__vSpellerSetNameInput( void);

/**
 * Function: SpellerGetNameInput
 * 
 * NISSAN
 */
void HSA_System_TestMode__vSpellerGetNameInput(GUI_String *out_result);

/**
 * Function: SpellerCharacterInput
 * 
 * NISSAN
 */
void HSA_System_TestMode__vSpellerCharacterInput(const GUI_String * InputString);

/**
 * Function: SpellerGetCursorPos
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwSpellerGetCursorPos( void);

/**
 * Function: SpellerCharacterDelete
 * 
 * NISSAN
 */
void HSA_System_TestMode__vSpellerCharacterDelete( void);

/**
 * Function: GetTimeInterval
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTimeInterval( void);

/**
 * Function: SetTimeInterval
 * 
 * NISSAN
 */
void HSA_System_TestMode__vSetTimeInterval(ulword ulwInterval);

/**
 * Function: GetDABMute
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blGetDABMute( void);

/**
 * Function: GetDABAudioBitRate
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABAudioBitRate( void);

/**
 * Function: GetDABSamplingRate
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABSamplingRate( void);

/**
 * Function: GetDABStereoMode
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABStereoMode(GUI_String *out_result);

/**
 * Function: GetDABAAC
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABAAC(GUI_String *out_result);

/**
 * Function: GetDABProtectionLevel
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABProtectionLevel( void);

/**
 * Function: GetDABAudioCodec
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABAudioCodec(GUI_String *out_result);

/**
 * Function: GetDABSourceState
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABSourceState( void);

/**
 * Function: GetDABFMFrq
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABFMFrq(GUI_String *out_result);

/**
 * Function: GetDABFMPI
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABFMPI(GUI_String *out_result);

/**
 * Function: GetDABFMQuality
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABFMQuality( void);

/**
 * Function: GetDABTransmissionMode
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABTransmissionMode( void);

/**
 * Function: GetDABShortEnsembleLabel
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABShortEnsembleLabel(GUI_String *out_result);

/**
 * Function: GetDABShortServiceLabel
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABShortServiceLabel(GUI_String *out_result);

/**
 * Function: GetDABSrvCompID
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABSrvCompID(GUI_String *out_result);

/**
 * Function: GetDABSrvCompLabel
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABSrvCompLabel(GUI_String *out_result);

/**
 * Function: GetDABShortSrvCompLabel
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABShortSrvCompLabel(GUI_String *out_result);

/**
 * Function: GetDABTPSupport
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blGetDABTPSupport( void);

/**
 * Function: GetDABTAStatus
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blGetDABTAStatus( void);

/**
 * Function: GetDABDRC
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blGetDABDRC( void);

/**
 * Function: GetDAB_PorS_Info
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blGetDAB_PorS_Info( void);

/**
 * Function: GetDABAudioDataSerComType
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABAudioDataSerComType(GUI_String *out_result);

/**
 * Function: GetDAB_PorD_Flag
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blGetDAB_PorD_Flag( void);

/**
 * Function: GetDABTransportMechanismID
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABTransportMechanismID( void);

/**
 * Function: GetDABAnnoSupport
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABAnnoSupport(GUI_String *out_result);

/**
 * Function: GetDABNumOfAudServices
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABNumOfAudServices( void);

/**
 * Function: GetDABNumOfDataServices
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABNumOfDataServices( void);

/**
 * Function: GetDABNumOfAudSerComp
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABNumOfAudSerComp( void);

/**
 * Function: GetDABNumOfDataSerComp
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABNumOfDataSerComp( void);

/**
 * Function: GetDABTMCSupportStatus
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blGetDABTMCSupportStatus( void);

/**
 * Function: DABEnsembleFrequency
 * 
 * NISSAN
 */
void HSA_System_TestMode__vDABEnsembleFrequency(tbool blDirection);

/**
 * Function: DABChangeService
 * 
 * NISSAN
 */
void HSA_System_TestMode__vDABChangeService(tbool blDirection);

/**
 * Function: GetDABAnnoSwitchMask
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABAnnoSwitchMask(GUI_String *out_result);

/**
 * Function: GetDAB_Database_Scrn_No
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDAB_Database_Scrn_No( void);

/**
 * Function: DAB_DB_Screen
 * 
 * NISSAN
 */
void HSA_System_TestMode__vDAB_DB_Screen(tbool blScreen_ID);

/**
 * Function: DAB_DB_CurrentScreenQuery
 * 
 * NISSAN
 */
void HSA_System_TestMode__vDAB_DB_CurrentScreenQuery( void);

/**
 * Function: GetDABConcealmentLevel
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABConcealmentLevel( void);

/**
 * Function: GetDAB_Database_String
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDAB_Database_String(GUI_String *out_result);

/**
 * Function: SetDABConcealmentLevel
 * 
 * NISSAN
 */
void HSA_System_TestMode__vSetDABConcealmentLevel(tbool blDirection);

/**
 * Function: SetDABSFMode
 * 
 * NISSAN
 */
void HSA_System_TestMode__vSetDABSFMode(ulword ulwServiceLinkingMode);

/**
 * Function: GetDABSFModeSelectionStatus
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABSFModeSelectionStatus( void);

/**
 * Function: GetTASource
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetTASource(GUI_String *out_result);

/**
 * Function: GetDABNumberOfLinks
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABNumberOfLinks( void);

/**
 * Function: GetDABActiveLinkIndex
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABActiveLinkIndex( void);

/**
 * Function: GetDABLinkType
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABLinkType(GUI_String *out_result, ulword ulwIndex);

/**
 * Function: GetDABFrqLabel
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABFrqLabel(GUI_String *out_result, ulword ulwIndex);

/**
 * Function: GetDABSID_PI
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABSID_PI(GUI_String *out_result, ulword ulwIndex);

/**
 * Function: GetDABQuality
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABQuality(ulword ulwIndex);

/**
 * Function: GetDABEID
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetDABEID(GUI_String *out_result, ulword ulwIndex);

/**
 * Function: GetCountry
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetCountry( void);

/**
 * Function: GetGender
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetGender( void);

/**
 * Function: BTDevDeviceAdress
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevDeviceAdress(GUI_String *out_result);

/**
 * Function: BTDevPIMOperationStatus
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevPIMOperationStatus(GUI_String *out_result);

/**
 * Function: BTDevHfpAgSupportedFeatures
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevHfpAgSupportedFeatures(GUI_String *out_result);

/**
 * Function: BTDevPhonebookEntriesCount
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevPhonebookEntriesCount(GUI_String *out_result, ulword ulwPhonebookType);

/**
 * Function: BTDevAvpPlayStatus
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwBTDevAvpPlayStatus( void);

/**
 * Function: BTDevAvpSupportedPlayerStatus
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevAvpSupportedPlayerStatus(GUI_String *out_result);

/**
 * Function: BTDevSMSSupportedFeatures
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevSMSSupportedFeatures(GUI_String *out_result);

/**
 * Function: BTDevSMSDeviceSystemStatus
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevSMSDeviceSystemStatus(GUI_String *out_result);

/**
 * Function: BTDevSMSSupportedNotification
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevSMSSupportedNotification(GUI_String *out_result);

/**
 * Function: BTDevEnabledServices
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blBTDevEnabledServices(ulword ulwBTService);

/**
 * Function: BTDevConnectedServices
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blBTDevConnectedServices(ulword ulwBTService);

/**
 * Function: GetTelephoneMicrophoneConnectionValue
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetTelephoneMicrophoneConnectionValue(GUI_String *out_result);

/**
 * Function: BTDevAudioCodecUsed
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwBTDevAudioCodecUsed( void);

/**
 * Function: ServiceModeEntry
 * 
 * NISSAN
 */
void HSA_System_TestMode__vServiceModeEntry( void);

/**
 * Function: ServiceModeExit
 * 
 * NISSAN
 */
void HSA_System_TestMode__vServiceModeExit( void);

/**
 * Function: GetMFLKeyPressed
 * NISSAN
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetMFLKeyPressed( void);

/**
 * Function: GetTunerAntennaOne
 * NISSAN
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerAntennaOne( void);

/**
 * Function: GetSrvTroubleCodeListElement
 * NISSAN
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetSrvTroubleCodeListElement(ulword ulwIndex);

/**
 * Function: GetUsbDeviceSrvStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetUsbDeviceSrvStatus( void);

/**
 * Function: GetUsbDeviceSrvID
 * NISSAN
 * NISSAN
 */
void HSA_System_TestMode__vGetUsbDeviceSrvID(GUI_String *out_result);

/**
 * Function: GetSrvSystemStatus
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetSrvSystemStatus(ulword ulwSystemStatus);

/**
 * Function: GetSrvUsbDeviceStatus
 * NISSAN
 * NISSAN
 */
void HSA_System_TestMode__vGetSrvUsbDeviceStatus(GUI_String *out_result);

/**
 * Function: GetExtPhoneSignalState
 * NISSAN NAR
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetExtPhoneSignalState( void);

/**
 * Function: GetTelephoneMicrophoneConnectionStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTelephoneMicrophoneConnectionStatus( void);

/**
 * Function: GetIpodFirmwareVersion
 * NISSAN
 * NISSAN
 */
void HSA_System_TestMode__vGetIpodFirmwareVersion(GUI_String *out_result);

/**
 * Function: GetSystemStatus
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetSystemStatus(GUI_String *out_result, ulword ulwSystemStatus);

/**
 * Function: GetTroubleCodeListCount
 * NISSAN
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTroubleCodeListCount( void);

/**
 * Function: ClearTroubleCodeList
 * NISSAN
 * NISSAN
 */
void HSA_System_TestMode__vClearTroubleCodeList( void);

/**
 * Function: GetTroubleCodeListElement
 * NISSAN
 * NISSAN
 */
void HSA_System_TestMode__vGetTroubleCodeListElement(GUI_String *out_result, ulword ulwIndex);

/**
 * Function: GetBTModuleMode
 * NISSAN
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetBTModuleMode( void);

/**
 * Function: SetBTModuleMode
 * NISSAN
 * NISSAN
 */
void HSA_System_TestMode__vSetBTModuleMode(ulword ulwBTModuleMode);

/**
 * Function: BTModuleStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_System_TestMode__ulwBTModuleStatus( void);

/**
 * Function: GetSystemVoltage
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetSystemVoltage(GUI_String *out_result);

/**
 * Function: GetCDDriveStatus
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetCDDriveStatus( void);

/**
 * Function: GetUSBMemoryFree
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetUSBMemoryFree(GUI_String *out_result);

/**
 * Function: GetUSBMemoryTotal
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetUSBMemoryTotal(GUI_String *out_result);

/**
 * Function: GetUSBMediaStatus
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetUSBMediaStatus( void);

/**
 * Function: GetBTLinkQuality
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetBTLinkQuality( void);

/**
 * Function: GetBTRSSI
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetBTRSSI( void);

/**
 * Function: GetFGSHWVersion
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetFGSHWVersion(GUI_String *out_result);

/**
 * Function: GetArionPlatformVersion
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetArionPlatformVersion(GUI_String *out_result);

/**
 * Function: GetBTApplVersionDate
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetBTApplVersionDate(GUI_String *out_result);

/**
 * Function: GetBTApplMsgCatalogVersion
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetBTApplMsgCatalogVersion(GUI_String *out_result);

/**
 * Function: GetBTApplInterfaceVersion
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetBTApplInterfaceVersion(GUI_String *out_result);

/**
 * Function: GetTemperatureAmplifier
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetTemperatureAmplifier(GUI_String *out_result);

/**
 * Function: ClearErrorStore
 * B
 * NISSAN
 */
void HSA_System_TestMode__vClearErrorStore( void);

/**
 * Function: ClearResetCounterValues
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vClearResetCounterValues( void);

/**
 * Function: DecreaseDABFader
 * Plus
 * NISSAN
 */
void HSA_System_TestMode__vDecreaseDABFader(ulword ulwFader);

/**
 * Function: GetActiveTuner
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetActiveTuner( void);

/**
 * Function: GetAF
 * B1
 * NISSAN
 */
tbool HSA_System_TestMode__blGetAF( void);

/**
 * Function: GetAngle
 * B2
 * NISSAN
 */
void HSA_System_TestMode__vGetAngle(GUI_String *out_result);

/**
 * Function: GetBestSatellite
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetBestSatellite(ulword ulwSatellite);

/**
 * Function: GetCANAnalogMute
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetCANAnalogMute(GUI_String *out_result);

/**
 * Function: GetCANKL15
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetCANKL15(GUI_String *out_result);

/**
 * Function: GetCANKL58D
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetCANKL58D(GUI_String *out_result);

/**
 * Function: GetCANMuteBit
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetCANMuteBit(GUI_String *out_result);

/**
 * Function: GetCANMuteValue
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetCANMuteValue(GUI_String *out_result);

/**
 * Function: GetCANReverseGear
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetCANReverseGear(GUI_String *out_result);

/**
 * Function: GetCANSKontakt
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetCANSKontakt(GUI_String *out_result);

/**
 * Function: GetCANSpeedSignal
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetCANSpeedSignal(GUI_String *out_result);

/**
 * Function: GetCogCount
 * B
 * NISSAN
 */
void HSA_System_TestMode__vGetCogCount(GUI_String *out_result);

/**
 * Function: GetCurrentDABFader
 * Plus
 * NISSAN
 */
slword HSA_System_TestMode__slwGetCurrentDABFader(ulword ulwFader);

/**
 * Function: GetDABConcealmentLevelValue
 * B2Plus
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABConcealmentLevelValue( void);

/**
 * Function: GetDABFM_LINK_Frequency
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABFM_LINK_Frequency(GUI_String *out_result);

/**
 * Function: GetDABFM_Link_PI
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABFM_Link_PI(GUI_String *out_result);

/**
 * Function: GetDABFM_Link_Quality
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABFM_Link_Quality(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueAC
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueAC(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueAS
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueAS(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueASU
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueASU(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueASW
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueASW(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueAudioQuality
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueAudioQuality(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueAudioSamplingRate
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueAudioSamplingRate(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueBER
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueBER(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueBitrate
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueBitrate(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueChannel
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueChannel(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueComponenShorttLabel
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueComponenShorttLabel(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueComponentID
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueComponentID(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueComponentLabel
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueComponentLabel(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueDABMode
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueDABMode(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueDRC
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueDRC(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueEnsembleID
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueEnsembleID(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueEnsembleLabel
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueEnsembleLabel(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueEnsembleShortLabel
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueEnsembleShortLabel(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueFieldStrength
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueFieldStrength(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueMode
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueMode(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueMSC
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueMSC(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueMute
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueMute(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueProtectionLevel
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueProtectionLevel(GUI_String *out_result);

/**
 * Function: GetDABMonitorValuePTY
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValuePTY(GUI_String *out_result);

/**
 * Function: GetDABMonitorValues
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValues(GUI_String *out_result, ulword uwArrayIndex);

/**
 * Function: GetDABMonitorValueSCID
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueSCID(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueServiceFollowing
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueServiceFollowing(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueServiceID
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueServiceID(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueServiceLabel
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueServiceLabel(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueServiceSF
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueServiceSF(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueServiceShortLabel
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueServiceShortLabel(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueStereoMode
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueStereoMode(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueSync
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueSync(GUI_String *out_result);

/**
 * Function: GetDABMonitorValueTMC
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABMonitorValueTMC(GUI_String *out_result);

/**
 * Function: GetDABReceptionValue
 * B2Plus
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABReceptionValue( void);

/**
 * Function: GetDABServiceLinking_Count
 * B
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABServiceLinking_Count( void);

/**
 * Function: GetDABServiceLinkingFreqLabel
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABServiceLinkingFreqLabel(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetDABServiceLinkingLinktype
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABServiceLinkingLinktype(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetDABServiceLinkingPI
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABServiceLinkingPI(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetDABServiceLinkingQuality
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABServiceLinkingQuality(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetDABServiceLinkingValue
 * B2Plus
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetDABServiceLinkingValue( void);

/**
 * Function: GetDABTP_Frequency
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABTP_Frequency(GUI_String *out_result);

/**
 * Function: GetDABTP_PI
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABTP_PI(GUI_String *out_result);

/**
 * Function: GetDABTP_Quality
 * B2Plus
 * NISSAN
 */
void HSA_System_TestMode__vGetDABTP_Quality(GUI_String *out_result);

/**
 * Function: GetDeadReckoningValues
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetDeadReckoningValues(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetFreezeBackgroundTuner
 * B1
 * NISSAN
 */
tbool HSA_System_TestMode__blGetFreezeBackgroundTuner( void);

/**
 * Function: GetDDAStatus
 * B1
 * NISSAN
 */
tbool HSA_System_TestMode__blGetDDAStatus( void);

/**
 * Function: GetGPSValues
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetGPSValues(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetLinearAudio
 * B1
 * NISSAN
 */
tbool HSA_System_TestMode__blGetLinearAudio( void);

/**
 * Function: GetMapInfoValues
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetMapInfoValues(GUI_String *out_result, ulword ulwMedium);

/**
 * Function: GetMatchedPositionValues
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetMatchedPositionValues(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetMediaStatus
 * B
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetMediaStatus(ulword ulwDrive);

/**
 * Function: GetOdometerDataUpdate
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetOdometerDataUpdate(tbool blOdometerData);

/**
 * Function: GetResetCounterValue
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetResetCounterValue(GUI_String *out_result, ulword ulwCounter);

/**
 * Function: GetSDTrace
 * B
 * NISSAN
 */
tbool HSA_System_TestMode__blGetSDTrace( void);

/**
 * Function: GetServiceModeFieldStrength
 * B2
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetServiceModeFieldStrength(ulword ulwType);

/**
 * Function: GetServiceModeQualityIndicatorValue
 * B2
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetServiceModeQualityIndicatorValue( void);

/**
 * Function: GetServiceModeQualityString
 * B2
 * NISSAN
 */
void HSA_System_TestMode__vGetServiceModeQualityString(GUI_String *out_result, ulword ulwType);

/**
 * Function: GetSetupHighcut
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetSetupHighcut( void);

/**
 * Function: GetSetupSharx
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetSetupSharx( void);

/**
 * Function: GetTemperatureDisplay
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTemperatureDisplay(GUI_String *out_result);

/**
 * Function: GetTemperatureGPS
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTemperatureGPS(GUI_String *out_result);

/**
 * Function: GetTMCLastMsgTimeDate
 * B
 * NISSAN
 */
void HSA_System_TestMode__vGetTMCLastMsgTimeDate(GUI_String *out_result);

/**
 * Function: GetTMCNoOfMsgs
 * B
 * NISSAN
 */
void HSA_System_TestMode__vGetTMCNoOfMsgs(GUI_String *out_result);

/**
 * Function: GetTMCNoOfMsgsSelectionArea
 * B
 * NISSAN
 */
void HSA_System_TestMode__vGetTMCNoOfMsgsSelectionArea(GUI_String *out_result);

/**
 * Function: GetTMCStation
 * B
 * NISSAN
 */
void HSA_System_TestMode__vGetTMCStation(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetTMCStation_Count
 * B
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTMCStation_Count( void);

/**
 * Function: GetTMCStationCountryCode
 * B2
 * NISSAN
 */
void HSA_System_TestMode__vGetTMCStationCountryCode(GUI_String *out_result);

/**
 * Function: GetTMCStationLTN
 * B2
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTMCStationLTN( void);

/**
 * Function: GetTMCStationPI
 * B2
 * NISSAN
 */
void HSA_System_TestMode__vGetTMCStationPI(GUI_String *out_result);

/**
 * Function: GetTMCStationPS
 * B2
 * NISSAN
 */
void HSA_System_TestMode__vGetTMCStationPS(GUI_String *out_result);

/**
 * Function: GetTMCStationQuality
 * B2
 * NISSAN
 */
void HSA_System_TestMode__vGetTMCStationQuality(GUI_String *out_result);

/**
 * Function: GetTMCStationSID
 * B2
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTMCStationSID( void);

/**
 * Function: GetTunerAF
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerAF(ulword ulwTuner);

/**
 * Function: GetTunerAFListCount
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerAFListCount(ulword ulwTuner);

/**
 * Function: GetTunerAFListIndex
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerAFListIndex(GUI_String *out_result, ulword ulwIndex);

/**
 * Function: GetTunerAntenna1
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerAntenna1(GUI_String *out_result, ulword ulwTuner);

/**
 * Function: GetTunerAntenna2
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerAntenna2(GUI_String *out_result, ulword ulwTuner);

/**
 * Function: GetTunerBER
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerBER(ulword ulwTuner);

/**
 * Function: GetTunerFrequency
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerFrequency(GUI_String *out_result, ulword ulwTuner);

/**
 * Function: GetTunerFrequencyUnit
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerFrequencyUnit(GUI_String *out_result, ulword ulwTuner);

/**
 * Function: GetTunerFS
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerFS(ulword ulwTuner);

/**
 * Function: GetTunerCalData
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerCalData(GUI_String *out_result, ulword ulwCalibration);

/**
 * Function: ExitAFList
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vExitAFList( void);

/**
 * Function: GetTunerHC
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerHC(ulword ulwTuner);

/**
 * Function: GetTunerHUB
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerHUB(GUI_String *out_result, ulword ulwTuner);

/**
 * Function: GetTunerMode
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerMode( void);

/**
 * Function: GetTunerModeSetup
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerModeSetup( void);

/**
 * Function: GetTunerMultiPath
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerMultiPath(GUI_String *out_result, ulword ulwTuner);

/**
 * Function: GetActiveBand
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetActiveBand(ulword ulwTuner);

/**
 * Function: SetActiveBand
 * 
 * NISSAN
 */
void HSA_System_TestMode__vSetActiveBand(ulword ulwBand);

/**
 * Function: GetTunerNeighbourChannel
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerNeighbourChannel(GUI_String *out_result, ulword ulwTuner);

/**
 * Function: GetTunerMeasureMode
 * B1
 * NISSAN
 */
tbool HSA_System_TestMode__blGetTunerMeasureMode( void);

/**
 * Function: GetTunerRDSReg
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blGetTunerRDSReg( void);

/**
 * Function: GetTunerPI
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerPI(GUI_String *out_result, ulword ulwTuner);

/**
 * Function: GetTunerPS
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerPS(GUI_String *out_result, ulword ulwTuner);

/**
 * Function: IsHDRadioActive
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blIsHDRadioActive(ulword ulwTuner);

/**
 * Function: GetTunerCallSign
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerCallSign(GUI_String *out_result, ulword ulwTuner);

/**
 * Function: GetTunerCDNo
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerCDNo(ulword ulwTuner);

/**
 * Function: GetTunerHDStationID
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerHDStationID(ulword ulwTuner);

/**
 * Function: GetTunerRDSErrorRate
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerRDSErrorRate(ulword ulwTuner);

/**
 * Function: GetTunerRDSErrorRateService
 * B2
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerRDSErrorRateService(ulword ulwTuner);

/**
 * Function: GetTunerSharx
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerSharx(ulword ulwTuner);

/**
 * Function: GetTunerSignalQuality
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerSignalQuality(GUI_String *out_result, ulword ulwTuner);

/**
 * Function: GetTunerCS
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerCS(ulword ulwTuner);

/**
 * Function: GetTASetup
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blGetTASetup( void);

/**
 * Function: ToggleTASetup
 * 
 * NISSAN
 */
void HSA_System_TestMode__vToggleTASetup( void);

/**
 * Function: GetTunerPD
 * 
 * NISSAN
 */
void HSA_System_TestMode__vGetTunerPD(GUI_String *out_result, ulword ulwTuner);

/**
 * Function: ToggleRDSReg
 * 
 * NISSAN
 */
void HSA_System_TestMode__vToggleRDSReg( void);

/**
 * Function: ToggleMeasureMode
 * 
 * NISSAN
 */
void HSA_System_TestMode__vToggleMeasureMode( void);

/**
 * Function: GetTunerTA
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerTA(ulword ulwTuner);

/**
 * Function: GetTunerTP
 * B1
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTunerTP(ulword ulwTuner);

/**
 * Function: GetValidAFItem
 * B
 * NISSAN
 */
void HSA_System_TestMode__vGetValidAFItem(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetValidAFItemCount
 * B
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetValidAFItemCount( void);

/**
 * Function: GetVersion
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vGetVersion(GUI_String *out_result, ulword ulwVersion);

/**
 * Function: BTDevTestToggleECNREngineStatus
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevTestToggleECNREngineStatus( void);

/**
 * Function: BTDevTestGetECNREngineStatus
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blBTDevTestGetECNREngineStatus( void);

/**
 * Function: BTDevTestSetHCIModeStatus
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevTestSetHCIModeStatus(tbool blValue);

/**
 * Function: BTDevTestGetHCIModeStatus
 * 
 * NISSAN
 */
tbool HSA_System_TestMode__blBTDevTestGetHCIModeStatus( void);

/**
 * Function: BTDevTestSetFrequency
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevTestSetFrequency(ulword ulwValue);

/**
 * Function: BTDevTestGetFrequency
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwBTDevTestGetFrequency( void);

/**
 * Function: BTDevTestSetPacketType
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevTestSetPacketType(ulword ulwValue);

/**
 * Function: BTDevTestGetPacketType
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwBTDevTestGetPacketType( void);

/**
 * Function: BTDevTestSetModulationValue
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevTestSetModulationValue(ulword ulwValue);

/**
 * Function: BTDevTestGetModulationValue
 * 
 * NISSAN
 */
ulword HSA_System_TestMode__ulwBTDevTestGetModulationValue( void);

/**
 * Function: BTDevRunTest
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevRunTest(ulword ulwTest);

/**
 * Function: BTDevStopTest
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevStopTest( void);

/**
 * Function: BTDevTestGetTestValues
 * 
 * NISSAN
 */
void HSA_System_TestMode__vBTDevTestGetTestValues(GUI_String *out_result, ulword ulwTestParameter);

/**
 * Function: GetWheel1RPM
 * B2
 * NISSAN
 */
void HSA_System_TestMode__vGetWheel1RPM(GUI_String *out_result);

/**
 * Function: BTDevTestGetLinkKey
 * B2
 * NISSAN
 */
void HSA_System_TestMode__vBTDevTestGetLinkKey(GUI_String *out_result);

/**
 * Function: GetWheel2RPM
 * B2
 * NISSAN
 */
void HSA_System_TestMode__vGetWheel2RPM(GUI_String *out_result);

/**
 * Function: GetWheel3RPM
 * B2
 * NISSAN
 */
void HSA_System_TestMode__vGetWheel3RPM(GUI_String *out_result);

/**
 * Function: GetWheel4RPM
 * B2
 * NISSAN
 */
void HSA_System_TestMode__vGetWheel4RPM(GUI_String *out_result);

/**
 * Function: GetWheelCircumference
 * B
 * NISSAN
 */
void HSA_System_TestMode__vGetWheelCircumference(GUI_String *out_result);

/**
 * Function: IncreaseDABFader
 * Plus
 * NISSAN
 */
void HSA_System_TestMode__vIncreaseDABFader(ulword ulwFader);

/**
 * Function: IsAntenna2Available
 * B1
 * NISSAN
 */
tbool HSA_System_TestMode__blIsAntenna2Available( void);

/**
 * Function: IsDevelopermodeEnabled
 * B1
 * NISSAN
 */
tbool HSA_System_TestMode__blIsDevelopermodeEnabled( void);

/**
 * Function: RestoreDefaultSettings
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vRestoreDefaultSettings( void);

/**
 * Function: SelectTMCStation
 * B
 * NISSAN
 */
void HSA_System_TestMode__vSelectTMCStation(ulword ulwListEntryNr);

/**
 * Function: SetActiveTuner
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vSetActiveTuner(ulword ulwTuner);

/**
 * Function: SetDABConcealmentLevelValue
 * Plus
 * NISSAN
 */
void HSA_System_TestMode__vSetDABConcealmentLevelValue(ulword ulwConcealmentLevelValue);

/**
 * Function: SetDABFaderPosition
 * Plus
 * NISSAN
 */
void HSA_System_TestMode__vSetDABFaderPosition(ulword ulwFader, slword slwValue);

/**
 * Function: SetDABReceptionValue
 * Plus
 * NISSAN
 */
void HSA_System_TestMode__vSetDABReceptionValue(ulword ulwDABReceptionValue);

/**
 * Function: SetDABServiceLinkingValue
 * Plus
 * NISSAN
 */
void HSA_System_TestMode__vSetDABServiceLinkingValue(ulword ulwServiceLinkingValue);

/**
 * Function: SetHighcut
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vSetHighcut(tbool blDirection);

/**
 * Function: SetRadioTestModeActive
 * B
 * NISSAN
 */
void HSA_System_TestMode__vSetRadioTestModeActive(ulword ulwenable);

/**
 * Function: SetSetupSharx
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vSetSetupSharx(tbool blDirection);

/**
 * Function: SetTunerModeSetup
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vSetTunerModeSetup(ulword ulwMode);

/**
 * Function: SetTuneToAF
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vSetTuneToAF(ulword ulwListEntryNr);

/**
 * Function: ToggelLinearAudio
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vToggelLinearAudio( void);

/**
 * Function: ToggleAFValue
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vToggleAFValue( void);

/**
 * Function: ToggleFreezeBackgroundTuner
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vToggleFreezeBackgroundTuner( void);

/**
 * Function: ToggleDDAState
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vToggleDDAState( void);

/**
 * Function: SetRadioTMEnter
 * B1
 * NISSAN
 */
void HSA_System_TestMode__vSetRadioTMEnter( void);

/**
 * Function: ToggleSDTrace
 * B
 * NISSAN
 */
void HSA_System_TestMode__vToggleSDTrace( void);

/**
 * Function: GetCsmEngineering_Count
 * NISSAN LCN NAR NET#2 Sample
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetCsmEngineering_Count( void);

/**
 * Function: StartCsmEngineering
 * NISSAN LCN NAR NET#2 Sample
 * NISSAN
 */
void HSA_System_TestMode__vStartCsmEngineering( void);

/**
 * Function: GetCsmEngineeringData
 * NISSAN LCN NAR NET#2 Sample
 * NISSAN
 */
void HSA_System_TestMode__vGetCsmEngineeringData(GUI_String *out_result, ulword ulwListEntryNumber);

/**
 * Function: CreateScreenShot
 * NISSAN LCN NAR NET#2 Sample
 * NISSAN
 */
void HSA_System_TestMode__vCreateScreenShot( void);

/**
 * Function: GetScreenShotState
 * NISSAN LCN NAR NET#2 Sample
 * NISSAN
 */
tbool HSA_System_TestMode__blGetScreenShotState( void);

/**
 * Function: ToggleScreenShotSetting
 * NISSAN LCN NAR NET#2 Sample
 * NISSAN
 */
void HSA_System_TestMode__vToggleScreenShotSetting( void);

/**
 * Function: GetScreenShotSetting
 * NISSAN LCN NAR NET#2 Sample
 * NISSAN
 */
tbool HSA_System_TestMode__blGetScreenShotSetting( void);

/**
 * Function: ScreenShotResetState
 * NISSAN LCN NAR NET#2 Sample
 * NISSAN
 */
void HSA_System_TestMode__vScreenShotResetState( void);

/**
 * Function: GetSXMServiceDTMMonData
 * NISSAN
 * NISSAN
 */
void HSA_System_TestMode__vGetSXMServiceDTMMonData(GUI_String *out_result, ulword ulwLineNo);

/**
 * Function: ActivateSXMDTM
 * NISSAN
 * NISSAN
 */
void HSA_System_TestMode__vActivateSXMDTM(ulword ulwAction);

/**
 * Function: ClearSXMDTMFunctions
 * NISSAN
 * NISSAN
 */
void HSA_System_TestMode__vClearSXMDTMFunctions(ulword ulwLineNo);

/**
 * Function: ExternalDiagModeState
 * NISSAN
 * NISSAN
 */
tbool HSA_System_TestMode__blExternalDiagModeState( void);

/**
 * Function: ToggleExternalDiagMode
 * NISSAN
 * NISSAN
 */
void HSA_System_TestMode__vToggleExternalDiagMode( void);

/**
 * Function: GetSXMSettingsMenuData
 * NISSAN
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetSXMSettingsMenuData(ulword ulwLineNo);

/**
 * Function: TriggerNavSamplePrompt
 * NISSAN LCN2KAI
 * NISSAN
 */
void HSA_System_TestMode__vTriggerNavSamplePrompt( void);

/**
 * Function: GetSXMRadioID
 * B2
 * NISSAN
 */
void HSA_System_TestMode__vGetSXMRadioID(GUI_String *out_result);

/**
 * Function: StartMethodforUPCLID
 * NISSAN LCN NAR NET#2 Sample
 * NISSAN
 */
void HSA_System_TestMode__vStartMethodforUPCLID( void);

/**
 * Function: WaitSyncforSXMDiag
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_System_TestMode__blWaitSyncforSXMDiag( void);

/**
 * Function: GetSXMSTMDataParam1
 * NISSAN
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetSXMSTMDataParam1(ulword ulwLineNo);

/**
 * Function: GetSXMSTMDataParam2
 * NISSAN
 * NISSAN
 */
void HSA_System_TestMode__vGetSXMSTMDataParam2(GUI_String *out_result, ulword ulwLineNo);

/**
 * Function: GetSxmDTMPopupStatus
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_System_TestMode__blGetSxmDTMPopupStatus( void);

/**
 * Function: GetTouchCordinate
 * NISSAN
 * NISSAN
 */
ulword HSA_System_TestMode__ulwGetTouchCordinate(ulword ulwX_Y_Coordinate, ulword ulwRow);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_System_TestMode_H

