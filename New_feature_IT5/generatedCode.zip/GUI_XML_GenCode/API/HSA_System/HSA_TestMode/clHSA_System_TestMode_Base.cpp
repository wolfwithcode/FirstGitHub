/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_System_TestMode_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_System/HSA_TestMode/clHSA_System_TestMode_Base.h"

clHSA_System_TestMode_Base* clHSA_System_TestMode_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_System_TestMode_Base.cpp.trc.h"
#endif


/**
 * Method: ulwGetTMDataAvailability
  * API for synchronising the testmode data.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetTMDataAvailability( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTMDataAvailability not implemented"));
   return 0;
}

/**
 * Method: vSetDABTestmode
  * API for indicating enter/exit from DAB testmode.
  * 
 */
void clHSA_System_TestMode_Base::vSetDABTestmode(tbool blActive)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blActive);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetDABTestmode not implemented"));
   
}

/**
 * Method: vSetNewScreenDataID
  * API for entering the respective screens.
  * 
 */
void clHSA_System_TestMode_Base::vSetNewScreenDataID(ulword ulwScreen_ID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwScreen_ID);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetNewScreenDataID not implemented"));
   
}

/**
 * Method: vDisplayTestStatus
  * API for Display test command status.
  * 
 */
void clHSA_System_TestMode_Base::vDisplayTestStatus(tbool blDisplayTestSuccess)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blDisplayTestSuccess);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vDisplayTestStatus not implemented"));
   
}

/**
 * Method: vCheckSystemVoltage
  * API for requesting battery voltage from SPM.
  * 
 */
void clHSA_System_TestMode_Base::vCheckSystemVoltage(tbool blAction)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blAction);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vCheckSystemVoltage not implemented"));
   
}

/**
 * Method: vGetDABChannelNumber
  * API for getting the Active Channel number of the current ensemble.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABChannelNumber(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABChannelNumber not implemented"));
   
}

/**
 * Method: vGetDABEnsembleLabel
  * API for getting the full Ensemble Label(16 characters).
  * 
 */
void clHSA_System_TestMode_Base::vGetDABEnsembleLabel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABEnsembleLabel not implemented"));
   
}

/**
 * Method: vGetDABEnsembleID
  * API for getting the Ensemble ID.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABEnsembleID(GUI_String *out_result, ulword ulwDABTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDABTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABEnsembleID not implemented"));
   
}

/**
 * Method: vGetDABServiceID
  * API for getting the Service ID.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABServiceID(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABServiceID not implemented"));
   
}

/**
 * Method: vGetDABFrequencyTable
  * API for getting the Current Frequency Table.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABFrequencyTable(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABFrequencyTable not implemented"));
   
}

/**
 * Method: ulwGetDABEnsembleFrequency
  * API for getting the Current Ensemble Frequency.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABEnsembleFrequency(ulword ulwDABTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDABTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABEnsembleFrequency not implemented"));
   return 0;
}

/**
 * Method: vGetDABServiceLabel
  * API for getting the full Service Label.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABServiceLabel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABServiceLabel not implemented"));
   
}

/**
 * Method: ulwGetDABMSCBER
  * API for getting the MSC Bit Error Rate.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABMSCBER( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABMSCBER not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABFICBER
  * API for getting the FIC Bit Error Rate.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABFICBER(ulword ulwDABTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDABTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABFICBER not implemented"));
   return 0;
}

/**
 * Method: ulwGetDAB_RS_FEC
  * API for Reed Solomon error correction.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDAB_RS_FEC( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDAB_RS_FEC not implemented"));
   return 0;
}

/**
 * Method: vGetDAB_BG_Mode
  * API gives the Mode of Backgroung tuner
  * 
 */
void clHSA_System_TestMode_Base::vGetDAB_BG_Mode(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDAB_BG_Mode not implemented"));
   
}

/**
 * Method: ulwGetDABTMC
  * API for the TMC 
  *  Returns the No of DAB TMC Messages
 */
ulword clHSA_System_TestMode_Base::ulwGetDABTMC( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABTMC not implemented"));
   return 0;
}

/**
 * Method: ulwGetDAB_TPEG
  * API for the TPEG 
  * Returns the No of DAB TMC Messages
 */
ulword clHSA_System_TestMode_Base::ulwGetDAB_TPEG( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDAB_TPEG not implemented"));
   return 0;
}

/**
 * Method: vStartTPEGRequest
  * API to be called on entering the TPEG
  * B
 */
void clHSA_System_TestMode_Base::vStartTPEGRequest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vStartTPEGRequest not implemented"));
   
}

/**
 * Method: vGetDAB_TPEGNew
  * API for indicating enter/exit from DAB testmode.
  * 
 */
void clHSA_System_TestMode_Base::vGetDAB_TPEGNew(GUI_String *out_result, ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDAB_TPEGNew not implemented"));
   
}

/**
 * Method: vGet_TEC
  * API for indicating enter/exit from DAB testmode.
  * 
 */
void clHSA_System_TestMode_Base::vGet_TEC(GUI_String *out_result, ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGet_TEC not implemented"));
   
}

/**
 * Method: vGet_TMC
  * API for indicating enter/exit from DAB testmode.
  * 
 */
void clHSA_System_TestMode_Base::vGet_TMC(GUI_String *out_result, ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGet_TMC not implemented"));
   
}

/**
 * Method: vGetURIData
  * API for indicating enter/exit from DAB testmode.
  * 
 */
void clHSA_System_TestMode_Base::vGetURIData(GUI_String *out_result, ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetURIData not implemented"));
   
}

/**
 * Method: ulwGetTotalACIDperFrame
  * API for indicating enter/exit from DAB testmode.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetTotalACIDperFrame(ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTotalACIDperFrame not implemented"));
   return 0;
}

/**
 * Method: vRequestToURIList
  * Request to get the URI lis
  * 
 */
void clHSA_System_TestMode_Base::vRequestToURIList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vRequestToURIList not implemented"));
   
}

/**
 * Method: ulwGetURIListCount
  * Request to get the URI lis
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetURIListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetURIListCount not implemented"));
   return 0;
}

/**
 * Method: vGetURIList
  * API to get the URI List 
  * Returns the info of URI List
 */
void clHSA_System_TestMode_Base::vGetURIList(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetURIList not implemented"));
   
}

/**
 * Method: vRequestToStreamList
  * Request to get the URI lis
  * 
 */
void clHSA_System_TestMode_Base::vRequestToStreamList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vRequestToStreamList not implemented"));
   
}

/**
 * Method: ulwGetStreamListCount
  * Request to get the URI lis
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetStreamListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetStreamListCount not implemented"));
   return 0;
}

/**
 * Method: vGetStreamList
  * Returns information about the text direction and label icon of POIs
  * B
 */
void clHSA_System_TestMode_Base::vGetStreamList(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwInfo_Type)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInfo_Type);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetStreamList not implemented"));
   
}

/**
 * Method: blGetDAB_TSU_Status
  * API for TSU status
  * 
 */
tbool clHSA_System_TestMode_Base::blGetDAB_TSU_Status( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetDAB_TSU_Status not implemented"));
   return 0;
}

/**
 * Method: blGetDABSwitchingStatus
  * API for the switching status
  * 
 */
tbool clHSA_System_TestMode_Base::blGetDABSwitchingStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetDABSwitchingStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABNumEnsembles_DB
  * API for Number of ensembles in the Database
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABNumEnsembles_DB( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABNumEnsembles_DB not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABNum_TMC_Services
  * API for Number of TMC Services
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABNum_TMC_Services( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABNum_TMC_Services not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABNum_TPEG_Services
  * API for Number of TPEG Services
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABNum_TPEG_Services( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABNum_TPEG_Services not implemented"));
   return 0;
}

/**
 * Method: vGetDABExpertIDValue
  * API to get the exper ID value.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABExpertIDValue(GUI_String *out_result, ulword ulwID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwID);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABExpertIDValue not implemented"));
   
}

/**
 * Method: vGetDABExpertIDInfo
  * API for getting the label/value of the requested ID
  * 
 */
void clHSA_System_TestMode_Base::vGetDABExpertIDInfo(GUI_String *out_result, ulword ulwID, ulword ulwID_Value, tbool blType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwID);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwID_Value);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABExpertIDInfo not implemented"));
   
}

/**
 * Method: ulwGetCurrentDABActivity
  * API for DAB tuner activity status.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetCurrentDABActivity( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetCurrentDABActivity not implemented"));
   return 0;
}

/**
 * Method: slwGetDABFieldStrength
  * API for Field Strength.
  * 
 */
slword clHSA_System_TestMode_Base::slwGetDABFieldStrength( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_System_TestMode::slwGetDABFieldStrength not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABSignalQuality
  * API for Signal Quality.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABSignalQuality( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABSignalQuality not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABAudioQuality
  * API for Audio Quality.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABAudioQuality( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABAudioQuality not implemented"));
   return 0;
}

/**
 * Method: blGetDABSync
  * API for DAB Synchronisation.
  * 
 */
tbool clHSA_System_TestMode_Base::blGetDABSync(ulword ulwDABTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDABTuner);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetDABSync not implemented"));
   return 0;
}

/**
 * Method: vSpellerInitforID
  * API on the entry to the DAB speller screen
  * 
 */
void clHSA_System_TestMode_Base::vSpellerInitforID(ulword ulwID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwID);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSpellerInitforID not implemented"));
   
}

/**
 * Method: vSpellerSetNameInput
  * API on the press of OK button in the speller screen
  * 
 */
void clHSA_System_TestMode_Base::vSpellerSetNameInput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSpellerSetNameInput not implemented"));
   
}

/**
 * Method: vSpellerGetNameInput
  * API to get the string entered in the speller
  * 
 */
void clHSA_System_TestMode_Base::vSpellerGetNameInput(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSpellerGetNameInput not implemented"));
   
}

/**
 * Method: vSpellerCharacterInput
  * Used in the speller to send the character chosen in the widget
  * 
 */
void clHSA_System_TestMode_Base::vSpellerCharacterInput(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSpellerCharacterInput not implemented"));
   
}

/**
 * Method: ulwSpellerGetCursorPos
  * API for getting the current position of speller.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwSpellerGetCursorPos( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwSpellerGetCursorPos not implemented"));
   return 0;
}

/**
 * Method: vSpellerCharacterDelete
  * API for deleting all the characters
  * 
 */
void clHSA_System_TestMode_Base::vSpellerCharacterDelete( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSpellerCharacterDelete not implemented"));
   
}

/**
 * Method: ulwGetTimeInterval
  * API for getting time interval state
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetTimeInterval( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTimeInterval not implemented"));
   return 0;
}

/**
 * Method: vSetTimeInterval
  * API for setting the time interval in STM
  * 
 */
void clHSA_System_TestMode_Base::vSetTimeInterval(ulword ulwInterval)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwInterval);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetTimeInterval not implemented"));
   
}

/**
 * Method: blGetDABMute
  * API for Mute status.
  * 
 */
tbool clHSA_System_TestMode_Base::blGetDABMute( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetDABMute not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABAudioBitRate
  * API for getting Audio Bit rate.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABAudioBitRate( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABAudioBitRate not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABSamplingRate
  * API for getting Audio Sampling rate.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABSamplingRate( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABSamplingRate not implemented"));
   return 0;
}

/**
 * Method: vGetDABStereoMode
  * API for getting Stereo mode.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABStereoMode(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABStereoMode not implemented"));
   
}

/**
 * Method: vGetDABAAC
  * API for getting Advanced Audio Codec.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABAAC(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABAAC not implemented"));
   
}

/**
 * Method: ulwGetDABProtectionLevel
  * API for getting Protection level.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABProtectionLevel( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABProtectionLevel not implemented"));
   return 0;
}

/**
 * Method: vGetDABAudioCodec
  * API for getting Audio Codec.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABAudioCodec(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABAudioCodec not implemented"));
   
}

/**
 * Method: ulwGetDABSourceState
  * API for indicating source.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABSourceState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABSourceState not implemented"));
   return 0;
}

/**
 * Method: vGetDABFMFrq
  * API for getting FM Frequency.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABFMFrq(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABFMFrq not implemented"));
   
}

/**
 * Method: vGetDABFMPI
  * API for getting FM PI code.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABFMPI(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABFMPI not implemented"));
   
}

/**
 * Method: ulwGetDABFMQuality
  * API for getting FM Quality -for use in FM-linking.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABFMQuality( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABFMQuality not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABTransmissionMode
  * API for getting DAB Transmission Mode.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABTransmissionMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABTransmissionMode not implemented"));
   return 0;
}

/**
 * Method: vGetDABShortEnsembleLabel
  * API for getting short ensemble label.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABShortEnsembleLabel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABShortEnsembleLabel not implemented"));
   
}

/**
 * Method: vGetDABShortServiceLabel
  * API for getting short service label.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABShortServiceLabel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABShortServiceLabel not implemented"));
   
}

/**
 * Method: vGetDABSrvCompID
  * API for getting Service Component ID.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABSrvCompID(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABSrvCompID not implemented"));
   
}

/**
 * Method: vGetDABSrvCompLabel
  * API for getting Service Component Label.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABSrvCompLabel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABSrvCompLabel not implemented"));
   
}

/**
 * Method: vGetDABShortSrvCompLabel
  * API for getting short Service Component Label.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABShortSrvCompLabel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABShortSrvCompLabel not implemented"));
   
}

/**
 * Method: blGetDABTPSupport
  * API for getting the TP support of the current service.
  * 
 */
tbool clHSA_System_TestMode_Base::blGetDABTPSupport( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetDABTPSupport not implemented"));
   return 0;
}

/**
 * Method: blGetDABTAStatus
  * API for getting the TA status of the current service.
  * 
 */
tbool clHSA_System_TestMode_Base::blGetDABTAStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetDABTAStatus not implemented"));
   return 0;
}

/**
 * Method: blGetDABDRC
  * API for DRC.
  * 
 */
tbool clHSA_System_TestMode_Base::blGetDABDRC( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetDABDRC not implemented"));
   return 0;
}

/**
 * Method: blGetDAB_PorS_Info
  * API for getting the info if it is a primary/secondary service.
  * 
 */
tbool clHSA_System_TestMode_Base::blGetDAB_PorS_Info( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetDAB_PorS_Info not implemented"));
   return 0;
}

/**
 * Method: vGetDABAudioDataSerComType
  * API for getting component type for the particular service.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABAudioDataSerComType(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABAudioDataSerComType not implemented"));
   
}

/**
 * Method: blGetDAB_PorD_Flag
  * API for getting the info if it is an Audio/Data service type.
  * 
 */
tbool clHSA_System_TestMode_Base::blGetDAB_PorD_Flag( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetDAB_PorD_Flag not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABTransportMechanismID
  * API for getting TMId.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABTransportMechanismID( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABTransportMechanismID not implemented"));
   return 0;
}

/**
 * Method: vGetDABAnnoSupport
  * API for getting the supported announcement bit mask.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABAnnoSupport(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABAnnoSupport not implemented"));
   
}

/**
 * Method: ulwGetDABNumOfAudServices
  * API for getting the number of Audio services in current ensemble.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABNumOfAudServices( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABNumOfAudServices not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABNumOfDataServices
  * API for getting the number of Data services in current ensemble.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABNumOfDataServices( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABNumOfDataServices not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABNumOfAudSerComp
  * API for getting the number of Audio service components.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABNumOfAudSerComp( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABNumOfAudSerComp not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABNumOfDataSerComp
  * API for getting the number of Data service components.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABNumOfDataSerComp( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABNumOfDataSerComp not implemented"));
   return 0;
}

/**
 * Method: blGetDABTMCSupportStatus
  * API for knowing if TMC is supported or not.
  * 
 */
tbool clHSA_System_TestMode_Base::blGetDABTMCSupportStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetDABTMCSupportStatus not implemented"));
   return 0;
}

/**
 * Method: vDABEnsembleFrequency
  * API is to change the DAB ensemble frequency
  * 
 */
void clHSA_System_TestMode_Base::vDABEnsembleFrequency(tbool blDirection)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blDirection);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vDABEnsembleFrequency not implemented"));
   
}

/**
 * Method: vDABChangeService
  * API is to change the DAB Services in testmode
  * 
 */
void clHSA_System_TestMode_Base::vDABChangeService(tbool blDirection)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blDirection);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vDABChangeService not implemented"));
   
}

/**
 * Method: vGetDABAnnoSwitchMask
  * API for getting currently playing announcement types.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABAnnoSwitchMask(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABAnnoSwitchMask not implemented"));
   
}

/**
 * Method: ulwGetDAB_Database_Scrn_No
  * API is used for the get the DAB Database screen no
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDAB_Database_Scrn_No( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDAB_Database_Scrn_No not implemented"));
   return 0;
}

/**
 * Method: vDAB_DB_Screen
  * API called on the entry of the next DAB Database screen
  * 
 */
void clHSA_System_TestMode_Base::vDAB_DB_Screen(tbool blScreen_ID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blScreen_ID);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vDAB_DB_Screen not implemented"));
   
}

/**
 * Method: vDAB_DB_CurrentScreenQuery
  * API to repeat curerent DAB database query
  * 
 */
void clHSA_System_TestMode_Base::vDAB_DB_CurrentScreenQuery( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vDAB_DB_CurrentScreenQuery not implemented"));
   
}

/**
 * Method: ulwGetDABConcealmentLevel
  * API for getting the Concealment Level.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABConcealmentLevel( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABConcealmentLevel not implemented"));
   return 0;
}

/**
 * Method: vGetDAB_Database_String
  * API for getting the data in the DAB Database screen
  * 
 */
void clHSA_System_TestMode_Base::vGetDAB_Database_String(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDAB_Database_String not implemented"));
   
}

/**
 * Method: vSetDABConcealmentLevel
  * API for increasing/decreasing the Concealment Level.
  * 
 */
void clHSA_System_TestMode_Base::vSetDABConcealmentLevel(tbool blDirection)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blDirection);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetDABConcealmentLevel not implemented"));
   
}

/**
 * Method: vSetDABSFMode
  * API for setting the Service Linking mode.
  * 
 */
void clHSA_System_TestMode_Base::vSetDABSFMode(ulword ulwServiceLinkingMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwServiceLinkingMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetDABSFMode not implemented"));
   
}

/**
 * Method: ulwGetDABSFModeSelectionStatus
  * API for getting the status of Service Linking mode selection.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABSFModeSelectionStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABSFModeSelectionStatus not implemented"));
   return 0;
}

/**
 * Method: vGetTASource
  * API for getting the TA Source.
  * 
 */
void clHSA_System_TestMode_Base::vGetTASource(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTASource not implemented"));
   
}

/**
 * Method: ulwGetDABNumberOfLinks
  * API for getting the total number of links.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABNumberOfLinks( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABNumberOfLinks not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABActiveLinkIndex
  * API for getting the index of the active link.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABActiveLinkIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABActiveLinkIndex not implemented"));
   return 0;
}

/**
 * Method: vGetDABLinkType
  * API for service link list.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABLinkType(GUI_String *out_result, ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABLinkType not implemented"));
   
}

/**
 * Method: vGetDABFrqLabel
  * API for service link list.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABFrqLabel(GUI_String *out_result, ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABFrqLabel not implemented"));
   
}

/**
 * Method: vGetDABSID_PI
  * API for service link list.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABSID_PI(GUI_String *out_result, ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABSID_PI not implemented"));
   
}

/**
 * Method: ulwGetDABQuality
  * API for service link list.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetDABQuality(ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABQuality not implemented"));
   return 0;
}

/**
 * Method: vGetDABEID
  * API for service link list.
  * 
 */
void clHSA_System_TestMode_Base::vGetDABEID(GUI_String *out_result, ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABEID not implemented"));
   
}

/**
 * Method: ulwGetCountry
  *  The API is used to get the country information.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetCountry( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetCountry not implemented"));
   return 0;
}

/**
 * Method: ulwGetGender
  *  The API is used to get the gender information in the language screen of DTM.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetGender( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetGender not implemented"));
   return 0;
}

/**
 * Method: vBTDevDeviceAdress
  * Bluetooth module developer value UGZZCBtAddress.
  * 
 */
void clHSA_System_TestMode_Base::vBTDevDeviceAdress(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevDeviceAdress not implemented"));
   
}

/**
 * Method: vBTDevPIMOperationStatus
  * Bluetooth module developer value u16PimOperationStatus
  * 
 */
void clHSA_System_TestMode_Base::vBTDevPIMOperationStatus(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevPIMOperationStatus not implemented"));
   
}

/**
 * Method: vBTDevHfpAgSupportedFeatures
  * Bluetooth module developer value HfpAgSupportedFeatures.
  * 
 */
void clHSA_System_TestMode_Base::vBTDevHfpAgSupportedFeatures(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevHfpAgSupportedFeatures not implemented"));
   
}

/**
 * Method: vBTDevPhonebookEntriesCount
  * Bluetooth module developer value for the two possible phone book sizes
  * 
 */
void clHSA_System_TestMode_Base::vBTDevPhonebookEntriesCount(GUI_String *out_result, ulword ulwPhonebookType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPhonebookType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevPhonebookEntriesCount not implemented"));
   
}

/**
 * Method: ulwBTDevAvpPlayStatus
  * Bluetooth module developer value u8AvpPlayStatus, indicate the working Status of the currently connected media player.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwBTDevAvpPlayStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwBTDevAvpPlayStatus not implemented"));
   return 0;
}

/**
 * Method: vBTDevAvpSupportedPlayerStatus
  * Bluetooth module developer value u16AvpSupportedPlayerStatus.
  * 
 */
void clHSA_System_TestMode_Base::vBTDevAvpSupportedPlayerStatus(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevAvpSupportedPlayerStatus not implemented"));
   
}

/**
 * Method: vBTDevSMSSupportedFeatures
  * Bluetooth module developer value u16SmsSupportedFeatures.
  * 
 */
void clHSA_System_TestMode_Base::vBTDevSMSSupportedFeatures(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevSMSSupportedFeatures not implemented"));
   
}

/**
 * Method: vBTDevSMSDeviceSystemStatus
  * Bluetooth module developer value u8SmsDeviceSystemStatus.
  * 
 */
void clHSA_System_TestMode_Base::vBTDevSMSDeviceSystemStatus(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevSMSDeviceSystemStatus not implemented"));
   
}

/**
 * Method: vBTDevSMSSupportedNotification
  * Bluetooth module developer value u16SmsSupportedNotification.
  * 
 */
void clHSA_System_TestMode_Base::vBTDevSMSSupportedNotification(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevSMSSupportedNotification not implemented"));
   
}

/**
 * Method: blBTDevEnabledServices
  * Bluetooth module developer value to show the available Services
  * 
 */
tbool clHSA_System_TestMode_Base::blBTDevEnabledServices(ulword ulwBTService)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBTService);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blBTDevEnabledServices not implemented"));
   return 0;
}

/**
 * Method: blBTDevConnectedServices
  * Bluetooth module developer value to show the connected Services
  * 
 */
tbool clHSA_System_TestMode_Base::blBTDevConnectedServices(ulword ulwBTService)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBTService);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blBTDevConnectedServices not implemented"));
   return 0;
}

/**
 * Method: vGetTelephoneMicrophoneConnectionValue
  * Indicates the current microphone connection value.
  * 
 */
void clHSA_System_TestMode_Base::vGetTelephoneMicrophoneConnectionValue(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTelephoneMicrophoneConnectionValue not implemented"));
   
}

/**
 * Method: ulwBTDevAudioCodecUsed
  * Bluetooth module developer value for the Audio Codec used.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwBTDevAudioCodecUsed( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwBTDevAudioCodecUsed not implemented"));
   return 0;
}

/**
 * Method: vServiceModeEntry
  * API called when the user enters STM
  * 
 */
void clHSA_System_TestMode_Base::vServiceModeEntry( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vServiceModeEntry not implemented"));
   
}

/**
 * Method: vServiceModeExit
  * API called when the user returns STM
  * 
 */
void clHSA_System_TestMode_Base::vServiceModeExit( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vServiceModeExit not implemented"));
   
}

/**
 * Method: ulwGetMFLKeyPressed
  * Returns the enum value of the MFL key pressed
  * NISSAN
 */
ulword clHSA_System_TestMode_Base::ulwGetMFLKeyPressed( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetMFLKeyPressed not implemented"));
   return 0;
}

/**
 * Method: ulwGetTunerAntennaOne
  * Returns the status of tuner antenna 1
  * NISSAN
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerAntennaOne( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerAntennaOne not implemented"));
   return 0;
}

/**
 * Method: ulwGetSrvTroubleCodeListElement
  * Returns the trouble code value for the given Index
  * NISSAN
 */
ulword clHSA_System_TestMode_Base::ulwGetSrvTroubleCodeListElement(ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetSrvTroubleCodeListElement not implemented"));
   return 0;
}

/**
 * Method: ulwGetUsbDeviceSrvStatus
  * Returns the status of USB
  * NISSAN
 */
ulword clHSA_System_TestMode_Base::ulwGetUsbDeviceSrvStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetUsbDeviceSrvStatus not implemented"));
   return 0;
}

/**
 * Method: vGetUsbDeviceSrvID
  * Returns USB Device ID
  * NISSAN
 */
void clHSA_System_TestMode_Base::vGetUsbDeviceSrvID(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetUsbDeviceSrvID not implemented"));
   
}

/**
 * Method: ulwGetSrvSystemStatus
  * Returns the System status value
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetSrvSystemStatus(ulword ulwSystemStatus)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSystemStatus);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetSrvSystemStatus not implemented"));
   return 0;
}

/**
 * Method: vGetSrvUsbDeviceStatus
  * Returns the status of USB
  * NISSAN
 */
void clHSA_System_TestMode_Base::vGetSrvUsbDeviceStatus(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetSrvUsbDeviceStatus not implemented"));
   
}

/**
 * Method: ulwGetExtPhoneSignalState
  * Returns the state of ext Phone Signal as an integer
  * NISSAN NAR
 */
ulword clHSA_System_TestMode_Base::ulwGetExtPhoneSignalState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetExtPhoneSignalState not implemented"));
   return 0;
}

/**
 * Method: ulwGetTelephoneMicrophoneConnectionStatus
  * Indicates the current microphone connection status.
  * NISSAN
 */
ulword clHSA_System_TestMode_Base::ulwGetTelephoneMicrophoneConnectionStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTelephoneMicrophoneConnectionStatus not implemented"));
   return 0;
}

/**
 * Method: vGetIpodFirmwareVersion
  * Returns the IPOD SW version as string
  * NISSAN
 */
void clHSA_System_TestMode_Base::vGetIpodFirmwareVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetIpodFirmwareVersion not implemented"));
   
}

/**
 * Method: vGetSystemStatus
  * Returns the System Status
  * 
 */
void clHSA_System_TestMode_Base::vGetSystemStatus(GUI_String *out_result, ulword ulwSystemStatus)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSystemStatus);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetSystemStatus not implemented"));
   
}

/**
 * Method: ulwGetTroubleCodeListCount
  * Returns the TroubleCode List count
  * NISSAN
 */
ulword clHSA_System_TestMode_Base::ulwGetTroubleCodeListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTroubleCodeListCount not implemented"));
   return 0;
}

/**
 * Method: vClearTroubleCodeList
  * Clears the Trouble code list
  * NISSAN
 */
void clHSA_System_TestMode_Base::vClearTroubleCodeList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vClearTroubleCodeList not implemented"));
   
}

/**
 * Method: vGetTroubleCodeListElement
  * Returns the trouble code value as string for the given Index
  * NISSAN
 */
void clHSA_System_TestMode_Base::vGetTroubleCodeListElement(GUI_String *out_result, ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTroubleCodeListElement not implemented"));
   
}

/**
 * Method: ulwGetBTModuleMode
  * Returns the BTModule mode
  * NISSAN
 */
ulword clHSA_System_TestMode_Base::ulwGetBTModuleMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetBTModuleMode not implemented"));
   return 0;
}

/**
 * Method: vSetBTModuleMode
  * Set BTModule from Testmode screen
  * NISSAN
 */
void clHSA_System_TestMode_Base::vSetBTModuleMode(ulword ulwBTModuleMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBTModuleMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetBTModuleMode not implemented"));
   
}

/**
 * Method: ulwBTModuleStatus
  * Returns the BTModule status
  * NISSAN
 */
ulword clHSA_System_TestMode_Base::ulwBTModuleStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwBTModuleStatus not implemented"));
   return 0;
}

/**
 * Method: vGetSystemVoltage
  * Returns the Current System Voltage
  * 
 */
void clHSA_System_TestMode_Base::vGetSystemVoltage(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetSystemVoltage not implemented"));
   
}

/**
 * Method: ulwGetCDDriveStatus
  * Returns the status of CD Drive
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetCDDriveStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetCDDriveStatus not implemented"));
   return 0;
}

/**
 * Method: vGetUSBMemoryFree
  * Returns the amount of unused space of USB in MB
  * 
 */
void clHSA_System_TestMode_Base::vGetUSBMemoryFree(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetUSBMemoryFree not implemented"));
   
}

/**
 * Method: vGetUSBMemoryTotal
  * Returns the total size of USB in MB
  * 
 */
void clHSA_System_TestMode_Base::vGetUSBMemoryTotal(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetUSBMemoryTotal not implemented"));
   
}

/**
 * Method: ulwGetUSBMediaStatus
  * Returns the status for USB
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetUSBMediaStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetUSBMediaStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetBTLinkQuality
  * Returns the link quality of BT
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetBTLinkQuality( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetBTLinkQuality not implemented"));
   return 0;
}

/**
 * Method: ulwGetBTRSSI
  * Returns the RSSI of BT
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetBTRSSI( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetBTRSSI not implemented"));
   return 0;
}

/**
 * Method: vGetFGSHWVersion
  * returns the FGS HW Version as string
  * 
 */
void clHSA_System_TestMode_Base::vGetFGSHWVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetFGSHWVersion not implemented"));
   
}

/**
 * Method: vGetArionPlatformVersion
  * returns the Arion Platform Version as string
  * 
 */
void clHSA_System_TestMode_Base::vGetArionPlatformVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetArionPlatformVersion not implemented"));
   
}

/**
 * Method: vGetBTApplVersionDate
  * returns the BT Application Version Date as string
  * 
 */
void clHSA_System_TestMode_Base::vGetBTApplVersionDate(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetBTApplVersionDate not implemented"));
   
}

/**
 * Method: vGetBTApplMsgCatalogVersion
  * returns the BT Application Msg Catalog Version as string
  * 
 */
void clHSA_System_TestMode_Base::vGetBTApplMsgCatalogVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetBTApplMsgCatalogVersion not implemented"));
   
}

/**
 * Method: vGetBTApplInterfaceVersion
  * returns the BT Application Interface Version as string
  * 
 */
void clHSA_System_TestMode_Base::vGetBTApplInterfaceVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetBTApplInterfaceVersion not implemented"));
   
}

/**
 * Method: vGetTemperatureAmplifier
  * Returns the Amplifier Temperature
  * 
 */
void clHSA_System_TestMode_Base::vGetTemperatureAmplifier(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTemperatureAmplifier not implemented"));
   
}

/**
 * Method: vClearErrorStore
  * clears the memory which contains the errorcodes
  * B
 */
void clHSA_System_TestMode_Base::vClearErrorStore( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vClearErrorStore not implemented"));
   
}

/**
 * Method: vClearResetCounterValues
  * Deletes all values about the reset counter
  * B1
 */
void clHSA_System_TestMode_Base::vClearResetCounterValues( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vClearResetCounterValues not implemented"));
   
}

/**
 * Method: vDecreaseDABFader
  * decreases the value of the selected fader until min-range is reached
  * Plus
 */
void clHSA_System_TestMode_Base::vDecreaseDABFader(ulword ulwFader)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwFader);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vDecreaseDABFader not implemented"));
   
}

/**
 * Method: ulwGetActiveTuner
  * Returns the active Tuner
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetActiveTuner( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetActiveTuner not implemented"));
   return 0;
}

/**
 * Method: blGetAF
  * Returns if AF is activated or not.
  * B1
 */
tbool clHSA_System_TestMode_Base::blGetAF( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetAF not implemented"));
   return 0;
}

/**
 * Method: vGetAngle
  * returns the steering wheel angle
  * B2
 */
void clHSA_System_TestMode_Base::vGetAngle(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetAngle not implemented"));
   
}

/**
 * Method: ulwGetBestSatellite
  * Returns an integer for the specified GPS satellite
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetBestSatellite(ulword ulwSatellite)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSatellite);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetBestSatellite not implemented"));
   return 0;
}

/**
 * Method: vGetCANAnalogMute
  * Returns value of Analog Mute
  * B1
 */
void clHSA_System_TestMode_Base::vGetCANAnalogMute(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetCANAnalogMute not implemented"));
   
}

/**
 * Method: vGetCANKL15
  * Returns value of KL15
  * B1
 */
void clHSA_System_TestMode_Base::vGetCANKL15(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetCANKL15 not implemented"));
   
}

/**
 * Method: vGetCANKL58D
  * Returns value of KL 58 d
  * B1
 */
void clHSA_System_TestMode_Base::vGetCANKL58D(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetCANKL58D not implemented"));
   
}

/**
 * Method: vGetCANMuteBit
  * Returns value of Mute Bit
  * B1
 */
void clHSA_System_TestMode_Base::vGetCANMuteBit(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetCANMuteBit not implemented"));
   
}

/**
 * Method: vGetCANMuteValue
  * Returns value of Mute
  * B1
 */
void clHSA_System_TestMode_Base::vGetCANMuteValue(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetCANMuteValue not implemented"));
   
}

/**
 * Method: vGetCANReverseGear
  * Returns value of Reverse Gear
  * B1
 */
void clHSA_System_TestMode_Base::vGetCANReverseGear(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetCANReverseGear not implemented"));
   
}

/**
 * Method: vGetCANSKontakt
  * Returns value of S-Kontakt
  * B1
 */
void clHSA_System_TestMode_Base::vGetCANSKontakt(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetCANSKontakt not implemented"));
   
}

/**
 * Method: vGetCANSpeedSignal
  * Returns value of Speed Signal
  * B1
 */
void clHSA_System_TestMode_Base::vGetCANSpeedSignal(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetCANSpeedSignal not implemented"));
   
}

/**
 * Method: vGetCogCount
  * Returns the cog count
  * B
 */
void clHSA_System_TestMode_Base::vGetCogCount(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetCogCount not implemented"));
   
}

/**
 * Method: slwGetCurrentDABFader
  * Returns values of the selected fader
  * Plus
 */
slword clHSA_System_TestMode_Base::slwGetCurrentDABFader(ulword ulwFader)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwFader);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_System_TestMode::slwGetCurrentDABFader not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABConcealmentLevelValue
  * Returns value of DAB concealment level
  * B2Plus
 */
ulword clHSA_System_TestMode_Base::ulwGetDABConcealmentLevelValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABConcealmentLevelValue not implemented"));
   return 0;
}

/**
 * Method: vGetDABFM_LINK_Frequency
  * Returns the frequency for FM-Link tuner as string including the unit.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABFM_LINK_Frequency(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABFM_LINK_Frequency not implemented"));
   
}

/**
 * Method: vGetDABFM_Link_PI
  * Returns the PI for the FM-Link tuner.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABFM_Link_PI(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABFM_Link_PI not implemented"));
   
}

/**
 * Method: vGetDABFM_Link_Quality
  * Returns thequality for the FM-Link tuner.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABFM_Link_Quality(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABFM_Link_Quality not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueAC
  * Returns the AC value.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueAC(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueAC not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueAS
  * Returns the AS value.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueAS(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueAS not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueASU
  * Returns the ASUvalue.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueASU(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueASU not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueASW
  * Returns the ASW value.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueASW(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueASW not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueAudioQuality
  * Returns the audio quality.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueAudioQuality(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueAudioQuality not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueAudioSamplingRate
  * Returns the audio sampling rate.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueAudioSamplingRate(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueAudioSamplingRate not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueBER
  * Returns the DAB FIC bit error rate.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueBER(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueBER not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueBitrate
  * Returns the DAB audio bit rate.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueBitrate(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueBitrate not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueChannel
  * Returns the DAB channel.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueChannel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueChannel not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueComponenShorttLabel
  * Returns the DAB component short label.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueComponenShorttLabel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueComponenShorttLabel not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueComponentID
  * Returns the DAB component ID.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueComponentID(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueComponentID not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueComponentLabel
  * Returns the DAB component label.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueComponentLabel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueComponentLabel not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueDABMode
  * Returns the DAB mode.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueDABMode(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueDABMode not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueDRC
  * Returns the DRC value.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueDRC(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueDRC not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueEnsembleID
  * Returns the DAB ensemble ID.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueEnsembleID(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueEnsembleID not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueEnsembleLabel
  * Returns the DAB ensemble label.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueEnsembleLabel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueEnsembleLabel not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueEnsembleShortLabel
  * Returns the DAB ensemble short label.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueEnsembleShortLabel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueEnsembleShortLabel not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueFieldStrength
  * Returns the DAB field strength.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueFieldStrength(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueFieldStrength not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueMode
  * Returns the DAB mode.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueMode(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueMode not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueMSC
  * Returns the DAB MSC bit error rate.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueMSC(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueMSC not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueMute
  * Returns whether mute is active or not.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueMute(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueMute not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueProtectionLevel
  * Returns the protection level.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueProtectionLevel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueProtectionLevel not implemented"));
   
}

/**
 * Method: vGetDABMonitorValuePTY
  * Returns the PTY value.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValuePTY(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValuePTY not implemented"));
   
}

/**
 * Method: vGetDABMonitorValues
  * Deprecated and was splitted up into seperated calls with naming GetDABMonitorValue...
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValues(GUI_String *out_result, ulword uwArrayIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(uwArrayIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValues not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueSCID
  * Returns the SCID value.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueSCID(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueSCID not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueServiceFollowing
  * Returns whether service following is active or not.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueServiceFollowing(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueServiceFollowing not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueServiceID
  * Returns the DAB service ID.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueServiceID(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueServiceID not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueServiceLabel
  * Returns the DAB service label.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueServiceLabel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueServiceLabel not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueServiceSF
  * Returns the DAB service following status.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueServiceSF(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueServiceSF not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueServiceShortLabel
  * Returns the DAB service short label.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueServiceShortLabel(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueServiceShortLabel not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueStereoMode
  * Returns the active stereo mode.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueStereoMode(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueStereoMode not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueSync
  * Returns the sync state
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueSync(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueSync not implemented"));
   
}

/**
 * Method: vGetDABMonitorValueTMC
  * Returns whether or not TMC is supported or not.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABMonitorValueTMC(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABMonitorValueTMC not implemented"));
   
}

/**
 * Method: ulwGetDABReceptionValue
  * Returns value of DAB-Reception
  * B2Plus
 */
ulword clHSA_System_TestMode_Base::ulwGetDABReceptionValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABReceptionValue not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABServiceLinking_Count
  * returns the number of service linking items
  * B
 */
ulword clHSA_System_TestMode_Base::ulwGetDABServiceLinking_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABServiceLinking_Count not implemented"));
   return 0;
}

/**
 * Method: vGetDABServiceLinkingFreqLabel
  * Return the frequency label for specified row.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABServiceLinkingFreqLabel(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABServiceLinkingFreqLabel not implemented"));
   
}

/**
 * Method: vGetDABServiceLinkingLinktype
  * Return the link type for specified row.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABServiceLinkingLinktype(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABServiceLinkingLinktype not implemented"));
   
}

/**
 * Method: vGetDABServiceLinkingPI
  * Return the PI for specified row.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABServiceLinkingPI(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABServiceLinkingPI not implemented"));
   
}

/**
 * Method: vGetDABServiceLinkingQuality
  * Return the quality for specified row.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABServiceLinkingQuality(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABServiceLinkingQuality not implemented"));
   
}

/**
 * Method: ulwGetDABServiceLinkingValue
  * Returns value of DAB-Service-Linking (on/off)
  * B2Plus
 */
ulword clHSA_System_TestMode_Base::ulwGetDABServiceLinkingValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetDABServiceLinkingValue not implemented"));
   return 0;
}

/**
 * Method: vGetDABTP_Frequency
  * Returns the frequency of the TP tuner.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABTP_Frequency(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABTP_Frequency not implemented"));
   
}

/**
 * Method: vGetDABTP_PI
  * Returns the PI of the TP tuner.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABTP_PI(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABTP_PI not implemented"));
   
}

/**
 * Method: vGetDABTP_Quality
  * Returns the qualityof the TP tuner.
  * B2Plus
 */
void clHSA_System_TestMode_Base::vGetDABTP_Quality(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDABTP_Quality not implemented"));
   
}

/**
 * Method: vGetDeadReckoningValues
  * Returns values about the dead reckoning
  * B1
 */
void clHSA_System_TestMode_Base::vGetDeadReckoningValues(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetDeadReckoningValues not implemented"));
   
}

/**
 * Method: blGetFreezeBackgroundTuner
  * Returns if Freeze Backgroung Tuner is activated
  * B1
 */
tbool clHSA_System_TestMode_Base::blGetFreezeBackgroundTuner( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetFreezeBackgroundTuner not implemented"));
   return 0;
}

/**
 * Method: blGetDDAStatus
  * Returns if DDA is On/Off
  * B1
 */
tbool clHSA_System_TestMode_Base::blGetDDAStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetDDAStatus not implemented"));
   return 0;
}

/**
 * Method: vGetGPSValues
  * Returns values about the GPS
  * B1
 */
void clHSA_System_TestMode_Base::vGetGPSValues(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetGPSValues not implemented"));
   
}

/**
 * Method: blGetLinearAudio
  * Returns wether or not Linear Audio is activated or not. Requested by BP
  * B1
 */
tbool clHSA_System_TestMode_Base::blGetLinearAudio( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetLinearAudio not implemented"));
   return 0;
}

/**
 * Method: vGetMapInfoValues
  * Returns values for the map info of CD or SD
  * B1
 */
void clHSA_System_TestMode_Base::vGetMapInfoValues(GUI_String *out_result, ulword ulwMedium)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMedium);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetMapInfoValues not implemented"));
   
}

/**
 * Method: vGetMatchedPositionValues
  * Returns values about the matched position
  * B1
 */
void clHSA_System_TestMode_Base::vGetMatchedPositionValues(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetMatchedPositionValues not implemented"));
   
}

/**
 * Method: ulwGetMediaStatus
  * Returns the status for the CD or SD drive
  * B
 */
ulword clHSA_System_TestMode_Base::ulwGetMediaStatus(ulword ulwDrive)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDrive);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetMediaStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetOdometerDataUpdate
  * Returns the value for Odometer status and Odometer pulse counter
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetOdometerDataUpdate(tbool blOdometerData)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blOdometerData);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetOdometerDataUpdate not implemented"));
   return 0;
}

/**
 * Method: vGetResetCounterValue
  * Returns the value for the given reset counter
  * B1
 */
void clHSA_System_TestMode_Base::vGetResetCounterValue(GUI_String *out_result, ulword ulwCounter)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCounter);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetResetCounterValue not implemented"));
   
}

/**
 * Method: blGetSDTrace
  * Returns if SD Trace is activated or not.
  * B
 */
tbool clHSA_System_TestMode_Base::blGetSDTrace( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetSDTrace not implemented"));
   return 0;
}

/**
 * Method: ulwGetServiceModeFieldStrength
  * Returns the field strength for the servicemode
  * B2
 */
ulword clHSA_System_TestMode_Base::ulwGetServiceModeFieldStrength(ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetServiceModeFieldStrength not implemented"));
   return 0;
}

/**
 * Method: ulwGetServiceModeQualityIndicatorValue
  * Returns the current progressbar value of the quality indicator for servicemode iboc
  * B2
 */
ulword clHSA_System_TestMode_Base::ulwGetServiceModeQualityIndicatorValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetServiceModeQualityIndicatorValue not implemented"));
   return 0;
}

/**
 * Method: vGetServiceModeQualityString
  * Returns the service quality as string
  * B2
 */
void clHSA_System_TestMode_Base::vGetServiceModeQualityString(GUI_String *out_result, ulword ulwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetServiceModeQualityString not implemented"));
   
}

/**
 * Method: ulwGetSetupHighcut
  * Returns currently selected highcut in radio setup 
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetSetupHighcut( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetSetupHighcut not implemented"));
   return 0;
}

/**
 * Method: ulwGetSetupSharx
  * Returns current sharx value for setup
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetSetupSharx( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetSetupSharx not implemented"));
   return 0;
}

/**
 * Method: vGetTemperatureDisplay
  * Returns the Display Temperature
  * B1
 */
void clHSA_System_TestMode_Base::vGetTemperatureDisplay(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTemperatureDisplay not implemented"));
   
}

/**
 * Method: vGetTemperatureGPS
  * Returns the GPS Temperature
  * B1
 */
void clHSA_System_TestMode_Base::vGetTemperatureGPS(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTemperatureGPS not implemented"));
   
}

/**
 * Method: vGetTMCLastMsgTimeDate
  * Returns the time and date of the last TMC message
  * B
 */
void clHSA_System_TestMode_Base::vGetTMCLastMsgTimeDate(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTMCLastMsgTimeDate not implemented"));
   
}

/**
 * Method: vGetTMCNoOfMsgs
  * Returns the number of TMC messages
  * B
 */
void clHSA_System_TestMode_Base::vGetTMCNoOfMsgs(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTMCNoOfMsgs not implemented"));
   
}

/**
 * Method: vGetTMCNoOfMsgsSelectionArea
  * Returns the number of TMC messages in selection area
  * B
 */
void clHSA_System_TestMode_Base::vGetTMCNoOfMsgsSelectionArea(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTMCNoOfMsgsSelectionArea not implemented"));
   
}

/**
 * Method: vGetTMCStation
  * returns information about the station with the given index of a list that contains only stations which are supporting TMC
  * B
 */
void clHSA_System_TestMode_Base::vGetTMCStation(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTMCStation not implemented"));
   
}

/**
 * Method: ulwGetTMCStation_Count
  * returns the number of stations in the TMC list
  * B
 */
ulword clHSA_System_TestMode_Base::ulwGetTMCStation_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTMCStation_Count not implemented"));
   return 0;
}

/**
 * Method: vGetTMCStationCountryCode
  * returns the Country Code of the active TMC station
  * B2
 */
void clHSA_System_TestMode_Base::vGetTMCStationCountryCode(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTMCStationCountryCode not implemented"));
   
}

/**
 * Method: ulwGetTMCStationLTN
  * returns the Localtion Table Number for the active TMC station
  * B2
 */
ulword clHSA_System_TestMode_Base::ulwGetTMCStationLTN( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTMCStationLTN not implemented"));
   return 0;
}

/**
 * Method: vGetTMCStationPI
  * returns the Program Identifier Name of the active TMC station
  * B2
 */
void clHSA_System_TestMode_Base::vGetTMCStationPI(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTMCStationPI not implemented"));
   
}

/**
 * Method: vGetTMCStationPS
  * returns the PS Name of the current TMC station
  * B2
 */
void clHSA_System_TestMode_Base::vGetTMCStationPS(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTMCStationPS not implemented"));
   
}

/**
 * Method: vGetTMCStationQuality
  * returns the Quality of the active TMC station
  * B2
 */
void clHSA_System_TestMode_Base::vGetTMCStationQuality(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTMCStationQuality not implemented"));
   
}

/**
 * Method: ulwGetTMCStationSID
  * returns the Service ID for the active TMC station
  * B2
 */
ulword clHSA_System_TestMode_Base::ulwGetTMCStationSID( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTMCStationSID not implemented"));
   return 0;
}

/**
 * Method: ulwGetTunerAF
  * Return current AF
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerAF(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerAF not implemented"));
   return 0;
}

/**
 * Method: ulwGetTunerAFListCount
  * Returns the number elements in the AF list. GetTunerAF was splitted into two calls.
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerAFListCount(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerAFListCount not implemented"));
   return 0;
}

/**
 * Method: vGetTunerAFListIndex
  * Returns the item with the given index. GetTunerAF was splitted into two calls.
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerAFListIndex(GUI_String *out_result, ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerAFListIndex not implemented"));
   
}

/**
 * Method: vGetTunerAntenna1
  * Returns tuner antenna 1
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerAntenna1(GUI_String *out_result, ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerAntenna1 not implemented"));
   
}

/**
 * Method: vGetTunerAntenna2
  * Returns tuner antenna 2
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerAntenna2(GUI_String *out_result, ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerAntenna2 not implemented"));
   
}

/**
 * Method: ulwGetTunerBER
  * Return current BER
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerBER(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerBER not implemented"));
   return 0;
}

/**
 * Method: vGetTunerFrequency
  * Returns the frequency of specified tuner as a formatted string (FMT_FREQUENCY)
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerFrequency(GUI_String *out_result, ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerFrequency not implemented"));
   
}

/**
 * Method: vGetTunerFrequencyUnit
  * Returns unit for frequency of tuner
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerFrequencyUnit(GUI_String *out_result, ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerFrequencyUnit not implemented"));
   
}

/**
 * Method: ulwGetTunerFS
  * Returns the Field Strength for the requested tuner
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerFS(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerFS not implemented"));
   return 0;
}

/**
 * Method: vGetTunerCalData
  * Returns the calibration data
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerCalData(GUI_String *out_result, ulword ulwCalibration)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCalibration);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerCalData not implemented"));
   
}

/**
 * Method: vExitAFList
  * Called at the exit of the AF List
  * B1
 */
void clHSA_System_TestMode_Base::vExitAFList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vExitAFList not implemented"));
   
}

/**
 * Method: ulwGetTunerHC
  * Returns High Cut for the requested tuner
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerHC(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerHC not implemented"));
   return 0;
}

/**
 * Method: vGetTunerHUB
  * Returns HUB value of the requested tuner
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerHUB(GUI_String *out_result, ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerHUB not implemented"));
   
}

/**
 * Method: ulwGetTunerMode
  * Returns Tuner Mode
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerMode not implemented"));
   return 0;
}

/**
 * Method: ulwGetTunerModeSetup
  * Returns current Tuner Mode for Radio Setup
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerModeSetup( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerModeSetup not implemented"));
   return 0;
}

/**
 * Method: vGetTunerMultiPath
  * Returns Multipath value for the requested tuner
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerMultiPath(GUI_String *out_result, ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerMultiPath not implemented"));
   
}

/**
 * Method: ulwGetActiveBand
  * Return active band in the specified tuner
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetActiveBand(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetActiveBand not implemented"));
   return 0;
}

/**
 * Method: vSetActiveBand
  * Sets active band in the active tuner
  * 
 */
void clHSA_System_TestMode_Base::vSetActiveBand(ulword ulwBand)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBand);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetActiveBand not implemented"));
   
}

/**
 * Method: vGetTunerNeighbourChannel
  * ReturnsNeighbourChannel
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerNeighbourChannel(GUI_String *out_result, ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerNeighbourChannel not implemented"));
   
}

/**
 * Method: blGetTunerMeasureMode
  * returns the measure mode of the requested tuner
  * B1
 */
tbool clHSA_System_TestMode_Base::blGetTunerMeasureMode( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetTunerMeasureMode not implemented"));
   return 0;
}

/**
 * Method: blGetTunerRDSReg
  * returns the RDS Reg of the requested tuner
  * 
 */
tbool clHSA_System_TestMode_Base::blGetTunerRDSReg( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetTunerRDSReg not implemented"));
   return 0;
}

/**
 * Method: vGetTunerPI
  * Returns PI value for the requested tuner
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerPI(GUI_String *out_result, ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerPI not implemented"));
   
}

/**
 * Method: vGetTunerPS
  * Return current PS
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerPS(GUI_String *out_result, ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerPS not implemented"));
   
}

/**
 * Method: blIsHDRadioActive
  * API for checking the availability of HD Radio.
  * 
 */
tbool clHSA_System_TestMode_Base::blIsHDRadioActive(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blIsHDRadioActive not implemented"));
   return 0;
}

/**
 * Method: vGetTunerCallSign
  * Return current Tuner Call Sign
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerCallSign(GUI_String *out_result, ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerCallSign not implemented"));
   
}

/**
 * Method: ulwGetTunerCDNo
  * Returns the CD No for the requested tuner
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerCDNo(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerCDNo not implemented"));
   return 0;
}

/**
 * Method: ulwGetTunerHDStationID
  * Returns the Station ID for the requested tuner
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerHDStationID(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerHDStationID not implemented"));
   return 0;
}

/**
 * Method: ulwGetTunerRDSErrorRate
  * Returns RDS error rate for the requested tuner
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerRDSErrorRate(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerRDSErrorRate not implemented"));
   return 0;
}

/**
 * Method: ulwGetTunerRDSErrorRateService
  * Returns RDS error rate
  * B2
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerRDSErrorRateService(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerRDSErrorRateService not implemented"));
   return 0;
}

/**
 * Method: ulwGetTunerSharx
  * Returns Sharx value for the requested tuner
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerSharx(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerSharx not implemented"));
   return 0;
}

/**
 * Method: vGetTunerSignalQuality
  * Returns Tuner signal quality for the requested tuner
  * B1
 */
void clHSA_System_TestMode_Base::vGetTunerSignalQuality(GUI_String *out_result, ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerSignalQuality not implemented"));
   
}

/**
 * Method: ulwGetTunerCS
  * Returns channel separation for the requested tuner
  * 
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerCS(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerCS not implemented"));
   return 0;
}

/**
 * Method: blGetTASetup
  * Returns TA setup for all the tuners
  * 
 */
tbool clHSA_System_TestMode_Base::blGetTASetup( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetTASetup not implemented"));
   return 0;
}

/**
 * Method: vToggleTASetup
  * Sets TA for all the tuners
  * 
 */
void clHSA_System_TestMode_Base::vToggleTASetup( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vToggleTASetup not implemented"));
   
}

/**
 * Method: vGetTunerPD
  * Returns the Phase Diversity for the requested tuner
  * 
 */
void clHSA_System_TestMode_Base::vGetTunerPD(GUI_String *out_result, ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetTunerPD not implemented"));
   
}

/**
 * Method: vToggleRDSReg
  * Toggle the value of RDS Reg
  * 
 */
void clHSA_System_TestMode_Base::vToggleRDSReg( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vToggleRDSReg not implemented"));
   
}

/**
 * Method: vToggleMeasureMode
  * Toggle the value of Measure Mode
  * 
 */
void clHSA_System_TestMode_Base::vToggleMeasureMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vToggleMeasureMode not implemented"));
   
}

/**
 * Method: ulwGetTunerTA
  * Returns TA status for the requested tuner
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerTA(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerTA not implemented"));
   return 0;
}

/**
 * Method: ulwGetTunerTP
  * Returns TP status for the requested tuner
  * B1
 */
ulword clHSA_System_TestMode_Base::ulwGetTunerTP(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTunerTP not implemented"));
   return 0;
}

/**
 * Method: vGetValidAFItem
  * Returns the selected entry of the AF list
  * B
 */
void clHSA_System_TestMode_Base::vGetValidAFItem(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetValidAFItem not implemented"));
   
}

/**
 * Method: ulwGetValidAFItemCount
  * Returns the count of the AF list
  * B
 */
ulword clHSA_System_TestMode_Base::ulwGetValidAFItemCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetValidAFItemCount not implemented"));
   return 0;
}

/**
 * Method: vGetVersion
  * Returns the requested version as string
  * B1
 */
void clHSA_System_TestMode_Base::vGetVersion(GUI_String *out_result, ulword ulwVersion)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwVersion);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetVersion not implemented"));
   
}

/**
 * Method: vBTDevTestToggleECNREngineStatus
  * Toggles status of the echo cancelation noise reduction engine.
  * 
 */
void clHSA_System_TestMode_Base::vBTDevTestToggleECNREngineStatus( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevTestToggleECNREngineStatus not implemented"));
   
}

/**
 * Method: blBTDevTestGetECNREngineStatus
  * Gets status of the echo cancelation noise reduction engine.
  * 
 */
tbool clHSA_System_TestMode_Base::blBTDevTestGetECNREngineStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blBTDevTestGetECNREngineStatus not implemented"));
   return 0;
}

/**
 * Method: vBTDevTestSetHCIModeStatus
  * Sets HCI Mode of the BT Module for running the accreditation tests.
  * 
 */
void clHSA_System_TestMode_Base::vBTDevTestSetHCIModeStatus(tbool blValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevTestSetHCIModeStatus not implemented"));
   
}

/**
 * Method: blBTDevTestGetHCIModeStatus
  * Gets status of the echo cancelation noise reduction engine.
  * 
 */
tbool clHSA_System_TestMode_Base::blBTDevTestGetHCIModeStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blBTDevTestGetHCIModeStatus not implemented"));
   return 0;
}

/**
 * Method: vBTDevTestSetFrequency
  * sets the frequency to the value chosen in the drop down menu.
  * 
 */
void clHSA_System_TestMode_Base::vBTDevTestSetFrequency(ulword ulwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevTestSetFrequency not implemented"));
   
}

/**
 * Method: ulwBTDevTestGetFrequency
  * gets the mapping value for the frequency chosen for the BT device
  * 
 */
ulword clHSA_System_TestMode_Base::ulwBTDevTestGetFrequency( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwBTDevTestGetFrequency not implemented"));
   return 0;
}

/**
 * Method: vBTDevTestSetPacketType
  * Sets the packet type for the test.
  * 
 */
void clHSA_System_TestMode_Base::vBTDevTestSetPacketType(ulword ulwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevTestSetPacketType not implemented"));
   
}

/**
 * Method: ulwBTDevTestGetPacketType
  * Returns the mapping value corresponding to the packet type chosen for the test.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwBTDevTestGetPacketType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwBTDevTestGetPacketType not implemented"));
   return 0;
}

/**
 * Method: vBTDevTestSetModulationValue
  * Sets the modulation value for the test.
  * 
 */
void clHSA_System_TestMode_Base::vBTDevTestSetModulationValue(ulword ulwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevTestSetModulationValue not implemented"));
   
}

/**
 * Method: ulwBTDevTestGetModulationValue
  * Returns the mapping value corresponding to the modulation chosen for the test.
  * 
 */
ulword clHSA_System_TestMode_Base::ulwBTDevTestGetModulationValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwBTDevTestGetModulationValue not implemented"));
   return 0;
}

/**
 * Method: vBTDevRunTest
  * runs one of the tests for the BT device
  * 
 */
void clHSA_System_TestMode_Base::vBTDevRunTest(ulword ulwTest)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTest);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevRunTest not implemented"));
   
}

/**
 * Method: vBTDevStopTest
  * ends the running test for the BT device
  * 
 */
void clHSA_System_TestMode_Base::vBTDevStopTest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevStopTest not implemented"));
   
}

/**
 * Method: vBTDevTestGetTestValues
  * Gets some additional values of the parameters for each BT device test
  * 
 */
void clHSA_System_TestMode_Base::vBTDevTestGetTestValues(GUI_String *out_result, ulword ulwTestParameter)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTestParameter);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevTestGetTestValues not implemented"));
   
}

/**
 * Method: vGetWheel1RPM
  * returns RPM of wheel 1
  * B2
 */
void clHSA_System_TestMode_Base::vGetWheel1RPM(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetWheel1RPM not implemented"));
   
}

/**
 * Method: vBTDevTestGetLinkKey
  *  To display the LinkKey of connected phone
  * B2
 */
void clHSA_System_TestMode_Base::vBTDevTestGetLinkKey(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vBTDevTestGetLinkKey not implemented"));
   
}

/**
 * Method: vGetWheel2RPM
  * returns RPM of wheel 2
  * B2
 */
void clHSA_System_TestMode_Base::vGetWheel2RPM(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetWheel2RPM not implemented"));
   
}

/**
 * Method: vGetWheel3RPM
  * returns RPM of wheel 3
  * B2
 */
void clHSA_System_TestMode_Base::vGetWheel3RPM(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetWheel3RPM not implemented"));
   
}

/**
 * Method: vGetWheel4RPM
  * returns RPM of wheel 4
  * B2
 */
void clHSA_System_TestMode_Base::vGetWheel4RPM(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetWheel4RPM not implemented"));
   
}

/**
 * Method: vGetWheelCircumference
  * Returns the  wheel circumference
  * B
 */
void clHSA_System_TestMode_Base::vGetWheelCircumference(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetWheelCircumference not implemented"));
   
}

/**
 * Method: vIncreaseDABFader
  * increases the value of the selected fader until max-range is reached
  * Plus
 */
void clHSA_System_TestMode_Base::vIncreaseDABFader(ulword ulwFader)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwFader);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vIncreaseDABFader not implemented"));
   
}

/**
 * Method: blIsAntenna2Available
  * Returns true if two antenna are installed in the car. In Skoda Variante only one antenna exists.
  * B1
 */
tbool clHSA_System_TestMode_Base::blIsAntenna2Available( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blIsAntenna2Available not implemented"));
   return 0;
}

/**
 * Method: blIsDevelopermodeEnabled
  * Returns whether Developermode was activated or not.
  * B1
 */
tbool clHSA_System_TestMode_Base::blIsDevelopermodeEnabled( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blIsDevelopermodeEnabled not implemented"));
   return 0;
}

/**
 * Method: vRestoreDefaultSettings
  * This call will set all user defined settings from developermode to default settings.
  * B1
 */
void clHSA_System_TestMode_Base::vRestoreDefaultSettings( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vRestoreDefaultSettings not implemented"));
   
}

/**
 * Method: vSelectTMCStation
  * Selects a station from the TMC Stationlist for showing the details of this station
  * B
 */
void clHSA_System_TestMode_Base::vSelectTMCStation(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSelectTMCStation not implemented"));
   
}

/**
 * Method: vSetActiveTuner
  * Sets the active Tuner
  * B1
 */
void clHSA_System_TestMode_Base::vSetActiveTuner(ulword ulwTuner)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTuner);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetActiveTuner not implemented"));
   
}

/**
 * Method: vSetDABConcealmentLevelValue
  * Sets the concealment level of dab in dab setup
  * Plus
 */
void clHSA_System_TestMode_Base::vSetDABConcealmentLevelValue(ulword ulwConcealmentLevelValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwConcealmentLevelValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetDABConcealmentLevelValue not implemented"));
   
}

/**
 * Method: vSetDABFaderPosition
  * sets th new value of the selected fader
  * Plus
 */
void clHSA_System_TestMode_Base::vSetDABFaderPosition(ulword ulwFader, slword slwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwFader);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetDABFaderPosition not implemented"));
   
}

/**
 * Method: vSetDABReceptionValue
  * sets the new value of DAB-Reception
  * Plus
 */
void clHSA_System_TestMode_Base::vSetDABReceptionValue(ulword ulwDABReceptionValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDABReceptionValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetDABReceptionValue not implemented"));
   
}

/**
 * Method: vSetDABServiceLinkingValue
  * sets the new alue of DAB-Service-Linking (on/off)
  * Plus
 */
void clHSA_System_TestMode_Base::vSetDABServiceLinkingValue(ulword ulwServiceLinkingValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwServiceLinkingValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetDABServiceLinkingValue not implemented"));
   
}

/**
 * Method: vSetHighcut
  * Sets current HC
  * B1
 */
void clHSA_System_TestMode_Base::vSetHighcut(tbool blDirection)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blDirection);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetHighcut not implemented"));
   
}

/**
 * Method: vSetRadioTestModeActive
  * Toggels the radio test mode to enabled or disabled.
  * B
 */
void clHSA_System_TestMode_Base::vSetRadioTestModeActive(ulword ulwenable)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwenable);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetRadioTestModeActive not implemented"));
   
}

/**
 * Method: vSetSetupSharx
  * Sets the sharx value 
  * B1
 */
void clHSA_System_TestMode_Base::vSetSetupSharx(tbool blDirection)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blDirection);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetSetupSharx not implemented"));
   
}

/**
 * Method: vSetTunerModeSetup
  * Sets the Tuner mode in Radio Setup
  * B1
 */
void clHSA_System_TestMode_Base::vSetTunerModeSetup(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetTunerModeSetup not implemented"));
   
}

/**
 * Method: vSetTuneToAF
  * tunes to selected AF
  * B1
 */
void clHSA_System_TestMode_Base::vSetTuneToAF(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetTuneToAF not implemented"));
   
}

/**
 * Method: vToggelLinearAudio
  * Toggles the Linea Audio value between true and false
  * B1
 */
void clHSA_System_TestMode_Base::vToggelLinearAudio( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vToggelLinearAudio not implemented"));
   
}

/**
 * Method: vToggleAFValue
  * Toggles the AF value between true and false.
  * B1
 */
void clHSA_System_TestMode_Base::vToggleAFValue( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vToggleAFValue not implemented"));
   
}

/**
 * Method: vToggleFreezeBackgroundTuner
  * Toggles the Freeze BackgroundTuner value between true and false.
  * B1
 */
void clHSA_System_TestMode_Base::vToggleFreezeBackgroundTuner( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vToggleFreezeBackgroundTuner not implemented"));
   
}

/**
 * Method: vToggleDDAState
  * Toggles the DDA Status in the Tuner between True and False.
  * B1
 */
void clHSA_System_TestMode_Base::vToggleDDAState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vToggleDDAState not implemented"));
   
}

/**
 * Method: vSetRadioTMEnter
  * API to trigger the switch off of persistant data storage by ADR3 on entering testmode
  * B1
 */
void clHSA_System_TestMode_Base::vSetRadioTMEnter( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vSetRadioTMEnter not implemented"));
   
}

/**
 * Method: vToggleSDTrace
  * Toggles the SD Trace value between true and false.
  * B
 */
void clHSA_System_TestMode_Base::vToggleSDTrace( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vToggleSDTrace not implemented"));
   
}

/**
 * Method: ulwGetCsmEngineering_Count
  * CsmEngineering data count
  * NISSAN LCN NAR NET#2 Sample
 */
ulword clHSA_System_TestMode_Base::ulwGetCsmEngineering_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetCsmEngineering_Count not implemented"));
   return 0;
}

/**
 * Method: vStartCsmEngineering
  * Start the CsmEngineering method of VD VehicleData(cyclic methodStart).
  * NISSAN LCN NAR NET#2 Sample
 */
void clHSA_System_TestMode_Base::vStartCsmEngineering( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vStartCsmEngineering not implemented"));
   
}

/**
 * Method: vGetCsmEngineeringData
  * This function is uesed to get the CsmEngineering data of the VD VehicleData.
  * NISSAN LCN NAR NET#2 Sample
 */
void clHSA_System_TestMode_Base::vGetCsmEngineeringData(GUI_String *out_result, ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetCsmEngineeringData not implemented"));
   
}

/**
 * Method: vCreateScreenShot
  * Tries to create a screenShot
  * NISSAN LCN NAR NET#2 Sample
 */
void clHSA_System_TestMode_Base::vCreateScreenShot( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vCreateScreenShot not implemented"));
   
}

/**
 * Method: blGetScreenShotState
  * Returns the state of last screen shot creation. FALSE = failure, TRUE = OK
  * NISSAN LCN NAR NET#2 Sample
 */
tbool clHSA_System_TestMode_Base::blGetScreenShotState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetScreenShotState not implemented"));
   return 0;
}

/**
 * Method: vToggleScreenShotSetting
  * Toggles the screen shot setting. Enable it if disabled and vice versa
  * NISSAN LCN NAR NET#2 Sample
 */
void clHSA_System_TestMode_Base::vToggleScreenShotSetting( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vToggleScreenShotSetting not implemented"));
   
}

/**
 * Method: blGetScreenShotSetting
  * Returns the state of screen shot setting
  * NISSAN LCN NAR NET#2 Sample
 */
tbool clHSA_System_TestMode_Base::blGetScreenShotSetting( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetScreenShotSetting not implemented"));
   return 0;
}

/**
 * Method: vScreenShotResetState
  * Resets DPGUI__BOOL_SCREEN_SHOT_STATE to 128
  * NISSAN LCN NAR NET#2 Sample
 */
void clHSA_System_TestMode_Base::vScreenShotResetState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vScreenShotResetState not implemented"));
   
}

/**
 * Method: vGetSXMServiceDTMMonData
  * Get SXM DTM data
  * NISSAN
 */
void clHSA_System_TestMode_Base::vGetSXMServiceDTMMonData(GUI_String *out_result, ulword ulwLineNo)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLineNo);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetSXMServiceDTMMonData not implemented"));
   
}

/**
 * Method: vActivateSXMDTM
  *  This API is called when user enter in to SXM DTM screen 
  * NISSAN
 */
void clHSA_System_TestMode_Base::vActivateSXMDTM(ulword ulwAction)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwAction);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vActivateSXMDTM not implemented"));
   
}

/**
 * Method: vClearSXMDTMFunctions
  *  To clear SXM functions 
  * NISSAN
 */
void clHSA_System_TestMode_Base::vClearSXMDTMFunctions(ulword ulwLineNo)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLineNo);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vClearSXMDTMFunctions not implemented"));
   
}

/**
 * Method: blExternalDiagModeState
  * State Of the External diag Mode
  * NISSAN
 */
tbool clHSA_System_TestMode_Base::blExternalDiagModeState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blExternalDiagModeState not implemented"));
   return 0;
}

/**
 * Method: vToggleExternalDiagMode
  *  Toggle(ON/OFF) between External Diagnosis mode
  * NISSAN
 */
void clHSA_System_TestMode_Base::vToggleExternalDiagMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vToggleExternalDiagMode not implemented"));
   
}

/**
 * Method: ulwGetSXMSettingsMenuData
  *  To get SXM Settings menu data 
  * NISSAN
 */
ulword clHSA_System_TestMode_Base::ulwGetSXMSettingsMenuData(ulword ulwLineNo)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLineNo);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetSXMSettingsMenuData not implemented"));
   return 0;
}

/**
 * Method: vTriggerNavSamplePrompt
  * Triggers the Navigation Sample voice prompt
  * NISSAN LCN2KAI
 */
void clHSA_System_TestMode_Base::vTriggerNavSamplePrompt( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vTriggerNavSamplePrompt not implemented"));
   
}

/**
 * Method: vGetSXMRadioID
  * returns SXM radio ID
  * B2
 */
void clHSA_System_TestMode_Base::vGetSXMRadioID(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetSXMRadioID not implemented"));
   
}

/**
 * Method: vStartMethodforUPCLID
  * initiates method start for obtaining SXM UPC LID
  * NISSAN LCN NAR NET#2 Sample
 */
void clHSA_System_TestMode_Base::vStartMethodforUPCLID( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vStartMethodforUPCLID not implemented"));
   
}

/**
 * Method: blWaitSyncforSXMDiag
  * Whether to wait for information or not.
  * NISSAN2.0
 */
tbool clHSA_System_TestMode_Base::blWaitSyncforSXMDiag( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blWaitSyncforSXMDiag not implemented"));
   return 0;
}

/**
 * Method: ulwGetSXMSTMDataParam1
  *  To get SXM STM data 
  * NISSAN
 */
ulword clHSA_System_TestMode_Base::ulwGetSXMSTMDataParam1(ulword ulwLineNo)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLineNo);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetSXMSTMDataParam1 not implemented"));
   return 0;
}

/**
 * Method: vGetSXMSTMDataParam2
  *  To get SXM STM data 
  * NISSAN
 */
void clHSA_System_TestMode_Base::vGetSXMSTMDataParam2(GUI_String *out_result, ulword ulwLineNo)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLineNo);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_TestMode::vGetSXMSTMDataParam2 not implemented"));
   
}

/**
 * Method: blGetSxmDTMPopupStatus
  * SXM DTM popup status
  * NISSAN2.0
 */
tbool clHSA_System_TestMode_Base::blGetSxmDTMPopupStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System_TestMode::blGetSxmDTMPopupStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetTouchCordinate
  *  To get Coordinate for touching 
  * NISSAN
 */
ulword clHSA_System_TestMode_Base::ulwGetTouchCordinate(ulword ulwX_Y_Coordinate, ulword ulwRow)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwX_Y_Coordinate);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRow);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_TestMode::ulwGetTouchCordinate not implemented"));
   return 0;
}

