/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_System_TestMode_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_System_TestMode_Wrapper_dbg.h"
#include "clHSA_System_TestMode_Base.h"
#include "HSA_System_TestMode_Trace.h"
#include "HSA_System_TestMode_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_System_TestMode_Wrapper_dbg::~clHSA_System_TestMode_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_System_TestMode_Wrapper_dbg::clHSA_System_TestMode_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_System_TestMode_Wrapper_dbg::clHSA_System_TestMode_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_System_TestMode_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_System_TestMode_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__GET_TM_DATA_AVAILABILITY:

            HSA_System_TestMode__ulwGetTMDataAvailability();
            break;

        case HSA_API_ENTRYPOINT__SET_DAB_TESTMODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System_TestMode__vSetDABTestmode(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_NEW_SCREEN_DATA_ID:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSetNewScreenDataID(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DISPLAY_TEST_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System_TestMode__vDisplayTestStatus(usParam1);
            break;

        case HSA_API_ENTRYPOINT__CHECK_SYSTEM_VOLTAGE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System_TestMode__vCheckSystemVoltage(usParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_CHANNEL_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABChannelNumber(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABEnsembleLabel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_ID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetDABEnsembleID(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SERVICE_ID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABServiceID(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_FREQUENCY_TABLE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABFrequencyTable(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_FREQUENCY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetDABEnsembleFrequency(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABServiceLabel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DABMSCBER:

            HSA_System_TestMode__ulwGetDABMSCBER();
            break;

        case HSA_API_ENTRYPOINT__GET_DABFICBER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetDABFICBER(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_RS_FEC:

            HSA_System_TestMode__ulwGetDAB_RS_FEC();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_BG__MODE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDAB_BG_Mode(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DABTMC:

            HSA_System_TestMode__ulwGetDABTMC();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_TPEG:

            HSA_System_TestMode__ulwGetDAB_TPEG();
            break;

        case HSA_API_ENTRYPOINT__START_TPEG_REQUEST:

            HSA_System_TestMode__vStartTPEGRequest();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_TPEG_NEW:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetDAB_TPEGNew(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TEC:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGet_TEC(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TMC:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGet_TMC(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_URI_DATA:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetURIData(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TOTAL_ACI_DPER_FRAME:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTotalACIDperFrame(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_URI_LIST:

            HSA_System_TestMode__vRequestToURIList();
            break;

        case HSA_API_ENTRYPOINT__GET_URI_LIST_COUNT:

            HSA_System_TestMode__ulwGetURIListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_URI_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_System_TestMode__vGetURIList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__REQUEST_TO_STREAM_LIST:

            HSA_System_TestMode__vRequestToStreamList();
            break;

        case HSA_API_ENTRYPOINT__GET_STREAM_LIST_COUNT:

            HSA_System_TestMode__ulwGetStreamListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_STREAM_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_System_TestMode__vGetStreamList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_TSU__STATUS:

            HSA_System_TestMode__blGetDAB_TSU_Status();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SWITCHING_STATUS:

            HSA_System_TestMode__blGetDABSwitchingStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_NUM_ENSEMBLES_DB:

            HSA_System_TestMode__ulwGetDABNumEnsembles_DB();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_NUM_TMC__SERVICES:

            HSA_System_TestMode__ulwGetDABNum_TMC_Services();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_NUM_TPEG__SERVICES:

            HSA_System_TestMode__ulwGetDABNum_TPEG_Services();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_EXPERT_ID_VALUE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetDABExpertIDValue(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_EXPERT_ID_INFO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam4); 

            HSA_System_TestMode__vGetDABExpertIDInfo(&gsParam1, ulParam2, ulParam3, usParam4);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_DAB_ACTIVITY:

            HSA_System_TestMode__ulwGetCurrentDABActivity();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_FIELD_STRENGTH:

            HSA_System_TestMode__slwGetDABFieldStrength();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SIGNAL_QUALITY:

            HSA_System_TestMode__ulwGetDABSignalQuality();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_AUDIO_QUALITY:

            HSA_System_TestMode__ulwGetDABAudioQuality();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SYNC:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__blGetDABSync(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_INITFOR_ID:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSpellerInitforID(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_NAME_INPUT:

            HSA_System_TestMode__vSpellerSetNameInput();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_NAME_INPUT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vSpellerGetNameInput(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_CHARACTER_INPUT:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_System_TestMode__vSpellerCharacterInput(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS:

            HSA_System_TestMode__ulwSpellerGetCursorPos();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_CHARACTER_DELETE:

            HSA_System_TestMode__vSpellerCharacterDelete();
            break;

        case HSA_API_ENTRYPOINT__GET_TIME_INTERVAL:

            HSA_System_TestMode__ulwGetTimeInterval();
            break;

        case HSA_API_ENTRYPOINT__SET_TIME_INTERVAL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSetTimeInterval(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MUTE:

            HSA_System_TestMode__blGetDABMute();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_AUDIO_BIT_RATE:

            HSA_System_TestMode__ulwGetDABAudioBitRate();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SAMPLING_RATE:

            HSA_System_TestMode__ulwGetDABSamplingRate();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_STEREO_MODE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABStereoMode(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DABAAC:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABAAC(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_PROTECTION_LEVEL:

            HSA_System_TestMode__ulwGetDABProtectionLevel();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_AUDIO_CODEC:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABAudioCodec(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SOURCE_STATE:

            HSA_System_TestMode__ulwGetDABSourceState();
            break;

        case HSA_API_ENTRYPOINT__GET_DABFM_FRQ:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABFMFrq(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DABFMPI:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABFMPI(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DABFM_QUALITY:

            HSA_System_TestMode__ulwGetDABFMQuality();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_TRANSMISSION_MODE:

            HSA_System_TestMode__ulwGetDABTransmissionMode();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SHORT_ENSEMBLE_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABShortEnsembleLabel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SHORT_SERVICE_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABShortServiceLabel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SRV_COMP_ID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABSrvCompID(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SRV_COMP_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABSrvCompLabel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SHORT_SRV_COMP_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABShortSrvCompLabel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DABTP_SUPPORT:

            HSA_System_TestMode__blGetDABTPSupport();
            break;

        case HSA_API_ENTRYPOINT__GET_DABTA_STATUS:

            HSA_System_TestMode__blGetDABTAStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_DABDRC:

            HSA_System_TestMode__blGetDABDRC();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB__POR_S__INFO:

            HSA_System_TestMode__blGetDAB_PorS_Info();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_AUDIO_DATA_SER_COM_TYPE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABAudioDataSerComType(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB__POR_D__FLAG:

            HSA_System_TestMode__blGetDAB_PorD_Flag();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_TRANSPORT_MECHANISM_ID:

            HSA_System_TestMode__ulwGetDABTransportMechanismID();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ANNO_SUPPORT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABAnnoSupport(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_NUM_OF_AUD_SERVICES:

            HSA_System_TestMode__ulwGetDABNumOfAudServices();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_NUM_OF_DATA_SERVICES:

            HSA_System_TestMode__ulwGetDABNumOfDataServices();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_NUM_OF_AUD_SER_COMP:

            HSA_System_TestMode__ulwGetDABNumOfAudSerComp();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_NUM_OF_DATA_SER_COMP:

            HSA_System_TestMode__ulwGetDABNumOfDataSerComp();
            break;

        case HSA_API_ENTRYPOINT__GET_DABTMC_SUPPORT_STATUS:

            HSA_System_TestMode__blGetDABTMCSupportStatus();
            break;

        case HSA_API_ENTRYPOINT__DAB_ENSEMBLE_FREQUENCY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System_TestMode__vDABEnsembleFrequency(usParam1);
            break;

        case HSA_API_ENTRYPOINT__DAB_CHANGE_SERVICE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System_TestMode__vDABChangeService(usParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ANNO_SWITCH_MASK:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABAnnoSwitchMask(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB__DATABASE__SCRN__NO:

            HSA_System_TestMode__ulwGetDAB_Database_Scrn_No();
            break;

        case HSA_API_ENTRYPOINT__DAB_DB__SCREEN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System_TestMode__vDAB_DB_Screen(usParam1);
            break;

        case HSA_API_ENTRYPOINT__DAB_DB__CURRENT_SCREEN_QUERY:

            HSA_System_TestMode__vDAB_DB_CurrentScreenQuery();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_CONCEALMENT_LEVEL:

            HSA_System_TestMode__ulwGetDABConcealmentLevel();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB__DATABASE__STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDAB_Database_String(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DAB_CONCEALMENT_LEVEL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System_TestMode__vSetDABConcealmentLevel(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DABSF_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSetDABSFMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DABSF_MODE_SELECTION_STATUS:

            HSA_System_TestMode__ulwGetDABSFModeSelectionStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_TA_SOURCE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetTASource(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_NUMBER_OF_LINKS:

            HSA_System_TestMode__ulwGetDABNumberOfLinks();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ACTIVE_LINK_INDEX:

            HSA_System_TestMode__ulwGetDABActiveLinkIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_LINK_TYPE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetDABLinkType(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_FRQ_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetDABFrqLabel(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DABSID_PI:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetDABSID_PI(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_QUALITY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetDABQuality(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DABEID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetDABEID(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_COUNTRY:

            HSA_System_TestMode__ulwGetCountry();
            break;

        case HSA_API_ENTRYPOINT__GET_GENDER:

            HSA_System_TestMode__ulwGetGender();
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_DEVICE_ADRESS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vBTDevDeviceAdress(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_PIM_OPERATION_STATUS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vBTDevPIMOperationStatus(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_HFP_AG_SUPPORTED_FEATURES:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vBTDevHfpAgSupportedFeatures(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_PHONEBOOK_ENTRIES_COUNT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vBTDevPhonebookEntriesCount(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_AVP_PLAY_STATUS:

            HSA_System_TestMode__ulwBTDevAvpPlayStatus();
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_AVP_SUPPORTED_PLAYER_STATUS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vBTDevAvpSupportedPlayerStatus(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_SMS_SUPPORTED_FEATURES:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vBTDevSMSSupportedFeatures(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_SMS_DEVICE_SYSTEM_STATUS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vBTDevSMSDeviceSystemStatus(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_SMS_SUPPORTED_NOTIFICATION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vBTDevSMSSupportedNotification(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_ENABLED_SERVICES:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__blBTDevEnabledServices(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_CONNECTED_SERVICES:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__blBTDevConnectedServices(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TELEPHONE_MICROPHONE_CONNECTION_VALUE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetTelephoneMicrophoneConnectionValue(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_AUDIO_CODEC_USED:

            HSA_System_TestMode__ulwBTDevAudioCodecUsed();
            break;

        case HSA_API_ENTRYPOINT__SERVICE_MODE_ENTRY:

            HSA_System_TestMode__vServiceModeEntry();
            break;

        case HSA_API_ENTRYPOINT__SERVICE_MODE_EXIT:

            HSA_System_TestMode__vServiceModeExit();
            break;

        case HSA_API_ENTRYPOINT__GET_MFL_KEY_PRESSED:

            HSA_System_TestMode__ulwGetMFLKeyPressed();
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_ANTENNA_ONE:

            HSA_System_TestMode__ulwGetTunerAntennaOne();
            break;

        case HSA_API_ENTRYPOINT__GET_SRV_TROUBLE_CODE_LIST_ELEMENT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetSrvTroubleCodeListElement(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_USB_DEVICE_SRV_STATUS:

            HSA_System_TestMode__ulwGetUsbDeviceSrvStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_USB_DEVICE_SRV_ID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetUsbDeviceSrvID(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SRV_SYSTEM_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetSrvSystemStatus(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SRV_USB_DEVICE_STATUS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetSrvUsbDeviceStatus(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_EXT_PHONE_SIGNAL_STATE:

            HSA_System_TestMode__ulwGetExtPhoneSignalState();
            break;

        case HSA_API_ENTRYPOINT__GET_TELEPHONE_MICROPHONE_CONNECTION_STATUS:

            HSA_System_TestMode__ulwGetTelephoneMicrophoneConnectionStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_IPOD_FIRMWARE_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetIpodFirmwareVersion(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_STATUS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetSystemStatus(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TROUBLE_CODE_LIST_COUNT:

            HSA_System_TestMode__ulwGetTroubleCodeListCount();
            break;

        case HSA_API_ENTRYPOINT__CLEAR_TROUBLE_CODE_LIST:

            HSA_System_TestMode__vClearTroubleCodeList();
            break;

        case HSA_API_ENTRYPOINT__GET_TROUBLE_CODE_LIST_ELEMENT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTroubleCodeListElement(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_BT_MODULE_MODE:

            HSA_System_TestMode__ulwGetBTModuleMode();
            break;

        case HSA_API_ENTRYPOINT__SET_BT_MODULE_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSetBTModuleMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_MODULE_STATUS:

            HSA_System_TestMode__ulwBTModuleStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_VOLTAGE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetSystemVoltage(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CD_DRIVE_STATUS:

            HSA_System_TestMode__ulwGetCDDriveStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_USB_MEMORY_FREE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetUSBMemoryFree(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_USB_MEMORY_TOTAL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetUSBMemoryTotal(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_USB_MEDIA_STATUS:

            HSA_System_TestMode__ulwGetUSBMediaStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_BT_LINK_QUALITY:

            HSA_System_TestMode__ulwGetBTLinkQuality();
            break;

        case HSA_API_ENTRYPOINT__GET_BTRSSI:

            HSA_System_TestMode__ulwGetBTRSSI();
            break;

        case HSA_API_ENTRYPOINT__GET_FGSHW_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetFGSHWVersion(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ARION_PLATFORM_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetArionPlatformVersion(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_BT_APPL_VERSION_DATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetBTApplVersionDate(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_BT_APPL_MSG_CATALOG_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetBTApplMsgCatalogVersion(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_BT_APPL_INTERFACE_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetBTApplInterfaceVersion(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TEMPERATURE_AMPLIFIER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetTemperatureAmplifier(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__CLEAR_ERROR_STORE:

            HSA_System_TestMode__vClearErrorStore();
            break;

        case HSA_API_ENTRYPOINT__CLEAR_RESET_COUNTER_VALUES:

            HSA_System_TestMode__vClearResetCounterValues();
            break;

        case HSA_API_ENTRYPOINT__DECREASE_DAB_FADER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vDecreaseDABFader(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_TUNER:

            HSA_System_TestMode__ulwGetActiveTuner();
            break;

        case HSA_API_ENTRYPOINT__GET_AF:

            HSA_System_TestMode__blGetAF();
            break;

        case HSA_API_ENTRYPOINT__GET_ANGLE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetAngle(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_BEST_SATELLITE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetBestSatellite(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CAN_ANALOG_MUTE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetCANAnalogMute(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CANKL15:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetCANKL15(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CANKL58D:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetCANKL58D(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CAN_MUTE_BIT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetCANMuteBit(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CAN_MUTE_VALUE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetCANMuteValue(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CAN_REVERSE_GEAR:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetCANReverseGear(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CANS_KONTAKT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetCANSKontakt(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CAN_SPEED_SIGNAL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetCANSpeedSignal(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_COG_COUNT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetCogCount(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_DAB_FADER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__slwGetCurrentDABFader(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_CONCEALMENT_LEVEL_VALUE:

            HSA_System_TestMode__ulwGetDABConcealmentLevelValue();
            break;

        case HSA_API_ENTRYPOINT__GET_DABFM_LINK__FREQUENCY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABFM_LINK_Frequency(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DABFM__LINK_PI:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABFM_Link_PI(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DABFM__LINK__QUALITY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABFM_Link_Quality(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_AC:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueAC(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_AS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueAS(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ASU:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueASU(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ASW:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueASW(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_AUDIO_QUALITY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueAudioQuality(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_AUDIO_SAMPLING_RATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueAudioSamplingRate(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_BER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueBER(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_BITRATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueBitrate(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_CHANNEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueChannel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_COMPONEN_SHORTT_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueComponenShorttLabel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_COMPONENT_ID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueComponentID(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_COMPONENT_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueComponentLabel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_DAB_MODE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueDABMode(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_DRC:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueDRC(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ENSEMBLE_ID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueEnsembleID(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ENSEMBLE_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueEnsembleLabel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ENSEMBLE_SHORT_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueEnsembleShortLabel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_FIELD_STRENGTH:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueFieldStrength(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_MODE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueMode(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_MSC:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueMSC(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_MUTE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueMute(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_PROTECTION_LEVEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueProtectionLevel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_PTY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValuePTY(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUES:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2);

            HSA_System_TestMode__vGetDABMonitorValues(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SCID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueSCID(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_FOLLOWING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueServiceFollowing(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_ID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueServiceID(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueServiceLabel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_SF:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueServiceSF(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_SHORT_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueServiceShortLabel(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_STEREO_MODE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueStereoMode(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SYNC:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueSync(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_TMC:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABMonitorValueTMC(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_RECEPTION_VALUE:

            HSA_System_TestMode__ulwGetDABReceptionValue();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING__COUNT:

            HSA_System_TestMode__ulwGetDABServiceLinking_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_FREQ_LABEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetDABServiceLinkingFreqLabel(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_LINKTYPE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetDABServiceLinkingLinktype(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_PI:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetDABServiceLinkingPI(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_QUALITY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetDABServiceLinkingQuality(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_VALUE:

            HSA_System_TestMode__ulwGetDABServiceLinkingValue();
            break;

        case HSA_API_ENTRYPOINT__GET_DABTP__FREQUENCY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABTP_Frequency(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DABTP_PI:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABTP_PI(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DABTP__QUALITY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetDABTP_Quality(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DEAD_RECKONING_VALUES:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetDeadReckoningValues(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_FREEZE_BACKGROUND_TUNER:

            HSA_System_TestMode__blGetFreezeBackgroundTuner();
            break;

        case HSA_API_ENTRYPOINT__GET_DDA_STATUS:

            HSA_System_TestMode__blGetDDAStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_GPS_VALUES:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetGPSValues(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_LINEAR_AUDIO:

            HSA_System_TestMode__blGetLinearAudio();
            break;

        case HSA_API_ENTRYPOINT__GET_MAP_INFO_VALUES:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetMapInfoValues(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_MATCHED_POSITION_VALUES:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetMatchedPositionValues(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_MEDIA_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetMediaStatus(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ODOMETER_DATA_UPDATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System_TestMode__ulwGetOdometerDataUpdate(usParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_RESET_COUNTER_VALUE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetResetCounterValue(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SD_TRACE:

            HSA_System_TestMode__blGetSDTrace();
            break;

        case HSA_API_ENTRYPOINT__GET_SERVICE_MODE_FIELD_STRENGTH:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetServiceModeFieldStrength(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SERVICE_MODE_QUALITY_INDICATOR_VALUE:

            HSA_System_TestMode__ulwGetServiceModeQualityIndicatorValue();
            break;

        case HSA_API_ENTRYPOINT__GET_SERVICE_MODE_QUALITY_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetServiceModeQualityString(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SETUP_HIGHCUT:

            HSA_System_TestMode__ulwGetSetupHighcut();
            break;

        case HSA_API_ENTRYPOINT__GET_SETUP_SHARX:

            HSA_System_TestMode__ulwGetSetupSharx();
            break;

        case HSA_API_ENTRYPOINT__GET_TEMPERATURE_DISPLAY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetTemperatureDisplay(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TEMPERATURE_GPS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetTemperatureGPS(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TMC_LAST_MSG_TIME_DATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetTMCLastMsgTimeDate(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TMC_NO_OF_MSGS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetTMCNoOfMsgs(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TMC_NO_OF_MSGS_SELECTION_AREA:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetTMCNoOfMsgsSelectionArea(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TMC_STATION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTMCStation(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TMC_STATION__COUNT:

            HSA_System_TestMode__ulwGetTMCStation_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_TMC_STATION_COUNTRY_CODE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetTMCStationCountryCode(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TMC_STATION_LTN:

            HSA_System_TestMode__ulwGetTMCStationLTN();
            break;

        case HSA_API_ENTRYPOINT__GET_TMC_STATION_PI:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetTMCStationPI(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TMC_STATION_PS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetTMCStationPS(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TMC_STATION_QUALITY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetTMCStationQuality(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TMC_STATION_SID:

            HSA_System_TestMode__ulwGetTMCStationSID();
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_AF:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerAF(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_AF_LIST_COUNT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerAFListCount(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_AF_LIST_INDEX:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerAFListIndex(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_ANTENNA1:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerAntenna1(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_ANTENNA2:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerAntenna2(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_BER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerBER(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_FREQUENCY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerFrequency(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_FREQUENCY_UNIT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerFrequencyUnit(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_FS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerFS(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_CAL_DATA:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerCalData(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__EXIT_AF_LIST:

            HSA_System_TestMode__vExitAFList();
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_HC:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerHC(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_HUB:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerHUB(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_MODE:

            HSA_System_TestMode__ulwGetTunerMode();
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_MODE_SETUP:

            HSA_System_TestMode__ulwGetTunerModeSetup();
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_MULTI_PATH:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerMultiPath(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_BAND:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetActiveBand(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_ACTIVE_BAND:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSetActiveBand(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_NEIGHBOUR_CHANNEL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerNeighbourChannel(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_MEASURE_MODE:

            HSA_System_TestMode__blGetTunerMeasureMode();
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_RDS_REG:

            HSA_System_TestMode__blGetTunerRDSReg();
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_PI:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerPI(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_PS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerPS(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__IS_HD_RADIO_ACTIVE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__blIsHDRadioActive(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_CALL_SIGN:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerCallSign(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_CD_NO:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerCDNo(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_HD_STATION_ID:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerHDStationID(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_RDS_ERROR_RATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerRDSErrorRate(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_RDS_ERROR_RATE_SERVICE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerRDSErrorRateService(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_SHARX:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerSharx(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_SIGNAL_QUALITY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerSignalQuality(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_CS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerCS(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TA_SETUP:

            HSA_System_TestMode__blGetTASetup();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_TA_SETUP:

            HSA_System_TestMode__vToggleTASetup();
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_PD:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetTunerPD(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_RDS_REG:

            HSA_System_TestMode__vToggleRDSReg();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_MEASURE_MODE:

            HSA_System_TestMode__vToggleMeasureMode();
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_TA:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerTA(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TUNER_TP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetTunerTP(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_VALID_AF_ITEM:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetValidAFItem(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_VALID_AF_ITEM_COUNT:

            HSA_System_TestMode__ulwGetValidAFItemCount();
            break;

        case HSA_API_ENTRYPOINT__GET_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetVersion(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_TEST_TOGGLE_ECNR_ENGINE_STATUS:

            HSA_System_TestMode__vBTDevTestToggleECNREngineStatus();
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_ECNR_ENGINE_STATUS:

            HSA_System_TestMode__blBTDevTestGetECNREngineStatus();
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_TEST_SET_HCI_MODE_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System_TestMode__vBTDevTestSetHCIModeStatus(usParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_HCI_MODE_STATUS:

            HSA_System_TestMode__blBTDevTestGetHCIModeStatus();
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_TEST_SET_FREQUENCY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vBTDevTestSetFrequency(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_FREQUENCY:

            HSA_System_TestMode__ulwBTDevTestGetFrequency();
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_TEST_SET_PACKET_TYPE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vBTDevTestSetPacketType(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_PACKET_TYPE:

            HSA_System_TestMode__ulwBTDevTestGetPacketType();
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_TEST_SET_MODULATION_VALUE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vBTDevTestSetModulationValue(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_MODULATION_VALUE:

            HSA_System_TestMode__ulwBTDevTestGetModulationValue();
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_RUN_TEST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vBTDevRunTest(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_STOP_TEST:

            HSA_System_TestMode__vBTDevStopTest();
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_TEST_VALUES:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vBTDevTestGetTestValues(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_WHEEL1RPM:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetWheel1RPM(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_LINK_KEY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vBTDevTestGetLinkKey(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_WHEEL2RPM:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetWheel2RPM(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_WHEEL3RPM:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetWheel3RPM(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_WHEEL4RPM:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetWheel4RPM(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_WHEEL_CIRCUMFERENCE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetWheelCircumference(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__INCREASE_DAB_FADER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vIncreaseDABFader(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_ANTENNA2_AVAILABLE:

            HSA_System_TestMode__blIsAntenna2Available();
            break;

        case HSA_API_ENTRYPOINT__IS_DEVELOPERMODE_ENABLED:

            HSA_System_TestMode__blIsDevelopermodeEnabled();
            break;

        case HSA_API_ENTRYPOINT__RESTORE_DEFAULT_SETTINGS:

            HSA_System_TestMode__vRestoreDefaultSettings();
            break;

        case HSA_API_ENTRYPOINT__SELECT_TMC_STATION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSelectTMCStation(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_ACTIVE_TUNER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSetActiveTuner(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DAB_CONCEALMENT_LEVEL_VALUE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSetDABConcealmentLevelValue(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DAB_FADER_POSITION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam2); 

            HSA_System_TestMode__vSetDABFaderPosition(ulParam1, slParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_DAB_RECEPTION_VALUE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSetDABReceptionValue(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DAB_SERVICE_LINKING_VALUE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSetDABServiceLinkingValue(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_HIGHCUT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System_TestMode__vSetHighcut(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_RADIO_TEST_MODE_ACTIVE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSetRadioTestModeActive(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_SETUP_SHARX:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System_TestMode__vSetSetupSharx(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_TUNER_MODE_SETUP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSetTunerModeSetup(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_TUNE_TO_AF:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vSetTuneToAF(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__TOGGEL_LINEAR_AUDIO:

            HSA_System_TestMode__vToggelLinearAudio();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_AF_VALUE:

            HSA_System_TestMode__vToggleAFValue();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_FREEZE_BACKGROUND_TUNER:

            HSA_System_TestMode__vToggleFreezeBackgroundTuner();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_DDA_STATE:

            HSA_System_TestMode__vToggleDDAState();
            break;

        case HSA_API_ENTRYPOINT__SET_RADIO_TM_ENTER:

            HSA_System_TestMode__vSetRadioTMEnter();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_SD_TRACE:

            HSA_System_TestMode__vToggleSDTrace();
            break;

        case HSA_API_ENTRYPOINT__GET_CSM_ENGINEERING__COUNT:

            HSA_System_TestMode__ulwGetCsmEngineering_Count();
            break;

        case HSA_API_ENTRYPOINT__START_CSM_ENGINEERING:

            HSA_System_TestMode__vStartCsmEngineering();
            break;

        case HSA_API_ENTRYPOINT__GET_CSM_ENGINEERING_DATA:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetCsmEngineeringData(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__CREATE_SCREEN_SHOT:

            HSA_System_TestMode__vCreateScreenShot();
            break;

        case HSA_API_ENTRYPOINT__GET_SCREEN_SHOT_STATE:

            HSA_System_TestMode__blGetScreenShotState();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_SCREEN_SHOT_SETTING:

            HSA_System_TestMode__vToggleScreenShotSetting();
            break;

        case HSA_API_ENTRYPOINT__GET_SCREEN_SHOT_SETTING:

            HSA_System_TestMode__blGetScreenShotSetting();
            break;

        case HSA_API_ENTRYPOINT__SCREEN_SHOT_RESET_STATE:

            HSA_System_TestMode__vScreenShotResetState();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_SERVICE_DTM_MON_DATA:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetSXMServiceDTMMonData(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_SXMDTM:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vActivateSXMDTM(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__CLEAR_SXMDTM_FUNCTIONS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__vClearSXMDTMFunctions(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__EXTERNAL_DIAG_MODE_STATE:

            HSA_System_TestMode__blExternalDiagModeState();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_EXTERNAL_DIAG_MODE:

            HSA_System_TestMode__vToggleExternalDiagMode();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_SETTINGS_MENU_DATA:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetSXMSettingsMenuData(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__TRIGGER_NAV_SAMPLE_PROMPT:

            HSA_System_TestMode__vTriggerNavSamplePrompt();
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_RADIO_ID:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System_TestMode__vGetSXMRadioID(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__START_METHODFOR_UPCLID:

            HSA_System_TestMode__vStartMethodforUPCLID();
            break;

        case HSA_API_ENTRYPOINT__WAIT_SYNCFOR_SXM_DIAG:

            HSA_System_TestMode__blWaitSyncforSXMDiag();
            break;

        case HSA_API_ENTRYPOINT__GET_SXMSTM_DATA_PARAM1:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System_TestMode__ulwGetSXMSTMDataParam1(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SXMSTM_DATA_PARAM2:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__vGetSXMSTMDataParam2(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SXM_DTM_POPUP_STATUS:

            HSA_System_TestMode__blGetSxmDTMPopupStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_TOUCH_CORDINATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System_TestMode__ulwGetTouchCordinate(ulParam1, ulParam2);
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

