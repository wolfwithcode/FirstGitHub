/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_System_TestMode_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_System_TestMode_Base_H
#define _clHSA_System_TestMode_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_System_TestMode_Base : public clHSA_Base
{
public:

    static clHSA_System_TestMode_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_System_TestMode_Base()        {}

    virtual ulword ulwGetTMDataAvailability( );

    virtual void vSetDABTestmode(tbool blActive);

    virtual void vSetNewScreenDataID(ulword ulwScreen_ID);

    virtual void vDisplayTestStatus(tbool blDisplayTestSuccess);

    virtual void vCheckSystemVoltage(tbool blAction);

    virtual void vGetDABChannelNumber(GUI_String *out_result);

    virtual void vGetDABEnsembleLabel(GUI_String *out_result);

    virtual void vGetDABEnsembleID(GUI_String *out_result, ulword ulwDABTuner);

    virtual void vGetDABServiceID(GUI_String *out_result);

    virtual void vGetDABFrequencyTable(GUI_String *out_result);

    virtual ulword ulwGetDABEnsembleFrequency(ulword ulwDABTuner);

    virtual void vGetDABServiceLabel(GUI_String *out_result);

    virtual ulword ulwGetDABMSCBER( );

    virtual ulword ulwGetDABFICBER(ulword ulwDABTuner);

    virtual ulword ulwGetDAB_RS_FEC( );

    virtual void vGetDAB_BG_Mode(GUI_String *out_result);

    virtual ulword ulwGetDABTMC( );

    virtual ulword ulwGetDAB_TPEG( );

    virtual void vStartTPEGRequest( );

    virtual void vGetDAB_TPEGNew(GUI_String *out_result, ulword ulwInfo_Type);

    virtual void vGet_TEC(GUI_String *out_result, ulword ulwInfo_Type);

    virtual void vGet_TMC(GUI_String *out_result, ulword ulwInfo_Type);

    virtual void vGetURIData(GUI_String *out_result, ulword ulwInfo_Type);

    virtual ulword ulwGetTotalACIDperFrame(ulword ulwInfo_Type);

    virtual void vRequestToURIList( );

    virtual ulword ulwGetURIListCount( );

    virtual void vGetURIList(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwInfo_Type);

    virtual void vRequestToStreamList( );

    virtual ulword ulwGetStreamListCount( );

    virtual void vGetStreamList(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwInfo_Type);

    virtual tbool blGetDAB_TSU_Status( );

    virtual tbool blGetDABSwitchingStatus( );

    virtual ulword ulwGetDABNumEnsembles_DB( );

    virtual ulword ulwGetDABNum_TMC_Services( );

    virtual ulword ulwGetDABNum_TPEG_Services( );

    virtual void vGetDABExpertIDValue(GUI_String *out_result, ulword ulwID);

    virtual void vGetDABExpertIDInfo(GUI_String *out_result, ulword ulwID, ulword ulwID_Value, tbool blType);

    virtual ulword ulwGetCurrentDABActivity( );

    virtual slword slwGetDABFieldStrength( );

    virtual ulword ulwGetDABSignalQuality( );

    virtual ulword ulwGetDABAudioQuality( );

    virtual tbool blGetDABSync(ulword ulwDABTuner);

    virtual void vSpellerInitforID(ulword ulwID);

    virtual void vSpellerSetNameInput( );

    virtual void vSpellerGetNameInput(GUI_String *out_result);

    virtual void vSpellerCharacterInput(const GUI_String * InputString);

    virtual ulword ulwSpellerGetCursorPos( );

    virtual void vSpellerCharacterDelete( );

    virtual ulword ulwGetTimeInterval( );

    virtual void vSetTimeInterval(ulword ulwInterval);

    virtual tbool blGetDABMute( );

    virtual ulword ulwGetDABAudioBitRate( );

    virtual ulword ulwGetDABSamplingRate( );

    virtual void vGetDABStereoMode(GUI_String *out_result);

    virtual void vGetDABAAC(GUI_String *out_result);

    virtual ulword ulwGetDABProtectionLevel( );

    virtual void vGetDABAudioCodec(GUI_String *out_result);

    virtual ulword ulwGetDABSourceState( );

    virtual void vGetDABFMFrq(GUI_String *out_result);

    virtual void vGetDABFMPI(GUI_String *out_result);

    virtual ulword ulwGetDABFMQuality( );

    virtual ulword ulwGetDABTransmissionMode( );

    virtual void vGetDABShortEnsembleLabel(GUI_String *out_result);

    virtual void vGetDABShortServiceLabel(GUI_String *out_result);

    virtual void vGetDABSrvCompID(GUI_String *out_result);

    virtual void vGetDABSrvCompLabel(GUI_String *out_result);

    virtual void vGetDABShortSrvCompLabel(GUI_String *out_result);

    virtual tbool blGetDABTPSupport( );

    virtual tbool blGetDABTAStatus( );

    virtual tbool blGetDABDRC( );

    virtual tbool blGetDAB_PorS_Info( );

    virtual void vGetDABAudioDataSerComType(GUI_String *out_result);

    virtual tbool blGetDAB_PorD_Flag( );

    virtual ulword ulwGetDABTransportMechanismID( );

    virtual void vGetDABAnnoSupport(GUI_String *out_result);

    virtual ulword ulwGetDABNumOfAudServices( );

    virtual ulword ulwGetDABNumOfDataServices( );

    virtual ulword ulwGetDABNumOfAudSerComp( );

    virtual ulword ulwGetDABNumOfDataSerComp( );

    virtual tbool blGetDABTMCSupportStatus( );

    virtual void vDABEnsembleFrequency(tbool blDirection);

    virtual void vDABChangeService(tbool blDirection);

    virtual void vGetDABAnnoSwitchMask(GUI_String *out_result);

    virtual ulword ulwGetDAB_Database_Scrn_No( );

    virtual void vDAB_DB_Screen(tbool blScreen_ID);

    virtual void vDAB_DB_CurrentScreenQuery( );

    virtual ulword ulwGetDABConcealmentLevel( );

    virtual void vGetDAB_Database_String(GUI_String *out_result);

    virtual void vSetDABConcealmentLevel(tbool blDirection);

    virtual void vSetDABSFMode(ulword ulwServiceLinkingMode);

    virtual ulword ulwGetDABSFModeSelectionStatus( );

    virtual void vGetTASource(GUI_String *out_result);

    virtual ulword ulwGetDABNumberOfLinks( );

    virtual ulword ulwGetDABActiveLinkIndex( );

    virtual void vGetDABLinkType(GUI_String *out_result, ulword ulwIndex);

    virtual void vGetDABFrqLabel(GUI_String *out_result, ulword ulwIndex);

    virtual void vGetDABSID_PI(GUI_String *out_result, ulword ulwIndex);

    virtual ulword ulwGetDABQuality(ulword ulwIndex);

    virtual void vGetDABEID(GUI_String *out_result, ulword ulwIndex);

    virtual ulword ulwGetCountry( );

    virtual ulword ulwGetGender( );

    virtual void vBTDevDeviceAdress(GUI_String *out_result);

    virtual void vBTDevPIMOperationStatus(GUI_String *out_result);

    virtual void vBTDevHfpAgSupportedFeatures(GUI_String *out_result);

    virtual void vBTDevPhonebookEntriesCount(GUI_String *out_result, ulword ulwPhonebookType);

    virtual ulword ulwBTDevAvpPlayStatus( );

    virtual void vBTDevAvpSupportedPlayerStatus(GUI_String *out_result);

    virtual void vBTDevSMSSupportedFeatures(GUI_String *out_result);

    virtual void vBTDevSMSDeviceSystemStatus(GUI_String *out_result);

    virtual void vBTDevSMSSupportedNotification(GUI_String *out_result);

    virtual tbool blBTDevEnabledServices(ulword ulwBTService);

    virtual tbool blBTDevConnectedServices(ulword ulwBTService);

    virtual void vGetTelephoneMicrophoneConnectionValue(GUI_String *out_result);

    virtual ulword ulwBTDevAudioCodecUsed( );

    virtual void vServiceModeEntry( );

    virtual void vServiceModeExit( );

    virtual ulword ulwGetMFLKeyPressed( );

    virtual ulword ulwGetTunerAntennaOne( );

    virtual ulword ulwGetSrvTroubleCodeListElement(ulword ulwIndex);

    virtual ulword ulwGetUsbDeviceSrvStatus( );

    virtual void vGetUsbDeviceSrvID(GUI_String *out_result);

    virtual ulword ulwGetSrvSystemStatus(ulword ulwSystemStatus);

    virtual void vGetSrvUsbDeviceStatus(GUI_String *out_result);

    virtual ulword ulwGetExtPhoneSignalState( );

    virtual ulword ulwGetTelephoneMicrophoneConnectionStatus( );

    virtual void vGetIpodFirmwareVersion(GUI_String *out_result);

    virtual void vGetSystemStatus(GUI_String *out_result, ulword ulwSystemStatus);

    virtual ulword ulwGetTroubleCodeListCount( );

    virtual void vClearTroubleCodeList( );

    virtual void vGetTroubleCodeListElement(GUI_String *out_result, ulword ulwIndex);

    virtual ulword ulwGetBTModuleMode( );

    virtual void vSetBTModuleMode(ulword ulwBTModuleMode);

    virtual ulword ulwBTModuleStatus( );

    virtual void vGetSystemVoltage(GUI_String *out_result);

    virtual ulword ulwGetCDDriveStatus( );

    virtual void vGetUSBMemoryFree(GUI_String *out_result);

    virtual void vGetUSBMemoryTotal(GUI_String *out_result);

    virtual ulword ulwGetUSBMediaStatus( );

    virtual ulword ulwGetBTLinkQuality( );

    virtual ulword ulwGetBTRSSI( );

    virtual void vGetFGSHWVersion(GUI_String *out_result);

    virtual void vGetArionPlatformVersion(GUI_String *out_result);

    virtual void vGetBTApplVersionDate(GUI_String *out_result);

    virtual void vGetBTApplMsgCatalogVersion(GUI_String *out_result);

    virtual void vGetBTApplInterfaceVersion(GUI_String *out_result);

    virtual void vGetTemperatureAmplifier(GUI_String *out_result);

    virtual void vClearErrorStore( );

    virtual void vClearResetCounterValues( );

    virtual void vDecreaseDABFader(ulword ulwFader);

    virtual ulword ulwGetActiveTuner( );

    virtual tbool blGetAF( );

    virtual void vGetAngle(GUI_String *out_result);

    virtual ulword ulwGetBestSatellite(ulword ulwSatellite);

    virtual void vGetCANAnalogMute(GUI_String *out_result);

    virtual void vGetCANKL15(GUI_String *out_result);

    virtual void vGetCANKL58D(GUI_String *out_result);

    virtual void vGetCANMuteBit(GUI_String *out_result);

    virtual void vGetCANMuteValue(GUI_String *out_result);

    virtual void vGetCANReverseGear(GUI_String *out_result);

    virtual void vGetCANSKontakt(GUI_String *out_result);

    virtual void vGetCANSpeedSignal(GUI_String *out_result);

    virtual void vGetCogCount(GUI_String *out_result);

    virtual slword slwGetCurrentDABFader(ulword ulwFader);

    virtual ulword ulwGetDABConcealmentLevelValue( );

    virtual void vGetDABFM_LINK_Frequency(GUI_String *out_result);

    virtual void vGetDABFM_Link_PI(GUI_String *out_result);

    virtual void vGetDABFM_Link_Quality(GUI_String *out_result);

    virtual void vGetDABMonitorValueAC(GUI_String *out_result);

    virtual void vGetDABMonitorValueAS(GUI_String *out_result);

    virtual void vGetDABMonitorValueASU(GUI_String *out_result);

    virtual void vGetDABMonitorValueASW(GUI_String *out_result);

    virtual void vGetDABMonitorValueAudioQuality(GUI_String *out_result);

    virtual void vGetDABMonitorValueAudioSamplingRate(GUI_String *out_result);

    virtual void vGetDABMonitorValueBER(GUI_String *out_result);

    virtual void vGetDABMonitorValueBitrate(GUI_String *out_result);

    virtual void vGetDABMonitorValueChannel(GUI_String *out_result);

    virtual void vGetDABMonitorValueComponenShorttLabel(GUI_String *out_result);

    virtual void vGetDABMonitorValueComponentID(GUI_String *out_result);

    virtual void vGetDABMonitorValueComponentLabel(GUI_String *out_result);

    virtual void vGetDABMonitorValueDABMode(GUI_String *out_result);

    virtual void vGetDABMonitorValueDRC(GUI_String *out_result);

    virtual void vGetDABMonitorValueEnsembleID(GUI_String *out_result);

    virtual void vGetDABMonitorValueEnsembleLabel(GUI_String *out_result);

    virtual void vGetDABMonitorValueEnsembleShortLabel(GUI_String *out_result);

    virtual void vGetDABMonitorValueFieldStrength(GUI_String *out_result);

    virtual void vGetDABMonitorValueMode(GUI_String *out_result);

    virtual void vGetDABMonitorValueMSC(GUI_String *out_result);

    virtual void vGetDABMonitorValueMute(GUI_String *out_result);

    virtual void vGetDABMonitorValueProtectionLevel(GUI_String *out_result);

    virtual void vGetDABMonitorValuePTY(GUI_String *out_result);

    virtual void vGetDABMonitorValues(GUI_String *out_result, ulword uwArrayIndex);

    virtual void vGetDABMonitorValueSCID(GUI_String *out_result);

    virtual void vGetDABMonitorValueServiceFollowing(GUI_String *out_result);

    virtual void vGetDABMonitorValueServiceID(GUI_String *out_result);

    virtual void vGetDABMonitorValueServiceLabel(GUI_String *out_result);

    virtual void vGetDABMonitorValueServiceSF(GUI_String *out_result);

    virtual void vGetDABMonitorValueServiceShortLabel(GUI_String *out_result);

    virtual void vGetDABMonitorValueStereoMode(GUI_String *out_result);

    virtual void vGetDABMonitorValueSync(GUI_String *out_result);

    virtual void vGetDABMonitorValueTMC(GUI_String *out_result);

    virtual ulword ulwGetDABReceptionValue( );

    virtual ulword ulwGetDABServiceLinking_Count( );

    virtual void vGetDABServiceLinkingFreqLabel(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetDABServiceLinkingLinktype(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetDABServiceLinkingPI(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetDABServiceLinkingQuality(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetDABServiceLinkingValue( );

    virtual void vGetDABTP_Frequency(GUI_String *out_result);

    virtual void vGetDABTP_PI(GUI_String *out_result);

    virtual void vGetDABTP_Quality(GUI_String *out_result);

    virtual void vGetDeadReckoningValues(GUI_String *out_result, ulword ulwListEntryNr);

    virtual tbool blGetFreezeBackgroundTuner( );

    virtual tbool blGetDDAStatus( );

    virtual void vGetGPSValues(GUI_String *out_result, ulword ulwListEntryNr);

    virtual tbool blGetLinearAudio( );

    virtual void vGetMapInfoValues(GUI_String *out_result, ulword ulwMedium);

    virtual void vGetMatchedPositionValues(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetMediaStatus(ulword ulwDrive);

    virtual ulword ulwGetOdometerDataUpdate(tbool blOdometerData);

    virtual void vGetResetCounterValue(GUI_String *out_result, ulword ulwCounter);

    virtual tbool blGetSDTrace( );

    virtual ulword ulwGetServiceModeFieldStrength(ulword ulwType);

    virtual ulword ulwGetServiceModeQualityIndicatorValue( );

    virtual void vGetServiceModeQualityString(GUI_String *out_result, ulword ulwType);

    virtual ulword ulwGetSetupHighcut( );

    virtual ulword ulwGetSetupSharx( );

    virtual void vGetTemperatureDisplay(GUI_String *out_result);

    virtual void vGetTemperatureGPS(GUI_String *out_result);

    virtual void vGetTMCLastMsgTimeDate(GUI_String *out_result);

    virtual void vGetTMCNoOfMsgs(GUI_String *out_result);

    virtual void vGetTMCNoOfMsgsSelectionArea(GUI_String *out_result);

    virtual void vGetTMCStation(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetTMCStation_Count( );

    virtual void vGetTMCStationCountryCode(GUI_String *out_result);

    virtual ulword ulwGetTMCStationLTN( );

    virtual void vGetTMCStationPI(GUI_String *out_result);

    virtual void vGetTMCStationPS(GUI_String *out_result);

    virtual void vGetTMCStationQuality(GUI_String *out_result);

    virtual ulword ulwGetTMCStationSID( );

    virtual ulword ulwGetTunerAF(ulword ulwTuner);

    virtual ulword ulwGetTunerAFListCount(ulword ulwTuner);

    virtual void vGetTunerAFListIndex(GUI_String *out_result, ulword ulwIndex);

    virtual void vGetTunerAntenna1(GUI_String *out_result, ulword ulwTuner);

    virtual void vGetTunerAntenna2(GUI_String *out_result, ulword ulwTuner);

    virtual ulword ulwGetTunerBER(ulword ulwTuner);

    virtual void vGetTunerFrequency(GUI_String *out_result, ulword ulwTuner);

    virtual void vGetTunerFrequencyUnit(GUI_String *out_result, ulword ulwTuner);

    virtual ulword ulwGetTunerFS(ulword ulwTuner);

    virtual void vGetTunerCalData(GUI_String *out_result, ulword ulwCalibration);

    virtual void vExitAFList( );

    virtual ulword ulwGetTunerHC(ulword ulwTuner);

    virtual void vGetTunerHUB(GUI_String *out_result, ulword ulwTuner);

    virtual ulword ulwGetTunerMode( );

    virtual ulword ulwGetTunerModeSetup( );

    virtual void vGetTunerMultiPath(GUI_String *out_result, ulword ulwTuner);

    virtual ulword ulwGetActiveBand(ulword ulwTuner);

    virtual void vSetActiveBand(ulword ulwBand);

    virtual void vGetTunerNeighbourChannel(GUI_String *out_result, ulword ulwTuner);

    virtual tbool blGetTunerMeasureMode( );

    virtual tbool blGetTunerRDSReg( );

    virtual void vGetTunerPI(GUI_String *out_result, ulword ulwTuner);

    virtual void vGetTunerPS(GUI_String *out_result, ulword ulwTuner);

    virtual tbool blIsHDRadioActive(ulword ulwTuner);

    virtual void vGetTunerCallSign(GUI_String *out_result, ulword ulwTuner);

    virtual ulword ulwGetTunerCDNo(ulword ulwTuner);

    virtual ulword ulwGetTunerHDStationID(ulword ulwTuner);

    virtual ulword ulwGetTunerRDSErrorRate(ulword ulwTuner);

    virtual ulword ulwGetTunerRDSErrorRateService(ulword ulwTuner);

    virtual ulword ulwGetTunerSharx(ulword ulwTuner);

    virtual void vGetTunerSignalQuality(GUI_String *out_result, ulword ulwTuner);

    virtual ulword ulwGetTunerCS(ulword ulwTuner);

    virtual tbool blGetTASetup( );

    virtual void vToggleTASetup( );

    virtual void vGetTunerPD(GUI_String *out_result, ulword ulwTuner);

    virtual void vToggleRDSReg( );

    virtual void vToggleMeasureMode( );

    virtual ulword ulwGetTunerTA(ulword ulwTuner);

    virtual ulword ulwGetTunerTP(ulword ulwTuner);

    virtual void vGetValidAFItem(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetValidAFItemCount( );

    virtual void vGetVersion(GUI_String *out_result, ulword ulwVersion);

    virtual void vBTDevTestToggleECNREngineStatus( );

    virtual tbool blBTDevTestGetECNREngineStatus( );

    virtual void vBTDevTestSetHCIModeStatus(tbool blValue);

    virtual tbool blBTDevTestGetHCIModeStatus( );

    virtual void vBTDevTestSetFrequency(ulword ulwValue);

    virtual ulword ulwBTDevTestGetFrequency( );

    virtual void vBTDevTestSetPacketType(ulword ulwValue);

    virtual ulword ulwBTDevTestGetPacketType( );

    virtual void vBTDevTestSetModulationValue(ulword ulwValue);

    virtual ulword ulwBTDevTestGetModulationValue( );

    virtual void vBTDevRunTest(ulword ulwTest);

    virtual void vBTDevStopTest( );

    virtual void vBTDevTestGetTestValues(GUI_String *out_result, ulword ulwTestParameter);

    virtual void vGetWheel1RPM(GUI_String *out_result);

    virtual void vBTDevTestGetLinkKey(GUI_String *out_result);

    virtual void vGetWheel2RPM(GUI_String *out_result);

    virtual void vGetWheel3RPM(GUI_String *out_result);

    virtual void vGetWheel4RPM(GUI_String *out_result);

    virtual void vGetWheelCircumference(GUI_String *out_result);

    virtual void vIncreaseDABFader(ulword ulwFader);

    virtual tbool blIsAntenna2Available( );

    virtual tbool blIsDevelopermodeEnabled( );

    virtual void vRestoreDefaultSettings( );

    virtual void vSelectTMCStation(ulword ulwListEntryNr);

    virtual void vSetActiveTuner(ulword ulwTuner);

    virtual void vSetDABConcealmentLevelValue(ulword ulwConcealmentLevelValue);

    virtual void vSetDABFaderPosition(ulword ulwFader, slword slwValue);

    virtual void vSetDABReceptionValue(ulword ulwDABReceptionValue);

    virtual void vSetDABServiceLinkingValue(ulword ulwServiceLinkingValue);

    virtual void vSetHighcut(tbool blDirection);

    virtual void vSetRadioTestModeActive(ulword ulwenable);

    virtual void vSetSetupSharx(tbool blDirection);

    virtual void vSetTunerModeSetup(ulword ulwMode);

    virtual void vSetTuneToAF(ulword ulwListEntryNr);

    virtual void vToggelLinearAudio( );

    virtual void vToggleAFValue( );

    virtual void vToggleFreezeBackgroundTuner( );

    virtual void vToggleDDAState( );

    virtual void vSetRadioTMEnter( );

    virtual void vToggleSDTrace( );

    virtual ulword ulwGetCsmEngineering_Count( );

    virtual void vStartCsmEngineering( );

    virtual void vGetCsmEngineeringData(GUI_String *out_result, ulword ulwListEntryNumber);

    virtual void vCreateScreenShot( );

    virtual tbool blGetScreenShotState( );

    virtual void vToggleScreenShotSetting( );

    virtual tbool blGetScreenShotSetting( );

    virtual void vScreenShotResetState( );

    virtual void vGetSXMServiceDTMMonData(GUI_String *out_result, ulword ulwLineNo);

    virtual void vActivateSXMDTM(ulword ulwAction);

    virtual void vClearSXMDTMFunctions(ulword ulwLineNo);

    virtual tbool blExternalDiagModeState( );

    virtual void vToggleExternalDiagMode( );

    virtual ulword ulwGetSXMSettingsMenuData(ulword ulwLineNo);

    virtual void vTriggerNavSamplePrompt( );

    virtual void vGetSXMRadioID(GUI_String *out_result);

    virtual void vStartMethodforUPCLID( );

    virtual tbool blWaitSyncforSXMDiag( );

    virtual ulword ulwGetSXMSTMDataParam1(ulword ulwLineNo);

    virtual void vGetSXMSTMDataParam2(GUI_String *out_result, ulword ulwLineNo);

    virtual tbool blGetSxmDTMPopupStatus( );

    virtual ulword ulwGetTouchCordinate(ulword ulwX_Y_Coordinate, ulword ulwRow);

protected:
    clHSA_System_TestMode_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_System_TestMode_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_System_TestMode_Base_H

