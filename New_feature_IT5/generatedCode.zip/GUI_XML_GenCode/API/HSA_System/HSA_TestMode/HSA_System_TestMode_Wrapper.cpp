/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_System_TestMode_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_System_TestMode_Wrapper.h"
#include "clHSA_System_TestMode_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_System_TestMode_Trace.h"
#include "hmi_trace.h"

ulword HSA_System_TestMode__ulwGetTMDataAvailability( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TM_DATA_AVAILABILITY  ) ); 
        }
      ret=pInst->ulwGetTMDataAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TM_DATA_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vSetDABTestmode(tbool blActive)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_DAB_TESTMODE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blActive); 
        }
      pInst->vSetDABTestmode(blActive);

    }
}

void HSA_System_TestMode__vSetNewScreenDataID(ulword ulwScreen_ID)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_NEW_SCREEN_DATA_ID | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwScreen_ID); 
        }
      pInst->vSetNewScreenDataID(ulwScreen_ID);

    }
}

void HSA_System_TestMode__vDisplayTestStatus(tbool blDisplayTestSuccess)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__DISPLAY_TEST_STATUS | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blDisplayTestSuccess); 
        }
      pInst->vDisplayTestStatus(blDisplayTestSuccess);

    }
}

void HSA_System_TestMode__vCheckSystemVoltage(tbool blAction)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__CHECK_SYSTEM_VOLTAGE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blAction); 
        }
      pInst->vCheckSystemVoltage(blAction);

    }
}

void HSA_System_TestMode__vGetDABChannelNumber(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_CHANNEL_NUMBER  ) ); 
        }
      pInst->vGetDABChannelNumber(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_CHANNEL_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABEnsembleLabel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_LABEL  ) ); 
        }
      pInst->vGetDABEnsembleLabel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABEnsembleID(GUI_String *out_result, ulword ulwDABTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_ID | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDABTuner); 
        }
      pInst->vGetDABEnsembleID(out_result, ulwDABTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABServiceID(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_ID  ) ); 
        }
      pInst->vGetDABServiceID(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABFrequencyTable(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_FREQUENCY_TABLE  ) ); 
        }
      pInst->vGetDABFrequencyTable(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_FREQUENCY_TABLE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetDABEnsembleFrequency(ulword ulwDABTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_FREQUENCY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDABTuner); 
        }
      ret=pInst->ulwGetDABEnsembleFrequency(ulwDABTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_FREQUENCY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABServiceLabel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LABEL  ) ); 
        }
      pInst->vGetDABServiceLabel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetDABMSCBER( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABMSCBER  ) ); 
        }
      ret=pInst->ulwGetDABMSCBER();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABMSCBER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABFICBER(ulword ulwDABTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFICBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDABTuner); 
        }
      ret=pInst->ulwGetDABFICBER(ulwDABTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFICBER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDAB_RS_FEC( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_RS_FEC  ) ); 
        }
      ret=pInst->ulwGetDAB_RS_FEC();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_RS_FEC | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDAB_BG_Mode(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_BG__MODE  ) ); 
        }
      pInst->vGetDAB_BG_Mode(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_BG__MODE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetDABTMC( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTMC  ) ); 
        }
      ret=pInst->ulwGetDABTMC();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTMC | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDAB_TPEG( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_TPEG  ) ); 
        }
      ret=pInst->ulwGetDAB_TPEG();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_TPEG | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vStartTPEGRequest( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__START_TPEG_REQUEST  ) ); 
        }
      pInst->vStartTPEGRequest();

    }
}

void HSA_System_TestMode__vGetDAB_TPEGNew(GUI_String *out_result, ulword ulwInfo_Type)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_TPEG_NEW | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vGetDAB_TPEGNew(out_result, ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_TPEG_NEW | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGet_TEC(GUI_String *out_result, ulword ulwInfo_Type)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TEC | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vGet_TEC(out_result, ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TEC | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGet_TMC(GUI_String *out_result, ulword ulwInfo_Type)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vGet_TMC(out_result, ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetURIData(GUI_String *out_result, ulword ulwInfo_Type)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_URI_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vGetURIData(out_result, ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_URI_DATA | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetTotalACIDperFrame(ulword ulwInfo_Type)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TOTAL_ACI_DPER_FRAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      ret=pInst->ulwGetTotalACIDperFrame(ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TOTAL_ACI_DPER_FRAME | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vRequestToURIList( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_URI_LIST  ) ); 
        }
      pInst->vRequestToURIList();

    }
}

ulword HSA_System_TestMode__ulwGetURIListCount( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_URI_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetURIListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_URI_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetURIList(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwInfo_Type)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_URI_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_URI_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vGetURIList(out_result, ulwListEntryNr, ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_URI_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vRequestToStreamList( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__REQUEST_TO_STREAM_LIST  ) ); 
        }
      pInst->vRequestToStreamList();

    }
}

ulword HSA_System_TestMode__ulwGetStreamListCount( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_STREAM_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetStreamListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_STREAM_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetStreamList(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwInfo_Type)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_STREAM_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_STREAM_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInfo_Type); 
        }
      pInst->vGetStreamList(out_result, ulwListEntryNr, ulwInfo_Type);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_STREAM_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_System_TestMode__blGetDAB_TSU_Status( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_TSU__STATUS  ) ); 
        }
      ret=pInst->blGetDAB_TSU_Status();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_TSU__STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System_TestMode__blGetDABSwitchingStatus( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SWITCHING_STATUS  ) ); 
        }
      ret=pInst->blGetDABSwitchingStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SWITCHING_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABNumEnsembles_DB( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_ENSEMBLES_DB  ) ); 
        }
      ret=pInst->ulwGetDABNumEnsembles_DB();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_ENSEMBLES_DB | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABNum_TMC_Services( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_TMC__SERVICES  ) ); 
        }
      ret=pInst->ulwGetDABNum_TMC_Services();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_TMC__SERVICES | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABNum_TPEG_Services( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_TPEG__SERVICES  ) ); 
        }
      ret=pInst->ulwGetDABNum_TPEG_Services();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_TPEG__SERVICES | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABExpertIDValue(GUI_String *out_result, ulword ulwID)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_EXPERT_ID_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwID); 
        }
      pInst->vGetDABExpertIDValue(out_result, ulwID);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_EXPERT_ID_VALUE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABExpertIDInfo(GUI_String *out_result, ulword ulwID, ulword ulwID_Value, tbool blType)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_EXPERT_ID_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwID); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_EXPERT_ID_INFO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwID_Value); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_EXPERT_ID_INFO | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blType); 
        }
      pInst->vGetDABExpertIDInfo(out_result, ulwID, ulwID_Value, blType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_EXPERT_ID_INFO | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetCurrentDABActivity( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DAB_ACTIVITY  ) ); 
        }
      ret=pInst->ulwGetCurrentDABActivity();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DAB_ACTIVITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

slword HSA_System_TestMode__slwGetDABFieldStrength( )
{
    slword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_FIELD_STRENGTH  ) ); 
        }
      ret=pInst->slwGetDABFieldStrength();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_FIELD_STRENGTH | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABSignalQuality( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SIGNAL_QUALITY  ) ); 
        }
      ret=pInst->ulwGetDABSignalQuality();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SIGNAL_QUALITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABAudioQuality( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_AUDIO_QUALITY  ) ); 
        }
      ret=pInst->ulwGetDABAudioQuality();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_AUDIO_QUALITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System_TestMode__blGetDABSync(ulword ulwDABTuner)
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SYNC | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDABTuner); 
        }
      ret=pInst->blGetDABSync(ulwDABTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SYNC | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vSpellerInitforID(ulword ulwID)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INITFOR_ID | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwID); 
        }
      pInst->vSpellerInitforID(ulwID);

    }
}

void HSA_System_TestMode__vSpellerSetNameInput( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_NAME_INPUT  ) ); 
        }
      pInst->vSpellerSetNameInput();

    }
}

void HSA_System_TestMode__vSpellerGetNameInput(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_NAME_INPUT  ) ); 
        }
      pInst->vSpellerGetNameInput(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_NAME_INPUT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vSpellerCharacterInput(const GUI_String * InputString)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_CHARACTER_INPUT | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSpellerCharacterInput( InputString);

    }
}

ulword HSA_System_TestMode__ulwSpellerGetCursorPos( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS  ) ); 
        }
      ret=pInst->ulwSpellerGetCursorPos();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vSpellerCharacterDelete( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_CHARACTER_DELETE  ) ); 
        }
      pInst->vSpellerCharacterDelete();

    }
}

ulword HSA_System_TestMode__ulwGetTimeInterval( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_INTERVAL  ) ); 
        }
      ret=pInst->ulwGetTimeInterval();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TIME_INTERVAL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vSetTimeInterval(ulword ulwInterval)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_TIME_INTERVAL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwInterval); 
        }
      pInst->vSetTimeInterval(ulwInterval);

    }
}

tbool HSA_System_TestMode__blGetDABMute( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MUTE  ) ); 
        }
      ret=pInst->blGetDABMute();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MUTE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABAudioBitRate( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_AUDIO_BIT_RATE  ) ); 
        }
      ret=pInst->ulwGetDABAudioBitRate();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_AUDIO_BIT_RATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABSamplingRate( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SAMPLING_RATE  ) ); 
        }
      ret=pInst->ulwGetDABSamplingRate();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SAMPLING_RATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABStereoMode(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_STEREO_MODE  ) ); 
        }
      pInst->vGetDABStereoMode(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_STEREO_MODE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABAAC(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABAAC  ) ); 
        }
      pInst->vGetDABAAC(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABAAC | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetDABProtectionLevel( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_PROTECTION_LEVEL  ) ); 
        }
      ret=pInst->ulwGetDABProtectionLevel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_PROTECTION_LEVEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABAudioCodec(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_AUDIO_CODEC  ) ); 
        }
      pInst->vGetDABAudioCodec(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_AUDIO_CODEC | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetDABSourceState( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SOURCE_STATE  ) ); 
        }
      ret=pInst->ulwGetDABSourceState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SOURCE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABFMFrq(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFM_FRQ  ) ); 
        }
      pInst->vGetDABFMFrq(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFM_FRQ | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABFMPI(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFMPI  ) ); 
        }
      pInst->vGetDABFMPI(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFMPI | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetDABFMQuality( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFM_QUALITY  ) ); 
        }
      ret=pInst->ulwGetDABFMQuality();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFM_QUALITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABTransmissionMode( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_TRANSMISSION_MODE  ) ); 
        }
      ret=pInst->ulwGetDABTransmissionMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_TRANSMISSION_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABShortEnsembleLabel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SHORT_ENSEMBLE_LABEL  ) ); 
        }
      pInst->vGetDABShortEnsembleLabel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SHORT_ENSEMBLE_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABShortServiceLabel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SHORT_SERVICE_LABEL  ) ); 
        }
      pInst->vGetDABShortServiceLabel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SHORT_SERVICE_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABSrvCompID(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SRV_COMP_ID  ) ); 
        }
      pInst->vGetDABSrvCompID(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SRV_COMP_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABSrvCompLabel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SRV_COMP_LABEL  ) ); 
        }
      pInst->vGetDABSrvCompLabel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SRV_COMP_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABShortSrvCompLabel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SHORT_SRV_COMP_LABEL  ) ); 
        }
      pInst->vGetDABShortSrvCompLabel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SHORT_SRV_COMP_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_System_TestMode__blGetDABTPSupport( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTP_SUPPORT  ) ); 
        }
      ret=pInst->blGetDABTPSupport();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTP_SUPPORT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System_TestMode__blGetDABTAStatus( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTA_STATUS  ) ); 
        }
      ret=pInst->blGetDABTAStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTA_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System_TestMode__blGetDABDRC( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABDRC  ) ); 
        }
      ret=pInst->blGetDABDRC();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABDRC | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System_TestMode__blGetDAB_PorS_Info( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB__POR_S__INFO  ) ); 
        }
      ret=pInst->blGetDAB_PorS_Info();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB__POR_S__INFO | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABAudioDataSerComType(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_AUDIO_DATA_SER_COM_TYPE  ) ); 
        }
      pInst->vGetDABAudioDataSerComType(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_AUDIO_DATA_SER_COM_TYPE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_System_TestMode__blGetDAB_PorD_Flag( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB__POR_D__FLAG  ) ); 
        }
      ret=pInst->blGetDAB_PorD_Flag();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB__POR_D__FLAG | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABTransportMechanismID( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_TRANSPORT_MECHANISM_ID  ) ); 
        }
      ret=pInst->ulwGetDABTransportMechanismID();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_TRANSPORT_MECHANISM_ID | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABAnnoSupport(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ANNO_SUPPORT  ) ); 
        }
      pInst->vGetDABAnnoSupport(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ANNO_SUPPORT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetDABNumOfAudServices( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_OF_AUD_SERVICES  ) ); 
        }
      ret=pInst->ulwGetDABNumOfAudServices();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_OF_AUD_SERVICES | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABNumOfDataServices( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_OF_DATA_SERVICES  ) ); 
        }
      ret=pInst->ulwGetDABNumOfDataServices();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_OF_DATA_SERVICES | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABNumOfAudSerComp( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_OF_AUD_SER_COMP  ) ); 
        }
      ret=pInst->ulwGetDABNumOfAudSerComp();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_OF_AUD_SER_COMP | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABNumOfDataSerComp( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_OF_DATA_SER_COMP  ) ); 
        }
      ret=pInst->ulwGetDABNumOfDataSerComp();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_OF_DATA_SER_COMP | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System_TestMode__blGetDABTMCSupportStatus( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTMC_SUPPORT_STATUS  ) ); 
        }
      ret=pInst->blGetDABTMCSupportStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTMC_SUPPORT_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vDABEnsembleFrequency(tbool blDirection)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__DAB_ENSEMBLE_FREQUENCY | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blDirection); 
        }
      pInst->vDABEnsembleFrequency(blDirection);

    }
}

void HSA_System_TestMode__vDABChangeService(tbool blDirection)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__DAB_CHANGE_SERVICE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blDirection); 
        }
      pInst->vDABChangeService(blDirection);

    }
}

void HSA_System_TestMode__vGetDABAnnoSwitchMask(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ANNO_SWITCH_MASK  ) ); 
        }
      pInst->vGetDABAnnoSwitchMask(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ANNO_SWITCH_MASK | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetDAB_Database_Scrn_No( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB__DATABASE__SCRN__NO  ) ); 
        }
      ret=pInst->ulwGetDAB_Database_Scrn_No();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB__DATABASE__SCRN__NO | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vDAB_DB_Screen(tbool blScreen_ID)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__DAB_DB__SCREEN | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blScreen_ID); 
        }
      pInst->vDAB_DB_Screen(blScreen_ID);

    }
}

void HSA_System_TestMode__vDAB_DB_CurrentScreenQuery( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__DAB_DB__CURRENT_SCREEN_QUERY  ) ); 
        }
      pInst->vDAB_DB_CurrentScreenQuery();

    }
}

ulword HSA_System_TestMode__ulwGetDABConcealmentLevel( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_CONCEALMENT_LEVEL  ) ); 
        }
      ret=pInst->ulwGetDABConcealmentLevel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_CONCEALMENT_LEVEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDAB_Database_String(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB__DATABASE__STRING  ) ); 
        }
      pInst->vGetDAB_Database_String(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB__DATABASE__STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vSetDABConcealmentLevel(tbool blDirection)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_DAB_CONCEALMENT_LEVEL | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blDirection); 
        }
      pInst->vSetDABConcealmentLevel(blDirection);

    }
}

void HSA_System_TestMode__vSetDABSFMode(ulword ulwServiceLinkingMode)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_DABSF_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwServiceLinkingMode); 
        }
      pInst->vSetDABSFMode(ulwServiceLinkingMode);

    }
}

ulword HSA_System_TestMode__ulwGetDABSFModeSelectionStatus( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABSF_MODE_SELECTION_STATUS  ) ); 
        }
      ret=pInst->ulwGetDABSFModeSelectionStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABSF_MODE_SELECTION_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTASource(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TA_SOURCE  ) ); 
        }
      pInst->vGetTASource(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TA_SOURCE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetDABNumberOfLinks( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUMBER_OF_LINKS  ) ); 
        }
      ret=pInst->ulwGetDABNumberOfLinks();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUMBER_OF_LINKS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABActiveLinkIndex( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ACTIVE_LINK_INDEX  ) ); 
        }
      ret=pInst->ulwGetDABActiveLinkIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ACTIVE_LINK_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABLinkType(GUI_String *out_result, ulword ulwIndex)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_LINK_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vGetDABLinkType(out_result, ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_LINK_TYPE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABFrqLabel(GUI_String *out_result, ulword ulwIndex)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_FRQ_LABEL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vGetDABFrqLabel(out_result, ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_FRQ_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABSID_PI(GUI_String *out_result, ulword ulwIndex)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABSID_PI | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vGetDABSID_PI(out_result, ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABSID_PI | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetDABQuality(ulword ulwIndex)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_QUALITY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      ret=pInst->ulwGetDABQuality(ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_QUALITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABEID(GUI_String *out_result, ulword ulwIndex)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABEID | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vGetDABEID(out_result, ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABEID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetCountry( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_COUNTRY  ) ); 
        }
      ret=pInst->ulwGetCountry();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_COUNTRY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetGender( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_GENDER  ) ); 
        }
      ret=pInst->ulwGetGender();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_GENDER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vBTDevDeviceAdress(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_DEVICE_ADRESS  ) ); 
        }
      pInst->vBTDevDeviceAdress(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_DEVICE_ADRESS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vBTDevPIMOperationStatus(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_PIM_OPERATION_STATUS  ) ); 
        }
      pInst->vBTDevPIMOperationStatus(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_PIM_OPERATION_STATUS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vBTDevHfpAgSupportedFeatures(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_HFP_AG_SUPPORTED_FEATURES  ) ); 
        }
      pInst->vBTDevHfpAgSupportedFeatures(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_HFP_AG_SUPPORTED_FEATURES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vBTDevPhonebookEntriesCount(GUI_String *out_result, ulword ulwPhonebookType)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_PHONEBOOK_ENTRIES_COUNT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPhonebookType); 
        }
      pInst->vBTDevPhonebookEntriesCount(out_result, ulwPhonebookType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_PHONEBOOK_ENTRIES_COUNT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwBTDevAvpPlayStatus( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_AVP_PLAY_STATUS  ) ); 
        }
      ret=pInst->ulwBTDevAvpPlayStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_AVP_PLAY_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vBTDevAvpSupportedPlayerStatus(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_AVP_SUPPORTED_PLAYER_STATUS  ) ); 
        }
      pInst->vBTDevAvpSupportedPlayerStatus(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_AVP_SUPPORTED_PLAYER_STATUS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vBTDevSMSSupportedFeatures(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_SMS_SUPPORTED_FEATURES  ) ); 
        }
      pInst->vBTDevSMSSupportedFeatures(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_SMS_SUPPORTED_FEATURES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vBTDevSMSDeviceSystemStatus(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_SMS_DEVICE_SYSTEM_STATUS  ) ); 
        }
      pInst->vBTDevSMSDeviceSystemStatus(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_SMS_DEVICE_SYSTEM_STATUS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vBTDevSMSSupportedNotification(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_SMS_SUPPORTED_NOTIFICATION  ) ); 
        }
      pInst->vBTDevSMSSupportedNotification(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_SMS_SUPPORTED_NOTIFICATION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_System_TestMode__blBTDevEnabledServices(ulword ulwBTService)
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_ENABLED_SERVICES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBTService); 
        }
      ret=pInst->blBTDevEnabledServices(ulwBTService);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_ENABLED_SERVICES | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System_TestMode__blBTDevConnectedServices(ulword ulwBTService)
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_CONNECTED_SERVICES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBTService); 
        }
      ret=pInst->blBTDevConnectedServices(ulwBTService);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_CONNECTED_SERVICES | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTelephoneMicrophoneConnectionValue(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TELEPHONE_MICROPHONE_CONNECTION_VALUE  ) ); 
        }
      pInst->vGetTelephoneMicrophoneConnectionValue(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TELEPHONE_MICROPHONE_CONNECTION_VALUE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwBTDevAudioCodecUsed( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_AUDIO_CODEC_USED  ) ); 
        }
      ret=pInst->ulwBTDevAudioCodecUsed();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_AUDIO_CODEC_USED | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vServiceModeEntry( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SERVICE_MODE_ENTRY  ) ); 
        }
      pInst->vServiceModeEntry();

    }
}

void HSA_System_TestMode__vServiceModeExit( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SERVICE_MODE_EXIT  ) ); 
        }
      pInst->vServiceModeExit();

    }
}

ulword HSA_System_TestMode__ulwGetMFLKeyPressed( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_MFL_KEY_PRESSED  ) ); 
        }
      ret=pInst->ulwGetMFLKeyPressed();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_MFL_KEY_PRESSED | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetTunerAntennaOne( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_ANTENNA_ONE  ) ); 
        }
      ret=pInst->ulwGetTunerAntennaOne();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_ANTENNA_ONE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetSrvTroubleCodeListElement(ulword ulwIndex)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SRV_TROUBLE_CODE_LIST_ELEMENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      ret=pInst->ulwGetSrvTroubleCodeListElement(ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SRV_TROUBLE_CODE_LIST_ELEMENT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetUsbDeviceSrvStatus( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_USB_DEVICE_SRV_STATUS  ) ); 
        }
      ret=pInst->ulwGetUsbDeviceSrvStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_USB_DEVICE_SRV_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetUsbDeviceSrvID(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_USB_DEVICE_SRV_ID  ) ); 
        }
      pInst->vGetUsbDeviceSrvID(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_USB_DEVICE_SRV_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetSrvSystemStatus(ulword ulwSystemStatus)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SRV_SYSTEM_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSystemStatus); 
        }
      ret=pInst->ulwGetSrvSystemStatus(ulwSystemStatus);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SRV_SYSTEM_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetSrvUsbDeviceStatus(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SRV_USB_DEVICE_STATUS  ) ); 
        }
      pInst->vGetSrvUsbDeviceStatus(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SRV_USB_DEVICE_STATUS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetExtPhoneSignalState( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_EXT_PHONE_SIGNAL_STATE  ) ); 
        }
      ret=pInst->ulwGetExtPhoneSignalState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_EXT_PHONE_SIGNAL_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetTelephoneMicrophoneConnectionStatus( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TELEPHONE_MICROPHONE_CONNECTION_STATUS  ) ); 
        }
      ret=pInst->ulwGetTelephoneMicrophoneConnectionStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TELEPHONE_MICROPHONE_CONNECTION_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetIpodFirmwareVersion(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_IPOD_FIRMWARE_VERSION  ) ); 
        }
      pInst->vGetIpodFirmwareVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_IPOD_FIRMWARE_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetSystemStatus(GUI_String *out_result, ulword ulwSystemStatus)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSystemStatus); 
        }
      pInst->vGetSystemStatus(out_result, ulwSystemStatus);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_STATUS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetTroubleCodeListCount( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TROUBLE_CODE_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetTroubleCodeListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TROUBLE_CODE_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vClearTroubleCodeList( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__CLEAR_TROUBLE_CODE_LIST  ) ); 
        }
      pInst->vClearTroubleCodeList();

    }
}

void HSA_System_TestMode__vGetTroubleCodeListElement(GUI_String *out_result, ulword ulwIndex)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TROUBLE_CODE_LIST_ELEMENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vGetTroubleCodeListElement(out_result, ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TROUBLE_CODE_LIST_ELEMENT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetBTModuleMode( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_MODULE_MODE  ) ); 
        }
      ret=pInst->ulwGetBTModuleMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_MODULE_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vSetBTModuleMode(ulword ulwBTModuleMode)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_BT_MODULE_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBTModuleMode); 
        }
      pInst->vSetBTModuleMode(ulwBTModuleMode);

    }
}

ulword HSA_System_TestMode__ulwBTModuleStatus( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_MODULE_STATUS  ) ); 
        }
      ret=pInst->ulwBTModuleStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_MODULE_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetSystemVoltage(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_VOLTAGE  ) ); 
        }
      pInst->vGetSystemVoltage(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SYSTEM_VOLTAGE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetCDDriveStatus( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CD_DRIVE_STATUS  ) ); 
        }
      ret=pInst->ulwGetCDDriveStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CD_DRIVE_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetUSBMemoryFree(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_USB_MEMORY_FREE  ) ); 
        }
      pInst->vGetUSBMemoryFree(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_USB_MEMORY_FREE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetUSBMemoryTotal(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_USB_MEMORY_TOTAL  ) ); 
        }
      pInst->vGetUSBMemoryTotal(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_USB_MEMORY_TOTAL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetUSBMediaStatus( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_USB_MEDIA_STATUS  ) ); 
        }
      ret=pInst->ulwGetUSBMediaStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_USB_MEDIA_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetBTLinkQuality( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_LINK_QUALITY  ) ); 
        }
      ret=pInst->ulwGetBTLinkQuality();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_LINK_QUALITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetBTRSSI( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BTRSSI  ) ); 
        }
      ret=pInst->ulwGetBTRSSI();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BTRSSI | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetFGSHWVersion(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_FGSHW_VERSION  ) ); 
        }
      pInst->vGetFGSHWVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_FGSHW_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetArionPlatformVersion(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_ARION_PLATFORM_VERSION  ) ); 
        }
      pInst->vGetArionPlatformVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_ARION_PLATFORM_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetBTApplVersionDate(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_APPL_VERSION_DATE  ) ); 
        }
      pInst->vGetBTApplVersionDate(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_APPL_VERSION_DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetBTApplMsgCatalogVersion(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_APPL_MSG_CATALOG_VERSION  ) ); 
        }
      pInst->vGetBTApplMsgCatalogVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_APPL_MSG_CATALOG_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetBTApplInterfaceVersion(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_APPL_INTERFACE_VERSION  ) ); 
        }
      pInst->vGetBTApplInterfaceVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_APPL_INTERFACE_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetTemperatureAmplifier(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TEMPERATURE_AMPLIFIER  ) ); 
        }
      pInst->vGetTemperatureAmplifier(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TEMPERATURE_AMPLIFIER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vClearErrorStore( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__CLEAR_ERROR_STORE  ) ); 
        }
      pInst->vClearErrorStore();

    }
}

void HSA_System_TestMode__vClearResetCounterValues( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__CLEAR_RESET_COUNTER_VALUES  ) ); 
        }
      pInst->vClearResetCounterValues();

    }
}

void HSA_System_TestMode__vDecreaseDABFader(ulword ulwFader)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__DECREASE_DAB_FADER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwFader); 
        }
      pInst->vDecreaseDABFader(ulwFader);

    }
}

ulword HSA_System_TestMode__ulwGetActiveTuner( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_TUNER  ) ); 
        }
      ret=pInst->ulwGetActiveTuner();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_TUNER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System_TestMode__blGetAF( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_AF  ) ); 
        }
      ret=pInst->blGetAF();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_AF | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetAngle(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_ANGLE  ) ); 
        }
      pInst->vGetAngle(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_ANGLE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetBestSatellite(ulword ulwSatellite)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BEST_SATELLITE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSatellite); 
        }
      ret=pInst->ulwGetBestSatellite(ulwSatellite);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_BEST_SATELLITE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetCANAnalogMute(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CAN_ANALOG_MUTE  ) ); 
        }
      pInst->vGetCANAnalogMute(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CAN_ANALOG_MUTE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetCANKL15(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CANKL15  ) ); 
        }
      pInst->vGetCANKL15(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CANKL15 | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetCANKL58D(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CANKL58D  ) ); 
        }
      pInst->vGetCANKL58D(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CANKL58D | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetCANMuteBit(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CAN_MUTE_BIT  ) ); 
        }
      pInst->vGetCANMuteBit(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CAN_MUTE_BIT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetCANMuteValue(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CAN_MUTE_VALUE  ) ); 
        }
      pInst->vGetCANMuteValue(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CAN_MUTE_VALUE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetCANReverseGear(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CAN_REVERSE_GEAR  ) ); 
        }
      pInst->vGetCANReverseGear(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CAN_REVERSE_GEAR | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetCANSKontakt(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CANS_KONTAKT  ) ); 
        }
      pInst->vGetCANSKontakt(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CANS_KONTAKT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetCANSpeedSignal(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CAN_SPEED_SIGNAL  ) ); 
        }
      pInst->vGetCANSpeedSignal(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CAN_SPEED_SIGNAL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetCogCount(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_COG_COUNT  ) ); 
        }
      pInst->vGetCogCount(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_COG_COUNT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

slword HSA_System_TestMode__slwGetCurrentDABFader(ulword ulwFader)
{
    slword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DAB_FADER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwFader); 
        }
      ret=pInst->slwGetCurrentDABFader(ulwFader);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DAB_FADER | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABConcealmentLevelValue( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_CONCEALMENT_LEVEL_VALUE  ) ); 
        }
      ret=pInst->ulwGetDABConcealmentLevelValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_CONCEALMENT_LEVEL_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABFM_LINK_Frequency(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFM_LINK__FREQUENCY  ) ); 
        }
      pInst->vGetDABFM_LINK_Frequency(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFM_LINK__FREQUENCY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABFM_Link_PI(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFM__LINK_PI  ) ); 
        }
      pInst->vGetDABFM_Link_PI(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFM__LINK_PI | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABFM_Link_Quality(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFM__LINK__QUALITY  ) ); 
        }
      pInst->vGetDABFM_Link_Quality(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABFM__LINK__QUALITY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueAC(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_AC  ) ); 
        }
      pInst->vGetDABMonitorValueAC(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_AC | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueAS(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_AS  ) ); 
        }
      pInst->vGetDABMonitorValueAS(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_AS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueASU(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ASU  ) ); 
        }
      pInst->vGetDABMonitorValueASU(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ASU | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueASW(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ASW  ) ); 
        }
      pInst->vGetDABMonitorValueASW(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ASW | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueAudioQuality(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_AUDIO_QUALITY  ) ); 
        }
      pInst->vGetDABMonitorValueAudioQuality(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_AUDIO_QUALITY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueAudioSamplingRate(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_AUDIO_SAMPLING_RATE  ) ); 
        }
      pInst->vGetDABMonitorValueAudioSamplingRate(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_AUDIO_SAMPLING_RATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueBER(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_BER  ) ); 
        }
      pInst->vGetDABMonitorValueBER(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_BER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueBitrate(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_BITRATE  ) ); 
        }
      pInst->vGetDABMonitorValueBitrate(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_BITRATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueChannel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_CHANNEL  ) ); 
        }
      pInst->vGetDABMonitorValueChannel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_CHANNEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueComponenShorttLabel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_COMPONEN_SHORTT_LABEL  ) ); 
        }
      pInst->vGetDABMonitorValueComponenShorttLabel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_COMPONEN_SHORTT_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueComponentID(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_COMPONENT_ID  ) ); 
        }
      pInst->vGetDABMonitorValueComponentID(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_COMPONENT_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueComponentLabel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_COMPONENT_LABEL  ) ); 
        }
      pInst->vGetDABMonitorValueComponentLabel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_COMPONENT_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueDABMode(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_DAB_MODE  ) ); 
        }
      pInst->vGetDABMonitorValueDABMode(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_DAB_MODE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueDRC(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_DRC  ) ); 
        }
      pInst->vGetDABMonitorValueDRC(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_DRC | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueEnsembleID(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ENSEMBLE_ID  ) ); 
        }
      pInst->vGetDABMonitorValueEnsembleID(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ENSEMBLE_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueEnsembleLabel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ENSEMBLE_LABEL  ) ); 
        }
      pInst->vGetDABMonitorValueEnsembleLabel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ENSEMBLE_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueEnsembleShortLabel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ENSEMBLE_SHORT_LABEL  ) ); 
        }
      pInst->vGetDABMonitorValueEnsembleShortLabel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_ENSEMBLE_SHORT_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueFieldStrength(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_FIELD_STRENGTH  ) ); 
        }
      pInst->vGetDABMonitorValueFieldStrength(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_FIELD_STRENGTH | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueMode(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_MODE  ) ); 
        }
      pInst->vGetDABMonitorValueMode(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_MODE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueMSC(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_MSC  ) ); 
        }
      pInst->vGetDABMonitorValueMSC(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_MSC | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueMute(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_MUTE  ) ); 
        }
      pInst->vGetDABMonitorValueMute(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_MUTE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueProtectionLevel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_PROTECTION_LEVEL  ) ); 
        }
      pInst->vGetDABMonitorValueProtectionLevel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_PROTECTION_LEVEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValuePTY(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_PTY  ) ); 
        }
      pInst->vGetDABMonitorValuePTY(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_PTY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValues(GUI_String *out_result, ulword uwArrayIndex)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUES )  );
             poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&uwArrayIndex); 
        }
      pInst->vGetDABMonitorValues(out_result, uwArrayIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueSCID(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SCID  ) ); 
        }
      pInst->vGetDABMonitorValueSCID(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SCID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueServiceFollowing(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_FOLLOWING  ) ); 
        }
      pInst->vGetDABMonitorValueServiceFollowing(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_FOLLOWING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueServiceID(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_ID  ) ); 
        }
      pInst->vGetDABMonitorValueServiceID(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueServiceLabel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_LABEL  ) ); 
        }
      pInst->vGetDABMonitorValueServiceLabel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueServiceSF(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_SF  ) ); 
        }
      pInst->vGetDABMonitorValueServiceSF(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_SF | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueServiceShortLabel(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_SHORT_LABEL  ) ); 
        }
      pInst->vGetDABMonitorValueServiceShortLabel(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SERVICE_SHORT_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueStereoMode(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_STEREO_MODE  ) ); 
        }
      pInst->vGetDABMonitorValueStereoMode(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_STEREO_MODE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueSync(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SYNC  ) ); 
        }
      pInst->vGetDABMonitorValueSync(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_SYNC | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABMonitorValueTMC(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_TMC  ) ); 
        }
      pInst->vGetDABMonitorValueTMC(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_MONITOR_VALUE_TMC | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetDABReceptionValue( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_RECEPTION_VALUE  ) ); 
        }
      ret=pInst->ulwGetDABReceptionValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_RECEPTION_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetDABServiceLinking_Count( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING__COUNT  ) ); 
        }
      ret=pInst->ulwGetDABServiceLinking_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABServiceLinkingFreqLabel(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_FREQ_LABEL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDABServiceLinkingFreqLabel(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_FREQ_LABEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABServiceLinkingLinktype(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_LINKTYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDABServiceLinkingLinktype(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_LINKTYPE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABServiceLinkingPI(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_PI | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDABServiceLinkingPI(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_PI | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABServiceLinkingQuality(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_QUALITY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDABServiceLinkingQuality(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_QUALITY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetDABServiceLinkingValue( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_VALUE  ) ); 
        }
      ret=pInst->ulwGetDABServiceLinkingValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetDABTP_Frequency(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTP__FREQUENCY  ) ); 
        }
      pInst->vGetDABTP_Frequency(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTP__FREQUENCY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABTP_PI(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTP_PI  ) ); 
        }
      pInst->vGetDABTP_PI(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTP_PI | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDABTP_Quality(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTP__QUALITY  ) ); 
        }
      pInst->vGetDABTP_Quality(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DABTP__QUALITY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetDeadReckoningValues(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DEAD_RECKONING_VALUES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDeadReckoningValues(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DEAD_RECKONING_VALUES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_System_TestMode__blGetFreezeBackgroundTuner( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_FREEZE_BACKGROUND_TUNER  ) ); 
        }
      ret=pInst->blGetFreezeBackgroundTuner();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_FREEZE_BACKGROUND_TUNER | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System_TestMode__blGetDDAStatus( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DDA_STATUS  ) ); 
        }
      ret=pInst->blGetDDAStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_DDA_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetGPSValues(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_GPS_VALUES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetGPSValues(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_GPS_VALUES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_System_TestMode__blGetLinearAudio( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_LINEAR_AUDIO  ) ); 
        }
      ret=pInst->blGetLinearAudio();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_LINEAR_AUDIO | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetMapInfoValues(GUI_String *out_result, ulword ulwMedium)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_MAP_INFO_VALUES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMedium); 
        }
      pInst->vGetMapInfoValues(out_result, ulwMedium);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_MAP_INFO_VALUES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetMatchedPositionValues(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_MATCHED_POSITION_VALUES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetMatchedPositionValues(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_MATCHED_POSITION_VALUES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetMediaStatus(ulword ulwDrive)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_MEDIA_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDrive); 
        }
      ret=pInst->ulwGetMediaStatus(ulwDrive);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_MEDIA_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetOdometerDataUpdate(tbool blOdometerData)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_ODOMETER_DATA_UPDATE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blOdometerData); 
        }
      ret=pInst->ulwGetOdometerDataUpdate(blOdometerData);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_ODOMETER_DATA_UPDATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetResetCounterValue(GUI_String *out_result, ulword ulwCounter)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_RESET_COUNTER_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCounter); 
        }
      pInst->vGetResetCounterValue(out_result, ulwCounter);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_RESET_COUNTER_VALUE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_System_TestMode__blGetSDTrace( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SD_TRACE  ) ); 
        }
      ret=pInst->blGetSDTrace();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SD_TRACE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetServiceModeFieldStrength(ulword ulwType)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SERVICE_MODE_FIELD_STRENGTH | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      ret=pInst->ulwGetServiceModeFieldStrength(ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SERVICE_MODE_FIELD_STRENGTH | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetServiceModeQualityIndicatorValue( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SERVICE_MODE_QUALITY_INDICATOR_VALUE  ) ); 
        }
      ret=pInst->ulwGetServiceModeQualityIndicatorValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SERVICE_MODE_QUALITY_INDICATOR_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetServiceModeQualityString(GUI_String *out_result, ulword ulwType)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SERVICE_MODE_QUALITY_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwType); 
        }
      pInst->vGetServiceModeQualityString(out_result, ulwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SERVICE_MODE_QUALITY_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetSetupHighcut( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SETUP_HIGHCUT  ) ); 
        }
      ret=pInst->ulwGetSetupHighcut();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SETUP_HIGHCUT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetSetupSharx( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SETUP_SHARX  ) ); 
        }
      ret=pInst->ulwGetSetupSharx();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SETUP_SHARX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTemperatureDisplay(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TEMPERATURE_DISPLAY  ) ); 
        }
      pInst->vGetTemperatureDisplay(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TEMPERATURE_DISPLAY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetTemperatureGPS(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TEMPERATURE_GPS  ) ); 
        }
      pInst->vGetTemperatureGPS(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TEMPERATURE_GPS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetTMCLastMsgTimeDate(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_LAST_MSG_TIME_DATE  ) ); 
        }
      pInst->vGetTMCLastMsgTimeDate(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_LAST_MSG_TIME_DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetTMCNoOfMsgs(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_NO_OF_MSGS  ) ); 
        }
      pInst->vGetTMCNoOfMsgs(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_NO_OF_MSGS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetTMCNoOfMsgsSelectionArea(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_NO_OF_MSGS_SELECTION_AREA  ) ); 
        }
      pInst->vGetTMCNoOfMsgsSelectionArea(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_NO_OF_MSGS_SELECTION_AREA | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetTMCStation(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetTMCStation(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetTMCStation_Count( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION__COUNT  ) ); 
        }
      ret=pInst->ulwGetTMCStation_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTMCStationCountryCode(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION_COUNTRY_CODE  ) ); 
        }
      pInst->vGetTMCStationCountryCode(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION_COUNTRY_CODE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetTMCStationLTN( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION_LTN  ) ); 
        }
      ret=pInst->ulwGetTMCStationLTN();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION_LTN | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTMCStationPI(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION_PI  ) ); 
        }
      pInst->vGetTMCStationPI(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION_PI | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetTMCStationPS(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION_PS  ) ); 
        }
      pInst->vGetTMCStationPS(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION_PS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetTMCStationQuality(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION_QUALITY  ) ); 
        }
      pInst->vGetTMCStationQuality(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION_QUALITY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetTMCStationSID( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION_SID  ) ); 
        }
      ret=pInst->ulwGetTMCStationSID();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TMC_STATION_SID | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetTunerAF(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_AF | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerAF(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_AF | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetTunerAFListCount(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_AF_LIST_COUNT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerAFListCount(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_AF_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTunerAFListIndex(GUI_String *out_result, ulword ulwIndex)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_AF_LIST_INDEX | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vGetTunerAFListIndex(out_result, ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_AF_LIST_INDEX | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetTunerAntenna1(GUI_String *out_result, ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_ANTENNA1 | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vGetTunerAntenna1(out_result, ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_ANTENNA1 | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetTunerAntenna2(GUI_String *out_result, ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_ANTENNA2 | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vGetTunerAntenna2(out_result, ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_ANTENNA2 | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetTunerBER(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_BER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerBER(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_BER | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTunerFrequency(GUI_String *out_result, ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_FREQUENCY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vGetTunerFrequency(out_result, ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_FREQUENCY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetTunerFrequencyUnit(GUI_String *out_result, ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_FREQUENCY_UNIT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vGetTunerFrequencyUnit(out_result, ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_FREQUENCY_UNIT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetTunerFS(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_FS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerFS(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_FS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTunerCalData(GUI_String *out_result, ulword ulwCalibration)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_CAL_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwCalibration); 
        }
      pInst->vGetTunerCalData(out_result, ulwCalibration);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_CAL_DATA | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vExitAFList( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__EXIT_AF_LIST  ) ); 
        }
      pInst->vExitAFList();

    }
}

ulword HSA_System_TestMode__ulwGetTunerHC(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_HC | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerHC(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_HC | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTunerHUB(GUI_String *out_result, ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_HUB | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vGetTunerHUB(out_result, ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_HUB | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetTunerMode( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_MODE  ) ); 
        }
      ret=pInst->ulwGetTunerMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetTunerModeSetup( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_MODE_SETUP  ) ); 
        }
      ret=pInst->ulwGetTunerModeSetup();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_MODE_SETUP | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTunerMultiPath(GUI_String *out_result, ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_MULTI_PATH | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vGetTunerMultiPath(out_result, ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_MULTI_PATH | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetActiveBand(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_BAND | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetActiveBand(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_BAND | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vSetActiveBand(ulword ulwBand)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_ACTIVE_BAND | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBand); 
        }
      pInst->vSetActiveBand(ulwBand);

    }
}

void HSA_System_TestMode__vGetTunerNeighbourChannel(GUI_String *out_result, ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_NEIGHBOUR_CHANNEL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vGetTunerNeighbourChannel(out_result, ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_NEIGHBOUR_CHANNEL | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_System_TestMode__blGetTunerMeasureMode( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_MEASURE_MODE  ) ); 
        }
      ret=pInst->blGetTunerMeasureMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_MEASURE_MODE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System_TestMode__blGetTunerRDSReg( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_RDS_REG  ) ); 
        }
      ret=pInst->blGetTunerRDSReg();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_RDS_REG | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTunerPI(GUI_String *out_result, ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_PI | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vGetTunerPI(out_result, ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_PI | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetTunerPS(GUI_String *out_result, ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_PS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vGetTunerPS(out_result, ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_PS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_System_TestMode__blIsHDRadioActive(ulword ulwTuner)
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__IS_HD_RADIO_ACTIVE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->blIsHDRadioActive(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__IS_HD_RADIO_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTunerCallSign(GUI_String *out_result, ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_CALL_SIGN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vGetTunerCallSign(out_result, ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_CALL_SIGN | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetTunerCDNo(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_CD_NO | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerCDNo(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_CD_NO | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetTunerHDStationID(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_HD_STATION_ID | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerHDStationID(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_HD_STATION_ID | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetTunerRDSErrorRate(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_RDS_ERROR_RATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerRDSErrorRate(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_RDS_ERROR_RATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetTunerRDSErrorRateService(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_RDS_ERROR_RATE_SERVICE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerRDSErrorRateService(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_RDS_ERROR_RATE_SERVICE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetTunerSharx(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_SHARX | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerSharx(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_SHARX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetTunerSignalQuality(GUI_String *out_result, ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_SIGNAL_QUALITY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vGetTunerSignalQuality(out_result, ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_SIGNAL_QUALITY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetTunerCS(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_CS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerCS(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_CS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System_TestMode__blGetTASetup( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TA_SETUP  ) ); 
        }
      ret=pInst->blGetTASetup();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TA_SETUP | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vToggleTASetup( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_TA_SETUP  ) ); 
        }
      pInst->vToggleTASetup();

    }
}

void HSA_System_TestMode__vGetTunerPD(GUI_String *out_result, ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_PD | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vGetTunerPD(out_result, ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_PD | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vToggleRDSReg( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_RDS_REG  ) ); 
        }
      pInst->vToggleRDSReg();

    }
}

void HSA_System_TestMode__vToggleMeasureMode( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_MEASURE_MODE  ) ); 
        }
      pInst->vToggleMeasureMode();

    }
}

ulword HSA_System_TestMode__ulwGetTunerTA(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_TA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerTA(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_TA | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetTunerTP(ulword ulwTuner)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_TP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      ret=pInst->ulwGetTunerTP(ulwTuner);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TUNER_TP | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetValidAFItem(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_VALID_AF_ITEM | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetValidAFItem(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_VALID_AF_ITEM | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_System_TestMode__ulwGetValidAFItemCount( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_VALID_AF_ITEM_COUNT  ) ); 
        }
      ret=pInst->ulwGetValidAFItemCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_VALID_AF_ITEM_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetVersion(GUI_String *out_result, ulword ulwVersion)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_VERSION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwVersion); 
        }
      pInst->vGetVersion(out_result, ulwVersion);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vBTDevTestToggleECNREngineStatus( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_TOGGLE_ECNR_ENGINE_STATUS  ) ); 
        }
      pInst->vBTDevTestToggleECNREngineStatus();

    }
}

tbool HSA_System_TestMode__blBTDevTestGetECNREngineStatus( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_ECNR_ENGINE_STATUS  ) ); 
        }
      ret=pInst->blBTDevTestGetECNREngineStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_ECNR_ENGINE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vBTDevTestSetHCIModeStatus(tbool blValue)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_SET_HCI_MODE_STATUS | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blValue); 
        }
      pInst->vBTDevTestSetHCIModeStatus(blValue);

    }
}

tbool HSA_System_TestMode__blBTDevTestGetHCIModeStatus( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_HCI_MODE_STATUS  ) ); 
        }
      ret=pInst->blBTDevTestGetHCIModeStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_HCI_MODE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vBTDevTestSetFrequency(ulword ulwValue)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_SET_FREQUENCY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwValue); 
        }
      pInst->vBTDevTestSetFrequency(ulwValue);

    }
}

ulword HSA_System_TestMode__ulwBTDevTestGetFrequency( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_FREQUENCY  ) ); 
        }
      ret=pInst->ulwBTDevTestGetFrequency();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_FREQUENCY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vBTDevTestSetPacketType(ulword ulwValue)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_SET_PACKET_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwValue); 
        }
      pInst->vBTDevTestSetPacketType(ulwValue);

    }
}

ulword HSA_System_TestMode__ulwBTDevTestGetPacketType( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_PACKET_TYPE  ) ); 
        }
      ret=pInst->ulwBTDevTestGetPacketType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_PACKET_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vBTDevTestSetModulationValue(ulword ulwValue)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_SET_MODULATION_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwValue); 
        }
      pInst->vBTDevTestSetModulationValue(ulwValue);

    }
}

ulword HSA_System_TestMode__ulwBTDevTestGetModulationValue( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_MODULATION_VALUE  ) ); 
        }
      ret=pInst->ulwBTDevTestGetModulationValue();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_MODULATION_VALUE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vBTDevRunTest(ulword ulwTest)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_RUN_TEST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTest); 
        }
      pInst->vBTDevRunTest(ulwTest);

    }
}

void HSA_System_TestMode__vBTDevStopTest( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_STOP_TEST  ) ); 
        }
      pInst->vBTDevStopTest();

    }
}

void HSA_System_TestMode__vBTDevTestGetTestValues(GUI_String *out_result, ulword ulwTestParameter)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_TEST_VALUES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTestParameter); 
        }
      pInst->vBTDevTestGetTestValues(out_result, ulwTestParameter);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_TEST_VALUES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetWheel1RPM(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_WHEEL1RPM  ) ); 
        }
      pInst->vGetWheel1RPM(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_WHEEL1RPM | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vBTDevTestGetLinkKey(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_LINK_KEY  ) ); 
        }
      pInst->vBTDevTestGetLinkKey(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__BT_DEV_TEST_GET_LINK_KEY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetWheel2RPM(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_WHEEL2RPM  ) ); 
        }
      pInst->vGetWheel2RPM(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_WHEEL2RPM | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetWheel3RPM(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_WHEEL3RPM  ) ); 
        }
      pInst->vGetWheel3RPM(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_WHEEL3RPM | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetWheel4RPM(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_WHEEL4RPM  ) ); 
        }
      pInst->vGetWheel4RPM(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_WHEEL4RPM | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vGetWheelCircumference(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_WHEEL_CIRCUMFERENCE  ) ); 
        }
      pInst->vGetWheelCircumference(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_WHEEL_CIRCUMFERENCE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vIncreaseDABFader(ulword ulwFader)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__INCREASE_DAB_FADER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwFader); 
        }
      pInst->vIncreaseDABFader(ulwFader);

    }
}

tbool HSA_System_TestMode__blIsAntenna2Available( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__IS_ANTENNA2_AVAILABLE  ) ); 
        }
      ret=pInst->blIsAntenna2Available();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__IS_ANTENNA2_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_System_TestMode__blIsDevelopermodeEnabled( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__IS_DEVELOPERMODE_ENABLED  ) ); 
        }
      ret=pInst->blIsDevelopermodeEnabled();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__IS_DEVELOPERMODE_ENABLED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vRestoreDefaultSettings( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__RESTORE_DEFAULT_SETTINGS  ) ); 
        }
      pInst->vRestoreDefaultSettings();

    }
}

void HSA_System_TestMode__vSelectTMCStation(ulword ulwListEntryNr)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SELECT_TMC_STATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSelectTMCStation(ulwListEntryNr);

    }
}

void HSA_System_TestMode__vSetActiveTuner(ulword ulwTuner)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_ACTIVE_TUNER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTuner); 
        }
      pInst->vSetActiveTuner(ulwTuner);

    }
}

void HSA_System_TestMode__vSetDABConcealmentLevelValue(ulword ulwConcealmentLevelValue)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_DAB_CONCEALMENT_LEVEL_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwConcealmentLevelValue); 
        }
      pInst->vSetDABConcealmentLevelValue(ulwConcealmentLevelValue);

    }
}

void HSA_System_TestMode__vSetDABFaderPosition(ulword ulwFader, slword slwValue)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_DAB_FADER_POSITION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwFader); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_DAB_FADER_POSITION | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwValue); 
        }
      pInst->vSetDABFaderPosition(ulwFader, slwValue);

    }
}

void HSA_System_TestMode__vSetDABReceptionValue(ulword ulwDABReceptionValue)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_DAB_RECEPTION_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDABReceptionValue); 
        }
      pInst->vSetDABReceptionValue(ulwDABReceptionValue);

    }
}

void HSA_System_TestMode__vSetDABServiceLinkingValue(ulword ulwServiceLinkingValue)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_DAB_SERVICE_LINKING_VALUE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwServiceLinkingValue); 
        }
      pInst->vSetDABServiceLinkingValue(ulwServiceLinkingValue);

    }
}

void HSA_System_TestMode__vSetHighcut(tbool blDirection)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_HIGHCUT | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blDirection); 
        }
      pInst->vSetHighcut(blDirection);

    }
}

void HSA_System_TestMode__vSetRadioTestModeActive(ulword ulwenable)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_RADIO_TEST_MODE_ACTIVE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwenable); 
        }
      pInst->vSetRadioTestModeActive(ulwenable);

    }
}

void HSA_System_TestMode__vSetSetupSharx(tbool blDirection)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_SETUP_SHARX | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blDirection); 
        }
      pInst->vSetSetupSharx(blDirection);

    }
}

void HSA_System_TestMode__vSetTunerModeSetup(ulword ulwMode)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_TUNER_MODE_SETUP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMode); 
        }
      pInst->vSetTunerModeSetup(ulwMode);

    }
}

void HSA_System_TestMode__vSetTuneToAF(ulword ulwListEntryNr)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_TUNE_TO_AF | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetTuneToAF(ulwListEntryNr);

    }
}

void HSA_System_TestMode__vToggelLinearAudio( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__TOGGEL_LINEAR_AUDIO  ) ); 
        }
      pInst->vToggelLinearAudio();

    }
}

void HSA_System_TestMode__vToggleAFValue( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_AF_VALUE  ) ); 
        }
      pInst->vToggleAFValue();

    }
}

void HSA_System_TestMode__vToggleFreezeBackgroundTuner( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_FREEZE_BACKGROUND_TUNER  ) ); 
        }
      pInst->vToggleFreezeBackgroundTuner();

    }
}

void HSA_System_TestMode__vToggleDDAState( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_DDA_STATE  ) ); 
        }
      pInst->vToggleDDAState();

    }
}

void HSA_System_TestMode__vSetRadioTMEnter( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SET_RADIO_TM_ENTER  ) ); 
        }
      pInst->vSetRadioTMEnter();

    }
}

void HSA_System_TestMode__vToggleSDTrace( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_SD_TRACE  ) ); 
        }
      pInst->vToggleSDTrace();

    }
}

ulword HSA_System_TestMode__ulwGetCsmEngineering_Count( )
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CSM_ENGINEERING__COUNT  ) ); 
        }
      ret=pInst->ulwGetCsmEngineering_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CSM_ENGINEERING__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vStartCsmEngineering( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__START_CSM_ENGINEERING  ) ); 
        }
      pInst->vStartCsmEngineering();

    }
}

void HSA_System_TestMode__vGetCsmEngineeringData(GUI_String *out_result, ulword ulwListEntryNumber)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CSM_ENGINEERING_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      pInst->vGetCsmEngineeringData(out_result, ulwListEntryNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_CSM_ENGINEERING_DATA | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vCreateScreenShot( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__CREATE_SCREEN_SHOT  ) ); 
        }
      pInst->vCreateScreenShot();

    }
}

tbool HSA_System_TestMode__blGetScreenShotState( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SCREEN_SHOT_STATE  ) ); 
        }
      ret=pInst->blGetScreenShotState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SCREEN_SHOT_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vToggleScreenShotSetting( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_SCREEN_SHOT_SETTING  ) ); 
        }
      pInst->vToggleScreenShotSetting();

    }
}

tbool HSA_System_TestMode__blGetScreenShotSetting( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SCREEN_SHOT_SETTING  ) ); 
        }
      ret=pInst->blGetScreenShotSetting();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SCREEN_SHOT_SETTING | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vScreenShotResetState( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__SCREEN_SHOT_RESET_STATE  ) ); 
        }
      pInst->vScreenShotResetState();

    }
}

void HSA_System_TestMode__vGetSXMServiceDTMMonData(GUI_String *out_result, ulword ulwLineNo)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SERVICE_DTM_MON_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLineNo); 
        }
      pInst->vGetSXMServiceDTMMonData(out_result, ulwLineNo);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SERVICE_DTM_MON_DATA | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vActivateSXMDTM(ulword ulwAction)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_SXMDTM | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwAction); 
        }
      pInst->vActivateSXMDTM(ulwAction);

    }
}

void HSA_System_TestMode__vClearSXMDTMFunctions(ulword ulwLineNo)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__CLEAR_SXMDTM_FUNCTIONS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLineNo); 
        }
      pInst->vClearSXMDTMFunctions(ulwLineNo);

    }
}

tbool HSA_System_TestMode__blExternalDiagModeState( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__EXTERNAL_DIAG_MODE_STATE  ) ); 
        }
      ret=pInst->blExternalDiagModeState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__EXTERNAL_DIAG_MODE_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vToggleExternalDiagMode( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_EXTERNAL_DIAG_MODE  ) ); 
        }
      pInst->vToggleExternalDiagMode();

    }
}

ulword HSA_System_TestMode__ulwGetSXMSettingsMenuData(ulword ulwLineNo)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SETTINGS_MENU_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLineNo); 
        }
      ret=pInst->ulwGetSXMSettingsMenuData(ulwLineNo);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_SETTINGS_MENU_DATA | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vTriggerNavSamplePrompt( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__TRIGGER_NAV_SAMPLE_PROMPT  ) ); 
        }
      pInst->vTriggerNavSamplePrompt();

    }
}

void HSA_System_TestMode__vGetSXMRadioID(GUI_String *out_result)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_RADIO_ID  ) ); 
        }
      pInst->vGetSXMRadioID(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_RADIO_ID | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_System_TestMode__vStartMethodforUPCLID( )
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__START_METHODFOR_UPCLID  ) ); 
        }
      pInst->vStartMethodforUPCLID();

    }
}

tbool HSA_System_TestMode__blWaitSyncforSXMDiag( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNCFOR_SXM_DIAG  ) ); 
        }
      ret=pInst->blWaitSyncforSXMDiag();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__WAIT_SYNCFOR_SXM_DIAG | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetSXMSTMDataParam1(ulword ulwLineNo)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SXMSTM_DATA_PARAM1 | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLineNo); 
        }
      ret=pInst->ulwGetSXMSTMDataParam1(ulwLineNo);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SXMSTM_DATA_PARAM1 | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_TestMode__vGetSXMSTMDataParam2(GUI_String *out_result, ulword ulwLineNo)
{
    
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SXMSTM_DATA_PARAM2 | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLineNo); 
        }
      pInst->vGetSXMSTMDataParam2(out_result, ulwLineNo);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SXMSTM_DATA_PARAM2 | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_System_TestMode__blGetSxmDTMPopupStatus( )
{
    tbool ret = false;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_DTM_POPUP_STATUS  ) ); 
        }
      ret=pInst->blGetSxmDTMPopupStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_SXM_DTM_POPUP_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_System_TestMode__ulwGetTouchCordinate(ulword ulwX_Y_Coordinate, ulword ulwRow)
{
    ulword ret = 0;
    clHSA_System_TestMode_Base *pInst=clHSA_System_TestMode_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TOUCH_CORDINATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwX_Y_Coordinate); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TOUCH_CORDINATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRow); 
        }
      ret=pInst->ulwGetTouchCordinate(ulwX_Y_Coordinate, ulwRow);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_TESTMODE), (tU16)(HSA_API_ENTRYPOINT__GET_TOUCH_CORDINATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

#ifdef __cplusplus
}
#endif

