/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_System_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_System_Wrapper_dbg.h"
#include "clHSA_System_Base.h"
#include "HSA_System_Trace.h"
#include "HSA_System_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_System_Wrapper_dbg::~clHSA_System_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_System_Wrapper_dbg::clHSA_System_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_System_Wrapper_dbg::clHSA_System_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_System_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_System_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__START_TOUCH_SCREEN_CALIBRATION:

            HSA_System__vStartTouchScreenCalibration();
            break;

        case HSA_API_ENTRYPOINT__ABORT_TOUCH_SCREEN_CALIBRATION:

            HSA_System__vAbortTouchScreenCalibration();
            break;

        case HSA_API_ENTRYPOINT__GET_CALIBRATION_PAGE_NUMBER:

            HSA_System__ulwGetCalibrationPageNumber();
            break;

        case HSA_API_ENTRYPOINT__NEW_CALIBRATION_PAGE_DRAWN:

            HSA_System__vNewCalibrationPageDrawn();
            break;

        case HSA_API_ENTRYPOINT__AUTO_MODE_ENABLE_DISABLE:

            HSA_System__blAutoModeEnableDisable();
            break;

        case HSA_API_ENTRYPOINT__GET_CALIBRATION_STATUS:

            HSA_System__ulwGetCalibrationStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_KDS_DATA:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vGetKDSData(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__CHECK_CLOCK_SCREEN_MODE:

            HSA_System__vCheckClockScreenMode();
            break;

        case HSA_API_ENTRYPOINT__SET_CLOCK_SCREEN_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System__vSetClockScreenMode(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_CLOCK_SCREEN_TIMER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System__vSetClockScreenTimer(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_APPLICATION_PALETTE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetApplicationPalette(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__RESET_TRANSITION_COUNTER:

            HSA_System__vResetTransitionCounter();
            break;

        case HSA_API_ENTRYPOINT__INCREMENT_TRANSITION_COUNTER:

            HSA_System__vIncrementTransitionCounter();
            break;

        case HSA_API_ENTRYPOINT__DECREMENT_TRANSITION_COUNTER:

            HSA_System__vDecrementTransitionCounter();
            break;

        case HSA_API_ENTRYPOINT__GET_VERSION:

            HSA_System__vGetVersion();
            break;

        case HSA_API_ENTRYPOINT__IS_OVER_SPEED_ACTIVE:

            HSA_System__blIsOverSpeedActive();
            break;

        case HSA_API_ENTRYPOINT__GET_ECO_DRIVING_DATA_SYMBOL_TYPE:

            HSA_System__ulwGetEcoDrivingDataSymbolType();
            break;

        case HSA_API_ENTRYPOINT__GET_ECO_DRIVING_SCORE:

            HSA_System__ulwGetEcoDrivingScore();
            break;

        case HSA_API_ENTRYPOINT__GET_ECO_PULLING_AWAY_SCORE:

            HSA_System__ulwGetEcoPullingAwayScore();
            break;

        case HSA_API_ENTRYPOINT__GET_ECO_CRUISE_SCORE:

            HSA_System__ulwGetEcoCruiseScore();
            break;

        case HSA_API_ENTRYPOINT__GET_ECO_DECELERATION_SCORE:

            HSA_System__ulwGetEcoDecelerationScore();
            break;

        case HSA_API_ENTRYPOINT__GET_ECO_D_DRIVING_HISTORY_VALUES:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetEcoDDrivingHistoryValues(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ECO_D_DRIVING_HISTORY_DATE_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vGetEcoDDrivingHistoryDateString(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_ECO_D_DRIVING_HISTORY_DATE_MONTH:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetEcoDDrivingHistoryDateMonth(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ECO_D_DRIVING_HISTORY_DATE_DAY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetEcoDDrivingHistoryDateDay(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__RESET_ECO_DRIVING_HISTORY:

            HSA_System__vResetEcoDrivingHistory();
            break;

        case HSA_API_ENTRYPOINT__XML_VERSION_CHECK_STATUS:

            HSA_System__ulwXMLVersionCheckStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_XML_VERSION_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vGetXMLVersionString(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_METER_AUDIO_WARNING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam2, aubBuffer2, sizeof(aubBuffer2)); 
            GUI_String_vSetCStr(&gsParam2, tmpBuffer);
            HSA_System__vSetMeterAudioWarning(ulParam1, &gsParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_METER_SMS_POPUP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vSetMeterSMSPopup(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_SMS_MESSAGE_TEXT_POPUP_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System__vSetSMSMessageTextPopupState(usParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_METER_CONNECTED:

            HSA_System__blIsMeterConnected();
            break;

        case HSA_API_ENTRYPOINT__SET_XML_VERSION_DISCLAIMER_ACCEPTANCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System__vSetXMLVersionDisclaimerAcceptance(usParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_XML_VERSION_DISCLAIMER_ACCEPTANCE:

            HSA_System__blGetXMLVersionDisclaimerAcceptance();
            break;

        case HSA_API_ENTRYPOINT__GET_SRV_SYSTEM_SELF_TEST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetSrvSystemSelfTest(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SRV_SD_CARD_WRITE_PROTECTION_STATUS:

            HSA_System__ulwGetSrvSDCardWriteProtectionStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_IMMOBILIZER_LOCK_STATE:

            HSA_System__ulwGetImmobilizerLockState();
            break;

        case HSA_API_ENTRYPOINT__SET_IMMOBILIZER_LOCK_STATE_TO_UN_LOCK:

            HSA_System__vSetImmobilizerLockStateToUnLock();
            break;

        case HSA_API_ENTRYPOINT__GET_SRV_SYSTEM_CONFIG:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetSrvSystemConfig(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_XM_TUNER_FIRMWARE_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetXMTunerFirmwareVersion(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_BTHF__BOX_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetBTHF_BoxVersion(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DISPLAY_MODE:

            HSA_System__ulwGetDisplayMode();
            break;

        case HSA_API_ENTRYPOINT__GET_DISPLAY_TEST_SCREEN:

            HSA_System__ulwGetDisplayTestScreen();
            break;

        case HSA_API_ENTRYPOINT__GET_NAV_DISCLAIMER_CONFIRMED:

            HSA_System__blGetNavDisclaimerConfirmed();
            break;

        case HSA_API_ENTRYPOINT__SET_NAV_DISCLAIMER_CONFIRMED:

            HSA_System__vSetNavDisclaimerConfirmed();
            break;

        case HSA_API_ENTRYPOINT__DISABLE_DESTINATION_INPUT_WHILE_DRIVING:

            HSA_System__vDisableDestinationInputWhileDriving();
            break;

        case HSA_API_ENTRYPOINT__GET_DESTINATION_INPUT_WHILE_DRIVING:

            HSA_System__blGetDestinationInputWhileDriving();
            break;

        case HSA_API_ENTRYPOINT__SET_BEEP_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetBeepMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_BEEP_MODE:

            HSA_System__ulwGetBeepMode();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_DISPLAY_MODE:

            HSA_System__vToggleDisplayMode();
            break;

        case HSA_API_ENTRYPOINT__LANGUAGE_ICON_SELECTED:

            HSA_System__vLanguageIconSelected();
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_SERIAL_NO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSystemSerialNo(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_DEVICE_NO:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSystemDeviceNo(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_PRODUCTION_DATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSystemProductionDate(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__PERFORM_SPEAKER_TEST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vPerformSpeakerTest(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_ENCODER_DIRECTION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetEncoderDirection(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ENCODER_DIRECTION:

            HSA_System__blGetEncoderDirection();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_SELF_TEST_PROGRESS_VALUE:

            HSA_System__ulwGetCurrentSelfTestProgressValue();
            break;

        case HSA_API_ENTRYPOINT__SET_RVC_FLAG:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System__vSetRVCFlag(usParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CAMERA_DISPLAY_SETTINGS_POPUP_STATE:

            HSA_System__ulwGetCameraDisplaySettingsPopupState();
            break;

        case HSA_API_ENTRYPOINT__SWITCH_TO_CAMERA_SCREEN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vSwitchToCameraScreen(usParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_GUIDE_LINE_STATE:

            HSA_System__vToggleGuideLineState();
            break;

        case HSA_API_ENTRYPOINT__GET_RVC_GUIDE_LINE_STATUS:

            HSA_System__ulwGetRVCGuideLineStatus();
            break;

        case HSA_API_ENTRYPOINT__INFORM_CAMERA_HK_PRESS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System__vInformCameraHKPress(usParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CAMERA_SYSTEM_CONFIGURED:

            HSA_System__ulwGetCameraSystemConfigured();
            break;

        case HSA_API_ENTRYPOINT__GET_CAMERA_REQUEST_STATE:

            HSA_System__ulwGetCameraRequestState();
            break;

        case HSA_API_ENTRYPOINT__IS_CAMERA_REQ_TIME_OUT_REQUIRED:

            HSA_System__blIsCameraReqTimeOutRequired();
            break;

        case HSA_API_ENTRYPOINT__IS_CAMERA_REQUEST_ACTIVE:

            HSA_System__blIsCameraRequestActive();
            break;

        case HSA_API_ENTRYPOINT__IS_VIDEO_SIGNAL_AVAILABLE:

            HSA_System__blIsVideoSignalAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_AVM_REQUEST_ACTIVE:

            HSA_System__blIsAVMRequestActive();
            break;

        case HSA_API_ENTRYPOINT__IS_AFFORDABLE_ITS_AVAILABLE:

            HSA_System__blIsAffordableITSAvailable();
            break;

        case HSA_API_ENTRYPOINT__SWITCH_OFF_CAMERA:

            HSA_System__vSwitchOffCamera();
            break;

        case HSA_API_ENTRYPOINT__GET_CAMERA_CONFIG_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetCameraConfigStatus(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_CAMERA_CONFIG_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vToggleCameraConfigStatus(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_VIDEO_DIMMING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetVideoDimming(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__INFORM_AVM_ON_PURPOSE_SWITCH:

            HSA_System__vInformAVMOnPurposeSwitch();
            break;

        case HSA_API_ENTRYPOINT__SET_VIDEO_DIMMING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam2); 

            HSA_System__vSetVideoDimming(ulParam1, usParam2);
            break;

        case HSA_API_ENTRYPOINT__IPA__SEND_BUTTON_PRESS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vIPA_SendButtonPress(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__IPA__SET_HMI_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System__vIPA_SetHMIStatus(usParam1);
            break;

        case HSA_API_ENTRYPOINT__IPA__GET_AVAILABLITY_STATUS:

            HSA_System__ulwIPA_GetAvailablityStatus();
            break;

        case HSA_API_ENTRYPOINT__IPA__GET_CONFIGURED_REGION:

            HSA_System__ulwIPA_GetConfiguredRegion();
            break;

        case HSA_API_ENTRYPOINT__IPA__GET_MESSAGE_REQUESTED:

            HSA_System__ulwIPA_GetMessageRequested();
            break;

        case HSA_API_ENTRYPOINT__IPA__GET_PATTERN_REQUESTED:

            HSA_System__ulwIPA_GetPatternRequested();
            break;

        case HSA_API_ENTRYPOINT__IPA__GET_POPUP_REQUESTED:

            HSA_System__ulwIPA_GetPopupRequested();
            break;

        case HSA_API_ENTRYPOINT__IPA__GET_OPERATION_STATUS:

            HSA_System__ulwIPA_GetOperationStatus();
            break;

        case HSA_API_ENTRYPOINT__IPA__GET_MODE:

            HSA_System__ulwIPA_GetMode();
            break;

        case HSA_API_ENTRYPOINT__IPA__GET_CAR_DIRECTION__INDICATOR__STATUS:

            HSA_System__ulwIPA_GetCarDirection_Indicator_Status();
            break;

        case HSA_API_ENTRYPOINT__IPA__GET_BUTTON_VISIBILITY_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwIPA_GetButtonVisibilityStatus(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_VISUALIZATION_STATUS:

            HSA_System__blSONAR_GetVisualizationStatus();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_CAR_SHAPE_MODEL:

            HSA_System__ulwSONAR_GetCarShapeModel();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_AVAILABILITY_STATUS:

            HSA_System__ulwSONAR_GetAvailabilityStatus();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_SONAR_SWITCH_AVAILABILITY:

            HSA_System__blSONAR_GetSonarSwitchAvailability();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_ERROR_STATUS:

            HSA_System__blSONAR_GetErrorStatus();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_FRONT_SENSOR_AVAILABILITY:

            HSA_System__ulwSONAR_GetFrontSensorAvailability();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_REAR_SENSOR_AVAILABILITY:

            HSA_System__ulwSONAR_GetRearSensorAvailability();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_FRONT_SENSOR_DISTANCE_LEVELS:

            HSA_System__ulwSONAR_GetFrontSensorDistanceLevels();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_REAR_SENSOR_DISTANCE_LEVELS:

            HSA_System__ulwSONAR_GetRearSensorDistanceLevels();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_SYSTEM_STATUS:

            HSA_System__blSONAR_GetSystemStatus();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_FRONT_SENSORS_ONLY_STATUS:

            HSA_System__blSONAR_GetFrontSensorsOnlyStatus();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_AUTOMATIC_DISPLAY_STATUS:

            HSA_System__blSONAR_GetAutomaticDisplayStatus();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_SENSITIVITY_LEVEL:

            HSA_System__ulwSONAR_GetSensitivityLevel();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_VOLUME_LEVEL:

            HSA_System__ulwSONAR_GetVolumeLevel();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_SONAR_CANCEL_SWITCH_STATUS:

            HSA_System__vToggleSonarCancelSwitchStatus();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_SONAR_SYSTEM_OPTION:

            HSA_System__vToggleSonarSystemOption();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_FRONT_SENSORS_ONLY_OPTION:

            HSA_System__vToggleFrontSensorsOnlyOption();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_AUTOMATIC_DISPLAY_OPTION:

            HSA_System__vToggleAutomaticDisplayOption();
            break;

        case HSA_API_ENTRYPOINT__SET_SONAR_SENSITIVITY_LEVEL:

            HSA_System__vSetSonarSensitivityLevel();
            break;

        case HSA_API_ENTRYPOINT__SET_SONAR_VOLUME_LEVEL:

            HSA_System__vSetSonarVolumeLevel();
            break;

        case HSA_API_ENTRYPOINT__SONAR__GET_SONAR_MENU:

            HSA_System__ulwSONAR_GetSonarMenu();
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_CONFIG:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vGetSystemConfig(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_HISTORY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vGetSystemHistory(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_SELF_TEST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vGetSystemSelfTest(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__START_SELF_TEST:

            HSA_System__vStartSelfTest();
            break;

        case HSA_API_ENTRYPOINT__GET_USB_SLOT_MEDIUM:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetUSBSlotMedium(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_VIA_GPS_TIME_STATUS:

            HSA_System__ulwGetViaGPSTimeStatus();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_VIA_GPS_TIME_STATUS:

            HSA_System__vToggleViaGPSTimeStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_SUMMER_TIME_STATUS:

            HSA_System__blGetSummerTimeStatus();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_SUMMER_TIME_STATUS:

            HSA_System__vToggleSummerTimeStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_TZ:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetCurrentTZ(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_TZ_INDEX:

            HSA_System__ulwGetCurrentTZIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_TZ_LIST_COUNT:

            HSA_System__ulwGetTZListCount();
            break;

        case HSA_API_ENTRYPOINT__GET_TZ_LIST_ELEMENT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vGetTZListElement(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_TZ:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetTZ(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__INCREASE_TIME_HOUR:

            HSA_System__vIncreaseTimeHour();
            break;

        case HSA_API_ENTRYPOINT__DATE_HANDLING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam2); 

            HSA_System__vDateHandling(ulParam1, usParam2);
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_DATE_FORMAT:

            HSA_System__vToggleDateFormat();
            break;

        case HSA_API_ENTRYPOINT__GET_DATE_FORMAT:

            HSA_System__ulwGetDateFormat();
            break;

        case HSA_API_ENTRYPOINT__DECREASE_TIME_HOUR:

            HSA_System__vDecreaseTimeHour();
            break;

        case HSA_API_ENTRYPOINT__GET_TIME_HOUR:

            HSA_System__ulwGetTimeHour();
            break;

        case HSA_API_ENTRYPOINT__INCREASE_TIME_MINUTE:

            HSA_System__vIncreaseTimeMinute();
            break;

        case HSA_API_ENTRYPOINT__INCREASE_DATE_DAY:

            HSA_System__vIncreaseDateDay();
            break;

        case HSA_API_ENTRYPOINT__INCREASE_DATE_MONTH:

            HSA_System__vIncreaseDateMonth();
            break;

        case HSA_API_ENTRYPOINT__INCREASE_DATE_YEAR:

            HSA_System__vIncreaseDateYear();
            break;

        case HSA_API_ENTRYPOINT__DECREASE_TIME_MINUTE:

            HSA_System__vDecreaseTimeMinute();
            break;

        case HSA_API_ENTRYPOINT__DECREASE_DATE_DAY:

            HSA_System__vDecreaseDateDay();
            break;

        case HSA_API_ENTRYPOINT__DECREASE_DATE_MONTH:

            HSA_System__vDecreaseDateMonth();
            break;

        case HSA_API_ENTRYPOINT__DECREASE_DATE_YEAR:

            HSA_System__vDecreaseDateYear();
            break;

        case HSA_API_ENTRYPOINT__GET_TIME_MINUTE:

            HSA_System__ulwGetTimeMinute();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_FIRST_MEDIA_DATA:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vActivateFirstMediaData(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ARE_REAR_SPEAKERS_ASSEMBLED:

            HSA_System__blAreRearSpeakersAssembled();
            break;

        case HSA_API_ENTRYPOINT__CANCEL_SOFTWARE_DOWNLOAD:

            HSA_System__vCancelSoftwareDownload();
            break;

        case HSA_API_ENTRYPOINT__CHECK_ASSEMBLY_UNLOCK:

            HSA_System__blCheckAssemblyUnlock();
            break;

        case HSA_API_ENTRYPOINT__CHECK_CODE:

            HSA_System__ulwCheckCode();
            break;

        case HSA_API_ENTRYPOINT__CHECK_SD_CODE:

            HSA_System__ulwCheckSDCode();
            break;

        case HSA_API_ENTRYPOINT__CHECK_COMFORT_CODING:

            HSA_System__ulwCheckComfortCoding();
            break;

        case HSA_API_ENTRYPOINT__CHECK_SD_PAIRED:

            HSA_System__ulwCheckSDPaired();
            break;

        case HSA_API_ENTRYPOINT__CHECK_SDPIN_REQUIREMENT:

            HSA_System__ulwCheckSDPINRequirement();
            break;

        case HSA_API_ENTRYPOINT__CHECK_SPELLER_DISCLAIMER:

            HSA_System__vCheckSpellerDisclaimer();
            break;

        case HSA_API_ENTRYPOINT__CODE_INPUT:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_System__vCodeInput(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SD_CODE_INPUT:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_System__vSDCodeInput(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SETUP_GET_PRESET_MENU:

            HSA_System__blSetupGetPresetMenu();
            break;

        case HSA_API_ENTRYPOINT__SETUP_SET_PRESET_MENU:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System__vSetupSetPresetMenu(usParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SIZEOF_DISPLAY:

            HSA_System__ulwGetSizeofDisplay();
            break;

        case HSA_API_ENTRYPOINT__CREATE_BEEP:

            HSA_System__vCreateBeep();
            break;

        case HSA_API_ENTRYPOINT__CREATE_BEEP_X:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vCreateBeepX(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__EJECT_CD:

            HSA_System__vEjectCD();
            break;

        case HSA_API_ENTRYPOINT__GET_ACOUSTIC_TOUCHSCREEN_FEEDBACK:

            HSA_System__ulwGetAcousticTouchscreenFeedback();
            break;

        case HSA_API_ENTRYPOINT__GET_BLUETOOTH_SW_PROGRESS:

            HSA_System__ulwGetBluetoothSWProgress();
            break;

        case HSA_API_ENTRYPOINT__GET_CLIMATE_AIRFLOW_BODY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetClimateAirflowBody(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CLIMATE_AIRFLOW_FOOTWELL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetClimateAirflowFootwell(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CLIMATE_AIRFLOW_RANGE:

            HSA_System__ulwGetClimateAirflowRange();
            break;

        case HSA_API_ENTRYPOINT__GET_CLIMATE_AIRFLOW_UP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetClimateAirflowUp(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CLIMATE_CONTEXT:

            HSA_System__ulwGetClimateContext();
            break;

        case HSA_API_ENTRYPOINT__GET_CLIMATE_CURRENT_STATUS_ICON:

            HSA_System__ulwGetClimateCurrentStatusIcon();
            break;

        case HSA_API_ENTRYPOINT__GET_CLIMATE_POPUP_DURATION:

            HSA_System__ulwGetClimatePopupDuration();
            break;

        case HSA_API_ENTRYPOINT__GET_CLIMATE_REAR_STATE:

            HSA_System__ulwGetClimateRearState();
            break;

        case HSA_API_ENTRYPOINT__GET_CLIMATE_SEATHEAT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetClimateSeatheat(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CLIMATE_STATUS_ICONS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetClimateStatusIcons(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CODE_INPUT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetCodeInput(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SD_CODE_INPUT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSDCodeInput(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_DISTANCE_UNIT:

            HSA_System__ulwGetCurrentDistanceUnit();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_MENU_LANGUAGE:

            HSA_System__ulwGetCurrentMenuLanguage();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_TEMPERATURE_UNIT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vGetCurrentTemperatureUnit(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DABSW_PROGRESS:

            HSA_System__ulwGetDABSWProgress();
            break;

        case HSA_API_ENTRYPOINT__GET_DATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetDate(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DATE_MODE:

            HSA_System__ulwGetDateMode();
            break;

        case HSA_API_ENTRYPOINT__GET_DESIRED_TEMPERATURE_AS_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vGetDesiredTemperatureAsString(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DISPLAY_BRIGHTNESS:

            HSA_System__slwGetDisplayBrightness();
            break;

        case HSA_API_ENTRYPOINT__GET_FGSSW_PROGRESS:

            HSA_System__ulwGetFGSSWProgress();
            break;

        case HSA_API_ENTRYPOINT__GET_LANGUAGE_CODE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetLanguageCode(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_CLAMP15_OFF_TIME:

            HSA_System__ulwGetLastClamp15OffTime();
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_MAIN_CONTEXT:

            HSA_System__ulwGetLastMainContext();
            break;

        case HSA_API_ENTRYPOINT__GET_NAV_SW_PROGRESS:

            HSA_System__ulwGetNavSWProgress();
            break;

        case HSA_API_ENTRYPOINT__GET_OPS_CAR_TYPE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetOPSCarType(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_OPS_FRONT_DISTANCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetOPSFrontDistance(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_OPS_NUMBER_OF_SECTORS:

            HSA_System__ulwGetOPSNumberOfSectors();
            break;

        case HSA_API_ENTRYPOINT__GET_OPS_REAR_DISTANCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetOPSRearDistance(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_OPS_REAR_SENSORS_ONLY:

            HSA_System__blGetOPSRearSensorsOnly();
            break;

        case HSA_API_ENTRYPOINT__GET_REMAINING_ATTEMPTS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetRemainingAttempts(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SD_REMAINING_ATTEMPTS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSDRemainingAttempts(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_REMAINING_UNLOCKS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetRemainingUnlocks(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_RVC_DARK:

            HSA_System__ulwGetRVCDark();
            break;

        case HSA_API_ENTRYPOINT__GET_RVC_MODE:

            HSA_System__ulwGetRVCMode();
            break;

        case HSA_API_ENTRYPOINT__GET_RVC_TYPE:

            HSA_System__ulwGetRVCType();
            break;

        case HSA_API_ENTRYPOINT__GET_SD_CARD_MEMORY_FREE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSDCardMemoryFree(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SD_CARD_MEMORY_TOTAL:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSDCardMemoryTotal(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SD_CARD_MEMORY_USED_BY_NAV:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSDCardMemoryUsedByNAV(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SD_CHKDSK_PROGRESS:

            HSA_System__ulwGetSDChkdskProgress();
            break;

        case HSA_API_ENTRYPOINT__GET_SD_FORMAT_PROGRESS:

            HSA_System__ulwGetSDFormatProgress();
            break;

        case HSA_API_ENTRYPOINT__GET_SKIN_DAY_NIGHT:

            HSA_System__ulwGetSkinDayNight();
            break;

        case HSA_API_ENTRYPOINT__GET_SOFTWARE_DOWNLOAD_ERROR_CODE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSoftwareDownloadErrorCode(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SOFTWARE_VERSION_FROM_CD:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSoftwareVersionFromCD(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SOFTWARE_VERSION_INSTALLED:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSoftwareVersionInstalled(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SPELLER_LAYOUT:

            HSA_System__ulwGetSpellerLayout();
            break;

        case HSA_API_ENTRYPOINT__GET_SW_UPDATE_PROGRESS:

            HSA_System__ulwGetSWUpdateProgress();
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_CODE_COUNTDOWN_TIME:

            HSA_System__ulwGetSystemCodeCountdownTime();
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_CODE_COUNTDOWN_TIME_AS_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSystemCodeCountdownTimeAsString(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SD_CODE_COUNTDOWN_TIME:

            HSA_System__ulwGetSDCodeCountdownTime();
            break;

        case HSA_API_ENTRYPOINT__GET_SD_CODE_COUNTDOWN_TIME_AS_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetSDCodeCountdownTimeAsString(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_ON_OFF_STATE:

            HSA_System__ulwGetSystemOnOffState();
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_SW_PROGRESS:

            HSA_System__ulwGetSystemSWProgress();
            break;

        case HSA_API_ENTRYPOINT__GET_SYSTEM_VENDOR:

            HSA_System__ulwGetSystemVendor();
            break;

        case HSA_API_ENTRYPOINT__GET_WEEKDAY_OF_TODAY:

            HSA_System__ulwGetWeekdayOfToday();
            break;

        case HSA_API_ENTRYPOINT__GET_WEEKDAY_OF_TOMORROW:

            HSA_System__ulwGetWeekdayOfTomorrow();
            break;

        case HSA_API_ENTRYPOINT__GET_TIME:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetTime(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TIME_FORMAT:

            HSA_System__ulwGetTimeFormat();
            break;

        case HSA_API_ENTRYPOINT__GET_TIME_FORMATTED:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_System__vGetTimeFormatted(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_APS_PRESENT:

            HSA_System__blIsAPSPresent();
            break;

        case HSA_API_ENTRYPOINT__IS_CLIMATE_SETUP_AVAILABLE:

            HSA_System__blIsClimateSetupAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_CLIMATE_STATUS_LINE_FUNCTION_ON:

            HSA_System__blIsClimateStatusLineFunctionOn();
            break;

        case HSA_API_ENTRYPOINT__IS_CLIMATE_TEMP_CHANGED:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__blIsClimateTempChanged(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_CLIMATE_TEMP_IN_RANGE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__blIsClimateTempInRange(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_DATE_FORMAT_MASTER_PRESENT:

            HSA_System__blIsDateFormatMasterPresent();
            break;

        case HSA_API_ENTRYPOINT__IS_DATE_MASTER_PRESENT:

            HSA_System__blIsDateMasterPresent();
            break;

        case HSA_API_ENTRYPOINT__IS_DATE_VALID:

            HSA_System__slwIsDateValid();
            break;

        case HSA_API_ENTRYPOINT__IS_OPS_PRESENT:

            HSA_System__blIsOPSPresent();
            break;

        case HSA_API_ENTRYPOINT__IS_OPS_TRAILER_RECOGNIZED:

            HSA_System__blIsOPSTrailerRecognized();
            break;

        case HSA_API_ENTRYPOINT__IS_REAR_GEAR_ACTIVE:

            HSA_System__blIsRearGearActive();
            break;

        case HSA_API_ENTRYPOINT__IS_RVC_REQUEST_ACTIVE:

            HSA_System__blIsRVCRequestActive();
            break;

        case HSA_API_ENTRYPOINT__IS_SD_CARD_AVAILABLE:

            HSA_System__ulwIsSDCardAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_SD_CARD_IN_USE:

            HSA_System__blIsSDCardInUse();
            break;

        case HSA_API_ENTRYPOINT__IS_SKODA_EXTERNAL_AMP_AVAILABLE:

            HSA_System__blIsSkodaExternalAmpAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_SW_DOWNLOAD_POSSIBLE:

            HSA_System__blIsSWDownloadPossible();
            break;

        case HSA_API_ENTRYPOINT__IS_TIME_FORMAT_MASTER_PRESENT:

            HSA_System__blIsTimeFormatMasterPresent();
            break;

        case HSA_API_ENTRYPOINT__IS_TIME_MASTER_PRESENT:

            HSA_System__blIsTimeMasterPresent();
            break;

        case HSA_API_ENTRYPOINT__IS_TIME_VALID:

            HSA_System__slwIsTimeValid();
            break;

        case HSA_API_ENTRYPOINT__LOCK_DDS_EVENT_FOCUS:

            HSA_System__vLockDDSEventFocus();
            break;

        case HSA_API_ENTRYPOINT__LOCK_DDS_VOLUME_FOCUS:

            HSA_System__vLockDDSVolumeFocus();
            break;

        case HSA_API_ENTRYPOINT__RESTART_SYSTEM:

            HSA_System__vRestartSystem();
            break;

        case HSA_API_ENTRYPOINT__RESTORE_DDS_SPEEDUP:

            HSA_System__vRestoreDDSSpeedup();
            break;

        case HSA_API_ENTRYPOINT__RESTORE_DDS_VOLUME_SPEEDUP:

            HSA_System__vRestoreDDSVolumeSpeedup();
            break;

        case HSA_API_ENTRYPOINT__SAVE_DATE:

            HSA_System__vSaveDate();
            break;

        case HSA_API_ENTRYPOINT__SAVE_TIME:

            HSA_System__vSaveTime();
            break;

        case HSA_API_ENTRYPOINT__DUR_SNOOZE:

            HSA_System__vDURSnooze();
            break;

        case HSA_API_ENTRYPOINT__DUR_DISMISS:

            HSA_System__vDURDismiss();
            break;

        case HSA_API_ENTRYPOINT__SET_ACOUSTIC_TOUCHSCREEN_FEEDBACK:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetAcousticTouchscreenFeedback(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_CLIMATE_POPUP_DURATION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetClimatePopupDuration(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DATE_DAY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetDateDay(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DATE_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetDateMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DATE_MONTH:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetDateMonth(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DATE_YEAR:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetDateYear(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DDS_EVENT_FOCUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetDDSEventFocus(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DDS_SPEEDUP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_System__vSetDDSSpeedup(ulParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__SET_DDS_VOLUME_FOCUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetDDSVolumeFocus(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DDS_VOLUME_SPEEDUP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_System__vSetDDSVolumeSpeedup(ulParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__SET_DISPLAY_BRIGHTNESS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System__vSetDisplayBrightness(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DISTANCE_UNIT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetDistanceUnit(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_FACTORY_SETTINGS:

            HSA_System__vSetFactorySettings();
            break;

        case HSA_API_ENTRYPOINT__SET_LAST_MAIN_CONTEXT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetLastMainContext(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_MENU_LANGUAGE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetMenuLanguage(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_RVC_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetRVCMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_SKIN_DAY_NIGHT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetSkinDayNight(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DIMSTATE:

            HSA_System__blGetDimstate();
            break;

        case HSA_API_ENTRYPOINT__SET_SPELLER_LAYOUT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetSpellerLayout(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_TIME_FORMAT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetTimeFormat(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_TIME_HOUR:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetTimeHour(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_TIME_MINUTE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetTimeMinute(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_TIME_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetTimeMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TIME_MODE:

            HSA_System__ulwGetTimeMode();
            break;

        case HSA_API_ENTRYPOINT__SET_USER_CONFIRMED_SPELLER_DISCLAIMER:

            HSA_System__vSetUserConfirmedSpellerDisclaimer();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION:

            HSA_System__blSpellerInvertGetLetterFunction();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_MAX_CHAR_COUNT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSpellerSetMaxCharCount(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__START_CHKDSK:

            HSA_System__vStartChkdsk();
            break;

        case HSA_API_ENTRYPOINT__START_FORMATTING:

            HSA_System__vStartFormatting();
            break;

        case HSA_API_ENTRYPOINT__START_SOFTWARE_DOWNLOAD:

            HSA_System__vStartSoftwareDownload();
            break;

        case HSA_API_ENTRYPOINT__INSERT_MEDIA_FOR_DOWNLOAD:

            HSA_System__vInsertMediaForDownload();
            break;

        case HSA_API_ENTRYPOINT__UN_LOCK_DDS_EVENT_FOCUS:

            HSA_System__vUnLockDDSEventFocus();
            break;

        case HSA_API_ENTRYPOINT__UN_LOCK_DDS_VOLUME_FOCUS:

            HSA_System__vUnLockDDSVolumeFocus();
            break;

        case HSA_API_ENTRYPOINT__UNMOUNT_SD:

            HSA_System__vUnmountSD();
            break;

        case HSA_API_ENTRYPOINT__IS_FORCED_DOWNLOAD_POSSIBLE:

            HSA_System__blIsForcedDownloadPossible();
            break;

        case HSA_API_ENTRYPOINT__GET_EA_BLOCKING_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetEABlockingMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_NISSAN_REGION_TYPE:

            HSA_System__ulwGetNissanRegionType();
            break;

        case HSA_API_ENTRYPOINT__GET_UNIT_OF_TEMPERATURE:

            HSA_System__ulwGetUnitOfTemperature();
            break;

        case HSA_API_ENTRYPOINT__SET_UNIT_OF_TEMPERATURE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetUnitOfTemperature(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DOCUMENT_TEXT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam2, aubBuffer2, sizeof(aubBuffer2)); 
            GUI_String_vSetCStr(&gsParam2, tmpBuffer);
            HSA_System__vGetDocumentText(&gsParam1, &gsParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DOCUMENT_SIZE:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_System__ulwGetDocumentSize(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_DRIVE_TYPE:

            HSA_System__ulwGetHEVDriveType();
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_BODY_SHAPE:

            HSA_System__ulwGetHEVBodyShape();
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_ENERGY_FLOW__START_INDEX:

            HSA_System__ulwGetHEVEnergyFlow_StartIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_ENERGY_FLOW__END_INDEX:

            HSA_System__ulwGetHEVEnergyFlow_EndIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_ENGINE_OPERATION_STATE:

            HSA_System__blGetHEVEngineOperationState();
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_BATTERY_OPERATION_STATE:

            HSA_System__blGetHEVBatteryOperationState();
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_BATTERY_CHARGE_DISCHARGE_STATE:

            HSA_System__ulwGetHEVBatteryChargeDischargeState();
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_BATTERY_CHARGE_LEVEL:

            HSA_System__ulwGetHEVBatteryChargeLevel();
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_TIRE_ROTATION_DIRECTION:

            HSA_System__ulwGetHEVTireRotationDirection();
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_AVERAGE_FUEL_ECONOMY_HISTORY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetHEVAverageFuelEconomyHistory(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_REGENERATION_AMOUNT_ICON_HISTORY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetHEVRegenerationAmountIconHistory(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_DRIVING_HISTORY_TIME_STAMP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__ulwGetHEVDrivingHistoryTimeStamp(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_HEVD_DRIVING_HISTORY_DATE_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_System__vGetHEVDDrivingHistoryDateString(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_FUEL_ECONOMY_UNIT:

            HSA_System__ulwGetHEVFuelEconomyUnit();
            break;

        case HSA_API_ENTRYPOINT__SET_HEV_SHIFT_DIRECTION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_System__vSetHEVShiftDirection(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_SCROLL_KEY_GRAYING_STATE:

            HSA_System__ulwGetHEVScrollKeyGrayingState();
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_HISTORY_MAX_VALUE:

            HSA_System__ulwGetHEVHistoryMaxValue();
            break;

        case HSA_API_ENTRYPOINT__LOAD_HEV_HISTORY:

            HSA_System__vLoadHEVHistory();
            break;

        case HSA_API_ENTRYPOINT__GET_HEV_HISTORY_LOADING_STATE:

            HSA_System__ulwGetHEVHistoryLoadingState();
            break;

        case HSA_API_ENTRYPOINT__IS_TIME_FORMAT_SCREEN_ACTIVE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_System__vIsTimeFormatScreenActive(usParam1);
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

