/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_System_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_System_Base_H
#define _clHSA_System_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_System_Base : public clHSA_Base
{
public:

    static clHSA_System_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_System_Base()        {}

    virtual void vStartTouchScreenCalibration( );

    virtual void vAbortTouchScreenCalibration( );

    virtual ulword ulwGetCalibrationPageNumber( );

    virtual void vNewCalibrationPageDrawn( );

    virtual tbool blAutoModeEnableDisable( );

    virtual ulword ulwGetCalibrationStatus( );

    virtual void vGetKDSData(GUI_String *out_result, ulword ulwKDSEntry);

    virtual void vCheckClockScreenMode( );

    virtual void vSetClockScreenMode(tbool blMode);

    virtual void vSetClockScreenTimer(tbool blAction);

    virtual void vSetApplicationPalette(ulword ulwPalette);

    virtual void vResetTransitionCounter( );

    virtual void vIncrementTransitionCounter( );

    virtual void vDecrementTransitionCounter( );

    virtual void vGetVersion( );

    virtual tbool blIsOverSpeedActive( );

    virtual ulword ulwGetEcoDrivingDataSymbolType( );

    virtual ulword ulwGetEcoDrivingScore( );

    virtual ulword ulwGetEcoPullingAwayScore( );

    virtual ulword ulwGetEcoCruiseScore( );

    virtual ulword ulwGetEcoDecelerationScore( );

    virtual ulword ulwGetEcoDDrivingHistoryValues(ulword ulwListEntryNumber);

    virtual void vGetEcoDDrivingHistoryDateString(GUI_String *out_result, ulword ulwListEntryNumber);

    virtual ulword ulwGetEcoDDrivingHistoryDateMonth(ulword ulwListEntryNumber);

    virtual ulword ulwGetEcoDDrivingHistoryDateDay(ulword ulwListEntryNumber);

    virtual void vResetEcoDrivingHistory( );

    virtual ulword ulwXMLVersionCheckStatus( );

    virtual void vGetXMLVersionString(GUI_String *out_result, ulword ulwDevice);

    virtual void vSetMeterAudioWarning(ulword ulwWarningState, const GUI_String * WarningText);

    virtual void vSetMeterSMSPopup(ulword ulwSMSState, ulword ulwListEntryNr);

    virtual void vSetSMSMessageTextPopupState(tbool blStatus);

    virtual tbool blIsMeterConnected( );

    virtual void vSetXMLVersionDisclaimerAcceptance(tbool blStatus);

    virtual tbool blGetXMLVersionDisclaimerAcceptance( );

    virtual ulword ulwGetSrvSystemSelfTest(ulword ulwSystemSelfTest);

    virtual ulword ulwGetSrvSDCardWriteProtectionStatus( );

    virtual ulword ulwGetImmobilizerLockState( );

    virtual void vSetImmobilizerLockStateToUnLock( );

    virtual ulword ulwGetSrvSystemConfig(ulword ulwSystemConfig);

    virtual void vGetXMTunerFirmwareVersion(GUI_String *out_result);

    virtual void vGetBTHF_BoxVersion(GUI_String *out_result);

    virtual ulword ulwGetDisplayMode( );

    virtual ulword ulwGetDisplayTestScreen( );

    virtual tbool blGetNavDisclaimerConfirmed( );

    virtual void vSetNavDisclaimerConfirmed( );

    virtual void vDisableDestinationInputWhileDriving( );

    virtual tbool blGetDestinationInputWhileDriving( );

    virtual void vSetBeepMode(ulword ulwListEntryNr);

    virtual ulword ulwGetBeepMode( );

    virtual void vToggleDisplayMode( );

    virtual void vLanguageIconSelected( );

    virtual void vGetSystemSerialNo(GUI_String *out_result);

    virtual void vGetSystemDeviceNo(GUI_String *out_result);

    virtual void vGetSystemProductionDate(GUI_String *out_result);

    virtual void vPerformSpeakerTest(ulword ulwFrequency);

    virtual void vSetEncoderDirection(ulword ulwEncoderDirn);

    virtual tbool blGetEncoderDirection( );

    virtual ulword ulwGetCurrentSelfTestProgressValue( );

    virtual void vSetRVCFlag(tbool blValue);

    virtual ulword ulwGetCameraDisplaySettingsPopupState( );

    virtual void vSwitchToCameraScreen(tbool blbSwitchStatus, ulword ulwCameraSettingParam);

    virtual void vToggleGuideLineState( );

    virtual ulword ulwGetRVCGuideLineStatus( );

    virtual void vInformCameraHKPress(tbool blCameraHKPressType);

    virtual ulword ulwGetCameraSystemConfigured( );

    virtual ulword ulwGetCameraRequestState( );

    virtual tbool blIsCameraReqTimeOutRequired( );

    virtual tbool blIsCameraRequestActive( );

    virtual tbool blIsVideoSignalAvailable( );

    virtual tbool blIsAVMRequestActive( );

    virtual tbool blIsAffordableITSAvailable( );

    virtual void vSwitchOffCamera( );

    virtual ulword ulwGetCameraConfigStatus(ulword ulwConfigParam);

    virtual void vToggleCameraConfigStatus(ulword ulwConfigParam);

    virtual ulword ulwGetVideoDimming(ulword ulwDimmingParam);

    virtual void vInformAVMOnPurposeSwitch( );

    virtual void vSetVideoDimming(ulword ulwDimmingParam, tbool blMode);

    virtual void vIPA_SendButtonPress(ulword ulwButtonIdentifier, ulword ulwButtonState);

    virtual void vIPA_SetHMIStatus(tbool blHmiStatus);

    virtual ulword ulwIPA_GetAvailablityStatus( );

    virtual ulword ulwIPA_GetConfiguredRegion( );

    virtual ulword ulwIPA_GetMessageRequested( );

    virtual ulword ulwIPA_GetPatternRequested( );

    virtual ulword ulwIPA_GetPopupRequested( );

    virtual ulword ulwIPA_GetOperationStatus( );

    virtual ulword ulwIPA_GetMode( );

    virtual ulword ulwIPA_GetCarDirection_Indicator_Status( );

    virtual ulword ulwIPA_GetButtonVisibilityStatus(ulword ulwButtonIdentifier);

    virtual tbool blSONAR_GetVisualizationStatus( );

    virtual ulword ulwSONAR_GetCarShapeModel( );

    virtual ulword ulwSONAR_GetAvailabilityStatus( );

    virtual tbool blSONAR_GetSonarSwitchAvailability( );

    virtual tbool blSONAR_GetErrorStatus( );

    virtual ulword ulwSONAR_GetFrontSensorAvailability( );

    virtual ulword ulwSONAR_GetRearSensorAvailability( );

    virtual ulword ulwSONAR_GetFrontSensorDistanceLevels( );

    virtual ulword ulwSONAR_GetRearSensorDistanceLevels( );

    virtual tbool blSONAR_GetSystemStatus( );

    virtual tbool blSONAR_GetFrontSensorsOnlyStatus( );

    virtual tbool blSONAR_GetAutomaticDisplayStatus( );

    virtual ulword ulwSONAR_GetSensitivityLevel( );

    virtual ulword ulwSONAR_GetVolumeLevel( );

    virtual void vToggleSonarCancelSwitchStatus( );

    virtual void vToggleSonarSystemOption( );

    virtual void vToggleFrontSensorsOnlyOption( );

    virtual void vToggleAutomaticDisplayOption( );

    virtual void vSetSonarSensitivityLevel( );

    virtual void vSetSonarVolumeLevel( );

    virtual ulword ulwSONAR_GetSonarMenu( );

    virtual void vGetSystemConfig(GUI_String *out_result, ulword ulwSystemConfig);

    virtual void vGetSystemHistory(GUI_String *out_result, ulword ulwSystemHistory);

    virtual void vGetSystemSelfTest(GUI_String *out_result, ulword ulwSystemSelfTest);

    virtual void vStartSelfTest( );

    virtual void vGetUSBSlotMedium(GUI_String *out_result);

    virtual ulword ulwGetViaGPSTimeStatus( );

    virtual void vToggleViaGPSTimeStatus( );

    virtual tbool blGetSummerTimeStatus( );

    virtual void vToggleSummerTimeStatus( );

    virtual void vGetCurrentTZ(GUI_String *out_result);

    virtual ulword ulwGetCurrentTZIndex( );

    virtual ulword ulwGetTZListCount( );

    virtual void vGetTZListElement(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vSetTZ(ulword ulwListEntryNr);

    virtual void vIncreaseTimeHour( );

    virtual void vDateHandling(ulword ulwType, tbool blOperation);

    virtual void vToggleDateFormat( );

    virtual ulword ulwGetDateFormat( );

    virtual void vDecreaseTimeHour( );

    virtual ulword ulwGetTimeHour( );

    virtual void vIncreaseTimeMinute( );

    virtual void vIncreaseDateDay( );

    virtual void vIncreaseDateMonth( );

    virtual void vIncreaseDateYear( );

    virtual void vDecreaseTimeMinute( );

    virtual void vDecreaseDateDay( );

    virtual void vDecreaseDateMonth( );

    virtual void vDecreaseDateYear( );

    virtual ulword ulwGetTimeMinute( );

    virtual void vActivateFirstMediaData(ulword ulwSource);

    virtual tbool blAreRearSpeakersAssembled( );

    virtual void vCancelSoftwareDownload( );

    virtual tbool blCheckAssemblyUnlock( );

    virtual ulword ulwCheckCode( );

    virtual ulword ulwCheckSDCode( );

    virtual ulword ulwCheckComfortCoding( );

    virtual ulword ulwCheckSDPaired( );

    virtual ulword ulwCheckSDPINRequirement( );

    virtual void vCheckSpellerDisclaimer( );

    virtual void vCodeInput(const GUI_String * InputString);

    virtual void vSDCodeInput(const GUI_String * InputString);

    virtual tbool blSetupGetPresetMenu( );

    virtual void vSetupSetPresetMenu(tbool blMode);

    virtual ulword ulwGetSizeofDisplay( );

    virtual void vCreateBeep( );

    virtual void vCreateBeepX(ulword ulwBeepType);

    virtual void vEjectCD( );

    virtual ulword ulwGetAcousticTouchscreenFeedback( );

    virtual ulword ulwGetBluetoothSWProgress( );

    virtual ulword ulwGetClimateAirflowBody(ulword ulwSeat);

    virtual ulword ulwGetClimateAirflowFootwell(ulword ulwSeat);

    virtual ulword ulwGetClimateAirflowRange( );

    virtual ulword ulwGetClimateAirflowUp(ulword ulwSeat);

    virtual ulword ulwGetClimateContext( );

    virtual ulword ulwGetClimateCurrentStatusIcon( );

    virtual ulword ulwGetClimatePopupDuration( );

    virtual ulword ulwGetClimateRearState( );

    virtual ulword ulwGetClimateSeatheat(ulword ulwSeat);

    virtual void vGetClimateStatusIcons(GUI_String *out_result);

    virtual void vGetCodeInput(GUI_String *out_result);

    virtual void vGetSDCodeInput(GUI_String *out_result);

    virtual ulword ulwGetCurrentDistanceUnit( );

    virtual ulword ulwGetCurrentMenuLanguage( );

    virtual void vGetCurrentTemperatureUnit(GUI_String *out_result, ulword ulwSeat);

    virtual ulword ulwGetDABSWProgress( );

    virtual ulword ulwGetDate(ulword ulwYearOrMonthOrDay);

    virtual ulword ulwGetDateMode( );

    virtual void vGetDesiredTemperatureAsString(GUI_String *out_result, ulword ulwSeat);

    virtual slword slwGetDisplayBrightness( );

    virtual ulword ulwGetFGSSWProgress( );

    virtual void vGetLanguageCode(GUI_String *out_result);

    virtual ulword ulwGetLastClamp15OffTime( );

    virtual ulword ulwGetLastMainContext( );

    virtual ulword ulwGetNavSWProgress( );

    virtual void vGetOPSCarType(GUI_String *out_result);

    virtual ulword ulwGetOPSFrontDistance(ulword ulwSector);

    virtual ulword ulwGetOPSNumberOfSectors( );

    virtual ulword ulwGetOPSRearDistance(ulword ulwSector);

    virtual tbool blGetOPSRearSensorsOnly( );

    virtual void vGetRemainingAttempts(GUI_String *out_result);

    virtual void vGetSDRemainingAttempts(GUI_String *out_result);

    virtual void vGetRemainingUnlocks(GUI_String *out_result);

    virtual ulword ulwGetRVCDark( );

    virtual ulword ulwGetRVCMode( );

    virtual ulword ulwGetRVCType( );

    virtual void vGetSDCardMemoryFree(GUI_String *out_result);

    virtual void vGetSDCardMemoryTotal(GUI_String *out_result);

    virtual void vGetSDCardMemoryUsedByNAV(GUI_String *out_result);

    virtual ulword ulwGetSDChkdskProgress( );

    virtual ulword ulwGetSDFormatProgress( );

    virtual ulword ulwGetSkinDayNight( );

    virtual void vGetSoftwareDownloadErrorCode(GUI_String *out_result);

    virtual void vGetSoftwareVersionFromCD(GUI_String *out_result);

    virtual void vGetSoftwareVersionInstalled(GUI_String *out_result);

    virtual ulword ulwGetSpellerLayout( );

    virtual ulword ulwGetSWUpdateProgress( );

    virtual ulword ulwGetSystemCodeCountdownTime( );

    virtual void vGetSystemCodeCountdownTimeAsString(GUI_String *out_result);

    virtual ulword ulwGetSDCodeCountdownTime( );

    virtual void vGetSDCodeCountdownTimeAsString(GUI_String *out_result);

    virtual ulword ulwGetSystemOnOffState( );

    virtual ulword ulwGetSystemSWProgress( );

    virtual ulword ulwGetSystemVendor( );

    virtual ulword ulwGetWeekdayOfToday( );

    virtual ulword ulwGetWeekdayOfTomorrow( );

    virtual ulword ulwGetTime(ulword ulwHourOrMinute);

    virtual ulword ulwGetTimeFormat( );

    virtual void vGetTimeFormatted(GUI_String *out_result);

    virtual tbool blIsAPSPresent( );

    virtual tbool blIsClimateSetupAvailable( );

    virtual tbool blIsClimateStatusLineFunctionOn( );

    virtual tbool blIsClimateTempChanged(ulword ulwSeat);

    virtual tbool blIsClimateTempInRange(ulword ulwSeat);

    virtual tbool blIsDateFormatMasterPresent( );

    virtual tbool blIsDateMasterPresent( );

    virtual slword slwIsDateValid( );

    virtual tbool blIsOPSPresent( );

    virtual tbool blIsOPSTrailerRecognized( );

    virtual tbool blIsRearGearActive( );

    virtual tbool blIsRVCRequestActive( );

    virtual ulword ulwIsSDCardAvailable( );

    virtual tbool blIsSDCardInUse( );

    virtual tbool blIsSkodaExternalAmpAvailable( );

    virtual tbool blIsSWDownloadPossible( );

    virtual tbool blIsTimeFormatMasterPresent( );

    virtual tbool blIsTimeMasterPresent( );

    virtual slword slwIsTimeValid( );

    virtual void vLockDDSEventFocus( );

    virtual void vLockDDSVolumeFocus( );

    virtual void vRestartSystem( );

    virtual void vRestoreDDSSpeedup( );

    virtual void vRestoreDDSVolumeSpeedup( );

    virtual void vSaveDate( );

    virtual void vSaveTime( );

    virtual void vDURSnooze( );

    virtual void vDURDismiss( );

    virtual void vSetAcousticTouchscreenFeedback(ulword ulwListEntryNr);

    virtual void vSetClimatePopupDuration(ulword ulwMode);

    virtual void vSetDateDay(ulword ulwDay);

    virtual void vSetDateMode(ulword ulwMode);

    virtual void vSetDateMonth(ulword ulwMonth);

    virtual void vSetDateYear(ulword ulwYear);

    virtual void vSetDDSEventFocus(ulword ulwWindow);

    virtual void vSetDDSSpeedup(ulword ulwtime, ulword ulwthreshold, ulword ulwmultiplier);

    virtual void vSetDDSVolumeFocus(ulword ulwWindow);

    virtual void vSetDDSVolumeSpeedup(ulword ulwtime, ulword ulwthreshold, ulword ulwmultiplier);

    virtual void vSetDisplayBrightness(tbool blMode);

    virtual void vSetDistanceUnit(ulword ulwMode);

    virtual void vSetFactorySettings( );

    virtual void vSetLastMainContext(ulword ulwListEntryNr);

    virtual void vSetMenuLanguage(ulword ulwListEntryNr);

    virtual void vSetRVCMode(ulword ulwRVCMode);

    virtual void vSetSkinDayNight(ulword ulwMode);

    virtual tbool blGetDimstate( );

    virtual void vSetSpellerLayout(ulword ulwLayout);

    virtual void vSetTimeFormat(ulword ulwFormat);

    virtual void vSetTimeHour(ulword ulwHour);

    virtual void vSetTimeMinute(ulword ulwMinute);

    virtual void vSetTimeMode(ulword ulwMode);

    virtual ulword ulwGetTimeMode( );

    virtual void vSetUserConfirmedSpellerDisclaimer( );

    virtual tbool blSpellerInvertGetLetterFunction( );

    virtual void vSpellerSetMaxCharCount(ulword ulwCount);

    virtual void vStartChkdsk( );

    virtual void vStartFormatting( );

    virtual void vStartSoftwareDownload( );

    virtual void vInsertMediaForDownload( );

    virtual void vUnLockDDSEventFocus( );

    virtual void vUnLockDDSVolumeFocus( );

    virtual void vUnmountSD( );

    virtual tbool blIsForcedDownloadPossible( );

    virtual ulword ulwGetEABlockingMode(ulword ulwApplication);

    virtual ulword ulwGetNissanRegionType( );

    virtual ulword ulwGetUnitOfTemperature( );

    virtual void vSetUnitOfTemperature(ulword ulwTemperatureUnit);

    virtual void vGetDocumentText(GUI_String *out_result, const GUI_String * DocPath);

    virtual ulword ulwGetDocumentSize(const GUI_String * DocPath);

    virtual ulword ulwGetHEVDriveType( );

    virtual ulword ulwGetHEVBodyShape( );

    virtual ulword ulwGetHEVEnergyFlow_StartIndex( );

    virtual ulword ulwGetHEVEnergyFlow_EndIndex( );

    virtual tbool blGetHEVEngineOperationState( );

    virtual tbool blGetHEVBatteryOperationState( );

    virtual ulword ulwGetHEVBatteryChargeDischargeState( );

    virtual ulword ulwGetHEVBatteryChargeLevel( );

    virtual ulword ulwGetHEVTireRotationDirection( );

    virtual ulword ulwGetHEVAverageFuelEconomyHistory(ulword ulwListEntryNumber);

    virtual ulword ulwGetHEVRegenerationAmountIconHistory(ulword ulwListEntryNumber);

    virtual ulword ulwGetHEVDrivingHistoryTimeStamp(ulword ulwListEntryNumber);

    virtual void vGetHEVDDrivingHistoryDateString(GUI_String *out_result, ulword ulwListEntryNumber);

    virtual ulword ulwGetHEVFuelEconomyUnit( );

    virtual void vSetHEVShiftDirection(ulword ulwShift_direction);

    virtual ulword ulwGetHEVScrollKeyGrayingState( );

    virtual ulword ulwGetHEVHistoryMaxValue( );

    virtual void vLoadHEVHistory( );

    virtual ulword ulwGetHEVHistoryLoadingState( );

    virtual void vIsTimeFormatScreenActive(tbool blScreenstate);

protected:
    clHSA_System_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_System_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_System_Base_H

