/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_System_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_System/clHSA_System_Base.h"

clHSA_System_Base* clHSA_System_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_System_Base.cpp.trc.h"
#endif


/**
 * Method: vStartTouchScreenCalibration
  * Initiates the TouchScreen Calibration
  * B1
 */
void clHSA_System_Base::vStartTouchScreenCalibration( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vStartTouchScreenCalibration not implemented"));
   
}

/**
 * Method: vAbortTouchScreenCalibration
  * Aborts the TouchScreen Calibration
  * B
 */
void clHSA_System_Base::vAbortTouchScreenCalibration( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vAbortTouchScreenCalibration not implemented"));
   
}

/**
 * Method: ulwGetCalibrationPageNumber
  * This API is used to return the page number after calibration response is received from driver
  * NISSAN LCN2 Sample
 */
ulword clHSA_System_Base::ulwGetCalibrationPageNumber( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetCalibrationPageNumber not implemented"));
   return 0;
}

/**
 * Method: vNewCalibrationPageDrawn
  * This API is called by GUI on drawing a new Calibration page
  * NISSAN LCN2 Sample
 */
void clHSA_System_Base::vNewCalibrationPageDrawn( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vNewCalibrationPageDrawn not implemented"));
   
}

/**
 * Method: blAutoModeEnableDisable
  * This API is used to enable/disable automatic button in language menu
  * C
 */
tbool clHSA_System_Base::blAutoModeEnableDisable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blAutoModeEnableDisable not implemented"));
   return 0;
}

/**
 * Method: ulwGetCalibrationStatus
  * API to return the calibration status to GUI
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetCalibrationStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetCalibrationStatus not implemented"));
   return 0;
}

/**
 * Method: vGetKDSData
  * API to get the required KDS data
  * NISSAN
 */
void clHSA_System_Base::vGetKDSData(GUI_String *out_result, ulword ulwKDSEntry)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwKDSEntry);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetKDSData not implemented"));
   
}

/**
 * Method: vCheckClockScreenMode
  * API to initiate the check if clock screen-saver mode is enabled on startup and to start the timer subsequently
  * NISSAN LCN2 Sample
 */
void clHSA_System_Base::vCheckClockScreenMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vCheckClockScreenMode not implemented"));
   
}

/**
 * Method: vSetClockScreenMode
  * API to enable the clock screen-saver mode
  * 
 */
void clHSA_System_Base::vSetClockScreenMode(tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetClockScreenMode not implemented"));
   
}

/**
 * Method: vSetClockScreenTimer
  * API to stop the clock screen-saver timer
  * NISSAN LCN2 Sample
 */
void clHSA_System_Base::vSetClockScreenTimer(tbool blAction)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blAction);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetClockScreenTimer not implemented"));
   
}

/**
 * Method: vSetApplicationPalette
  * Set the palette for all four layers depending on the application
  * 
 */
void clHSA_System_Base::vSetApplicationPalette(ulword ulwPalette)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPalette);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetApplicationPalette not implemented"));
   
}

/**
 * Method: vResetTransitionCounter
  * This function is used to reset the counter which counts the number of screen transitions for HMI lockout feature.
  * NISSAN LCN2 Sample
 */
void clHSA_System_Base::vResetTransitionCounter( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vResetTransitionCounter not implemented"));
   
}

/**
 * Method: vIncrementTransitionCounter
  * This function is used to increment the counter which counts the number of screen transitions for HMI lockout feature.
  * NISSAN LCN2 Sample
 */
void clHSA_System_Base::vIncrementTransitionCounter( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vIncrementTransitionCounter not implemented"));
   
}

/**
 * Method: vDecrementTransitionCounter
  * This function is used to decrement the counter which counts the number of screen transitions for HMI lockout feature.
  * NISSAN LCN2 Sample
 */
void clHSA_System_Base::vDecrementTransitionCounter( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vDecrementTransitionCounter not implemented"));
   
}

/**
 * Method: vGetVersion
  * only for code generation sdu2hi.
  * NISSAN LCN2 Sample
 */
void clHSA_System_Base::vGetVersion( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vGetVersion not implemented"));
   
}

/**
 * Method: blIsOverSpeedActive
  * This function is used to disable speller widgets and scroll bars when actual speed goes beyond the speed limit for HMI lockout feature.
  * NISSAN LCN2 Sample
 */
tbool clHSA_System_Base::blIsOverSpeedActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsOverSpeedActive not implemented"));
   return 0;
}

/**
 * Method: ulwGetEcoDrivingDataSymbolType
  * This function is uesed to get the Eco Driving Data Symbol Type from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
ulword clHSA_System_Base::ulwGetEcoDrivingDataSymbolType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetEcoDrivingDataSymbolType not implemented"));
   return 0;
}

/**
 * Method: ulwGetEcoDrivingScore
  * This function is uesed to get the Eco Driving Data PullingAway Score Value from the VD VehicleData.
  * NISSAN LCN2  Sample
 */
ulword clHSA_System_Base::ulwGetEcoDrivingScore( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetEcoDrivingScore not implemented"));
   return 0;
}

/**
 * Method: ulwGetEcoPullingAwayScore
  * This function is uesed to get the Eco Driving Data PullingAway Score Value from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
ulword clHSA_System_Base::ulwGetEcoPullingAwayScore( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetEcoPullingAwayScore not implemented"));
   return 0;
}

/**
 * Method: ulwGetEcoCruiseScore
  * This function is uesed to get the Eco Driving Data Cruise Data Score Value from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
ulword clHSA_System_Base::ulwGetEcoCruiseScore( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetEcoCruiseScore not implemented"));
   return 0;
}

/**
 * Method: ulwGetEcoDecelerationScore
  * This function is uesed to get the Eco Driving Data Deceleration Data Score Value from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
ulword clHSA_System_Base::ulwGetEcoDecelerationScore( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetEcoDecelerationScore not implemented"));
   return 0;
}

/**
 * Method: ulwGetEcoDDrivingHistoryValues
  * This function is uesed to get the Eco Driving History Values from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
ulword clHSA_System_Base::ulwGetEcoDDrivingHistoryValues(ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetEcoDDrivingHistoryValues not implemented"));
   return 0;
}

/**
 * Method: vGetEcoDDrivingHistoryDateString
  * This function is uesed to get the Eco Driving History dates from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
void clHSA_System_Base::vGetEcoDDrivingHistoryDateString(GUI_String *out_result, ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetEcoDDrivingHistoryDateString not implemented"));
   
}

/**
 * Method: ulwGetEcoDDrivingHistoryDateMonth
  * This function is uesed to get the Eco Driving History Month value from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
ulword clHSA_System_Base::ulwGetEcoDDrivingHistoryDateMonth(ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetEcoDDrivingHistoryDateMonth not implemented"));
   return 0;
}

/**
 * Method: ulwGetEcoDDrivingHistoryDateDay
  * This function is uesed to get the Eco Driving History Date Day value from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
ulword clHSA_System_Base::ulwGetEcoDDrivingHistoryDateDay(ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetEcoDDrivingHistoryDateDay not implemented"));
   return 0;
}

/**
 * Method: vResetEcoDrivingHistory
  * This function is uesed to reset the Eco Driving History Values from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
void clHSA_System_Base::vResetEcoDrivingHistory( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vResetEcoDrivingHistory not implemented"));
   
}

/**
 * Method: ulwXMLVersionCheckStatus
  * Returns the status of requested parameter
  * NISSAN
 */
ulword clHSA_System_Base::ulwXMLVersionCheckStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwXMLVersionCheckStatus not implemented"));
   return 0;
}

/**
 * Method: vGetXMLVersionString
  * Returns the version string of the given device
  * 
 */
void clHSA_System_Base::vGetXMLVersionString(GUI_String *out_result, ulword ulwDevice)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDevice);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetXMLVersionString not implemented"));
   
}

/**
 * Method: vSetMeterAudioWarning
  * API is called when any audio warning Popup is displayed
  * 
 */
void clHSA_System_Base::vSetMeterAudioWarning(ulword ulwWarningState, const GUI_String * WarningText)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwWarningState);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( WarningText);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetMeterAudioWarning not implemented"));
   
}

/**
 * Method: vSetMeterSMSPopup
  * API is called when SMS popup is displayed
  * 
 */
void clHSA_System_Base::vSetMeterSMSPopup(ulword ulwSMSState, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSMSState);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetMeterSMSPopup not implemented"));
   
}

/**
 * Method: vSetSMSMessageTextPopupState
  * API is called when SMS Message text is displayed and also when removed with value 1 and 0 respectively
  * 
 */
void clHSA_System_Base::vSetSMSMessageTextPopupState(tbool blStatus)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blStatus);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetSMSMessageTextPopupState not implemented"));
   
}

/**
 * Method: blIsMeterConnected
  * Returns Whether Instrument Cluster(METER) is connected or Not
  * 
 */
tbool clHSA_System_Base::blIsMeterConnected( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsMeterConnected not implemented"));
   return 0;
}

/**
 * Method: vSetXMLVersionDisclaimerAcceptance
  * Set the flag for the XML version missmatch popup
  * 
 */
void clHSA_System_Base::vSetXMLVersionDisclaimerAcceptance(tbool blStatus)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blStatus);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetXMLVersionDisclaimerAcceptance not implemented"));
   
}

/**
 * Method: blGetXMLVersionDisclaimerAcceptance
  * Get the flag for the XML version missmatch popup
  * 
 */
tbool clHSA_System_Base::blGetXMLVersionDisclaimerAcceptance( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blGetXMLVersionDisclaimerAcceptance not implemented"));
   return 0;
}

/**
 * Method: ulwGetSrvSystemSelfTest
  * Returns the status of requested parameter
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetSrvSystemSelfTest(ulword ulwSystemSelfTest)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSystemSelfTest);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSrvSystemSelfTest not implemented"));
   return 0;
}

/**
 * Method: ulwGetSrvSDCardWriteProtectionStatus
  * Returns the status of SD CARD
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetSrvSDCardWriteProtectionStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSrvSDCardWriteProtectionStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetImmobilizerLockState
  * Returns the Lock State
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetImmobilizerLockState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetImmobilizerLockState not implemented"));
   return 0;
}

/**
 * Method: vSetImmobilizerLockStateToUnLock
  * Set the HMI State to normal for a defined time
  * NISSAN
 */
void clHSA_System_Base::vSetImmobilizerLockStateToUnLock( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vSetImmobilizerLockStateToUnLock not implemented"));
   
}

/**
 * Method: ulwGetSrvSystemConfig
  * Returns the System Config
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetSrvSystemConfig(ulword ulwSystemConfig)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSystemConfig);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSrvSystemConfig not implemented"));
   return 0;
}

/**
 * Method: vGetXMTunerFirmwareVersion
  * Returns System XMTuner Firmware Version as a string
  * NISSAN NAR
 */
void clHSA_System_Base::vGetXMTunerFirmwareVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetXMTunerFirmwareVersion not implemented"));
   
}

/**
 * Method: vGetBTHF_BoxVersion
  * Returns System BTHF BoxVersion as a string
  * NISSAN NAR
 */
void clHSA_System_Base::vGetBTHF_BoxVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetBTHF_BoxVersion not implemented"));
   
}

/**
 * Method: ulwGetDisplayMode
  * returns the current selected display mode
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetDisplayMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetDisplayMode not implemented"));
   return 0;
}

/**
 * Method: ulwGetDisplayTestScreen
  * Returns the display test screen for production diagnosis
  * B1
 */
ulword clHSA_System_Base::ulwGetDisplayTestScreen( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetDisplayTestScreen not implemented"));
   return 0;
}

/**
 * Method: blGetNavDisclaimerConfirmed
  * Returns information if Nav disclaimer has been confirmed once since coldstart
  * NISSAN
 */
tbool clHSA_System_Base::blGetNavDisclaimerConfirmed( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blGetNavDisclaimerConfirmed not implemented"));
   return 0;
}

/**
 * Method: vSetNavDisclaimerConfirmed
  * Sets flag that Nav disclaimer has been confirmed
  * NISSAN
 */
void clHSA_System_Base::vSetNavDisclaimerConfirmed( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vSetNavDisclaimerConfirmed not implemented"));
   
}

/**
 * Method: vDisableDestinationInputWhileDriving
  * Destination input while driving will be deactivated forever
  * NISSAN
 */
void clHSA_System_Base::vDisableDestinationInputWhileDriving( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vDisableDestinationInputWhileDriving not implemented"));
   
}

/**
 * Method: blGetDestinationInputWhileDriving
  * Returns whether Destination input while driving is deactivated or not
  * NISSAN
 */
tbool clHSA_System_Base::blGetDestinationInputWhileDriving( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blGetDestinationInputWhileDriving not implemented"));
   return 0;
}

/**
 * Method: vSetBeepMode
  * selects new mode of Beep feedback
  * NISSAN
 */
void clHSA_System_Base::vSetBeepMode(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetBeepMode not implemented"));
   
}

/**
 * Method: ulwGetBeepMode
  * returns the current selected mode of Beep
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetBeepMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetBeepMode not implemented"));
   return 0;
}

/**
 * Method: vToggleDisplayMode
  * Toggles the display mode on pressing HK_ILLUM(day, night,autoday,autonight)
  * NISSAN
 */
void clHSA_System_Base::vToggleDisplayMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vToggleDisplayMode not implemented"));
   
}

/**
 * Method: vLanguageIconSelected
  * Trigger to inform HMI that Language icon is selected
  * NISSAN
 */
void clHSA_System_Base::vLanguageIconSelected( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vLanguageIconSelected not implemented"));
   
}

/**
 * Method: vGetSystemSerialNo
  * Returns System serial no. as a string
  * NISSAN
 */
void clHSA_System_Base::vGetSystemSerialNo(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSystemSerialNo not implemented"));
   
}

/**
 * Method: vGetSystemDeviceNo
  * Returns System device no. as a sting
  * NISSAN
 */
void clHSA_System_Base::vGetSystemDeviceNo(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSystemDeviceNo not implemented"));
   
}

/**
 * Method: vGetSystemProductionDate
  * Returns System production date as a sting
  * NISSAN
 */
void clHSA_System_Base::vGetSystemProductionDate(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSystemProductionDate not implemented"));
   
}

/**
 * Method: vPerformSpeakerTest
  * Performs speaker test
  * NISSAN
 */
void clHSA_System_Base::vPerformSpeakerTest(ulword ulwFrequency)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwFrequency);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vPerformSpeakerTest not implemented"));
   
}

/**
 * Method: vSetEncoderDirection
  * Set the dapapool variale with encoder direction
  * NISSAN
 */
void clHSA_System_Base::vSetEncoderDirection(ulword ulwEncoderDirn)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEncoderDirn);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetEncoderDirection not implemented"));
   
}

/**
 * Method: blGetEncoderDirection
  * Returns the current direction of encoder
  * NISSAN
 */
tbool clHSA_System_Base::blGetEncoderDirection( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blGetEncoderDirection not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentSelfTestProgressValue
  * Returns the progress value of the Self Test
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetCurrentSelfTestProgressValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetCurrentSelfTestProgressValue not implemented"));
   return 0;
}

/**
 * Method: vSetRVCFlag
  * Changes the current status of RVC flag
  * 
 */
void clHSA_System_Base::vSetRVCFlag(tbool blValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetRVCFlag not implemented"));
   
}

/**
 * Method: ulwGetCameraDisplaySettingsPopupState
  * This API returns whether Popup should be shown on RVC screen for the Camera Display adjustment for User.
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetCameraDisplaySettingsPopupState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetCameraDisplaySettingsPopupState not implemented"));
   return 0;
}

/**
 * Method: vSwitchToCameraScreen
  * This API informs VD_RVC to switch to camera screen because of User Camera Display Settings request OR to close the Camera screen.
  * 
 */
void clHSA_System_Base::vSwitchToCameraScreen(tbool blbSwitchStatus, ulword ulwCameraSettingParam)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blbSwitchStatus);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCameraSettingParam);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSwitchToCameraScreen not implemented"));
   
}

/**
 * Method: vToggleGuideLineState
  * Changes the current status of GuideLine
  * 
 */
void clHSA_System_Base::vToggleGuideLineState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vToggleGuideLineState not implemented"));
   
}

/**
 * Method: ulwGetRVCGuideLineStatus
  * Returns the current status of GuideLine
  * 
 */
ulword clHSA_System_Base::ulwGetRVCGuideLineStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetRVCGuideLineStatus not implemented"));
   return 0;
}

/**
 * Method: vInformCameraHKPress
  * API called by GUI while camera HK is pressed by User
  * 
 */
void clHSA_System_Base::vInformCameraHKPress(tbool blCameraHKPressType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blCameraHKPressType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vInformCameraHKPress not implemented"));
   
}

/**
 * Method: ulwGetCameraSystemConfigured
  * Returns the Camera system which is configured in the device
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetCameraSystemConfigured( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetCameraSystemConfigured not implemented"));
   return 0;
}

/**
 * Method: ulwGetCameraRequestState
  * returns camera state
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetCameraRequestState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetCameraRequestState not implemented"));
   return 0;
}

/**
 * Method: blIsCameraReqTimeOutRequired
  * returns whether to start timer when BLACK_IN_NEW shown
  * NISSAN
 */
tbool clHSA_System_Base::blIsCameraReqTimeOutRequired( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsCameraReqTimeOutRequired not implemented"));
   return 0;
}

/**
 * Method: blIsCameraRequestActive
  * returns whether camera request is active or valid. 
  * NISSAN
 */
tbool clHSA_System_Base::blIsCameraRequestActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsCameraRequestActive not implemented"));
   return 0;
}

/**
 * Method: blIsVideoSignalAvailable
  * returns whether video signal is available or not
  * NISSAN
 */
tbool clHSA_System_Base::blIsVideoSignalAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsVideoSignalAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsAVMRequestActive
  * Returns the status of AVM Pin Input Signal Active or not
  * NISSAN
 */
tbool clHSA_System_Base::blIsAVMRequestActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsAVMRequestActive not implemented"));
   return 0;
}

/**
 * Method: blIsAffordableITSAvailable
  * returns whether ITS is available or not. Depending on the return value, camera config menu will be shown or hidden
  * NISSAN
 */
tbool clHSA_System_Base::blIsAffordableITSAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsAffordableITSAvailable not implemented"));
   return 0;
}

/**
 * Method: vSwitchOffCamera
  * This API sends switch off request to RVC / AVM / RVC_Tailgate unit depending the configured system
  * NISSAN
 */
void clHSA_System_Base::vSwitchOffCamera( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vSwitchOffCamera not implemented"));
   
}

/**
 * Method: ulwGetCameraConfigStatus
  * returns the status of camera config items
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetCameraConfigStatus(ulword ulwConfigParam)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwConfigParam);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetCameraConfigStatus not implemented"));
   return 0;
}

/**
 * Method: vToggleCameraConfigStatus
  * Inform AVM to toggle the requested camera config item status.
  * NISSAN
 */
void clHSA_System_Base::vToggleCameraConfigStatus(ulword ulwConfigParam)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwConfigParam);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vToggleCameraConfigStatus not implemented"));
   
}

/**
 * Method: ulwGetVideoDimming
  * Returns the value of either Video Brightness, Contrast or Color
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetVideoDimming(ulword ulwDimmingParam)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDimmingParam);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetVideoDimming not implemented"));
   return 0;
}

/**
 * Method: vInformAVMOnPurposeSwitch
  * This is called in AVM screen on Purpose Switch key press
  * NISSAN
 */
void clHSA_System_Base::vInformAVMOnPurposeSwitch( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vInformAVMOnPurposeSwitch not implemented"));
   
}

/**
 * Method: vSetVideoDimming
  * Sets the Video Brightness, Constrast and color depending on the parameter
  * NISSAN
 */
void clHSA_System_Base::vSetVideoDimming(ulword ulwDimmingParam, tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDimmingParam);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetVideoDimming not implemented"));
   
}

/**
 * Method: vIPA_SendButtonPress
  * This API sends IPA button press information to IPA unit.
  * NISSAN
 */
void clHSA_System_Base::vIPA_SendButtonPress(ulword ulwButtonIdentifier, ulword ulwButtonState)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwButtonIdentifier);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwButtonState);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vIPA_SendButtonPress not implemented"));
   
}

/**
 * Method: vIPA_SetHMIStatus
  * This API sends IPA status at HMI to MIDW RVC. It informs whether IPA is active or inactive at HMI.
  * NISSAN
 */
void clHSA_System_Base::vIPA_SetHMIStatus(tbool blHmiStatus)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blHmiStatus);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vIPA_SetHMIStatus not implemented"));
   
}

/**
 * Method: ulwIPA_GetAvailablityStatus
  * Returns IPA availability status
  * NISSAN
 */
ulword clHSA_System_Base::ulwIPA_GetAvailablityStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwIPA_GetAvailablityStatus not implemented"));
   return 0;
}

/**
 * Method: ulwIPA_GetConfiguredRegion
  * Returns configured reqion for IPA
  * NISSAN
 */
ulword clHSA_System_Base::ulwIPA_GetConfiguredRegion( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwIPA_GetConfiguredRegion not implemented"));
   return 0;
}

/**
 * Method: ulwIPA_GetMessageRequested
  * Returns current requested message lines by IPA
  * NISSAN
 */
ulword clHSA_System_Base::ulwIPA_GetMessageRequested( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwIPA_GetMessageRequested not implemented"));
   return 0;
}

/**
 * Method: ulwIPA_GetPatternRequested
  * Returns current requested screen pattern by IPA
  * NISSAN
 */
ulword clHSA_System_Base::ulwIPA_GetPatternRequested( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwIPA_GetPatternRequested not implemented"));
   return 0;
}

/**
 * Method: ulwIPA_GetPopupRequested
  * Returns current requested popup by IPA.
  * NISSAN
 */
ulword clHSA_System_Base::ulwIPA_GetPopupRequested( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwIPA_GetPopupRequested not implemented"));
   return 0;
}

/**
 * Method: ulwIPA_GetOperationStatus
  * Returns IPA Status
  * NISSAN
 */
ulword clHSA_System_Base::ulwIPA_GetOperationStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwIPA_GetOperationStatus not implemented"));
   return 0;
}

/**
 * Method: ulwIPA_GetMode
  * Returns IPA Mode
  * NISSAN
 */
ulword clHSA_System_Base::ulwIPA_GetMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwIPA_GetMode not implemented"));
   return 0;
}

/**
 * Method: ulwIPA_GetCarDirection_Indicator_Status
  * Returns the direction of the moving car and IPA indicator status
  * NISSAN
 */
ulword clHSA_System_Base::ulwIPA_GetCarDirection_Indicator_Status( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwIPA_GetCarDirection_Indicator_Status not implemented"));
   return 0;
}

/**
 * Method: ulwIPA_GetButtonVisibilityStatus
  * Returns the visibility status of the buttons depending on the switch mask
  * NISSAN
 */
ulword clHSA_System_Base::ulwIPA_GetButtonVisibilityStatus(ulword ulwButtonIdentifier)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwButtonIdentifier);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwIPA_GetButtonVisibilityStatus not implemented"));
   return 0;
}

/**
 * Method: blSONAR_GetVisualizationStatus
  * Returns Sonar visualization status
  * NISSAN
 */
tbool clHSA_System_Base::blSONAR_GetVisualizationStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blSONAR_GetVisualizationStatus not implemented"));
   return 0;
}

/**
 * Method: ulwSONAR_GetCarShapeModel
  * Returns car shape configured for Sonar
  * NISSAN
 */
ulword clHSA_System_Base::ulwSONAR_GetCarShapeModel( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwSONAR_GetCarShapeModel not implemented"));
   return 0;
}

/**
 * Method: ulwSONAR_GetAvailabilityStatus
  * Returns the type of Sonar configured
  * NISSAN
 */
ulword clHSA_System_Base::ulwSONAR_GetAvailabilityStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwSONAR_GetAvailabilityStatus not implemented"));
   return 0;
}

/**
 * Method: blSONAR_GetSonarSwitchAvailability
  * Returns the availability of Sonar switch
  * NISSAN
 */
tbool clHSA_System_Base::blSONAR_GetSonarSwitchAvailability( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blSONAR_GetSonarSwitchAvailability not implemented"));
   return 0;
}

/**
 * Method: blSONAR_GetErrorStatus
  * Returns the error status of Sonar
  * NISSAN
 */
tbool clHSA_System_Base::blSONAR_GetErrorStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blSONAR_GetErrorStatus not implemented"));
   return 0;
}

/**
 * Method: ulwSONAR_GetFrontSensorAvailability
  * Returns the availability of Front Left Corner, Front Center and Front Right Corner sensors
  * NISSAN
 */
ulword clHSA_System_Base::ulwSONAR_GetFrontSensorAvailability( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwSONAR_GetFrontSensorAvailability not implemented"));
   return 0;
}

/**
 * Method: ulwSONAR_GetRearSensorAvailability
  * Returns the availability of Rear Left Corner, Rear Center and Rear Right Corner sensors
  * NISSAN
 */
ulword clHSA_System_Base::ulwSONAR_GetRearSensorAvailability( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwSONAR_GetRearSensorAvailability not implemented"));
   return 0;
}

/**
 * Method: ulwSONAR_GetFrontSensorDistanceLevels
  * Returns the distance levels of Front Left Corner, Front Center and Front Right Corner sensors
  * NISSAN
 */
ulword clHSA_System_Base::ulwSONAR_GetFrontSensorDistanceLevels( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwSONAR_GetFrontSensorDistanceLevels not implemented"));
   return 0;
}

/**
 * Method: ulwSONAR_GetRearSensorDistanceLevels
  * Returns the distance levels of Rear Left Corner, Rear Center and Rear Right Corner sensors
  * NISSAN
 */
ulword clHSA_System_Base::ulwSONAR_GetRearSensorDistanceLevels( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwSONAR_GetRearSensorDistanceLevels not implemented"));
   return 0;
}

/**
 * Method: blSONAR_GetSystemStatus
  * Returns the status of Sonar System
  * NISSAN
 */
tbool clHSA_System_Base::blSONAR_GetSystemStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blSONAR_GetSystemStatus not implemented"));
   return 0;
}

/**
 * Method: blSONAR_GetFrontSensorsOnlyStatus
  * Returns whether only Front sensors are On or Off
  * NISSAN
 */
tbool clHSA_System_Base::blSONAR_GetFrontSensorsOnlyStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blSONAR_GetFrontSensorsOnlyStatus not implemented"));
   return 0;
}

/**
 * Method: blSONAR_GetAutomaticDisplayStatus
  * Returns whether Automatic Display for Front sensors is On or Off
  * NISSAN
 */
tbool clHSA_System_Base::blSONAR_GetAutomaticDisplayStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blSONAR_GetAutomaticDisplayStatus not implemented"));
   return 0;
}

/**
 * Method: ulwSONAR_GetSensitivityLevel
  * Returns the sensitivity level of Sonar
  * NISSAN
 */
ulword clHSA_System_Base::ulwSONAR_GetSensitivityLevel( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwSONAR_GetSensitivityLevel not implemented"));
   return 0;
}

/**
 * Method: ulwSONAR_GetVolumeLevel
  * Returns the volume level of Sonar
  * NISSAN
 */
ulword clHSA_System_Base::ulwSONAR_GetVolumeLevel( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwSONAR_GetVolumeLevel not implemented"));
   return 0;
}

/**
 * Method: vToggleSonarCancelSwitchStatus
  * User changes the current status of Sonar switch
  * 
 */
void clHSA_System_Base::vToggleSonarCancelSwitchStatus( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vToggleSonarCancelSwitchStatus not implemented"));
   
}

/**
 * Method: vToggleSonarSystemOption
  * User changes the current status of Sonar System option in the Sonar Settings screen
  * 
 */
void clHSA_System_Base::vToggleSonarSystemOption( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vToggleSonarSystemOption not implemented"));
   
}

/**
 * Method: vToggleFrontSensorsOnlyOption
  * User changes the current status of Front Sensors Only option in the Sonar Settings screen
  * 
 */
void clHSA_System_Base::vToggleFrontSensorsOnlyOption( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vToggleFrontSensorsOnlyOption not implemented"));
   
}

/**
 * Method: vToggleAutomaticDisplayOption
  * User changes the current status of Automatic Display option in the Sonar Settings screen
  * 
 */
void clHSA_System_Base::vToggleAutomaticDisplayOption( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vToggleAutomaticDisplayOption not implemented"));
   
}

/**
 * Method: vSetSonarSensitivityLevel
  * User changes the current status of Sensitivity option in the Sonar Settings screen
  * 
 */
void clHSA_System_Base::vSetSonarSensitivityLevel( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vSetSonarSensitivityLevel not implemented"));
   
}

/**
 * Method: vSetSonarVolumeLevel
  * User changes the current status of Volume option in the Sonar Settings screen
  * 
 */
void clHSA_System_Base::vSetSonarVolumeLevel( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vSetSonarVolumeLevel not implemented"));
   
}

/**
 * Method: ulwSONAR_GetSonarMenu
  * Returns the Vehicle Type based on which the set of items to be displayed in Sonar Menu are decided
  * NISSAN
 */
ulword clHSA_System_Base::ulwSONAR_GetSonarMenu( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwSONAR_GetSonarMenu not implemented"));
   return 0;
}

/**
 * Method: vGetSystemConfig
  * Returns the System Config
  * NISSAN
 */
void clHSA_System_Base::vGetSystemConfig(GUI_String *out_result, ulword ulwSystemConfig)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSystemConfig);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSystemConfig not implemented"));
   
}

/**
 * Method: vGetSystemHistory
  * Returns the System History
  * NISSAN
 */
void clHSA_System_Base::vGetSystemHistory(GUI_String *out_result, ulword ulwSystemHistory)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSystemHistory);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSystemHistory not implemented"));
   
}

/**
 * Method: vGetSystemSelfTest
  * Returns the System SelfTest
  * NISSAN
 */
void clHSA_System_Base::vGetSystemSelfTest(GUI_String *out_result, ulword ulwSystemSelfTest)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSystemSelfTest);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSystemSelfTest not implemented"));
   
}

/**
 * Method: vStartSelfTest
  * Starts System SelfTest
  * NISSAN
 */
void clHSA_System_Base::vStartSelfTest( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vStartSelfTest not implemented"));
   
}

/**
 * Method: vGetUSBSlotMedium
  * returns USB media type for each possible device
  * NISSAN
 */
void clHSA_System_Base::vGetUSBSlotMedium(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetUSBSlotMedium not implemented"));
   
}

/**
 * Method: ulwGetViaGPSTimeStatus
  * returns whether GPS Time Status is enabled or disabled
  * 
 */
ulword clHSA_System_Base::ulwGetViaGPSTimeStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetViaGPSTimeStatus not implemented"));
   return 0;
}

/**
 * Method: vToggleViaGPSTimeStatus
  * Toggles the GPS Time Status between TRUE and FALSE
  * 
 */
void clHSA_System_Base::vToggleViaGPSTimeStatus( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vToggleViaGPSTimeStatus not implemented"));
   
}

/**
 * Method: blGetSummerTimeStatus
  * returns Flag indicating whether DST is On or Off
  * 
 */
tbool clHSA_System_Base::blGetSummerTimeStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blGetSummerTimeStatus not implemented"));
   return 0;
}

/**
 * Method: vToggleSummerTimeStatus
  * Toggles the Summer Time Status between TRUE and FALSE
  * 
 */
void clHSA_System_Base::vToggleSummerTimeStatus( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vToggleSummerTimeStatus not implemented"));
   
}

/**
 * Method: vGetCurrentTZ
  * returns the Description of the current TimeZone
  * 
 */
void clHSA_System_Base::vGetCurrentTZ(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetCurrentTZ not implemented"));
   
}

/**
 * Method: ulwGetCurrentTZIndex
  * returns the Index of the current TimeZone
  * 
 */
ulword clHSA_System_Base::ulwGetCurrentTZIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetCurrentTZIndex not implemented"));
   return 0;
}

/**
 * Method: ulwGetTZListCount
  * returns the TimeZone list count
  * 
 */
ulword clHSA_System_Base::ulwGetTZListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetTZListCount not implemented"));
   return 0;
}

/**
 * Method: vGetTZListElement
  * returns the description of TimeZone for the given index
  * 
 */
void clHSA_System_Base::vGetTZListElement(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetTZListElement not implemented"));
   
}

/**
 * Method: vSetTZ
  * set the current TimeZone to the given index
  * 
 */
void clHSA_System_Base::vSetTZ(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetTZ not implemented"));
   
}

/**
 * Method: vIncreaseTimeHour
  * Increments the Hour value by 1
  * 
 */
void clHSA_System_Base::vIncreaseTimeHour( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vIncreaseTimeHour not implemented"));
   
}

/**
 * Method: vDateHandling
  * Day,month,year can be increased decreased
  * 
 */
void clHSA_System_Base::vDateHandling(ulword ulwType, tbool blOperation)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blOperation);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vDateHandling not implemented"));
   
}

/**
 * Method: vToggleDateFormat
  * toggles the Date format from dd mm yyyy to mm dd yyyy
  * NISSAN 2.0
 */
void clHSA_System_Base::vToggleDateFormat( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vToggleDateFormat not implemented"));
   
}

/**
 * Method: ulwGetDateFormat
  * Returns whether date mode is dd mm yyyy or mm dd yyyy
  * B2
 */
ulword clHSA_System_Base::ulwGetDateFormat( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetDateFormat not implemented"));
   return 0;
}

/**
 * Method: vDecreaseTimeHour
  * Decrements the Hour value by 1
  * 
 */
void clHSA_System_Base::vDecreaseTimeHour( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vDecreaseTimeHour not implemented"));
   
}

/**
 * Method: ulwGetTimeHour
  * returns the current time Hour
  * 
 */
ulword clHSA_System_Base::ulwGetTimeHour( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetTimeHour not implemented"));
   return 0;
}

/**
 * Method: vIncreaseTimeMinute
  * Increments the Minute value by 1
  * 
 */
void clHSA_System_Base::vIncreaseTimeMinute( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vIncreaseTimeMinute not implemented"));
   
}

/**
 * Method: vIncreaseDateDay
  * Increments the current value by 1 if the date falls with in the current days of the month other wise Date will be wrapped to the next possible value
  * 
 */
void clHSA_System_Base::vIncreaseDateDay( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vIncreaseDateDay not implemented"));
   
}

/**
 * Method: vIncreaseDateMonth
  * Increments the current value by 1 if the date falls with in the current days of the month other wise Date will be wrapped to the next possible value
  * 
 */
void clHSA_System_Base::vIncreaseDateMonth( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vIncreaseDateMonth not implemented"));
   
}

/**
 * Method: vIncreaseDateYear
  * Increments the current value by 1 if the date falls with in the current days of the month other wise Date will be wrapped to the next possible value
  * 
 */
void clHSA_System_Base::vIncreaseDateYear( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vIncreaseDateYear not implemented"));
   
}

/**
 * Method: vDecreaseTimeMinute
  * Decrements the Minute value by 1
  * 
 */
void clHSA_System_Base::vDecreaseTimeMinute( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vDecreaseTimeMinute not implemented"));
   
}

/**
 * Method: vDecreaseDateDay
  * Decrements the current value by 1 if the date falls with in the current days of the month other wise Date will be wrapped to the next possible value
  * 
 */
void clHSA_System_Base::vDecreaseDateDay( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vDecreaseDateDay not implemented"));
   
}

/**
 * Method: vDecreaseDateMonth
  * Decrements the current value by 1 if the Month falls with in the range of the months other wise Month will be wrapped to the next possible value
  * 
 */
void clHSA_System_Base::vDecreaseDateMonth( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vDecreaseDateMonth not implemented"));
   
}

/**
 * Method: vDecreaseDateYear
  * Decrements the current value of the year by 1 and the Minimum possible value of Year is 2010
  * 
 */
void clHSA_System_Base::vDecreaseDateYear( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vDecreaseDateYear not implemented"));
   
}

/**
 * Method: ulwGetTimeMinute
  * returns the current time Minute
  * 
 */
ulword clHSA_System_Base::ulwGetTimeMinute( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetTimeMinute not implemented"));
   return 0;
}

/**
 * Method: vActivateFirstMediaData
  * activates the first file of the requested Data e.g. CD or SD-CARD with audiofiles, playlists, pictures or other formats.
  * B2
 */
void clHSA_System_Base::vActivateFirstMediaData(ulword ulwSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSource);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vActivateFirstMediaData not implemented"));
   
}

/**
 * Method: blAreRearSpeakersAssembled
  * returns whether rearseatspeakers are integrated or not
  * B2
 */
tbool clHSA_System_Base::blAreRearSpeakersAssembled( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blAreRearSpeakersAssembled not implemented"));
   return 0;
}

/**
 * Method: vCancelSoftwareDownload
  * indicates that  the software download mode is canceled
  * B
 */
void clHSA_System_Base::vCancelSoftwareDownload( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vCancelSoftwareDownload not implemented"));
   
}

/**
 * Method: blCheckAssemblyUnlock
  * returns true, if the System was entered by code_unlock_at_assembly_line. After 15 minutes, the system should go to HMI_OFF, only if it was entered by AssemblyUnlock. Otherwise the HMI ignores the 15-minute-timeout 
  * B2
 */
tbool clHSA_System_Base::blCheckAssemblyUnlock( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blCheckAssemblyUnlock not implemented"));
   return 0;
}

/**
 * Method: ulwCheckCode
  * System-PIN: activates checking of the system-PIN code 
  * B2
 */
ulword clHSA_System_Base::ulwCheckCode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwCheckCode not implemented"));
   return 0;
}

/**
 * Method: ulwCheckSDCode
  * SD-PIN: activates checking of the SD-PIN code 
  * NISSAN
 */
ulword clHSA_System_Base::ulwCheckSDCode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwCheckSDCode not implemented"));
   return 0;
}

/**
 * Method: ulwCheckComfortCoding
  * System-PIN: checks the Comfort Coding state for system code check
  * B2
 */
ulword clHSA_System_Base::ulwCheckComfortCoding( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwCheckComfortCoding not implemented"));
   return 0;
}

/**
 * Method: ulwCheckSDPaired
  * SD-PIN: checks PAIRED state for SD code check
  * NISSAN
 */
ulword clHSA_System_Base::ulwCheckSDPaired( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwCheckSDPaired not implemented"));
   return 0;
}

/**
 * Method: ulwCheckSDPINRequirement
  * SD-PIN: checks if SD code input is required
  * NISSAN
 */
ulword clHSA_System_Base::ulwCheckSDPINRequirement( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwCheckSDPINRequirement not implemented"));
   return 0;
}

/**
 * Method: vCheckSpellerDisclaimer
  * checks if there was a disclaimer already shown and confirmed. if it was'nt confirmed the System has to send the systemevent SYSTEM_SHOW_SPELLER_DISCLAIMER to indicate showing the disclaimer.
  * B2
 */
void clHSA_System_Base::vCheckSpellerDisclaimer( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vCheckSpellerDisclaimer not implemented"));
   
}

/**
 * Method: vCodeInput
  * enter one character of the PIN Code of the whole system (speller input function). Used in the speller to send the character chosen in the widget to the application.  This APICall will also be used for deleting characters, by sending the unicode F808.
  * B2
 */
void clHSA_System_Base::vCodeInput(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vCodeInput not implemented"));
   
}

/**
 * Method: vSDCodeInput
  * enter one character of the PIN Code of the Navi SD card (speller input function). Used in the speller to send the character chosen in the widget to the application.  This APICall will also be used for deleting characters, by sending the unicode F808.
  * NISSAN
 */
void clHSA_System_Base::vSDCodeInput(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSDCodeInput not implemented"));
   
}

/**
 * Method: blSetupGetPresetMenu
  * Status of activated/deactivated preset ot menu group on Map
  * NISSAN 2.0
 */
tbool clHSA_System_Base::blSetupGetPresetMenu( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blSetupGetPresetMenu not implemented"));
   return 0;
}

/**
 * Method: vSetupSetPresetMenu
  * Status of activated/deactivated preset ot menu group on Map
  * NISSAN 2.0
 */
void clHSA_System_Base::vSetupSetPresetMenu(tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetupSetPresetMenu not implemented"));
   
}

/**
 * Method: ulwGetSizeofDisplay
  * returns the current display size
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetSizeofDisplay( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSizeofDisplay not implemented"));
   return 0;
}

/**
 * Method: vCreateBeep
  * Creates a system beep to signal an error (e.g. function not possible) or a confirmation (e.g. radio station saved after a long press on a preset button).
  * B1
 */
void clHSA_System_Base::vCreateBeep( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vCreateBeep not implemented"));
   
}

/**
 * Method: vCreateBeepX
  * Creates a system beep to signal an error (e.g. function not possible) or a confirmation (e.g. radio station saved                                                                                         after a long press on a preset button).
  * B1
 */
void clHSA_System_Base::vCreateBeepX(ulword ulwBeepType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBeepType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vCreateBeepX not implemented"));
   
}

/**
 * Method: vEjectCD
  * requests the ejection of the CD
  * B
 */
void clHSA_System_Base::vEjectCD( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vEjectCD not implemented"));
   
}

/**
 * Method: ulwGetAcousticTouchscreenFeedback
  * returns the current selected mode of acoustic feedback
  * B2
 */
ulword clHSA_System_Base::ulwGetAcousticTouchscreenFeedback( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetAcousticTouchscreenFeedback not implemented"));
   return 0;
}

/**
 * Method: ulwGetBluetoothSWProgress
  * Returns the progress of Bluetooth-Software Update.
  * B1
 */
ulword clHSA_System_Base::ulwGetBluetoothSWProgress( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetBluetoothSWProgress not implemented"));
   return 0;
}

/**
 * Method: ulwGetClimateAirflowBody
  * Returns the currently set range of Airflow Body of all seats (selectable)
  * B2
 */
ulword clHSA_System_Base::ulwGetClimateAirflowBody(ulword ulwSeat)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSeat);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetClimateAirflowBody not implemented"));
   return 0;
}

/**
 * Method: ulwGetClimateAirflowFootwell
  * Returns the currently set range of Airflow Footwell of all seats (selectable)
  * B2
 */
ulword clHSA_System_Base::ulwGetClimateAirflowFootwell(ulword ulwSeat)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSeat);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetClimateAirflowFootwell not implemented"));
   return 0;
}

/**
 * Method: ulwGetClimateAirflowRange
  * Returns the range of air that floods the car Values gt 7 sould be set to 7
  * B2
 */
ulword clHSA_System_Base::ulwGetClimateAirflowRange( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetClimateAirflowRange not implemented"));
   return 0;
}

/**
 * Method: ulwGetClimateAirflowUp
  * Returns the currently set range of Airflow Up of all seats (selectable)
  * B2
 */
ulword clHSA_System_Base::ulwGetClimateAirflowUp(ulword ulwSeat)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSeat);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetClimateAirflowUp not implemented"));
   return 0;
}

/**
 * Method: ulwGetClimateContext
  * returns the current context: e.g. seatheater, airflow, temperature, statusicon
  * B2
 */
ulword clHSA_System_Base::ulwGetClimateContext( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetClimateContext not implemented"));
   return 0;
}

/**
 * Method: ulwGetClimateCurrentStatusIcon
  * returns the currently activated / deactivated stausicon.
  * B2
 */
ulword clHSA_System_Base::ulwGetClimateCurrentStatusIcon( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetClimateCurrentStatusIcon not implemented"));
   return 0;
}

/**
 * Method: ulwGetClimatePopupDuration
  * returns the currently selected duration of the climate-popup
  * B2
 */
ulword clHSA_System_Base::ulwGetClimatePopupDuration( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetClimatePopupDuration not implemented"));
   return 0;
}

/**
 * Method: ulwGetClimateRearState
  * returns if all displayed climate values are displayed for the 2nd row. If true temperature and vent setting displayed will be the rear values.
  * B2
 */
ulword clHSA_System_Base::ulwGetClimateRearState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetClimateRearState not implemented"));
   return 0;
}

/**
 * Method: ulwGetClimateSeatheat
  * Gets the currently set seatheat of the (selectable) seat
  * B2
 */
ulword clHSA_System_Base::ulwGetClimateSeatheat(ulword ulwSeat)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSeat);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetClimateSeatheat not implemented"));
   return 0;
}

/**
 * Method: vGetClimateStatusIcons
  * returns the stautsicons as a String to display in the statusline. The Space between the Symbols depends on the number of statusicons: When showing 2-5 statusicons, U+00c2 �Clim_Blank_L_UL.png� has to be used as spacer between the icons.  When 6 or 7 icons are displayed, U+00c3 �Clim_Blank_S_UL.png� has to be used as spacer. For 8-9 icons no spacer has to be used.
  * B2
 */
void clHSA_System_Base::vGetClimateStatusIcons(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetClimateStatusIcons not implemented"));
   
}

/**
 * Method: vGetCodeInput
  * Returns the whole entered PIN Code (the combined characters send by CodeInput)
  * B2
 */
void clHSA_System_Base::vGetCodeInput(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetCodeInput not implemented"));
   
}

/**
 * Method: vGetSDCodeInput
  * Returns the so far entered SD PIN Code (the combined characters sent by CodeInput)
  * NISSAN
 */
void clHSA_System_Base::vGetSDCodeInput(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSDCodeInput not implemented"));
   
}

/**
 * Method: ulwGetCurrentDistanceUnit
  * returns an identifier that represents the current set distance-unit
  * B2
 */
ulword clHSA_System_Base::ulwGetCurrentDistanceUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetCurrentDistanceUnit not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentMenuLanguage
  * returns the name of the currently active language
  * B2
 */
ulword clHSA_System_Base::ulwGetCurrentMenuLanguage( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetCurrentMenuLanguage not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentTemperatureUnit
  * returns a string with a single unicode character representing the �C U+2103 or �F U+2109
  * B2
 */
void clHSA_System_Base::vGetCurrentTemperatureUnit(GUI_String *out_result, ulword ulwSeat)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSeat);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetCurrentTemperatureUnit not implemented"));
   
}

/**
 * Method: ulwGetDABSWProgress
  * Returns the progress of DAB-Software Update.
  * B1
 */
ulword clHSA_System_Base::ulwGetDABSWProgress( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetDABSWProgress not implemented"));
   return 0;
}

/**
 * Method: ulwGetDate
  * Returns the current date
  * B2
 */
ulword clHSA_System_Base::ulwGetDate(ulword ulwYearOrMonthOrDay)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwYearOrMonthOrDay);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetDate not implemented"));
   return 0;
}

/**
 * Method: ulwGetDateMode
  * Returns an enum that describes the current date-format
  * B2
 */
ulword clHSA_System_Base::ulwGetDateMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetDateMode not implemented"));
   return 0;
}

/**
 * Method: vGetDesiredTemperatureAsString
  * Returns the current set temperature that should be at this seat (selectable) formated as a String. See "6.9 FMT_TEMPERATURE" in GUI Widget Catalog for further formatting informations. If Temperature == 0x00 return "High" If Temperature == 0xff (for �F additionally 188 indicates low) return "Low" (without the ") For the numbers use fixwith unicodes beginning with U+F830 = 0
  * B2
 */
void clHSA_System_Base::vGetDesiredTemperatureAsString(GUI_String *out_result, ulword ulwSeat)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSeat);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetDesiredTemperatureAsString not implemented"));
   
}

/**
 * Method: slwGetDisplayBrightness
  * returns the current brightness of the display
  * B1
 */
slword clHSA_System_Base::slwGetDisplayBrightness( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_System::slwGetDisplayBrightness not implemented"));
   return 0;
}

/**
 * Method: ulwGetFGSSWProgress
  * Returns the progress of FGS-Software Update.
  * B1
 */
ulword clHSA_System_Base::ulwGetFGSSWProgress( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetFGSSWProgress not implemented"));
   return 0;
}

/**
 * Method: vGetLanguageCode
  * gets the Code of the currently setten Systemlanguage encoded as descriped in ISO 639-1
  * B
 */
void clHSA_System_Base::vGetLanguageCode(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetLanguageCode not implemented"));
   
}

/**
 * Method: ulwGetLastClamp15OffTime
  * gets the Time in Minutes since the last Clamp15Off. 
  * B2
 */
ulword clHSA_System_Base::ulwGetLastClamp15OffTime( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetLastClamp15OffTime not implemented"));
   return 0;
}

/**
 * Method: ulwGetLastMainContext
  * gets the last context that was saved before Kl15
  * B1
 */
ulword clHSA_System_Base::ulwGetLastMainContext( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetLastMainContext not implemented"));
   return 0;
}

/**
 * Method: ulwGetNavSWProgress
  * Returns the progress of Navigation-Software Update.
  * B1
 */
ulword clHSA_System_Base::ulwGetNavSWProgress( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetNavSWProgress not implemented"));
   return 0;
}

/**
 * Method: vGetOPSCarType
  * returns the name of the recognized cars (e.g. "VW350")
  * B
 */
void clHSA_System_Base::vGetOPSCarType(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetOPSCarType not implemented"));
   
}

/**
 * Method: ulwGetOPSFrontDistance
  * Returns the distance in cm to an obstacle of the respective OPS front sector
  * B
 */
ulword clHSA_System_Base::ulwGetOPSFrontDistance(ulword ulwSector)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSector);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetOPSFrontDistance not implemented"));
   return 0;
}

/**
 * Method: ulwGetOPSNumberOfSectors
  * returns the number of sectors (2-4) 
  * B
 */
ulword clHSA_System_Base::ulwGetOPSNumberOfSectors( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetOPSNumberOfSectors not implemented"));
   return 0;
}

/**
 * Method: ulwGetOPSRearDistance
  * Returns the distance in cm to an obstacle of the respective OPS rear sector
  * B
 */
ulword clHSA_System_Base::ulwGetOPSRearDistance(ulword ulwSector)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSector);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetOPSRearDistance not implemented"));
   return 0;
}

/**
 * Method: blGetOPSRearSensorsOnly
  * returns true if only rear sensors are available
  * B
 */
tbool clHSA_System_Base::blGetOPSRearSensorsOnly( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blGetOPSRearSensorsOnly not implemented"));
   return 0;
}

/**
 * Method: vGetRemainingAttempts
  * System-PIN: returns how many wrong inputs are possible before locking the system
  * B2
 */
void clHSA_System_Base::vGetRemainingAttempts(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetRemainingAttempts not implemented"));
   
}

/**
 * Method: vGetSDRemainingAttempts
  * SD-PIN: returns how many wrong inputs are possible before locking the system
  * NISSAN
 */
void clHSA_System_Base::vGetSDRemainingAttempts(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSDRemainingAttempts not implemented"));
   
}

/**
 * Method: vGetRemainingUnlocks
  * System Unlock at Assembly Line: returns how many unlocks are possible before unlock at assembly line will be disabled
  * B2
 */
void clHSA_System_Base::vGetRemainingUnlocks(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetRemainingUnlocks not implemented"));
   
}

/**
 * Method: ulwGetRVCDark
  * Darken the RVC if the velocity exceeds the threshold. Returns  0 if velocity smaller v_dark 1 if velocity bigger v_dark
  * B
 */
ulword clHSA_System_Base::ulwGetRVCDark( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetRVCDark not implemented"));
   return 0;
}

/**
 * Method: ulwGetRVCMode
  * Returns the active RVC mode (lengthwise or crosswise)
  * B
 */
ulword clHSA_System_Base::ulwGetRVCMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetRVCMode not implemented"));
   return 0;
}

/**
 * Method: ulwGetRVCType
  * Returns the type of RV-Camera: 0 - low 1 - high If a low-Camera is build in, the lengthwise and crosswise - mode cannot be selected (invisible in optionlist)
  * 
 */
ulword clHSA_System_Base::ulwGetRVCType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetRVCType not implemented"));
   return 0;
}

/**
 * Method: vGetSDCardMemoryFree
  * gets the amount of unused space of the SD-Card in MB
  * B2
 */
void clHSA_System_Base::vGetSDCardMemoryFree(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSDCardMemoryFree not implemented"));
   
}

/**
 * Method: vGetSDCardMemoryTotal
  * gets the total size of the SD-Card in MB
  * B2
 */
void clHSA_System_Base::vGetSDCardMemoryTotal(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSDCardMemoryTotal not implemented"));
   
}

/**
 * Method: vGetSDCardMemoryUsedByNAV
  * gets the amount of MBs used by the NAV-Data on the SD-Card
  * B2
 */
void clHSA_System_Base::vGetSDCardMemoryUsedByNAV(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSDCardMemoryUsedByNAV not implemented"));
   
}

/**
 * Method: ulwGetSDChkdskProgress
  * gets the value of progress of chkdsk of SD Card
  * B
 */
ulword clHSA_System_Base::ulwGetSDChkdskProgress( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSDChkdskProgress not implemented"));
   return 0;
}

/**
 * Method: ulwGetSDFormatProgress
  * gets the value of progress of formatting of SD Card
  * B
 */
ulword clHSA_System_Base::ulwGetSDFormatProgress( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSDFormatProgress not implemented"));
   return 0;
}

/**
 * Method: ulwGetSkinDayNight
  * Gets the current skin-mode
  * B2
 */
ulword clHSA_System_Base::ulwGetSkinDayNight( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSkinDayNight not implemented"));
   return 0;
}

/**
 * Method: vGetSoftwareDownloadErrorCode
  * Returns the last Download-error-code if the download failes
  * B1
 */
void clHSA_System_Base::vGetSoftwareDownloadErrorCode(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSoftwareDownloadErrorCode not implemented"));
   
}

/**
 * Method: vGetSoftwareVersionFromCD
  * returns the software version from CD as string
  * B1
 */
void clHSA_System_Base::vGetSoftwareVersionFromCD(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSoftwareVersionFromCD not implemented"));
   
}

/**
 * Method: vGetSoftwareVersionInstalled
  * returns the installed software version as string (same as for VAG diagnosis)
  * B1
 */
void clHSA_System_Base::vGetSoftwareVersionInstalled(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSoftwareVersionInstalled not implemented"));
   
}

/**
 * Method: ulwGetSpellerLayout
  * returns an identifier that represents the current set speller Layout (ABC or QWERTY)
  * B
 */
ulword clHSA_System_Base::ulwGetSpellerLayout( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSpellerLayout not implemented"));
   return 0;
}

/**
 * Method: ulwGetSWUpdateProgress
  * Returns the progress of the entire SW Update Process.
  * B1
 */
ulword clHSA_System_Base::ulwGetSWUpdateProgress( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSWUpdateProgress not implemented"));
   return 0;
}

/**
 * Method: ulwGetSystemCodeCountdownTime
  * gets the remaining countdown time after wrong system code input in minutes
  * B2
 */
ulword clHSA_System_Base::ulwGetSystemCodeCountdownTime( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSystemCodeCountdownTime not implemented"));
   return 0;
}

/**
 * Method: vGetSystemCodeCountdownTimeAsString
  * gets the remaining countdown time after wrong system code input in minutes as a String.
  * B2
 */
void clHSA_System_Base::vGetSystemCodeCountdownTimeAsString(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSystemCodeCountdownTimeAsString not implemented"));
   
}

/**
 * Method: ulwGetSDCodeCountdownTime
  * gets the remaining countdown time after wrong SD code input in minutes
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetSDCodeCountdownTime( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSDCodeCountdownTime not implemented"));
   return 0;
}

/**
 * Method: vGetSDCodeCountdownTimeAsString
  * gets the remaining countdown time after wrong SD code input in minutes as a String.
  * NISSAN
 */
void clHSA_System_Base::vGetSDCodeCountdownTimeAsString(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetSDCodeCountdownTimeAsString not implemented"));
   
}

/**
 * Method: ulwGetSystemOnOffState
  * returns if the system is off or on, related to KL15 or On-Off-Tipper
  * B
 */
ulword clHSA_System_Base::ulwGetSystemOnOffState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSystemOnOffState not implemented"));
   return 0;
}

/**
 * Method: ulwGetSystemSWProgress
  * Returns the progress of System-Software Update.
  * B1
 */
ulword clHSA_System_Base::ulwGetSystemSWProgress( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSystemSWProgress not implemented"));
   return 0;
}

/**
 * Method: ulwGetSystemVendor
  * gets the vendor
  * B2
 */
ulword clHSA_System_Base::ulwGetSystemVendor( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetSystemVendor not implemented"));
   return 0;
}

/**
 * Method: ulwGetWeekdayOfToday
  * Returns the weekday of Today 
  * NISSAN LCN2
 */
ulword clHSA_System_Base::ulwGetWeekdayOfToday( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetWeekdayOfToday not implemented"));
   return 0;
}

/**
 * Method: ulwGetWeekdayOfTomorrow
  * Returns the weekday of Tomorrow 
  * NISSAN LCN2
 */
ulword clHSA_System_Base::ulwGetWeekdayOfTomorrow( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetWeekdayOfTomorrow not implemented"));
   return 0;
}

/**
 * Method: ulwGetTime
  * Returns the current hour, minute or mode according to the given Parameter. Returnvalue for mode: 0 - AM 1 - PM
  * B2
 */
ulword clHSA_System_Base::ulwGetTime(ulword ulwHourOrMinute)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwHourOrMinute);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetTime not implemented"));
   return 0;
}

/**
 * Method: ulwGetTimeFormat
  * Returns whether time mode is 24-hour or 12h
  * B2
 */
ulword clHSA_System_Base::ulwGetTimeFormat( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetTimeFormat not implemented"));
   return 0;
}

/**
 * Method: vGetTimeFormatted
  * Returns the current time formatted according the GUI-Catalog FMT_TIME
  * B2
 */
void clHSA_System_Base::vGetTimeFormatted(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetTimeFormatted not implemented"));
   
}

/**
 * Method: blIsAPSPresent
  * returns whether Park-Distance-Control are integrated or not
  * B
 */
tbool clHSA_System_Base::blIsAPSPresent( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsAPSPresent not implemented"));
   return 0;
}

/**
 * Method: blIsClimateSetupAvailable
  * Returns true if  BAP climate detected and climate-setup-time is supported
  * B2
 */
tbool clHSA_System_Base::blIsClimateSetupAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsClimateSetupAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsClimateStatusLineFunctionOn
  * Returns whether the Fuction turned on (true) or off (false) For the minipopup (timeout or not)
  * B2
 */
tbool clHSA_System_Base::blIsClimateStatusLineFunctionOn( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsClimateStatusLineFunctionOn not implemented"));
   return 0;
}

/**
 * Method: blIsClimateTempChanged
  * Returns whether the temperature of the given seat-index has changed (true) or not (false)
  * B2
 */
tbool clHSA_System_Base::blIsClimateTempChanged(ulword ulwSeat)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSeat);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_System::blIsClimateTempChanged not implemented"));
   return 0;
}

/**
 * Method: blIsClimateTempInRange
  * Returns whether the temperature of the given seat-index is in range (true) or not (false) - for displaying the temperature if in range in a different style than HIGH/LOW if not
  * B2
 */
tbool clHSA_System_Base::blIsClimateTempInRange(ulword ulwSeat)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSeat);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_System::blIsClimateTempInRange not implemented"));
   return 0;
}

/**
 * Method: blIsDateFormatMasterPresent
  * is a date format master present or not
  * B2
 */
tbool clHSA_System_Base::blIsDateFormatMasterPresent( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsDateFormatMasterPresent not implemented"));
   return 0;
}

/**
 * Method: blIsDateMasterPresent
  * is a date master present or not
  * B2
 */
tbool clHSA_System_Base::blIsDateMasterPresent( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsDateMasterPresent not implemented"));
   return 0;
}

/**
 * Method: slwIsDateValid
  * Returns the result of the validation caused by the function SaveDate. Instandly by calling the SaveDate method, the returnvalue of IsDateValid changes to -1. If the setten Datevalues are invalid (see SaveDate) the HMI has to show a warning and return to the Datesetup. If the setten Datevalues are valid, the Datevalues overwrite the systemdate. 
  * B2
 */
slword clHSA_System_Base::slwIsDateValid( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_System::slwIsDateValid not implemented"));
   return 0;
}

/**
 * Method: blIsOPSPresent
  * returns whether Optical-Parking-System are integrated or not
  * B
 */
tbool clHSA_System_Base::blIsOPSPresent( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsOPSPresent not implemented"));
   return 0;
}

/**
 * Method: blIsOPSTrailerRecognized
  * returns true if a car trailer is recognized
  * B
 */
tbool clHSA_System_Base::blIsOPSTrailerRecognized( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsOPSTrailerRecognized not implemented"));
   return 0;
}

/**
 * Method: blIsRearGearActive
  * checks whether the Rear-Gear is active or not
  * B2
 */
tbool clHSA_System_Base::blIsRearGearActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsRearGearActive not implemented"));
   return 0;
}

/**
 * Method: blIsRVCRequestActive
  * checks whether a RVCRequest is active. Needs to be checked bevor the user can switch to RVC. If the RVCRequest wasn't sent befor, the button should be disabled.
  * B2
 */
tbool clHSA_System_Base::blIsRVCRequestActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsRVCRequestActive not implemented"));
   return 0;
}

/**
 * Method: ulwIsSDCardAvailable
  * checks whether a SD-Card is inserted or not
  * B2
 */
ulword clHSA_System_Base::ulwIsSDCardAvailable( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwIsSDCardAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsSDCardInUse
  * checks whether a SD-Card is in use (read or write access) or not
  * B2
 */
tbool clHSA_System_Base::blIsSDCardInUse( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsSDCardInUse not implemented"));
   return 0;
}

/**
 * Method: blIsSkodaExternalAmpAvailable
  * Returns if external amplifier in Skoda connected
  * B2
 */
tbool clHSA_System_Base::blIsSkodaExternalAmpAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsSkodaExternalAmpAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsSWDownloadPossible
  * Returns true if a Download of a software CD is possible. It returns false if no CD is inserted or the provided Version is not compatible with the Hardware. 
  * B1
 */
tbool clHSA_System_Base::blIsSWDownloadPossible( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsSWDownloadPossible not implemented"));
   return 0;
}

/**
 * Method: blIsTimeFormatMasterPresent
  * is a time format master present or not
  * B2
 */
tbool clHSA_System_Base::blIsTimeFormatMasterPresent( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsTimeFormatMasterPresent not implemented"));
   return 0;
}

/**
 * Method: blIsTimeMasterPresent
  * is a time master present or not
  * B2
 */
tbool clHSA_System_Base::blIsTimeMasterPresent( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsTimeMasterPresent not implemented"));
   return 0;
}

/**
 * Method: slwIsTimeValid
  * Returns the result of the validation caused by the function SaveTime. Instandly by calling the SaveTime method, the returnvalue of IsTimeValid changes to -1. If the setten Timevalues are invalid the HMI has to show a warning and return to the Timesetup. if the setten Timevalues are valid, the Timevalues overwirte the systemtime. 
  * B2
 */
slword clHSA_System_Base::slwIsTimeValid( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_System::slwIsTimeValid not implemented"));
   return 0;
}

/**
 * Method: vLockDDSEventFocus
  * locks the DDS so not all left / right-rotate-events will be send into the HMI - but does not have effect on DDS-Pressed
  * B1
 */
void clHSA_System_Base::vLockDDSEventFocus( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vLockDDSEventFocus not implemented"));
   
}

/**
 * Method: vLockDDSVolumeFocus
  * locks the DDS (Volume) so not all left / right-rotate-events will be send into the HMI - but does not have effect on DDS-Pressed
  * B1
 */
void clHSA_System_Base::vLockDDSVolumeFocus( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vLockDDSVolumeFocus not implemented"));
   
}

/**
 * Method: vRestartSystem
  * Restarts the entire System after a Softwareupdate
  * B1
 */
void clHSA_System_Base::vRestartSystem( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vRestartSystem not implemented"));
   
}

/**
 * Method: vRestoreDDSSpeedup
  * disables the speedup functionality of the RE
  * B
 */
void clHSA_System_Base::vRestoreDDSSpeedup( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vRestoreDDSSpeedup not implemented"));
   
}

/**
 * Method: vRestoreDDSVolumeSpeedup
  * disables the speedup functionality of the VolumeRE
  * B
 */
void clHSA_System_Base::vRestoreDDSVolumeSpeedup( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vRestoreDDSVolumeSpeedup not implemented"));
   
}

/**
 * Method: vSaveDate
  * Initiate the validation of the currently setten temporary datevalue. Only If the datevalue is valid, the Systemdate will be overwritten. (see also the IsDateValid)
  * B2
 */
void clHSA_System_Base::vSaveDate( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vSaveDate not implemented"));
   
}

/**
 * Method: vSaveTime
  * Initiate the validation of the currently setten temporary timevalue. Only If the timevalue is valid, the Systemtime will be overwritten. (see also the IsTimeValid)
  * B2
 */
void clHSA_System_Base::vSaveTime( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vSaveTime not implemented"));
   
}

/**
 * Method: vDURSnooze
  * executes Snooze of the Data Update Reminder - makes it sleep for one day
  * B?
 */
void clHSA_System_Base::vDURSnooze( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vDURSnooze not implemented"));
   
}

/**
 * Method: vDURDismiss
  * executes Dismiss of the Data Update Reminder - makes it sleep for one year
  * B?
 */
void clHSA_System_Base::vDURDismiss( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vDURDismiss not implemented"));
   
}

/**
 * Method: vSetAcousticTouchscreenFeedback
  * selects new mode of acoustic feedback
  * B2
 */
void clHSA_System_Base::vSetAcousticTouchscreenFeedback(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetAcousticTouchscreenFeedback not implemented"));
   
}

/**
 * Method: vSetClimatePopupDuration
  * sets the style of the climate-pop-ups to a new appearance
  * B2
 */
void clHSA_System_Base::vSetClimatePopupDuration(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetClimatePopupDuration not implemented"));
   
}

/**
 * Method: vSetDateDay
  * sets the day
  * B2
 */
void clHSA_System_Base::vSetDateDay(ulword ulwDay)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDay);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetDateDay not implemented"));
   
}

/**
 * Method: vSetDateMode
  * sets a new date-format
  * B2
 */
void clHSA_System_Base::vSetDateMode(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetDateMode not implemented"));
   
}

/**
 * Method: vSetDateMonth
  * sets the month
  * B2
 */
void clHSA_System_Base::vSetDateMonth(ulword ulwMonth)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMonth);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetDateMonth not implemented"));
   
}

/**
 * Method: vSetDateYear
  * sets the year
  * B2
 */
void clHSA_System_Base::vSetDateYear(ulword ulwYear)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwYear);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetDateYear not implemented"));
   
}

/**
 * Method: vSetDDSEventFocus
  * set focus to the selected window for DDS-Events
  * B1
 */
void clHSA_System_Base::vSetDDSEventFocus(ulword ulwWindow)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwWindow);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetDDSEventFocus not implemented"));
   
}

/**
 * Method: vSetDDSSpeedup
  * Starts the speedup functionality of the RE.
  * B
 */
void clHSA_System_Base::vSetDDSSpeedup(ulword ulwtime, ulword ulwthreshold, ulword ulwmultiplier)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwtime);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwthreshold);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwmultiplier);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetDDSSpeedup not implemented"));
   
}

/**
 * Method: vSetDDSVolumeFocus
  * set focus to the selected window for DDS-Events (for Volume DDS)
  * B1
 */
void clHSA_System_Base::vSetDDSVolumeFocus(ulword ulwWindow)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwWindow);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetDDSVolumeFocus not implemented"));
   
}

/**
 * Method: vSetDDSVolumeSpeedup
  * Starts the speedup functionality of the Volume RE.
  * B
 */
void clHSA_System_Base::vSetDDSVolumeSpeedup(ulword ulwtime, ulword ulwthreshold, ulword ulwmultiplier)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwtime);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwthreshold);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwmultiplier);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetDDSVolumeSpeedup not implemented"));
   
}

/**
 * Method: vSetDisplayBrightness
  * sets the brightness of the display
  * B1
 */
void clHSA_System_Base::vSetDisplayBrightness(tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetDisplayBrightness not implemented"));
   
}

/**
 * Method: vSetDistanceUnit
  * set distance-unit to the new value
  * B2
 */
void clHSA_System_Base::vSetDistanceUnit(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetDistanceUnit not implemented"));
   
}

/**
 * Method: vSetFactorySettings
  * to reset the marked factory-settings
  * B2
 */
void clHSA_System_Base::vSetFactorySettings( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vSetFactorySettings not implemented"));
   
}

/**
 * Method: vSetLastMainContext
  * set the last context which saved before Kl15
  * B1
 */
void clHSA_System_Base::vSetLastMainContext(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetLastMainContext not implemented"));
   
}

/**
 * Method: vSetMenuLanguage
  * Sets the new system-language to the entry of the given index
  * B2
 */
void clHSA_System_Base::vSetMenuLanguage(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetMenuLanguage not implemented"));
   
}

/**
 * Method: vSetRVCMode
  * Sets the either lengthwise or crosswise
  * B
 */
void clHSA_System_Base::vSetRVCMode(ulword ulwRVCMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRVCMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetRVCMode not implemented"));
   
}

/**
 * Method: vSetSkinDayNight
  * Changes the current skin to Day- or Night-Skin or to automatic
  * B2
 */
void clHSA_System_Base::vSetSkinDayNight(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetSkinDayNight not implemented"));
   
}

/**
 * Method: blGetDimstate
  * returns true, if Dim state is on
  * B
 */
tbool clHSA_System_Base::blGetDimstate( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blGetDimstate not implemented"));
   return 0;
}

/**
 * Method: vSetSpellerLayout
  * Sets the speller layout to ABC or QWERTY
  * B
 */
void clHSA_System_Base::vSetSpellerLayout(ulword ulwLayout)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLayout);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetSpellerLayout not implemented"));
   
}

/**
 * Method: vSetTimeFormat
  * Sets the System-Time-Format to 24h or 12h
  * B2
 */
void clHSA_System_Base::vSetTimeFormat(ulword ulwFormat)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwFormat);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetTimeFormat not implemented"));
   
}

/**
 * Method: vSetTimeHour
  * Sets the Hour of a temporary timevalue. The temporary timevalue will be validated by SaveTime.
  * B2
 */
void clHSA_System_Base::vSetTimeHour(ulword ulwHour)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwHour);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetTimeHour not implemented"));
   
}

/**
 * Method: vSetTimeMinute
  * Sets the Minute of a temporary timevalue. The temporary timevalue will be validated by SaveTime.
  * B2
 */
void clHSA_System_Base::vSetTimeMinute(ulword ulwMinute)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMinute);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetTimeMinute not implemented"));
   
}

/**
 * Method: vSetTimeMode
  * Sets the TimeMode: AM / PM of a temporary timevalue. The temporary timevalue will be validated by SaveTime.
  * B2
 */
void clHSA_System_Base::vSetTimeMode(ulword ulwMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetTimeMode not implemented"));
   
}

/**
 * Method: ulwGetTimeMode
  * Gets the TimeMode: AM / PM of a temporary timevalue. The temporary timevalue will be validated by SaveTime.
  * B2
 */
ulword clHSA_System_Base::ulwGetTimeMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetTimeMode not implemented"));
   return 0;
}

/**
 * Method: vSetUserConfirmedSpellerDisclaimer
  * indicates that the user has agreed using the speller while the car is moving
  * B2
 */
void clHSA_System_Base::vSetUserConfirmedSpellerDisclaimer( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vSetUserConfirmedSpellerDisclaimer not implemented"));
   
}

/**
 * Method: blSpellerInvertGetLetterFunction
  * Inverts the logic of the SpellerGetLetterFunction. Has to be set if the MaxInput of Chars (numbers) is reached, to disable further input.
  * B
 */
tbool clHSA_System_Base::blSpellerInvertGetLetterFunction( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blSpellerInvertGetLetterFunction not implemented"));
   return 0;
}

/**
 * Method: vSpellerSetMaxCharCount
  * Used to set the max number of characters which can be entered in the SpellerEntryField. The application has to know this value, in order to prevent entering characters after the maximum of allowed characters was reached. 
  * B
 */
void clHSA_System_Base::vSpellerSetMaxCharCount(ulword ulwCount)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwCount);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSpellerSetMaxCharCount not implemented"));
   
}

/**
 * Method: vStartChkdsk
  * requests the start of chkdsk of a SD Card
  * B
 */
void clHSA_System_Base::vStartChkdsk( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vStartChkdsk not implemented"));
   
}

/**
 * Method: vStartFormatting
  * requests the start of formatting of a SD Card
  * B
 */
void clHSA_System_Base::vStartFormatting( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vStartFormatting not implemented"));
   
}

/**
 * Method: vStartSoftwareDownload
  * starts the download of a firmware if a fw-updade-cd is inserted
  * B1
 */
void clHSA_System_Base::vStartSoftwareDownload( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vStartSoftwareDownload not implemented"));
   
}

/**
 * Method: vInsertMediaForDownload
  * prompts for inserting USB pendrive
  * 
 */
void clHSA_System_Base::vInsertMediaForDownload( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vInsertMediaForDownload not implemented"));
   
}

/**
 * Method: vUnLockDDSEventFocus
  * unlocks the DDS and restores the former state
  * B1
 */
void clHSA_System_Base::vUnLockDDSEventFocus( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vUnLockDDSEventFocus not implemented"));
   
}

/**
 * Method: vUnLockDDSVolumeFocus
  * unlocks the DDS and restores the former state (Volume-DDS)
  * B1
 */
void clHSA_System_Base::vUnLockDDSVolumeFocus( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vUnLockDDSVolumeFocus not implemented"));
   
}

/**
 * Method: vUnmountSD
  * requests the unmounting of the SD Card. A running chkdsk or formatting will be canceled
  * B
 */
void clHSA_System_Base::vUnmountSD( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vUnmountSD not implemented"));
   
}

/**
 * Method: blIsForcedDownloadPossible
  * Returns Forced Download is possible or not
  * NISSAN
 */
tbool clHSA_System_Base::blIsForcedDownloadPossible( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blIsForcedDownloadPossible not implemented"));
   return 0;
}

/**
 * Method: ulwGetEABlockingMode
  * return the current blocking mode for the given external application
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetEABlockingMode(ulword ulwApplication)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwApplication);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetEABlockingMode not implemented"));
   return 0;
}

/**
 * Method: ulwGetNissanRegionType
  * returns the Nissan region type
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetNissanRegionType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetNissanRegionType not implemented"));
   return 0;
}

/**
 * Method: ulwGetUnitOfTemperature
  * returns the unit of temperature
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetUnitOfTemperature( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetUnitOfTemperature not implemented"));
   return 0;
}

/**
 * Method: vSetUnitOfTemperature
  * API to Set the Temperature unit
  * 
 */
void clHSA_System_Base::vSetUnitOfTemperature(ulword ulwTemperatureUnit)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTemperatureUnit);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetUnitOfTemperature not implemented"));
   
}

/**
 * Method: vGetDocumentText
  * returns the Text from Document specified in the path
  * NISSAN
 */
void clHSA_System_Base::vGetDocumentText(GUI_String *out_result, const GUI_String * DocPath)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( DocPath);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetDocumentText not implemented"));
   
}

/**
 * Method: ulwGetDocumentSize
  * returns the size of the Document specified in the path
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetDocumentSize(const GUI_String * DocPath)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( DocPath);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetDocumentSize not implemented"));
   return 0;
}

/**
 * Method: ulwGetHEVDriveType
  * returns the Drive Type bit for HEV
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetHEVDriveType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVDriveType not implemented"));
   return 0;
}

/**
 * Method: ulwGetHEVBodyShape
  * returns the Shape of the car body for HEV
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetHEVBodyShape( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVBodyShape not implemented"));
   return 0;
}

/**
 * Method: ulwGetHEVEnergyFlow_StartIndex
  * Gets the HEVEnergyFlow_StartIndex used for animation
  * 
 */
ulword clHSA_System_Base::ulwGetHEVEnergyFlow_StartIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVEnergyFlow_StartIndex not implemented"));
   return 0;
}

/**
 * Method: ulwGetHEVEnergyFlow_EndIndex
  * Gets the HEVEnergyFlow_EndIndex used for animation
  * 
 */
ulword clHSA_System_Base::ulwGetHEVEnergyFlow_EndIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVEnergyFlow_EndIndex not implemented"));
   return 0;
}

/**
 * Method: blGetHEVEngineOperationState
  * returns the EngineOperationState
  * NISSAN
 */
tbool clHSA_System_Base::blGetHEVEngineOperationState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blGetHEVEngineOperationState not implemented"));
   return 0;
}

/**
 * Method: blGetHEVBatteryOperationState
  * returns the BatteryOperationState
  * NISSAN
 */
tbool clHSA_System_Base::blGetHEVBatteryOperationState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_System::blGetHEVBatteryOperationState not implemented"));
   return 0;
}

/**
 * Method: ulwGetHEVBatteryChargeDischargeState
  * returns the Battery ChargeDischargeState for HEV
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetHEVBatteryChargeDischargeState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVBatteryChargeDischargeState not implemented"));
   return 0;
}

/**
 * Method: ulwGetHEVBatteryChargeLevel
  * returns the Battery Charge Level for HEV
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetHEVBatteryChargeLevel( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVBatteryChargeLevel not implemented"));
   return 0;
}

/**
 * Method: ulwGetHEVTireRotationDirection
  * returns the TireRotationDirection for HEV
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetHEVTireRotationDirection( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVTireRotationDirection not implemented"));
   return 0;
}

/**
 * Method: ulwGetHEVAverageFuelEconomyHistory
  * This function is uesed to get the HEV Driving History Values from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
ulword clHSA_System_Base::ulwGetHEVAverageFuelEconomyHistory(ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVAverageFuelEconomyHistory not implemented"));
   return 0;
}

/**
 * Method: ulwGetHEVRegenerationAmountIconHistory
  * This function is uesed to get the HEV Driving History Values from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
ulword clHSA_System_Base::ulwGetHEVRegenerationAmountIconHistory(ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVRegenerationAmountIconHistory not implemented"));
   return 0;
}

/**
 * Method: ulwGetHEVDrivingHistoryTimeStamp
  * This function is uesed to get the HEV Driving History Values from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
ulword clHSA_System_Base::ulwGetHEVDrivingHistoryTimeStamp(ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVDrivingHistoryTimeStamp not implemented"));
   return 0;
}

/**
 * Method: vGetHEVDDrivingHistoryDateString
  * This function is uesed to get the HEV Driving History dates from the VD VehicleData.
  * NISSAN LCN2 Sample
 */
void clHSA_System_Base::vGetHEVDDrivingHistoryDateString(GUI_String *out_result, ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vGetHEVDDrivingHistoryDateString not implemented"));
   
}

/**
 * Method: ulwGetHEVFuelEconomyUnit
  * returns the unit for Fuel Economy for HEV
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetHEVFuelEconomyUnit( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVFuelEconomyUnit not implemented"));
   return 0;
}

/**
 * Method: vSetHEVShiftDirection
  * Gives Shift direction for Fuel Energy History.
  * NISSAN2.0
 */
void clHSA_System_Base::vSetHEVShiftDirection(ulword ulwShift_direction)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwShift_direction);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vSetHEVShiftDirection not implemented"));
   
}

/**
 * Method: ulwGetHEVScrollKeyGrayingState
  * returns the state of scroll keys for HEV
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetHEVScrollKeyGrayingState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVScrollKeyGrayingState not implemented"));
   return 0;
}

/**
 * Method: ulwGetHEVHistoryMaxValue
  * returns the max for Fuel Economy for HEV
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetHEVHistoryMaxValue( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVHistoryMaxValue not implemented"));
   return 0;
}

/**
 * Method: vLoadHEVHistory
  * requests HEV history data
  * B
 */
void clHSA_System_Base::vLoadHEVHistory( )
{
   
   ETG_TRACE_USR4(("function void clHSA_System::vLoadHEVHistory not implemented"));
   
}

/**
 * Method: ulwGetHEVHistoryLoadingState
  * returns the state of HEVHistory
  * NISSAN
 */
ulword clHSA_System_Base::ulwGetHEVHistoryLoadingState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_System::ulwGetHEVHistoryLoadingState not implemented"));
   return 0;
}

/**
 * Method: vIsTimeFormatScreenActive
  * Is the user on the time format screen
  * B2
 */
void clHSA_System_Base::vIsTimeFormatScreenActive(tbool blScreenstate)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blScreenstate);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System::vIsTimeFormatScreenActive not implemented"));
   
}

