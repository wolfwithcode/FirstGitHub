/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_System_Config_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_System/HSA_Config/clHSA_System_Config_Base.h"

clHSA_System_Config_Base* clHSA_System_Config_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_System_Config_Base.cpp.trc.h"
#endif


/**
 * Method: ulwGetConfigData
  * Returns the requested configuration parameter
  * NISSAN LCN2
 */
ulword clHSA_System_Config_Base::ulwGetConfigData(ulword ulwParam1, ulword ulwParam2, ulword ulwParam3, ulword ulwParam4)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwParam1);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwParam2);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwParam3);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwParam4);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_System_Config::ulwGetConfigData not implemented"));
   return 0;
}

/**
 * Method: vGetPartNumber
  * Returns the Vehicle Part number read from the registry
  * NISSAN LCN2
 */
void clHSA_System_Config_Base::vGetPartNumber(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_System_Config::vGetPartNumber not implemented"));
   
}

