/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_System_Config_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_System_Config_Base_H
#define _clHSA_System_Config_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_System_Config_Base : public clHSA_Base
{
public:

    static clHSA_System_Config_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_System_Config_Base()        {}

    virtual ulword ulwGetConfigData(ulword ulwParam1, ulword ulwParam2, ulword ulwParam3, ulword ulwParam4);

    virtual void vGetPartNumber(GUI_String *out_result);

protected:
    clHSA_System_Config_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_System_Config_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_System_Config_Base_H

