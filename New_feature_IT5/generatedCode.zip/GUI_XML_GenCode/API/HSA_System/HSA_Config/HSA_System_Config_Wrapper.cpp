/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_System_Config_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_System_Config_Wrapper.h"
#include "clHSA_System_Config_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_System_Config_Trace.h"
#include "hmi_trace.h"

ulword HSA_System_Config__ulwGetConfigData(ulword ulwParam1, ulword ulwParam2, ulword ulwParam3, ulword ulwParam4)
{
    ulword ret = 0;
    clHSA_System_Config_Base *pInst=clHSA_System_Config_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_CONFIG), (tU16)(HSA_API_ENTRYPOINT__GET_CONFIG_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwParam1); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_CONFIG), (tU16)(HSA_API_ENTRYPOINT__GET_CONFIG_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwParam2); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_CONFIG), (tU16)(HSA_API_ENTRYPOINT__GET_CONFIG_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwParam3); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_CONFIG), (tU16)(HSA_API_ENTRYPOINT__GET_CONFIG_DATA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwParam4); 
        }
      ret=pInst->ulwGetConfigData(ulwParam1, ulwParam2, ulwParam3, ulwParam4);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_CONFIG), (tU16)(HSA_API_ENTRYPOINT__GET_CONFIG_DATA | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_System_Config__vGetPartNumber(GUI_String *out_result)
{
    
    clHSA_System_Config_Base *pInst=clHSA_System_Config_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_CONFIG), (tU16)(HSA_API_ENTRYPOINT__GET_PART_NUMBER  ) ); 
        }
      pInst->vGetPartNumber(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SYSTEM_CONFIG), (tU16)(HSA_API_ENTRYPOINT__GET_PART_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

#ifdef __cplusplus
}
#endif

