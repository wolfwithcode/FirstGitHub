/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_System_Config_Trace.h
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
#ifndef _HSA_System_Config_TRACE_H
#define _HSA_System_Config_TRACE_H
 

/**** Trace defines for HSA_System_Config ****/

#define HSA_API_ENTRYPOINT__GET_CONFIG_DATA 0x1

#define HSA_API_ENTRYPOINT__GET_PART_NUMBER 0x2

#endif  //#ifndef _HSA_System_Config_TRACE_H

