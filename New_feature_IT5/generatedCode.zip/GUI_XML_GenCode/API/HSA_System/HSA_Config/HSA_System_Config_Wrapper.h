/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_System_Config_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_System_Config_Wrapper_H
#define _HSA_System_Config_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: GetConfigData
 * NISSAN LCN2
 * NISSAN
 */
ulword HSA_System_Config__ulwGetConfigData(ulword ulwParam1, ulword ulwParam2, ulword ulwParam3, ulword ulwParam4);

/**
 * Function: GetPartNumber
 * NISSAN LCN2
 * NISSAN
 */
void HSA_System_Config__vGetPartNumber(GUI_String *out_result);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_System_Config_H

