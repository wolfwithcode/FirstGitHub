/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SpeechDialog_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_SpeechDialog_Wrapper_H
#define _HSA_SpeechDialog_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: GetHeadline
 * LCN2
 * NISSAN
 */
void HSA_SpeechDialog__vGetHeadline(GUI_String *out_result);

/**
 * Function: GetText
 * B1
 * NISSAN
 */
void HSA_SpeechDialog__vGetText(GUI_String *out_result, ulword ulwLineNumber, ulword ulwColumnNumber);

/**
 * Function: GetDescription
 * B1
 * NISSAN
 */
void HSA_SpeechDialog__vGetDescription(GUI_String *out_result, ulword ulwLineNumber);

/**
 * Function: GetHelpLine
 * B1
 * NISSAN
 */
void HSA_SpeechDialog__vGetHelpLine(GUI_String *out_result);

/**
 * Function: GetStatusLine
 * LCN2
 * NISSAN
 */
void HSA_SpeechDialog__vGetStatusLine(GUI_String *out_result);

/**
 * Function: IsSpeechInputActive
 * LCN2
 * NISSAN
 */
tbool HSA_SpeechDialog__blIsSpeechInputActive( void);

/**
 * Function: CancelSession
 * LCN2
 * NISSAN
 */
void HSA_SpeechDialog__vCancelSession( void);

/**
 * Function: RequestUserWordSession
 * LCN2
 * NISSAN
 */
void HSA_SpeechDialog__vRequestUserWordSession( void);

/**
 * Function: IsSDSHelpDataAvailable
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SpeechDialog__blIsSDSHelpDataAvailable( void);

/**
 * Function: GetNumberOfSDSHelpDataList
 * Nissan LCN2
 * NISSAN
 */
ulword HSA_SpeechDialog__ulwGetNumberOfSDSHelpDataList( void);

/**
 * Function: GetSDSHelpDataListEntries
 * NISSAN LCN2
 * NISSAN
 */
void HSA_SpeechDialog__vGetSDSHelpDataListEntries(GUI_String *out_result, ulword ulwListEntryNumber);

/**
 * Function: SelectSDSHelpDataListEntry
 * B
 * NISSAN
 */
void HSA_SpeechDialog__vSelectSDSHelpDataListEntry(ulword ulwListEntryNumber);

/**
 * Function: EnterSDSHelpDataListMainScreen
 * NISSAN
 * NISSAN
 */
void HSA_SpeechDialog__vEnterSDSHelpDataListMainScreen( void);

/**
 * Function: PttShortPressed
 * NISSAN LCN2
 * NISSAN
 */
void HSA_SpeechDialog__vPttShortPressed( void);

/**
 * Function: PttLongPressed
 * NISSAN LCN2
 * NISSAN
 */
void HSA_SpeechDialog__vPttLongPressed( void);

/**
 * Function: SWC_Next_ShortPress
 * NISSAN LCN2
 * NISSAN
 */
void HSA_SpeechDialog__vSWC_Next_ShortPress( void);

/**
 * Function: SWC_Prev_ShortPress
 * NISSAN LCN2
 * NISSAN
 */
void HSA_SpeechDialog__vSWC_Prev_ShortPress( void);

/**
 * Function: GetColor
 * B1
 * NISSAN
 */
ulword HSA_SpeechDialog__ulwGetColor(ulword ulwLineNumber, ulword ulwColumnNumber);

/**
 * Function: GetDirectionSymbol
 * B1
 * NISSAN
 */
ulword HSA_SpeechDialog__ulwGetDirectionSymbol(ulword ulwLineNumber);

/**
 * Function: SwcPhoneEndPressed
 * NISSAN LCN2
 * NISSAN
 */
void HSA_SpeechDialog__vSwcPhoneEndPressed( void);

/**
 * Function: SetCurrentGUIApplication
 * NISSAN LCN2
 * NISSAN
 */
void HSA_SpeechDialog__vSetCurrentGUIApplication(ulword ulwGUIApplication);

/**
 * Function: GetSettingsMenuToDisplay
 * NISSAN LCN2
 * NISSAN
 */
ulword HSA_SpeechDialog__ulwGetSettingsMenuToDisplay( void);

/**
 * Function: StartSmsReplySession
 * NISSAN2.0
 * NISSAN
 */
void HSA_SpeechDialog__vStartSmsReplySession( void);

/**
 * Function: BackButtonPressed
 * NISSAN2.0
 * NISSAN
 */
void HSA_SpeechDialog__vBackButtonPressed( void);

/**
 * Function: HangUpButtonPressed
 * NISSAN2.0
 * NISSAN
 */
void HSA_SpeechDialog__vHangUpButtonPressed( void);

/**
 * Function: ReadSMSFromTTS
 * NISSAN2.0
 * NISSAN
 */
void HSA_SpeechDialog__vReadSMSFromTTS(const GUI_String * InputString);

/**
 * Function: AbortTTSPrompt
 * NISSAN2.0
 * NISSAN
 */
void HSA_SpeechDialog__vAbortTTSPrompt( void);

/**
 * Function: IsIdle
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SpeechDialog__blIsIdle( void);

/**
 * Function: StartSessionFromHelp
 * NISSAN2.0
 * NISSAN
 */
void HSA_SpeechDialog__vStartSessionFromHelp( void);

/**
 * Function: StartPhonetization
 * NISSAN2.0
 * NISSAN
 */
void HSA_SpeechDialog__vStartPhonetization( void);

/**
 * Function: PttPressFromCameraMode
 * NISSAN2.0
 * NISSAN
 */
void HSA_SpeechDialog__vPttPressFromCameraMode( void);

/**
 * Function: AbortSession
 * NISSAN2.0
 * NISSAN
 */
void HSA_SpeechDialog__vAbortSession( void);

/**
 * Function: IsPhonetizationActive
 * NISSAN2.0
 * NISSAN
 */
tbool HSA_SpeechDialog__blIsPhonetizationActive( void);

/**
 * Function: GetGracenoteVersion
 * NISSAN2.0
 * NISSAN
 */
void HSA_SpeechDialog__vGetGracenoteVersion(GUI_String *out_result);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_SpeechDialog_H

