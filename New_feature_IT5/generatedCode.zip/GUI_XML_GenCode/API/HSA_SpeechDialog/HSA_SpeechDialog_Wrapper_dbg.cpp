/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SpeechDialog_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_SpeechDialog_Wrapper_dbg.h"
#include "clHSA_SpeechDialog_Base.h"
#include "HSA_SpeechDialog_Trace.h"
#include "HSA_SpeechDialog_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_SpeechDialog_Wrapper_dbg::~clHSA_SpeechDialog_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_SpeechDialog_Wrapper_dbg::clHSA_SpeechDialog_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_SpeechDialog_Wrapper_dbg::clHSA_SpeechDialog_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_SpeechDialog_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_SpeechDialog_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__GET_HEADLINE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SpeechDialog__vGetHeadline(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_TEXT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_SpeechDialog__vGetText(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_DESCRIPTION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SpeechDialog__vGetDescription(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_HELP_LINE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SpeechDialog__vGetHelpLine(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_STATUS_LINE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SpeechDialog__vGetStatusLine(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_SPEECH_INPUT_ACTIVE:

            HSA_SpeechDialog__blIsSpeechInputActive();
            break;

        case HSA_API_ENTRYPOINT__CANCEL_SESSION:

            HSA_SpeechDialog__vCancelSession();
            break;

        case HSA_API_ENTRYPOINT__REQUEST_USER_WORD_SESSION:

            HSA_SpeechDialog__vRequestUserWordSession();
            break;

        case HSA_API_ENTRYPOINT__IS_SDS_HELP_DATA_AVAILABLE:

            HSA_SpeechDialog__blIsSDSHelpDataAvailable();
            break;

        case HSA_API_ENTRYPOINT__GET_NUMBER_OF_SDS_HELP_DATA_LIST:

            HSA_SpeechDialog__ulwGetNumberOfSDSHelpDataList();
            break;

        case HSA_API_ENTRYPOINT__GET_SDS_HELP_DATA_LIST_ENTRIES:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SpeechDialog__vGetSDSHelpDataListEntries(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SELECT_SDS_HELP_DATA_LIST_ENTRY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SpeechDialog__vSelectSDSHelpDataListEntry(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ENTER_SDS_HELP_DATA_LIST_MAIN_SCREEN:

            HSA_SpeechDialog__vEnterSDSHelpDataListMainScreen();
            break;

        case HSA_API_ENTRYPOINT__PTT_SHORT_PRESSED:

            HSA_SpeechDialog__vPttShortPressed();
            break;

        case HSA_API_ENTRYPOINT__PTT_LONG_PRESSED:

            HSA_SpeechDialog__vPttLongPressed();
            break;

        case HSA_API_ENTRYPOINT__SWC__NEXT__SHORT_PRESS:

            HSA_SpeechDialog__vSWC_Next_ShortPress();
            break;

        case HSA_API_ENTRYPOINT__SWC__PREV__SHORT_PRESS:

            HSA_SpeechDialog__vSWC_Prev_ShortPress();
            break;

        case HSA_API_ENTRYPOINT__GET_COLOR:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_SpeechDialog__ulwGetColor(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DIRECTION_SYMBOL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SpeechDialog__ulwGetDirectionSymbol(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SWC_PHONE_END_PRESSED:

            HSA_SpeechDialog__vSwcPhoneEndPressed();
            break;

        case HSA_API_ENTRYPOINT__SET_CURRENT_GUI_APPLICATION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_SpeechDialog__vSetCurrentGUIApplication(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SETTINGS_MENU_TO_DISPLAY:

            HSA_SpeechDialog__ulwGetSettingsMenuToDisplay();
            break;

        case HSA_API_ENTRYPOINT__START_SMS_REPLY_SESSION:

            HSA_SpeechDialog__vStartSmsReplySession();
            break;

        case HSA_API_ENTRYPOINT__BACK_BUTTON_PRESSED:

            HSA_SpeechDialog__vBackButtonPressed();
            break;

        case HSA_API_ENTRYPOINT__HANG_UP_BUTTON_PRESSED:

            HSA_SpeechDialog__vHangUpButtonPressed();
            break;

        case HSA_API_ENTRYPOINT__READ_SMS_FROM_TTS:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_SpeechDialog__vReadSMSFromTTS(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__ABORT_TTS_PROMPT:

            HSA_SpeechDialog__vAbortTTSPrompt();
            break;

        case HSA_API_ENTRYPOINT__IS_IDLE:

            HSA_SpeechDialog__blIsIdle();
            break;

        case HSA_API_ENTRYPOINT__START_SESSION_FROM_HELP:

            HSA_SpeechDialog__vStartSessionFromHelp();
            break;

        case HSA_API_ENTRYPOINT__START_PHONETIZATION:

            HSA_SpeechDialog__vStartPhonetization();
            break;

        case HSA_API_ENTRYPOINT__PTT_PRESS_FROM_CAMERA_MODE:

            HSA_SpeechDialog__vPttPressFromCameraMode();
            break;

        case HSA_API_ENTRYPOINT__ABORT_SESSION:

            HSA_SpeechDialog__vAbortSession();
            break;

        case HSA_API_ENTRYPOINT__IS_PHONETIZATION_ACTIVE:

            HSA_SpeechDialog__blIsPhonetizationActive();
            break;

        case HSA_API_ENTRYPOINT__GET_GRACENOTE_VERSION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_SpeechDialog__vGetGracenoteVersion(&gsParam1);
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

