/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_SpeechDialog_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_SpeechDialog/clHSA_SpeechDialog_Base.h"

clHSA_SpeechDialog_Base* clHSA_SpeechDialog_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_SpeechDialog_Base.cpp.trc.h"
#endif


/**
 * Method: vGetHeadline
  * Returns the headline of a speech dialog popup.
  * LCN2
 */
void clHSA_SpeechDialog_Base::vGetHeadline(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vGetHeadline not implemented"));
   
}

/**
 * Method: vGetText
  * Returns the descriptive string for a number tag in list popups. Descriptive strings are written into the second column.
  * B1
 */
void clHSA_SpeechDialog_Base::vGetText(GUI_String *out_result, ulword ulwLineNumber, ulword ulwColumnNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLineNumber);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwColumnNumber);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vGetText not implemented"));
   
}

/**
 * Method: vGetDescription
  * Returns the descriptive string for a number tag in list popups. Descriptive strings are written into the second column.
  * B1
 */
void clHSA_SpeechDialog_Base::vGetDescription(GUI_String *out_result, ulword ulwLineNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLineNumber);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vGetDescription not implemented"));
   
}

/**
 * Method: vGetHelpLine
  * Returns the help line (6th text line) of a speech dialog popup.
  * B1
 */
void clHSA_SpeechDialog_Base::vGetHelpLine(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vGetHelpLine not implemented"));
   
}

/**
 * Method: vGetStatusLine
  * Returns the status line of a speech dialog popup.
  * LCN2
 */
void clHSA_SpeechDialog_Base::vGetStatusLine(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vGetStatusLine not implemented"));
   
}

/**
 * Method: blIsSpeechInputActive
  * Returns 1 if the speech dialog system is waiting for user speech input. Determines the state of the 'talking head' icon.
  * LCN2
 */
tbool clHSA_SpeechDialog_Base::blIsSpeechInputActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SpeechDialog::blIsSpeechInputActive not implemented"));
   return 0;
}

/**
 * Method: vCancelSession
  * Cancels an ongoing SDS session eg.PTT press to abort.
  * LCN2
 */
void clHSA_SpeechDialog_Base::vCancelSession( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vCancelSession not implemented"));
   
}

/**
 * Method: vRequestUserWordSession
  * Requests a special SDS session for adding a user word.
  * LCN2
 */
void clHSA_SpeechDialog_Base::vRequestUserWordSession( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vRequestUserWordSession not implemented"));
   
}

/**
 * Method: blIsSDSHelpDataAvailable
  * Method to Get the Info if the availablity of SDS help commands
  * NISSAN2.0
 */
tbool clHSA_SpeechDialog_Base::blIsSDSHelpDataAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SpeechDialog::blIsSDSHelpDataAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwGetNumberOfSDSHelpDataList
  * Returns the number of Help commands
  * Nissan LCN2
 */
ulword clHSA_SpeechDialog_Base::ulwGetNumberOfSDSHelpDataList( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SpeechDialog::ulwGetNumberOfSDSHelpDataList not implemented"));
   return 0;
}

/**
 * Method: vGetSDSHelpDataListEntries
  * Get the entries for showing the list of Help command
  * NISSAN LCN2
 */
void clHSA_SpeechDialog_Base::vGetSDSHelpDataListEntries(GUI_String *out_result, ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vGetSDSHelpDataListEntries not implemented"));
   
}

/**
 * Method: vSelectSDSHelpDataListEntry
  * Selects the SDS Help List for the corresponding item.
  * B
 */
void clHSA_SpeechDialog_Base::vSelectSDSHelpDataListEntry(ulword ulwListEntryNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNumber);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vSelectSDSHelpDataListEntry not implemented"));
   
}

/**
 * Method: vEnterSDSHelpDataListMainScreen
  * SDS HELP Command tree listing - VOICE RECOGNITION HELP button selection from Menu and HK return for Sub commads
  * NISSAN
 */
void clHSA_SpeechDialog_Base::vEnterSDSHelpDataListMainScreen( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vEnterSDSHelpDataListMainScreen not implemented"));
   
}

/**
 * Method: vPttShortPressed
  * Ptt Short Press from Model used to start the SDS session if not started and also stop the prompt and sometimes cancel sds session
  * NISSAN LCN2
 */
void clHSA_SpeechDialog_Base::vPttShortPressed( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vPttShortPressed not implemented"));
   
}

/**
 * Method: vPttLongPressed
  * Ptt Short Press from Model used to cance the SDS session SDS session is started 
  * NISSAN LCN2
 */
void clHSA_SpeechDialog_Base::vPttLongPressed( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vPttLongPressed not implemented"));
   
}

/**
 * Method: vSWC_Next_ShortPress
  * SWC Next button is pressed while SDS session is active, used in Manual mode operation of SDS
  * NISSAN LCN2
 */
void clHSA_SpeechDialog_Base::vSWC_Next_ShortPress( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vSWC_Next_ShortPress not implemented"));
   
}

/**
 * Method: vSWC_Prev_ShortPress
  * SWC Prev button is pressed while SDS session is active, used in Manual mode operation of SDS
  * NISSAN LCN2
 */
void clHSA_SpeechDialog_Base::vSWC_Prev_ShortPress( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vSWC_Prev_ShortPress not implemented"));
   
}

/**
 * Method: ulwGetColor
  * Returns the color for the DP text at the provided row and column.
  * B1
 */
ulword clHSA_SpeechDialog_Base::ulwGetColor(ulword ulwLineNumber, ulword ulwColumnNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLineNumber);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwColumnNumber);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_SpeechDialog::ulwGetColor not implemented"));
   return 0;
}

/**
 * Method: ulwGetDirectionSymbol
  * Returns the index corresponding to the requested direction symbol.
  * B1
 */
ulword clHSA_SpeechDialog_Base::ulwGetDirectionSymbol(ulword ulwLineNumber)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwLineNumber);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_SpeechDialog::ulwGetDirectionSymbol not implemented"));
   return 0;
}

/**
 * Method: vSwcPhoneEndPressed
  *  Model need to call this API for SWC Phone end press in SDS context
  * NISSAN LCN2
 */
void clHSA_SpeechDialog_Base::vSwcPhoneEndPressed( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vSwcPhoneEndPressed not implemented"));
   
}

/**
 * Method: vSetCurrentGUIApplication
  * Informs SDS-API about the current visible application in GUI 
  * NISSAN LCN2
 */
void clHSA_SpeechDialog_Base::vSetCurrentGUIApplication(ulword ulwGUIApplication)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwGUIApplication);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vSetCurrentGUIApplication not implemented"));
   
}

/**
 * Method: ulwGetSettingsMenuToDisplay
  * Method to Get the value of the settings screen to display 
  * NISSAN LCN2
 */
ulword clHSA_SpeechDialog_Base::ulwGetSettingsMenuToDisplay( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_SpeechDialog::ulwGetSettingsMenuToDisplay not implemented"));
   return 0;
}

/**
 * Method: vStartSmsReplySession
  * Method to start SMS reply session
  * NISSAN2.0
 */
void clHSA_SpeechDialog_Base::vStartSmsReplySession( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vStartSmsReplySession not implemented"));
   
}

/**
 * Method: vBackButtonPressed
  * Method to call when Back button is pressed
  * NISSAN2.0
 */
void clHSA_SpeechDialog_Base::vBackButtonPressed( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vBackButtonPressed not implemented"));
   
}

/**
 * Method: vHangUpButtonPressed
  * Method to call when HangUp button is pressed
  * NISSAN2.0
 */
void clHSA_SpeechDialog_Base::vHangUpButtonPressed( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vHangUpButtonPressed not implemented"));
   
}

/**
 * Method: vReadSMSFromTTS
  * method to trigger TTS engine for reading sms
  * NISSAN2.0
 */
void clHSA_SpeechDialog_Base::vReadSMSFromTTS(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vReadSMSFromTTS not implemented"));
   
}

/**
 * Method: vAbortTTSPrompt
  * method to Stop TTS engine to stop reading sms
  * NISSAN2.0
 */
void clHSA_SpeechDialog_Base::vAbortTTSPrompt( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vAbortTTSPrompt not implemented"));
   
}

/**
 * Method: blIsIdle
  * method to Indicate Model that SDS Applications are ready to operated
  * NISSAN2.0
 */
tbool clHSA_SpeechDialog_Base::blIsIdle( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SpeechDialog::blIsIdle not implemented"));
   return 0;
}

/**
 * Method: vStartSessionFromHelp
  * method to start the SDS session in a specific context as displayed by the help menu
  * NISSAN2.0
 */
void clHSA_SpeechDialog_Base::vStartSessionFromHelp( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vStartSessionFromHelp not implemented"));
   
}

/**
 * Method: vStartPhonetization
  * method to Start Phonetization
  * NISSAN2.0
 */
void clHSA_SpeechDialog_Base::vStartPhonetization( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vStartPhonetization not implemented"));
   
}

/**
 * Method: vPttPressFromCameraMode
  * Method to indicate PTT has been pressed in Camera mode
  * NISSAN2.0
 */
void clHSA_SpeechDialog_Base::vPttPressFromCameraMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vPttPressFromCameraMode not implemented"));
   
}

/**
 * Method: vAbortSession
  * Method to abort SDS session when RVC is connected
  * NISSAN2.0
 */
void clHSA_SpeechDialog_Base::vAbortSession( )
{
   
   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vAbortSession not implemented"));
   
}

/**
 * Method: blIsPhonetizationActive
  * Returns true in case of ongoing phonetization
  * NISSAN2.0
 */
tbool clHSA_SpeechDialog_Base::blIsPhonetizationActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_SpeechDialog::blIsPhonetizationActive not implemented"));
   return 0;
}

/**
 * Method: vGetGracenoteVersion
  * Returns the Gracenote version number 
  * NISSAN2.0
 */
void clHSA_SpeechDialog_Base::vGetGracenoteVersion(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_SpeechDialog::vGetGracenoteVersion not implemented"));
   
}

