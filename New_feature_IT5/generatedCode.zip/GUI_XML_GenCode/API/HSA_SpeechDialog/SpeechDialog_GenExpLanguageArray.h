/*Exported Language Array from the model - SpeechDialog*/
/*  This file has been generated on 05.12.2014 16:38 */
/*
 *  This file contains the definition of exported language content.
 *  The String lists with the translation that are to be exported
 *  from the model are listed here in the array structure
 *  
 *  Please note that:
 *    - Translations are provided in the following language order
 *    - English US
 *    - French CAN
 *    - Spanish Standard Latin
 *    - Dutch
 *    - German
 *    - Italian
 *    - Portuguese
 *    - Russian
 *    - Turkish
 *    - English UK
 *    - French
 *    - Spanish
 *    - Danish
 *    - Swedish
 *    - Finnish
 *    - Norwegian
 *    - Polish
 *    - Slovak
 *    - Czech
 *    - Hungarian
 *    - Greek
 *    - Brazilian
 *    - Arabic
 *    - Thai
 *    - Australian
 *
 *    This list is the same as used in the Model
 *
 *  The following macros are used:
 *
 *    CONTENT_LANGUAGE_COUNT(LanguageCount)
 *       Provides the count value to indicate the number of translations
 *    CONTENT_LANGUAGE_ARRAY(DeviceName) 
 *       Provides the start of the Array with Device name to which the 
 *       array belongs
 *    CONTENT_INDEX_START(Index Value)
 *       mark the start of Each string followed by the array of
 *       translations
 *    CONTENT_LANGUAGE(ContentID)
 *       provides the content ID for the translated string
 *    CONTENT_INDEX_END
 *       marks the end of Each string translation set
 *    CONTENT_END(value)
 *       End of the complete array
 *
 */


CONTENT_BEGIN()
#ifndef CONTENT_EXP_LANGUAGE_COUNT
   #define CONTENT_EXP_LANGUAGE_COUNT       25
#endif // #ifndef CONTENT_EXP_LANGUAGE_COUNT
CONTENT_LANGUAGE_ARRAY(SpeechDialog)

#ifdef CONTENT_LANGUAGE
    //STRING_START(0)
    CONTENT_LANGUAGE(0x40004cde)                                      // 0x80000049: Yesterday
    CONTENT_LANGUAGE(0x40004cdf)                                      // 0x80000049: Hier
    CONTENT_LANGUAGE(0x40004ce0)                                      // 0x80000049: Ayer
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000049: #No translation required
    //STRING_END()
    //STRING_START(1)
    CONTENT_LANGUAGE(0x40004ce1)                                      // 0x8000004a: Sunday
    CONTENT_LANGUAGE(0x40004ce2)                                      // 0x8000004a: Dimanche
    CONTENT_LANGUAGE(0x40004ce3)                                      // 0x8000004a: Domingo
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004a: #No translation required
    //STRING_END()
    //STRING_START(2)
    CONTENT_LANGUAGE(0x40004ce4)                                      // 0x8000004b: Monday
    CONTENT_LANGUAGE(0x40004ce5)                                      // 0x8000004b: Lundi
    CONTENT_LANGUAGE(0x40004ce6)                                      // 0x8000004b: Lunes
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004b: #No translation required
    //STRING_END()
    //STRING_START(3)
    CONTENT_LANGUAGE(0x40004ce7)                                      // 0x8000004c: Tuesday
    CONTENT_LANGUAGE(0x40004ce8)                                      // 0x8000004c: Mardi
    CONTENT_LANGUAGE(0x40004ce9)                                      // 0x8000004c: Martes
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004c: #No translation required
    //STRING_END()
    //STRING_START(4)
    CONTENT_LANGUAGE(0x40004cea)                                      // 0x8000004d: Wednesday
    CONTENT_LANGUAGE(0x40004ceb)                                      // 0x8000004d: Mercredi
    CONTENT_LANGUAGE(0x40004cec)                                      // 0x8000004d: Mi�rcoles
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004d: #No translation required
    //STRING_END()
    //STRING_START(5)
    CONTENT_LANGUAGE(0x40004ced)                                      // 0x8000004e: Thursday
    CONTENT_LANGUAGE(0x40004cee)                                      // 0x8000004e: Jeudi
    CONTENT_LANGUAGE(0x40004cef)                                      // 0x8000004e: Jueves
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004e: #No translation required
    //STRING_END()
    //STRING_START(6)
    CONTENT_LANGUAGE(0x40004cf0)                                      // 0x8000004f: Friday
    CONTENT_LANGUAGE(0x40004cf1)                                      // 0x8000004f: Vendredi
    CONTENT_LANGUAGE(0x40004cf2)                                      // 0x8000004f: Viernes
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x8000004f: #No translation required
    //STRING_END()
    //STRING_START(7)
    CONTENT_LANGUAGE(0x40004cf3)                                      // 0x80000050: Saturday
    CONTENT_LANGUAGE(0x40004cf4)                                      // 0x80000050: Samedi
    CONTENT_LANGUAGE(0x40004cf5)                                      // 0x80000050: S�bado
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000050: #No translation required
    //STRING_END()
    //STRING_START(8)
    CONTENT_LANGUAGE(0x40004cf6)                                      // 0x80000051: Msg 
    CONTENT_LANGUAGE(0x40004cf6)                                      // 0x80000051: Msg 
    CONTENT_LANGUAGE(0x40004cf7)                                      // 0x80000051: Mje 
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000051: #No translation required
    //STRING_END()
    //STRING_START(9)
    CONTENT_LANGUAGE(0x40004cf8)                                      // 0x80000052:  of 
    CONTENT_LANGUAGE(0x40004cf9)                                      // 0x80000052:  de 
    CONTENT_LANGUAGE(0x40004cf9)                                      // 0x80000052:  de 
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000052: #No translation required
    //STRING_END()
    //STRING_START(10)
    CONTENT_LANGUAGE(0x40004d1d)                                      // 0x80000054: Today
    CONTENT_LANGUAGE(0x40004d1e)                                      // 0x80000054: Aujourd'hui
    CONTENT_LANGUAGE(0x40004d1f)                                      // 0x80000054: Hoy
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000054: #No translation required
    //STRING_END()
    //STRING_START(11)
    CONTENT_LANGUAGE(0x40004d0e)                                      // 0x80000055: 1 day 
    CONTENT_LANGUAGE(0x40004d20)                                      // 0x80000055: 1 jour
    CONTENT_LANGUAGE(0x40004d21)                                      // 0x80000055: 1 d�a
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000055: #No translation required
    //STRING_END()
    //STRING_START(12)
    CONTENT_LANGUAGE(0x40004d22)                                      // 0x80000056: 2 days
    CONTENT_LANGUAGE(0x40004d23)                                      // 0x80000056: 2 jours
    CONTENT_LANGUAGE(0x40004d24)                                      // 0x80000056: 2 d�as
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000056: #No translation required
    //STRING_END()
    //STRING_START(13)
    CONTENT_LANGUAGE(0x40004d10)                                      // 0x80000057: 3+days
    CONTENT_LANGUAGE(0x40004d25)                                      // 0x80000057: 3+jours
    CONTENT_LANGUAGE(0x40004d26)                                      // 0x80000057: 3+d�as
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000057: #No translation required
    //STRING_END()
    //STRING_START(14)
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x80000058: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x80000058: km
    CONTENT_LANGUAGE(0x4000083a)                                      // 0x80000058: km
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000058: #No translation required
    //STRING_END()
    //STRING_START(15)
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x80000059: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x80000059: mi
    CONTENT_LANGUAGE(0x4000083c)                                      // 0x80000059: mi
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    CONTENT_LANGUAGE(0x40004c66)                                      // 0x80000059: #No translation required
    //STRING_END()
    //STRING_START(16)
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    CONTENT_LANGUAGE(0x40004d11)                                      // 0x8000005a: Favorite Teams
    //STRING_END()
    //STRING_START(17)
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    CONTENT_LANGUAGE(0x400005e9)                                      // 0x8000005b: Favorites
    //STRING_END()
    //STRING_START(18)
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    CONTENT_LANGUAGE(0x40004d12)                                      // 0x8000005c: Football
    //STRING_END()
    //STRING_START(19)
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    CONTENT_LANGUAGE(0x40004d13)                                      // 0x8000005d: American Football
    //STRING_END()
    //STRING_START(20)
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    CONTENT_LANGUAGE(0x40004d14)                                      // 0x8000005e: Basketball
    //STRING_END()
    //STRING_START(21)
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    CONTENT_LANGUAGE(0x40004d15)                                      // 0x8000005f: Baseball
    //STRING_END()
    //STRING_START(22)
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    CONTENT_LANGUAGE(0x40004d16)                                      // 0x80000060: Soccer
    //STRING_END()
    //STRING_START(23)
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    CONTENT_LANGUAGE(0x40004d17)                                      // 0x80000061: Ice Hockey
    //STRING_END()
    //STRING_START(24)
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    CONTENT_LANGUAGE(0x40004d18)                                      // 0x80000062: Hockey
    //STRING_END()
    //STRING_START(25)
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    CONTENT_LANGUAGE(0x40004d19)                                      // 0x80000063: Motor Sports
    //STRING_END()
    //STRING_START(26)
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    CONTENT_LANGUAGE(0x40004d1a)                                      // 0x80000064: Auto Racing
    //STRING_END()
    //STRING_START(27)
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    CONTENT_LANGUAGE(0x40004d1b)                                      // 0x80000065: Golf
    //STRING_END()
#endif // #ifdef CONTENT_LANGUAGE

CONTENT_END()
