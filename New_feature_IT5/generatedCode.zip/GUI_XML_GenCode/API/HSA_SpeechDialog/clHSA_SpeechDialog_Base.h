/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_SpeechDialog_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_SpeechDialog_Base_H
#define _clHSA_SpeechDialog_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_SpeechDialog_Base : public clHSA_Base
{
public:

    static clHSA_SpeechDialog_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_SpeechDialog_Base()        {}

    virtual void vGetHeadline(GUI_String *out_result);

    virtual void vGetText(GUI_String *out_result, ulword ulwLineNumber, ulword ulwColumnNumber);

    virtual void vGetDescription(GUI_String *out_result, ulword ulwLineNumber);

    virtual void vGetHelpLine(GUI_String *out_result);

    virtual void vGetStatusLine(GUI_String *out_result);

    virtual tbool blIsSpeechInputActive( );

    virtual void vCancelSession( );

    virtual void vRequestUserWordSession( );

    virtual tbool blIsSDSHelpDataAvailable( );

    virtual ulword ulwGetNumberOfSDSHelpDataList( );

    virtual void vGetSDSHelpDataListEntries(GUI_String *out_result, ulword ulwListEntryNumber);

    virtual void vSelectSDSHelpDataListEntry(ulword ulwListEntryNumber);

    virtual void vEnterSDSHelpDataListMainScreen( );

    virtual void vPttShortPressed( );

    virtual void vPttLongPressed( );

    virtual void vSWC_Next_ShortPress( );

    virtual void vSWC_Prev_ShortPress( );

    virtual ulword ulwGetColor(ulword ulwLineNumber, ulword ulwColumnNumber);

    virtual ulword ulwGetDirectionSymbol(ulword ulwLineNumber);

    virtual void vSwcPhoneEndPressed( );

    virtual void vSetCurrentGUIApplication(ulword ulwGUIApplication);

    virtual ulword ulwGetSettingsMenuToDisplay( );

    virtual void vStartSmsReplySession( );

    virtual void vBackButtonPressed( );

    virtual void vHangUpButtonPressed( );

    virtual void vReadSMSFromTTS(const GUI_String * InputString);

    virtual void vAbortTTSPrompt( );

    virtual tbool blIsIdle( );

    virtual void vStartSessionFromHelp( );

    virtual void vStartPhonetization( );

    virtual void vPttPressFromCameraMode( );

    virtual void vAbortSession( );

    virtual tbool blIsPhonetizationActive( );

    virtual void vGetGracenoteVersion(GUI_String *out_result);

protected:
    clHSA_SpeechDialog_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_SpeechDialog_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_SpeechDialog_Base_H

