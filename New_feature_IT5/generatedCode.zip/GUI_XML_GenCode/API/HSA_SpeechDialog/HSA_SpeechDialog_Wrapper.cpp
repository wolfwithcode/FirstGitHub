/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_SpeechDialog_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_SpeechDialog_Wrapper.h"
#include "clHSA_SpeechDialog_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_SpeechDialog_Trace.h"
#include "hmi_trace.h"

void HSA_SpeechDialog__vGetHeadline(GUI_String *out_result)
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_HEADLINE  ) ); 
        }
      pInst->vGetHeadline(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_HEADLINE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SpeechDialog__vGetText(GUI_String *out_result, ulword ulwLineNumber, ulword ulwColumnNumber)
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_TEXT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLineNumber); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_TEXT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwColumnNumber); 
        }
      pInst->vGetText(out_result, ulwLineNumber, ulwColumnNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_TEXT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SpeechDialog__vGetDescription(GUI_String *out_result, ulword ulwLineNumber)
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_DESCRIPTION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLineNumber); 
        }
      pInst->vGetDescription(out_result, ulwLineNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_DESCRIPTION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SpeechDialog__vGetHelpLine(GUI_String *out_result)
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_HELP_LINE  ) ); 
        }
      pInst->vGetHelpLine(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_HELP_LINE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SpeechDialog__vGetStatusLine(GUI_String *out_result)
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_STATUS_LINE  ) ); 
        }
      pInst->vGetStatusLine(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_STATUS_LINE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_SpeechDialog__blIsSpeechInputActive( )
{
    tbool ret = false;
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__IS_SPEECH_INPUT_ACTIVE  ) ); 
        }
      ret=pInst->blIsSpeechInputActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__IS_SPEECH_INPUT_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SpeechDialog__vCancelSession( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__CANCEL_SESSION  ) ); 
        }
      pInst->vCancelSession();

    }
}

void HSA_SpeechDialog__vRequestUserWordSession( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__REQUEST_USER_WORD_SESSION  ) ); 
        }
      pInst->vRequestUserWordSession();

    }
}

tbool HSA_SpeechDialog__blIsSDSHelpDataAvailable( )
{
    tbool ret = false;
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__IS_SDS_HELP_DATA_AVAILABLE  ) ); 
        }
      ret=pInst->blIsSDSHelpDataAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__IS_SDS_HELP_DATA_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SpeechDialog__ulwGetNumberOfSDSHelpDataList( )
{
    ulword ret = 0;
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_NUMBER_OF_SDS_HELP_DATA_LIST  ) ); 
        }
      ret=pInst->ulwGetNumberOfSDSHelpDataList();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_NUMBER_OF_SDS_HELP_DATA_LIST | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SpeechDialog__vGetSDSHelpDataListEntries(GUI_String *out_result, ulword ulwListEntryNumber)
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_SDS_HELP_DATA_LIST_ENTRIES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      pInst->vGetSDSHelpDataListEntries(out_result, ulwListEntryNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_SDS_HELP_DATA_LIST_ENTRIES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_SpeechDialog__vSelectSDSHelpDataListEntry(ulword ulwListEntryNumber)
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__SELECT_SDS_HELP_DATA_LIST_ENTRY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNumber); 
        }
      pInst->vSelectSDSHelpDataListEntry(ulwListEntryNumber);

    }
}

void HSA_SpeechDialog__vEnterSDSHelpDataListMainScreen( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__ENTER_SDS_HELP_DATA_LIST_MAIN_SCREEN  ) ); 
        }
      pInst->vEnterSDSHelpDataListMainScreen();

    }
}

void HSA_SpeechDialog__vPttShortPressed( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__PTT_SHORT_PRESSED  ) ); 
        }
      pInst->vPttShortPressed();

    }
}

void HSA_SpeechDialog__vPttLongPressed( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__PTT_LONG_PRESSED  ) ); 
        }
      pInst->vPttLongPressed();

    }
}

void HSA_SpeechDialog__vSWC_Next_ShortPress( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__SWC__NEXT__SHORT_PRESS  ) ); 
        }
      pInst->vSWC_Next_ShortPress();

    }
}

void HSA_SpeechDialog__vSWC_Prev_ShortPress( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__SWC__PREV__SHORT_PRESS  ) ); 
        }
      pInst->vSWC_Prev_ShortPress();

    }
}

ulword HSA_SpeechDialog__ulwGetColor(ulword ulwLineNumber, ulword ulwColumnNumber)
{
    ulword ret = 0;
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_COLOR | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLineNumber); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_COLOR | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwColumnNumber); 
        }
      ret=pInst->ulwGetColor(ulwLineNumber, ulwColumnNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_COLOR | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_SpeechDialog__ulwGetDirectionSymbol(ulword ulwLineNumber)
{
    ulword ret = 0;
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_DIRECTION_SYMBOL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwLineNumber); 
        }
      ret=pInst->ulwGetDirectionSymbol(ulwLineNumber);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_DIRECTION_SYMBOL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SpeechDialog__vSwcPhoneEndPressed( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__SWC_PHONE_END_PRESSED  ) ); 
        }
      pInst->vSwcPhoneEndPressed();

    }
}

void HSA_SpeechDialog__vSetCurrentGUIApplication(ulword ulwGUIApplication)
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__SET_CURRENT_GUI_APPLICATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwGUIApplication); 
        }
      pInst->vSetCurrentGUIApplication(ulwGUIApplication);

    }
}

ulword HSA_SpeechDialog__ulwGetSettingsMenuToDisplay( )
{
    ulword ret = 0;
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_SETTINGS_MENU_TO_DISPLAY  ) ); 
        }
      ret=pInst->ulwGetSettingsMenuToDisplay();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_SETTINGS_MENU_TO_DISPLAY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_SpeechDialog__vStartSmsReplySession( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__START_SMS_REPLY_SESSION  ) ); 
        }
      pInst->vStartSmsReplySession();

    }
}

void HSA_SpeechDialog__vBackButtonPressed( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__BACK_BUTTON_PRESSED  ) ); 
        }
      pInst->vBackButtonPressed();

    }
}

void HSA_SpeechDialog__vHangUpButtonPressed( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__HANG_UP_BUTTON_PRESSED  ) ); 
        }
      pInst->vHangUpButtonPressed();

    }
}

void HSA_SpeechDialog__vReadSMSFromTTS(const GUI_String * InputString)
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__READ_SMS_FROM_TTS | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vReadSMSFromTTS( InputString);

    }
}

void HSA_SpeechDialog__vAbortTTSPrompt( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__ABORT_TTS_PROMPT  ) ); 
        }
      pInst->vAbortTTSPrompt();

    }
}

tbool HSA_SpeechDialog__blIsIdle( )
{
    tbool ret = false;
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__IS_IDLE  ) ); 
        }
      ret=pInst->blIsIdle();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__IS_IDLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SpeechDialog__vStartSessionFromHelp( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__START_SESSION_FROM_HELP  ) ); 
        }
      pInst->vStartSessionFromHelp();

    }
}

void HSA_SpeechDialog__vStartPhonetization( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__START_PHONETIZATION  ) ); 
        }
      pInst->vStartPhonetization();

    }
}

void HSA_SpeechDialog__vPttPressFromCameraMode( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__PTT_PRESS_FROM_CAMERA_MODE  ) ); 
        }
      pInst->vPttPressFromCameraMode();

    }
}

void HSA_SpeechDialog__vAbortSession( )
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__ABORT_SESSION  ) ); 
        }
      pInst->vAbortSession();

    }
}

tbool HSA_SpeechDialog__blIsPhonetizationActive( )
{
    tbool ret = false;
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__IS_PHONETIZATION_ACTIVE  ) ); 
        }
      ret=pInst->blIsPhonetizationActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__IS_PHONETIZATION_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_SpeechDialog__vGetGracenoteVersion(GUI_String *out_result)
{
    
    clHSA_SpeechDialog_Base *pInst=clHSA_SpeechDialog_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_GRACENOTE_VERSION  ) ); 
        }
      pInst->vGetGracenoteVersion(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_SPEECHDIALOG), (tU16)(HSA_API_ENTRYPOINT__GET_GRACENOTE_VERSION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

#ifdef __cplusplus
}
#endif

