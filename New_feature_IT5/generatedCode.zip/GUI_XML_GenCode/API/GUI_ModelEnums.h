/**
 *  @file GUI_ModelEnums.h
 * 
 * @brief Generated file containing all model defined enumerations.
 * Generation date:	Fri Dec 05 16:37:52 IST 2014
 */

#ifndef _GUI_MODELENUMS_H
#define _GUI_MODELENUMS_H

#endif // #ifndef _GUI_MODELENUMS_H
