/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Radio_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_Radio_Wrapper.h"
#include "clHSA_Radio_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_Radio_Trace.h"
#include "hmi_trace.h"

tbool HSA_Radio__blIsDABListUpdateActive( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DAB_LIST_UPDATE_ACTIVE  ) ); 
        }
      ret=pInst->blIsDABListUpdateActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DAB_LIST_UPDATE_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vActivateNextSecComponent( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_NEXT_SEC_COMPONENT  ) ); 
        }
      pInst->vActivateNextSecComponent();

    }
}

void HSA_Radio__vActivatePreviousSecComponent( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_PREVIOUS_SEC_COMPONENT  ) ); 
        }
      pInst->vActivatePreviousSecComponent();

    }
}

void HSA_Radio__vSetDABSecAudioOff( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_DAB_SEC_AUDIO_OFF  ) ); 
        }
      pInst->vSetDABSecAudioOff();

    }
}

tbool HSA_Radio__blGetDABComponentMode( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_COMPONENT_MODE  ) ); 
        }
      ret=pInst->blGetDABComponentMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_COMPONENT_MODE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vUpdateDABSrvList(tbool blAction)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__UPDATE_DAB_SRV_LIST | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blAction); 
        }
      pInst->vUpdateDABSrvList(blAction);

    }
}

tbool HSA_Radio__blGetDAB_FM_SF_Status( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_FM_SF__STATUS  ) ); 
        }
      ret=pInst->blGetDAB_FM_SF_Status();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_FM_SF__STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vCloseDABList( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__CLOSE_DAB_LIST  ) ); 
        }
      pInst->vCloseDABList();

    }
}

ulword HSA_Radio__ulwGetDABSrvAvailability( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SRV_AVAILABILITY  ) ); 
        }
      ret=pInst->ulwGetDABSrvAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SRV_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetDABReceptionList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_RECEPTION_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDABReceptionList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_RECEPTION_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Radio__ulwGetDABSrvListLength( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SRV_LIST_LENGTH  ) ); 
        }
      ret=pInst->ulwGetDABSrvListLength();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SRV_LIST_LENGTH | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetDABCompListLength( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_COMP_LIST_LENGTH  ) ); 
        }
      ret=pInst->ulwGetDABCompListLength();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_COMP_LIST_LENGTH | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetDABNumSecComponents( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_SEC_COMPONENTS  ) ); 
        }
      ret=pInst->ulwGetDABNumSecComponents();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_NUM_SEC_COMPONENTS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetCurrentFrequencyString(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_FREQUENCY_STRING  ) ); 
        }
      pInst->vGetCurrentFrequencyString(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_FREQUENCY_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetCurrentFrequencyUnit(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_FREQUENCY_UNIT  ) ); 
        }
      pInst->vGetCurrentFrequencyUnit(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_FREQUENCY_UNIT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vActivateNextPresetStation( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_NEXT_PRESET_STATION  ) ); 
        }
      pInst->vActivateNextPresetStation();

    }
}

void HSA_Radio__vActivatePrevPresetStation( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_PREV_PRESET_STATION  ) ); 
        }
      pInst->vActivatePrevPresetStation();

    }
}

tbool HSA_Radio__blGetStereoStatus( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STEREO_STATUS  ) ); 
        }
      ret=pInst->blGetStereoStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STEREO_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetStationListLoadingState(ulword ulwActiveSource)
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_LIST_LOADING_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwActiveSource); 
        }
      ret=pInst->ulwGetStationListLoadingState(ulwActiveSource);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_LIST_LOADING_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetCurrentBank( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_BANK  ) ); 
        }
      ret=pInst->ulwGetCurrentBank();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_BANK | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetCurrentFrequency( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_FREQUENCY  ) ); 
        }
      ret=pInst->ulwGetCurrentFrequency();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_FREQUENCY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vSwitchAutoCompareBank(ulword ulwBand)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SWITCH_AUTO_COMPARE_BANK | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBand); 
        }
      pInst->vSwitchAutoCompareBank(ulwBand);

    }
}

void HSA_Radio__vIncreaseTunerFrequency(ulword ulwNoOfSteps)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__INCREASE_TUNER_FREQUENCY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vIncreaseTunerFrequency(ulwNoOfSteps);

    }
}

void HSA_Radio__vDecreaseTunerFrequency(ulword ulwNoOfSteps)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__DECREASE_TUNER_FREQUENCY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNoOfSteps); 
        }
      pInst->vDecreaseTunerFrequency(ulwNoOfSteps);

    }
}

void HSA_Radio__vSetTunerFrequencyDirect(ulword ulwFrequency)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_TUNER_FREQUENCY_DIRECT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwFrequency); 
        }
      pInst->vSetTunerFrequencyDirect(ulwFrequency);

    }
}

void HSA_Radio__vActivateBand(ulword ulwBand)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_BAND | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBand); 
        }
      pInst->vActivateBand(ulwBand);

    }
}

void HSA_Radio__vActivateDABService(ulword ulwListEntryNr, ulword ulwSubListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_DAB_SERVICE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_DAB_SERVICE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSubListEntryNr); 
        }
      pInst->vActivateDABService(ulwListEntryNr, ulwSubListEntryNr);

    }
}

void HSA_Radio__vActivateInitialAutoStore( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_INITIAL_AUTO_STORE  ) ); 
        }
      pInst->vActivateInitialAutoStore();

    }
}

void HSA_Radio__vActivateNextEnsemble( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_NEXT_ENSEMBLE  ) ); 
        }
      pInst->vActivateNextEnsemble();

    }
}

void HSA_Radio__vActivateNextListStation( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_NEXT_LIST_STATION  ) ); 
        }
      pInst->vActivateNextListStation();

    }
}

void HSA_Radio__vActivateNextStation( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_NEXT_STATION  ) ); 
        }
      pInst->vActivateNextStation();

    }
}

void HSA_Radio__vActivatePreviousEnsemble( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_PREVIOUS_ENSEMBLE  ) ); 
        }
      pInst->vActivatePreviousEnsemble();

    }
}

void HSA_Radio__vActivatePreviousListStation( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_PREVIOUS_LIST_STATION  ) ); 
        }
      pInst->vActivatePreviousListStation();

    }
}

void HSA_Radio__vActivatePreviousStation( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_PREVIOUS_STATION  ) ); 
        }
      pInst->vActivatePreviousStation();

    }
}

void HSA_Radio__vActivateSecondaryService(ulword ulwListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_SECONDARY_SERVICE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vActivateSecondaryService(ulwListEntryNr);

    }
}

void HSA_Radio__vActivateStation(ulword ulwListType, ulword ulwListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_STATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_STATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vActivateStation(ulwListType, ulwListEntryNr);

    }
}

void HSA_Radio__vActivateStationPreset(ulword ulwEntryNr, ulword ulwBankNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_STATION_PRESET | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_STATION_PRESET | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBankNr); 
        }
      pInst->vActivateStationPreset(ulwEntryNr, ulwBankNr);

    }
}

void HSA_Radio__vCancelUpdateDABStationList( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__CANCEL_UPDATE_DAB_STATION_LIST  ) ); 
        }
      pInst->vCancelUpdateDABStationList();

    }
}

void HSA_Radio__vClearPresetList( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__CLEAR_PRESET_LIST  ) ); 
        }
      pInst->vClearPresetList();

    }
}

slword HSA_Radio__slwConvertToDynamicIndex_DABEnsembleList(ulword ulwUniqueId)
{
    slword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_DYNAMIC_INDEX_DAB_ENSEMBLE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwUniqueId); 
        }
      ret=pInst->slwConvertToDynamicIndex_DABEnsembleList(ulwUniqueId);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_DYNAMIC_INDEX_DAB_ENSEMBLE_LIST | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Radio__slwConvertToDynamicIndex_DABSecServicesList(ulword ulwUniqueId)
{
    slword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_DYNAMIC_INDEX_DAB_SEC_SERVICES_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwUniqueId); 
        }
      ret=pInst->slwConvertToDynamicIndex_DABSecServicesList(ulwUniqueId);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_DYNAMIC_INDEX_DAB_SEC_SERVICES_LIST | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Radio__slwConvertToUniqueId_DABEnsembleList(ulword ulwDynamicIndex)
{
    slword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_UNIQUE_ID_DAB_ENSEMBLE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDynamicIndex); 
        }
      ret=pInst->slwConvertToUniqueId_DABEnsembleList(ulwDynamicIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_UNIQUE_ID_DAB_ENSEMBLE_LIST | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

slword HSA_Radio__slwConvertToUniqueId_DABSecServicesList(ulword ulwDynamicIndex)
{
    slword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_UNIQUE_ID_DAB_SEC_SERVICES_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDynamicIndex); 
        }
      ret=pInst->slwConvertToUniqueId_DABSecServicesList(ulwDynamicIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__CONVERT_TO_UNIQUE_ID_DAB_SEC_SERVICES_LIST | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vDeletePresetStation(ulword ulwEntryNr, ulword ulwBankNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__DELETE_PRESET_STATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__DELETE_PRESET_STATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBankNr); 
        }
      pInst->vDeletePresetStation(ulwEntryNr, ulwBankNr);

    }
}

void HSA_Radio__vExitStationList( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__EXIT_STATION_LIST  ) ); 
        }
      pInst->vExitStationList();

    }
}

void HSA_Radio__vFixActiveStationListName( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__FIX_ACTIVE_STATION_LIST_NAME  ) ); 
        }
      pInst->vFixActiveStationListName();

    }
}

void HSA_Radio__vFixActiveStationName( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__FIX_ACTIVE_STATION_NAME  ) ); 
        }
      pInst->vFixActiveStationName();

    }
}

void HSA_Radio__vFreezePS( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__FREEZE_PS  ) ); 
        }
      pInst->vFreezePS();

    }
}

ulword HSA_Radio__ulwGetActiveEnsembleIndex( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_ENSEMBLE_INDEX  ) ); 
        }
      ret=pInst->ulwGetActiveEnsembleIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_ENSEMBLE_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetActiveEnsembleServiceIndex( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_ENSEMBLE_SERVICE_INDEX  ) ); 
        }
      ret=pInst->ulwGetActiveEnsembleServiceIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_ENSEMBLE_SERVICE_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetActiveFavouritesScreen( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_FAVOURITES_SCREEN  ) ); 
        }
      ret=pInst->ulwGetActiveFavouritesScreen();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_FAVOURITES_SCREEN | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetActiveSecondaryServiceIndex( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_SECONDARY_SERVICE_INDEX  ) ); 
        }
      ret=pInst->ulwGetActiveSecondaryServiceIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_SECONDARY_SERVICE_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetActiveSecondaryServiceName(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_SECONDARY_SERVICE_NAME  ) ); 
        }
      pInst->vGetActiveSecondaryServiceName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_SECONDARY_SERVICE_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetActiveStationBandString(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_BAND_STRING  ) ); 
        }
      pInst->vGetActiveStationBandString(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_BAND_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetActiveStationEnsembleName(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_ENSEMBLE_NAME  ) ); 
        }
      pInst->vGetActiveStationEnsembleName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_ENSEMBLE_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Radio__ulwGetActiveStationEnsembleState( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_ENSEMBLE_STATE  ) ); 
        }
      ret=pInst->ulwGetActiveStationEnsembleState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_ENSEMBLE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetActiveStationListIndex(ulword ulwListType)
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_LIST_INDEX | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListType); 
        }
      ret=pInst->ulwGetActiveStationListIndex(ulwListType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_LIST_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetActiveStationName(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_NAME  ) ); 
        }
      pInst->vGetActiveStationName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetActiveStationNameShort(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_NAME_SHORT  ) ); 
        }
      pInst->vGetActiveStationNameShort(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_NAME_SHORT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

slword HSA_Radio__slwGetActiveStationPresetNr(ulword ulwActiveSource)
{
    slword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_PRESET_NR | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwActiveSource); 
        }
      ret=pInst->slwGetActiveStationPresetNr(ulwActiveSource);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_PRESET_NR | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetActiveStationPS(GUI_String *out_result, ulword ulwActiveSource)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_PS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwActiveSource); 
        }
      pInst->vGetActiveStationPS(out_result, ulwActiveSource);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_PS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Radio__ulwGetCurrentBand( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_BAND  ) ); 
        }
      ret=pInst->ulwGetCurrentBand();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_BAND | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vSetTunerVisibality(tbool blVisibality, ulword ulwSource)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_TUNER_VISIBALITY | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blVisibality); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_TUNER_VISIBALITY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSource); 
        }
      pInst->vSetTunerVisibality(blVisibality, ulwSource);

    }
}

void HSA_Radio__vGetCurrentTAStationName(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TA_STATION_NAME  ) ); 
        }
      pInst->vGetCurrentTAStationName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_TA_STATION_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Radio__blGetDAB_LBandState( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_L_BAND_STATE  ) ); 
        }
      ret=pInst->blGetDAB_LBandState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_L_BAND_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetDABEnsembleList_Count( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_LIST__COUNT  ) ); 
        }
      ret=pInst->ulwGetDABEnsembleList_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_LIST__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetDABEnsembleListItem_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_LIST_ITEM__NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDABEnsembleListItem_Name(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_LIST_ITEM__NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Radio__ulwGetDABEnsembleListItem_State(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_LIST_ITEM__STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetDABEnsembleListItem_State(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_LIST_ITEM__STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetDABEnsembleServiceList_Count(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST__COUNT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetDABEnsembleServiceList_Count(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetDABEnsembleServiceListItem_Name(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwSubListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST_ITEM__NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST_ITEM__NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSubListEntryNr); 
        }
      pInst->vGetDABEnsembleServiceListItem_Name(out_result, ulwListEntryNr, ulwSubListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST_ITEM__NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Radio__ulwGetDABEnsembleServiceListItem_State(ulword ulwListEntryNr, ulword ulwSubListEntryNr)
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST_ITEM__STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST_ITEM__STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSubListEntryNr); 
        }
      ret=pInst->ulwGetDABEnsembleServiceListItem_State(ulwListEntryNr, ulwSubListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST_ITEM__STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetDABEnsembleServiceListItem_TP(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwSubListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST_ITEM_TP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST_ITEM_TP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSubListEntryNr); 
        }
      pInst->vGetDABEnsembleServiceListItem_TP(out_result, ulwListEntryNr, ulwSubListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST_ITEM_TP | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Radio__blGetDABOtherAnnouncementState( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_OTHER_ANNOUNCEMENT_STATE  ) ); 
        }
      ret=pInst->blGetDABOtherAnnouncementState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_OTHER_ANNOUNCEMENT_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetDABRadioText(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_RADIO_TEXT  ) ); 
        }
      pInst->vGetDABRadioText(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_RADIO_TEXT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Radio__ulwGetDABRadioTextState( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_RADIO_TEXT_STATE  ) ); 
        }
      ret=pInst->ulwGetDABRadioTextState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_RADIO_TEXT_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blGetDABServiceFollowingState( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_FOLLOWING_STATE  ) ); 
        }
      ret=pInst->blGetDABServiceFollowingState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_FOLLOWING_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blGetDABServiceLinkingState( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_STATE  ) ); 
        }
      ret=pInst->blGetDABServiceLinkingState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetDABServiceState( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_STATE  ) ); 
        }
      ret=pInst->ulwGetDABServiceState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_SERVICE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetDABStationListUpdateState( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_STATION_LIST_UPDATE_STATE  ) ); 
        }
      ret=pInst->ulwGetDABStationListUpdateState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_DAB_STATION_LIST_UPDATE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetFirstEmptyPreset( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_FIRST_EMPTY_PRESET  ) ); 
        }
      ret=pInst->ulwGetFirstEmptyPreset();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_FIRST_EMPTY_PRESET | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetRadioText(GUI_String *out_result, ulword ulwActiveSource)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_RADIO_TEXT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwActiveSource); 
        }
      pInst->vGetRadioText(out_result, ulwActiveSource);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_RADIO_TEXT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Radio__ulwGetFMRadioTextState( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_FM_RADIO_TEXT_STATE  ) ); 
        }
      ret=pInst->ulwGetFMRadioTextState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_FM_RADIO_TEXT_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetStationNameList(GUI_String *out_result, ulword ulwListType, ulword ulwListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_NAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_NAME_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetStationNameList(out_result, ulwListType, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_NAME_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetStationPresetNrList(GUI_String *out_result, ulword ulwListType, ulword ulwListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_PRESET_NR_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_PRESET_NR_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetStationPresetNrList(out_result, ulwListType, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_PRESET_NR_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetFMStationRegList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_FM_STATION_REG_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetFMStationRegList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_FM_STATION_REG_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetFMStationTPList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_FM_STATION_TP_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetFMStationTPList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_FM_STATION_TP_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetStationFreqList(GUI_String *out_result, ulword ulwListType, ulword ulwListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_FREQ_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_FREQ_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetStationFreqList(out_result, ulwListType, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_FREQ_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetPresetButtonText(GUI_String *out_result, ulword ulwIndex, ulword ulwBank)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_BUTTON_TEXT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_BUTTON_TEXT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBank); 
        }
      pInst->vGetPresetButtonText(out_result, ulwIndex, ulwBank);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_BUTTON_TEXT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

slword HSA_Radio__slwGetPresetStationBand(ulword ulwEntryNr, ulword ulwBankNr)
{
    slword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_STATION_BAND | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_STATION_BAND | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBankNr); 
        }
      ret=pInst->slwGetPresetStationBand(ulwEntryNr, ulwBankNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_STATION_BAND | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetPresetStationBandString(GUI_String *out_result, ulword ulwEntryNr, ulword ulwBankNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_STATION_BAND_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_STATION_BAND_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBankNr); 
        }
      pInst->vGetPresetStationBandString(out_result, ulwEntryNr, ulwBankNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_STATION_BAND_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetPresetStationEnsembleName(GUI_String *out_result, ulword ulwEntryNr, ulword ulwBankNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_STATION_ENSEMBLE_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_STATION_ENSEMBLE_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBankNr); 
        }
      pInst->vGetPresetStationEnsembleName(out_result, ulwEntryNr, ulwBankNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_STATION_ENSEMBLE_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetPresetStationName(GUI_String *out_result, ulword ulwEntryNr, ulword ulwBankNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_STATION_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_STATION_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBankNr); 
        }
      pInst->vGetPresetStationName(out_result, ulwEntryNr, ulwBankNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_PRESET_STATION_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Radio__blGetRadioTextModeState( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_RADIO_TEXT_MODE_STATE  ) ); 
        }
      ret=pInst->blGetRadioTextModeState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_RADIO_TEXT_MODE_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetReceivedDABAnnouncementProgName(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_DAB_ANNOUNCEMENT_PROG_NAME  ) ); 
        }
      pInst->vGetReceivedDABAnnouncementProgName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_DAB_ANNOUNCEMENT_PROG_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Radio__ulwGetReceivedDABAnnouncementType( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_DAB_ANNOUNCEMENT_TYPE  ) ); 
        }
      ret=pInst->ulwGetReceivedDABAnnouncementType();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_DAB_ANNOUNCEMENT_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetRegState( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_REG_STATE  ) ); 
        }
      ret=pInst->ulwGetRegState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_REG_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetSecondaryServiceList_Count( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SECONDARY_SERVICE_LIST__COUNT  ) ); 
        }
      ret=pInst->ulwGetSecondaryServiceList_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SECONDARY_SERVICE_LIST__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetSecondaryServiceListItem_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SECONDARY_SERVICE_LIST_ITEM__NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetSecondaryServiceListItem_Name(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SECONDARY_SERVICE_LIST_ITEM__NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Radio__ulwGetSecondaryServiceListItem_State(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SECONDARY_SERVICE_LIST_ITEM__STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetSecondaryServiceListItem_State(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SECONDARY_SERVICE_LIST_ITEM__STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetSeekMode( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SEEK_MODE  ) ); 
        }
      ret=pInst->ulwGetSeekMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SEEK_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blGetSelectionMode( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTION_MODE  ) ); 
        }
      ret=pInst->blGetSelectionMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_SELECTION_MODE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetStationInfoFM_Count( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_INFO_FM__COUNT  ) ); 
        }
      ret=pInst->ulwGetStationInfoFM_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_INFO_FM__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetTPSeekState( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_TP_SEEK_STATE  ) ); 
        }
      ret=pInst->ulwGetTPSeekState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_TP_SEEK_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Radio__ulwGetTPState( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_TP_STATE  ) ); 
        }
      ret=pInst->ulwGetTPState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_TP_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsDABAvailable( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DAB_AVAILABLE  ) ); 
        }
      ret=pInst->blIsDABAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DAB_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsDABOtherAnnouncementPlaying( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DAB_OTHER_ANNOUNCEMENT_PLAYING  ) ); 
        }
      ret=pInst->blIsDABOtherAnnouncementPlaying();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DAB_OTHER_ANNOUNCEMENT_PLAYING | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsDABServiceReadyToBeStored( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DAB_SERVICE_READY_TO_BE_STORED  ) ); 
        }
      ret=pInst->blIsDABServiceReadyToBeStored();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DAB_SERVICE_READY_TO_BE_STORED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsDABServiceSeekActive( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DAB_SERVICE_SEEK_ACTIVE  ) ); 
        }
      ret=pInst->blIsDABServiceSeekActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DAB_SERVICE_SEEK_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsDABTrafficAnnouncementPlaying( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DAB_TRAFFIC_ANNOUNCEMENT_PLAYING  ) ); 
        }
      ret=pInst->blIsDABTrafficAnnouncementPlaying();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DAB_TRAFFIC_ANNOUNCEMENT_PLAYING | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsManualModeActive( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_MANUAL_MODE_ACTIVE  ) ); 
        }
      ret=pInst->blIsManualModeActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_MANUAL_MODE_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsPSNameAvailable( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_PS_NAME_AVAILABLE  ) ); 
        }
      ret=pInst->blIsPSNameAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_PS_NAME_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsScanActive( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_SCAN_ACTIVE  ) ); 
        }
      ret=pInst->blIsScanActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_SCAN_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsSeekActive( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_SEEK_ACTIVE  ) ); 
        }
      ret=pInst->blIsSeekActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_SEEK_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsTAMessagePlaying( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_TA_MESSAGE_PLAYING  ) ); 
        }
      ret=pInst->blIsTAMessagePlaying();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_TA_MESSAGE_PLAYING | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsTPActivated( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_TP_ACTIVATED  ) ); 
        }
      ret=pInst->blIsTPActivated();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_TP_ACTIVATED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsTPSeekActive( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_TP_SEEK_ACTIVE  ) ); 
        }
      ret=pInst->blIsTPSeekActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_TP_SEEK_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vLoadList(ulword ulwListType)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__LOAD_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListType); 
        }
      pInst->vLoadList(ulwListType);

    }
}

ulword HSA_Radio__ulwScanStart( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SCAN_START  ) ); 
        }
      ret=pInst->ulwScanStart();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SCAN_START | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vScanStop( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SCAN_STOP  ) ); 
        }
      pInst->vScanStop();

    }
}

ulword HSA_Radio__ulwSeekStart(ulword ulwDirection)
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_START | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDirection); 
        }
      ret=pInst->ulwSeekStart(ulwDirection);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_START | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vSeekStop( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SEEK_STOP  ) ); 
        }
      pInst->vSeekStop();

    }
}

void HSA_Radio__vSetActiveFavouritesScreen(ulword ulwBankNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_ACTIVE_FAVOURITES_SCREEN | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBankNr); 
        }
      pInst->vSetActiveFavouritesScreen(ulwBankNr);

    }
}

void HSA_Radio__vSetDABOtherAnnouncementOff( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_DAB_OTHER_ANNOUNCEMENT_OFF  ) ); 
        }
      pInst->vSetDABOtherAnnouncementOff();

    }
}

void HSA_Radio__vSetDABTrafficAnnouncementOff( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_DAB_TRAFFIC_ANNOUNCEMENT_OFF  ) ); 
        }
      pInst->vSetDABTrafficAnnouncementOff();

    }
}

void HSA_Radio__vSetManualMode(tbool blValue)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_MANUAL_MODE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blValue); 
        }
      pInst->vSetManualMode(blValue);

    }
}

void HSA_Radio__vSetRadioTextModeState(tbool blMode)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_RADIO_TEXT_MODE_STATE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vSetRadioTextModeState(blMode);

    }
}

void HSA_Radio__vSetRegState(ulword ulwValue)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_REG_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwValue); 
        }
      pInst->vSetRegState(ulwValue);

    }
}

void HSA_Radio__vSetSeekMode(ulword ulwValue)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_SEEK_MODE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwValue); 
        }
      pInst->vSetSeekMode(ulwValue);

    }
}

void HSA_Radio__vSetSelectionMode(tbool blMode)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_SELECTION_MODE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blMode); 
        }
      pInst->vSetSelectionMode(blMode);

    }
}

void HSA_Radio__vSetTPState(tbool blValue)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SET_TP_STATE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blValue); 
        }
      pInst->vSetTPState(blValue);

    }
}

void HSA_Radio__vStopCurrentDABAnnouncement( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__STOP_CURRENT_DAB_ANNOUNCEMENT  ) ); 
        }
      pInst->vStopCurrentDABAnnouncement();

    }
}

void HSA_Radio__vStopCurrentTAMessage( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__STOP_CURRENT_TA_MESSAGE  ) ); 
        }
      pInst->vStopCurrentTAMessage();

    }
}

void HSA_Radio__vStopInitialAutostore( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__STOP_INITIAL_AUTOSTORE  ) ); 
        }
      pInst->vStopInitialAutostore();

    }
}

void HSA_Radio__vStopTPSeek( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__STOP_TP_SEEK  ) ); 
        }
      pInst->vStopTPSeek();

    }
}

void HSA_Radio__vStoreCurrentStationPreset(ulword ulwEntryNr, ulword ulwBankNr)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__STORE_CURRENT_STATION_PRESET | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__STORE_CURRENT_STATION_PRESET | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwBankNr); 
        }
      pInst->vStoreCurrentStationPreset(ulwEntryNr, ulwBankNr);

    }
}

void HSA_Radio__vTargetSeekStart(ulword ulwDirection)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__TARGET_SEEK_START | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwDirection); 
        }
      pInst->vTargetSeekStart(ulwDirection);

    }
}

void HSA_Radio__vTargetSeekStop( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__TARGET_SEEK_STOP  ) ); 
        }
      pInst->vTargetSeekStop();

    }
}

void HSA_Radio__vToggleDAB_LBandState( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_DAB_L_BAND_STATE  ) ); 
        }
      pInst->vToggleDAB_LBandState();

    }
}

void HSA_Radio__vToggleDABOtherAnnouncementState( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_DAB_OTHER_ANNOUNCEMENT_STATE  ) ); 
        }
      pInst->vToggleDABOtherAnnouncementState();

    }
}

void HSA_Radio__vToggleDABServiceFollowingState( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_DAB_SERVICE_FOLLOWING_STATE  ) ); 
        }
      pInst->vToggleDABServiceFollowingState();

    }
}

void HSA_Radio__vToggleDABServiceLinkingState( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_DAB_SERVICE_LINKING_STATE  ) ); 
        }
      pInst->vToggleDABServiceLinkingState();

    }
}

void HSA_Radio__vToggleDABServiceState( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_DAB_SERVICE_STATE  ) ); 
        }
      pInst->vToggleDABServiceState();

    }
}

void HSA_Radio__vToggleTPState( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_TP_STATE  ) ); 
        }
      pInst->vToggleTPState();

    }
}

void HSA_Radio__vUnfixActiveStationName( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__UNFIX_ACTIVE_STATION_NAME  ) ); 
        }
      pInst->vUnfixActiveStationName();

    }
}

void HSA_Radio__vUpdateDABStationList( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__UPDATE_DAB_STATION_LIST  ) ); 
        }
      pInst->vUpdateDABStationList();

    }
}

void HSA_Radio__vToggleHDsetting( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_H_DSETTING  ) ); 
        }
      pInst->vToggleHDsetting();

    }
}

tbool HSA_Radio__blGetHDSetting( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_HD_SETTING  ) ); 
        }
      ret=pInst->blGetHDSetting();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_HD_SETTING | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blIsPresetHDStation(ulword ulwPresetID)
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_PRESET_HD_STATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwPresetID); 
        }
      ret=pInst->blIsPresetHDStation(ulwPresetID);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_PRESET_HD_STATION | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Radio__blGetListUpdateStatus( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_LIST_UPDATE_STATUS  ) ); 
        }
      ret=pInst->blGetListUpdateStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_LIST_UPDATE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vUpdateList(ulword ulwListID)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__UPDATE_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListID); 
        }
      pInst->vUpdateList(ulwListID);

    }
}

ulword HSA_Radio__ulwGetStationHDPrgNoList(ulword ulwListType, ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_HD_PRG_NO_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListType); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_HD_PRG_NO_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetStationHDPrgNoList(ulwListType, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_STATION_HD_PRG_NO_LIST | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vCancelListUpdate( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__CANCEL_LIST_UPDATE  ) ); 
        }
      pInst->vCancelListUpdate();

    }
}

tbool HSA_Radio__blIsActiveStationHD( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_ACTIVE_STATION_HD  ) ); 
        }
      ret=pInst->blIsActiveStationHD();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_ACTIVE_STATION_HD | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetAvailableHDAudPrgmIDs(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_AVAILABLE_HD_AUD_PRGM_I_DS  ) ); 
        }
      pInst->vGetAvailableHDAudPrgmIDs(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_AVAILABLE_HD_AUD_PRGM_I_DS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Radio__blIsDigitalAudAvailable( )
{
    tbool ret = false;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DIGITAL_AUD_AVAILABLE  ) ); 
        }
      ret=pInst->blIsDigitalAudAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__IS_DIGITAL_AUD_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Radio__vGetTitlePSD(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_TITLE_PSD  ) ); 
        }
      pInst->vGetTitlePSD(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_TITLE_PSD | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetArtistPSD(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ARTIST_PSD  ) ); 
        }
      pInst->vGetArtistPSD(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ARTIST_PSD | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vGetAlbumPSD(GUI_String *out_result)
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ALBUM_PSD  ) ); 
        }
      pInst->vGetAlbumPSD(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_ALBUM_PSD | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Radio__vSelectHDAudPrgm( )
{
    
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__SELECT_HD_AUD_PRGM  ) ); 
        }
      pInst->vSelectHDAudPrgm();

    }
}

ulword HSA_Radio__ulwGetAMStationListCount( )
{
    ulword ret = 0;
    clHSA_Radio_Base *pInst=clHSA_Radio_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_AM_STATION_LIST_COUNT  ) ); 
        }
      ret=pInst->ulwGetAMStationListCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_RADIO), (tU16)(HSA_API_ENTRYPOINT__GET_AM_STATION_LIST_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

#ifdef __cplusplus
}
#endif

