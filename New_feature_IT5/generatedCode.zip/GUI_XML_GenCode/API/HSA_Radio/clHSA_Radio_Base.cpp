/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_Radio_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_Radio/clHSA_Radio_Base.h"

clHSA_Radio_Base* clHSA_Radio_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_Radio_Base.cpp.trc.h"
#endif


/**
 * Method: blIsDABListUpdateActive
  * To check if the DAB service list update is still active or not
  * NISSAN
 */
tbool clHSA_Radio_Base::blIsDABListUpdateActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsDABListUpdateActive not implemented"));
   return 0;
}

/**
 * Method: vActivateNextSecComponent
  * To activate the next secondary component through skip buttons
  * NISSAN
 */
void clHSA_Radio_Base::vActivateNextSecComponent( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vActivateNextSecComponent not implemented"));
   
}

/**
 * Method: vActivatePreviousSecComponent
  * To activate the previous secondary component through skip buttons
  * NISSAN
 */
void clHSA_Radio_Base::vActivatePreviousSecComponent( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vActivatePreviousSecComponent not implemented"));
   
}

/**
 * Method: vSetDABSecAudioOff
  * To switch off the secondary audio and return to last primary service
  * NISSAN
 */
void clHSA_Radio_Base::vSetDABSecAudioOff( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vSetDABSecAudioOff not implemented"));
   
}

/**
 * Method: blGetDABComponentMode
  * To get notified if active service is primary or secondary
  * NISSAN
 */
tbool clHSA_Radio_Base::blGetDABComponentMode( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blGetDABComponentMode not implemented"));
   return 0;
}

/**
 * Method: vUpdateDABSrvList
  * API for updating or cancelling the update of the service list
  * NISSAN
 */
void clHSA_Radio_Base::vUpdateDABSrvList(tbool blAction)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blAction);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vUpdateDABSrvList not implemented"));
   
}

/**
 * Method: blGetDAB_FM_SF_Status
  * To get the FM Service following status
  * NISSAN
 */
tbool clHSA_Radio_Base::blGetDAB_FM_SF_Status( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blGetDAB_FM_SF_Status not implemented"));
   return 0;
}

/**
 * Method: vCloseDABList
  * To close the DAB service list. To be called on exiting from the service list screen
  * NISSAN
 */
void clHSA_Radio_Base::vCloseDABList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vCloseDABList not implemented"));
   
}

/**
 * Method: ulwGetDABSrvAvailability
  * To get the Service availability of the active service
  * NISSAN
 */
ulword clHSA_Radio_Base::ulwGetDABSrvAvailability( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetDABSrvAvailability not implemented"));
   return 0;
}

/**
 * Method: vGetDABReceptionList
  * Gets the reception of service at a particular index of the service list
  * NISSAN
 */
void clHSA_Radio_Base::vGetDABReceptionList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetDABReceptionList not implemented"));
   
}

/**
 * Method: ulwGetDABSrvListLength
  * To get the Service List length, once it is available in HMI
  * NISSAN
 */
ulword clHSA_Radio_Base::ulwGetDABSrvListLength( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetDABSrvListLength not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABCompListLength
  * To get the Secondary service list length, once the list is available in HMI
  * NISSAN
 */
ulword clHSA_Radio_Base::ulwGetDABCompListLength( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetDABCompListLength not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABNumSecComponents
  * To be used to check whether to enable 2ndAudio button and for requesting sec list
  * NISSAN
 */
ulword clHSA_Radio_Base::ulwGetDABNumSecComponents( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetDABNumSecComponents not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentFrequencyString
  * Return the current frequency information as string 
  * NISSAN
 */
void clHSA_Radio_Base::vGetCurrentFrequencyString(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetCurrentFrequencyString not implemented"));
   
}

/**
 * Method: vGetCurrentFrequencyUnit
  * Return the current frequency Unit information as string 
  * NISSAN
 */
void clHSA_Radio_Base::vGetCurrentFrequencyUnit(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetCurrentFrequencyUnit not implemented"));
   
}

/**
 * Method: vActivateNextPresetStation
  * Activates the next preset Station in the current bank
  * NISSAN
 */
void clHSA_Radio_Base::vActivateNextPresetStation( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vActivateNextPresetStation not implemented"));
   
}

/**
 * Method: vActivatePrevPresetStation
  * Activates the Previous preset Station in the current bank
  * NISSAN
 */
void clHSA_Radio_Base::vActivatePrevPresetStation( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vActivatePrevPresetStation not implemented"));
   
}

/**
 * Method: blGetStereoStatus
  * Return the Mono stereo Status
  * NISSAN
 */
tbool clHSA_Radio_Base::blGetStereoStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blGetStereoStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetStationListLoadingState
  * returns Station list loading State 
  * NISSAN
 */
ulword clHSA_Radio_Base::ulwGetStationListLoadingState(ulword ulwActiveSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwActiveSource);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetStationListLoadingState not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentBank
  * Return the current Bank information
  * NISSAN
 */
ulword clHSA_Radio_Base::ulwGetCurrentBank( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetCurrentBank not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentFrequency
  * Returns the Tuner Current Frequency 
  * NISSAN
 */
ulword clHSA_Radio_Base::ulwGetCurrentFrequency( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetCurrentFrequency not implemented"));
   return 0;
}

/**
 * Method: vSwitchAutoCompareBank
  * Set the Required Auto compare Params to Presets in Station List 
  * NISSAN
 */
void clHSA_Radio_Base::vSwitchAutoCompareBank(ulword ulwBand)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBand);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vSwitchAutoCompareBank not implemented"));
   
}

/**
 * Method: vIncreaseTunerFrequency
  * Increments the tuner frequency to the given no. of steps
  * 
 */
void clHSA_Radio_Base::vIncreaseTunerFrequency(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vIncreaseTunerFrequency not implemented"));
   
}

/**
 * Method: vDecreaseTunerFrequency
  * Decrements the tuner frequency to the given no. of steps
  * 
 */
void clHSA_Radio_Base::vDecreaseTunerFrequency(ulword ulwNoOfSteps)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNoOfSteps);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vDecreaseTunerFrequency not implemented"));
   
}

/**
 * Method: vSetTunerFrequencyDirect
  * Sets tuner to the frequency provided in input parmeter
  * 
 */
void clHSA_Radio_Base::vSetTunerFrequencyDirect(ulword ulwFrequency)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwFrequency);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vSetTunerFrequencyDirect not implemented"));
   
}

/**
 * Method: vActivateBand
  * Activates  1) DAB - if currentBand = AM and IsDABAvailable returns true 2)FM if currentBand = AM and IsDABAvailable returns false 3)FM   - if currentBand = DAB  4)AM    - if currentBand = FM 
  * B1
 */
void clHSA_Radio_Base::vActivateBand(ulword ulwBand)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBand);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vActivateBand not implemented"));
   
}

/**
 * Method: vActivateDABService
  * activates the selected service from the DAB stationlist. 
  * B1Plus
 */
void clHSA_Radio_Base::vActivateDABService(ulword ulwListEntryNr, ulword ulwSubListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSubListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vActivateDABService not implemented"));
   
}

/**
 * Method: vActivateInitialAutoStore
  * Start 'Initial Autostore FM'. ('The Broadcast Receiver shall provide a function to store receivable FM broadcast stations on the presets 1...6.'). Switch to FM mode at first. See TU_016
  * B
 */
void clHSA_Radio_Base::vActivateInitialAutoStore( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vActivateInitialAutoStore not implemented"));
   
}

/**
 * Method: vActivateNextEnsemble
  *  Activates the next ensemble.  If the 'last' ensemble was active switch to the 'first' ensemble again. This function is called in the hierarchical list.
  * BPlus
 */
void clHSA_Radio_Base::vActivateNextEnsemble( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vActivateNextEnsemble not implemented"));
   
}

/**
 * Method: vActivateNextListStation
  * Activates the next station from the station list. For DAB: If the last service of an ensemble was active the first service of the next available ensemble must be activated. If the 'last' ensemble was active switch to the 'first' ensemble again.
  * B2 [DAB: A plus]
 */
void clHSA_Radio_Base::vActivateNextListStation( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vActivateNextListStation not implemented"));
   
}

/**
 * Method: vActivateNextStation
  *  Activates the next station of the active list (station list or memory list, dependent of the active 'seek mode'). For DAB: If the last service of an ensemble was active the first service of the next available ensemble must be activated. If the 'last' ensemble was active switch to the 'first' ensemble again.
  * B2 [DAB: A plus]
 */
void clHSA_Radio_Base::vActivateNextStation( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vActivateNextStation not implemented"));
   
}

/**
 * Method: vActivatePreviousEnsemble
  *  Activates the previous ensemble.  If the 'last' ensemble was active switch to the 'first' ensemble again. This function is called in the hierarchical list.
  * BPlus
 */
void clHSA_Radio_Base::vActivatePreviousEnsemble( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vActivatePreviousEnsemble not implemented"));
   
}

/**
 * Method: vActivatePreviousListStation
  * equivalent to ActivateNextListStation
  * B2 [DAB: A plus]
 */
void clHSA_Radio_Base::vActivatePreviousListStation( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vActivatePreviousListStation not implemented"));
   
}

/**
 * Method: vActivatePreviousStation
  * equivalent to ActivateNextStation
  * B2 [DAB: A plus]
 */
void clHSA_Radio_Base::vActivatePreviousStation( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vActivatePreviousStation not implemented"));
   
}

/**
 * Method: vActivateSecondaryService
  * Activates the selected secondary audio service (subchannel) of the current selected DAB-station. The secondary audio service is called by a list index.
  * B1Plus
 */
void clHSA_Radio_Base::vActivateSecondaryService(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vActivateSecondaryService not implemented"));
   
}

/**
 * Method: vActivateStation
  * activates the selected station from the FM stationlist or DAB Service List or DAB Secondary List or AM list. 
  * B
 */
void clHSA_Radio_Base::vActivateStation(ulword ulwListType, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vActivateStation not implemented"));
   
}

/**
 * Method: vActivateStationPreset
  * Activates the station selected by the user in the Presets-Bank
  * B
 */
void clHSA_Radio_Base::vActivateStationPreset(ulword ulwEntryNr, ulword ulwBankNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBankNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vActivateStationPreset not implemented"));
   
}

/**
 * Method: vCancelUpdateDABStationList
  * Called to cancel the update of the ensemble list.
  * B1Plus
 */
void clHSA_Radio_Base::vCancelUpdateDABStationList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vCancelUpdateDABStationList not implemented"));
   
}

/**
 * Method: vClearPresetList
  * Clears all the preset-entries from  the preset-banks
  * B
 */
void clHSA_Radio_Base::vClearPresetList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vClearPresetList not implemented"));
   
}

/**
 * Method: slwConvertToDynamicIndex_DABEnsembleList
  * used for the highly dynamic list with multiparty calls
  * BPlus
 */
slword clHSA_Radio_Base::slwConvertToDynamicIndex_DABEnsembleList(ulword ulwUniqueId)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwUniqueId);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Radio::slwConvertToDynamicIndex_DABEnsembleList not implemented"));
   return 0;
}

/**
 * Method: slwConvertToDynamicIndex_DABSecServicesList
  * used for the highly dynamic list with multiparty calls
  * BPlus
 */
slword clHSA_Radio_Base::slwConvertToDynamicIndex_DABSecServicesList(ulword ulwUniqueId)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwUniqueId);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Radio::slwConvertToDynamicIndex_DABSecServicesList not implemented"));
   return 0;
}

/**
 * Method: slwConvertToUniqueId_DABEnsembleList
  * used for the highly dynamic list with multiparty calls
  * BPlus
 */
slword clHSA_Radio_Base::slwConvertToUniqueId_DABEnsembleList(ulword ulwDynamicIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDynamicIndex);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Radio::slwConvertToUniqueId_DABEnsembleList not implemented"));
   return 0;
}

/**
 * Method: slwConvertToUniqueId_DABSecServicesList
  * used for the highly dynamic list with multiparty calls
  * BPlus
 */
slword clHSA_Radio_Base::slwConvertToUniqueId_DABSecServicesList(ulword ulwDynamicIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDynamicIndex);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Radio::slwConvertToUniqueId_DABSecServicesList not implemented"));
   return 0;
}

/**
 * Method: vDeletePresetStation
  * Deletes a station selected by the user in one of the preset-banks.
  * B
 */
void clHSA_Radio_Base::vDeletePresetStation(ulword ulwEntryNr, ulword ulwBankNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBankNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vDeletePresetStation not implemented"));
   
}

/**
 * Method: vExitStationList
  * Called when living the station list.
  * B
 */
void clHSA_Radio_Base::vExitStationList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vExitStationList not implemented"));
   
}

/**
 * Method: vFixActiveStationListName
  * Saves the name of the active FM station (as shown in the station list) so that the station name string does not change during save. The station name is unfixed if the station is saved or the save mode is cancelled.
  * B
 */
void clHSA_Radio_Base::vFixActiveStationListName( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vFixActiveStationListName not implemented"));
   
}

/**
 * Method: vFixActiveStationName
  * Saves the name of the active FM station, so that the station name string does not change till the station is saved. The function is needed when the active station is saved by longpress on a preset. The station name is unfixed if the station is saved or a preset station is recalled.
  * B
 */
void clHSA_Radio_Base::vFixActiveStationName( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vFixActiveStationName not implemented"));
   
}

/**
 * Method: vFreezePS
  * Freezes the current station name, so that the name doesn't change anymore in the preset-banks and station list.
  * B
 */
void clHSA_Radio_Base::vFreezePS( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vFreezePS not implemented"));
   
}

/**
 * Method: ulwGetActiveEnsembleIndex
  * gets the index of the active ensemble in the DAB station list
  * B1Plus
 */
ulword clHSA_Radio_Base::ulwGetActiveEnsembleIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetActiveEnsembleIndex not implemented"));
   return 0;
}

/**
 * Method: ulwGetActiveEnsembleServiceIndex
  * gets the index of the active service in the DAB station list
  * B1Plus
 */
ulword clHSA_Radio_Base::ulwGetActiveEnsembleServiceIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetActiveEnsembleServiceIndex not implemented"));
   return 0;
}

/**
 * Method: ulwGetActiveFavouritesScreen
  * gets the index of the last active preset-bank
  * B
 */
ulword clHSA_Radio_Base::ulwGetActiveFavouritesScreen( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetActiveFavouritesScreen not implemented"));
   return 0;
}

/**
 * Method: ulwGetActiveSecondaryServiceIndex
  * gets the index of the active secondary service in the secondary service list.
  * B1Plus
 */
ulword clHSA_Radio_Base::ulwGetActiveSecondaryServiceIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetActiveSecondaryServiceIndex not implemented"));
   return 0;
}

/**
 * Method: vGetActiveSecondaryServiceName
  * Gets the name of the active secondary service.Used in the main screens.
  * APlus
 */
void clHSA_Radio_Base::vGetActiveSecondaryServiceName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetActiveSecondaryServiceName not implemented"));
   
}

/**
 * Method: vGetActiveStationBandString
  * Returns a formatted string including the band and the preset nr on which the active station is saved (e.g. FM: 2). If the preset nr is not available (station is not saved), only the the band of the active station will be returned (e.g. FM). Used in the main screens.
  * B1
 */
void clHSA_Radio_Base::vGetActiveStationBandString(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetActiveStationBandString not implemented"));
   
}

/**
 * Method: vGetActiveStationEnsembleName
  * Returns the Ensemble name of the active radio station.  Used in the main screens.
  * APlus
 */
void clHSA_Radio_Base::vGetActiveStationEnsembleName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetActiveStationEnsembleName not implemented"));
   
}

/**
 * Method: ulwGetActiveStationEnsembleState
  * Gets the status of the active ensemble. Used to show special states of the ensemble like '- - -' (during manual tuning), 'No ensemble' (if the tuned frequency contains no valid ensemble) or 'No audio' (if the tuned ensemble contains no audio services). In these 3 states the frequency label of the active ensemble is shown instead of the servicename. See 'Radio.GetActiveStationName'. Hint: If changing the frequency manually the ensemble name is replaced by a special text like '- - -'. This is done by setting the return value of this function to '1'. If the new frequency is checked the return value of this function must changed. Used in the main screens.
  * APlus
 */
ulword clHSA_Radio_Base::ulwGetActiveStationEnsembleState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetActiveStationEnsembleState not implemented"));
   return 0;
}

/**
 * Method: ulwGetActiveStationListIndex
  * Gets the index of the active station in the StationList 
  * B2
 */
ulword clHSA_Radio_Base::ulwGetActiveStationListIndex(ulword ulwListType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListType);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetActiveStationListIndex not implemented"));
   return 0;
}

/**
 * Method: vGetActiveStationName
  * Gets the name of the active station. If no name is available, send an empty string. FM: In manual tuning mode, send the frequency instead of the RDS name.FM: send the frequency, if the PS is not available. DAB: In 'manual tuning'; mode, send the frequency label of the current ensemble instead of the servicename. DAB: If no service name is available, show the frequency. In AM, always send the frequency. The frequency must be sent as a formatted string (See FMT_FREQUENCY in the GUICatalog).See statecharts on page: TUN_MAIN and TUN_MAIN_DAB.  
  * B1 [DAB service name: A plus ]
 */
void clHSA_Radio_Base::vGetActiveStationName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetActiveStationName not implemented"));
   
}

/**
 * Method: vGetActiveStationNameShort
  * Used to show the name of the radio station in the navigation map. FM/AM: Returns the name of the active station. If no name is available return the frequency as formatted string. DAB: Return the name of the active service with maximal 8 characters. If no service is tuned return the avctive frequency (e.g. '12 D'). 
  * B1
 */
void clHSA_Radio_Base::vGetActiveStationNameShort(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetActiveStationNameShort not implemented"));
   
}

/**
 * Method: slwGetActiveStationPresetNr
  * Gets the preset nr, on which the active station is saved. If the station is not saved, the function returns -1 (Autocompare)
  * B
 */
slword clHSA_Radio_Base::slwGetActiveStationPresetNr(ulword ulwActiveSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwActiveSource);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Radio::slwGetActiveStationPresetNr not implemented"));
   return 0;
}

/**
 * Method: vGetActiveStationPS
  * Returns the program service name 'PS' of the active station for FM and returns the service label in case of DAB. If no PS/service label is available, returns an empty string.
  * t.b.d.
 */
void clHSA_Radio_Base::vGetActiveStationPS(GUI_String *out_result, ulword ulwActiveSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwActiveSource);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetActiveStationPS not implemented"));
   
}

/**
 * Method: ulwGetCurrentBand
  * Gets the index of the active band
  * B1
 */
ulword clHSA_Radio_Base::ulwGetCurrentBand( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetCurrentBand not implemented"));
   return 0;
}

/**
 * Method: vSetTunerVisibality
  * Gives infomation about Tuner compoenet being visible
  * B1
 */
void clHSA_Radio_Base::vSetTunerVisibality(tbool blVisibality, ulword ulwSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blVisibality);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSource);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vSetTunerVisibality not implemented"));
   
}

/**
 * Method: vGetCurrentTAStationName
  * Gets the name of the current TA Station
  * B
 */
void clHSA_Radio_Base::vGetCurrentTAStationName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetCurrentTAStationName not implemented"));
   
}

/**
 * Method: blGetDAB_LBandState
  * Returns true, if the if the DAB frequency band 'L-Band' is activated. Used in setup menu.
  * B1Plus
 */
tbool clHSA_Radio_Base::blGetDAB_LBandState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blGetDAB_LBandState not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABEnsembleList_Count
  * Returns the count of ensembles found on the DAB band.
  * B1Plus
 */
ulword clHSA_Radio_Base::ulwGetDABEnsembleList_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetDABEnsembleList_Count not implemented"));
   return 0;
}

/**
 * Method: vGetDABEnsembleListItem_Name
  * Gets the name of the ensemble which should be shown in the combined ensemble/service list, at the position given as parameter. The list contains on the first level the ensembles and on the second level the services. If no ensemble name is available return the frequency as string.
  * B1Plus
 */
void clHSA_Radio_Base::vGetDABEnsembleListItem_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetDABEnsembleListItem_Name not implemented"));
   
}

/**
 * Method: ulwGetDABEnsembleListItem_State
  * Gets the status of the ensemble at the position given as parameter. Used to show special states of the ensemble like 'not available', 'no ensemble' or 'no audio'.
  * B1Plus
 */
ulword clHSA_Radio_Base::ulwGetDABEnsembleListItem_State(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetDABEnsembleListItem_State not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABEnsembleServiceList_Count
  * Returns the count of the services found for the selected ensemble.
  * B1Plus
 */
ulword clHSA_Radio_Base::ulwGetDABEnsembleServiceList_Count(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetDABEnsembleServiceList_Count not implemented"));
   return 0;
}

/**
 * Method: vGetDABEnsembleServiceListItem_Name
  * Gets the name of the station which should be shown in the DAB - StationList, at the position given as parameter.
  * B1Plus
 */
void clHSA_Radio_Base::vGetDABEnsembleServiceListItem_Name(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwSubListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSubListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetDABEnsembleServiceListItem_Name not implemented"));
   
}

/**
 * Method: ulwGetDABEnsembleServiceListItem_State
  * Gets the status of the service at the position given as parameter. Used to show different icons if secondary services available, if the service is not available or if the service is currently linked to a FM station.
  * B1Plus
 */
ulword clHSA_Radio_Base::ulwGetDABEnsembleServiceListItem_State(ulword ulwListEntryNr, ulword ulwSubListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSubListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetDABEnsembleServiceListItem_State not implemented"));
   return 0;
}

/**
 * Method: vGetDABEnsembleServiceListItem_TP
  * Gets the TPState-string  of the service at the position given as parameter. Used to show the "TP" status for each service from the DAB EnsembleList.
  * B1Plus
 */
void clHSA_Radio_Base::vGetDABEnsembleServiceListItem_TP(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwSubListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSubListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetDABEnsembleServiceListItem_TP not implemented"));
   
}

/**
 * Method: blGetDABOtherAnnouncementState
  * Returns true, if an announcement of other type than Traffic,  is active. Used in setup menu.
  * B2Plus
 */
tbool clHSA_Radio_Base::blGetDABOtherAnnouncementState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blGetDABOtherAnnouncementState not implemented"));
   return 0;
}

/**
 * Method: vGetDABRadioText
  * get DAB radio text
  * B2Plus [for the B1Plus sample: always return 1]
 */
void clHSA_Radio_Base::vGetDABRadioText(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetDABRadioText not implemented"));
   
}

/**
 * Method: ulwGetDABRadioTextState
  * Gets the state of the DabRadioText-loading process.
  * B2Plus [for the B1Plus sample: always return 1]
 */
ulword clHSA_Radio_Base::ulwGetDABRadioTextState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetDABRadioTextState not implemented"));
   return 0;
}

/**
 * Method: blGetDABServiceFollowingState
  * Returns the state of Service Following (switching from a DAB service to an equivalent DAB service if the quality of the current DAB station becomes too bad).  Used in setup menu.
  * B2Plus
 */
tbool clHSA_Radio_Base::blGetDABServiceFollowingState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blGetDABServiceFollowingState not implemented"));
   return 0;
}

/**
 * Method: blGetDABServiceLinkingState
  * Returns the state of Service Linking (switching from a DAB service to an equivalent FM station if the quality of the current DAB station becomes too bad).  Used in setup menu.
  * B2Plus
 */
tbool clHSA_Radio_Base::blGetDABServiceLinkingState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blGetDABServiceLinkingState not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABServiceState
  * Returns the state of the active DAB service. The states are: none (no status information shown), service not available/muted, additional service available (secondary service component), additional service active, service linking active. Hint: Change the state to 'service not available/muted' if the service is not available for 2 seconds.
  * B1Plus
 */
ulword clHSA_Radio_Base::ulwGetDABServiceState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetDABServiceState not implemented"));
   return 0;
}

/**
 * Method: ulwGetDABStationListUpdateState
  * returns true, if the DAB ensemble/service list is being updated.
  * B1Plus
 */
ulword clHSA_Radio_Base::ulwGetDABStationListUpdateState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetDABStationListUpdateState not implemented"));
   return 0;
}

/**
 * Method: ulwGetFirstEmptyPreset
  * Gets the index of the first empty preset . 
  * B
 */
ulword clHSA_Radio_Base::ulwGetFirstEmptyPreset( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetFirstEmptyPreset not implemented"));
   return 0;
}

/**
 * Method: vGetRadioText
  * get radio text/DLS based on the active source
  * B2 [for the  B1 sample: returns a static value]
 */
void clHSA_Radio_Base::vGetRadioText(GUI_String *out_result, ulword ulwActiveSource)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwActiveSource);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetRadioText not implemented"));
   
}

/**
 * Method: ulwGetFMRadioTextState
  * returns the state of the Radio text (loading/available)for FM
  * B2 [for the B1 sample: always return 1] 
 */
ulword clHSA_Radio_Base::ulwGetFMRadioTextState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetFMRadioTextState not implemented"));
   return 0;
}

/**
 * Method: vGetStationNameList
  * Gets the name of the station which should be shown in the FM StationList/ DAB Service List/ DAB Component List/ AM Station List, at the position given as parameter.
  * B2
 */
void clHSA_Radio_Base::vGetStationNameList(GUI_String *out_result, ulword ulwListType, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetStationNameList not implemented"));
   
}

/**
 * Method: vGetStationPresetNrList
  * Gets the Preset number which should be shown on the FM_StationList or DAB service List or AM Station list at the position given as parameter.
  * B
 */
void clHSA_Radio_Base::vGetStationPresetNrList(GUI_String *out_result, ulword ulwListType, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetStationPresetNrList not implemented"));
   
}

/**
 * Method: vGetFMStationRegList
  * Gets the RegState-string for the  FM_StationList-item with the index given as parameter.
  * B
 */
void clHSA_Radio_Base::vGetFMStationRegList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetFMStationRegList not implemented"));
   
}

/**
 * Method: vGetFMStationTPList
  * Gets the TPState-string of the FMStationList-item with the index given as parameter
  * B
 */
void clHSA_Radio_Base::vGetFMStationTPList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetFMStationTPList not implemented"));
   
}

/**
 * Method: vGetStationFreqList
  * Gets the frequency of the StationList-item with the index given as parameter
  * B
 */
void clHSA_Radio_Base::vGetStationFreqList(GUI_String *out_result, ulword ulwListType, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetStationFreqList not implemented"));
   
}

/**
 * Method: vGetPresetButtonText
  * Returns the text which should be displayed on the preset-buttons.
  * B1
 */
void clHSA_Radio_Base::vGetPresetButtonText(GUI_String *out_result, ulword ulwIndex, ulword ulwBank)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBank);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetPresetButtonText not implemented"));
   
}

/**
 * Method: slwGetPresetStationBand
  * Returns an integer corresponding to the band of the station saved at a given preset nr. 
  * B
 */
slword clHSA_Radio_Base::slwGetPresetStationBand(ulword ulwEntryNr, ulword ulwBankNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBankNr);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_Radio::slwGetPresetStationBand not implemented"));
   return 0;
}

/**
 * Method: vGetPresetStationBandString
  * Returns a formatted string including the band and the preset nr of the current preset (e.g. FM: 2). Used in the main screens.
  * B [for the B1 sample: return an empty string] 
 */
void clHSA_Radio_Base::vGetPresetStationBandString(GUI_String *out_result, ulword ulwEntryNr, ulword ulwBankNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBankNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetPresetStationBandString not implemented"));
   
}

/**
 * Method: vGetPresetStationEnsembleName
  * gets the ensemble name of a station in the presetlist, if the band of the station is DAB
  * B1Plus
 */
void clHSA_Radio_Base::vGetPresetStationEnsembleName(GUI_String *out_result, ulword ulwEntryNr, ulword ulwBankNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBankNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetPresetStationEnsembleName not implemented"));
   
}

/**
 * Method: vGetPresetStationName
  * gets the name of the station saved on the selected preset.
  * B [for the B1 sample: return an empty string] 
 */
void clHSA_Radio_Base::vGetPresetStationName(GUI_String *out_result, ulword ulwEntryNr, ulword ulwBankNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBankNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetPresetStationName not implemented"));
   
}

/**
 * Method: blGetRadioTextModeState
  * gets the state of the radiotext-mode
  * B
 */
tbool clHSA_Radio_Base::blGetRadioTextModeState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blGetRadioTextModeState not implemented"));
   return 0;
}

/**
 * Method: vGetReceivedDABAnnouncementProgName
  * Returns the program-name of the station that sent the DAB announcement event
  * B1Plus
 */
void clHSA_Radio_Base::vGetReceivedDABAnnouncementProgName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetReceivedDABAnnouncementProgName not implemented"));
   
}

/**
 * Method: ulwGetReceivedDABAnnouncementType
  * Returns a number corresponding to the announcement type of a received DAB announcement.
  * B1Plus
 */
ulword clHSA_Radio_Base::ulwGetReceivedDABAnnouncementType( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetReceivedDABAnnouncementType not implemented"));
   return 0;
}

/**
 * Method: ulwGetRegState
  * Returns the value of the Regionalization option( Auto/ Fix)
  * B
 */
ulword clHSA_Radio_Base::ulwGetRegState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetRegState not implemented"));
   return 0;
}

/**
 * Method: ulwGetSecondaryServiceList_Count
  * gets the count of secondary audio service (subchannels) of the current selected DAB-station
  * B1Plus
 */
ulword clHSA_Radio_Base::ulwGetSecondaryServiceList_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetSecondaryServiceList_Count not implemented"));
   return 0;
}

/**
 * Method: vGetSecondaryServiceListItem_Name
  * Returns the name of the secondary audio service (subchannel) which should be shown at the index given as parameter.
  * B1Plus
 */
void clHSA_Radio_Base::vGetSecondaryServiceListItem_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetSecondaryServiceListItem_Name not implemented"));
   
}

/**
 * Method: ulwGetSecondaryServiceListItem_State
  * Returns the state of the secondary audio service (subchannel) which should be shown at the index given as parameter.
  * B1Plus
 */
ulword clHSA_Radio_Base::ulwGetSecondaryServiceListItem_State(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetSecondaryServiceListItem_State not implemented"));
   return 0;
}

/**
 * Method: ulwGetSeekMode
  * Returns the seek mode selected in the radio setup menu. The seek mode can be "Stationlis" or "Memorylist". The selected list determines the function of the next/previous buttons and hardkeys.
  * B2 [for the B1 sample: always return 0 (StationList)] 
 */
ulword clHSA_Radio_Base::ulwGetSeekMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetSeekMode not implemented"));
   return 0;
}

/**
 * Method: blGetSelectionMode
  * gets the active selection mode (presets/ selection)
  * B
 */
tbool clHSA_Radio_Base::blGetSelectionMode( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blGetSelectionMode not implemented"));
   return 0;
}

/**
 * Method: ulwGetStationInfoFM_Count
  * Returns the count of stations found on the FM band
  * B2
 */
ulword clHSA_Radio_Base::ulwGetStationInfoFM_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetStationInfoFM_Count not implemented"));
   return 0;
}

/**
 * Method: ulwGetTPSeekState
  * returns0 if TP seek is active, 1 if tTP seek is finished. Used for closing the TPSeek PopUp (trigger in the WaitScreenMediator).
  * B
 */
ulword clHSA_Radio_Base::ulwGetTPSeekState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetTPSeekState not implemented"));
   return 0;
}

/**
 * Method: ulwGetTPState
  * Returns the current TP state. Needed for the TPWidget.
  * B [for the B1 sample, always return true] 
 */
ulword clHSA_Radio_Base::ulwGetTPState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetTPState not implemented"));
   return 0;
}

/**
 * Method: blIsDABAvailable
  * Returns if a DAB tuner is available or not.
  * B1
 */
tbool clHSA_Radio_Base::blIsDABAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsDABAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsDABOtherAnnouncementPlaying
  * returns true if a DAB Announcement (not traffic announcement) is playing
  * B1Plus
 */
tbool clHSA_Radio_Base::blIsDABOtherAnnouncementPlaying( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsDABOtherAnnouncementPlaying not implemented"));
   return 0;
}

/**
 * Method: blIsDABServiceReadyToBeStored
  * Returns true if all the infomation needed for the saving of the service are available.
  * B1Plus
 */
tbool clHSA_Radio_Base::blIsDABServiceReadyToBeStored( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsDABServiceReadyToBeStored not implemented"));
   return 0;
}

/**
 * Method: blIsDABServiceSeekActive
  * Returns true if activating the next or prev. DAB service takes longer than 2 seconds. This call is used to show a special text like 'Searching...' instead of the service name. The return value 'true' must not be changed for 2 seconds to avoid flickering.
  * B1Plus
 */
tbool clHSA_Radio_Base::blIsDABServiceSeekActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsDABServiceSeekActive not implemented"));
   return 0;
}

/**
 * Method: blIsDABTrafficAnnouncementPlaying
  * returns true if a DAB TrafficAnnouncement is playing
  * B1Plus
 */
tbool clHSA_Radio_Base::blIsDABTrafficAnnouncementPlaying( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsDABTrafficAnnouncementPlaying not implemented"));
   return 0;
}

/**
 * Method: blIsManualModeActive
  * Returns the state of the manual mode: active or not active
  * B1
 */
tbool clHSA_Radio_Base::blIsManualModeActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsManualModeActive not implemented"));
   return 0;
}

/**
 * Method: blIsPSNameAvailable
  * returns true, if the name of the active station is available (the FreezePS function can be used only if this APICall returns true)
  * B
 */
tbool clHSA_Radio_Base::blIsPSNameAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsPSNameAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsScanActive
  * returns the state of the scan function (active or not active). If the scan function is stopped by the tuner, this APICall returns true.
  * B2 [planned for the B sample but agreed with Mr. Feldbauer to be implemented for B1]
 */
tbool clHSA_Radio_Base::blIsScanActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsScanActive not implemented"));
   return 0;
}

/**
 * Method: blIsSeekActive
  * Returns the state of the seek mode: active or not active (started or not started)
  * B1
 */
tbool clHSA_Radio_Base::blIsSeekActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsSeekActive not implemented"));
   return 0;
}

/**
 * Method: blIsTAMessagePlaying
  * returnstrue if a TP Message is playing, false otherwise
  * B
 */
tbool clHSA_Radio_Base::blIsTAMessagePlaying( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsTAMessagePlaying not implemented"));
   return 0;
}

/**
 * Method: blIsTPActivated
  * get the tp state (active/ inactive);  the APICall is used for the TP-option in the Radio and Media setup menu, and also for the TP-option in the PushUp menu "Mode", in the Radio context
  * B [for the B1 sample, always return true]
 */
tbool clHSA_Radio_Base::blIsTPActivated( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsTPActivated not implemented"));
   return 0;
}

/**
 * Method: blIsTPSeekActive
  * returns true if TP seek is active. Used to show the TPSeek Popup when the user returns to the radio context.
  * B
 */
tbool clHSA_Radio_Base::blIsTPSeekActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsTPSeekActive not implemented"));
   return 0;
}

/**
 * Method: vLoadList
  * To be called when FM Station List, AM Station List or DAB Service List or DAB Sec service list has to be loaded. 
  * B2
 */
void clHSA_Radio_Base::vLoadList(ulword ulwListType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vLoadList not implemented"));
   
}

/**
 * Method: ulwScanStart
  * starts scanning the current band until a valid station is found; once a station is found, the scan continues after a short wating time; scanning can be stopped by calling the ScanStop (press on the arrow-keys)
  * B2 [planned for the B sample but agreed with Mr. Feldbauer to be implemented for B1] [DAB: B2 plus]
 */
ulword clHSA_Radio_Base::ulwScanStart( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwScanStart not implemented"));
   return 0;
}

/**
 * Method: vScanStop
  * Stops the scan function. The tuner remains on the active station. 
  * B2 [planned for the B sample but agreed with Mr. Feldbauer to be implemented for B1] [DAB: B2 plus]
 */
void clHSA_Radio_Base::vScanStop( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vScanStop not implemented"));
   
}

/**
 * Method: ulwSeekStart
  * Starts seeking a next/ previous station on the current frequency band, until a valid station is found or the whole band was scanned. For FM and DAB, this APICall is valid only if the manual mode is active.See TU_022
  * B1
 */
ulword clHSA_Radio_Base::ulwSeekStart(ulword ulwDirection)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDirection);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwSeekStart not implemented"));
   return 0;
}

/**
 * Method: vSeekStop
  * Stops the seek mode, even if a valid station is found on the current freqency.
  * B1
 */
void clHSA_Radio_Base::vSeekStop( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vSeekStop not implemented"));
   
}

/**
 * Method: vSetActiveFavouritesScreen
  * sets the index of the last active preset-bank
  * B
 */
void clHSA_Radio_Base::vSetActiveFavouritesScreen(ulword ulwBankNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBankNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vSetActiveFavouritesScreen not implemented"));
   
}

/**
 * Method: vSetDABOtherAnnouncementOff
  * Deactivates the setup option 'DAB other announcements'. It will be used only in the announcement popup by pressing the button 'Deactivate'.
  * B1Plus
 */
void clHSA_Radio_Base::vSetDABOtherAnnouncementOff( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vSetDABOtherAnnouncementOff not implemented"));
   
}

/**
 * Method: vSetDABTrafficAnnouncementOff
  * Deactivates the setup option 'DAB Traffic announcements'. It will be used only in the announcement popup by pressing the button 'Deactivate'.
  * B1Plus
 */
void clHSA_Radio_Base::vSetDABTrafficAnnouncementOff( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vSetDABTrafficAnnouncementOff not implemented"));
   
}

/**
 * Method: vSetManualMode
  * Activates/ deactivates the manual mode. If manual mode is active, a press on the Next/Prev. buttons starts a seek on the frequency band. Holding the arrow buttons pressed, starts a target seek; See also IsManualModeActive. When the manual mode is active, the frequency will be shown on the screen  instead of the StationName.
  * B1 [DAB: A plus]
 */
void clHSA_Radio_Base::vSetManualMode(tbool blValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vSetManualMode not implemented"));
   
}

/**
 * Method: vSetRadioTextModeState
  * sets the state of the radiotext-mode
  * B
 */
void clHSA_Radio_Base::vSetRadioTextModeState(tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vSetRadioTextModeState not implemented"));
   
}

/**
 * Method: vSetRegState
  * Sets the value of the setup-option "Regionalization" (Auto/ Fix)
  * B
 */
void clHSA_Radio_Base::vSetRegState(ulword ulwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vSetRegState not implemented"));
   
}

/**
 * Method: vSetSeekMode
  * Changes the state of the seek mode in the radio setup. 0=Stationlist, 1=Memorylist.
  * B2
 */
void clHSA_Radio_Base::vSetSeekMode(ulword ulwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vSetSeekMode not implemented"));
   
}

/**
 * Method: vSetSelectionMode
  * sets the active selection mode (presets/ station)
  * B
 */
void clHSA_Radio_Base::vSetSelectionMode(tbool blMode)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blMode);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vSetSelectionMode not implemented"));
   
}

/**
 * Method: vSetTPState
  * Modifies the TP state. It will be used only to deactivate TP by pressing the button 'Deactivate TP' in the PopUp TUNER_PO_TA. This ApiCall will always be used with the parameter 'False'.
  * B
 */
void clHSA_Radio_Base::vSetTPState(tbool blValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vSetTPState not implemented"));
   
}

/**
 * Method: vStopCurrentDABAnnouncement
  * stops the playing of the current DAB Announcement
  * B1Plus
 */
void clHSA_Radio_Base::vStopCurrentDABAnnouncement( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vStopCurrentDABAnnouncement not implemented"));
   
}

/**
 * Method: vStopCurrentTAMessage
  * stops the current TA
  * B [planned for the B sample but agreed with Mr. Feldbauer to be implemented for B1]
 */
void clHSA_Radio_Base::vStopCurrentTAMessage( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vStopCurrentTAMessage not implemented"));
   
}

/**
 * Method: vStopInitialAutostore
  * stops the autostore - used for the SK_LEFT='Cancel' in the PopUp menu which appears after starting the InitialAutoStore.
  * B
 */
void clHSA_Radio_Base::vStopInitialAutostore( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vStopInitialAutostore not implemented"));
   
}

/**
 * Method: vStopTPSeek
  * stops the TP seek
  * B
 */
void clHSA_Radio_Base::vStopTPSeek( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vStopTPSeek not implemented"));
   
}

/**
 * Method: vStoreCurrentStationPreset
  * stores the active station on the selected preset
  * B
 */
void clHSA_Radio_Base::vStoreCurrentStationPreset(ulword ulwEntryNr, ulword ulwBankNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwBankNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vStoreCurrentStationPreset not implemented"));
   
}

/**
 * Method: vTargetSeekStart
  * starts tuning up/down through the current band until TargetSeekStop is called. During the tuning, the new frequency is repeatedly sent to the HMI. When the Targetseek is stopped, the tuner seeks the next available station, starting from the current frequency. See TU_022
  * B1
 */
void clHSA_Radio_Base::vTargetSeekStart(ulword ulwDirection)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwDirection);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vTargetSeekStart not implemented"));
   
}

/**
 * Method: vTargetSeekStop
  * stops tuning through the current band. When the Targetseek is stopped, the tuner seeks the next available station, starting from the current frequency.
  * B1
 */
void clHSA_Radio_Base::vTargetSeekStop( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vTargetSeekStop not implemented"));
   
}

/**
 * Method: vToggleDAB_LBandState
  * Toggles the state of the DAB frequency band 'L-Band'. Used in setup menu.
  * B2Plus
 */
void clHSA_Radio_Base::vToggleDAB_LBandState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vToggleDAB_LBandState not implemented"));
   
}

/**
 * Method: vToggleDABOtherAnnouncementState
  * Toggles the global state of the DAB announcements
  * B2Plus
 */
void clHSA_Radio_Base::vToggleDABOtherAnnouncementState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vToggleDABOtherAnnouncementState not implemented"));
   
}

/**
 * Method: vToggleDABServiceFollowingState
  * Toggles the state of Service Following (switching between two DAB services)
  * B2Plus
 */
void clHSA_Radio_Base::vToggleDABServiceFollowingState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vToggleDABServiceFollowingState not implemented"));
   
}

/**
 * Method: vToggleDABServiceLinkingState
  * Toggles the state of Service Following (switching between FM and DAB if the reception's quality is decreasing for the active station)
  * B2Plus
 */
void clHSA_Radio_Base::vToggleDABServiceLinkingState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vToggleDABServiceLinkingState not implemented"));
   
}

/**
 * Method: vToggleDABServiceState
  * Dependend on the actual state of the DAB service switch to the secondary service, switch to the next secondary service or switch back to the primary service if the last secondary service was active. 
  * B1Plus
 */
void clHSA_Radio_Base::vToggleDABServiceState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vToggleDABServiceState not implemented"));
   
}

/**
 * Method: vToggleTPState
  * Toggles the TP (Traffic program) state. Used for the TP-option  in radio and media setup, and in the PushUp menu  in radio context.
  * B [planned for the B2 sample but agreed with Mr. Feldhofer to be implemented for B1]
 */
void clHSA_Radio_Base::vToggleTPState( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vToggleTPState not implemented"));
   
}

/**
 * Method: vUnfixActiveStationName
  * Unfix the station name if the save process is cancelled. Only for FM stations.
  * B
 */
void clHSA_Radio_Base::vUnfixActiveStationName( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vUnfixActiveStationName not implemented"));
   
}

/**
 * Method: vUpdateDABStationList
  * Called to update the ensemble list.
  * B1Plus
 */
void clHSA_Radio_Base::vUpdateDABStationList( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vUpdateDABStationList not implemented"));
   
}

/**
 * Method: vToggleHDsetting
  * Toggles the HD setting from Off to On and On to Off for the active band
  * ITG5
 */
void clHSA_Radio_Base::vToggleHDsetting( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vToggleHDsetting not implemented"));
   
}

/**
 * Method: blGetHDSetting
  * Gets the Current HD setting for the active band
  * ITG5
 */
tbool clHSA_Radio_Base::blGetHDSetting( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blGetHDSetting not implemented"));
   return 0;
}

/**
 * Method: blIsPresetHDStation
  *  Returns if the preset is stored with HD station or not. 
  * ITG5
 */
tbool clHSA_Radio_Base::blIsPresetHDStation(ulword ulwPresetID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwPresetID);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsPresetHDStation not implemented"));
   return 0;
}

/**
 * Method: blGetListUpdateStatus
  * Gets the status of update Station list. Returns TRUE if update is running
  * ITG5
 */
tbool clHSA_Radio_Base::blGetListUpdateStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blGetListUpdateStatus not implemented"));
   return 0;
}

/**
 * Method: vUpdateList
  * Triggers update for station lists
  * ITG5
 */
void clHSA_Radio_Base::vUpdateList(ulword ulwListID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListID);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vUpdateList not implemented"));
   
}

/**
 * Method: ulwGetStationHDPrgNoList
  * Gets the HD Audio Program ID of the station which should be shown in the FM StationList/ AM Station List, at the position given as parameter.
  * ITG5
 */
ulword clHSA_Radio_Base::ulwGetStationHDPrgNoList(ulword ulwListType, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListType);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetStationHDPrgNoList not implemented"));
   return 0;
}

/**
 * Method: vCancelListUpdate
  * Cancels the Station List update
  * ITG5
 */
void clHSA_Radio_Base::vCancelListUpdate( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vCancelListUpdate not implemented"));
   
}

/**
 * Method: blIsActiveStationHD
  * Indicates weather active Audio program is a HD audio program or not 
  * ITG5
 */
tbool clHSA_Radio_Base::blIsActiveStationHD( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsActiveStationHD not implemented"));
   return 0;
}

/**
 * Method: vGetAvailableHDAudPrgmIDs
  * Returns the formatted string with all the available HD Audio Program IDs.
  * ITG5
 */
void clHSA_Radio_Base::vGetAvailableHDAudPrgmIDs(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetAvailableHDAudPrgmIDs not implemented"));
   
}

/**
 * Method: blIsDigitalAudAvailable
  * Indicates weather Digital audio for selected station is available or not
  * ITG5
 */
tbool clHSA_Radio_Base::blIsDigitalAudAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Radio::blIsDigitalAudAvailable not implemented"));
   return 0;
}

/**
 * Method: vGetTitlePSD
  * Returns the Title name if available
  * ITG5
 */
void clHSA_Radio_Base::vGetTitlePSD(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetTitlePSD not implemented"));
   
}

/**
 * Method: vGetArtistPSD
  * Returns the Artist name if available
  * ITG5
 */
void clHSA_Radio_Base::vGetArtistPSD(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetArtistPSD not implemented"));
   
}

/**
 * Method: vGetAlbumPSD
  * Returns the Album name if available
  * ITG5
 */
void clHSA_Radio_Base::vGetAlbumPSD(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Radio::vGetAlbumPSD not implemented"));
   
}

/**
 * Method: vSelectHDAudPrgm
  * To select next HD Audio Program MPS=> SPS1 => SPS2...=>MPS
  * ITG5
 */
void clHSA_Radio_Base::vSelectHDAudPrgm( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Radio::vSelectHDAudPrgm not implemented"));
   
}

/**
 * Method: ulwGetAMStationListCount
  * To get the length of AM station list
  * ITG5
 */
ulword clHSA_Radio_Base::ulwGetAMStationListCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Radio::ulwGetAMStationListCount not implemented"));
   return 0;
}

