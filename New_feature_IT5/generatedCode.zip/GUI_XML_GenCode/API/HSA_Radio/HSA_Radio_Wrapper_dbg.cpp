/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Radio_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_Radio_Wrapper_dbg.h"
#include "clHSA_Radio_Base.h"
#include "HSA_Radio_Trace.h"
#include "HSA_Radio_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_Radio_Wrapper_dbg::~clHSA_Radio_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_Radio_Wrapper_dbg::clHSA_Radio_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_Radio_Wrapper_dbg::clHSA_Radio_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_Radio_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_Radio_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__IS_DAB_LIST_UPDATE_ACTIVE:

            HSA_Radio__blIsDABListUpdateActive();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_NEXT_SEC_COMPONENT:

            HSA_Radio__vActivateNextSecComponent();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_PREVIOUS_SEC_COMPONENT:

            HSA_Radio__vActivatePreviousSecComponent();
            break;

        case HSA_API_ENTRYPOINT__SET_DAB_SEC_AUDIO_OFF:

            HSA_Radio__vSetDABSecAudioOff();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_COMPONENT_MODE:

            HSA_Radio__blGetDABComponentMode();
            break;

        case HSA_API_ENTRYPOINT__UPDATE_DAB_SRV_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Radio__vUpdateDABSrvList(usParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_FM_SF__STATUS:

            HSA_Radio__blGetDAB_FM_SF_Status();
            break;

        case HSA_API_ENTRYPOINT__CLOSE_DAB_LIST:

            HSA_Radio__vCloseDABList();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SRV_AVAILABILITY:

            HSA_Radio__ulwGetDABSrvAvailability();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_RECEPTION_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vGetDABReceptionList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SRV_LIST_LENGTH:

            HSA_Radio__ulwGetDABSrvListLength();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_COMP_LIST_LENGTH:

            HSA_Radio__ulwGetDABCompListLength();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_NUM_SEC_COMPONENTS:

            HSA_Radio__ulwGetDABNumSecComponents();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_FREQUENCY_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetCurrentFrequencyString(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_FREQUENCY_UNIT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetCurrentFrequencyUnit(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_NEXT_PRESET_STATION:

            HSA_Radio__vActivateNextPresetStation();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_PREV_PRESET_STATION:

            HSA_Radio__vActivatePrevPresetStation();
            break;

        case HSA_API_ENTRYPOINT__GET_STEREO_STATUS:

            HSA_Radio__blGetStereoStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_STATION_LIST_LOADING_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__ulwGetStationListLoadingState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_BANK:

            HSA_Radio__ulwGetCurrentBank();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_FREQUENCY:

            HSA_Radio__ulwGetCurrentFrequency();
            break;

        case HSA_API_ENTRYPOINT__SWITCH_AUTO_COMPARE_BANK:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__vSwitchAutoCompareBank(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__INCREASE_TUNER_FREQUENCY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__vIncreaseTunerFrequency(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DECREASE_TUNER_FREQUENCY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__vDecreaseTunerFrequency(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_TUNER_FREQUENCY_DIRECT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__vSetTunerFrequencyDirect(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_BAND:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__vActivateBand(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_DAB_SERVICE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vActivateDABService(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_INITIAL_AUTO_STORE:

            HSA_Radio__vActivateInitialAutoStore();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_NEXT_ENSEMBLE:

            HSA_Radio__vActivateNextEnsemble();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_NEXT_LIST_STATION:

            HSA_Radio__vActivateNextListStation();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_NEXT_STATION:

            HSA_Radio__vActivateNextStation();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_PREVIOUS_ENSEMBLE:

            HSA_Radio__vActivatePreviousEnsemble();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_PREVIOUS_LIST_STATION:

            HSA_Radio__vActivatePreviousListStation();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_PREVIOUS_STATION:

            HSA_Radio__vActivatePreviousStation();
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_SECONDARY_SERVICE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__vActivateSecondaryService(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_STATION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vActivateStation(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_STATION_PRESET:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vActivateStationPreset(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__CANCEL_UPDATE_DAB_STATION_LIST:

            HSA_Radio__vCancelUpdateDABStationList();
            break;

        case HSA_API_ENTRYPOINT__CLEAR_PRESET_LIST:

            HSA_Radio__vClearPresetList();
            break;

        case HSA_API_ENTRYPOINT__CONVERT_TO_DYNAMIC_INDEX_DAB_ENSEMBLE_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__slwConvertToDynamicIndex_DABEnsembleList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__CONVERT_TO_DYNAMIC_INDEX_DAB_SEC_SERVICES_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__slwConvertToDynamicIndex_DABSecServicesList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__CONVERT_TO_UNIQUE_ID_DAB_ENSEMBLE_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__slwConvertToUniqueId_DABEnsembleList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__CONVERT_TO_UNIQUE_ID_DAB_SEC_SERVICES_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__slwConvertToUniqueId_DABSecServicesList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DELETE_PRESET_STATION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vDeletePresetStation(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__EXIT_STATION_LIST:

            HSA_Radio__vExitStationList();
            break;

        case HSA_API_ENTRYPOINT__FIX_ACTIVE_STATION_LIST_NAME:

            HSA_Radio__vFixActiveStationListName();
            break;

        case HSA_API_ENTRYPOINT__FIX_ACTIVE_STATION_NAME:

            HSA_Radio__vFixActiveStationName();
            break;

        case HSA_API_ENTRYPOINT__FREEZE_PS:

            HSA_Radio__vFreezePS();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_ENSEMBLE_INDEX:

            HSA_Radio__ulwGetActiveEnsembleIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_ENSEMBLE_SERVICE_INDEX:

            HSA_Radio__ulwGetActiveEnsembleServiceIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_FAVOURITES_SCREEN:

            HSA_Radio__ulwGetActiveFavouritesScreen();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_SECONDARY_SERVICE_INDEX:

            HSA_Radio__ulwGetActiveSecondaryServiceIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_SECONDARY_SERVICE_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetActiveSecondaryServiceName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_BAND_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetActiveStationBandString(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_ENSEMBLE_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetActiveStationEnsembleName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_ENSEMBLE_STATE:

            HSA_Radio__ulwGetActiveStationEnsembleState();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_LIST_INDEX:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__ulwGetActiveStationListIndex(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetActiveStationName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_NAME_SHORT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetActiveStationNameShort(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_PRESET_NR:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__slwGetActiveStationPresetNr(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_STATION_PS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vGetActiveStationPS(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_BAND:

            HSA_Radio__ulwGetCurrentBand();
            break;

        case HSA_API_ENTRYPOINT__SET_TUNER_VISIBALITY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vSetTunerVisibality(usParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_TA_STATION_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetCurrentTAStationName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_L_BAND_STATE:

            HSA_Radio__blGetDAB_LBandState();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_LIST__COUNT:

            HSA_Radio__ulwGetDABEnsembleList_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_LIST_ITEM__NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vGetDABEnsembleListItem_Name(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_LIST_ITEM__STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__ulwGetDABEnsembleListItem_State(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST__COUNT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__ulwGetDABEnsembleServiceList_Count(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST_ITEM__NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Radio__vGetDABEnsembleServiceListItem_Name(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST_ITEM__STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__ulwGetDABEnsembleServiceListItem_State(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_ENSEMBLE_SERVICE_LIST_ITEM_TP:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Radio__vGetDABEnsembleServiceListItem_TP(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_OTHER_ANNOUNCEMENT_STATE:

            HSA_Radio__blGetDABOtherAnnouncementState();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_RADIO_TEXT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetDABRadioText(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_RADIO_TEXT_STATE:

            HSA_Radio__ulwGetDABRadioTextState();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SERVICE_FOLLOWING_STATE:

            HSA_Radio__blGetDABServiceFollowingState();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SERVICE_LINKING_STATE:

            HSA_Radio__blGetDABServiceLinkingState();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_SERVICE_STATE:

            HSA_Radio__ulwGetDABServiceState();
            break;

        case HSA_API_ENTRYPOINT__GET_DAB_STATION_LIST_UPDATE_STATE:

            HSA_Radio__ulwGetDABStationListUpdateState();
            break;

        case HSA_API_ENTRYPOINT__GET_FIRST_EMPTY_PRESET:

            HSA_Radio__ulwGetFirstEmptyPreset();
            break;

        case HSA_API_ENTRYPOINT__GET_RADIO_TEXT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vGetRadioText(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_FM_RADIO_TEXT_STATE:

            HSA_Radio__ulwGetFMRadioTextState();
            break;

        case HSA_API_ENTRYPOINT__GET_STATION_NAME_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Radio__vGetStationNameList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_STATION_PRESET_NR_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Radio__vGetStationPresetNrList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_FM_STATION_REG_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vGetFMStationRegList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_FM_STATION_TP_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vGetFMStationTPList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_STATION_FREQ_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Radio__vGetStationFreqList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_PRESET_BUTTON_TEXT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Radio__vGetPresetButtonText(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_PRESET_STATION_BAND:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__slwGetPresetStationBand(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_PRESET_STATION_BAND_STRING:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Radio__vGetPresetStationBandString(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_PRESET_STATION_ENSEMBLE_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Radio__vGetPresetStationEnsembleName(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_PRESET_STATION_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Radio__vGetPresetStationName(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_RADIO_TEXT_MODE_STATE:

            HSA_Radio__blGetRadioTextModeState();
            break;

        case HSA_API_ENTRYPOINT__GET_RECEIVED_DAB_ANNOUNCEMENT_PROG_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetReceivedDABAnnouncementProgName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_RECEIVED_DAB_ANNOUNCEMENT_TYPE:

            HSA_Radio__ulwGetReceivedDABAnnouncementType();
            break;

        case HSA_API_ENTRYPOINT__GET_REG_STATE:

            HSA_Radio__ulwGetRegState();
            break;

        case HSA_API_ENTRYPOINT__GET_SECONDARY_SERVICE_LIST__COUNT:

            HSA_Radio__ulwGetSecondaryServiceList_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_SECONDARY_SERVICE_LIST_ITEM__NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vGetSecondaryServiceListItem_Name(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SECONDARY_SERVICE_LIST_ITEM__STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__ulwGetSecondaryServiceListItem_State(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SEEK_MODE:

            HSA_Radio__ulwGetSeekMode();
            break;

        case HSA_API_ENTRYPOINT__GET_SELECTION_MODE:

            HSA_Radio__blGetSelectionMode();
            break;

        case HSA_API_ENTRYPOINT__GET_STATION_INFO_FM__COUNT:

            HSA_Radio__ulwGetStationInfoFM_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_TP_SEEK_STATE:

            HSA_Radio__ulwGetTPSeekState();
            break;

        case HSA_API_ENTRYPOINT__GET_TP_STATE:

            HSA_Radio__ulwGetTPState();
            break;

        case HSA_API_ENTRYPOINT__IS_DAB_AVAILABLE:

            HSA_Radio__blIsDABAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_DAB_OTHER_ANNOUNCEMENT_PLAYING:

            HSA_Radio__blIsDABOtherAnnouncementPlaying();
            break;

        case HSA_API_ENTRYPOINT__IS_DAB_SERVICE_READY_TO_BE_STORED:

            HSA_Radio__blIsDABServiceReadyToBeStored();
            break;

        case HSA_API_ENTRYPOINT__IS_DAB_SERVICE_SEEK_ACTIVE:

            HSA_Radio__blIsDABServiceSeekActive();
            break;

        case HSA_API_ENTRYPOINT__IS_DAB_TRAFFIC_ANNOUNCEMENT_PLAYING:

            HSA_Radio__blIsDABTrafficAnnouncementPlaying();
            break;

        case HSA_API_ENTRYPOINT__IS_MANUAL_MODE_ACTIVE:

            HSA_Radio__blIsManualModeActive();
            break;

        case HSA_API_ENTRYPOINT__IS_PS_NAME_AVAILABLE:

            HSA_Radio__blIsPSNameAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_SCAN_ACTIVE:

            HSA_Radio__blIsScanActive();
            break;

        case HSA_API_ENTRYPOINT__IS_SEEK_ACTIVE:

            HSA_Radio__blIsSeekActive();
            break;

        case HSA_API_ENTRYPOINT__IS_TA_MESSAGE_PLAYING:

            HSA_Radio__blIsTAMessagePlaying();
            break;

        case HSA_API_ENTRYPOINT__IS_TP_ACTIVATED:

            HSA_Radio__blIsTPActivated();
            break;

        case HSA_API_ENTRYPOINT__IS_TP_SEEK_ACTIVE:

            HSA_Radio__blIsTPSeekActive();
            break;

        case HSA_API_ENTRYPOINT__LOAD_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__vLoadList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SCAN_START:

            HSA_Radio__ulwScanStart();
            break;

        case HSA_API_ENTRYPOINT__SCAN_STOP:

            HSA_Radio__vScanStop();
            break;

        case HSA_API_ENTRYPOINT__SEEK_START:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__ulwSeekStart(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SEEK_STOP:

            HSA_Radio__vSeekStop();
            break;

        case HSA_API_ENTRYPOINT__SET_ACTIVE_FAVOURITES_SCREEN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__vSetActiveFavouritesScreen(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_DAB_OTHER_ANNOUNCEMENT_OFF:

            HSA_Radio__vSetDABOtherAnnouncementOff();
            break;

        case HSA_API_ENTRYPOINT__SET_DAB_TRAFFIC_ANNOUNCEMENT_OFF:

            HSA_Radio__vSetDABTrafficAnnouncementOff();
            break;

        case HSA_API_ENTRYPOINT__SET_MANUAL_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Radio__vSetManualMode(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_RADIO_TEXT_MODE_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Radio__vSetRadioTextModeState(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_REG_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__vSetRegState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_SEEK_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__vSetSeekMode(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_SELECTION_MODE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Radio__vSetSelectionMode(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_TP_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Radio__vSetTPState(usParam1);
            break;

        case HSA_API_ENTRYPOINT__STOP_CURRENT_DAB_ANNOUNCEMENT:

            HSA_Radio__vStopCurrentDABAnnouncement();
            break;

        case HSA_API_ENTRYPOINT__STOP_CURRENT_TA_MESSAGE:

            HSA_Radio__vStopCurrentTAMessage();
            break;

        case HSA_API_ENTRYPOINT__STOP_INITIAL_AUTOSTORE:

            HSA_Radio__vStopInitialAutostore();
            break;

        case HSA_API_ENTRYPOINT__STOP_TP_SEEK:

            HSA_Radio__vStopTPSeek();
            break;

        case HSA_API_ENTRYPOINT__STORE_CURRENT_STATION_PRESET:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__vStoreCurrentStationPreset(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__TARGET_SEEK_START:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__vTargetSeekStart(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__TARGET_SEEK_STOP:

            HSA_Radio__vTargetSeekStop();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_DAB_L_BAND_STATE:

            HSA_Radio__vToggleDAB_LBandState();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_DAB_OTHER_ANNOUNCEMENT_STATE:

            HSA_Radio__vToggleDABOtherAnnouncementState();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_DAB_SERVICE_FOLLOWING_STATE:

            HSA_Radio__vToggleDABServiceFollowingState();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_DAB_SERVICE_LINKING_STATE:

            HSA_Radio__vToggleDABServiceLinkingState();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_DAB_SERVICE_STATE:

            HSA_Radio__vToggleDABServiceState();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_TP_STATE:

            HSA_Radio__vToggleTPState();
            break;

        case HSA_API_ENTRYPOINT__UNFIX_ACTIVE_STATION_NAME:

            HSA_Radio__vUnfixActiveStationName();
            break;

        case HSA_API_ENTRYPOINT__UPDATE_DAB_STATION_LIST:

            HSA_Radio__vUpdateDABStationList();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_H_DSETTING:

            HSA_Radio__vToggleHDsetting();
            break;

        case HSA_API_ENTRYPOINT__GET_HD_SETTING:

            HSA_Radio__blGetHDSetting();
            break;

        case HSA_API_ENTRYPOINT__IS_PRESET_HD_STATION:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__blIsPresetHDStation(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LIST_UPDATE_STATUS:

            HSA_Radio__blGetListUpdateStatus();
            break;

        case HSA_API_ENTRYPOINT__UPDATE_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Radio__vUpdateList(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_STATION_HD_PRG_NO_LIST:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Radio__ulwGetStationHDPrgNoList(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__CANCEL_LIST_UPDATE:

            HSA_Radio__vCancelListUpdate();
            break;

        case HSA_API_ENTRYPOINT__IS_ACTIVE_STATION_HD:

            HSA_Radio__blIsActiveStationHD();
            break;

        case HSA_API_ENTRYPOINT__GET_AVAILABLE_HD_AUD_PRGM_I_DS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetAvailableHDAudPrgmIDs(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_DIGITAL_AUD_AVAILABLE:

            HSA_Radio__blIsDigitalAudAvailable();
            break;

        case HSA_API_ENTRYPOINT__GET_TITLE_PSD:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetTitlePSD(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ARTIST_PSD:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetArtistPSD(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_ALBUM_PSD:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Radio__vGetAlbumPSD(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SELECT_HD_AUD_PRGM:

            HSA_Radio__vSelectHDAudPrgm();
            break;

        case HSA_API_ENTRYPOINT__GET_AM_STATION_LIST_COUNT:

            HSA_Radio__ulwGetAMStationListCount();
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

