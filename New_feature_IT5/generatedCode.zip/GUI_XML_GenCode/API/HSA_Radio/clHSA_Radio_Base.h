/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_Radio_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_Radio_Base_H
#define _clHSA_Radio_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_Radio_Base : public clHSA_Base
{
public:

    static clHSA_Radio_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_Radio_Base()        {}

    virtual tbool blIsDABListUpdateActive( );

    virtual void vActivateNextSecComponent( );

    virtual void vActivatePreviousSecComponent( );

    virtual void vSetDABSecAudioOff( );

    virtual tbool blGetDABComponentMode( );

    virtual void vUpdateDABSrvList(tbool blAction);

    virtual tbool blGetDAB_FM_SF_Status( );

    virtual void vCloseDABList( );

    virtual ulword ulwGetDABSrvAvailability( );

    virtual void vGetDABReceptionList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetDABSrvListLength( );

    virtual ulword ulwGetDABCompListLength( );

    virtual ulword ulwGetDABNumSecComponents( );

    virtual void vGetCurrentFrequencyString(GUI_String *out_result);

    virtual void vGetCurrentFrequencyUnit(GUI_String *out_result);

    virtual void vActivateNextPresetStation( );

    virtual void vActivatePrevPresetStation( );

    virtual tbool blGetStereoStatus( );

    virtual ulword ulwGetStationListLoadingState(ulword ulwActiveSource);

    virtual ulword ulwGetCurrentBank( );

    virtual ulword ulwGetCurrentFrequency( );

    virtual void vSwitchAutoCompareBank(ulword ulwBand);

    virtual void vIncreaseTunerFrequency(ulword ulwNoOfSteps);

    virtual void vDecreaseTunerFrequency(ulword ulwNoOfSteps);

    virtual void vSetTunerFrequencyDirect(ulword ulwFrequency);

    virtual void vActivateBand(ulword ulwBand);

    virtual void vActivateDABService(ulword ulwListEntryNr, ulword ulwSubListEntryNr);

    virtual void vActivateInitialAutoStore( );

    virtual void vActivateNextEnsemble( );

    virtual void vActivateNextListStation( );

    virtual void vActivateNextStation( );

    virtual void vActivatePreviousEnsemble( );

    virtual void vActivatePreviousListStation( );

    virtual void vActivatePreviousStation( );

    virtual void vActivateSecondaryService(ulword ulwListEntryNr);

    virtual void vActivateStation(ulword ulwListType, ulword ulwListEntryNr);

    virtual void vActivateStationPreset(ulword ulwEntryNr, ulword ulwBankNr);

    virtual void vCancelUpdateDABStationList( );

    virtual void vClearPresetList( );

    virtual slword slwConvertToDynamicIndex_DABEnsembleList(ulword ulwUniqueId);

    virtual slword slwConvertToDynamicIndex_DABSecServicesList(ulword ulwUniqueId);

    virtual slword slwConvertToUniqueId_DABEnsembleList(ulword ulwDynamicIndex);

    virtual slword slwConvertToUniqueId_DABSecServicesList(ulword ulwDynamicIndex);

    virtual void vDeletePresetStation(ulword ulwEntryNr, ulword ulwBankNr);

    virtual void vExitStationList( );

    virtual void vFixActiveStationListName( );

    virtual void vFixActiveStationName( );

    virtual void vFreezePS( );

    virtual ulword ulwGetActiveEnsembleIndex( );

    virtual ulword ulwGetActiveEnsembleServiceIndex( );

    virtual ulword ulwGetActiveFavouritesScreen( );

    virtual ulword ulwGetActiveSecondaryServiceIndex( );

    virtual void vGetActiveSecondaryServiceName(GUI_String *out_result);

    virtual void vGetActiveStationBandString(GUI_String *out_result);

    virtual void vGetActiveStationEnsembleName(GUI_String *out_result);

    virtual ulword ulwGetActiveStationEnsembleState( );

    virtual ulword ulwGetActiveStationListIndex(ulword ulwListType);

    virtual void vGetActiveStationName(GUI_String *out_result);

    virtual void vGetActiveStationNameShort(GUI_String *out_result);

    virtual slword slwGetActiveStationPresetNr(ulword ulwActiveSource);

    virtual void vGetActiveStationPS(GUI_String *out_result, ulword ulwActiveSource);

    virtual ulword ulwGetCurrentBand( );

    virtual void vSetTunerVisibality(tbool blVisibality, ulword ulwSource);

    virtual void vGetCurrentTAStationName(GUI_String *out_result);

    virtual tbool blGetDAB_LBandState( );

    virtual ulword ulwGetDABEnsembleList_Count( );

    virtual void vGetDABEnsembleListItem_Name(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetDABEnsembleListItem_State(ulword ulwListEntryNr);

    virtual ulword ulwGetDABEnsembleServiceList_Count(ulword ulwListEntryNr);

    virtual void vGetDABEnsembleServiceListItem_Name(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwSubListEntryNr);

    virtual ulword ulwGetDABEnsembleServiceListItem_State(ulword ulwListEntryNr, ulword ulwSubListEntryNr);

    virtual void vGetDABEnsembleServiceListItem_TP(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwSubListEntryNr);

    virtual tbool blGetDABOtherAnnouncementState( );

    virtual void vGetDABRadioText(GUI_String *out_result);

    virtual ulword ulwGetDABRadioTextState( );

    virtual tbool blGetDABServiceFollowingState( );

    virtual tbool blGetDABServiceLinkingState( );

    virtual ulword ulwGetDABServiceState( );

    virtual ulword ulwGetDABStationListUpdateState( );

    virtual ulword ulwGetFirstEmptyPreset( );

    virtual void vGetRadioText(GUI_String *out_result, ulword ulwActiveSource);

    virtual ulword ulwGetFMRadioTextState( );

    virtual void vGetStationNameList(GUI_String *out_result, ulword ulwListType, ulword ulwListEntryNr);

    virtual void vGetStationPresetNrList(GUI_String *out_result, ulword ulwListType, ulword ulwListEntryNr);

    virtual void vGetFMStationRegList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetFMStationTPList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetStationFreqList(GUI_String *out_result, ulword ulwListType, ulword ulwListEntryNr);

    virtual void vGetPresetButtonText(GUI_String *out_result, ulword ulwIndex, ulword ulwBank);

    virtual slword slwGetPresetStationBand(ulword ulwEntryNr, ulword ulwBankNr);

    virtual void vGetPresetStationBandString(GUI_String *out_result, ulword ulwEntryNr, ulword ulwBankNr);

    virtual void vGetPresetStationEnsembleName(GUI_String *out_result, ulword ulwEntryNr, ulword ulwBankNr);

    virtual void vGetPresetStationName(GUI_String *out_result, ulword ulwEntryNr, ulword ulwBankNr);

    virtual tbool blGetRadioTextModeState( );

    virtual void vGetReceivedDABAnnouncementProgName(GUI_String *out_result);

    virtual ulword ulwGetReceivedDABAnnouncementType( );

    virtual ulword ulwGetRegState( );

    virtual ulword ulwGetSecondaryServiceList_Count( );

    virtual void vGetSecondaryServiceListItem_Name(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetSecondaryServiceListItem_State(ulword ulwListEntryNr);

    virtual ulword ulwGetSeekMode( );

    virtual tbool blGetSelectionMode( );

    virtual ulword ulwGetStationInfoFM_Count( );

    virtual ulword ulwGetTPSeekState( );

    virtual ulword ulwGetTPState( );

    virtual tbool blIsDABAvailable( );

    virtual tbool blIsDABOtherAnnouncementPlaying( );

    virtual tbool blIsDABServiceReadyToBeStored( );

    virtual tbool blIsDABServiceSeekActive( );

    virtual tbool blIsDABTrafficAnnouncementPlaying( );

    virtual tbool blIsManualModeActive( );

    virtual tbool blIsPSNameAvailable( );

    virtual tbool blIsScanActive( );

    virtual tbool blIsSeekActive( );

    virtual tbool blIsTAMessagePlaying( );

    virtual tbool blIsTPActivated( );

    virtual tbool blIsTPSeekActive( );

    virtual void vLoadList(ulword ulwListType);

    virtual ulword ulwScanStart( );

    virtual void vScanStop( );

    virtual ulword ulwSeekStart(ulword ulwDirection);

    virtual void vSeekStop( );

    virtual void vSetActiveFavouritesScreen(ulword ulwBankNr);

    virtual void vSetDABOtherAnnouncementOff( );

    virtual void vSetDABTrafficAnnouncementOff( );

    virtual void vSetManualMode(tbool blValue);

    virtual void vSetRadioTextModeState(tbool blMode);

    virtual void vSetRegState(ulword ulwValue);

    virtual void vSetSeekMode(ulword ulwValue);

    virtual void vSetSelectionMode(tbool blMode);

    virtual void vSetTPState(tbool blValue);

    virtual void vStopCurrentDABAnnouncement( );

    virtual void vStopCurrentTAMessage( );

    virtual void vStopInitialAutostore( );

    virtual void vStopTPSeek( );

    virtual void vStoreCurrentStationPreset(ulword ulwEntryNr, ulword ulwBankNr);

    virtual void vTargetSeekStart(ulword ulwDirection);

    virtual void vTargetSeekStop( );

    virtual void vToggleDAB_LBandState( );

    virtual void vToggleDABOtherAnnouncementState( );

    virtual void vToggleDABServiceFollowingState( );

    virtual void vToggleDABServiceLinkingState( );

    virtual void vToggleDABServiceState( );

    virtual void vToggleTPState( );

    virtual void vUnfixActiveStationName( );

    virtual void vUpdateDABStationList( );

    virtual void vToggleHDsetting( );

    virtual tbool blGetHDSetting( );

    virtual tbool blIsPresetHDStation(ulword ulwPresetID);

    virtual tbool blGetListUpdateStatus( );

    virtual void vUpdateList(ulword ulwListID);

    virtual ulword ulwGetStationHDPrgNoList(ulword ulwListType, ulword ulwListEntryNr);

    virtual void vCancelListUpdate( );

    virtual tbool blIsActiveStationHD( );

    virtual void vGetAvailableHDAudPrgmIDs(GUI_String *out_result);

    virtual tbool blIsDigitalAudAvailable( );

    virtual void vGetTitlePSD(GUI_String *out_result);

    virtual void vGetArtistPSD(GUI_String *out_result);

    virtual void vGetAlbumPSD(GUI_String *out_result);

    virtual void vSelectHDAudPrgm( );

    virtual ulword ulwGetAMStationListCount( );

protected:
    clHSA_Radio_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_Radio_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_Radio_Base_H

