/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Radio_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_Radio_Wrapper_H
#define _HSA_Radio_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: IsDABListUpdateActive
 * NISSAN
 * NISSAN
 */
tbool HSA_Radio__blIsDABListUpdateActive( void);

/**
 * Function: ActivateNextSecComponent
 * NISSAN
 * NISSAN
 */
void HSA_Radio__vActivateNextSecComponent( void);

/**
 * Function: ActivatePreviousSecComponent
 * NISSAN
 * NISSAN
 */
void HSA_Radio__vActivatePreviousSecComponent( void);

/**
 * Function: SetDABSecAudioOff
 * NISSAN
 * NISSAN
 */
void HSA_Radio__vSetDABSecAudioOff( void);

/**
 * Function: GetDABComponentMode
 * NISSAN
 * NISSAN
 */
tbool HSA_Radio__blGetDABComponentMode( void);

/**
 * Function: UpdateDABSrvList
 * NISSAN
 * NISSAN
 */
void HSA_Radio__vUpdateDABSrvList(tbool blAction);

/**
 * Function: GetDAB_FM_SF_Status
 * NISSAN
 * NISSAN
 */
tbool HSA_Radio__blGetDAB_FM_SF_Status( void);

/**
 * Function: CloseDABList
 * NISSAN
 * NISSAN
 */
void HSA_Radio__vCloseDABList( void);

/**
 * Function: GetDABSrvAvailability
 * NISSAN
 * NISSAN
 */
ulword HSA_Radio__ulwGetDABSrvAvailability( void);

/**
 * Function: GetDABReceptionList
 * NISSAN
 * NISSAN
 */
void HSA_Radio__vGetDABReceptionList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetDABSrvListLength
 * NISSAN
 * NISSAN
 */
ulword HSA_Radio__ulwGetDABSrvListLength( void);

/**
 * Function: GetDABCompListLength
 * NISSAN
 * NISSAN
 */
ulword HSA_Radio__ulwGetDABCompListLength( void);

/**
 * Function: GetDABNumSecComponents
 * NISSAN
 * NISSAN
 */
ulword HSA_Radio__ulwGetDABNumSecComponents( void);

/**
 * Function: GetCurrentFrequencyString
 * NISSAN
 * NISSAN
 */
void HSA_Radio__vGetCurrentFrequencyString(GUI_String *out_result);

/**
 * Function: GetCurrentFrequencyUnit
 * NISSAN
 * NISSAN
 */
void HSA_Radio__vGetCurrentFrequencyUnit(GUI_String *out_result);

/**
 * Function: ActivateNextPresetStation
 * NISSAN
 * NISSAN
 */
void HSA_Radio__vActivateNextPresetStation( void);

/**
 * Function: ActivatePrevPresetStation
 * NISSAN
 * NISSAN
 */
void HSA_Radio__vActivatePrevPresetStation( void);

/**
 * Function: GetStereoStatus
 * NISSAN
 * NISSAN
 */
tbool HSA_Radio__blGetStereoStatus( void);

/**
 * Function: GetStationListLoadingState
 * NISSAN
 * NISSAN
 */
ulword HSA_Radio__ulwGetStationListLoadingState(ulword ulwActiveSource);

/**
 * Function: GetCurrentBank
 * NISSAN
 * NISSAN
 */
ulword HSA_Radio__ulwGetCurrentBank( void);

/**
 * Function: GetCurrentFrequency
 * NISSAN
 * NISSAN
 */
ulword HSA_Radio__ulwGetCurrentFrequency( void);

/**
 * Function: SwitchAutoCompareBank
 * NISSAN
 * NISSAN
 */
void HSA_Radio__vSwitchAutoCompareBank(ulword ulwBand);

/**
 * Function: IncreaseTunerFrequency
 * 
 * NISSAN
 */
void HSA_Radio__vIncreaseTunerFrequency(ulword ulwNoOfSteps);

/**
 * Function: DecreaseTunerFrequency
 * 
 * NISSAN
 */
void HSA_Radio__vDecreaseTunerFrequency(ulword ulwNoOfSteps);

/**
 * Function: SetTunerFrequencyDirect
 * 
 * NISSAN
 */
void HSA_Radio__vSetTunerFrequencyDirect(ulword ulwFrequency);

/**
 * Function: ActivateBand
 * B1
 * NISSAN
 */
void HSA_Radio__vActivateBand(ulword ulwBand);

/**
 * Function: ActivateDABService
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vActivateDABService(ulword ulwListEntryNr, ulword ulwSubListEntryNr);

/**
 * Function: ActivateInitialAutoStore
 * B
 * NISSAN
 */
void HSA_Radio__vActivateInitialAutoStore( void);

/**
 * Function: ActivateNextEnsemble
 * BPlus
 * NISSAN
 */
void HSA_Radio__vActivateNextEnsemble( void);

/**
 * Function: ActivateNextListStation
 * B2 [DAB: A plus]
 * NISSAN
 */
void HSA_Radio__vActivateNextListStation( void);

/**
 * Function: ActivateNextStation
 * B2 [DAB: A plus]
 * NISSAN
 */
void HSA_Radio__vActivateNextStation( void);

/**
 * Function: ActivatePreviousEnsemble
 * BPlus
 * NISSAN
 */
void HSA_Radio__vActivatePreviousEnsemble( void);

/**
 * Function: ActivatePreviousListStation
 * B2 [DAB: A plus]
 * NISSAN
 */
void HSA_Radio__vActivatePreviousListStation( void);

/**
 * Function: ActivatePreviousStation
 * B2 [DAB: A plus]
 * NISSAN
 */
void HSA_Radio__vActivatePreviousStation( void);

/**
 * Function: ActivateSecondaryService
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vActivateSecondaryService(ulword ulwListEntryNr);

/**
 * Function: ActivateStation
 * B
 * NISSAN
 */
void HSA_Radio__vActivateStation(ulword ulwListType, ulword ulwListEntryNr);

/**
 * Function: ActivateStationPreset
 * B
 * NISSAN
 */
void HSA_Radio__vActivateStationPreset(ulword ulwEntryNr, ulword ulwBankNr);

/**
 * Function: CancelUpdateDABStationList
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vCancelUpdateDABStationList( void);

/**
 * Function: ClearPresetList
 * B
 * NISSAN
 */
void HSA_Radio__vClearPresetList( void);

/**
 * Function: ConvertToDynamicIndex_DABEnsembleList
 * BPlus
 * NISSAN
 */
slword HSA_Radio__slwConvertToDynamicIndex_DABEnsembleList(ulword ulwUniqueId);

/**
 * Function: ConvertToDynamicIndex_DABSecServicesList
 * BPlus
 * NISSAN
 */
slword HSA_Radio__slwConvertToDynamicIndex_DABSecServicesList(ulword ulwUniqueId);

/**
 * Function: ConvertToUniqueId_DABEnsembleList
 * BPlus
 * NISSAN
 */
slword HSA_Radio__slwConvertToUniqueId_DABEnsembleList(ulword ulwDynamicIndex);

/**
 * Function: ConvertToUniqueId_DABSecServicesList
 * BPlus
 * NISSAN
 */
slword HSA_Radio__slwConvertToUniqueId_DABSecServicesList(ulword ulwDynamicIndex);

/**
 * Function: DeletePresetStation
 * B
 * NISSAN
 */
void HSA_Radio__vDeletePresetStation(ulword ulwEntryNr, ulword ulwBankNr);

/**
 * Function: ExitStationList
 * B
 * NISSAN
 */
void HSA_Radio__vExitStationList( void);

/**
 * Function: FixActiveStationListName
 * B
 * NISSAN
 */
void HSA_Radio__vFixActiveStationListName( void);

/**
 * Function: FixActiveStationName
 * B
 * NISSAN
 */
void HSA_Radio__vFixActiveStationName( void);

/**
 * Function: FreezePS
 * B
 * NISSAN
 */
void HSA_Radio__vFreezePS( void);

/**
 * Function: GetActiveEnsembleIndex
 * B1Plus
 * NISSAN
 */
ulword HSA_Radio__ulwGetActiveEnsembleIndex( void);

/**
 * Function: GetActiveEnsembleServiceIndex
 * B1Plus
 * NISSAN
 */
ulword HSA_Radio__ulwGetActiveEnsembleServiceIndex( void);

/**
 * Function: GetActiveFavouritesScreen
 * B
 * NISSAN
 */
ulword HSA_Radio__ulwGetActiveFavouritesScreen( void);

/**
 * Function: GetActiveSecondaryServiceIndex
 * B1Plus
 * NISSAN
 */
ulword HSA_Radio__ulwGetActiveSecondaryServiceIndex( void);

/**
 * Function: GetActiveSecondaryServiceName
 * APlus
 * NISSAN
 */
void HSA_Radio__vGetActiveSecondaryServiceName(GUI_String *out_result);

/**
 * Function: GetActiveStationBandString
 * B1
 * NISSAN
 */
void HSA_Radio__vGetActiveStationBandString(GUI_String *out_result);

/**
 * Function: GetActiveStationEnsembleName
 * APlus
 * NISSAN
 */
void HSA_Radio__vGetActiveStationEnsembleName(GUI_String *out_result);

/**
 * Function: GetActiveStationEnsembleState
 * APlus
 * NISSAN
 */
ulword HSA_Radio__ulwGetActiveStationEnsembleState( void);

/**
 * Function: GetActiveStationListIndex
 * B2
 * NISSAN
 */
ulword HSA_Radio__ulwGetActiveStationListIndex(ulword ulwListType);

/**
 * Function: GetActiveStationName
 * B1 [DAB service name: A plus ]
 * NISSAN
 */
void HSA_Radio__vGetActiveStationName(GUI_String *out_result);

/**
 * Function: GetActiveStationNameShort
 * B1
 * NISSAN
 */
void HSA_Radio__vGetActiveStationNameShort(GUI_String *out_result);

/**
 * Function: GetActiveStationPresetNr
 * B
 * NISSAN
 */
slword HSA_Radio__slwGetActiveStationPresetNr(ulword ulwActiveSource);

/**
 * Function: GetActiveStationPS
 * t.b.d.
 * NISSAN
 */
void HSA_Radio__vGetActiveStationPS(GUI_String *out_result, ulword ulwActiveSource);

/**
 * Function: GetCurrentBand
 * B1
 * NISSAN
 */
ulword HSA_Radio__ulwGetCurrentBand( void);

/**
 * Function: SetTunerVisibality
 * B1
 * NISSAN
 */
void HSA_Radio__vSetTunerVisibality(tbool blVisibality, ulword ulwSource);

/**
 * Function: GetCurrentTAStationName
 * B
 * NISSAN
 */
void HSA_Radio__vGetCurrentTAStationName(GUI_String *out_result);

/**
 * Function: GetDAB_LBandState
 * B1Plus
 * NISSAN
 */
tbool HSA_Radio__blGetDAB_LBandState( void);

/**
 * Function: GetDABEnsembleList_Count
 * B1Plus
 * NISSAN
 */
ulword HSA_Radio__ulwGetDABEnsembleList_Count( void);

/**
 * Function: GetDABEnsembleListItem_Name
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vGetDABEnsembleListItem_Name(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetDABEnsembleListItem_State
 * B1Plus
 * NISSAN
 */
ulword HSA_Radio__ulwGetDABEnsembleListItem_State(ulword ulwListEntryNr);

/**
 * Function: GetDABEnsembleServiceList_Count
 * B1Plus
 * NISSAN
 */
ulword HSA_Radio__ulwGetDABEnsembleServiceList_Count(ulword ulwListEntryNr);

/**
 * Function: GetDABEnsembleServiceListItem_Name
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vGetDABEnsembleServiceListItem_Name(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwSubListEntryNr);

/**
 * Function: GetDABEnsembleServiceListItem_State
 * B1Plus
 * NISSAN
 */
ulword HSA_Radio__ulwGetDABEnsembleServiceListItem_State(ulword ulwListEntryNr, ulword ulwSubListEntryNr);

/**
 * Function: GetDABEnsembleServiceListItem_TP
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vGetDABEnsembleServiceListItem_TP(GUI_String *out_result, ulword ulwListEntryNr, ulword ulwSubListEntryNr);

/**
 * Function: GetDABOtherAnnouncementState
 * B2Plus
 * NISSAN
 */
tbool HSA_Radio__blGetDABOtherAnnouncementState( void);

/**
 * Function: GetDABRadioText
 * B2Plus [for the B1Plus sample: always return 1]
 * NISSAN
 */
void HSA_Radio__vGetDABRadioText(GUI_String *out_result);

/**
 * Function: GetDABRadioTextState
 * B2Plus [for the B1Plus sample: always return 1]
 * NISSAN
 */
ulword HSA_Radio__ulwGetDABRadioTextState( void);

/**
 * Function: GetDABServiceFollowingState
 * B2Plus
 * NISSAN
 */
tbool HSA_Radio__blGetDABServiceFollowingState( void);

/**
 * Function: GetDABServiceLinkingState
 * B2Plus
 * NISSAN
 */
tbool HSA_Radio__blGetDABServiceLinkingState( void);

/**
 * Function: GetDABServiceState
 * B1Plus
 * NISSAN
 */
ulword HSA_Radio__ulwGetDABServiceState( void);

/**
 * Function: GetDABStationListUpdateState
 * B1Plus
 * NISSAN
 */
ulword HSA_Radio__ulwGetDABStationListUpdateState( void);

/**
 * Function: GetFirstEmptyPreset
 * B
 * NISSAN
 */
ulword HSA_Radio__ulwGetFirstEmptyPreset( void);

/**
 * Function: GetRadioText
 * B2 [for the  B1 sample: returns a static value]
 * NISSAN
 */
void HSA_Radio__vGetRadioText(GUI_String *out_result, ulword ulwActiveSource);

/**
 * Function: GetFMRadioTextState
 * B2 [for the B1 sample: always return 1] 
 * NISSAN
 */
ulword HSA_Radio__ulwGetFMRadioTextState( void);

/**
 * Function: GetStationNameList
 * B2
 * NISSAN
 */
void HSA_Radio__vGetStationNameList(GUI_String *out_result, ulword ulwListType, ulword ulwListEntryNr);

/**
 * Function: GetStationPresetNrList
 * B
 * NISSAN
 */
void HSA_Radio__vGetStationPresetNrList(GUI_String *out_result, ulword ulwListType, ulword ulwListEntryNr);

/**
 * Function: GetFMStationRegList
 * B
 * NISSAN
 */
void HSA_Radio__vGetFMStationRegList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetFMStationTPList
 * B
 * NISSAN
 */
void HSA_Radio__vGetFMStationTPList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetStationFreqList
 * B
 * NISSAN
 */
void HSA_Radio__vGetStationFreqList(GUI_String *out_result, ulword ulwListType, ulword ulwListEntryNr);

/**
 * Function: GetPresetButtonText
 * B1
 * NISSAN
 */
void HSA_Radio__vGetPresetButtonText(GUI_String *out_result, ulword ulwIndex, ulword ulwBank);

/**
 * Function: GetPresetStationBand
 * B
 * NISSAN
 */
slword HSA_Radio__slwGetPresetStationBand(ulword ulwEntryNr, ulword ulwBankNr);

/**
 * Function: GetPresetStationBandString
 * B [for the B1 sample: return an empty string] 
 * NISSAN
 */
void HSA_Radio__vGetPresetStationBandString(GUI_String *out_result, ulword ulwEntryNr, ulword ulwBankNr);

/**
 * Function: GetPresetStationEnsembleName
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vGetPresetStationEnsembleName(GUI_String *out_result, ulword ulwEntryNr, ulword ulwBankNr);

/**
 * Function: GetPresetStationName
 * B [for the B1 sample: return an empty string] 
 * NISSAN
 */
void HSA_Radio__vGetPresetStationName(GUI_String *out_result, ulword ulwEntryNr, ulword ulwBankNr);

/**
 * Function: GetRadioTextModeState
 * B
 * NISSAN
 */
tbool HSA_Radio__blGetRadioTextModeState( void);

/**
 * Function: GetReceivedDABAnnouncementProgName
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vGetReceivedDABAnnouncementProgName(GUI_String *out_result);

/**
 * Function: GetReceivedDABAnnouncementType
 * B1Plus
 * NISSAN
 */
ulword HSA_Radio__ulwGetReceivedDABAnnouncementType( void);

/**
 * Function: GetRegState
 * B
 * NISSAN
 */
ulword HSA_Radio__ulwGetRegState( void);

/**
 * Function: GetSecondaryServiceList_Count
 * B1Plus
 * NISSAN
 */
ulword HSA_Radio__ulwGetSecondaryServiceList_Count( void);

/**
 * Function: GetSecondaryServiceListItem_Name
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vGetSecondaryServiceListItem_Name(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetSecondaryServiceListItem_State
 * B1Plus
 * NISSAN
 */
ulword HSA_Radio__ulwGetSecondaryServiceListItem_State(ulword ulwListEntryNr);

/**
 * Function: GetSeekMode
 * B2 [for the B1 sample: always return 0 (StationList)] 
 * NISSAN
 */
ulword HSA_Radio__ulwGetSeekMode( void);

/**
 * Function: GetSelectionMode
 * B
 * NISSAN
 */
tbool HSA_Radio__blGetSelectionMode( void);

/**
 * Function: GetStationInfoFM_Count
 * B2
 * NISSAN
 */
ulword HSA_Radio__ulwGetStationInfoFM_Count( void);

/**
 * Function: GetTPSeekState
 * B
 * NISSAN
 */
ulword HSA_Radio__ulwGetTPSeekState( void);

/**
 * Function: GetTPState
 * B [for the B1 sample, always return true] 
 * NISSAN
 */
ulword HSA_Radio__ulwGetTPState( void);

/**
 * Function: IsDABAvailable
 * B1
 * NISSAN
 */
tbool HSA_Radio__blIsDABAvailable( void);

/**
 * Function: IsDABOtherAnnouncementPlaying
 * B1Plus
 * NISSAN
 */
tbool HSA_Radio__blIsDABOtherAnnouncementPlaying( void);

/**
 * Function: IsDABServiceReadyToBeStored
 * B1Plus
 * NISSAN
 */
tbool HSA_Radio__blIsDABServiceReadyToBeStored( void);

/**
 * Function: IsDABServiceSeekActive
 * B1Plus
 * NISSAN
 */
tbool HSA_Radio__blIsDABServiceSeekActive( void);

/**
 * Function: IsDABTrafficAnnouncementPlaying
 * B1Plus
 * NISSAN
 */
tbool HSA_Radio__blIsDABTrafficAnnouncementPlaying( void);

/**
 * Function: IsManualModeActive
 * B1
 * NISSAN
 */
tbool HSA_Radio__blIsManualModeActive( void);

/**
 * Function: IsPSNameAvailable
 * B
 * NISSAN
 */
tbool HSA_Radio__blIsPSNameAvailable( void);

/**
 * Function: IsScanActive
 * B2 [planned for the B sample but agreed with Mr. Feldbauer to be implemented for B1]
 * NISSAN
 */
tbool HSA_Radio__blIsScanActive( void);

/**
 * Function: IsSeekActive
 * B1
 * NISSAN
 */
tbool HSA_Radio__blIsSeekActive( void);

/**
 * Function: IsTAMessagePlaying
 * B
 * NISSAN
 */
tbool HSA_Radio__blIsTAMessagePlaying( void);

/**
 * Function: IsTPActivated
 * B [for the B1 sample, always return true]
 * NISSAN
 */
tbool HSA_Radio__blIsTPActivated( void);

/**
 * Function: IsTPSeekActive
 * B
 * NISSAN
 */
tbool HSA_Radio__blIsTPSeekActive( void);

/**
 * Function: LoadList
 * B2
 * NISSAN
 */
void HSA_Radio__vLoadList(ulword ulwListType);

/**
 * Function: ScanStart
 * B2 [planned for the B sample but agreed with Mr. Feldbauer to be implemented for B1] [DAB: B2 plus]
 * NISSAN
 */
ulword HSA_Radio__ulwScanStart( void);

/**
 * Function: ScanStop
 * B2 [planned for the B sample but agreed with Mr. Feldbauer to be implemented for B1] [DAB: B2 plus]
 * NISSAN
 */
void HSA_Radio__vScanStop( void);

/**
 * Function: SeekStart
 * B1
 * NISSAN
 */
ulword HSA_Radio__ulwSeekStart(ulword ulwDirection);

/**
 * Function: SeekStop
 * B1
 * NISSAN
 */
void HSA_Radio__vSeekStop( void);

/**
 * Function: SetActiveFavouritesScreen
 * B
 * NISSAN
 */
void HSA_Radio__vSetActiveFavouritesScreen(ulword ulwBankNr);

/**
 * Function: SetDABOtherAnnouncementOff
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vSetDABOtherAnnouncementOff( void);

/**
 * Function: SetDABTrafficAnnouncementOff
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vSetDABTrafficAnnouncementOff( void);

/**
 * Function: SetManualMode
 * B1 [DAB: A plus]
 * NISSAN
 */
void HSA_Radio__vSetManualMode(tbool blValue);

/**
 * Function: SetRadioTextModeState
 * B
 * NISSAN
 */
void HSA_Radio__vSetRadioTextModeState(tbool blMode);

/**
 * Function: SetRegState
 * B
 * NISSAN
 */
void HSA_Radio__vSetRegState(ulword ulwValue);

/**
 * Function: SetSeekMode
 * B2
 * NISSAN
 */
void HSA_Radio__vSetSeekMode(ulword ulwValue);

/**
 * Function: SetSelectionMode
 * B
 * NISSAN
 */
void HSA_Radio__vSetSelectionMode(tbool blMode);

/**
 * Function: SetTPState
 * B
 * NISSAN
 */
void HSA_Radio__vSetTPState(tbool blValue);

/**
 * Function: StopCurrentDABAnnouncement
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vStopCurrentDABAnnouncement( void);

/**
 * Function: StopCurrentTAMessage
 * B [planned for the B sample but agreed with Mr. Feldbauer to be implemented for B1]
 * NISSAN
 */
void HSA_Radio__vStopCurrentTAMessage( void);

/**
 * Function: StopInitialAutostore
 * B
 * NISSAN
 */
void HSA_Radio__vStopInitialAutostore( void);

/**
 * Function: StopTPSeek
 * B
 * NISSAN
 */
void HSA_Radio__vStopTPSeek( void);

/**
 * Function: StoreCurrentStationPreset
 * B
 * NISSAN
 */
void HSA_Radio__vStoreCurrentStationPreset(ulword ulwEntryNr, ulword ulwBankNr);

/**
 * Function: TargetSeekStart
 * B1
 * NISSAN
 */
void HSA_Radio__vTargetSeekStart(ulword ulwDirection);

/**
 * Function: TargetSeekStop
 * B1
 * NISSAN
 */
void HSA_Radio__vTargetSeekStop( void);

/**
 * Function: ToggleDAB_LBandState
 * B2Plus
 * NISSAN
 */
void HSA_Radio__vToggleDAB_LBandState( void);

/**
 * Function: ToggleDABOtherAnnouncementState
 * B2Plus
 * NISSAN
 */
void HSA_Radio__vToggleDABOtherAnnouncementState( void);

/**
 * Function: ToggleDABServiceFollowingState
 * B2Plus
 * NISSAN
 */
void HSA_Radio__vToggleDABServiceFollowingState( void);

/**
 * Function: ToggleDABServiceLinkingState
 * B2Plus
 * NISSAN
 */
void HSA_Radio__vToggleDABServiceLinkingState( void);

/**
 * Function: ToggleDABServiceState
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vToggleDABServiceState( void);

/**
 * Function: ToggleTPState
 * B [planned for the B2 sample but agreed with Mr. Feldhofer to be implemented for B1]
 * NISSAN
 */
void HSA_Radio__vToggleTPState( void);

/**
 * Function: UnfixActiveStationName
 * B
 * NISSAN
 */
void HSA_Radio__vUnfixActiveStationName( void);

/**
 * Function: UpdateDABStationList
 * B1Plus
 * NISSAN
 */
void HSA_Radio__vUpdateDABStationList( void);

/**
 * Function: ToggleHDsetting
 * ITG5
 * NISSAN
 */
void HSA_Radio__vToggleHDsetting( void);

/**
 * Function: GetHDSetting
 * ITG5
 * NISSAN
 */
tbool HSA_Radio__blGetHDSetting( void);

/**
 * Function: IsPresetHDStation
 * ITG5
 * NISSAN
 */
tbool HSA_Radio__blIsPresetHDStation(ulword ulwPresetID);

/**
 * Function: GetListUpdateStatus
 * ITG5
 * NISSAN
 */
tbool HSA_Radio__blGetListUpdateStatus( void);

/**
 * Function: UpdateList
 * ITG5
 * NISSAN
 */
void HSA_Radio__vUpdateList(ulword ulwListID);

/**
 * Function: GetStationHDPrgNoList
 * ITG5
 * NISSAN
 */
ulword HSA_Radio__ulwGetStationHDPrgNoList(ulword ulwListType, ulword ulwListEntryNr);

/**
 * Function: CancelListUpdate
 * ITG5
 * NISSAN
 */
void HSA_Radio__vCancelListUpdate( void);

/**
 * Function: IsActiveStationHD
 * ITG5
 * NISSAN
 */
tbool HSA_Radio__blIsActiveStationHD( void);

/**
 * Function: GetAvailableHDAudPrgmIDs
 * ITG5
 * NISSAN
 */
void HSA_Radio__vGetAvailableHDAudPrgmIDs(GUI_String *out_result);

/**
 * Function: IsDigitalAudAvailable
 * ITG5
 * NISSAN
 */
tbool HSA_Radio__blIsDigitalAudAvailable( void);

/**
 * Function: GetTitlePSD
 * ITG5
 * NISSAN
 */
void HSA_Radio__vGetTitlePSD(GUI_String *out_result);

/**
 * Function: GetArtistPSD
 * ITG5
 * NISSAN
 */
void HSA_Radio__vGetArtistPSD(GUI_String *out_result);

/**
 * Function: GetAlbumPSD
 * ITG5
 * NISSAN
 */
void HSA_Radio__vGetAlbumPSD(GUI_String *out_result);

/**
 * Function: SelectHDAudPrgm
 * ITG5
 * NISSAN
 */
void HSA_Radio__vSelectHDAudPrgm( void);

/**
 * Function: GetAMStationListCount
 * ITG5
 * NISSAN
 */
ulword HSA_Radio__ulwGetAMStationListCount( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_Radio_H

