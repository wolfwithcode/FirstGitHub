/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_GUI_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_GUI_Wrapper.h"
#include "clHSA_GUI_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_GUI_Trace.h"
#include "hmi_trace.h"

tbool HSA_GUI__blGetBooleanVariable(ulword ulwVariableID)
{
    tbool ret = false;
    clHSA_GUI_Base *pInst=clHSA_GUI_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_BOOLEAN_VARIABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwVariableID); 
        }
      ret=pInst->blGetBooleanVariable(ulwVariableID);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_BOOLEAN_VARIABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_GUI__vGetCurrentMenu(GUI_String *out_result)
{
    
    clHSA_GUI_Base *pInst=clHSA_GUI_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MENU  ) ); 
        }
      pInst->vGetCurrentMenu(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_MENU | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_GUI__vGetCurrentOverlay(GUI_String *out_result)
{
    
    clHSA_GUI_Base *pInst=clHSA_GUI_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_OVERLAY  ) ); 
        }
      pInst->vGetCurrentOverlay(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_OVERLAY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

slword HSA_GUI__slwGetIntegerVariable(ulword ulwVariableID)
{
    slword ret = 0;
    clHSA_GUI_Base *pInst=clHSA_GUI_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_INTEGER_VARIABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwVariableID); 
        }
      ret=pInst->slwGetIntegerVariable(ulwVariableID);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_INTEGER_VARIABLE | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

void HSA_GUI__vGetStringVariable(GUI_String *out_result, ulword ulwVariableID)
{
    
    clHSA_GUI_Base *pInst=clHSA_GUI_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_STRING_VARIABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwVariableID); 
        }
      pInst->vGetStringVariable(out_result, ulwVariableID);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_STRING_VARIABLE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_GUI__vResetMenuPositions( )
{
    
    clHSA_GUI_Base *pInst=clHSA_GUI_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__RESET_MENU_POSITIONS  ) ); 
        }
      pInst->vResetMenuPositions();

    }
}

void HSA_GUI__vSetBooleanVariable(ulword ulwVariableID, tbool blValue)
{
    
    clHSA_GUI_Base *pInst=clHSA_GUI_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__SET_BOOLEAN_VARIABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwVariableID); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__SET_BOOLEAN_VARIABLE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blValue); 
        }
      pInst->vSetBooleanVariable(ulwVariableID, blValue);

    }
}

void HSA_GUI__vSetIntegerVariable(ulword ulwVariableID, slword slwValue)
{
    
    clHSA_GUI_Base *pInst=clHSA_GUI_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__SET_INTEGER_VARIABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwVariableID); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__SET_INTEGER_VARIABLE | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwValue); 
        }
      pInst->vSetIntegerVariable(ulwVariableID, slwValue);

    }
}

void HSA_GUI__vSetStringVariable(ulword ulwVariableID, const GUI_String * Value)
{
    
    clHSA_GUI_Base *pInst=clHSA_GUI_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__SET_STRING_VARIABLE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwVariableID); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__SET_STRING_VARIABLE | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)Value->ulwLen_+1, Value->pubBuffer_);
         }
      pInst->vSetStringVariable(ulwVariableID,  Value);

    }
}

ulword HSA_GUI__ulwGetTextColorMode( )
{
    ulword ret = 0;
    clHSA_GUI_Base *pInst=clHSA_GUI_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_TEXT_COLOR_MODE  ) ); 
        }
      ret=pInst->ulwGetTextColorMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_TEXT_COLOR_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_GUI__vGetColorCodeString(GUI_String *out_result, ulword ulwTextType)
{
    
    clHSA_GUI_Base *pInst=clHSA_GUI_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_COLOR_CODE_STRING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwTextType); 
        }
      pInst->vGetColorCodeString(out_result, ulwTextType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_GUI), (tU16)(HSA_API_ENTRYPOINT__GET_COLOR_CODE_STRING | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

#ifdef __cplusplus
}
#endif

