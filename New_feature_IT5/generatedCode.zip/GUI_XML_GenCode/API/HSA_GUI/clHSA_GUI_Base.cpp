/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_GUI_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_GUI/clHSA_GUI_Base.h"

clHSA_GUI_Base* clHSA_GUI_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_GUI_Base.cpp.trc.h"
#endif


/**
 * Method: blGetBooleanVariable
  * Get the content of a boolean GUI-Variable
  * B1
 */
tbool clHSA_GUI_Base::blGetBooleanVariable(ulword ulwVariableID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwVariableID);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_GUI::blGetBooleanVariable not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentMenu
  * Check which of the Menu is currently active
  * B1
 */
void clHSA_GUI_Base::vGetCurrentMenu(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_GUI::vGetCurrentMenu not implemented"));
   
}

/**
 * Method: vGetCurrentOverlay
  * Check which of the Overlay is currently active
  * B1
 */
void clHSA_GUI_Base::vGetCurrentOverlay(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_GUI::vGetCurrentOverlay not implemented"));
   
}

/**
 * Method: slwGetIntegerVariable
  * Get the content of an integer GUI-Variable
  * B1
 */
slword clHSA_GUI_Base::slwGetIntegerVariable(ulword ulwVariableID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwVariableID);  // for Lint 

   ETG_TRACE_USR4(("function slword clHSA_GUI::slwGetIntegerVariable not implemented"));
   return 0;
}

/**
 * Method: vGetStringVariable
  * Get the content of a string GUI-Variable
  * B1
 */
void clHSA_GUI_Base::vGetStringVariable(GUI_String *out_result, ulword ulwVariableID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwVariableID);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_GUI::vGetStringVariable not implemented"));
   
}

/**
 * Method: vResetMenuPositions
  * Resets the menu. API call for Down transitions
  * C
 */
void clHSA_GUI_Base::vResetMenuPositions( )
{
   
   ETG_TRACE_USR4(("function void clHSA_GUI::vResetMenuPositions not implemented"));
   
}

/**
 * Method: vSetBooleanVariable
  * Set the content of a GUI-Variable
  * B1
 */
void clHSA_GUI_Base::vSetBooleanVariable(ulword ulwVariableID, tbool blValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwVariableID);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_GUI::vSetBooleanVariable not implemented"));
   
}

/**
 * Method: vSetIntegerVariable
  * Set the content of a GUI-Variable
  * B1
 */
void clHSA_GUI_Base::vSetIntegerVariable(ulword ulwVariableID, slword slwValue)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwVariableID);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwValue);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_GUI::vSetIntegerVariable not implemented"));
   
}

/**
 * Method: vSetStringVariable
  * Set the content of a GUI-Variable
  * B1
 */
void clHSA_GUI_Base::vSetStringVariable(ulword ulwVariableID, const GUI_String * Value)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwVariableID);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( Value);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_GUI::vSetStringVariable not implemented"));
   
}

/**
 * Method: ulwGetTextColorMode
  * returns if day or night mode is currently visible
  * NISSAN_LCN2KAI
 */
ulword clHSA_GUI_Base::ulwGetTextColorMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_GUI::ulwGetTextColorMode not implemented"));
   return 0;
}

/**
 * Method: vGetColorCodeString
  * get the color information as a character code
  * NISSAN_LCN2KAI
 */
void clHSA_GUI_Base::vGetColorCodeString(GUI_String *out_result, ulword ulwTextType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwTextType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_GUI::vGetColorCodeString not implemented"));
   
}

