/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_GUI_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_GUI_Base_H
#define _clHSA_GUI_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_GUI_Base : public clHSA_Base
{
public:

    static clHSA_GUI_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_GUI_Base()        {}

    virtual tbool blGetBooleanVariable(ulword ulwVariableID);

    virtual void vGetCurrentMenu(GUI_String *out_result);

    virtual void vGetCurrentOverlay(GUI_String *out_result);

    virtual slword slwGetIntegerVariable(ulword ulwVariableID);

    virtual void vGetStringVariable(GUI_String *out_result, ulword ulwVariableID);

    virtual void vResetMenuPositions( );

    virtual void vSetBooleanVariable(ulword ulwVariableID, tbool blValue);

    virtual void vSetIntegerVariable(ulword ulwVariableID, slword slwValue);

    virtual void vSetStringVariable(ulword ulwVariableID, const GUI_String * Value);

    virtual ulword ulwGetTextColorMode( );

    virtual void vGetColorCodeString(GUI_String *out_result, ulword ulwTextType);

protected:
    clHSA_GUI_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_GUI_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_GUI_Base_H

