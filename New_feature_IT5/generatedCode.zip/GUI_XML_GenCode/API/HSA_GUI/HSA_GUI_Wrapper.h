/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_GUI_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_GUI_Wrapper_H
#define _HSA_GUI_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: GetBooleanVariable
 * B1
 * NISSAN
 */
tbool HSA_GUI__blGetBooleanVariable(ulword ulwVariableID);

/**
 * Function: GetCurrentMenu
 * B1
 * NISSAN
 */
void HSA_GUI__vGetCurrentMenu(GUI_String *out_result);

/**
 * Function: GetCurrentOverlay
 * B1
 * NISSAN
 */
void HSA_GUI__vGetCurrentOverlay(GUI_String *out_result);

/**
 * Function: GetIntegerVariable
 * B1
 * NISSAN
 */
slword HSA_GUI__slwGetIntegerVariable(ulword ulwVariableID);

/**
 * Function: GetStringVariable
 * B1
 * NISSAN
 */
void HSA_GUI__vGetStringVariable(GUI_String *out_result, ulword ulwVariableID);

/**
 * Function: ResetMenuPositions
 * C
 * NISSAN
 */
void HSA_GUI__vResetMenuPositions( void);

/**
 * Function: SetBooleanVariable
 * B1
 * NISSAN
 */
void HSA_GUI__vSetBooleanVariable(ulword ulwVariableID, tbool blValue);

/**
 * Function: SetIntegerVariable
 * B1
 * NISSAN
 */
void HSA_GUI__vSetIntegerVariable(ulword ulwVariableID, slword slwValue);

/**
 * Function: SetStringVariable
 * B1
 * NISSAN
 */
void HSA_GUI__vSetStringVariable(ulword ulwVariableID, const GUI_String * Value);

/**
 * Function: GetTextColorMode
 * NISSAN_LCN2KAI
 * NISSAN
 */
ulword HSA_GUI__ulwGetTextColorMode( void);

/**
 * Function: GetColorCodeString
 * NISSAN_LCN2KAI
 * NISSAN
 */
void HSA_GUI__vGetColorCodeString(GUI_String *out_result, ulword ulwTextType);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_GUI_H

