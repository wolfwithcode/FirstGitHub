/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Phone_Wrapper_dbg.cpp
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */
 

#include "HSA_Phone_Wrapper_dbg.h"
#include "clHSA_Phone_Base.h"
#include "HSA_Phone_Trace.h"
#include "HSA_Phone_Wrapper.h"




/*************************************************************************
* METHOD:         destructor
* DESCRIPTION:    default destructor. 
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/

clHSA_Phone_Wrapper_dbg::~clHSA_Phone_Wrapper_dbg()
{
    m_poTrace = 0;
} 


/*************************************************************************
* METHOD:         constructor
* DESCRIPTION:    default constructor. member init.
* PARAMETER:      none
* RETURNVALUE:    none
************************************************************************/
clHSA_Phone_Wrapper_dbg::clHSA_Phone_Wrapper_dbg() 
    : m_poTrace(0)
{
   
}

clHSA_Phone_Wrapper_dbg::clHSA_Phone_Wrapper_dbg(void *v)
    : m_poTrace(0)
{
    OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(v);  // make Lint shut up.
}

/*************************************************************************
* METHOD:         bConfigure
* DESCRIPTION:    get pointer to needed modules
* PARAMETER:      
* RETURNVALUE:    
************************************************************************/

tBool clHSA_Phone_Wrapper_dbg::bConfigure( clITrace* poTrace ) 
{
	this->m_poTrace = poTrace;
    return TRUE;
}



tBool clHSA_Phone_Wrapper_dbg::bExecDbgInput ( tU8 **pu8Stream) 
{
	tU16 functionSelectorID;

	// provide 3 dummy params for each param type
	// as there is no function call with more than 2 params this should be sufficient

	tS32 slParam1, slParam2, slParam3, slParam4, slParam5, slParam6;
	tU32 ulParam1, ulParam2, ulParam3, ulParam4, ulParam5, ulParam6;
	tU8  usParam1, usParam2, usParam3, usParam4, usParam5, usParam6;
	GUI_String gsParam1, gsParam2, gsParam3, gsParam4;
	
	// auxiliary buffers for initializing GUI_String params
	ubyte aubBuffer1[255], aubBuffer2[255], aubBuffer3[255], aubBuffer4[255], tmpBuffer[255];
	
	/* for LINT only  -- Start --- */
	
	slParam1=0;
	slParam2=0;
	slParam3=0;
	slParam4=0; 
	slParam5=0;
	slParam6=0;
	ulParam1=0;
	ulParam2=0;
	ulParam3=0;
	ulParam4=0;
	ulParam5=0;
	ulParam6=0;	
	usParam1=0;
	usParam2=0;
	usParam3=0;
	usParam4=0;
	usParam5=0;
	usParam6=0;
	slParam1=slParam1; ulParam1=ulParam1; usParam1=usParam1;
	slParam2=slParam2; ulParam2=ulParam2; usParam2=usParam2;
	slParam3=slParam3; ulParam3=ulParam3; usParam3=usParam3;
	slParam4=slParam4; ulParam4=ulParam4; usParam4=usParam4;
	slParam5=slParam5; ulParam5=ulParam5; usParam5=usParam5;
	slParam6=slParam6; ulParam6=ulParam6; usParam6=usParam6;
	aubBuffer1[0]=0; aubBuffer2[0]=0; aubBuffer3[0]=0; aubBuffer4[0]=0; tmpBuffer[0]=0;
	aubBuffer1[0]=aubBuffer1[0]; aubBuffer2[0]=aubBuffer2[0]; aubBuffer3[0]=aubBuffer3[0]; aubBuffer4[0]=aubBuffer4[0]; tmpBuffer[0]=tmpBuffer[0];
	GUI_String_vInit(&gsParam1, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam2, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam3, tmpBuffer, sizeof(tmpBuffer)); GUI_String_vInit(&gsParam4, tmpBuffer, sizeof(tmpBuffer));
	/* for LINT only  -- End ---   */
	
	// parse the next 2-bytes to obtain the function ID, as defined in .trc-file
	bGetDataFwdStream(pu8Stream, &functionSelectorID);

	switch(functionSelectorID)
	{

        case HSA_API_ENTRYPOINT__UPDATE_SMS_INBOX:

            HSA_Phone__vUpdateSMSInbox();
            break;

        case HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__USER_WORD:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__blGetPhoneBookDetails_UserWord(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_NUMBER:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Phone__vSetNumber(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_NUMBER_TYPE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vSetNumberType(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_BATTERY_LEVEL:

            HSA_Phone__ulwGetBatteryLevel();
            break;

        case HSA_API_ENTRYPOINT__IS_BATTERY_LEVEL_AVAILABLE:

            HSA_Phone__blIsBatteryLevelAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_SHORTCUT_NUMBER_ASSIGNED:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__blIsShortcutNumberAssigned(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SHORTCUT_NUMBERS_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetShortcutNumbersList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_SHORTCUT_NUMBER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam2, aubBuffer2, sizeof(aubBuffer2)); 
            GUI_String_vSetCStr(&gsParam2, tmpBuffer);
            HSA_Phone__vSpellerSetShortcutNumber(ulParam1, &gsParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_COPILOT_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetCopilotList(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__IS_COPILOT_NUMBER_ASSIGNED:

            HSA_Phone__blIsCopilotNumberAssigned();
            break;

        case HSA_API_ENTRYPOINT__GET_CO_PILOT_NAME_OR_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetCoPilotNameOrNumber(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_COPILOT_NUMBER:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vSetCopilotNumber(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_COPILOT_COUNTRY_LIST__COUNT:

            HSA_Phone__ulwGetCopilotCountryList_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_CO_PILOT_LIST__ACTIVE_ITEM_INDEX:

            HSA_Phone__ulwGetCoPilotList_ActiveItemIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_SSPPIN:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetSSPPIN(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_CONFIRM_SSPPIN:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Phone__vSetConfirmSSPPIN(usParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CONNECTED_DEVICE_ADRESS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetConnectedDeviceAdress(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__QS_INIT_QUICK_SEARCH:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vQSInitQuickSearch(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_QS_CURRENT_CHARACTER_GROUP_PH:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetQSCurrentCharacterGroupPH(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_QS_INCREASE_CURRENT_CHARACTER_GROUP_PH:

            HSA_Phone__vSetQSIncreaseCurrentCharacterGroupPH();
            break;

        case HSA_API_ENTRYPOINT__SET_QS_DECREASE_CURRENT_CHARACTER_GROUP_PH:

            HSA_Phone__vSetQSDecreaseCurrentCharacterGroupPH();
            break;

        case HSA_API_ENTRYPOINT__QS_START_SEARCH_PH:

            HSA_Phone__vQSStartSearchPH();
            break;

        case HSA_API_ENTRYPOINT__GET_PHONEBOOK_POSITION:

            HSA_Phone__ulwGetPhonebookPosition();
            break;

        case HSA_API_ENTRYPOINT__IS_BT_AUDIO_PLAYING:

            HSA_Phone__blIsBTAudioPlaying();
            break;

        case HSA_API_ENTRYPOINT__IS_BT_SETUP_VISIBILITY_VISIBLE_AVAILABLE:

            HSA_Phone__blIsBtSetupVisibilityVisibleAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_BT_SETUP_VISIBILITY_INVISIBLE_AVAILABLE:

            HSA_Phone__blIsBtSetupVisibilityInvisibleAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_BT_SETUP_CONNECT_START_AVAILABLE:

            HSA_Phone__blIsBtSetupConnectStartAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_BT_SETUP_DELETE_PAIR_AVAILABLE:

            HSA_Phone__blIsBtSetupDeletePairAvailable();
            break;

        case HSA_API_ENTRYPOINT__GET_DEVICES__IS_A2D_POR_HFP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__ulwGetDevices_IsA2DPorHFP(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__DIAL_NUMBER_BY_ID:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vDialNumberByID(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SPELLER_MATCH_INDEX:

            HSA_Phone__ulwGetSpellerMatchIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_SPELLER_MATCH_FOUND_RESULT:

            HSA_Phone__ulwGetSpellerMatchFoundResult();
            break;

        case HSA_API_ENTRYPOINT__IS_SPELLER_MATCH_FOUND:

            HSA_Phone__blIsSpellerMatchFound();
            break;

        case HSA_API_ENTRYPOINT__IS_VOICE_RECOGNITION_FUNCTION_AVAILABLE:

            HSA_Phone__blIsVoiceRecognitionFunctionAvailable();
            break;

        case HSA_API_ENTRYPOINT__GET_VOICE_RECOGNITION_STATE:

            HSA_Phone__blGetVoiceRecognitionState();
            break;

        case HSA_API_ENTRYPOINT__SET_VOICE_RECOGNITION_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vSetVoiceRecognitionState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_VOICE_RECOGNITION_RESULT:

            HSA_Phone__ulwGetVoiceRecognitionResult();
            break;

        case HSA_API_ENTRYPOINT__GET_SIRI_STATUS:

            HSA_Phone__ulwGetSiriStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_SIRI_OR_VA_SWC_SETTING:

            HSA_Phone__ulwGetSiriOrVA_SWCSetting();
            break;

        case HSA_API_ENTRYPOINT__SET_SIRI_OR_VA_SWC_SETTING:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vSetSiriOrVA_SWCSetting(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_BT_MODE:

            HSA_Phone__vToggleBTMode();
            break;

        case HSA_API_ENTRYPOINT__GET_BT_MODE:

            HSA_Phone__ulwGetBTMode();
            break;

        case HSA_API_ENTRYPOINT__ACCEPT_CALL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__blAcceptCall(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ACTIVATE_CALL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__blActivateCall(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__ADD_TO_CONFERENCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vAddToConference(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__CANCEL_PAIRING_PROCESS:

            HSA_Phone__vCancelPairingProcess();
            break;

        case HSA_API_ENTRYPOINT__CHECK_PIN:

            HSA_Phone__vCheckPIN();
            break;

        case HSA_API_ENTRYPOINT__CLEAR_MISSED_CALL_INDICATION:

            HSA_Phone__vClearMissedCallIndication();
            break;

        case HSA_API_ENTRYPOINT__CONNECT_DEVICE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vConnectDevice(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DELETE_PAIRED_DEVICE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__blDeletePairedDevice(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__DIAL_EMERGENCY_NUMBER:

            HSA_Phone__vDialEmergencyNumber();
            break;

        case HSA_API_ENTRYPOINT__DIAL_NUMBER:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Phone__vDialNumber(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__DIAL_NUMBER_NAME:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam2, aubBuffer2, sizeof(aubBuffer2)); 
            GUI_String_vSetCStr(&gsParam2, tmpBuffer);
            HSA_Phone__vDialNumberName(&gsParam1, &gsParam2);
            break;

        case HSA_API_ENTRYPOINT__DIAL_NUMBER_FOR_POI:

            HSA_Phone__vDialNumberForPOI();
            break;

        case HSA_API_ENTRYPOINT__DIAL_COPILOT_NUMBER:

            HSA_Phone__vDialCopilotNumber();
            break;

        case HSA_API_ENTRYPOINT__GET_POI_NUMBER_AVAILABILITY:

            HSA_Phone__ulwGetPOINumberAvailability();
            break;

        case HSA_API_ENTRYPOINT__GET_REDIAL_NUMBER_AVAILABLE:

            HSA_Phone__ulwGetRedialNumberAvailable();
            break;

        case HSA_API_ENTRYPOINT__REDIAL:

            HSA_Phone__vRedial();
            break;

        case HSA_API_ENTRYPOINT__GET_OUTGOING_CALL_SOURCE:

            HSA_Phone__ulwGetOutgoingCallSource();
            break;

        case HSA_API_ENTRYPOINT__GET_MAX_LIMIT_OF_PB_ENTRIES:

            HSA_Phone__ulwGetMaxLimitOfPBEntries();
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_PHONEBOOK_SOURCE:

            HSA_Phone__ulwGetActivePhonebookSource();
            break;

        case HSA_API_ENTRYPOINT__GET_PB_NUMBER_OF_DOWNLOADED_ENTRIES:

            HSA_Phone__ulwGetPBNumberOfDownloadedEntries();
            break;

        case HSA_API_ENTRYPOINT__GET_BT_DEVICES__NAMES:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetBTDevices_Names(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_BT_PASSKEY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetBTPasskey(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_DIVERT_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__ulwGetCallBarListCallBarDivertState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_MAIN_TEXT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetCallBarListCallBarMainText(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetCallBarListCallBarName(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetCallBarListCallBarNumber(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_TEXT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__ulwGetCallBarListCallBarText(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_DURATION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetCallBarListCallDuration(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_STATE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__ulwGetCallBarListCallState(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_ITEM__COUNT:

            HSA_Phone__ulwGetCallBarListItem_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_CONNECTED_DEVICE_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetConnectedDeviceName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CONNECTING_PROCESS_STATE:

            HSA_Phone__ulwGetConnectingProcessState();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_DATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetCurrentDate(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_PHONEBOOK_SORTING_CRITERIA:

            HSA_Phone__ulwGetCurrentPhonebookSortingCriteria();
            break;

        case HSA_API_ENTRYPOINT__GET_DEVICES__IS_A2DP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__ulwGetDevices_IsA2DP(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DEVICES__IS_HFP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__ulwGetDevices_IsHFP(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DEVICE_STATE:

            HSA_Phone__ulwGetDeviceState();
            break;

        case HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__COUNT:

            HSA_Phone__ulwGetDialedNumbersList_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__DATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetDialedNumbersList_Date(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__ICON:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__ulwGetDialedNumbersList_Icon(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetDialedNumbersList_Name(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetDialedNumbersList_Number(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__NAME_OR_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetDialedNumbersList_NameOrNumber(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__TIME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetDialedNumbersList_Time(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_GSM_INTENSITY:

            HSA_Phone__ulwGetGSMIntensity();
            break;

        case HSA_API_ENTRYPOINT__GET_HANDSFREE_STATE:

            HSA_Phone__blGetHandsfreeState();
            break;

        case HSA_API_ENTRYPOINT__GET_HANDSFREE_OPTION_STATE:

            HSA_Phone__ulwGetHandsfreeOptionState();
            break;

        case HSA_API_ENTRYPOINT__GET_MICRO_MUTE_STATE:

            HSA_Phone__blGetMicroMuteState();
            break;

        case HSA_API_ENTRYPOINT__GET_MICRO_MUTE_OPTION_STATE:

            HSA_Phone__ulwGetMicroMuteOptionState();
            break;

        case HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__COUNT:

            HSA_Phone__ulwGetMissedCallsList_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__DATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetMissedCallsList_Date(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__ICON:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__ulwGetMissedCallsList_Icon(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetMissedCallsList_Name(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetMissedCallsList_Number(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__NAME_OR_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetMissedCallsList_NameOrNumber(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__TIME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetMissedCallsList_Time(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_NEW_MISSED_CALLS__COUNT:

            HSA_Phone__blGetNewMissedCalls_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_PAIRED_DEVICES__ACTIVE_ITEM_INDEX:

            HSA_Phone__slwGetPairedDevices_ActiveItemIndex();
            break;

        case HSA_API_ENTRYPOINT__GET_PAIRED_DEVICES__COUNT:

            HSA_Phone__ulwGetPairedDevices_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_PAIRED_DEVICES__NAMES:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetPairedDevices_Names(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_PAIRING_PROCESS_STATE:

            HSA_Phone__ulwGetPairingProcessState();
            break;

        case HSA_API_ENTRYPOINT__GET_PHONE_BOOK:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2);
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Phone__vGetPhoneBook(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_PHONE_BOOK__COUNT:

            HSA_Phone__ulwGetPhoneBook_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_PHONE_BOOK__DETAILS_ICON:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__ulwGetPhoneBook_DetailsIcon(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SMS_PHONEBOOK_ICON__TYPE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetSMSPhonebookIcon_Type(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_PHONE_BOOK__ICON_TYPE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__ulwGetPhoneBook_IconType(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_PHONE_BOOK__NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetPhoneBook_Name(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_PHONE_BOOK_AVAILABILITY:

            HSA_Phone__ulwGetPhoneBookAvailability();
            break;

        case HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__COUNT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__ulwGetPhoneBookDetails_Count(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetPhoneBookDetails_Name(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetPhoneBookDetails_Number(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__TYPE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__ulwGetPhoneBookDetails_Type(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_PHONE_NUMBER_FOR_LIST_ENTRY:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Phone__vGetPhoneNumberForListEntry(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__GET_PROVIDER_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetProviderName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_REDIAL_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetRedialNumber(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_REDIAL_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetRedialName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_LAST_DIALLED__NAME_OR_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetLastDialled_NameOrNumber(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_PROVIDER_STATE:

            HSA_Phone__ulwGetProviderState();
            break;

        case HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__COUNT:

            HSA_Phone__ulwGetReceivedCallsList_Count();
            break;

        case HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__DATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetReceivedCallsList_Date(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__ICON:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetReceivedCallsList_Icon(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__ICON_NEW:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__ulwGetReceivedCallsList_Icon_new(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetReceivedCallsList_Name(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetReceivedCallsList_Number(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__NAME_OR_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetReceivedCallsList_NameOrNumber(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__TIME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetReceivedCallsList_Time(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_RETURN_TO_SYSTEM:

            HSA_Phone__blGetReturnToSystem();
            break;

        case HSA_API_ENTRYPOINT__GET_SIM_STATE:

            HSA_Phone__ulwGetSIMState();
            break;

        case HSA_API_ENTRYPOINT__GET_SPELLER_ENTRY_FIELD:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetSpellerEntryField(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SPELLER_ENTRY_FIELD_NAR:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetSpellerEntryFieldNAR(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_VISIBILITY:

            HSA_Phone__blGetVisibility();
            break;

        case HSA_API_ENTRYPOINT__GET_YESTERDAY_DATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetYesterdayDate(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__HANG_UP:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vHangUp(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__HOLD_CALL:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vHoldCall(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_BT_ACTIVE:

            HSA_Phone__blIsBTActive();
            break;

        case HSA_API_ENTRYPOINT__IS_CALL_PRESENT:

            HSA_Phone__ulwIsCallPresent();
            break;

        case HSA_API_ENTRYPOINT__IS_EMERGENCY_CALL_PRESENT:

            HSA_Phone__ulwIsEmergencyCallPresent();
            break;

        case HSA_API_ENTRYPOINT__IS_SECOND_INCOMING_CALL_PRESENT:

            HSA_Phone__blIsSecondIncomingCallPresent();
            break;

        case HSA_API_ENTRYPOINT__IS_GSM_MODULE_CONNECTED:

            HSA_Phone__blIsGSMModuleConnected();
            break;

        case HSA_API_ENTRYPOINT__IS_HANDSFREE_OPTION_AVAILABLE:

            HSA_Phone__blIsHandsfreeOptionAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_INTERNAL_GSM_MODULE_AVAILABLE:

            HSA_Phone__blIsInternalGSMModuleAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_LOAD_PHONE_BOOK_AVAILABLE:

            HSA_Phone__blIsLoadPhoneBookAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_MICRO_MUTE_OPTION_AVAILABLE:

            HSA_Phone__blIsMicroMuteOptionAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_REDIAL_NUMBER_AVAILABLE:

            HSA_Phone__blIsRedialNumberAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_REDIAL_NAME_AVAILABLE:

            HSA_Phone__blIsRedialNameAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_PAIRED_DEVICES_LIST_FULL:

            HSA_Phone__blIsPairedDevicesListFull();
            break;

        case HSA_API_ENTRYPOINT__IS_PHONE_MUTE_ACTIVE:

            HSA_Phone__ulwIsPhoneMuteActive();
            break;

        case HSA_API_ENTRYPOINT__IS_LIMITED_PHONE_MODE_ACTIVE:

            HSA_Phone__blIsLimitedPhoneModeActive();
            break;

        case HSA_API_ENTRYPOINT__IS_PIN_SPELLER_SUPPORTED:

            HSA_Phone__blIsPINSpellerSupported();
            break;

        case HSA_API_ENTRYPOINT__IS_SET_PHONE_BOOK_SORTING_AVAILABLE:

            HSA_Phone__blIsSetPhoneBookSortingAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_SET_PHONE_BOOK_SOURCE_AVAILABLE:

            HSA_Phone__blIsSetPhoneBookSourceAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_SIGNAL_STRENGTH_AVAILABLE:

            HSA_Phone__blIsSignalStrengthAvailable();
            break;

        case HSA_API_ENTRYPOINT__IS_USER_CONNECTED:

            HSA_Phone__blIsUserConnected();
            break;

        case HSA_API_ENTRYPOINT__PREPARE_SPELLER_ENTRY_FIELD:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vPrepareSpellerEntryField(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_ACTIVE_PHONE_BOOK_SOURCE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vSetActivePhoneBookSource(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_INITIAL_FOCUS_POSITION_IN_PHONEBOOK:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vSetInitialFocusPositionInPhonebook(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_PHONEBOOK_SORTING_CRITERIA:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vSetPhonebookSortingCriteria(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_RETURN_TO_SYSTEM:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 

            HSA_Phone__vSetReturnToSystem(usParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_VISIBILITY:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vSetVisibility(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_DIAL_NUMBER:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Phone__vSpellerDialNumber(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_DISCARD_INPUT:

            HSA_Phone__vSpellerDiscardInput();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_DELETE_INPUT:

            HSA_Phone__vSpellerDeleteInput();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_ENABLE_MATCH_SPELLER:

            HSA_Phone__blSpellerEnableMatchSpeller();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS:

            HSA_Phone__ulwSpellerGetCursorPos();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_HIGHLIGHTED_TEXT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vSpellerGetHighlightedText(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_GET_LETTER_FUNCTION:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vSpellerGetLetterFunction(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION:

            HSA_Phone__blSpellerInvertGetLetterFunction();
            break;

        case HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_FIRST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam2); 

            HSA_Phone__vSpellerMatchGetFirst(&gsParam1, slParam2);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_LIST:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2);
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam3); 

            HSA_Phone__vSpellerMatchGetList(&gsParam1, ulParam2, ulParam3);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SEND_PHONEBOOK_SEARCH_STRING:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Phone__vSpellerSendPhonebookSearchString(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SEND_PIN_INPUT:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Phone__vSpellerSendPINInput(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_BT_PASSKEY:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Phone__vSpellerSetBTPasskey(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_CHARACTER:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Phone__vSpellerSetCharacter(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_MAX_CHAR_COUNT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &slParam1); 

            HSA_Phone__vSpellerSetMaxCharCount(slParam1);
            break;

        case HSA_API_ENTRYPOINT__START_PHONEBOOK_DOWNLOAD:

            HSA_Phone__vStartPhonebookDownload();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_MICRO_MUTE:

            HSA_Phone__vToggleMicroMute();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_PRIVATE_HANDS_FREE_MODE:

            HSA_Phone__vTogglePrivateHandsFreeMode();
            break;

        case HSA_API_ENTRYPOINT__LOAD_PHONE_BOOK_DETAILS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vLoadPhoneBookDetails(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_PHONE_IN_CONNECTING_PHASE:

            HSA_Phone__blIsPhoneInConnectingPhase();
            break;

        case HSA_API_ENTRYPOINT__GET_SMS_INBOX_UPDATE_STATUS:

            HSA_Phone__ulwGetSMSInboxUpdateStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_SMS_MESSAGES_COUNT:

            HSA_Phone__ulwGetSMSMessagesCount();
            break;

        case HSA_API_ENTRYPOINT__IS_PREDEFINED_SMS_PARAGRAPHS_SUPPORTED:

            HSA_Phone__blIsPredefinedSMSParagraphsSupported();
            break;

        case HSA_API_ENTRYPOINT__IS_PREDEFINED_MESSAGE_PRESENT:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__blIsPredefinedMessagePresent(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_PREDEFINED_SMS_PARAGRAPHS_COUNT:

            HSA_Phone__ulwGetPredefinedSMSParagraphsCount();
            break;

        case HSA_API_ENTRYPOINT__GET_PREDEFINED_SMS_PARAGRAPHS:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetPredefinedSMSParagraphs(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SMS_SUBJECT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetSMSSubject(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__SET_PREDEFINED_MSG_INDEX:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vSetPredefinedMsgIndex(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_INBOX_MSG_INDEX:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vSetInboxMsgIndex(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__SPELLER_SET_PREDEFINED_MSG:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);
            HSA_Phone__vSpellerSetPredefinedMsg(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__DELETE_PREDEFINED_MESSAGE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vDeletePredefinedMessage(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__IS_NEW_SMS_INDICATION_SUPPORTED:

            HSA_Phone__blIsNewSMSIndicationSupported();
            break;

        case HSA_API_ENTRYPOINT__IS_RESET_SMS_INDICATION_SUPPORTED:

            HSA_Phone__blIsResetSMSIndicationSupported();
            break;

        case HSA_API_ENTRYPOINT__IS_READ_SMS_SUPPORTED:

            HSA_Phone__blIsReadSMSSupported();
            break;

        case HSA_API_ENTRYPOINT__IS_LIST_SMS_SUPPORTED:

            HSA_Phone__blIsListSMSSupported();
            break;

        case HSA_API_ENTRYPOINT__IS_SET_SMS_MSG_STATUS_SUPPORTED:

            HSA_Phone__blIsSetSMSMsgStatusSupported();
            break;

        case HSA_API_ENTRYPOINT__IS_SEND_SMS_SUPPORTED:

            HSA_Phone__blIsSendSMSSupported();
            break;

        case HSA_API_ENTRYPOINT__RESET_NEW_SMS_INDICATION:

            HSA_Phone__vResetNewSMSIndication();
            break;

        case HSA_API_ENTRYPOINT__GET_SMS_MESSAGE_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__ulwGetSMSMessageStatus(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SMS_DATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetSMSDate(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SMS_TIME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetSMSTime(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SMS__SENDER_TEL_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetSMS_SenderTelNumber(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SMS__SENDER_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetSMS_SenderName(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SMS__SENDER_NAME_OR_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetSMS_SenderNameOrNumber(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__READ_SMS_MESSAGE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vReadSMSMessage(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_SMS_MESSAGE_CONTENT:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetSMSMessageContent(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__SET_SMS_MESSAGE_STATUS:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vSetSMSMessageStatus(ulParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__MARK_SMS_AS_READ:

            HSA_Phone__vMarkSMSAsRead();
            break;

        case HSA_API_ENTRYPOINT__SEND_SMS_MESSAGE:
            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1)); 
            GUI_String_vSetCStr(&gsParam1, tmpBuffer);            // parse the required string from ttfis stream
            bGetStringDataFwdStream(pu8Stream, (tChar*)tmpBuffer, 32);
            GUI_String_vInit(&gsParam2, aubBuffer2, sizeof(aubBuffer2)); 
            GUI_String_vSetCStr(&gsParam2, tmpBuffer);
            HSA_Phone__vSendSMSMessage(&gsParam1, &gsParam2);
            break;

        case HSA_API_ENTRYPOINT__LOAD_FIRST_SMS_FROM_INBOX:

            HSA_Phone__vLoadFirstSMSFromInbox();
            break;

        case HSA_API_ENTRYPOINT__LOAD_NEXT_SMS_MESSAGE:

            HSA_Phone__vLoadNextSMSMessage();
            break;

        case HSA_API_ENTRYPOINT__LOAD_PREVIOUS_SMS_MESSAGE:

            HSA_Phone__vLoadPreviousSMSMessage();
            break;

        case HSA_API_ENTRYPOINT__IS_START_OF_SMS_LIST_REACHED:

            HSA_Phone__blIsStartOfSMSListReached();
            break;

        case HSA_API_ENTRYPOINT__IS_END_OF_SMS_LIST_REACHED:

            HSA_Phone__blIsEndOfSMSListReached();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_SMS_MESSAGE_INDEX:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetCurrentSMSMessageIndex(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_NUMBER_OF_UNREAD_MESSAGES:

            HSA_Phone__ulwGetNumberOfUnreadMessages();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_SMS__MESSAGE_STATUS:

            HSA_Phone__ulwGetCurrentSMS_MessageStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_SMS__DATE:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetCurrentSMS_Date(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_SMS__TIME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetCurrentSMS_Time(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_SMS__SENDER_TEL_NUMBER:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetCurrentSMS_SenderTelNumber(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_CURRENT_SMS__SENDER_NAME:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));

            HSA_Phone__vGetCurrentSMS_SenderName(&gsParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_READ_SMS_MESSAGE_RESULT:

            HSA_Phone__ulwGetReadSMSMessageResult();
            break;

        case HSA_API_ENTRYPOINT__GET_SEND_SMS_SENDING_STATUS:

            HSA_Phone__ulwGetSendSMSSendingStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_SMS_SET_PREDEFINED_MESSAGE_RESULT:

            HSA_Phone__ulwGetSMSSetPredefinedMessageResult();
            break;

        case HSA_API_ENTRYPOINT__GET_AUTO_REPLY_SMS_COUNT:

            HSA_Phone__ulwGetAutoReplySMSCount();
            break;

        case HSA_API_ENTRYPOINT__GET_AUTO_REPLY_MESSAGES:
            GUI_String_vInit(&gsParam1, aubBuffer1, sizeof(aubBuffer1));
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vGetAutoReplyMessages(&gsParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_ACTIVE_AUTO_REPLY_INDEX:

            HSA_Phone__ulwGetActiveAutoReplyIndex();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_SMS_SERVICE_STATUS:

            HSA_Phone__vToggleSMSServiceStatus();
            break;

        case HSA_API_ENTRYPOINT__GET_SMS_SERVICE_STATUS:

            HSA_Phone__blGetSMSServiceStatus();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_SMS_DISPLAY_SETTING:

            HSA_Phone__vToggleSMSDisplaySetting();
            break;

        case HSA_API_ENTRYPOINT__GET_SMS_DISPLAY_SETTING:

            HSA_Phone__ulwGetSMSDisplaySetting();
            break;

        case HSA_API_ENTRYPOINT__ND_STREAMING_STATUS:

            HSA_Phone__ulwNDStreamingStatus();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_INCOMING_CALL_DISPLAY_SETTING:

            HSA_Phone__vToggleIncomingCallDisplaySetting();
            break;

        case HSA_API_ENTRYPOINT__GET_INCOMING_CALL_DISPLAY_SETTING:

            HSA_Phone__ulwGetIncomingCallDisplaySetting();
            break;

        case HSA_API_ENTRYPOINT__TOGGLE_VEHICLE_SIGNATURE:

            HSA_Phone__vToggleVehicleSignature();
            break;

        case HSA_API_ENTRYPOINT__GET_VEHICLE_SIGNATURE_STATUS:

            HSA_Phone__blGetVehicleSignatureStatus();
            break;

        case HSA_API_ENTRYPOINT__SET_AUTO_REPLY_MESSAGE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &usParam1); 
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam2); 

            HSA_Phone__vSetAutoReplyMessage(usParam1, ulParam2);
            break;

        case HSA_API_ENTRYPOINT__GET_SMS_AUTO_REPLY_FUNCTION_STATUS:

            HSA_Phone__blGetSMSAutoReplyFunctionStatus();
            break;

        case HSA_API_ENTRYPOINT__REPLACE_PAIRED_DEVICE:
            // parse the required param from ttfis stream
            bGetDataFwdStream(pu8Stream, &ulParam1); 

            HSA_Phone__vReplacePairedDevice(ulParam1);
            break;

        case HSA_API_ENTRYPOINT__GET_REPLACE_PAIRED_DEVICE_PROCESS_STATE:

            HSA_Phone__ulwGetReplacePairedDeviceProcessState();
            break;

		default:
			if (NULL != this->m_poTrace)
			{
				this->m_poTrace->vTrace(TR_LEVEL_HMI_ERROR,
					TR_CLASS_HMI_HSA_MNGR,
						"unknown API call with invalid ID:%X - (maybe API version conflict?)", functionSelectorID);
			}
	}
	return TRUE;
}

