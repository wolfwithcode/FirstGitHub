/*<<< auto-generated file. Do not edit. >>>*/

/**
  *  FILE:         clHSA_Phone_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _clHSA_Phone_Base_H
#define _clHSA_Phone_Base_H

#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#include "API_Impl/clHSA_Base.h"

class clHSA_Phone_Base : public clHSA_Base
{
public:

    static clHSA_Phone_Base *getInstance()		{return sm_pInstance;}


    virtual ~clHSA_Phone_Base()        {}

    virtual void vUpdateSMSInbox( );

    virtual tbool blGetPhoneBookDetails_UserWord(ulword ulwListEntryNr);

    virtual void vSetNumber(const GUI_String * Number);

    virtual void vSetNumberType(ulword ulwNumberType);

    virtual ulword ulwGetBatteryLevel( );

    virtual tbool blIsBatteryLevelAvailable( );

    virtual tbool blIsShortcutNumberAssigned(ulword ulwListEntryNr);

    virtual void vGetShortcutNumbersList(GUI_String *out_result, ulword ulwIndex);

    virtual void vSpellerSetShortcutNumber(ulword ulwIndex, const GUI_String * Number);

    virtual void vGetCopilotList(GUI_String *out_result, ulword ulwListEntryNr);

    virtual tbool blIsCopilotNumberAssigned( );

    virtual void vGetCoPilotNameOrNumber(GUI_String *out_result);

    virtual void vSetCopilotNumber(ulword ulwIndex);

    virtual ulword ulwGetCopilotCountryList_Count( );

    virtual ulword ulwGetCoPilotList_ActiveItemIndex( );

    virtual void vGetSSPPIN(GUI_String *out_result);

    virtual void vSetConfirmSSPPIN(tbool blSSPPINConfirmation);

    virtual void vGetConnectedDeviceAdress(GUI_String *out_result);

    virtual void vQSInitQuickSearch(ulword ulwListPos);

    virtual void vGetQSCurrentCharacterGroupPH(GUI_String *out_result);

    virtual void vSetQSIncreaseCurrentCharacterGroupPH( );

    virtual void vSetQSDecreaseCurrentCharacterGroupPH( );

    virtual void vQSStartSearchPH( );

    virtual ulword ulwGetPhonebookPosition( );

    virtual tbool blIsBTAudioPlaying( );

    virtual tbool blIsBtSetupVisibilityVisibleAvailable( );

    virtual tbool blIsBtSetupVisibilityInvisibleAvailable( );

    virtual tbool blIsBtSetupConnectStartAvailable( );

    virtual tbool blIsBtSetupDeletePairAvailable( );

    virtual ulword ulwGetDevices_IsA2DPorHFP(ulword ulwList, ulword ulwListEntryNr);

    virtual void vDialNumberByID(ulword ulwListEntryNbr);

    virtual ulword ulwGetSpellerMatchIndex( );

    virtual ulword ulwGetSpellerMatchFoundResult( );

    virtual tbool blIsSpellerMatchFound( );

    virtual tbool blIsVoiceRecognitionFunctionAvailable( );

    virtual tbool blGetVoiceRecognitionState( );

    virtual void vSetVoiceRecognitionState(ulword ulwRecognitionstate);

    virtual ulword ulwGetVoiceRecognitionResult( );

    virtual ulword ulwGetSiriStatus( );

    virtual ulword ulwGetSiriOrVA_SWCSetting( );

    virtual void vSetSiriOrVA_SWCSetting(ulword ulwVRSetting);

    virtual void vToggleBTMode( );

    virtual ulword ulwGetBTMode( );

    virtual tbool blAcceptCall(ulword ulwitemID);

    virtual tbool blActivateCall(ulword ulwitemID);

    virtual void vAddToConference(ulword ulwitemID);

    virtual void vCancelPairingProcess( );

    virtual void vCheckPIN( );

    virtual void vClearMissedCallIndication( );

    virtual void vConnectDevice(ulword ulwListEntryNr);

    virtual tbool blDeletePairedDevice(ulword ulwListEntryNr);

    virtual void vDialEmergencyNumber( );

    virtual void vDialNumber(const GUI_String * Number);

    virtual void vDialNumberName(const GUI_String * Number, const GUI_String * Name);

    virtual void vDialNumberForPOI( );

    virtual void vDialCopilotNumber( );

    virtual ulword ulwGetPOINumberAvailability( );

    virtual ulword ulwGetRedialNumberAvailable( );

    virtual void vRedial( );

    virtual ulword ulwGetOutgoingCallSource( );

    virtual ulword ulwGetMaxLimitOfPBEntries( );

    virtual ulword ulwGetActivePhonebookSource( );

    virtual ulword ulwGetPBNumberOfDownloadedEntries( );

    virtual void vGetBTDevices_Names(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetBTPasskey(GUI_String *out_result);

    virtual ulword ulwGetCallBarListCallBarDivertState(ulword ulwListEntryNr);

    virtual void vGetCallBarListCallBarMainText(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetCallBarListCallBarName(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetCallBarListCallBarNumber(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetCallBarListCallBarText(ulword ulwListEntryNr);

    virtual void vGetCallBarListCallDuration(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetCallBarListCallState(ulword ulwListEntryNr);

    virtual ulword ulwGetCallBarListItem_Count( );

    virtual void vGetConnectedDeviceName(GUI_String *out_result);

    virtual ulword ulwGetConnectingProcessState( );

    virtual void vGetCurrentDate(GUI_String *out_result);

    virtual ulword ulwGetCurrentPhonebookSortingCriteria( );

    virtual ulword ulwGetDevices_IsA2DP(ulword ulwList, ulword ulwListEntryNr);

    virtual ulword ulwGetDevices_IsHFP(ulword ulwList, ulword ulwListEntryNr);

    virtual ulword ulwGetDeviceState( );

    virtual ulword ulwGetDialedNumbersList_Count( );

    virtual void vGetDialedNumbersList_Date(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetDialedNumbersList_Icon(ulword ulwListEntryNr);

    virtual void vGetDialedNumbersList_Name(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetDialedNumbersList_Number(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetDialedNumbersList_NameOrNumber(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetDialedNumbersList_Time(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetGSMIntensity( );

    virtual tbool blGetHandsfreeState( );

    virtual ulword ulwGetHandsfreeOptionState( );

    virtual tbool blGetMicroMuteState( );

    virtual ulword ulwGetMicroMuteOptionState( );

    virtual ulword ulwGetMissedCallsList_Count( );

    virtual void vGetMissedCallsList_Date(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetMissedCallsList_Icon(ulword ulwListEntryNr);

    virtual void vGetMissedCallsList_Name(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetMissedCallsList_Number(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetMissedCallsList_NameOrNumber(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetMissedCallsList_Time(GUI_String *out_result, ulword ulwListEntryNr);

    virtual tbool blGetNewMissedCalls_Count( );

    virtual slword slwGetPairedDevices_ActiveItemIndex( );

    virtual ulword ulwGetPairedDevices_Count( );

    virtual void vGetPairedDevices_Names(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetPairingProcessState( );

    virtual void vGetPhoneBook(GUI_String *out_result, ulword uwArrayIndex, ulword ulwListEntryNr);

    virtual ulword ulwGetPhoneBook_Count( );

    virtual ulword ulwGetPhoneBook_DetailsIcon(ulword ulwListEntryNr);

    virtual void vGetSMSPhonebookIcon_Type(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetPhoneBook_IconType(ulword ulwListEntryNr);

    virtual void vGetPhoneBook_Name(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetPhoneBookAvailability( );

    virtual ulword ulwGetPhoneBookDetails_Count(ulword ulwListEntryNr);

    virtual void vGetPhoneBookDetails_Name(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetPhoneBookDetails_Number(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetPhoneBookDetails_Type(ulword ulwListEntryNr);

    virtual void vGetPhoneNumberForListEntry(GUI_String *out_result, ulword ulwList, ulword ulwListEntryNr);

    virtual void vGetProviderName(GUI_String *out_result);

    virtual void vGetRedialNumber(GUI_String *out_result);

    virtual void vGetRedialName(GUI_String *out_result);

    virtual void vGetLastDialled_NameOrNumber(GUI_String *out_result);

    virtual ulword ulwGetProviderState( );

    virtual ulword ulwGetReceivedCallsList_Count( );

    virtual void vGetReceivedCallsList_Date(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetReceivedCallsList_Icon(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetReceivedCallsList_Icon_new(ulword ulwListEntryNr);

    virtual void vGetReceivedCallsList_Name(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetReceivedCallsList_Number(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetReceivedCallsList_NameOrNumber(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetReceivedCallsList_Time(GUI_String *out_result, ulword ulwListEntryNr);

    virtual tbool blGetReturnToSystem( );

    virtual ulword ulwGetSIMState( );

    virtual void vGetSpellerEntryField(GUI_String *out_result);

    virtual void vGetSpellerEntryFieldNAR(GUI_String *out_result);

    virtual tbool blGetVisibility( );

    virtual void vGetYesterdayDate(GUI_String *out_result);

    virtual void vHangUp(ulword ulwitemID);

    virtual void vHoldCall(ulword ulwitemID);

    virtual tbool blIsBTActive( );

    virtual ulword ulwIsCallPresent( );

    virtual ulword ulwIsEmergencyCallPresent( );

    virtual tbool blIsSecondIncomingCallPresent( );

    virtual tbool blIsGSMModuleConnected( );

    virtual tbool blIsHandsfreeOptionAvailable( );

    virtual tbool blIsInternalGSMModuleAvailable( );

    virtual tbool blIsLoadPhoneBookAvailable( );

    virtual tbool blIsMicroMuteOptionAvailable( );

    virtual tbool blIsRedialNumberAvailable( );

    virtual tbool blIsRedialNameAvailable( );

    virtual tbool blIsPairedDevicesListFull( );

    virtual ulword ulwIsPhoneMuteActive( );

    virtual tbool blIsLimitedPhoneModeActive( );

    virtual tbool blIsPINSpellerSupported( );

    virtual tbool blIsSetPhoneBookSortingAvailable( );

    virtual tbool blIsSetPhoneBookSourceAvailable( );

    virtual tbool blIsSignalStrengthAvailable( );

    virtual tbool blIsUserConnected( );

    virtual void vPrepareSpellerEntryField(const GUI_String * EntryFieldValue, ulword ulwSpeller);

    virtual void vSetActivePhoneBookSource(ulword ulwEntryNr);

    virtual void vSetInitialFocusPositionInPhonebook(ulword ulwIndex);

    virtual void vSetPhonebookSortingCriteria(ulword ulwEntryNr);

    virtual void vSetReturnToSystem(tbool blReturnToSystem);

    virtual void vSetVisibility(ulword ulwVisibility);

    virtual void vSpellerDialNumber(const GUI_String * Number);

    virtual void vSpellerDiscardInput( );

    virtual void vSpellerDeleteInput( );

    virtual tbool blSpellerEnableMatchSpeller( );

    virtual ulword ulwSpellerGetCursorPos( );

    virtual void vSpellerGetHighlightedText(GUI_String *out_result);

    virtual void vSpellerGetLetterFunction(GUI_String *out_result);

    virtual tbool blSpellerInvertGetLetterFunction( );

    virtual void vSpellerMatchGetFirst(GUI_String *out_result, slword slwType);

    virtual void vSpellerMatchGetList(GUI_String *out_result, ulword uwArrayIndex, ulword ulwListEntryNr);

    virtual void vSpellerSendPhonebookSearchString(const GUI_String * InputString);

    virtual void vSpellerSendPINInput(const GUI_String * InputString);

    virtual void vSpellerSetBTPasskey(const GUI_String * Number);

    virtual void vSpellerSetCharacter(const GUI_String * InputString);

    virtual void vSpellerSetMaxCharCount(slword slwCount);

    virtual void vStartPhonebookDownload( );

    virtual void vToggleMicroMute( );

    virtual void vTogglePrivateHandsFreeMode( );

    virtual void vLoadPhoneBookDetails(ulword ulwListEntryNr);

    virtual tbool blIsPhoneInConnectingPhase( );

    virtual ulword ulwGetSMSInboxUpdateStatus( );

    virtual ulword ulwGetSMSMessagesCount( );

    virtual tbool blIsPredefinedSMSParagraphsSupported( );

    virtual tbool blIsPredefinedMessagePresent(ulword ulwListEntryNr);

    virtual ulword ulwGetPredefinedSMSParagraphsCount( );

    virtual void vGetPredefinedSMSParagraphs(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetSMSSubject(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vSetPredefinedMsgIndex(ulword ulwListEntryNr);

    virtual void vSetInboxMsgIndex(ulword ulwListEntryNr);

    virtual void vSpellerSetPredefinedMsg(const GUI_String * Message);

    virtual void vDeletePredefinedMessage(ulword ulwListEntryNr);

    virtual tbool blIsNewSMSIndicationSupported( );

    virtual tbool blIsResetSMSIndicationSupported( );

    virtual tbool blIsReadSMSSupported( );

    virtual tbool blIsListSMSSupported( );

    virtual tbool blIsSetSMSMsgStatusSupported( );

    virtual tbool blIsSendSMSSupported( );

    virtual void vResetNewSMSIndication( );

    virtual ulword ulwGetSMSMessageStatus(ulword ulwListEntryNr);

    virtual void vGetSMSDate(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetSMSTime(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetSMS_SenderTelNumber(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetSMS_SenderName(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vGetSMS_SenderNameOrNumber(GUI_String *out_result, ulword ulwListEntryNr);

    virtual void vReadSMSMessage(ulword ulwListEntryNr);

    virtual void vGetSMSMessageContent(GUI_String *out_result);

    virtual void vSetSMSMessageStatus(ulword ulwListEntryNr, ulword ulwMessageSts);

    virtual void vMarkSMSAsRead( );

    virtual void vSendSMSMessage(const GUI_String * TelNumber, const GUI_String * Message);

    virtual void vLoadFirstSMSFromInbox( );

    virtual void vLoadNextSMSMessage( );

    virtual void vLoadPreviousSMSMessage( );

    virtual tbool blIsStartOfSMSListReached( );

    virtual tbool blIsEndOfSMSListReached( );

    virtual void vGetCurrentSMSMessageIndex(GUI_String *out_result);

    virtual ulword ulwGetNumberOfUnreadMessages( );

    virtual ulword ulwGetCurrentSMS_MessageStatus( );

    virtual void vGetCurrentSMS_Date(GUI_String *out_result);

    virtual void vGetCurrentSMS_Time(GUI_String *out_result);

    virtual void vGetCurrentSMS_SenderTelNumber(GUI_String *out_result);

    virtual void vGetCurrentSMS_SenderName(GUI_String *out_result);

    virtual ulword ulwGetReadSMSMessageResult( );

    virtual ulword ulwGetSendSMSSendingStatus( );

    virtual ulword ulwGetSMSSetPredefinedMessageResult( );

    virtual ulword ulwGetAutoReplySMSCount( );

    virtual void vGetAutoReplyMessages(GUI_String *out_result, ulword ulwListEntryNr);

    virtual ulword ulwGetActiveAutoReplyIndex( );

    virtual void vToggleSMSServiceStatus( );

    virtual tbool blGetSMSServiceStatus( );

    virtual void vToggleSMSDisplaySetting( );

    virtual ulword ulwGetSMSDisplaySetting( );

    virtual ulword ulwNDStreamingStatus( );

    virtual void vToggleIncomingCallDisplaySetting( );

    virtual ulword ulwGetIncomingCallDisplaySetting( );

    virtual void vToggleVehicleSignature( );

    virtual tbool blGetVehicleSignatureStatus( );

    virtual void vSetAutoReplyMessage(tbool blEnable, ulword ulwListEntryNr);

    virtual tbool blGetSMSAutoReplyFunctionStatus( );

    virtual void vReplacePairedDevice(ulword ulwListEntryNr);

    virtual ulword ulwGetReplacePairedDeviceProcessState( );

protected:
    clHSA_Phone_Base(T_EN_HSA_ID en_HSA_ID)     : clHSA_Base(en_HSA_ID)    {}

    static clHSA_Phone_Base *sm_pInstance;

};
#endif  //#ifndef _clHSA_Phone_Base_H

