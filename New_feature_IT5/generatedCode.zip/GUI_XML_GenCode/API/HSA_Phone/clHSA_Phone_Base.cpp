/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         clHSA_Phone_Base
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 */
 
 #include "precompiled.hh"
#include "API/HSA_Phone/clHSA_Phone_Base.h"

clHSA_Phone_Base* clHSA_Phone_Base::sm_pInstance = 0;

#ifdef VARIANT_S_FTR_ENABLE_TRC_GEN
#define ETG_DEFAULT_TRACE_CLASS TR_CLASS_HMI_HSA_MNGR
#include "trcGenProj/Header/clHSA_Phone_Base.cpp.trc.h"
#endif


/**
 * Method: vUpdateSMSInbox
  * Used to update the SMS inbox forcibly.
  * NISSAN_15
 */
void clHSA_Phone_Base::vUpdateSMSInbox( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vUpdateSMSInbox not implemented"));
   
}

/**
 * Method: blGetPhoneBookDetails_UserWord
  * Returns the name, which has to be displayed in the phonebook details-list, on the position given as parameter.BAP Phonebook
  * B2Plus
 */
tbool clHSA_Phone_Base::blGetPhoneBookDetails_UserWord(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Phone::blGetPhoneBookDetails_UserWord not implemented"));
   return 0;
}

/**
 * Method: vSetNumber
  * Set the number given as parameter. For further usage. The further usage must be triggered by any other second interface functiojn e.g. to Start a SDS Session where a user word is going to be created
  * B1Plus
 */
void clHSA_Phone_Base::vSetNumber(const GUI_String * Number)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( Number);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetNumber not implemented"));
   
}

/**
 * Method: vSetNumberType
  * Set the number type given as parameter. For further usage. The further usage must be triggered by any other second interface functiojn e.g. to Start a SDS Session where a user word is going to be created
  * B1Plus
 */
void clHSA_Phone_Base::vSetNumberType(ulword ulwNumberType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwNumberType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetNumberType not implemented"));
   
}

/**
 * Method: ulwGetBatteryLevel
  * Returns the battery status of the connected mobile phone.
  * APlus
 */
ulword clHSA_Phone_Base::ulwGetBatteryLevel( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetBatteryLevel not implemented"));
   return 0;
}

/**
 * Method: blIsBatteryLevelAvailable
  * Returns true if battery status of the connected mobile device is available.
  * B1Plus
 */
tbool clHSA_Phone_Base::blIsBatteryLevelAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsBatteryLevelAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsShortcutNumberAssigned
  * Checks if a shortcut number is available for the requested list index.
  * 
 */
tbool clHSA_Phone_Base::blIsShortcutNumberAssigned(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsShortcutNumberAssigned not implemented"));
   return 0;
}

/**
 * Method: vGetShortcutNumbersList
  * List of short cut phone numbers. Returns the short cut phone number given by the Index.
  * 
 */
void clHSA_Phone_Base::vGetShortcutNumbersList(GUI_String *out_result, ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetShortcutNumbersList not implemented"));
   
}

/**
 * Method: vSpellerSetShortcutNumber
  * Sends the new shortcut number for the chosen index to the application (used in speller)
  * 
 */
void clHSA_Phone_Base::vSpellerSetShortcutNumber(ulword ulwIndex, const GUI_String * Number)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( Number);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerSetShortcutNumber not implemented"));
   
}

/**
 * Method: vGetCopilotList
  * Returns the Copilot country name or number from the list
  * 
 */
void clHSA_Phone_Base::vGetCopilotList(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetCopilotList not implemented"));
   
}

/**
 * Method: blIsCopilotNumberAssigned
  * Checks if the Copilot number is set
  * 
 */
tbool clHSA_Phone_Base::blIsCopilotNumberAssigned( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsCopilotNumberAssigned not implemented"));
   return 0;
}

/**
 * Method: vGetCoPilotNameOrNumber
  * Returns the Copilot country name or number
  * 
 */
void clHSA_Phone_Base::vGetCoPilotNameOrNumber(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetCoPilotNameOrNumber not implemented"));
   
}

/**
 * Method: vSetCopilotNumber
  * Sends the index of the selected copilot country by the user
  * 
 */
void clHSA_Phone_Base::vSetCopilotNumber(ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetCopilotNumber not implemented"));
   
}

/**
 * Method: ulwGetCopilotCountryList_Count
  * Used to get the Copilot country list size
  * 
 */
ulword clHSA_Phone_Base::ulwGetCopilotCountryList_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetCopilotCountryList_Count not implemented"));
   return 0;
}

/**
 * Method: ulwGetCoPilotList_ActiveItemIndex
  * Used to get the user selcted Copilot index
  * 
 */
ulword clHSA_Phone_Base::ulwGetCoPilotList_ActiveItemIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetCoPilotList_ActiveItemIndex not implemented"));
   return 0;
}

/**
 * Method: vGetSSPPIN
  * Returns the number for Secure simple Pairing SSP. This needs to be compared by the user and confirmed via 
  * 
 */
void clHSA_Phone_Base::vGetSSPPIN(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetSSPPIN not implemented"));
   
}

/**
 * Method: vSetConfirmSSPPIN
  * sends the PIN to Phone BAP PhoneEnabled
  * 
 */
void clHSA_Phone_Base::vSetConfirmSSPPIN(tbool blSSPPINConfirmation)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blSSPPINConfirmation);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetConfirmSSPPIN not implemented"));
   
}

/**
 * Method: vGetConnectedDeviceAdress
  * Returns the adress of the currently connected BT device.
  * 
 */
void clHSA_Phone_Base::vGetConnectedDeviceAdress(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetConnectedDeviceAdress not implemented"));
   
}

/**
 * Method: vQSInitQuickSearch
  * When Quick Search is started by the list position the API must evaluate what is the first character displayed in the Quick Search POPup based on the current position in the list which is given as param1
  * NISSAN_15
 */
void clHSA_Phone_Base::vQSInitQuickSearch(ulword ulwListPos)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListPos);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vQSInitQuickSearch not implemented"));
   
}

/**
 * Method: vGetQSCurrentCharacterGroupPH
  * This function provides the character which is shown in the Quick Search POPup
  * NISSAN_15
 */
void clHSA_Phone_Base::vGetQSCurrentCharacterGroupPH(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetQSCurrentCharacterGroupPH not implemented"));
   
}

/**
 * Method: vSetQSIncreaseCurrentCharacterGroupPH
  * Makes the API increasing the position in the character grouping list
  * NISSAN_15
 */
void clHSA_Phone_Base::vSetQSIncreaseCurrentCharacterGroupPH( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vSetQSIncreaseCurrentCharacterGroupPH not implemented"));
   
}

/**
 * Method: vSetQSDecreaseCurrentCharacterGroupPH
  * Makes the API decreasing the position in the character grouping list
  * NISSAN_15
 */
void clHSA_Phone_Base::vSetQSDecreaseCurrentCharacterGroupPH( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vSetQSDecreaseCurrentCharacterGroupPH not implemented"));
   
}

/**
 * Method: vQSStartSearchPH
  * This function makes the API calling the interface towards the middleware to start the quick search by using the currently selected letter. As the control of the current displayed character is in the hand of the API layer it must not be given as parameter.
  * NISSAN_15
 */
void clHSA_Phone_Base::vQSStartSearchPH( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vQSStartSearchPH not implemented"));
   
}

/**
 * Method: ulwGetPhonebookPosition
  * Used for reposition the Phonebook list
  * NISSAN_15
 */
ulword clHSA_Phone_Base::ulwGetPhonebookPosition( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetPhonebookPosition not implemented"));
   return 0;
}

/**
 * Method: blIsBTAudioPlaying
  * Indicates if the BT Module transmits on the A2DP Channel
  * NISSAN
 */
tbool clHSA_Phone_Base::blIsBTAudioPlaying( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsBTAudioPlaying not implemented"));
   return 0;
}

/**
 * Method: blIsBtSetupVisibilityVisibleAvailable
  * Indicates if the BT Module can be triggered with this function
  * NISSAN
 */
tbool clHSA_Phone_Base::blIsBtSetupVisibilityVisibleAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsBtSetupVisibilityVisibleAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsBtSetupVisibilityInvisibleAvailable
  * Indicates if the BT Module can be triggered with this function
  * NISSAN
 */
tbool clHSA_Phone_Base::blIsBtSetupVisibilityInvisibleAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsBtSetupVisibilityInvisibleAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsBtSetupConnectStartAvailable
  * Indicates if the BT Module can be triggered with this function
  * NISSAN
 */
tbool clHSA_Phone_Base::blIsBtSetupConnectStartAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsBtSetupConnectStartAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsBtSetupDeletePairAvailable
  * Indicates if the BT Module can be triggered with this function
  * NISSAN
 */
tbool clHSA_Phone_Base::blIsBtSetupDeletePairAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsBtSetupDeletePairAvailable not implemented"));
   return 0;
}

/**
 * Method: ulwGetDevices_IsA2DPorHFP
  * Returns an integer value that indicates type of device.0: ND, 1: PHN, 2: MULTI, 3: INVALID
  * NISSAN
 */
ulword clHSA_Phone_Base::ulwGetDevices_IsA2DPorHFP(ulword ulwList, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwList);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetDevices_IsA2DPorHFP not implemented"));
   return 0;
}

/**
 * Method: vDialNumberByID
  * Dials the phone book number given as parameter by ID i.e., List Entry Number. BAP.u32PhonebookEntryId
  * NISSAN
 */
void clHSA_Phone_Base::vDialNumberByID(ulword ulwListEntryNbr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNbr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vDialNumberByID not implemented"));
   
}

/**
 * Method: ulwGetSpellerMatchIndex
  * Returns the position of the phonebook entry if matching string found in phonebook.
  * NISSAN n VW
 */
ulword clHSA_Phone_Base::ulwGetSpellerMatchIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetSpellerMatchIndex not implemented"));
   return 0;
}

/**
 * Method: ulwGetSpellerMatchFoundResult
  * Returns the status of the speller string searched into the phonebook.
  * NISSAN
 */
ulword clHSA_Phone_Base::ulwGetSpellerMatchFoundResult( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetSpellerMatchFoundResult not implemented"));
   return 0;
}

/**
 * Method: blIsSpellerMatchFound
  * Returns the status of the speller string searched into the phonebook.
  * NISSAN
 */
tbool clHSA_Phone_Base::blIsSpellerMatchFound( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsSpellerMatchFound not implemented"));
   return 0;
}

/**
 * Method: blIsVoiceRecognitionFunctionAvailable
  * returns true, if voice recognition is supported else false.
  * NISSAN
 */
tbool clHSA_Phone_Base::blIsVoiceRecognitionFunctionAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsVoiceRecognitionFunctionAvailable not implemented"));
   return 0;
}

/**
 * Method: blGetVoiceRecognitionState
  * Returns true if the Voice recognition is active and false if it is inactive.
  * NISSAN
 */
tbool clHSA_Phone_Base::blGetVoiceRecognitionState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blGetVoiceRecognitionState not implemented"));
   return 0;
}

/**
 * Method: vSetVoiceRecognitionState
  * Toggles the voice recognition state.
  * NISSAN
 */
void clHSA_Phone_Base::vSetVoiceRecognitionState(ulword ulwRecognitionstate)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwRecognitionstate);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetVoiceRecognitionState not implemented"));
   
}

/**
 * Method: ulwGetVoiceRecognitionResult
  * returns the result of the voice recognition method start.
  * NISSAN
 */
ulword clHSA_Phone_Base::ulwGetVoiceRecognitionResult( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetVoiceRecognitionResult not implemented"));
   return 0;
}

/**
 * Method: ulwGetSiriStatus
  * returns the current siri status values
  * NISSAN
 */
ulword clHSA_Phone_Base::ulwGetSiriStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetSiriStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetSiriOrVA_SWCSetting
  * returns current swc setting for SIRI/VA.
  * NISSAN
 */
ulword clHSA_Phone_Base::ulwGetSiriOrVA_SWCSetting( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetSiriOrVA_SWCSetting not implemented"));
   return 0;
}

/**
 * Method: vSetSiriOrVA_SWCSetting
  * sets swc setting for SIRI/VA
  * NISSAN
 */
void clHSA_Phone_Base::vSetSiriOrVA_SWCSetting(ulword ulwVRSetting)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwVRSetting);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetSiriOrVA_SWCSetting not implemented"));
   
}

/**
 * Method: vToggleBTMode
  * toggles the state of bluetooth mode
  * NISSAN
 */
void clHSA_Phone_Base::vToggleBTMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vToggleBTMode not implemented"));
   
}

/**
 * Method: ulwGetBTMode
  * Returns 0 if bluetooth status unknown, 1 on, 2 off or 3 intermediate.
  * NISSAN
 */
ulword clHSA_Phone_Base::ulwGetBTMode( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetBTMode not implemented"));
   return 0;
}

/**
 * Method: blAcceptCall
  * accept the incoming call (more than one call is active)
  * BPlus
 */
tbool clHSA_Phone_Base::blAcceptCall(ulword ulwitemID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwitemID);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Phone::blAcceptCall not implemented"));
   return 0;
}

/**
 * Method: blActivateCall
  * activate the selected call from the call list. BAP function ResumeCall
  * BPlus
 */
tbool clHSA_Phone_Base::blActivateCall(ulword ulwitemID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwitemID);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Phone::blActivateCall not implemented"));
   return 0;
}

/**
 * Method: vAddToConference
  * used to add a call to a conference BAP CCJoin
  * B1Plus
 */
void clHSA_Phone_Base::vAddToConference(ulword ulwitemID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwitemID);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vAddToConference not implemented"));
   
}

/**
 * Method: vCancelPairingProcess
  * Stops the pairing process
  * APlus
 */
void clHSA_Phone_Base::vCancelPairingProcess( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vCancelPairingProcess not implemented"));
   
}

/**
 * Method: vCheckPIN
  * checks the PIN (async.)
  * 
 */
void clHSA_Phone_Base::vCheckPIN( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vCheckPIN not implemented"));
   
}

/**
 * Method: vClearMissedCallIndication
  * clears the indication for missed calls (used when entering the missed calls list) BAP MissedCallIndication
  * B2Plus
 */
void clHSA_Phone_Base::vClearMissedCallIndication( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vClearMissedCallIndication not implemented"));
   
}

/**
 * Method: vConnectDevice
  * Starts a connecting process for the selected device.
  * APlus
 */
void clHSA_Phone_Base::vConnectDevice(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vConnectDevice not implemented"));
   
}

/**
 * Method: blDeletePairedDevice
  * Deletes the paired-device selected in the list.
  * APlus
 */
tbool clHSA_Phone_Base::blDeletePairedDevice(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Phone::blDeletePairedDevice not implemented"));
   return 0;
}

/**
 * Method: vDialEmergencyNumber
  * dials the currend emergency-number (even without logging on phone) BAP DialNumber.StartResult(112)
  * B1Plus
 */
void clHSA_Phone_Base::vDialEmergencyNumber( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vDialEmergencyNumber not implemented"));
   
}

/**
 * Method: vDialNumber
  * Dials the number given as parameter. BAP.DialNumber
  * B1Plus
 */
void clHSA_Phone_Base::vDialNumber(const GUI_String * Number)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( Number);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vDialNumber not implemented"));
   
}

/**
 * Method: vDialNumberName
  * Dials the number of contact name given as parameters. BAP.DialNumber
  * B1Plus
 */
void clHSA_Phone_Base::vDialNumberName(const GUI_String * Number, const GUI_String * Name)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( Number);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( Name);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vDialNumberName not implemented"));
   
}

/**
 * Method: vDialNumberForPOI
  * Dials the number of the selected POI. The parameter represents the index of the item in the POI list
  * B1Plus
 */
void clHSA_Phone_Base::vDialNumberForPOI( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vDialNumberForPOI not implemented"));
   
}

/**
 * Method: vDialCopilotNumber
  * Dial the Copilot number that is set by the user
  * 
 */
void clHSA_Phone_Base::vDialCopilotNumber( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vDialCopilotNumber not implemented"));
   
}

/**
 * Method: ulwGetPOINumberAvailability
  * The Dial button in the POI details screen is enabled/disabled according to the return value of this API
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetPOINumberAvailability( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetPOINumberAvailability not implemented"));
   return 0;
}

/**
 * Method: ulwGetRedialNumberAvailable
  * Returns if a redial number is available in phone
  * C1
 */
ulword clHSA_Phone_Base::ulwGetRedialNumberAvailable( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetRedialNumberAvailable not implemented"));
   return 0;
}

/**
 * Method: vRedial
  * Realises Redial functionality
  * C1
 */
void clHSA_Phone_Base::vRedial( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vRedial not implemented"));
   
}

/**
 * Method: ulwGetOutgoingCallSource
  * gets the value which indicates from which source the outgoing call has been initiated
  * 
 */
ulword clHSA_Phone_Base::ulwGetOutgoingCallSource( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetOutgoingCallSource not implemented"));
   return 0;
}

/**
 * Method: ulwGetMaxLimitOfPBEntries
  * returns the maximum limit of phonebook entries
  * C
 */
ulword clHSA_Phone_Base::ulwGetMaxLimitOfPBEntries( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetMaxLimitOfPBEntries not implemented"));
   return 0;
}

/**
 * Method: ulwGetActivePhonebookSource
  * gets the source set in the phone-setup menu to be used for downloading the phonebook
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetActivePhonebookSource( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetActivePhonebookSource not implemented"));
   return 0;
}

/**
 * Method: ulwGetPBNumberOfDownloadedEntries
  * Gets the number of phonebook downloaded entries during download process
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetPBNumberOfDownloadedEntries( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetPBNumberOfDownloadedEntries not implemented"));
   return 0;
}

/**
 * Method: vGetBTDevices_Names
  * Returns a string with  the name of  the BT-device shown in the list at the index given as parameter.
  * APlus
 */
void clHSA_Phone_Base::vGetBTDevices_Names(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetBTDevices_Names not implemented"));
   
}

/**
 * Method: vGetBTPasskey
  * returns a string with the value of the BTPasskey. Used to show the BTPasskay in the waiting screen of the pairing process
  * B1Plus
 */
void clHSA_Phone_Base::vGetBTPasskey(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetBTPasskey not implemented"));
   
}

/**
 * Method: ulwGetCallBarListCallBarDivertState
  * Returns the diverted State for a list entry in the call list. BAP CallState
  * B1Plus
 */
ulword clHSA_Phone_Base::ulwGetCallBarListCallBarDivertState(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetCallBarListCallBarDivertState not implemented"));
   return 0;
}

/**
 * Method: vGetCallBarListCallBarMainText
  * Returns the CallBar_MainText for a list entry in the call list. BAP: CallInfo
  * B1Plus
 */
void clHSA_Phone_Base::vGetCallBarListCallBarMainText(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetCallBarListCallBarMainText not implemented"));
   
}

/**
 * Method: vGetCallBarListCallBarName
  * Returns the Callar_name for a list entry in the call list. BAP: CallInfo
  * NISSAN
 */
void clHSA_Phone_Base::vGetCallBarListCallBarName(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetCallBarListCallBarName not implemented"));
   
}

/**
 * Method: vGetCallBarListCallBarNumber
  * Returns the CallBar_number for a list entry in the call list. BAP: CallInfo
  * NISSAN
 */
void clHSA_Phone_Base::vGetCallBarListCallBarNumber(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetCallBarListCallBarNumber not implemented"));
   
}

/**
 * Method: ulwGetCallBarListCallBarText
  * Returns the CallBarText for a list entry in the call list.
  * B1Plus
 */
ulword clHSA_Phone_Base::ulwGetCallBarListCallBarText(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetCallBarListCallBarText not implemented"));
   return 0;
}

/**
 * Method: vGetCallBarListCallDuration
  * Returns the call duration for given list entry.
  * B1Plus
 */
void clHSA_Phone_Base::vGetCallBarListCallDuration(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetCallBarListCallDuration not implemented"));
   
}

/**
 * Method: ulwGetCallBarListCallState
  * Returns the CallState for a list entry in the call list. BAP CallState
  * B1Plus
 */
ulword clHSA_Phone_Base::ulwGetCallBarListCallState(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetCallBarListCallState not implemented"));
   return 0;
}

/**
 * Method: ulwGetCallBarListItem_Count
  * the count of the items which will be shown in the call bar list
  * B1Plus
 */
ulword clHSA_Phone_Base::ulwGetCallBarListItem_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetCallBarListItem_Count not implemented"));
   return 0;
}

/**
 * Method: vGetConnectedDeviceName
  * Returns the name of the currently connected BT device. If no device name is available the BT-Adress is displayed instead. BAP ActiveUser
  * APlus
 */
void clHSA_Phone_Base::vGetConnectedDeviceName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetConnectedDeviceName not implemented"));
   
}

/**
 * Method: ulwGetConnectingProcessState
  * Returns the state of the connecting process.
  * APlus
 */
ulword clHSA_Phone_Base::ulwGetConnectingProcessState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetConnectingProcessState not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentDate
  * Returns the current date as a formatted string. Used in the call stack lists, to compare the date of a call, in oder to show the text "today" in the list.
  * BPlus
 */
void clHSA_Phone_Base::vGetCurrentDate(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetCurrentDate not implemented"));
   
}

/**
 * Method: ulwGetCurrentPhonebookSortingCriteria
  * Returns the current sorting criteria for the phonebook.
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetCurrentPhonebookSortingCriteria( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetCurrentPhonebookSortingCriteria not implemented"));
   return 0;
}

/**
 * Method: ulwGetDevices_IsA2DP
  * Returns an integer value that indicates wether a list item supports A2DP or not. 2 if the device supports A2DP, 3 otherwise.
  * APlus
 */
ulword clHSA_Phone_Base::ulwGetDevices_IsA2DP(ulword ulwList, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwList);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetDevices_IsA2DP not implemented"));
   return 0;
}

/**
 * Method: ulwGetDevices_IsHFP
  * Returns an integer value that indicates wether a list item supports HFP or not. 1 if the device supports HFP, 0 otherwise.
  * APlus
 */
ulword clHSA_Phone_Base::ulwGetDevices_IsHFP(ulword ulwList, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwList);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetDevices_IsHFP not implemented"));
   return 0;
}

/**
 * Method: ulwGetDeviceState
  * returns the state of the phone device
  * B1Plus
 */
ulword clHSA_Phone_Base::ulwGetDeviceState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetDeviceState not implemented"));
   return 0;
}

/**
 * Method: ulwGetDialedNumbersList_Count
  * the count of the items contained by the list of dialed numbers BAP DialedNumbers
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetDialedNumbersList_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetDialedNumbersList_Count not implemented"));
   return 0;
}

/**
 * Method: vGetDialedNumbersList_Date
  * Returns the date to be shown in the dialed_numbers list, at the index ListEntryNr BAP DialedNumbers
  * B2Plus
 */
void clHSA_Phone_Base::vGetDialedNumbersList_Date(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetDialedNumbersList_Date not implemented"));
   
}

/**
 * Method: ulwGetDialedNumbersList_Icon
  * Returns the type of the icon to be shown in the dialed_numbers list, at the index ListEntryNr BAP DialedNumbers
  * 
 */
ulword clHSA_Phone_Base::ulwGetDialedNumbersList_Icon(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetDialedNumbersList_Icon not implemented"));
   return 0;
}

/**
 * Method: vGetDialedNumbersList_Name
  * Returns the name to be shown in the dialed_numbers list, atthe index ListEntryNr BAP DialedNumbers 
  * B2Plus
 */
void clHSA_Phone_Base::vGetDialedNumbersList_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetDialedNumbersList_Name not implemented"));
   
}

/**
 * Method: vGetDialedNumbersList_Number
  * Returns the number to be shown in the dialed_numbers list, at the index ListEntryNr BAP DialedNumbers 
  * B2Plus
 */
void clHSA_Phone_Base::vGetDialedNumbersList_Number(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetDialedNumbersList_Number not implemented"));
   
}

/**
 * Method: vGetDialedNumbersList_NameOrNumber
  * Returns the name if available otherwise number to be shown in the dialed_numbers list, at the index ListEntryNr BAP DialedNumbers
  * NISSAN
 */
void clHSA_Phone_Base::vGetDialedNumbersList_NameOrNumber(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetDialedNumbersList_NameOrNumber not implemented"));
   
}

/**
 * Method: vGetDialedNumbersList_Time
  * Returns the time to be shown in the dialed_numbers list, at the index ListEntryNr BAP DialedNumbers 
  * B2Plus
 */
void clHSA_Phone_Base::vGetDialedNumbersList_Time(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetDialedNumbersList_Time not implemented"));
   
}

/**
 * Method: ulwGetGSMIntensity
  * Represents the provider signal strength by blocks.5 filled blocks represents the maximum value BAP SignalQuality
  * BPlus
 */
ulword clHSA_Phone_Base::ulwGetGSMIntensity( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetGSMIntensity not implemented"));
   return 0;
}

/**
 * Method: blGetHandsfreeState
  * Returns true if the handsfree mode is active and false if the private mode is active.  BAP HandsfreeOnOff
  * BPlus
 */
tbool clHSA_Phone_Base::blGetHandsfreeState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blGetHandsfreeState not implemented"));
   return 0;
}

/**
 * Method: ulwGetHandsfreeOptionState
  * Returns the state of the "activate Handsfree/PrivateMode" function regarding the availability and the supporting of the function (see return values).  Used to set the state of the "Handsfree"button
  * BPlus
 */
ulword clHSA_Phone_Base::ulwGetHandsfreeOptionState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetHandsfreeOptionState not implemented"));
   return 0;
}

/**
 * Method: blGetMicroMuteState
  * Returns true if micro mute is activated, false otherwise. BAP MicroMuteOnOff
  * BPlus
 */
tbool clHSA_Phone_Base::blGetMicroMuteState( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blGetMicroMuteState not implemented"));
   return 0;
}

/**
 * Method: ulwGetMicroMuteOptionState
  * Returns the state of the "micro mute" function regarding the availability and the supporting of the function (see return values).  Used to set the state of the "Micro mute"
  * BPlus
 */
ulword clHSA_Phone_Base::ulwGetMicroMuteOptionState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetMicroMuteOptionState not implemented"));
   return 0;
}

/**
 * Method: ulwGetMissedCallsList_Count
  * the count of the items contained by the missed_calls list BAP MissedCalls
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetMissedCallsList_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetMissedCallsList_Count not implemented"));
   return 0;
}

/**
 * Method: vGetMissedCallsList_Date
  * Returns the date to be shown in the missed calls list, at the index ListEntryNr BAP MissedCalls
  * B2Plus
 */
void clHSA_Phone_Base::vGetMissedCallsList_Date(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetMissedCallsList_Date not implemented"));
   
}

/**
 * Method: ulwGetMissedCallsList_Icon
  * Returns the type of the icon to be shown in the missed_calls list, at the index ListEntryNr 
  * 
 */
ulword clHSA_Phone_Base::ulwGetMissedCallsList_Icon(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetMissedCallsList_Icon not implemented"));
   return 0;
}

/**
 * Method: vGetMissedCallsList_Name
  * Returns the name to be shown in the missed_calls list, at the index ListEntryNr BAP MissedCalls
  * B2Plus
 */
void clHSA_Phone_Base::vGetMissedCallsList_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetMissedCallsList_Name not implemented"));
   
}

/**
 * Method: vGetMissedCallsList_Number
  * Returns the number the the icon to be shown in the missed_calls list, at the index ListEntryNr BAP MissedCalls
  * B2Plus
 */
void clHSA_Phone_Base::vGetMissedCallsList_Number(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetMissedCallsList_Number not implemented"));
   
}

/**
 * Method: vGetMissedCallsList_NameOrNumber
  * Returns the name if available otherwise number the the icon to be shown in the missed_calls list, at the index ListEntryNr BAP MissedCalls
  * NISSAN
 */
void clHSA_Phone_Base::vGetMissedCallsList_NameOrNumber(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetMissedCallsList_NameOrNumber not implemented"));
   
}

/**
 * Method: vGetMissedCallsList_Time
  * Returns the time to be shown in the missed_calls list, at the index ListEntryNr BAP MissedCalls
  * B2Plus
 */
void clHSA_Phone_Base::vGetMissedCallsList_Time(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetMissedCallsList_Time not implemented"));
   
}

/**
 * Method: blGetNewMissedCalls_Count
  * the count of the items, which are new missed calls (this number is displayed in the PopUp PHONE_PO_MISSED_CALLS )
  * B2Plus
 */
tbool clHSA_Phone_Base::blGetNewMissedCalls_Count( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blGetNewMissedCalls_Count not implemented"));
   return 0;
}

/**
 * Method: slwGetPairedDevices_ActiveItemIndex
  * Returns the index of the current active connected device.
  * APlus
 */
slword clHSA_Phone_Base::slwGetPairedDevices_ActiveItemIndex( )
{
   
   ETG_TRACE_USR4(("function slword clHSA_Phone::slwGetPairedDevices_ActiveItemIndex not implemented"));
   return 0;
}

/**
 * Method: ulwGetPairedDevices_Count
  * Returns the item-count of the list of paired devices.
  * APlus
 */
ulword clHSA_Phone_Base::ulwGetPairedDevices_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetPairedDevices_Count not implemented"));
   return 0;
}

/**
 * Method: vGetPairedDevices_Names
  * Returns a string with  the name of  the paired device shown in the list at the index given as parameter. If no device name is available the BT-Adress is displayed instead.
  * APlus
 */
void clHSA_Phone_Base::vGetPairedDevices_Names(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetPairedDevices_Names not implemented"));
   
}

/**
 * Method: ulwGetPairingProcessState
  * Returns the state of the pairing process.
  * APlus
 */
ulword clHSA_Phone_Base::ulwGetPairingProcessState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetPairingProcessState not implemented"));
   return 0;
}

/**
 * Method: vGetPhoneBook
  * Returns a list of Phonebook entries BAP Phonebook
  * 
 */
void clHSA_Phone_Base::vGetPhoneBook(GUI_String *out_result, ulword uwArrayIndex, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(uwArrayIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetPhoneBook not implemented"));
   
}

/**
 * Method: ulwGetPhoneBook_Count
  * the count of the items contained by the  Phonebook list BAP Phonebook
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetPhoneBook_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetPhoneBook_Count not implemented"));
   return 0;
}

/**
 * Method: ulwGetPhoneBook_DetailsIcon
  * Used in the phonebook to test if details are avaiable for the items. If on the item is more number saved, an icon will be displayed in the listItem, to indicate the existance of more phone-numbers.
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetPhoneBook_DetailsIcon(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetPhoneBook_DetailsIcon not implemented"));
   return 0;
}

/**
 * Method: vGetSMSPhonebookIcon_Type
  * Returns the icon type of the sender of SMS
  * CPlus
 */
void clHSA_Phone_Base::vGetSMSPhonebookIcon_Type(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetSMSPhonebookIcon_Type not implemented"));
   
}

/**
 * Method: ulwGetPhoneBook_IconType
  * Returns the type of the Phonebook entry BAP Phonebook
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetPhoneBook_IconType(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetPhoneBook_IconType not implemented"));
   return 0;
}

/**
 * Method: vGetPhoneBook_Name
  * Returns the name of the contact saved in the  Phonebook entryBAP Phonebook
  * B2Plus
 */
void clHSA_Phone_Base::vGetPhoneBook_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetPhoneBook_Name not implemented"));
   
}

/**
 * Method: ulwGetPhoneBookAvailability
  * Returns 0 if the phonebook can be displayed. If the phonebook is not available, the function returns several values, corresponding to the error that occured. These values are used to display an InfoText in the PopUp PHONE_PHONEBOOK_NOT_AVAILABLE BAP PhoneBookPbState
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetPhoneBookAvailability( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetPhoneBookAvailability not implemented"));
   return 0;
}

/**
 * Method: ulwGetPhoneBookDetails_Count
  * Returns the count of the items contained by the Phonebook-detail list, for the selected Phonebook entry. BAP Phonebook
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetPhoneBookDetails_Count(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetPhoneBookDetails_Count not implemented"));
   return 0;
}

/**
 * Method: vGetPhoneBookDetails_Name
  * Returns the name, which has to be displayed in the phonebook details-list, on the position given as parameter.BAP Phonebook
  * B2Plus
 */
void clHSA_Phone_Base::vGetPhoneBookDetails_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetPhoneBookDetails_Name not implemented"));
   
}

/**
 * Method: vGetPhoneBookDetails_Number
  * Returns the phone number, which has to be displayed in the phonebook details-list, on the position given as parameter.BAP PhonebookBAP Phonebook
  * B2Plus
 */
void clHSA_Phone_Base::vGetPhoneBookDetails_Number(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetPhoneBookDetails_Number not implemented"));
   
}

/**
 * Method: ulwGetPhoneBookDetails_Type
  * Returns the type of the icon, which has to be displayed in the phonebook details-list, on the position given as parameter.BAP Phonebook
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetPhoneBookDetails_Type(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetPhoneBookDetails_Type not implemented"));
   return 0;
}

/**
 * Method: vGetPhoneNumberForListEntry
  * returns a string containing the phone number saved in the list at the index given as parameter. The number returned will be used as parameter in the APICall DialNumber. 
  * BPlus
 */
void clHSA_Phone_Base::vGetPhoneNumberForListEntry(GUI_String *out_result, ulword ulwList, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwList);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetPhoneNumberForListEntry not implemented"));
   
}

/**
 * Method: vGetProviderName
  * Displays the current provider if found An empty string will indicate the displayed states empty (no presentation) or "no network" BAP NetworkProvider
  * APlus
 */
void clHSA_Phone_Base::vGetProviderName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetProviderName not implemented"));
   
}

/**
 * Method: vGetRedialNumber
  * returns the Number for the redial option if available. This could be checked using IsRedialNumberAvailable
  * NISSAN
 */
void clHSA_Phone_Base::vGetRedialNumber(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetRedialNumber not implemented"));
   
}

/**
 * Method: vGetRedialName
  * returns the Name for the redial option if available. This could be checked using IsRedialNameAvailable
  * NISSAN
 */
void clHSA_Phone_Base::vGetRedialName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetRedialName not implemented"));
   
}

/**
 * Method: vGetLastDialled_NameOrNumber
  * Returns the name if available or dialled number if name not available to be shown in the dialup failed popup
  * NISSAN
 */
void clHSA_Phone_Base::vGetLastDialled_NameOrNumber(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetLastDialled_NameOrNumber not implemented"));
   
}

/**
 * Method: ulwGetProviderState
  * Display the different Status of the provider BAP RegisterState
  * APlus
 */
ulword clHSA_Phone_Base::ulwGetProviderState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetProviderState not implemented"));
   return 0;
}

/**
 * Method: ulwGetReceivedCallsList_Count
  * the count of the items contained by the received calls list BAP ReceivedCalls
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwGetReceivedCallsList_Count( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetReceivedCallsList_Count not implemented"));
   return 0;
}

/**
 * Method: vGetReceivedCallsList_Date
  * Returns the date to be shown in the received_calls list, at the index ListEntryNr BAP ReceivedCalls
  * B2Plus
 */
void clHSA_Phone_Base::vGetReceivedCallsList_Date(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetReceivedCallsList_Date not implemented"));
   
}

/**
 * Method: vGetReceivedCallsList_Icon
  * Returns the type of the icon to be shown in the received_calls list, at the index ListEntryNr 
  * 
 */
void clHSA_Phone_Base::vGetReceivedCallsList_Icon(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetReceivedCallsList_Icon not implemented"));
   
}

/**
 * Method: ulwGetReceivedCallsList_Icon_new
  * Returns the type of the icon to be shown in the received_calls list, at the index ListEntryNr 
  * NISSAN
 */
ulword clHSA_Phone_Base::ulwGetReceivedCallsList_Icon_new(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetReceivedCallsList_Icon_new not implemented"));
   return 0;
}

/**
 * Method: vGetReceivedCallsList_Name
  * Returns the name to be shown in the received_calls list, at the index ListEntryNr BAP ReceivedCalls
  * B2Plus
 */
void clHSA_Phone_Base::vGetReceivedCallsList_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetReceivedCallsList_Name not implemented"));
   
}

/**
 * Method: vGetReceivedCallsList_Number
  * Returns the number to be shown in the received_calls list, at the index ListEntryNr BAP ReceivedCalls
  * B2Plus
 */
void clHSA_Phone_Base::vGetReceivedCallsList_Number(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetReceivedCallsList_Number not implemented"));
   
}

/**
 * Method: vGetReceivedCallsList_NameOrNumber
  * Returns the name if available otherwise number to be shown in the received_calls list, at the index ListEntryNr BAP ReceivedCalls
  * NISSAN
 */
void clHSA_Phone_Base::vGetReceivedCallsList_NameOrNumber(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetReceivedCallsList_NameOrNumber not implemented"));
   
}

/**
 * Method: vGetReceivedCallsList_Time
  * Returns the time to be shown in the received_calls list, at the index ListEntryNr BAP ReceivedCalls
  * B2Plus
 */
void clHSA_Phone_Base::vGetReceivedCallsList_Time(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetReceivedCallsList_Time not implemented"));
   
}

/**
 * Method: blGetReturnToSystem
  * returns the value ReturnToSystem; the value is used to check which context has to be activated after the last call was ended. The value is set by using the APICall SetReturnToSystem.
  * B2Plus
 */
tbool clHSA_Phone_Base::blGetReturnToSystem( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blGetReturnToSystem not implemented"));
   return 0;
}

/**
 * Method: ulwGetSIMState
  * Represents the state of the SIM card BAP GetLockStates
  * B1Plus
 */
ulword clHSA_Phone_Base::ulwGetSIMState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetSIMState not implemented"));
   return 0;
}

/**
 * Method: vGetSpellerEntryField
  * returns the string which will be shown in the input textfield of the speller
  * B1Plus
 */
void clHSA_Phone_Base::vGetSpellerEntryField(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetSpellerEntryField not implemented"));
   
}

/**
 * Method: vGetSpellerEntryFieldNAR
  * returns the string which will be shown in the input textfield of the speller
  * B1Plus
 */
void clHSA_Phone_Base::vGetSpellerEntryFieldNAR(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetSpellerEntryFieldNAR not implemented"));
   
}

/**
 * Method: blGetVisibility
  * Returns true, if the RNS is visible for a BT connection.
  * APlus
 */
tbool clHSA_Phone_Base::blGetVisibility( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blGetVisibility not implemented"));
   return 0;
}

/**
 * Method: vGetYesterdayDate
  * Returns the date for the day before today as a formatted string. Used in the call stack lists, to compare the date of a call, in oder to show the text "yesterday" in the list.
  * BPlus
 */
void clHSA_Phone_Base::vGetYesterdayDate(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetYesterdayDate not implemented"));
   
}

/**
 * Method: vHangUp
  * ends the phone call BAP HangupCall
  * B1Plus
 */
void clHSA_Phone_Base::vHangUp(ulword ulwitemID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwitemID);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vHangUp not implemented"));
   
}

/**
 * Method: vHoldCall
  * puts the call on hold (option in the Extras menu) BAP CallHold
  * BPlus
 */
void clHSA_Phone_Base::vHoldCall(ulword ulwitemID)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwitemID);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vHoldCall not implemented"));
   
}

/**
 * Method: blIsBTActive
  * Returns true if BT is sctive. Indication for BT-Icon BAP FSG-Setup.MobileConnectionType
  * B1Plus
 */
tbool clHSA_Phone_Base::blIsBTActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsBTActive not implemented"));
   return 0;
}

/**
 * Method: ulwIsCallPresent
  * Indicates if a call is present or not in order to switch to the right screen.a call might be ringing (incoming/outgoing), active, on hold, etc BAP CallState
  * B1Plus 
 */
ulword clHSA_Phone_Base::ulwIsCallPresent( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwIsCallPresent not implemented"));
   return 0;
}

/**
 * Method: ulwIsEmergencyCallPresent
  * Indicates if an emergency call is present or not in order to switch to the right screen BAP CallStates.CallType
  * B1Plus
 */
ulword clHSA_Phone_Base::ulwIsEmergencyCallPresent( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwIsEmergencyCallPresent not implemented"));
   return 0;
}

/**
 * Method: blIsSecondIncomingCallPresent
  * Indicates if a second call is incoming when a call is already active
  * B1Plus
 */
tbool clHSA_Phone_Base::blIsSecondIncomingCallPresent( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsSecondIncomingCallPresent not implemented"));
   return 0;
}

/**
 * Method: blIsGSMModuleConnected
  * Indicates if the GSM module is connected or not
  * B1Plus
 */
tbool clHSA_Phone_Base::blIsGSMModuleConnected( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsGSMModuleConnected not implemented"));
   return 0;
}

/**
 * Method: blIsHandsfreeOptionAvailable
  * returns true, if activating the handsfree/ privatemode is possible.  Used to show/ hide the handsfree/ private_mode eoption in the Extras-Menu
  * BPlus
 */
tbool clHSA_Phone_Base::blIsHandsfreeOptionAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsHandsfreeOptionAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsInternalGSMModuleAvailable
  * Provides the internal GSM module status if it is availabale or not BAP FSG-Setup.PhoneCaracteristics
  * B1Plus 
 */
tbool clHSA_Phone_Base::blIsInternalGSMModuleAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsInternalGSMModuleAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsLoadPhoneBookAvailable
  * Indicates if the ;Load phonebook button is available or not BAP FunctionList
  * B2Plus
 */
tbool clHSA_Phone_Base::blIsLoadPhoneBookAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsLoadPhoneBookAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsMicroMuteOptionAvailable
  * returns true, if activating the micro mute is possible.  Used to show/ hide the Micro muteoption in the Extras-Menu BAP FunctionList
  * BPlus
 */
tbool clHSA_Phone_Base::blIsMicroMuteOptionAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsMicroMuteOptionAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsRedialNumberAvailable
  * returns true, if the number ro redial is not NULL
  * NISSAN
 */
tbool clHSA_Phone_Base::blIsRedialNumberAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsRedialNumberAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsRedialNameAvailable
  * returns true, if the name to redial is not NULL
  * 
 */
tbool clHSA_Phone_Base::blIsRedialNameAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsRedialNameAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsPairedDevicesListFull
  * Returns true if the list of paired devices is full and a device must  be deleted in order to be allowed to pair a new device.
  * APlus
 */
tbool clHSA_Phone_Base::blIsPairedDevicesListFull( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsPairedDevicesListFull not implemented"));
   return 0;
}

/**
 * Method: ulwIsPhoneMuteActive
  * Indicates the status of phone mute for all phone variants (including BAP, AT, CAN and mute line phones) BAP MicroMuteOnOff
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwIsPhoneMuteActive( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwIsPhoneMuteActive not implemented"));
   return 0;
}

/**
 * Method: blIsLimitedPhoneModeActive
  * Indicates if the HMI is off and a call is active (limited phone mode is active).
  * B2Plus
 */
tbool clHSA_Phone_Base::blIsLimitedPhoneModeActive( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsLimitedPhoneModeActive not implemented"));
   return 0;
}

/**
 * Method: blIsPINSpellerSupported
  * Indicates if the pin speller is available or not BAP FunctionList[PhoneEnabled]
  * B1Plus
 */
tbool clHSA_Phone_Base::blIsPINSpellerSupported( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsPINSpellerSupported not implemented"));
   return 0;
}

/**
 * Method: blIsSetPhoneBookSortingAvailable
  * Indicates if the 'Phone book sorting' button is available in the setup menu or not
  * B2Plus
 */
tbool clHSA_Phone_Base::blIsSetPhoneBookSortingAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsSetPhoneBookSortingAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsSetPhoneBookSourceAvailable
  * Indicates if the "Change phone book source" button is available or not
  * B2Plus
 */
tbool clHSA_Phone_Base::blIsSetPhoneBookSourceAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsSetPhoneBookSourceAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsSignalStrengthAvailable
  * Indicates if the network signal is available or not BAP FunctionList
  * BPlus
 */
tbool clHSA_Phone_Base::blIsSignalStrengthAvailable( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsSignalStrengthAvailable not implemented"));
   return 0;
}

/**
 * Method: blIsUserConnected
  * Indicates if the user is connected or not BAP ActiveUser
  * B1Plus
 */
tbool clHSA_Phone_Base::blIsUserConnected( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsUserConnected not implemented"));
   return 0;
}

/**
 * Method: vPrepareSpellerEntryField
  * Used to give an initial value to the input field of the speller, and to indicate the active speller.
  * B1Plus
 */
void clHSA_Phone_Base::vPrepareSpellerEntryField(const GUI_String * EntryFieldValue, ulword ulwSpeller)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( EntryFieldValue);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwSpeller);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vPrepareSpellerEntryField not implemented"));
   
}

/**
 * Method: vSetActivePhoneBookSource
  * sets the source from where phonebook has to be read 
  * B2Plus
 */
void clHSA_Phone_Base::vSetActivePhoneBookSource(ulword ulwEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetActivePhoneBookSource not implemented"));
   
}

/**
 * Method: vSetInitialFocusPositionInPhonebook
  * Called when the phonebook is opened from the main menu to set the focus at the beginning of the list
  * 
 */
void clHSA_Phone_Base::vSetInitialFocusPositionInPhonebook(ulword ulwIndex)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwIndex);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetInitialFocusPositionInPhonebook not implemented"));
   
}

/**
 * Method: vSetPhonebookSortingCriteria
  * Sets the current sorting criteria for the phonebook.
  * B2Plus
 */
void clHSA_Phone_Base::vSetPhonebookSortingCriteria(ulword ulwEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetPhonebookSortingCriteria not implemented"));
   
}

/**
 * Method: vSetReturnToSystem
  * Set the property ReturnToSystem. Siehe GetReturnToSystem.
  * B2Plus
 */
void clHSA_Phone_Base::vSetReturnToSystem(tbool blReturnToSystem)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blReturnToSystem);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetReturnToSystem not implemented"));
   
}

/**
 * Method: vSetVisibility
  * Toggles the visibilty state.
  * APlus
 */
void clHSA_Phone_Base::vSetVisibility(ulword ulwVisibility)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwVisibility);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetVisibility not implemented"));
   
}

/**
 * Method: vSpellerDialNumber
  * Dials the number given as parameter. This parameter is given by the APIcall GetSpellerInputField BAP DialNumber
  * B1Plus
 */
void clHSA_Phone_Base::vSpellerDialNumber(const GUI_String * Number)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( Number);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerDialNumber not implemented"));
   
}

/**
 * Method: vSpellerDiscardInput
  * discards the resultset of the speller input
  * B1Plus
 */
void clHSA_Phone_Base::vSpellerDiscardInput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerDiscardInput not implemented"));
   
}

/**
 * Method: vSpellerDeleteInput
  * deletes entire input in speller
  * C
 */
void clHSA_Phone_Base::vSpellerDeleteInput( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerDeleteInput not implemented"));
   
}

/**
 * Method: blSpellerEnableMatchSpeller
  * During matching, the user shouldn't be able to to enter characters or to change the position of the cursor. This is why in this case the speller must be disabled .
  * BPlus
 */
tbool clHSA_Phone_Base::blSpellerEnableMatchSpeller( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blSpellerEnableMatchSpeller not implemented"));
   return 0;
}

/**
 * Method: ulwSpellerGetCursorPos
  * Returns the position of the cursor. The application has to manage the position of the cursor by using the special unicodes F817 and F818. The cursor is independent from the length of the text. "Left" would position the cursor between the last and the last but one  character. "Right" will position the cursor after the last character.
  * B2Plus
 */
ulword clHSA_Phone_Base::ulwSpellerGetCursorPos( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwSpellerGetCursorPos not implemented"));
   return 0;
}

/**
 * Method: vSpellerGetHighlightedText
  * The initial text set by the APICall GetSpellerEntryField, wil be taken as proposal and will be sent to the entry field. This proposal can be displayed inverted by using the property "matchText". If only one character is entered, this proposal will be discarded and this function returns an empty string. If the cursor is moved,  this method also returns an empty string.
  * BPlus
 */
void clHSA_Phone_Base::vSpellerGetHighlightedText(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerGetHighlightedText not implemented"));
   
}

/**
 * Method: vSpellerGetLetterFunction
  * Returns the characters which should be displayed enabled in the speller.
  * B2Plus
 */
void clHSA_Phone_Base::vSpellerGetLetterFunction(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerGetLetterFunction not implemented"));
   
}

/**
 * Method: blSpellerInvertGetLetterFunction
  * Inverts the logic of the SpellerGetLetterFunction. Has to be set by the application, for example in a freetext-speller, in order to disable some buttons and, at the same time, to enable the cursor-buttons and alt/sub/nr. 
  * B2Plus
 */
tbool clHSA_Phone_Base::blSpellerInvertGetLetterFunction( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blSpellerInvertGetLetterFunction not implemented"));
   return 0;
}

/**
 * Method: vSpellerMatchGetFirst
  * gets the first match it the spellertype is a match-peller or SpellerInput was called, else the first entry in the dataset will be returned
  * BPlus
 */
void clHSA_Phone_Base::vSpellerMatchGetFirst(GUI_String *out_result, slword slwType)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwType);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerMatchGetFirst not implemented"));
   
}

/**
 * Method: vSpellerMatchGetList
  * gets the entry of the match-resultset or database (depends on SpellerInput was called)
  * BPlus
 */
void clHSA_Phone_Base::vSpellerMatchGetList(GUI_String *out_result, ulword uwArrayIndex, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(uwArrayIndex);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerMatchGetList not implemented"));
   
}

/**
 * Method: vSpellerSendPhonebookSearchString
  * send the string entered in the phonebook speller
  * B1Plus
 */
void clHSA_Phone_Base::vSpellerSendPhonebookSearchString(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerSendPhonebookSearchString not implemented"));
   
}

/**
 * Method: vSpellerSendPINInput
  * sends the PIN to Phone BAP PhoneEnabled
  * B1Plus
 */
void clHSA_Phone_Base::vSpellerSendPINInput(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerSendPINInput not implemented"));
   
}

/**
 * Method: vSpellerSetBTPasskey
  * send the new BT pass key to the UHV
  * B1Plus
 */
void clHSA_Phone_Base::vSpellerSetBTPasskey(const GUI_String * Number)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( Number);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerSetBTPasskey not implemented"));
   
}

/**
 * Method: vSpellerSetCharacter
  * Used in the speller to send the character chosen in the widget to the application. Special unicodes which will be sent: F817 (cursor left), F818 (cursor right), F81C (DTMF). This APICall will also be used for deleting characters, by sending the unicode 0008. 
  * B1Plus
 */
void clHSA_Phone_Base::vSpellerSetCharacter(const GUI_String * InputString)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( InputString);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerSetCharacter not implemented"));
   
}

/**
 * Method: vSpellerSetMaxCharCount
  * Used to set the max number of characters which can be entered in the SpellerEntryField. The application has to know this value, in order to prevent entering characters after the maximum of allowed characters was reached. 
  * B2Plus
 */
void clHSA_Phone_Base::vSpellerSetMaxCharCount(slword slwCount)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(slwCount);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerSetMaxCharCount not implemented"));
   
}

/**
 * Method: vStartPhonebookDownload
  * initiates the phone book download via BAP BAP: PbStartDownload
  * B2Plus
 */
void clHSA_Phone_Base::vStartPhonebookDownload( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vStartPhonebookDownload not implemented"));
   
}

/**
 * Method: vToggleMicroMute
  * toggles the state of MicroMute BAP MicroMuteOnOff
  * BPlus
 */
void clHSA_Phone_Base::vToggleMicroMute( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vToggleMicroMute not implemented"));
   
}

/**
 * Method: vTogglePrivateHandsFreeMode
  * toggles the states PrivateMode and RingToneMute BAP HandsfreeOnOff
  * BPlus
 */
void clHSA_Phone_Base::vTogglePrivateHandsFreeMode( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vTogglePrivateHandsFreeMode not implemented"));
   
}

/**
 * Method: vLoadPhoneBookDetails
  * Initiates loading of phone book entry details in application
  * 
 */
void clHSA_Phone_Base::vLoadPhoneBookDetails(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vLoadPhoneBookDetails not implemented"));
   
}

/**
 * Method: blIsPhoneInConnectingPhase
  * Returns true if Phone is in connecting Phase else false
  * B1Plus
 */
tbool clHSA_Phone_Base::blIsPhoneInConnectingPhase( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsPhoneInConnectingPhase not implemented"));
   return 0;
}

/**
 * Method: ulwGetSMSInboxUpdateStatus
  * Indicates the status of SMS Inbox Update
  * 
 */
ulword clHSA_Phone_Base::ulwGetSMSInboxUpdateStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetSMSInboxUpdateStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetSMSMessagesCount
  * Returns the number of messages updated in the Inbox
  * 
 */
ulword clHSA_Phone_Base::ulwGetSMSMessagesCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetSMSMessagesCount not implemented"));
   return 0;
}

/**
 * Method: blIsPredefinedSMSParagraphsSupported
  * Indicates whether Predefined SMS Paragraphs are supported or not
  * 
 */
tbool clHSA_Phone_Base::blIsPredefinedSMSParagraphsSupported( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsPredefinedSMSParagraphsSupported not implemented"));
   return 0;
}

/**
 * Method: blIsPredefinedMessagePresent
  * used to disable the delete option in the custom text message if no message is saved
  * 
 */
tbool clHSA_Phone_Base::blIsPredefinedMessagePresent(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsPredefinedMessagePresent not implemented"));
   return 0;
}

/**
 * Method: ulwGetPredefinedSMSParagraphsCount
  * Returns the count of the items contained by the Predefined SMS Messages list
  * 
 */
ulword clHSA_Phone_Base::ulwGetPredefinedSMSParagraphsCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetPredefinedSMSParagraphsCount not implemented"));
   return 0;
}

/**
 * Method: vGetPredefinedSMSParagraphs
  * Returns the content of the SMS message saved in the particular list entry
  * 
 */
void clHSA_Phone_Base::vGetPredefinedSMSParagraphs(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetPredefinedSMSParagraphs not implemented"));
   
}

/**
 * Method: vGetSMSSubject
  * Returns the content of the SMS message subject saved in the particular list entry
  * 
 */
void clHSA_Phone_Base::vGetSMSSubject(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetSMSSubject not implemented"));
   
}

/**
 * Method: vSetPredefinedMsgIndex
  * Sets the DP by the predefined paragraph index 
  * NISSAN
 */
void clHSA_Phone_Base::vSetPredefinedMsgIndex(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetPredefinedMsgIndex not implemented"));
   
}

/**
 * Method: vSetInboxMsgIndex
  * Sets the DP by the Inbox index 
  * NISSAN
 */
void clHSA_Phone_Base::vSetInboxMsgIndex(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetInboxMsgIndex not implemented"));
   
}

/**
 * Method: vSpellerSetPredefinedMsg
  * Sends the predefined message entered by the user in the SETTINGS_PHONE_SMS_SPELLER
  * 
 */
void clHSA_Phone_Base::vSpellerSetPredefinedMsg(const GUI_String * Message)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( Message);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSpellerSetPredefinedMsg not implemented"));
   
}

/**
 * Method: vDeletePredefinedMessage
  * Deletes the predefined msg at a particular list entry
  * NISSAN
 */
void clHSA_Phone_Base::vDeletePredefinedMessage(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vDeletePredefinedMessage not implemented"));
   
}

/**
 * Method: blIsNewSMSIndicationSupported
  * Indicates if an indication of a new received SMS is supported or not
  * 
 */
tbool clHSA_Phone_Base::blIsNewSMSIndicationSupported( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsNewSMSIndicationSupported not implemented"));
   return 0;
}

/**
 * Method: blIsResetSMSIndicationSupported
  * Indicates if a reset of an indication of a newly received SMS is supported or not
  * 
 */
tbool clHSA_Phone_Base::blIsResetSMSIndicationSupported( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsResetSMSIndicationSupported not implemented"));
   return 0;
}

/**
 * Method: blIsReadSMSSupported
  * Indicates if reading of an SMS is supported or not
  * 
 */
tbool clHSA_Phone_Base::blIsReadSMSSupported( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsReadSMSSupported not implemented"));
   return 0;
}

/**
 * Method: blIsListSMSSupported
  * Indicates if listing of SMS messages from inbox folder is supported or not
  * 
 */
tbool clHSA_Phone_Base::blIsListSMSSupported( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsListSMSSupported not implemented"));
   return 0;
}

/**
 * Method: blIsSetSMSMsgStatusSupported
  * Indicates if setting the SMS status is supported or not
  * 
 */
tbool clHSA_Phone_Base::blIsSetSMSMsgStatusSupported( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsSetSMSMsgStatusSupported not implemented"));
   return 0;
}

/**
 * Method: blIsSendSMSSupported
  * Indicates if sending of an SMS is supported or not
  * 
 */
tbool clHSA_Phone_Base::blIsSendSMSSupported( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsSendSMSSupported not implemented"));
   return 0;
}

/**
 * Method: vResetNewSMSIndication
  * Resets new SMS message indication
  * 
 */
void clHSA_Phone_Base::vResetNewSMSIndication( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vResetNewSMSIndication not implemented"));
   
}

/**
 * Method: ulwGetSMSMessageStatus
  * Returns the status of the SMS message
  * 
 */
ulword clHSA_Phone_Base::ulwGetSMSMessageStatus(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetSMSMessageStatus not implemented"));
   return 0;
}

/**
 * Method: vGetSMSDate
  * Returns the date when the SMS message received
  * 
 */
void clHSA_Phone_Base::vGetSMSDate(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetSMSDate not implemented"));
   
}

/**
 * Method: vGetSMSTime
  * Returns the time of the SMS message received
  * 
 */
void clHSA_Phone_Base::vGetSMSTime(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetSMSTime not implemented"));
   
}

/**
 * Method: vGetSMS_SenderTelNumber
  * Returns the Telephone number of sender
  * 
 */
void clHSA_Phone_Base::vGetSMS_SenderTelNumber(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetSMS_SenderTelNumber not implemented"));
   
}

/**
 * Method: vGetSMS_SenderName
  * Returns the name of sender
  * 
 */
void clHSA_Phone_Base::vGetSMS_SenderName(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetSMS_SenderName not implemented"));
   
}

/**
 * Method: vGetSMS_SenderNameOrNumber
  * Returns the name of the sender or number if name not available
  * 
 */
void clHSA_Phone_Base::vGetSMS_SenderNameOrNumber(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetSMS_SenderNameOrNumber not implemented"));
   
}

/**
 * Method: vReadSMSMessage
  * Initiates the Read operation for SMS message
  * 
 */
void clHSA_Phone_Base::vReadSMSMessage(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vReadSMSMessage not implemented"));
   
}

/**
 * Method: vGetSMSMessageContent
  * Returns the content of SMS message.
  * 
 */
void clHSA_Phone_Base::vGetSMSMessageContent(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetSMSMessageContent not implemented"));
   
}

/**
 * Method: vSetSMSMessageStatus
  * Sets message status of SMS
  * NISSAN
 */
void clHSA_Phone_Base::vSetSMSMessageStatus(ulword ulwListEntryNr, ulword ulwMessageSts)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwMessageSts);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetSMSMessageStatus not implemented"));
   
}

/**
 * Method: vMarkSMSAsRead
  * Changes the SMS status from UNREAD to READ
  * NISSAN LCN2
 */
void clHSA_Phone_Base::vMarkSMSAsRead( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vMarkSMSAsRead not implemented"));
   
}

/**
 * Method: vSendSMSMessage
  * Send SMS message
  * NISSAN
 */
void clHSA_Phone_Base::vSendSMSMessage(const GUI_String * TelNumber, const GUI_String * Message)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( TelNumber);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED( Message);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSendSMSMessage not implemented"));
   
}

/**
 * Method: vLoadFirstSMSFromInbox
  * Loads the first SMS from the available Inbox list. Dependent on the sorting of the FC_Phone defined this is expected to be the most recent received SMS.
  * NISSAN LCN2
 */
void clHSA_Phone_Base::vLoadFirstSMSFromInbox( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vLoadFirstSMSFromInbox not implemented"));
   
}

/**
 * Method: vLoadNextSMSMessage
  * Loads the Next SMS from the available Inbox list. Base is the inbox list index of the current loaded SMS.
  * NISSAN LCN2
 */
void clHSA_Phone_Base::vLoadNextSMSMessage( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vLoadNextSMSMessage not implemented"));
   
}

/**
 * Method: vLoadPreviousSMSMessage
  * Loads the Previous SMS from the available Inbox list. Base is the inbox list index of the current loaded SMS.
  * NISSAN LCN2
 */
void clHSA_Phone_Base::vLoadPreviousSMSMessage( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vLoadPreviousSMSMessage not implemented"));
   
}

/**
 * Method: blIsStartOfSMSListReached
  * This API is to denote whether the index of the current loaded SMS is pointing to the starting of SMS list
  * NISSAN LCN2
 */
tbool clHSA_Phone_Base::blIsStartOfSMSListReached( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsStartOfSMSListReached not implemented"));
   return 0;
}

/**
 * Method: blIsEndOfSMSListReached
  * This API is to denote whether the index of the current loaded SMS is pointing to the end of SMS list
  * NISSAN LCN2
 */
tbool clHSA_Phone_Base::blIsEndOfSMSListReached( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blIsEndOfSMSListReached not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentSMSMessageIndex
  * For displaying purposes only. To get the index of the SMS currently loaded and available with GetSMSMessageContent
  * NISSAN LCN2
 */
void clHSA_Phone_Base::vGetCurrentSMSMessageIndex(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetCurrentSMSMessageIndex not implemented"));
   
}

/**
 * Method: ulwGetNumberOfUnreadMessages
  * For displaying purposes only. To get the number of Unread messages
  * NISSAN LCN2
 */
ulword clHSA_Phone_Base::ulwGetNumberOfUnreadMessages( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetNumberOfUnreadMessages not implemented"));
   return 0;
}

/**
 * Method: ulwGetCurrentSMS_MessageStatus
  * Returns the status of the SMS message that is currently being read
  * 
 */
ulword clHSA_Phone_Base::ulwGetCurrentSMS_MessageStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetCurrentSMS_MessageStatus not implemented"));
   return 0;
}

/**
 * Method: vGetCurrentSMS_Date
  * Returns the date of the SMS message that is currently being read
  * 
 */
void clHSA_Phone_Base::vGetCurrentSMS_Date(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetCurrentSMS_Date not implemented"));
   
}

/**
 * Method: vGetCurrentSMS_Time
  * Returns the time of the SMS message that is currently being read
  * 
 */
void clHSA_Phone_Base::vGetCurrentSMS_Time(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetCurrentSMS_Time not implemented"));
   
}

/**
 * Method: vGetCurrentSMS_SenderTelNumber
  * Returns the Telephone number of sender of the current SMS being read
  * 
 */
void clHSA_Phone_Base::vGetCurrentSMS_SenderTelNumber(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetCurrentSMS_SenderTelNumber not implemented"));
   
}

/**
 * Method: vGetCurrentSMS_SenderName
  * Returns the Name of sender of the current SMS being read
  * 
 */
void clHSA_Phone_Base::vGetCurrentSMS_SenderName(GUI_String *out_result)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetCurrentSMS_SenderName not implemented"));
   
}

/**
 * Method: ulwGetReadSMSMessageResult
  * Returns the method result of Read SMS message
  * 
 */
ulword clHSA_Phone_Base::ulwGetReadSMSMessageResult( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetReadSMSMessageResult not implemented"));
   return 0;
}

/**
 * Method: ulwGetSendSMSSendingStatus
  * Returns the status of sending of an SMS message
  * 
 */
ulword clHSA_Phone_Base::ulwGetSendSMSSendingStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetSendSMSSendingStatus not implemented"));
   return 0;
}

/**
 * Method: ulwGetSMSSetPredefinedMessageResult
  * Returns the method result of setting/storing a predefined SMS message
  * 
 */
ulword clHSA_Phone_Base::ulwGetSMSSetPredefinedMessageResult( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetSMSSetPredefinedMessageResult not implemented"));
   return 0;
}

/**
 * Method: ulwGetAutoReplySMSCount
  * Returns the count of Autoreply msgs. It is same as the num of items in Predefined SMS Messages list
  * 
 */
ulword clHSA_Phone_Base::ulwGetAutoReplySMSCount( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetAutoReplySMSCount not implemented"));
   return 0;
}

/**
 * Method: vGetAutoReplyMessages
  * Returns the content of the autoreply message saved in the particular list entry
  * 
 */
void clHSA_Phone_Base::vGetAutoReplyMessages(GUI_String *out_result, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(out_result);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vGetAutoReplyMessages not implemented"));
   
}

/**
 * Method: ulwGetActiveAutoReplyIndex
  * Returns the currently active auto reply index
  * 
 */
ulword clHSA_Phone_Base::ulwGetActiveAutoReplyIndex( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetActiveAutoReplyIndex not implemented"));
   return 0;
}

/**
 * Method: vToggleSMSServiceStatus
  * Toggles the SMS feature
  * 
 */
void clHSA_Phone_Base::vToggleSMSServiceStatus( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vToggleSMSServiceStatus not implemented"));
   
}

/**
 * Method: blGetSMSServiceStatus
  * Indicates if the SMS feature is On or Off
  * 
 */
tbool clHSA_Phone_Base::blGetSMSServiceStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blGetSMSServiceStatus not implemented"));
   return 0;
}

/**
 * Method: vToggleSMSDisplaySetting
  * Toggles the display control for new SMS (show in head unit and/or in cluster display)
  * 
 */
void clHSA_Phone_Base::vToggleSMSDisplaySetting( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vToggleSMSDisplaySetting not implemented"));
   
}

/**
 * Method: ulwGetSMSDisplaySetting
  * Indicates the current display settings for new SMS
  * C
 */
ulword clHSA_Phone_Base::ulwGetSMSDisplaySetting( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetSMSDisplaySetting not implemented"));
   return 0;
}

/**
 * Method: ulwNDStreamingStatus
  * Indicates the Nomadic device streaming status
  * C
 */
ulword clHSA_Phone_Base::ulwNDStreamingStatus( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwNDStreamingStatus not implemented"));
   return 0;
}

/**
 * Method: vToggleIncomingCallDisplaySetting
  * Toggles display control for incoming call(show in head unit and/or in cluster display)
  * 
 */
void clHSA_Phone_Base::vToggleIncomingCallDisplaySetting( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vToggleIncomingCallDisplaySetting not implemented"));
   
}

/**
 * Method: ulwGetIncomingCallDisplaySetting
  * Indicates the current display settings for incoming call
  * 
 */
ulword clHSA_Phone_Base::ulwGetIncomingCallDisplaySetting( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetIncomingCallDisplaySetting not implemented"));
   return 0;
}

/**
 * Method: vToggleVehicleSignature
  * Toggles the vehicle signature status
  * 
 */
void clHSA_Phone_Base::vToggleVehicleSignature( )
{
   
   ETG_TRACE_USR4(("function void clHSA_Phone::vToggleVehicleSignature not implemented"));
   
}

/**
 * Method: blGetVehicleSignatureStatus
  * Indicates if the adding of a vehicle signature to a SMS for sending is enabled or not
  * 
 */
tbool clHSA_Phone_Base::blGetVehicleSignatureStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blGetVehicleSignatureStatus not implemented"));
   return 0;
}

/**
 * Method: vSetAutoReplyMessage
  * Toggles the auto reply feature
  * 
 */
void clHSA_Phone_Base::vSetAutoReplyMessage(tbool blEnable, ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(blEnable);  // for Lint 
OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vSetAutoReplyMessage not implemented"));
   
}

/**
 * Method: blGetSMSAutoReplyFunctionStatus
  * Indicates if the auto reply feature for incoming SMS is enabled or not
  * 
 */
tbool clHSA_Phone_Base::blGetSMSAutoReplyFunctionStatus( )
{
   
   ETG_TRACE_USR4(("function tbool clHSA_Phone::blGetSMSAutoReplyFunctionStatus not implemented"));
   return 0;
}

/**
 * Method: vReplacePairedDevice
  * Replaces the paired-device selected from the list
  * 
 */
void clHSA_Phone_Base::vReplacePairedDevice(ulword ulwListEntryNr)
{
   OSAL_C_PARAMETER_INTENTIONALLY_UNUSED(ulwListEntryNr);  // for Lint 

   ETG_TRACE_USR4(("function void clHSA_Phone::vReplacePairedDevice not implemented"));
   
}

/**
 * Method: ulwGetReplacePairedDeviceProcessState
  * Returns the state of the replacing device process
  * 
 */
ulword clHSA_Phone_Base::ulwGetReplacePairedDeviceProcessState( )
{
   
   ETG_TRACE_USR4(("function ulword clHSA_Phone::ulwGetReplacePairedDeviceProcessState not implemented"));
   return 0;
}

