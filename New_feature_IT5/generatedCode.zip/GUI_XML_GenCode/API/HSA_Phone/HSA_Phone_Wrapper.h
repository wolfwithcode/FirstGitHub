/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Phone_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 */

#ifndef _HSA_Phone_Wrapper_H
#define _HSA_Phone_Wrapper_H


#define OSAL_S_IMPORT_INTERFACE_GENERIC
#include "osal_if.h"
#include "GUI_Widget/GUI_Base/GUI_Datatypes.h"

#ifdef __cplusplus
extern "C"
{
#endif

/**
 * Function: UpdateSMSInbox
 * NISSAN_15
 * NISSAN
 */
void HSA_Phone__vUpdateSMSInbox( void);

/**
 * Function: GetPhoneBookDetails_UserWord
 * B2Plus
 * NISSAN
 */
tbool HSA_Phone__blGetPhoneBookDetails_UserWord(ulword ulwListEntryNr);

/**
 * Function: SetNumber
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vSetNumber(const GUI_String * Number);

/**
 * Function: SetNumberType
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vSetNumberType(ulword ulwNumberType);

/**
 * Function: GetBatteryLevel
 * APlus
 * NISSAN
 */
ulword HSA_Phone__ulwGetBatteryLevel( void);

/**
 * Function: IsBatteryLevelAvailable
 * B1Plus
 * NISSAN
 */
tbool HSA_Phone__blIsBatteryLevelAvailable( void);

/**
 * Function: IsShortcutNumberAssigned
 * 
 * NISSAN
 */
tbool HSA_Phone__blIsShortcutNumberAssigned(ulword ulwListEntryNr);

/**
 * Function: GetShortcutNumbersList
 * 
 * NISSAN
 */
void HSA_Phone__vGetShortcutNumbersList(GUI_String *out_result, ulword ulwIndex);

/**
 * Function: SpellerSetShortcutNumber
 * 
 * NISSAN
 */
void HSA_Phone__vSpellerSetShortcutNumber(ulword ulwIndex, const GUI_String * Number);

/**
 * Function: GetCopilotList
 * 
 * NISSAN
 */
void HSA_Phone__vGetCopilotList(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: IsCopilotNumberAssigned
 * 
 * NISSAN
 */
tbool HSA_Phone__blIsCopilotNumberAssigned( void);

/**
 * Function: GetCoPilotNameOrNumber
 * 
 * NISSAN
 */
void HSA_Phone__vGetCoPilotNameOrNumber(GUI_String *out_result);

/**
 * Function: SetCopilotNumber
 * 
 * NISSAN
 */
void HSA_Phone__vSetCopilotNumber(ulword ulwIndex);

/**
 * Function: GetCopilotCountryList_Count
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetCopilotCountryList_Count( void);

/**
 * Function: GetCoPilotList_ActiveItemIndex
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetCoPilotList_ActiveItemIndex( void);

/**
 * Function: GetSSPPIN
 * 
 * NISSAN
 */
void HSA_Phone__vGetSSPPIN(GUI_String *out_result);

/**
 * Function: SetConfirmSSPPIN
 * 
 * NISSAN
 */
void HSA_Phone__vSetConfirmSSPPIN(tbool blSSPPINConfirmation);

/**
 * Function: GetConnectedDeviceAdress
 * 
 * NISSAN
 */
void HSA_Phone__vGetConnectedDeviceAdress(GUI_String *out_result);

/**
 * Function: QSInitQuickSearch
 * NISSAN_15
 * NISSAN
 */
void HSA_Phone__vQSInitQuickSearch(ulword ulwListPos);

/**
 * Function: GetQSCurrentCharacterGroupPH
 * NISSAN_15
 * NISSAN
 */
void HSA_Phone__vGetQSCurrentCharacterGroupPH(GUI_String *out_result);

/**
 * Function: SetQSIncreaseCurrentCharacterGroupPH
 * NISSAN_15
 * NISSAN
 */
void HSA_Phone__vSetQSIncreaseCurrentCharacterGroupPH( void);

/**
 * Function: SetQSDecreaseCurrentCharacterGroupPH
 * NISSAN_15
 * NISSAN
 */
void HSA_Phone__vSetQSDecreaseCurrentCharacterGroupPH( void);

/**
 * Function: QSStartSearchPH
 * NISSAN_15
 * NISSAN
 */
void HSA_Phone__vQSStartSearchPH( void);

/**
 * Function: GetPhonebookPosition
 * NISSAN_15
 * NISSAN
 */
ulword HSA_Phone__ulwGetPhonebookPosition( void);

/**
 * Function: IsBTAudioPlaying
 * NISSAN
 * NISSAN
 */
tbool HSA_Phone__blIsBTAudioPlaying( void);

/**
 * Function: IsBtSetupVisibilityVisibleAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_Phone__blIsBtSetupVisibilityVisibleAvailable( void);

/**
 * Function: IsBtSetupVisibilityInvisibleAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_Phone__blIsBtSetupVisibilityInvisibleAvailable( void);

/**
 * Function: IsBtSetupConnectStartAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_Phone__blIsBtSetupConnectStartAvailable( void);

/**
 * Function: IsBtSetupDeletePairAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_Phone__blIsBtSetupDeletePairAvailable( void);

/**
 * Function: GetDevices_IsA2DPorHFP
 * NISSAN
 * NISSAN
 */
ulword HSA_Phone__ulwGetDevices_IsA2DPorHFP(ulword ulwList, ulword ulwListEntryNr);

/**
 * Function: DialNumberByID
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vDialNumberByID(ulword ulwListEntryNbr);

/**
 * Function: GetSpellerMatchIndex
 * NISSAN n VW
 * NISSAN
 */
ulword HSA_Phone__ulwGetSpellerMatchIndex( void);

/**
 * Function: GetSpellerMatchFoundResult
 * NISSAN
 * NISSAN
 */
ulword HSA_Phone__ulwGetSpellerMatchFoundResult( void);

/**
 * Function: IsSpellerMatchFound
 * NISSAN
 * NISSAN
 */
tbool HSA_Phone__blIsSpellerMatchFound( void);

/**
 * Function: IsVoiceRecognitionFunctionAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_Phone__blIsVoiceRecognitionFunctionAvailable( void);

/**
 * Function: GetVoiceRecognitionState
 * NISSAN
 * NISSAN
 */
tbool HSA_Phone__blGetVoiceRecognitionState( void);

/**
 * Function: SetVoiceRecognitionState
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vSetVoiceRecognitionState(ulword ulwRecognitionstate);

/**
 * Function: GetVoiceRecognitionResult
 * NISSAN
 * NISSAN
 */
ulword HSA_Phone__ulwGetVoiceRecognitionResult( void);

/**
 * Function: GetSiriStatus
 * NISSAN
 * NISSAN
 */
ulword HSA_Phone__ulwGetSiriStatus( void);

/**
 * Function: GetSiriOrVA_SWCSetting
 * NISSAN
 * NISSAN
 */
ulword HSA_Phone__ulwGetSiriOrVA_SWCSetting( void);

/**
 * Function: SetSiriOrVA_SWCSetting
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vSetSiriOrVA_SWCSetting(ulword ulwVRSetting);

/**
 * Function: ToggleBTMode
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vToggleBTMode( void);

/**
 * Function: GetBTMode
 * NISSAN
 * NISSAN
 */
ulword HSA_Phone__ulwGetBTMode( void);

/**
 * Function: AcceptCall
 * BPlus
 * NISSAN
 */
tbool HSA_Phone__blAcceptCall(ulword ulwitemID);

/**
 * Function: ActivateCall
 * BPlus
 * NISSAN
 */
tbool HSA_Phone__blActivateCall(ulword ulwitemID);

/**
 * Function: AddToConference
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vAddToConference(ulword ulwitemID);

/**
 * Function: CancelPairingProcess
 * APlus
 * NISSAN
 */
void HSA_Phone__vCancelPairingProcess( void);

/**
 * Function: CheckPIN
 * 
 * NISSAN
 */
void HSA_Phone__vCheckPIN( void);

/**
 * Function: ClearMissedCallIndication
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vClearMissedCallIndication( void);

/**
 * Function: ConnectDevice
 * APlus
 * NISSAN
 */
void HSA_Phone__vConnectDevice(ulword ulwListEntryNr);

/**
 * Function: DeletePairedDevice
 * APlus
 * NISSAN
 */
tbool HSA_Phone__blDeletePairedDevice(ulword ulwListEntryNr);

/**
 * Function: DialEmergencyNumber
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vDialEmergencyNumber( void);

/**
 * Function: DialNumber
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vDialNumber(const GUI_String * Number);

/**
 * Function: DialNumberName
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vDialNumberName(const GUI_String * Number, const GUI_String * Name);

/**
 * Function: DialNumberForPOI
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vDialNumberForPOI( void);

/**
 * Function: DialCopilotNumber
 * 
 * NISSAN
 */
void HSA_Phone__vDialCopilotNumber( void);

/**
 * Function: GetPOINumberAvailability
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetPOINumberAvailability( void);

/**
 * Function: GetRedialNumberAvailable
 * C1
 * NISSAN
 */
ulword HSA_Phone__ulwGetRedialNumberAvailable( void);

/**
 * Function: Redial
 * C1
 * NISSAN
 */
void HSA_Phone__vRedial( void);

/**
 * Function: GetOutgoingCallSource
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetOutgoingCallSource( void);

/**
 * Function: GetMaxLimitOfPBEntries
 * C
 * NISSAN
 */
ulword HSA_Phone__ulwGetMaxLimitOfPBEntries( void);

/**
 * Function: GetActivePhonebookSource
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetActivePhonebookSource( void);

/**
 * Function: GetPBNumberOfDownloadedEntries
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetPBNumberOfDownloadedEntries( void);

/**
 * Function: GetBTDevices_Names
 * APlus
 * NISSAN
 */
void HSA_Phone__vGetBTDevices_Names(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetBTPasskey
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vGetBTPasskey(GUI_String *out_result);

/**
 * Function: GetCallBarListCallBarDivertState
 * B1Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetCallBarListCallBarDivertState(ulword ulwListEntryNr);

/**
 * Function: GetCallBarListCallBarMainText
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vGetCallBarListCallBarMainText(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetCallBarListCallBarName
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vGetCallBarListCallBarName(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetCallBarListCallBarNumber
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vGetCallBarListCallBarNumber(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetCallBarListCallBarText
 * B1Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetCallBarListCallBarText(ulword ulwListEntryNr);

/**
 * Function: GetCallBarListCallDuration
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vGetCallBarListCallDuration(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetCallBarListCallState
 * B1Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetCallBarListCallState(ulword ulwListEntryNr);

/**
 * Function: GetCallBarListItem_Count
 * B1Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetCallBarListItem_Count( void);

/**
 * Function: GetConnectedDeviceName
 * APlus
 * NISSAN
 */
void HSA_Phone__vGetConnectedDeviceName(GUI_String *out_result);

/**
 * Function: GetConnectingProcessState
 * APlus
 * NISSAN
 */
ulword HSA_Phone__ulwGetConnectingProcessState( void);

/**
 * Function: GetCurrentDate
 * BPlus
 * NISSAN
 */
void HSA_Phone__vGetCurrentDate(GUI_String *out_result);

/**
 * Function: GetCurrentPhonebookSortingCriteria
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetCurrentPhonebookSortingCriteria( void);

/**
 * Function: GetDevices_IsA2DP
 * APlus
 * NISSAN
 */
ulword HSA_Phone__ulwGetDevices_IsA2DP(ulword ulwList, ulword ulwListEntryNr);

/**
 * Function: GetDevices_IsHFP
 * APlus
 * NISSAN
 */
ulword HSA_Phone__ulwGetDevices_IsHFP(ulword ulwList, ulword ulwListEntryNr);

/**
 * Function: GetDeviceState
 * B1Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetDeviceState( void);

/**
 * Function: GetDialedNumbersList_Count
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetDialedNumbersList_Count( void);

/**
 * Function: GetDialedNumbersList_Date
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetDialedNumbersList_Date(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetDialedNumbersList_Icon
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetDialedNumbersList_Icon(ulword ulwListEntryNr);

/**
 * Function: GetDialedNumbersList_Name
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetDialedNumbersList_Name(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetDialedNumbersList_Number
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetDialedNumbersList_Number(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetDialedNumbersList_NameOrNumber
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vGetDialedNumbersList_NameOrNumber(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetDialedNumbersList_Time
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetDialedNumbersList_Time(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetGSMIntensity
 * BPlus
 * NISSAN
 */
ulword HSA_Phone__ulwGetGSMIntensity( void);

/**
 * Function: GetHandsfreeState
 * BPlus
 * NISSAN
 */
tbool HSA_Phone__blGetHandsfreeState( void);

/**
 * Function: GetHandsfreeOptionState
 * BPlus
 * NISSAN
 */
ulword HSA_Phone__ulwGetHandsfreeOptionState( void);

/**
 * Function: GetMicroMuteState
 * BPlus
 * NISSAN
 */
tbool HSA_Phone__blGetMicroMuteState( void);

/**
 * Function: GetMicroMuteOptionState
 * BPlus
 * NISSAN
 */
ulword HSA_Phone__ulwGetMicroMuteOptionState( void);

/**
 * Function: GetMissedCallsList_Count
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetMissedCallsList_Count( void);

/**
 * Function: GetMissedCallsList_Date
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetMissedCallsList_Date(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetMissedCallsList_Icon
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetMissedCallsList_Icon(ulword ulwListEntryNr);

/**
 * Function: GetMissedCallsList_Name
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetMissedCallsList_Name(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetMissedCallsList_Number
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetMissedCallsList_Number(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetMissedCallsList_NameOrNumber
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vGetMissedCallsList_NameOrNumber(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetMissedCallsList_Time
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetMissedCallsList_Time(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetNewMissedCalls_Count
 * B2Plus
 * NISSAN
 */
tbool HSA_Phone__blGetNewMissedCalls_Count( void);

/**
 * Function: GetPairedDevices_ActiveItemIndex
 * APlus
 * NISSAN
 */
slword HSA_Phone__slwGetPairedDevices_ActiveItemIndex( void);

/**
 * Function: GetPairedDevices_Count
 * APlus
 * NISSAN
 */
ulword HSA_Phone__ulwGetPairedDevices_Count( void);

/**
 * Function: GetPairedDevices_Names
 * APlus
 * NISSAN
 */
void HSA_Phone__vGetPairedDevices_Names(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetPairingProcessState
 * APlus
 * NISSAN
 */
ulword HSA_Phone__ulwGetPairingProcessState( void);

/**
 * Function: GetPhoneBook
 * 
 * NISSAN
 */
void HSA_Phone__vGetPhoneBook(GUI_String *out_result, ulword uwArrayIndex, ulword ulwListEntryNr);

/**
 * Function: GetPhoneBook_Count
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetPhoneBook_Count( void);

/**
 * Function: GetPhoneBook_DetailsIcon
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetPhoneBook_DetailsIcon(ulword ulwListEntryNr);

/**
 * Function: GetSMSPhonebookIcon_Type
 * CPlus
 * NISSAN
 */
void HSA_Phone__vGetSMSPhonebookIcon_Type(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetPhoneBook_IconType
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetPhoneBook_IconType(ulword ulwListEntryNr);

/**
 * Function: GetPhoneBook_Name
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetPhoneBook_Name(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetPhoneBookAvailability
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetPhoneBookAvailability( void);

/**
 * Function: GetPhoneBookDetails_Count
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetPhoneBookDetails_Count(ulword ulwListEntryNr);

/**
 * Function: GetPhoneBookDetails_Name
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetPhoneBookDetails_Name(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetPhoneBookDetails_Number
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetPhoneBookDetails_Number(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetPhoneBookDetails_Type
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetPhoneBookDetails_Type(ulword ulwListEntryNr);

/**
 * Function: GetPhoneNumberForListEntry
 * BPlus
 * NISSAN
 */
void HSA_Phone__vGetPhoneNumberForListEntry(GUI_String *out_result, ulword ulwList, ulword ulwListEntryNr);

/**
 * Function: GetProviderName
 * APlus
 * NISSAN
 */
void HSA_Phone__vGetProviderName(GUI_String *out_result);

/**
 * Function: GetRedialNumber
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vGetRedialNumber(GUI_String *out_result);

/**
 * Function: GetRedialName
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vGetRedialName(GUI_String *out_result);

/**
 * Function: GetLastDialled_NameOrNumber
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vGetLastDialled_NameOrNumber(GUI_String *out_result);

/**
 * Function: GetProviderState
 * APlus
 * NISSAN
 */
ulword HSA_Phone__ulwGetProviderState( void);

/**
 * Function: GetReceivedCallsList_Count
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetReceivedCallsList_Count( void);

/**
 * Function: GetReceivedCallsList_Date
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetReceivedCallsList_Date(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetReceivedCallsList_Icon
 * 
 * NISSAN
 */
void HSA_Phone__vGetReceivedCallsList_Icon(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetReceivedCallsList_Icon_new
 * NISSAN
 * NISSAN
 */
ulword HSA_Phone__ulwGetReceivedCallsList_Icon_new(ulword ulwListEntryNr);

/**
 * Function: GetReceivedCallsList_Name
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetReceivedCallsList_Name(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetReceivedCallsList_Number
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetReceivedCallsList_Number(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetReceivedCallsList_NameOrNumber
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vGetReceivedCallsList_NameOrNumber(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetReceivedCallsList_Time
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vGetReceivedCallsList_Time(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetReturnToSystem
 * B2Plus
 * NISSAN
 */
tbool HSA_Phone__blGetReturnToSystem( void);

/**
 * Function: GetSIMState
 * B1Plus
 * NISSAN
 */
ulword HSA_Phone__ulwGetSIMState( void);

/**
 * Function: GetSpellerEntryField
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vGetSpellerEntryField(GUI_String *out_result);

/**
 * Function: GetSpellerEntryFieldNAR
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vGetSpellerEntryFieldNAR(GUI_String *out_result);

/**
 * Function: GetVisibility
 * APlus
 * NISSAN
 */
tbool HSA_Phone__blGetVisibility( void);

/**
 * Function: GetYesterdayDate
 * BPlus
 * NISSAN
 */
void HSA_Phone__vGetYesterdayDate(GUI_String *out_result);

/**
 * Function: HangUp
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vHangUp(ulword ulwitemID);

/**
 * Function: HoldCall
 * BPlus
 * NISSAN
 */
void HSA_Phone__vHoldCall(ulword ulwitemID);

/**
 * Function: IsBTActive
 * B1Plus
 * NISSAN
 */
tbool HSA_Phone__blIsBTActive( void);

/**
 * Function: IsCallPresent
 * B1Plus 
 * NISSAN
 */
ulword HSA_Phone__ulwIsCallPresent( void);

/**
 * Function: IsEmergencyCallPresent
 * B1Plus
 * NISSAN
 */
ulword HSA_Phone__ulwIsEmergencyCallPresent( void);

/**
 * Function: IsSecondIncomingCallPresent
 * B1Plus
 * NISSAN
 */
tbool HSA_Phone__blIsSecondIncomingCallPresent( void);

/**
 * Function: IsGSMModuleConnected
 * B1Plus
 * NISSAN
 */
tbool HSA_Phone__blIsGSMModuleConnected( void);

/**
 * Function: IsHandsfreeOptionAvailable
 * BPlus
 * NISSAN
 */
tbool HSA_Phone__blIsHandsfreeOptionAvailable( void);

/**
 * Function: IsInternalGSMModuleAvailable
 * B1Plus 
 * NISSAN
 */
tbool HSA_Phone__blIsInternalGSMModuleAvailable( void);

/**
 * Function: IsLoadPhoneBookAvailable
 * B2Plus
 * NISSAN
 */
tbool HSA_Phone__blIsLoadPhoneBookAvailable( void);

/**
 * Function: IsMicroMuteOptionAvailable
 * BPlus
 * NISSAN
 */
tbool HSA_Phone__blIsMicroMuteOptionAvailable( void);

/**
 * Function: IsRedialNumberAvailable
 * NISSAN
 * NISSAN
 */
tbool HSA_Phone__blIsRedialNumberAvailable( void);

/**
 * Function: IsRedialNameAvailable
 * 
 * NISSAN
 */
tbool HSA_Phone__blIsRedialNameAvailable( void);

/**
 * Function: IsPairedDevicesListFull
 * APlus
 * NISSAN
 */
tbool HSA_Phone__blIsPairedDevicesListFull( void);

/**
 * Function: IsPhoneMuteActive
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwIsPhoneMuteActive( void);

/**
 * Function: IsLimitedPhoneModeActive
 * B2Plus
 * NISSAN
 */
tbool HSA_Phone__blIsLimitedPhoneModeActive( void);

/**
 * Function: IsPINSpellerSupported
 * B1Plus
 * NISSAN
 */
tbool HSA_Phone__blIsPINSpellerSupported( void);

/**
 * Function: IsSetPhoneBookSortingAvailable
 * B2Plus
 * NISSAN
 */
tbool HSA_Phone__blIsSetPhoneBookSortingAvailable( void);

/**
 * Function: IsSetPhoneBookSourceAvailable
 * B2Plus
 * NISSAN
 */
tbool HSA_Phone__blIsSetPhoneBookSourceAvailable( void);

/**
 * Function: IsSignalStrengthAvailable
 * BPlus
 * NISSAN
 */
tbool HSA_Phone__blIsSignalStrengthAvailable( void);

/**
 * Function: IsUserConnected
 * B1Plus
 * NISSAN
 */
tbool HSA_Phone__blIsUserConnected( void);

/**
 * Function: PrepareSpellerEntryField
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vPrepareSpellerEntryField(const GUI_String * EntryFieldValue, ulword ulwSpeller);

/**
 * Function: SetActivePhoneBookSource
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vSetActivePhoneBookSource(ulword ulwEntryNr);

/**
 * Function: SetInitialFocusPositionInPhonebook
 * 
 * NISSAN
 */
void HSA_Phone__vSetInitialFocusPositionInPhonebook(ulword ulwIndex);

/**
 * Function: SetPhonebookSortingCriteria
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vSetPhonebookSortingCriteria(ulword ulwEntryNr);

/**
 * Function: SetReturnToSystem
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vSetReturnToSystem(tbool blReturnToSystem);

/**
 * Function: SetVisibility
 * APlus
 * NISSAN
 */
void HSA_Phone__vSetVisibility(ulword ulwVisibility);

/**
 * Function: SpellerDialNumber
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vSpellerDialNumber(const GUI_String * Number);

/**
 * Function: SpellerDiscardInput
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vSpellerDiscardInput( void);

/**
 * Function: SpellerDeleteInput
 * C
 * NISSAN
 */
void HSA_Phone__vSpellerDeleteInput( void);

/**
 * Function: SpellerEnableMatchSpeller
 * BPlus
 * NISSAN
 */
tbool HSA_Phone__blSpellerEnableMatchSpeller( void);

/**
 * Function: SpellerGetCursorPos
 * B2Plus
 * NISSAN
 */
ulword HSA_Phone__ulwSpellerGetCursorPos( void);

/**
 * Function: SpellerGetHighlightedText
 * BPlus
 * NISSAN
 */
void HSA_Phone__vSpellerGetHighlightedText(GUI_String *out_result);

/**
 * Function: SpellerGetLetterFunction
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vSpellerGetLetterFunction(GUI_String *out_result);

/**
 * Function: SpellerInvertGetLetterFunction
 * B2Plus
 * NISSAN
 */
tbool HSA_Phone__blSpellerInvertGetLetterFunction( void);

/**
 * Function: SpellerMatchGetFirst
 * BPlus
 * NISSAN
 */
void HSA_Phone__vSpellerMatchGetFirst(GUI_String *out_result, slword slwType);

/**
 * Function: SpellerMatchGetList
 * BPlus
 * NISSAN
 */
void HSA_Phone__vSpellerMatchGetList(GUI_String *out_result, ulword uwArrayIndex, ulword ulwListEntryNr);

/**
 * Function: SpellerSendPhonebookSearchString
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vSpellerSendPhonebookSearchString(const GUI_String * InputString);

/**
 * Function: SpellerSendPINInput
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vSpellerSendPINInput(const GUI_String * InputString);

/**
 * Function: SpellerSetBTPasskey
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vSpellerSetBTPasskey(const GUI_String * Number);

/**
 * Function: SpellerSetCharacter
 * B1Plus
 * NISSAN
 */
void HSA_Phone__vSpellerSetCharacter(const GUI_String * InputString);

/**
 * Function: SpellerSetMaxCharCount
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vSpellerSetMaxCharCount(slword slwCount);

/**
 * Function: StartPhonebookDownload
 * B2Plus
 * NISSAN
 */
void HSA_Phone__vStartPhonebookDownload( void);

/**
 * Function: ToggleMicroMute
 * BPlus
 * NISSAN
 */
void HSA_Phone__vToggleMicroMute( void);

/**
 * Function: TogglePrivateHandsFreeMode
 * BPlus
 * NISSAN
 */
void HSA_Phone__vTogglePrivateHandsFreeMode( void);

/**
 * Function: LoadPhoneBookDetails
 * 
 * NISSAN
 */
void HSA_Phone__vLoadPhoneBookDetails(ulword ulwListEntryNr);

/**
 * Function: IsPhoneInConnectingPhase
 * B1Plus
 * NISSAN
 */
tbool HSA_Phone__blIsPhoneInConnectingPhase( void);

/**
 * Function: GetSMSInboxUpdateStatus
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetSMSInboxUpdateStatus( void);

/**
 * Function: GetSMSMessagesCount
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetSMSMessagesCount( void);

/**
 * Function: IsPredefinedSMSParagraphsSupported
 * 
 * NISSAN
 */
tbool HSA_Phone__blIsPredefinedSMSParagraphsSupported( void);

/**
 * Function: IsPredefinedMessagePresent
 * 
 * NISSAN
 */
tbool HSA_Phone__blIsPredefinedMessagePresent(ulword ulwListEntryNr);

/**
 * Function: GetPredefinedSMSParagraphsCount
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetPredefinedSMSParagraphsCount( void);

/**
 * Function: GetPredefinedSMSParagraphs
 * 
 * NISSAN
 */
void HSA_Phone__vGetPredefinedSMSParagraphs(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetSMSSubject
 * 
 * NISSAN
 */
void HSA_Phone__vGetSMSSubject(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: SetPredefinedMsgIndex
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vSetPredefinedMsgIndex(ulword ulwListEntryNr);

/**
 * Function: SetInboxMsgIndex
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vSetInboxMsgIndex(ulword ulwListEntryNr);

/**
 * Function: SpellerSetPredefinedMsg
 * 
 * NISSAN
 */
void HSA_Phone__vSpellerSetPredefinedMsg(const GUI_String * Message);

/**
 * Function: DeletePredefinedMessage
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vDeletePredefinedMessage(ulword ulwListEntryNr);

/**
 * Function: IsNewSMSIndicationSupported
 * 
 * NISSAN
 */
tbool HSA_Phone__blIsNewSMSIndicationSupported( void);

/**
 * Function: IsResetSMSIndicationSupported
 * 
 * NISSAN
 */
tbool HSA_Phone__blIsResetSMSIndicationSupported( void);

/**
 * Function: IsReadSMSSupported
 * 
 * NISSAN
 */
tbool HSA_Phone__blIsReadSMSSupported( void);

/**
 * Function: IsListSMSSupported
 * 
 * NISSAN
 */
tbool HSA_Phone__blIsListSMSSupported( void);

/**
 * Function: IsSetSMSMsgStatusSupported
 * 
 * NISSAN
 */
tbool HSA_Phone__blIsSetSMSMsgStatusSupported( void);

/**
 * Function: IsSendSMSSupported
 * 
 * NISSAN
 */
tbool HSA_Phone__blIsSendSMSSupported( void);

/**
 * Function: ResetNewSMSIndication
 * 
 * NISSAN
 */
void HSA_Phone__vResetNewSMSIndication( void);

/**
 * Function: GetSMSMessageStatus
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetSMSMessageStatus(ulword ulwListEntryNr);

/**
 * Function: GetSMSDate
 * 
 * NISSAN
 */
void HSA_Phone__vGetSMSDate(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetSMSTime
 * 
 * NISSAN
 */
void HSA_Phone__vGetSMSTime(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetSMS_SenderTelNumber
 * 
 * NISSAN
 */
void HSA_Phone__vGetSMS_SenderTelNumber(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetSMS_SenderName
 * 
 * NISSAN
 */
void HSA_Phone__vGetSMS_SenderName(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetSMS_SenderNameOrNumber
 * 
 * NISSAN
 */
void HSA_Phone__vGetSMS_SenderNameOrNumber(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: ReadSMSMessage
 * 
 * NISSAN
 */
void HSA_Phone__vReadSMSMessage(ulword ulwListEntryNr);

/**
 * Function: GetSMSMessageContent
 * 
 * NISSAN
 */
void HSA_Phone__vGetSMSMessageContent(GUI_String *out_result);

/**
 * Function: SetSMSMessageStatus
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vSetSMSMessageStatus(ulword ulwListEntryNr, ulword ulwMessageSts);

/**
 * Function: MarkSMSAsRead
 * NISSAN LCN2
 * NISSAN
 */
void HSA_Phone__vMarkSMSAsRead( void);

/**
 * Function: SendSMSMessage
 * NISSAN
 * NISSAN
 */
void HSA_Phone__vSendSMSMessage(const GUI_String * TelNumber, const GUI_String * Message);

/**
 * Function: LoadFirstSMSFromInbox
 * NISSAN LCN2
 * NISSAN
 */
void HSA_Phone__vLoadFirstSMSFromInbox( void);

/**
 * Function: LoadNextSMSMessage
 * NISSAN LCN2
 * NISSAN
 */
void HSA_Phone__vLoadNextSMSMessage( void);

/**
 * Function: LoadPreviousSMSMessage
 * NISSAN LCN2
 * NISSAN
 */
void HSA_Phone__vLoadPreviousSMSMessage( void);

/**
 * Function: IsStartOfSMSListReached
 * NISSAN LCN2
 * NISSAN
 */
tbool HSA_Phone__blIsStartOfSMSListReached( void);

/**
 * Function: IsEndOfSMSListReached
 * NISSAN LCN2
 * NISSAN
 */
tbool HSA_Phone__blIsEndOfSMSListReached( void);

/**
 * Function: GetCurrentSMSMessageIndex
 * NISSAN LCN2
 * NISSAN
 */
void HSA_Phone__vGetCurrentSMSMessageIndex(GUI_String *out_result);

/**
 * Function: GetNumberOfUnreadMessages
 * NISSAN LCN2
 * NISSAN
 */
ulword HSA_Phone__ulwGetNumberOfUnreadMessages( void);

/**
 * Function: GetCurrentSMS_MessageStatus
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetCurrentSMS_MessageStatus( void);

/**
 * Function: GetCurrentSMS_Date
 * 
 * NISSAN
 */
void HSA_Phone__vGetCurrentSMS_Date(GUI_String *out_result);

/**
 * Function: GetCurrentSMS_Time
 * 
 * NISSAN
 */
void HSA_Phone__vGetCurrentSMS_Time(GUI_String *out_result);

/**
 * Function: GetCurrentSMS_SenderTelNumber
 * 
 * NISSAN
 */
void HSA_Phone__vGetCurrentSMS_SenderTelNumber(GUI_String *out_result);

/**
 * Function: GetCurrentSMS_SenderName
 * 
 * NISSAN
 */
void HSA_Phone__vGetCurrentSMS_SenderName(GUI_String *out_result);

/**
 * Function: GetReadSMSMessageResult
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetReadSMSMessageResult( void);

/**
 * Function: GetSendSMSSendingStatus
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetSendSMSSendingStatus( void);

/**
 * Function: GetSMSSetPredefinedMessageResult
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetSMSSetPredefinedMessageResult( void);

/**
 * Function: GetAutoReplySMSCount
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetAutoReplySMSCount( void);

/**
 * Function: GetAutoReplyMessages
 * 
 * NISSAN
 */
void HSA_Phone__vGetAutoReplyMessages(GUI_String *out_result, ulword ulwListEntryNr);

/**
 * Function: GetActiveAutoReplyIndex
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetActiveAutoReplyIndex( void);

/**
 * Function: ToggleSMSServiceStatus
 * 
 * NISSAN
 */
void HSA_Phone__vToggleSMSServiceStatus( void);

/**
 * Function: GetSMSServiceStatus
 * 
 * NISSAN
 */
tbool HSA_Phone__blGetSMSServiceStatus( void);

/**
 * Function: ToggleSMSDisplaySetting
 * 
 * NISSAN
 */
void HSA_Phone__vToggleSMSDisplaySetting( void);

/**
 * Function: GetSMSDisplaySetting
 * C
 * NISSAN
 */
ulword HSA_Phone__ulwGetSMSDisplaySetting( void);

/**
 * Function: NDStreamingStatus
 * C
 * NISSAN
 */
ulword HSA_Phone__ulwNDStreamingStatus( void);

/**
 * Function: ToggleIncomingCallDisplaySetting
 * 
 * NISSAN
 */
void HSA_Phone__vToggleIncomingCallDisplaySetting( void);

/**
 * Function: GetIncomingCallDisplaySetting
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetIncomingCallDisplaySetting( void);

/**
 * Function: ToggleVehicleSignature
 * 
 * NISSAN
 */
void HSA_Phone__vToggleVehicleSignature( void);

/**
 * Function: GetVehicleSignatureStatus
 * 
 * NISSAN
 */
tbool HSA_Phone__blGetVehicleSignatureStatus( void);

/**
 * Function: SetAutoReplyMessage
 * 
 * NISSAN
 */
void HSA_Phone__vSetAutoReplyMessage(tbool blEnable, ulword ulwListEntryNr);

/**
 * Function: GetSMSAutoReplyFunctionStatus
 * 
 * NISSAN
 */
tbool HSA_Phone__blGetSMSAutoReplyFunctionStatus( void);

/**
 * Function: ReplacePairedDevice
 * 
 * NISSAN
 */
void HSA_Phone__vReplacePairedDevice(ulword ulwListEntryNr);

/**
 * Function: GetReplacePairedDeviceProcessState
 * 
 * NISSAN
 */
ulword HSA_Phone__ulwGetReplacePairedDeviceProcessState( void);

#ifdef __cplusplus
}
#endif



#endif  //#ifndef _HSA_Phone_H

