/*<<< auto-generated file. Do not edit. >>>*/

/**
 *  FILE:         HSA_Phone_Wrapper
 *  PROJECT:      CM-CR HMI Framework
 *  SW-COMPONENT: API2HSA Adapter
 *
 *  DESCRIPTION:  This file contains the wrappers, which provide the C-style 
 *                API functions and delegate the requests to the C++ objects.
 *                It also contains the TTFis tracing for the API functions.
 *                For each function, there is a trace output containing the 
 *                function-name and the values of the parameters.
 *                For each function which has an output parameter, there is
 *                an additional trace output, to trace the return value.
 *                Note, that this traces are not part of the component's trace
 *                class. But they have an own trace class:
 *                TR_CLASS_HMI_HSA_API_ENTRYPOINT_[component-name] so they can
 *                be activated/deactivated independently of the actual 
 *                component.
 *                
 *                The trace-ID has a proprietary format in order to encapsulate
 *                additional meta-infos to the TTFis Console rules. This meta-
 *                info contains: 
 *                bit 0: flag indicates if trace output reports a return value
 *                      or a paramater value
 *                bit 1-3: these 3 bits specify the datatype of the reported 
 *                value
 *                
 *                bit 4-15: these 12 bits contain the identifier of the traced
 *                function. This ID is matched in the TTFis console to the 
 *                Human Readable String (i.e. function name).
 *
 *                This complete TTFis functionality of the API Wrapper is 
 *                provided by the Code-Generator. 
 */
 
 
#include "hmicca_trace.h"
#include "HSA_Phone_Wrapper.h"
#include "clHSA_Phone_Base.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "HSA_Phone_Trace.h"
#include "hmi_trace.h"

void HSA_Phone__vUpdateSMSInbox( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__UPDATE_SMS_INBOX  ) ); 
        }
      pInst->vUpdateSMSInbox();

    }
}

tbool HSA_Phone__blGetPhoneBookDetails_UserWord(ulword ulwListEntryNr)
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__USER_WORD | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->blGetPhoneBookDetails_UserWord(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__USER_WORD | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vSetNumber(const GUI_String * Number)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_NUMBER | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)Number->ulwLen_+1, Number->pubBuffer_);
         }
      pInst->vSetNumber( Number);

    }
}

void HSA_Phone__vSetNumberType(ulword ulwNumberType)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_NUMBER_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwNumberType); 
        }
      pInst->vSetNumberType(ulwNumberType);

    }
}

ulword HSA_Phone__ulwGetBatteryLevel( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_BATTERY_LEVEL  ) ); 
        }
      ret=pInst->ulwGetBatteryLevel();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_BATTERY_LEVEL | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsBatteryLevelAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BATTERY_LEVEL_AVAILABLE  ) ); 
        }
      ret=pInst->blIsBatteryLevelAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BATTERY_LEVEL_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsShortcutNumberAssigned(ulword ulwListEntryNr)
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SHORTCUT_NUMBER_ASSIGNED | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->blIsShortcutNumberAssigned(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SHORTCUT_NUMBER_ASSIGNED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetShortcutNumbersList(GUI_String *out_result, ulword ulwIndex)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SHORTCUT_NUMBERS_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vGetShortcutNumbersList(out_result, ulwIndex);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SHORTCUT_NUMBERS_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vSpellerSetShortcutNumber(ulword ulwIndex, const GUI_String * Number)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_SHORTCUT_NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_SHORTCUT_NUMBER | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)Number->ulwLen_+1, Number->pubBuffer_);
         }
      pInst->vSpellerSetShortcutNumber(ulwIndex,  Number);

    }
}

void HSA_Phone__vGetCopilotList(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_COPILOT_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetCopilotList(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_COPILOT_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Phone__blIsCopilotNumberAssigned( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_COPILOT_NUMBER_ASSIGNED  ) ); 
        }
      ret=pInst->blIsCopilotNumberAssigned();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_COPILOT_NUMBER_ASSIGNED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetCoPilotNameOrNumber(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CO_PILOT_NAME_OR_NUMBER  ) ); 
        }
      pInst->vGetCoPilotNameOrNumber(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CO_PILOT_NAME_OR_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vSetCopilotNumber(ulword ulwIndex)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_COPILOT_NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vSetCopilotNumber(ulwIndex);

    }
}

ulword HSA_Phone__ulwGetCopilotCountryList_Count( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_COPILOT_COUNTRY_LIST__COUNT  ) ); 
        }
      ret=pInst->ulwGetCopilotCountryList_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_COPILOT_COUNTRY_LIST__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetCoPilotList_ActiveItemIndex( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CO_PILOT_LIST__ACTIVE_ITEM_INDEX  ) ); 
        }
      ret=pInst->ulwGetCoPilotList_ActiveItemIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CO_PILOT_LIST__ACTIVE_ITEM_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetSSPPIN(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SSPPIN  ) ); 
        }
      pInst->vGetSSPPIN(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SSPPIN | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vSetConfirmSSPPIN(tbool blSSPPINConfirmation)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_CONFIRM_SSPPIN | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blSSPPINConfirmation); 
        }
      pInst->vSetConfirmSSPPIN(blSSPPINConfirmation);

    }
}

void HSA_Phone__vGetConnectedDeviceAdress(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_DEVICE_ADRESS  ) ); 
        }
      pInst->vGetConnectedDeviceAdress(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_DEVICE_ADRESS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vQSInitQuickSearch(ulword ulwListPos)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__QS_INIT_QUICK_SEARCH | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListPos); 
        }
      pInst->vQSInitQuickSearch(ulwListPos);

    }
}

void HSA_Phone__vGetQSCurrentCharacterGroupPH(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_QS_CURRENT_CHARACTER_GROUP_PH  ) ); 
        }
      pInst->vGetQSCurrentCharacterGroupPH(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_QS_CURRENT_CHARACTER_GROUP_PH | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vSetQSIncreaseCurrentCharacterGroupPH( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_QS_INCREASE_CURRENT_CHARACTER_GROUP_PH  ) ); 
        }
      pInst->vSetQSIncreaseCurrentCharacterGroupPH();

    }
}

void HSA_Phone__vSetQSDecreaseCurrentCharacterGroupPH( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_QS_DECREASE_CURRENT_CHARACTER_GROUP_PH  ) ); 
        }
      pInst->vSetQSDecreaseCurrentCharacterGroupPH();

    }
}

void HSA_Phone__vQSStartSearchPH( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__QS_START_SEARCH_PH  ) ); 
        }
      pInst->vQSStartSearchPH();

    }
}

ulword HSA_Phone__ulwGetPhonebookPosition( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONEBOOK_POSITION  ) ); 
        }
      ret=pInst->ulwGetPhonebookPosition();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONEBOOK_POSITION | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsBTAudioPlaying( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BT_AUDIO_PLAYING  ) ); 
        }
      ret=pInst->blIsBTAudioPlaying();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BT_AUDIO_PLAYING | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsBtSetupVisibilityVisibleAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BT_SETUP_VISIBILITY_VISIBLE_AVAILABLE  ) ); 
        }
      ret=pInst->blIsBtSetupVisibilityVisibleAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BT_SETUP_VISIBILITY_VISIBLE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsBtSetupVisibilityInvisibleAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BT_SETUP_VISIBILITY_INVISIBLE_AVAILABLE  ) ); 
        }
      ret=pInst->blIsBtSetupVisibilityInvisibleAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BT_SETUP_VISIBILITY_INVISIBLE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsBtSetupConnectStartAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BT_SETUP_CONNECT_START_AVAILABLE  ) ); 
        }
      ret=pInst->blIsBtSetupConnectStartAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BT_SETUP_CONNECT_START_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsBtSetupDeletePairAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BT_SETUP_DELETE_PAIR_AVAILABLE  ) ); 
        }
      ret=pInst->blIsBtSetupDeletePairAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BT_SETUP_DELETE_PAIR_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetDevices_IsA2DPorHFP(ulword ulwList, ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DEVICES__IS_A2D_POR_HFP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwList); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DEVICES__IS_A2D_POR_HFP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetDevices_IsA2DPorHFP(ulwList, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DEVICES__IS_A2D_POR_HFP | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vDialNumberByID(ulword ulwListEntryNbr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__DIAL_NUMBER_BY_ID | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNbr); 
        }
      pInst->vDialNumberByID(ulwListEntryNbr);

    }
}

ulword HSA_Phone__ulwGetSpellerMatchIndex( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_MATCH_INDEX  ) ); 
        }
      ret=pInst->ulwGetSpellerMatchIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_MATCH_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetSpellerMatchFoundResult( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_MATCH_FOUND_RESULT  ) ); 
        }
      ret=pInst->ulwGetSpellerMatchFoundResult();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_MATCH_FOUND_RESULT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsSpellerMatchFound( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SPELLER_MATCH_FOUND  ) ); 
        }
      ret=pInst->blIsSpellerMatchFound();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SPELLER_MATCH_FOUND | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsVoiceRecognitionFunctionAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_VOICE_RECOGNITION_FUNCTION_AVAILABLE  ) ); 
        }
      ret=pInst->blIsVoiceRecognitionFunctionAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_VOICE_RECOGNITION_FUNCTION_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blGetVoiceRecognitionState( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_RECOGNITION_STATE  ) ); 
        }
      ret=pInst->blGetVoiceRecognitionState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_RECOGNITION_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vSetVoiceRecognitionState(ulword ulwRecognitionstate)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_VOICE_RECOGNITION_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwRecognitionstate); 
        }
      pInst->vSetVoiceRecognitionState(ulwRecognitionstate);

    }
}

ulword HSA_Phone__ulwGetVoiceRecognitionResult( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_RECOGNITION_RESULT  ) ); 
        }
      ret=pInst->ulwGetVoiceRecognitionResult();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_VOICE_RECOGNITION_RESULT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetSiriStatus( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SIRI_STATUS  ) ); 
        }
      ret=pInst->ulwGetSiriStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SIRI_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetSiriOrVA_SWCSetting( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SIRI_OR_VA_SWC_SETTING  ) ); 
        }
      ret=pInst->ulwGetSiriOrVA_SWCSetting();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SIRI_OR_VA_SWC_SETTING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vSetSiriOrVA_SWCSetting(ulword ulwVRSetting)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_SIRI_OR_VA_SWC_SETTING | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwVRSetting); 
        }
      pInst->vSetSiriOrVA_SWCSetting(ulwVRSetting);

    }
}

void HSA_Phone__vToggleBTMode( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_BT_MODE  ) ); 
        }
      pInst->vToggleBTMode();

    }
}

ulword HSA_Phone__ulwGetBTMode( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_MODE  ) ); 
        }
      ret=pInst->ulwGetBTMode();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_MODE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blAcceptCall(ulword ulwitemID)
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__ACCEPT_CALL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwitemID); 
        }
      ret=pInst->blAcceptCall(ulwitemID);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__ACCEPT_CALL | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blActivateCall(ulword ulwitemID)
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_CALL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwitemID); 
        }
      ret=pInst->blActivateCall(ulwitemID);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__ACTIVATE_CALL | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vAddToConference(ulword ulwitemID)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__ADD_TO_CONFERENCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwitemID); 
        }
      pInst->vAddToConference(ulwitemID);

    }
}

void HSA_Phone__vCancelPairingProcess( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__CANCEL_PAIRING_PROCESS  ) ); 
        }
      pInst->vCancelPairingProcess();

    }
}

void HSA_Phone__vCheckPIN( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__CHECK_PIN  ) ); 
        }
      pInst->vCheckPIN();

    }
}

void HSA_Phone__vClearMissedCallIndication( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__CLEAR_MISSED_CALL_INDICATION  ) ); 
        }
      pInst->vClearMissedCallIndication();

    }
}

void HSA_Phone__vConnectDevice(ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__CONNECT_DEVICE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vConnectDevice(ulwListEntryNr);

    }
}

tbool HSA_Phone__blDeletePairedDevice(ulword ulwListEntryNr)
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__DELETE_PAIRED_DEVICE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->blDeletePairedDevice(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__DELETE_PAIRED_DEVICE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vDialEmergencyNumber( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__DIAL_EMERGENCY_NUMBER  ) ); 
        }
      pInst->vDialEmergencyNumber();

    }
}

void HSA_Phone__vDialNumber(const GUI_String * Number)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__DIAL_NUMBER | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)Number->ulwLen_+1, Number->pubBuffer_);
         }
      pInst->vDialNumber( Number);

    }
}

void HSA_Phone__vDialNumberName(const GUI_String * Number, const GUI_String * Name)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__DIAL_NUMBER_NAME | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)Number->ulwLen_+1, Number->pubBuffer_);
             poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__DIAL_NUMBER_NAME | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)Name->ulwLen_+1, Name->pubBuffer_);
         }
      pInst->vDialNumberName( Number,  Name);

    }
}

void HSA_Phone__vDialNumberForPOI( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__DIAL_NUMBER_FOR_POI  ) ); 
        }
      pInst->vDialNumberForPOI();

    }
}

void HSA_Phone__vDialCopilotNumber( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__DIAL_COPILOT_NUMBER  ) ); 
        }
      pInst->vDialCopilotNumber();

    }
}

ulword HSA_Phone__ulwGetPOINumberAvailability( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_POI_NUMBER_AVAILABILITY  ) ); 
        }
      ret=pInst->ulwGetPOINumberAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_POI_NUMBER_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetRedialNumberAvailable( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_REDIAL_NUMBER_AVAILABLE  ) ); 
        }
      ret=pInst->ulwGetRedialNumberAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_REDIAL_NUMBER_AVAILABLE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vRedial( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__REDIAL  ) ); 
        }
      pInst->vRedial();

    }
}

ulword HSA_Phone__ulwGetOutgoingCallSource( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_OUTGOING_CALL_SOURCE  ) ); 
        }
      ret=pInst->ulwGetOutgoingCallSource();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_OUTGOING_CALL_SOURCE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetMaxLimitOfPBEntries( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MAX_LIMIT_OF_PB_ENTRIES  ) ); 
        }
      ret=pInst->ulwGetMaxLimitOfPBEntries();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MAX_LIMIT_OF_PB_ENTRIES | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetActivePhonebookSource( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_PHONEBOOK_SOURCE  ) ); 
        }
      ret=pInst->ulwGetActivePhonebookSource();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_PHONEBOOK_SOURCE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetPBNumberOfDownloadedEntries( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PB_NUMBER_OF_DOWNLOADED_ENTRIES  ) ); 
        }
      ret=pInst->ulwGetPBNumberOfDownloadedEntries();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PB_NUMBER_OF_DOWNLOADED_ENTRIES | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetBTDevices_Names(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_DEVICES__NAMES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetBTDevices_Names(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_DEVICES__NAMES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetBTPasskey(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_PASSKEY  ) ); 
        }
      pInst->vGetBTPasskey(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_BT_PASSKEY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetCallBarListCallBarDivertState(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_DIVERT_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetCallBarListCallBarDivertState(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_DIVERT_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetCallBarListCallBarMainText(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_MAIN_TEXT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetCallBarListCallBarMainText(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_MAIN_TEXT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetCallBarListCallBarName(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetCallBarListCallBarName(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetCallBarListCallBarNumber(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetCallBarListCallBarNumber(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetCallBarListCallBarText(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_TEXT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetCallBarListCallBarText(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_BAR_TEXT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetCallBarListCallDuration(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_DURATION | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetCallBarListCallDuration(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_DURATION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetCallBarListCallState(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_STATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetCallBarListCallState(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_CALL_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetCallBarListItem_Count( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_ITEM__COUNT  ) ); 
        }
      ret=pInst->ulwGetCallBarListItem_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CALL_BAR_LIST_ITEM__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetConnectedDeviceName(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_DEVICE_NAME  ) ); 
        }
      pInst->vGetConnectedDeviceName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTED_DEVICE_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetConnectingProcessState( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTING_PROCESS_STATE  ) ); 
        }
      ret=pInst->ulwGetConnectingProcessState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CONNECTING_PROCESS_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetCurrentDate(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DATE  ) ); 
        }
      pInst->vGetCurrentDate(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetCurrentPhonebookSortingCriteria( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_PHONEBOOK_SORTING_CRITERIA  ) ); 
        }
      ret=pInst->ulwGetCurrentPhonebookSortingCriteria();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_PHONEBOOK_SORTING_CRITERIA | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetDevices_IsA2DP(ulword ulwList, ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DEVICES__IS_A2DP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwList); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DEVICES__IS_A2DP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetDevices_IsA2DP(ulwList, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DEVICES__IS_A2DP | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetDevices_IsHFP(ulword ulwList, ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DEVICES__IS_HFP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwList); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DEVICES__IS_HFP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetDevices_IsHFP(ulwList, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DEVICES__IS_HFP | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetDeviceState( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DEVICE_STATE  ) ); 
        }
      ret=pInst->ulwGetDeviceState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DEVICE_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetDialedNumbersList_Count( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__COUNT  ) ); 
        }
      ret=pInst->ulwGetDialedNumbersList_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetDialedNumbersList_Date(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__DATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDialedNumbersList_Date(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetDialedNumbersList_Icon(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__ICON | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetDialedNumbersList_Icon(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__ICON | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetDialedNumbersList_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDialedNumbersList_Name(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetDialedNumbersList_Number(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDialedNumbersList_Number(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetDialedNumbersList_NameOrNumber(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__NAME_OR_NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDialedNumbersList_NameOrNumber(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__NAME_OR_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetDialedNumbersList_Time(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__TIME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetDialedNumbersList_Time(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_DIALED_NUMBERS_LIST__TIME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetGSMIntensity( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_GSM_INTENSITY  ) ); 
        }
      ret=pInst->ulwGetGSMIntensity();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_GSM_INTENSITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blGetHandsfreeState( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_HANDSFREE_STATE  ) ); 
        }
      ret=pInst->blGetHandsfreeState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_HANDSFREE_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetHandsfreeOptionState( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_HANDSFREE_OPTION_STATE  ) ); 
        }
      ret=pInst->ulwGetHandsfreeOptionState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_HANDSFREE_OPTION_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blGetMicroMuteState( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MICRO_MUTE_STATE  ) ); 
        }
      ret=pInst->blGetMicroMuteState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MICRO_MUTE_STATE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetMicroMuteOptionState( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MICRO_MUTE_OPTION_STATE  ) ); 
        }
      ret=pInst->ulwGetMicroMuteOptionState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MICRO_MUTE_OPTION_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetMissedCallsList_Count( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__COUNT  ) ); 
        }
      ret=pInst->ulwGetMissedCallsList_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetMissedCallsList_Date(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__DATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetMissedCallsList_Date(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetMissedCallsList_Icon(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__ICON | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetMissedCallsList_Icon(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__ICON | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetMissedCallsList_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetMissedCallsList_Name(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetMissedCallsList_Number(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetMissedCallsList_Number(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetMissedCallsList_NameOrNumber(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__NAME_OR_NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetMissedCallsList_NameOrNumber(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__NAME_OR_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetMissedCallsList_Time(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__TIME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetMissedCallsList_Time(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_MISSED_CALLS_LIST__TIME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Phone__blGetNewMissedCalls_Count( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_NEW_MISSED_CALLS__COUNT  ) ); 
        }
      ret=pInst->blGetNewMissedCalls_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_NEW_MISSED_CALLS__COUNT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

slword HSA_Phone__slwGetPairedDevices_ActiveItemIndex( )
{
    slword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PAIRED_DEVICES__ACTIVE_ITEM_INDEX  ) ); 
        }
      ret=pInst->slwGetPairedDevices_ActiveItemIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PAIRED_DEVICES__ACTIVE_ITEM_INDEX | TRC_RET_MASK | TRC_TYPE_SINT), 4, (tS32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetPairedDevices_Count( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PAIRED_DEVICES__COUNT  ) ); 
        }
      ret=pInst->ulwGetPairedDevices_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PAIRED_DEVICES__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetPairedDevices_Names(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PAIRED_DEVICES__NAMES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetPairedDevices_Names(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PAIRED_DEVICES__NAMES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetPairingProcessState( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PAIRING_PROCESS_STATE  ) ); 
        }
      ret=pInst->ulwGetPairingProcessState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PAIRING_PROCESS_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetPhoneBook(GUI_String *out_result, ulword uwArrayIndex, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&uwArrayIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetPhoneBook(out_result, uwArrayIndex, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetPhoneBook_Count( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK__COUNT  ) ); 
        }
      ret=pInst->ulwGetPhoneBook_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetPhoneBook_DetailsIcon(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK__DETAILS_ICON | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetPhoneBook_DetailsIcon(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK__DETAILS_ICON | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetSMSPhonebookIcon_Type(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_PHONEBOOK_ICON__TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetSMSPhonebookIcon_Type(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_PHONEBOOK_ICON__TYPE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetPhoneBook_IconType(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK__ICON_TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetPhoneBook_IconType(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK__ICON_TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetPhoneBook_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK__NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetPhoneBook_Name(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK__NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetPhoneBookAvailability( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK_AVAILABILITY  ) ); 
        }
      ret=pInst->ulwGetPhoneBookAvailability();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK_AVAILABILITY | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetPhoneBookDetails_Count(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__COUNT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetPhoneBookDetails_Count(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetPhoneBookDetails_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetPhoneBookDetails_Name(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetPhoneBookDetails_Number(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetPhoneBookDetails_Number(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetPhoneBookDetails_Type(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__TYPE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetPhoneBookDetails_Type(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_BOOK_DETAILS__TYPE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetPhoneNumberForListEntry(GUI_String *out_result, ulword ulwList, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_NUMBER_FOR_LIST_ENTRY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwList); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_NUMBER_FOR_LIST_ENTRY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetPhoneNumberForListEntry(out_result, ulwList, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PHONE_NUMBER_FOR_LIST_ENTRY | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetProviderName(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PROVIDER_NAME  ) ); 
        }
      pInst->vGetProviderName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PROVIDER_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetRedialNumber(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_REDIAL_NUMBER  ) ); 
        }
      pInst->vGetRedialNumber(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_REDIAL_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetRedialName(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_REDIAL_NAME  ) ); 
        }
      pInst->vGetRedialName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_REDIAL_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetLastDialled_NameOrNumber(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_DIALLED__NAME_OR_NUMBER  ) ); 
        }
      pInst->vGetLastDialled_NameOrNumber(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_LAST_DIALLED__NAME_OR_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetProviderState( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PROVIDER_STATE  ) ); 
        }
      ret=pInst->ulwGetProviderState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PROVIDER_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetReceivedCallsList_Count( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__COUNT  ) ); 
        }
      ret=pInst->ulwGetReceivedCallsList_Count();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetReceivedCallsList_Date(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__DATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetReceivedCallsList_Date(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetReceivedCallsList_Icon(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__ICON | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetReceivedCallsList_Icon(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__ICON | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetReceivedCallsList_Icon_new(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__ICON_NEW | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetReceivedCallsList_Icon_new(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__ICON_NEW | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetReceivedCallsList_Name(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetReceivedCallsList_Name(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetReceivedCallsList_Number(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetReceivedCallsList_Number(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetReceivedCallsList_NameOrNumber(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__NAME_OR_NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetReceivedCallsList_NameOrNumber(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__NAME_OR_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetReceivedCallsList_Time(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__TIME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetReceivedCallsList_Time(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RECEIVED_CALLS_LIST__TIME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Phone__blGetReturnToSystem( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RETURN_TO_SYSTEM  ) ); 
        }
      ret=pInst->blGetReturnToSystem();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_RETURN_TO_SYSTEM | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetSIMState( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SIM_STATE  ) ); 
        }
      ret=pInst->ulwGetSIMState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SIM_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetSpellerEntryField(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_ENTRY_FIELD  ) ); 
        }
      pInst->vGetSpellerEntryField(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_ENTRY_FIELD | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetSpellerEntryFieldNAR(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_ENTRY_FIELD_NAR  ) ); 
        }
      pInst->vGetSpellerEntryFieldNAR(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SPELLER_ENTRY_FIELD_NAR | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Phone__blGetVisibility( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_VISIBILITY  ) ); 
        }
      ret=pInst->blGetVisibility();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_VISIBILITY | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetYesterdayDate(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_YESTERDAY_DATE  ) ); 
        }
      pInst->vGetYesterdayDate(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_YESTERDAY_DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vHangUp(ulword ulwitemID)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__HANG_UP | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwitemID); 
        }
      pInst->vHangUp(ulwitemID);

    }
}

void HSA_Phone__vHoldCall(ulword ulwitemID)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__HOLD_CALL | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwitemID); 
        }
      pInst->vHoldCall(ulwitemID);

    }
}

tbool HSA_Phone__blIsBTActive( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BT_ACTIVE  ) ); 
        }
      ret=pInst->blIsBTActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_BT_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwIsCallPresent( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_CALL_PRESENT  ) ); 
        }
      ret=pInst->ulwIsCallPresent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_CALL_PRESENT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwIsEmergencyCallPresent( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_EMERGENCY_CALL_PRESENT  ) ); 
        }
      ret=pInst->ulwIsEmergencyCallPresent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_EMERGENCY_CALL_PRESENT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsSecondIncomingCallPresent( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SECOND_INCOMING_CALL_PRESENT  ) ); 
        }
      ret=pInst->blIsSecondIncomingCallPresent();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SECOND_INCOMING_CALL_PRESENT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsGSMModuleConnected( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_GSM_MODULE_CONNECTED  ) ); 
        }
      ret=pInst->blIsGSMModuleConnected();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_GSM_MODULE_CONNECTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsHandsfreeOptionAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_HANDSFREE_OPTION_AVAILABLE  ) ); 
        }
      ret=pInst->blIsHandsfreeOptionAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_HANDSFREE_OPTION_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsInternalGSMModuleAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_INTERNAL_GSM_MODULE_AVAILABLE  ) ); 
        }
      ret=pInst->blIsInternalGSMModuleAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_INTERNAL_GSM_MODULE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsLoadPhoneBookAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_LOAD_PHONE_BOOK_AVAILABLE  ) ); 
        }
      ret=pInst->blIsLoadPhoneBookAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_LOAD_PHONE_BOOK_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsMicroMuteOptionAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_MICRO_MUTE_OPTION_AVAILABLE  ) ); 
        }
      ret=pInst->blIsMicroMuteOptionAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_MICRO_MUTE_OPTION_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsRedialNumberAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_REDIAL_NUMBER_AVAILABLE  ) ); 
        }
      ret=pInst->blIsRedialNumberAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_REDIAL_NUMBER_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsRedialNameAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_REDIAL_NAME_AVAILABLE  ) ); 
        }
      ret=pInst->blIsRedialNameAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_REDIAL_NAME_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsPairedDevicesListFull( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_PAIRED_DEVICES_LIST_FULL  ) ); 
        }
      ret=pInst->blIsPairedDevicesListFull();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_PAIRED_DEVICES_LIST_FULL | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwIsPhoneMuteActive( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_PHONE_MUTE_ACTIVE  ) ); 
        }
      ret=pInst->ulwIsPhoneMuteActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_PHONE_MUTE_ACTIVE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsLimitedPhoneModeActive( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_LIMITED_PHONE_MODE_ACTIVE  ) ); 
        }
      ret=pInst->blIsLimitedPhoneModeActive();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_LIMITED_PHONE_MODE_ACTIVE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsPINSpellerSupported( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_PIN_SPELLER_SUPPORTED  ) ); 
        }
      ret=pInst->blIsPINSpellerSupported();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_PIN_SPELLER_SUPPORTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsSetPhoneBookSortingAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SET_PHONE_BOOK_SORTING_AVAILABLE  ) ); 
        }
      ret=pInst->blIsSetPhoneBookSortingAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SET_PHONE_BOOK_SORTING_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsSetPhoneBookSourceAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SET_PHONE_BOOK_SOURCE_AVAILABLE  ) ); 
        }
      ret=pInst->blIsSetPhoneBookSourceAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SET_PHONE_BOOK_SOURCE_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsSignalStrengthAvailable( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SIGNAL_STRENGTH_AVAILABLE  ) ); 
        }
      ret=pInst->blIsSignalStrengthAvailable();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SIGNAL_STRENGTH_AVAILABLE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsUserConnected( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_USER_CONNECTED  ) ); 
        }
      ret=pInst->blIsUserConnected();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_USER_CONNECTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vPrepareSpellerEntryField(const GUI_String * EntryFieldValue, ulword ulwSpeller)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__PREPARE_SPELLER_ENTRY_FIELD | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)EntryFieldValue->ulwLen_+1, EntryFieldValue->pubBuffer_);
             poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__PREPARE_SPELLER_ENTRY_FIELD | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwSpeller); 
        }
      pInst->vPrepareSpellerEntryField( EntryFieldValue, ulwSpeller);

    }
}

void HSA_Phone__vSetActivePhoneBookSource(ulword ulwEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_ACTIVE_PHONE_BOOK_SOURCE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
        }
      pInst->vSetActivePhoneBookSource(ulwEntryNr);

    }
}

void HSA_Phone__vSetInitialFocusPositionInPhonebook(ulword ulwIndex)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_INITIAL_FOCUS_POSITION_IN_PHONEBOOK | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwIndex); 
        }
      pInst->vSetInitialFocusPositionInPhonebook(ulwIndex);

    }
}

void HSA_Phone__vSetPhonebookSortingCriteria(ulword ulwEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_PHONEBOOK_SORTING_CRITERIA | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwEntryNr); 
        }
      pInst->vSetPhonebookSortingCriteria(ulwEntryNr);

    }
}

void HSA_Phone__vSetReturnToSystem(tbool blReturnToSystem)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_RETURN_TO_SYSTEM | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blReturnToSystem); 
        }
      pInst->vSetReturnToSystem(blReturnToSystem);

    }
}

void HSA_Phone__vSetVisibility(ulword ulwVisibility)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_VISIBILITY | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwVisibility); 
        }
      pInst->vSetVisibility(ulwVisibility);

    }
}

void HSA_Phone__vSpellerDialNumber(const GUI_String * Number)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_DIAL_NUMBER | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)Number->ulwLen_+1, Number->pubBuffer_);
         }
      pInst->vSpellerDialNumber( Number);

    }
}

void HSA_Phone__vSpellerDiscardInput( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_DISCARD_INPUT  ) ); 
        }
      pInst->vSpellerDiscardInput();

    }
}

void HSA_Phone__vSpellerDeleteInput( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_DELETE_INPUT  ) ); 
        }
      pInst->vSpellerDeleteInput();

    }
}

tbool HSA_Phone__blSpellerEnableMatchSpeller( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_ENABLE_MATCH_SPELLER  ) ); 
        }
      ret=pInst->blSpellerEnableMatchSpeller();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_ENABLE_MATCH_SPELLER | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwSpellerGetCursorPos( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS  ) ); 
        }
      ret=pInst->ulwSpellerGetCursorPos();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_CURSOR_POS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vSpellerGetHighlightedText(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_HIGHLIGHTED_TEXT  ) ); 
        }
      pInst->vSpellerGetHighlightedText(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_HIGHLIGHTED_TEXT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vSpellerGetLetterFunction(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_LETTER_FUNCTION  ) ); 
        }
      pInst->vSpellerGetLetterFunction(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_GET_LETTER_FUNCTION | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

tbool HSA_Phone__blSpellerInvertGetLetterFunction( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION  ) ); 
        }
      ret=pInst->blSpellerInvertGetLetterFunction();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_INVERT_GET_LETTER_FUNCTION | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vSpellerMatchGetFirst(GUI_String *out_result, slword slwType)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_FIRST | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwType); 
        }
      pInst->vSpellerMatchGetFirst(out_result, slwType);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_FIRST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vSpellerMatchGetList(GUI_String *out_result, ulword uwArrayIndex, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&uwArrayIndex); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_LIST | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSpellerMatchGetList(out_result, uwArrayIndex, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_MATCH_GET_LIST | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vSpellerSendPhonebookSearchString(const GUI_String * InputString)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SEND_PHONEBOOK_SEARCH_STRING | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSpellerSendPhonebookSearchString( InputString);

    }
}

void HSA_Phone__vSpellerSendPINInput(const GUI_String * InputString)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SEND_PIN_INPUT | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSpellerSendPINInput( InputString);

    }
}

void HSA_Phone__vSpellerSetBTPasskey(const GUI_String * Number)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_BT_PASSKEY | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)Number->ulwLen_+1, Number->pubBuffer_);
         }
      pInst->vSpellerSetBTPasskey( Number);

    }
}

void HSA_Phone__vSpellerSetCharacter(const GUI_String * InputString)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_CHARACTER | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)InputString->ulwLen_+1, InputString->pubBuffer_);
         }
      pInst->vSpellerSetCharacter( InputString);

    }
}

void HSA_Phone__vSpellerSetMaxCharCount(slword slwCount)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_MAX_CHAR_COUNT | TRC_PARAM_MASK | TRC_TYPE_SINT), 4, (tS32*)&slwCount); 
        }
      pInst->vSpellerSetMaxCharCount(slwCount);

    }
}

void HSA_Phone__vStartPhonebookDownload( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__START_PHONEBOOK_DOWNLOAD  ) ); 
        }
      pInst->vStartPhonebookDownload();

    }
}

void HSA_Phone__vToggleMicroMute( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_MICRO_MUTE  ) ); 
        }
      pInst->vToggleMicroMute();

    }
}

void HSA_Phone__vTogglePrivateHandsFreeMode( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_PRIVATE_HANDS_FREE_MODE  ) ); 
        }
      pInst->vTogglePrivateHandsFreeMode();

    }
}

void HSA_Phone__vLoadPhoneBookDetails(ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__LOAD_PHONE_BOOK_DETAILS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vLoadPhoneBookDetails(ulwListEntryNr);

    }
}

tbool HSA_Phone__blIsPhoneInConnectingPhase( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_PHONE_IN_CONNECTING_PHASE  ) ); 
        }
      ret=pInst->blIsPhoneInConnectingPhase();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_PHONE_IN_CONNECTING_PHASE | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetSMSInboxUpdateStatus( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_INBOX_UPDATE_STATUS  ) ); 
        }
      ret=pInst->ulwGetSMSInboxUpdateStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_INBOX_UPDATE_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetSMSMessagesCount( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_MESSAGES_COUNT  ) ); 
        }
      ret=pInst->ulwGetSMSMessagesCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_MESSAGES_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsPredefinedSMSParagraphsSupported( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_PREDEFINED_SMS_PARAGRAPHS_SUPPORTED  ) ); 
        }
      ret=pInst->blIsPredefinedSMSParagraphsSupported();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_PREDEFINED_SMS_PARAGRAPHS_SUPPORTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsPredefinedMessagePresent(ulword ulwListEntryNr)
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_PREDEFINED_MESSAGE_PRESENT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->blIsPredefinedMessagePresent(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_PREDEFINED_MESSAGE_PRESENT | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetPredefinedSMSParagraphsCount( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PREDEFINED_SMS_PARAGRAPHS_COUNT  ) ); 
        }
      ret=pInst->ulwGetPredefinedSMSParagraphsCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PREDEFINED_SMS_PARAGRAPHS_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetPredefinedSMSParagraphs(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PREDEFINED_SMS_PARAGRAPHS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetPredefinedSMSParagraphs(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_PREDEFINED_SMS_PARAGRAPHS | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetSMSSubject(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_SUBJECT | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetSMSSubject(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_SUBJECT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vSetPredefinedMsgIndex(ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_PREDEFINED_MSG_INDEX | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetPredefinedMsgIndex(ulwListEntryNr);

    }
}

void HSA_Phone__vSetInboxMsgIndex(ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_INBOX_MSG_INDEX | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetInboxMsgIndex(ulwListEntryNr);

    }
}

void HSA_Phone__vSpellerSetPredefinedMsg(const GUI_String * Message)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SPELLER_SET_PREDEFINED_MSG | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)Message->ulwLen_+1, Message->pubBuffer_);
         }
      pInst->vSpellerSetPredefinedMsg( Message);

    }
}

void HSA_Phone__vDeletePredefinedMessage(ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__DELETE_PREDEFINED_MESSAGE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vDeletePredefinedMessage(ulwListEntryNr);

    }
}

tbool HSA_Phone__blIsNewSMSIndicationSupported( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_NEW_SMS_INDICATION_SUPPORTED  ) ); 
        }
      ret=pInst->blIsNewSMSIndicationSupported();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_NEW_SMS_INDICATION_SUPPORTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsResetSMSIndicationSupported( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_RESET_SMS_INDICATION_SUPPORTED  ) ); 
        }
      ret=pInst->blIsResetSMSIndicationSupported();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_RESET_SMS_INDICATION_SUPPORTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsReadSMSSupported( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_READ_SMS_SUPPORTED  ) ); 
        }
      ret=pInst->blIsReadSMSSupported();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_READ_SMS_SUPPORTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsListSMSSupported( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_LIST_SMS_SUPPORTED  ) ); 
        }
      ret=pInst->blIsListSMSSupported();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_LIST_SMS_SUPPORTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsSetSMSMsgStatusSupported( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SET_SMS_MSG_STATUS_SUPPORTED  ) ); 
        }
      ret=pInst->blIsSetSMSMsgStatusSupported();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SET_SMS_MSG_STATUS_SUPPORTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsSendSMSSupported( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SEND_SMS_SUPPORTED  ) ); 
        }
      ret=pInst->blIsSendSMSSupported();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_SEND_SMS_SUPPORTED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vResetNewSMSIndication( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__RESET_NEW_SMS_INDICATION  ) ); 
        }
      pInst->vResetNewSMSIndication();

    }
}

ulword HSA_Phone__ulwGetSMSMessageStatus(ulword ulwListEntryNr)
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_MESSAGE_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      ret=pInst->ulwGetSMSMessageStatus(ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_MESSAGE_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetSMSDate(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_DATE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetSMSDate(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetSMSTime(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_TIME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetSMSTime(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_TIME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetSMS_SenderTelNumber(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS__SENDER_TEL_NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetSMS_SenderTelNumber(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS__SENDER_TEL_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetSMS_SenderName(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS__SENDER_NAME | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetSMS_SenderName(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS__SENDER_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetSMS_SenderNameOrNumber(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS__SENDER_NAME_OR_NUMBER | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetSMS_SenderNameOrNumber(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS__SENDER_NAME_OR_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vReadSMSMessage(ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__READ_SMS_MESSAGE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vReadSMSMessage(ulwListEntryNr);

    }
}

void HSA_Phone__vGetSMSMessageContent(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_MESSAGE_CONTENT  ) ); 
        }
      pInst->vGetSMSMessageContent(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_MESSAGE_CONTENT | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vSetSMSMessageStatus(ulword ulwListEntryNr, ulword ulwMessageSts)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_SMS_MESSAGE_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_SMS_MESSAGE_STATUS | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwMessageSts); 
        }
      pInst->vSetSMSMessageStatus(ulwListEntryNr, ulwMessageSts);

    }
}

void HSA_Phone__vMarkSMSAsRead( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__MARK_SMS_AS_READ  ) ); 
        }
      pInst->vMarkSMSAsRead();

    }
}

void HSA_Phone__vSendSMSMessage(const GUI_String * TelNumber, const GUI_String * Message)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SEND_SMS_MESSAGE | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)TelNumber->ulwLen_+1, TelNumber->pubBuffer_);
             poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SEND_SMS_MESSAGE | TRC_PARAM_MASK | TRC_TYPE_STRING), (tU8)Message->ulwLen_+1, Message->pubBuffer_);
         }
      pInst->vSendSMSMessage( TelNumber,  Message);

    }
}

void HSA_Phone__vLoadFirstSMSFromInbox( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__LOAD_FIRST_SMS_FROM_INBOX  ) ); 
        }
      pInst->vLoadFirstSMSFromInbox();

    }
}

void HSA_Phone__vLoadNextSMSMessage( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__LOAD_NEXT_SMS_MESSAGE  ) ); 
        }
      pInst->vLoadNextSMSMessage();

    }
}

void HSA_Phone__vLoadPreviousSMSMessage( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__LOAD_PREVIOUS_SMS_MESSAGE  ) ); 
        }
      pInst->vLoadPreviousSMSMessage();

    }
}

tbool HSA_Phone__blIsStartOfSMSListReached( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_START_OF_SMS_LIST_REACHED  ) ); 
        }
      ret=pInst->blIsStartOfSMSListReached();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_START_OF_SMS_LIST_REACHED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

tbool HSA_Phone__blIsEndOfSMSListReached( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_END_OF_SMS_LIST_REACHED  ) ); 
        }
      ret=pInst->blIsEndOfSMSListReached();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__IS_END_OF_SMS_LIST_REACHED | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetCurrentSMSMessageIndex(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SMS_MESSAGE_INDEX  ) ); 
        }
      pInst->vGetCurrentSMSMessageIndex(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SMS_MESSAGE_INDEX | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetNumberOfUnreadMessages( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_NUMBER_OF_UNREAD_MESSAGES  ) ); 
        }
      ret=pInst->ulwGetNumberOfUnreadMessages();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_NUMBER_OF_UNREAD_MESSAGES | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetCurrentSMS_MessageStatus( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SMS__MESSAGE_STATUS  ) ); 
        }
      ret=pInst->ulwGetCurrentSMS_MessageStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SMS__MESSAGE_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetCurrentSMS_Date(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SMS__DATE  ) ); 
        }
      pInst->vGetCurrentSMS_Date(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SMS__DATE | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetCurrentSMS_Time(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SMS__TIME  ) ); 
        }
      pInst->vGetCurrentSMS_Time(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SMS__TIME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetCurrentSMS_SenderTelNumber(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SMS__SENDER_TEL_NUMBER  ) ); 
        }
      pInst->vGetCurrentSMS_SenderTelNumber(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SMS__SENDER_TEL_NUMBER | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

void HSA_Phone__vGetCurrentSMS_SenderName(GUI_String *out_result)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SMS__SENDER_NAME  ) ); 
        }
      pInst->vGetCurrentSMS_SenderName(out_result);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_CURRENT_SMS__SENDER_NAME | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetReadSMSMessageResult( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_READ_SMS_MESSAGE_RESULT  ) ); 
        }
      ret=pInst->ulwGetReadSMSMessageResult();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_READ_SMS_MESSAGE_RESULT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetSendSMSSendingStatus( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SEND_SMS_SENDING_STATUS  ) ); 
        }
      ret=pInst->ulwGetSendSMSSendingStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SEND_SMS_SENDING_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetSMSSetPredefinedMessageResult( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_SET_PREDEFINED_MESSAGE_RESULT  ) ); 
        }
      ret=pInst->ulwGetSMSSetPredefinedMessageResult();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_SET_PREDEFINED_MESSAGE_RESULT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwGetAutoReplySMSCount( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_REPLY_SMS_COUNT  ) ); 
        }
      ret=pInst->ulwGetAutoReplySMSCount();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_REPLY_SMS_COUNT | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vGetAutoReplyMessages(GUI_String *out_result, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_REPLY_MESSAGES | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vGetAutoReplyMessages(out_result, ulwListEntryNr);
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_AUTO_REPLY_MESSAGES | TRC_RET_MASK | TRC_TYPE_STRING) , (tU8)out_result->ulwLen_+1, out_result->pubBuffer_); 
        }

    }
}

ulword HSA_Phone__ulwGetActiveAutoReplyIndex( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_AUTO_REPLY_INDEX  ) ); 
        }
      ret=pInst->ulwGetActiveAutoReplyIndex();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_ACTIVE_AUTO_REPLY_INDEX | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vToggleSMSServiceStatus( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_SMS_SERVICE_STATUS  ) ); 
        }
      pInst->vToggleSMSServiceStatus();

    }
}

tbool HSA_Phone__blGetSMSServiceStatus( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_SERVICE_STATUS  ) ); 
        }
      ret=pInst->blGetSMSServiceStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_SERVICE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vToggleSMSDisplaySetting( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_SMS_DISPLAY_SETTING  ) ); 
        }
      pInst->vToggleSMSDisplaySetting();

    }
}

ulword HSA_Phone__ulwGetSMSDisplaySetting( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_DISPLAY_SETTING  ) ); 
        }
      ret=pInst->ulwGetSMSDisplaySetting();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_DISPLAY_SETTING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

ulword HSA_Phone__ulwNDStreamingStatus( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__ND_STREAMING_STATUS  ) ); 
        }
      ret=pInst->ulwNDStreamingStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__ND_STREAMING_STATUS | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vToggleIncomingCallDisplaySetting( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_INCOMING_CALL_DISPLAY_SETTING  ) ); 
        }
      pInst->vToggleIncomingCallDisplaySetting();

    }
}

ulword HSA_Phone__ulwGetIncomingCallDisplaySetting( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_INCOMING_CALL_DISPLAY_SETTING  ) ); 
        }
      ret=pInst->ulwGetIncomingCallDisplaySetting();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_INCOMING_CALL_DISPLAY_SETTING | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vToggleVehicleSignature( )
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__TOGGLE_VEHICLE_SIGNATURE  ) ); 
        }
      pInst->vToggleVehicleSignature();

    }
}

tbool HSA_Phone__blGetVehicleSignatureStatus( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_VEHICLE_SIGNATURE_STATUS  ) ); 
        }
      ret=pInst->blGetVehicleSignatureStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_VEHICLE_SIGNATURE_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vSetAutoReplyMessage(tbool blEnable, ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_AUTO_REPLY_MESSAGE | TRC_PARAM_MASK | TRC_TYPE_BOOL), 1, (tU8*)&blEnable); 
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__SET_AUTO_REPLY_MESSAGE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vSetAutoReplyMessage(blEnable, ulwListEntryNr);

    }
}

tbool HSA_Phone__blGetSMSAutoReplyFunctionStatus( )
{
    tbool ret = false;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_AUTO_REPLY_FUNCTION_STATUS  ) ); 
        }
      ret=pInst->blGetSMSAutoReplyFunctionStatus();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_SMS_AUTO_REPLY_FUNCTION_STATUS | TRC_RET_MASK | TRC_TYPE_BOOL), 1, (tU8*)&ret); 
        }
        return ret;

    }
}

void HSA_Phone__vReplacePairedDevice(ulword ulwListEntryNr)
{
    
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__REPLACE_PAIRED_DEVICE | TRC_PARAM_MASK | TRC_TYPE_UINT), 4, (tU32*)&ulwListEntryNr); 
        }
      pInst->vReplacePairedDevice(ulwListEntryNr);

    }
}

ulword HSA_Phone__ulwGetReplacePairedDeviceProcessState( )
{
    ulword ret = 0;
    clHSA_Phone_Base *pInst=clHSA_Phone_Base::getInstance();
    if(!pInst) {
        return ret;
    }
    else {
        hmicca_tclTrace *poTrace=hmicca_tclTrace::pclGetInstance();
		        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_REPLACE_PAIRED_DEVICE_PROCESS_STATE  ) ); 
        }
      ret=pInst->ulwGetReplacePairedDeviceProcessState();
        if(poTrace) {
            poTrace->vTrace(TR_LEVEL_HMI_INFO, (tU16)(TR_CLASS_HMI_HSA_API_ENTRYPOINT_PHONE), (tU16)(HSA_API_ENTRYPOINT__GET_REPLACE_PAIRED_DEVICE_PROCESS_STATE | TRC_RET_MASK | TRC_TYPE_UINT), 4, (tU32*)&ret); 
        }
        return ret;

    }
}

#ifdef __cplusplus
}
#endif

