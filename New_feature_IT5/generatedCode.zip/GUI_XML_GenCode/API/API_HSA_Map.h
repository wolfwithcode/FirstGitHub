/*<<< auto-generated file. Do not edit. >>>
  *  FILE:         API_HSA_Map
  *  PROJECT:      CM-CR HMI Framework
  *  SW-COMPONENT: API2HSA Adapter > */

#ifndef _API_HSA_Map_H
#define _API_HSA_Map_H
#include	"API/HSA_AVDC/HSA_AVDC_Wrapper.h"
#include	"API/HSA_AVDC/HSA_Audio/HSA_AVDC_Audio_Wrapper.h"
#include	"API/HSA_GUI/HSA_GUI_Wrapper.h"
#include	"API/HSA_HMIFW_Test/HSA_HMIFW_Test_Wrapper.h"
#include	"API/HSA_Navigation/HSA_Navigation_Wrapper.h"
#include	"API/HSA_Navigation/HSA_Map/HSA_Navigation_Map_Wrapper.h"
#include	"API/HSA_Phone/HSA_Phone_Wrapper.h"
#include	"API/HSA_Radio/HSA_Radio_Wrapper.h"
#include	"API/HSA_Sound/HSA_Sound_Wrapper.h"
#include	"API/HSA_SpeechDialog/HSA_SpeechDialog_Wrapper.h"
#include	"API/HSA_System/HSA_System_Wrapper.h"
#include	"API/HSA_System/HSA_TestMode/HSA_System_TestMode_Wrapper.h"
#include	"API/HSA_System/HSA_Config/HSA_System_Config_Wrapper.h"
#include	"API/HSA_Telematic/HSA_Telematic_Wrapper.h"
#include	"API/HSA_Traffic/HSA_Traffic_Wrapper.h"
#include	"API/HSA_XMRadio/HSA_XMRadio_Wrapper.h"
#include	"API/HSA_SmartPhone/HSA_SmartPhone_Wrapper.h"
#include	"API/HSA_SXM/HSA_SXM_Wrapper.h"
#include	"API/HSA_SXM/HSA_Tabweather/HSA_SXM_Tabweather_Wrapper.h"
#include	"API/HSA_SXM/HSA_SPORTS/HSA_SXM_SPORTS_Wrapper.h"
#include	"API/HSA_SXM/HSA_STOCKS/HSA_SXM_STOCKS_Wrapper.h"
#include	"API/HSA_SXM/HSA_MOVIES/HSA_SXM_MOVIES_Wrapper.h"
#include	"API/HSA_SXM/HSA_FUEL/HSA_SXM_FUEL_Wrapper.h"
#include	"API/HSA_SXM/HSA_CHANNELART/HSA_SXM_CHANNELART_Wrapper.h"
#include	"API/HSA_SXM/HSA_SXM_TRAFFIC/HSA_SXM_SXM_TRAFFIC_Wrapper.h"
#include	"API/HSA_SXM/HSA_SXM_AUDIO/HSA_SXM_SXM_AUDIO_Wrapper.h"
#include	"API/HSA_TCU/HSA_TCU_Wrapper.h"
#include	"API/HSA_Climate/HSA_Climate_Wrapper.h"
#include	"API/HSA_VehicleFunction/HSA_VehicleFunction_Wrapper.h"

#endif  //#ifndef _API_HSA_Map_H

